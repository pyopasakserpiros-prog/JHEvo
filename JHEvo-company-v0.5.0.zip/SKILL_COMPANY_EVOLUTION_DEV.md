---
name: company-evolution-dev
description: Master engineering and patch development blueprint for Siam Enterprise / Company Simulation (บริษัทจำลองธุรกิจและอุตสาหกรรมอัตโนมัติ, COMPANY_SOURCE/) up to v0.5.0. Covers the Locked Human Core 1.0.0 (14 Personalities, 18 Values, 30 Aptitudes, 12 Vitality States), Multi-Nationality Demographic & Name Pools (TH/JP/CN/VN/MM/EN), 10-Level Corporate & Factory Job Grade Hierarchy (Lv.1–Lv.10 / G1–G10), 4-Tier Multi-Branch Organizational Tree (Division -> Department -> Section -> Group/Line), Span-of-Control Headcount Quotas & Chain-of-Command Promotion Evaluation Engine (Merit vs Favoritism/Nepotism), 5-Person Lean Startup to 500-NPC High-Performance Scaling (<1ms/tick), 56x34 Greenfield Campus with 12 Constructible Expansion Facilities (Lines A/B/C/D, Raw Depot, QA Lab, Dispatch Hub, Trade Annex, Maintenance, Solar, Water Utility, Dormitory, Expo Hall), 5 Production Modes & 3 Production Regimes, End-to-End B2B Sales/Procurement/Dispatch Logistics, External World Engine (Clients, Suppliers, Competitors, Government Policy, Stock Market & Enterprise Valuation), and 20 Materials / 16 Products across 4 Sectors. Update this skill after every Company patch.
---

# Siam Enterprise / Company Simulation — Master Development Blueprint (v0.5.0)

## 1. Core Architectural Philosophy & Locked Human Core (`human-core.js`)
- **Autonomous Bottom-Up NPC Simulation**: Every operational action (B2B sales pitch, PO issuance, raw material receiving, assembly on Lines A/B/C/D, QC inspection, rework, packing, fleet dispatch, R&D research, machine maintenance, hiring, facility investment, land plot construction, and promotion evaluation) is performed by an employed NPC whose choices emerge from **Human Core 1.0.0** (`COMPANY_SOURCE/js/human-core.js`).
- **Strictly Locked Human Core**: `COMPANY_SOURCE/js/human-core.js` (`SHA-256: fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32`) and `COMPANY_SOURCE/CORE_LOCK.json` are permanently locked. Never edit them.
- **Closed-Loop Accounting & Material Conservation**:
  - Every financial transaction is integer satang posted through `CompanyEconomy.post`.
  - Material stock strictly satisfies `stock === opening + purchased - consumed` and `reserved <= stock`.
  - Product units strictly satisfy `completed === shipped + finished` and `started === shipped + scrapped + inProcess`.

## 2. 10-Level Job Grade Hierarchy (`Lv.1`–`Lv.10` / `G1`–`G10`) & 4-Tier Org Tree (`ORG_TREE`)
- **10-Level Career Ladders (`CAREER_LADDERS` in `data.js`)**:
  - Every role (`sales`, `admin`, `engineer`, `assembler`, `inspector`, `logistics`, `coordinator`) has 10 distinct career levels:
    - `Lv.1 (G1)`: พนักงานปฏิบัติการระดับต้น (Junior Operator / Staff)
    - `Lv.2 (G2)`: พนักงานชำนาญการ / อาวุโส (Senior Specialist / Skilled Tech)
    - `Lv.3 (G3)`: หัวหน้ากลุ่มงาน / หัวหน้าชุดในไลน์ผลิต (Group Leader / Line Leader)
    - `Lv.4 (G4)`: หัวหน้าหมวด / หัวหน้ากะสายการผลิต (Section Supervisor / Shift Foreman)
    - `Lv.5 (G5)`: รองหัวหน้าแผนก / ผู้ช่วยผู้จัดการแผนก (Assistant Department Manager)
    - `Lv.6 (G6)`: หัวหน้าแผนก / ผู้จัดการแผนก (Department Manager)
    - `Lv.7 (G7)`: รองหัวหน้าฝ่าย / รองผู้จัดการโรงงาน (Deputy Division Director / Deputy Plant Mgr)
    - `Lv.8 (G8)`: หัวหน้าฝ่าย / ผู้อำนวยการฝ่าย / ผู้จัดการโรงงาน (Division Director / Plant GM)
    - `Lv.9 (G9)`: รองกรรมการผู้จัดการใหญ่ C-Suite (`EVP / CCO / CFO / CTO / COO / CSCO`)
    - `Lv.10 (G10)`: ประธานเจ้าหน้าที่บริหารสูงสุด (`CEO / President`)
- **4-Tier Organizational Tree (`ORG_TREE` & `resolveOrgAssignment`)**:
  - `Division (สายงาน)` -> `Department (ฝ่าย)` -> `Section (แผนก)` -> `Group/Line (กลุ่มงาน/ไลน์ผลิต)`.
  - Constructing new production line buildings (`prodLineB`, `prodLineC`, `prodLineD`) dynamically branches assembler sections across Lines A, B, C, and D (`การแตกไลน์ผลิต`).
- **Span-of-Control Quotas (`getDepartmentHeadroom`) & Chain-of-Command Promotions (`evaluatePromotions`)**:
  - Enforces pyramid quotas across all 10 levels (`Lv.2`: 45% of dept; `Lv.3`: 1 per 5 staff; `Lv.4`: 1 per 7–8 staff when expanded; `Lv.5`: 1 per 10; `Lv.6`: 1 per 14; `Lv.7`: 1 per 20; `Lv.8`: 1 per 28; `Lv.9`: 1 C-Suite per role; `Lv.10`: 1 CEO company-wide).
  - `findSupervisorForRole(w, roleId, targetLevel)` finds the direct superior at `level >= targetLevel` in the same department, escalating to higher directors or the CEO (`coordinator`), and scores candidates using Human Core `integrity`/`fairness` (Merit) vs `trust`/`familiarity` (Favoritism/Nepotism).

## 3. 56×34 Greenfield Campus, 12 Constructible Facilities & 5 Production Modes
- **56×34 Greenfield Layout (`layout.js`)**:
  - West Office Zone (`x: 1..15, y: 1..32`) and East Factory Zone (`x: 17..54, y: 1..32`) separated by wall at `x = 16` with 4 doors (`y = 6, 14, 20, 27`).
  - Keep `(32, 4)` and `(32, 5)` unblocked for station installation tests.
- **12 Constructible Expansion Plots (`EXPANSION_PLOTS` in `data.js`)**:
  - `rawDepot`, `prodLineB`, `dispatchHub`, `execAnnex`, `maintWorkshop`, `prodLineC`, `solarPlant`, `dormitory`, `prodLineD`, `qaLab`, `waterPlant`, `expoHall`.
- **5 Production Modes (`PRODUCTION_MODES`) & 3 Regimes (`PRODUCTION_REGIMES`)**:
  - Modes: `smt_precision`, `cnc_mechanical`, `cleanroom_batch`, `high_voltage_cell`, `automated_modular`.
  - Regimes: `craft_precision`, `lean_balanced`, `mass_throughput`.
  - Catalog includes **20 raw materials** and **16 products** across 4 industrial sectors (`tech`, `automotive`, `food`, `energy`).
- **High-Performance 500-NPC Scaling (`< 1 ms/tick`)**:
  - `layout.js` uses an 8,192-entry LRU `pathCache`.
  - `sim.js` builds an $O(1)$ per-tick spatial/social index (`tickCtx`) when `w.people.length > 15`.
