# ACTIVE PATCH PROMPT — Patch v5.6.0 (Era 5 Phase 7: Defensive Kungfu, Support Arts & Forbidden Arts Tangible Overhaul)

## Target Identifiers
- **Patch Version**: `5.6.0` (`SIM.PATCH_VERSION = '5.6.0'`)
- **Save Schema Version**: `5.6.0-defensive-support-and-forbidden-arts` (`SIM.SAVE_SCHEMA_VERSION = '5.6.0-defensive-support-and-forbidden-arts'`)
- **Prerequisite Baseline**: `v5.5.0` (`131/131` suites passed)

## Scope & Engineering Requirements
Continuing the Martial Category Identity Overhaul series (after `MOVEMENT_TECHNIQUE` in `v5.4.0` and `MANTRA` / `INNER_KUNGFU` in `v5.5.0`), elevate the next three technique categories so each has distinct, tangible Sect Map, Combat, and Visual mechanics:
1. **`DEFENSIVE_TECHNIQUE` (`วิชาคุ้มกาย / ปราณเกราะคุ้มครอง`)**:
   - Visible protective barrier stances (Iron Shirt / Golden Bell / Mirror Qi Reflection / Gossamer Silk Redirection / Astral Aegis) with active Poise/Guard gauges, projectile deflection, and ally bodyguard interception.
2. **`SUPPORT_TECHNIQUE` (`วิชาหนุนเสริม / ค่ายกลประสาน / ดนตรีปราณ`)**:
   - Sect Map & Battlefield support auras (Zither Sound-Wave Buffs, Acupoint Meridians Boost, Battle Flag Formation Command, Spirit Herb Mist) that buff nearby disciples during work, training, and group combat.
3. **`FORBIDDEN_ART` (`วิชาต้องห้าม / เคล็ดมารเผาโลหิต`)**:
   - High-risk, overwhelming power techniques (`Blood Essence Sacrifice`, `Lifespan Ignition`, `Soul-Devouring Berserk`) that grant massive temporary realm/combat surges (`+60%` to `+100%` power) at authentic costs (temporary meridian backlash, lifespan burn, or Heart Demon spike) with crimson-black forbidden seal VFX on the Sect Map.
4. **Verification & Packaging**:
   - Add `GAME_SOURCE/test/v560_defensive_support_and_forbidden_arts_suite.js` (`132/132 PASS`), validate schema (`0 Errors / 0 Warnings`), rebuild `GAME_SOURCE/JianghuSect_single.html`, write `PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_V5_6_0.md`, and package `JHEvo-main-v5.6.0.zip`.
