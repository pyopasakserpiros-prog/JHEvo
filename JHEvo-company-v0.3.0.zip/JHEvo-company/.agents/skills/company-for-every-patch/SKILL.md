---
name: company-for-every-patch
description: Evergreen pre-patch and post-patch workflow, architectural invariants, and mandatory documentation/skill update checklist for every patch of Siam Enterprise / Company Simulation (COMPANY_SOURCE/). Use on every Company patch alongside company-evolution-dev.
---

# Company Simulation — Evergreen Patch Workflow & Invariants (`company-for-every-patch`)

Use this skill on **every patch** of `Siam Enterprise: Autonomous Multi-Industry Company Simulation (COMPANY_SOURCE/)` alongside `company-evolution-dev`.

## 1. Pre-Patch Onboarding Sequence
Before writing code on any patch:
1. Read `START_HERE_FOR_AI.md`, `AGENTS.md`, and `project_status_and_ai_onboarding.md`.
2. Run baseline checks in `COMPANY_SOURCE/`:
   ```bash
   node tools/verify.cjs
   node tools/test.cjs
   ```
3. Check `docs/company/` and `ideas/company/` if the user's request touches workforce hierarchy, supply chain, multi-industry products, or new systems.

## 2. Non-Negotiable Architectural Invariants
1. **Locked Human Core 1.0.0 (`COMPANY_SOURCE/js/human-core.js`)**:
   - NEVER edit `js/human-core.js` or `CORE_LOCK.json`.
   - `node tools/core-review.cjs` (called by `node tools/verify.cjs`) verifies exact byte-for-byte SHA-256 (`fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32`).
   - Never mutate `p.profile` directly unless cloning and re-freezing via `H.freezeProfile` inside a validated edit command.
2. **100% Autonomous NPC & CEO Gameplay**:
   - All operational actions (accepting customer offers, purchasing materials, assembling, QC, packing, shipping, invoicing, R&D, facility upgrades, debt repayment, recruitment, promotions, bonuses, machine maintenance) must happen autonomously via NPC/CEO decisions.
   - Policy and Campus Expansion sheets remain observational; player intervention is limited to time speed, camera/inspection, tracking NPCs (`⭐`), and the **Sandbox Edit Hub (`directorEdit`)**.
3. **Headcount Quotas & Human-Core Boss Promotion Evaluation**:
   - Promotions never happen automatically on hit of tenure/tasks. A vacant slot quota (`headroom`) must be open according to organizational hierarchy and company expansion.
   - The department supervisor or CEO evaluates candidates using their Human Core (Merit weighted by boss's integrity/fairness vs. Favoritism weighted by trust/familiarity/influence).
   - Social ripple effects: Candidates passed over due to nepotism feel fairness grievances (`promotionGrievance`).
4. **Closed-Loop Integer-Satang Accounting & Material Conservation**:
   - All monetary values in `sim.js` and `economy.js` are integer satang (`100` satang = `฿1`).
   - Every wage, overtime, or bonus payout must reconcile across `w.finance.entries`, `w.finance.totals`, `p.pay.totalEarned`, `p.pay.totalPaid`, and `p.pay.wallet + p.pay.outsideSpending`.
   - Every raw material and finished unit must reconcile in `S.audit(w)` and `Save.validate(w)`.
5. **RNG Stream & Save Determinism**:
   - Never consume `w.rng` inside presentation (`api.js`, `debug.js`) or cosmetic/demographic helpers (`D.createIdentity` uses deterministic hashing of `seed + ":" + personId`).
   - Repeated `app.snapshot()` calls must never mutate world state or RNG.
6. **100% Natural Thai UI (Zero Raw Internal Keys)**:
   - Always translate motive factors (`value:*`, `personality:*`, `state:*`, `effort`, `skillFit`, `delay`, etc.) via `D.translateMotiveFactor` before displaying in Character Sheet thoughts or motive chips.

## 3. Mandatory Post-Patch Checklist (Execute After Every Patch)
Before finishing any patch turn:
1. **Run Verification, Unit Tests, Build & Benchmark**:
   ```bash
   cd COMPANY_SOURCE
   node tools/verify.cjs
   node tools/test.cjs
   node tools/build.cjs
   node tools/benchmark.cjs
   ```
   Also copy `COMPANY_SOURCE/CompanyFoundation_single.html` to `COMPANY_SOURCE/Company_single.html` so both filenames are up to date.
2. **Update Project Status & Onboarding Docs**:
   - Update `project_status_and_ai_onboarding.md` with the new patch date, features implemented, test count, and known limitations.
   - Update `START_HERE_FOR_AI.md`, `README.md`, and `COMPANY_SOURCE/README.md` if new features, files, or test suites were added.
3. **Write Patch Implementation Report**:
   - Create `docs/company/PATCH_IMPLEMENTATION_REPORT_COMPANY_V<X_Y_Z>.md` (and copy to `PATCH_REPORTS/`) detailing root causes fixed, new systems added, chain-reaction effects, and verification results.
4. **Update Skills in Both ZIP and Gemini App**:
   - Update `.agents/skills/company-evolution-dev/SKILL.md` (and root `SKILL.md`) and `.agents/skills/company-for-every-patch/SKILL.md` in the repository/ZIP.
   - Call `skills:update_skill` in the Gemini App to keep `company-evolution-dev` and `company-for-every-patch` synchronized with the latest patch.
