---
name: company-evolution-dev
description: Master engineering and patch development blueprint for Siam Enterprise / Company Simulation (บริษัทจำลองธุรกิจและอุตสาหกรรมอัตโนมัติ, COMPANY_SOURCE/) up to v0.3.0. Covers the Locked Human Core 1.0.0 (14 Personalities, 18 Values, 30 Aptitudes, 12 Vitality States, Yerkes-Dodson Curve), Multi-Nationality Demographic & Name Pools (TH/JP/CN/VN/MM/EN), Organizational Headcount Quotas (Pyramid Hierarchy), Boss Promotion Evaluation Engine (Human Core Merit vs Favoritism/Nepotism & Social Ripple Effects), Multi-Industry Products (Electronics, Automotive, Agro-Food, Green Energy), Payday KPI Performance Bonuses & Satisfaction Index, Senior Mentorship & Machine Maintenance, 100% Thai Motive Translation, 2D Bird's-Eye Campus Grounds (8 Buildings), Character Sheet (8 Tabs + Compare), Living Corporate Chronicle, 1/7/30-Day 4-Account Periodic Digest, Tracked NPCs, and Sandbox Edit Hub. Update this skill after every Company patch.
---

# Siam Enterprise: Autonomous Multi-Industry Company Simulation — Master Engineering Blueprint (v0.3.0)

## 1. Core Identity & Autonomous Design Philosophy
- **Game Title**: `Siam Enterprise: Autonomous Multi-Industry Company Simulation (บริษัทจำลองธุรกิจและอุตสาหกรรมอัตโนมัติ)`
- **Source Root**: `COMPANY_SOURCE/`
- **Single-File Build**: `COMPANY_SOURCE/CompanyFoundation_single.html` (and `Company_single.html`, built via `node tools/build.cjs`, 100% Offline)
- **Core Gameplay Philosophy**:
  - **100% Autonomous NPC & CEO Loop**: Employees and the CEO (`coordinator` role) make all operational decisions autonomously based on their innate personalities, values, aptitudes, learned skills, vitality states, and cash reserves:
    - **Sales / CEO (`autoAccept`)**: Evaluates customer offers against BOM cost, margin, delivery deadline, queue load, achievement value, riskTaking, and prudence.
    - **Purchasing / Admin (`planPurchases`)**: Monitors BOM requirements vs. on-hand + in-transit inventory and orders materials while respecting payroll reserve cash.
    - **CEO Debt Repayment (`evaluateDebtRepayment`)**: Repays bank loan principal from surplus cash above a prudence-weighted safety reserve (`15..25` days of burn + payables).
    - **CEO Facility Investment (`evaluateFacilityInvestment`)**: Evaluates and upgrades 7 upgradable campus buildings (`hq`, `factory`, `warehouse`, `rnd`, `canteen`, `courtyard`, `training`) from Lv.1 to Lv.3 using company cash above reserve.
    - **CEO / HR Recruitment (`evaluateAutonomousHiring`)**: Recruits candidates when job backlog is overloaded and cash runway exceeds 30 days.
    - **Organizational Headcount Quotas (`CAREER_QUOTAS` & `getDepartmentHeadroom`)**:
      - Promotions do NOT happen automatically when employees hit an age or tenure threshold. A vacant position/slot (`โควตาตำแหน่งว่าง`) must exist according to pyramid hierarchy.
      - **Lv.1 (Staff/Operator)**: Baseline operational capacity.
      - **Lv.2 (Senior)**: Max 1 per department for small teams (deptSize 1–2); up to 50% max when deptSize >= 3.
      - **Lv.3 (Supervisor/Foreman/Manager)**: Strictly 1 per department. Opens a 2nd slot ONLY upon company expansion (facility upgraded to Lv.2+ or department size >= 4).
      - **Lv.4 (Director/C-Level)**: Base 1 company-wide (the CEO). Opens an additional executive slot ONLY when company expands (staff >= 10, cash >= 15M).
    - **Boss Promotion Evaluation Engine (`evaluatePromotions`)**:
      - Promotions are evaluated by the **Department Supervisor or CEO (Evaluator)** using the **Human Core 1.0.0 and Interpersonal Relationships**:
        - **Merit Score**: Primary skill level, KPI score, tasks completed.
        - **Favoritism / Nepotism Score**: Evaluator's personal `trust` and `familiarity` with the candidate.
        - **Evaluator's Ethics & Values**: Evaluator's `values.integrity` and `values.fairness` determine the merit vs. favoritism decision weight (high integrity = merit wins; low integrity / high influence = personal favorites win).
        - **Social Ripple Effects**: Competitors passed over due to boss favoritism experience **fairness grievances (`promotionGrievance`)**: morale drops, stress rises, trust in boss decreases. Competitors passed over fairly under a high-integrity boss accept the outcome with healthy rivalry drive.
    - **Payday KPI Performance Bonuses (`evaluateBonuses`)**: Awards a payday bonus (`bonusAwarded`) to the top KPI performer when company cash exceeds safety reserves, posting to `wages` and crediting employee `wallet`, `totalPaid`, `totalEarned`, and `career.bonusTotal`.
    - **Preventive Machine Maintenance (`evaluateMachineMaintenance`)**: Assembly work wears `w.facilities.machineCondition`; when `< 82%`, an on-duty engineer/assembler/inspector restores machine condition (`machineMaintained`).
  - **Player Role**: Observational Director & Inspector who watches the living campus, inspects deep 8-tab character sheets, tracks favorite NPCs (`⭐`), filters the Living Corporate Chronicle, reviews 1/7/30-day 4-account digests, controls simulation speed/camera, or experiments via the **Sandbox Edit Hub**.

## 2. Permanently Locked Human Core 1.0.0 (`js/human-core.js`)
- **HARD INVARIANT**: Never modify `COMPANY_SOURCE/js/human-core.js` or `COMPANY_SOURCE/CORE_LOCK.json` (`SHA-256: fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32`).
- **Dimensions**:
  - **14 Personalities (`H.PERSONALITY`)**: `sociability`, `conscientiousness`, `agreeableness`, `openness`, `riskTaking`, `stressReactivity`, `assertiveness`, `patience`, `integrity`, `adaptability`, `ambition`, `prudence`, `humility`, `optimism`
  - **18 Values (`H.VALUES`)**: `security`, `income`, `autonomy`, `fairness`, `belonging`, `learning`, `achievement`, `meaning`, `workLifeBalance`, `recognition`, `family`, `comfort`, `care`, `stewardship`, `influence`, `tradition`, `variety`, `craftsmanship`
  - **30 Aptitudes & Potentials (`H.APTITUDES`)**: Cognitive, Social/Executive, Psychomotor/Technical, and Sensory/Physical capacities.
  - **12 Vitality States (`H.STATE_DEFAULTS`)**: `energy`, `focus`, `hunger`, `stress`, `burnout`, `morale`, `health`, `sleepDebt`, `socialNeed`, `lifeBurden`, `fulfillment`, `drive`.

## 3. Multi-Industry Catalog & Supply Chain (v0.3.0)
The enterprise is NOT limited to electronics; it operates across 4 distinct industrial sectors:
1. **Electronics & Smart Tech**: `speaker`, `lamp`, `iotController` (กล่องควบคุม IoT อุตสาหกรรม: `pcb`, `casing`, `microchip`, `sensor`)
2. **Automotive & Hardware**: `autoSensor` (เซนเซอร์ยานยนต์: `pcb`, `metal_sheet`, `wire_harness`, `sensor`), `evController` (ชุดควบคุมมอเตอร์ EV: `pcb`, `metal_sheet`, `wire_harness`, `casing`)
3. **Agro-Food & Health Beverage**: `herbalDrink` (เครื่องดื่มสมุนไพรอัดขวด: `raw_extract`, `glass_bottle`, `pack_carton`), `energyProtein` (โปรตีนอัดแท่ง: `raw_extract`, `pack_carton`) — Fast bottling, strict hygiene QA focus
4. **Green Energy**: `solarCharger` (เครื่องชาร์จโซลาร์พกพา: `solar_cell`, `battery`, `casing`, `pcb`)

## 4. Module Architecture (`COMPANY_SOURCE/js/`)
1. `human-core.js`: Locked Human Core 1.0.0.
2. `data.js`: Catalog defaults, `NATIONALITIES`, `NAME_POOLS`, `STARTER_IDENTITIES`, `CAREER_LADDERS`, `CAREER_QUOTAS`, `MOTIVE_FACTOR_LABELS`, multi-industry materials/products, `createIdentity`, `translateMotiveFactor`.
3. `layout.js`: 40×25 tile grid, 4-direction A* pathfinding, station access coordinates, and site expansion.
4. `economy.js`: Integer-satang closed-loop ledger (`sales`, `materials`, `rent`, `interest`, `wages`, `overtime`, `welfare`, `loan`, `debtRepayment`, `expansion`, `equipment`, `hiring`, `customerRefund`).
5. `sim.js`: 5-minute tick engine, autonomous role/CEO loops, headcount quota checker, boss promotion evaluation engine, payday bonuses, machine maintenance, mentorship, and `audit(w)`.
6. `save.js`: Strict JSON schema validator, `identity`/`career`/`facilities` validator, and legacy save migrator.
7. `api.js`: Immutable `CompanyAPI.create` facade, `CAMPUS_BUILDINGS`, `presentChronicleEntry` (including `promotionGrievance`), `computePeriodDigest` (1/7/30d × 4 accounts), and `compareEmployees`.
8. `campus-render.js`: 2D bird's-eye campus renderer, level-scaled building visuals, smooth walking interpolation, and minimap.
9. `debug.js`: JS2-inspired dark-emerald & gold HUD, 6 bottom nav sheets, 8-tab Character Sheet (showing department headroom and boss evaluation history), Living Chronicle filter, and Sandbox Edit Hub.

## 5. Verification & Build Commands
```bash
cd COMPANY_SOURCE
node tools/verify.cjs
node tools/test.cjs
node tools/build.cjs
node tools/benchmark.cjs
```
- All 108 unit tests in `tools/test.cjs` must pass with 0 failures before packaging.
