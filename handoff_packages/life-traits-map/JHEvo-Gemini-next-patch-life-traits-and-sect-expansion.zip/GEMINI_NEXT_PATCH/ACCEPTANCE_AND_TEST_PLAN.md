# เกณฑ์ตรวจที่เสนอ — ตรวจพฤติกรรม ผลต่อเนื่อง และส่งมอบ

Gemini เพิ่ม/ปรับวิธีตรวจได้ตามโค้ดจริง ต้องแสดงหลักฐานว่าข้อกำหนดผู้ใช้เกิดขึ้นจริง ไม่ผ่านด้วยการตัดassertionหรือคืนค่าปลอม รายการนี้เป็นแผนทดสอบ ไม่ใช่ผลทดสอบที่ Codexรันแล้ว

## 1. ก่อนเริ่ม

- เก็บสำเนาซอร์สงานฉายาล่าสุดของคุณ/รายการไฟล์และผลทดสอบก่อนแก้ บันทึกbaselineให้ต่างจากmain-debugที่Codexอ่าน
- อ่านAGENTSและสกิลที่ได้รับผล ตรวจhashhuman_core.jsเทียบฐานbyte-identical, ลำดับscriptในindex/testload, path/rngและจำนวนข้อมูลที่เกี่ยวข้อง
- สำรวจ6experience/4masteryเดิม พื้นที่/เวลา/ฉายาปัจจุบัน อย่าคาดว่าซอร์สหลังฉายาเหมือนตำแหน่งบรรทัดในเอกสารนี้
- ทำdecision ledgerสั้นสำหรับการเลือกขนาด/ผัง, factorวัน, สัญญาเวลา, lifecycleและstacking, ขอบเขตE/F/Gและโอกาสเกิดจริง ใช้WORK_ITEMS.csvประกอบได้

## 2. คุณลักษณะและความชำนาญ

1. **สิทธิ์ได้มา:** NPCใหม่ไม่มีacquiredจากbirthpool; คนไม่มีเหตุการณ์ไม่เกิดtrait; คนมีเหตุการณ์จริงและถึงเงื่อนไขได้ ข้อมูลหาย/foe/ผู้ตาย/ผู้ที่ไม่เกี่ยวข้องไม่รับผิดคน
2. **หลักฐานและidempotency:** repeatedcallback, interrupted/resumed, save/load, logreplayและผ่านมากกว่า64eventไม่เพิ่มรางวัล/traitซ้ำจากเหตุการณ์เดิม ไม่ให้IDจากcalendarซ้ำตอนsubstep
3. **การเกิดจากโลกจริง:** มีscenarioที่ใช้simulation/AIตัดสินใจและจบกิจกรรมจริง ครอบคลุมนักสู้ สายสนับสนุน อาชีพและชีวิตสัมพันธ์ ไม่ใช่ทุกtestเรียกgrant/recordEventโดยตรงแล้วอ้างว่าเข้าถึงเอง
4. **ผลจริง:** compareก่อน/หลังและบริบทเปิด/ปิดของtrait; computed/fast/cached statsตรง; แสดงผลhp/qi/heal/status/movement/productionจริงตามชนิด ไม่ใช่แค่paperpower
5. **เติบโต/ฟื้นตัว:** NPCเข้าถึงกิจกรรมช่วยคลายปมได้เอง ภาระลดตามเงื่อนไข บทเรียนที่ควรอยู่ไม่หาย ไม่reacquireทันทีจากcountเก่า ไม่ทิ้งcache/bonusค้าง
6. **เพดานและองค์ประกอบ:** trait+mastery+ฉายา+daoScars+gear+passiveไม่คิดซ้ำ ไม่เกินcap/ความหมายcrit/percent; ทดสอบconflictingtraitsและเปลี่ยนบริบท/คู่หูเสียชีวิต
7. **ป้องกันฟาร์มผิดเหตุผล:** repeatedoverheal, เปิดauraลอย ๆ, ฉากโจมตีพลาด/immune, ศัตรูอ่อนมาก, ยืนlowHP, ให้เพื่อนตาย, ยกเลิกcraft, ของคนอื่นและeventduplicateไม่ให้ผลเกินกติกา
8. **ความจริงและข่าว:** การได้traitจากเหตุการณ์ลับไม่เปิดฉายาหรือข่าวแก่คนที่ไม่รู้ ข่าวลืออย่างเดียวไม่เปลี่ยนร่างกาย/ความชำนาญเป็นความจริง พงศาวดารไม่เพิ่มรายการจากผู้เห็นหน้าจอ

## 3. พื้นที่และการเดินทาง

1. วัดboundsพื้นที่ใหม่และinnercompound ตรวจgeometry/station/building/yard/road/peakterrace/plot/river/bridge/safebelt/zone/decorชัดเจน ไม่ทับสิ่งกีดขวางโดยไม่ตั้งใจ
2. หลายseedทุกทิศ: ภายใน→ภายนอก/กลับ, ใกล้→ไกล, ภายนอกข้ามเขต, พิกัด>=256, gateใกล้สุดถูกบล็อก, จุดเกิดไม่free ต้องมีทางเลือก/เหตุผลไม่ไป ไม่เดินทะลุกำแพง/น้ำ/ตัดมุม
3. เก็บสถิติเส้นทางจริงรวมรอ/กลับเทียบก่อน ไม่แก้เฉพาะหนึ่งNPCหรือหนึ่งseed ตรวจspawn/visit/exile/death/expeditionreturnและbuilding expansionหลังnavcacheเคยถูกใช้
4. ทุกstationสำคัญที่NPCใช้ประจำมีapproachและslotเข้าได้ กิน นอน รักษา งานคลัง/ผลิตและยอดเขาไม่ถูกขังหลังจัดผัง
5. อสูรเกิด/เดิน/สู้/จับ/ตายบนพื้นที่ที่สมเหตุสมผล ข้อมูลชนิด/ธาตุ/ท่า/ดรอปไม่หาย ไม่เดินขึ้นน้ำ ถิ่นเลี้ยง/สัตว์นอกพื้นที่ไม่รับlandInfluenceผิดที่
6. ถ้าทำdens/pack/party: นับเพดานทั้งฝูง จับ/ตาย/ย้ายโซนไม่ทำrespawnฟรี สมาชิกมาช้า/ตาย/หมดแรง/ไม่ยอมร่วมต้องไม่deadlock ไม่มีteleportเข้าศึก
7. minimap/project-unproject/picking/cameraclamp/ซูม/ลาก/ติดตามNPC/ติดตามศึกตรงพิกัดจริง ตรวจ360/412/1280px มีปิดsheetและปุ่มกลับการติดตาม ไม่บังพื้นที่/ล้นหน้าจอ

## 4. เวลาใหม่และ96×

1. พิสูจน์วัน1.5/2เท่าเพิ่มwork-stepก่อนวันเปลี่ยนจริงและ1×ยังเดิน/สู้จังหวะเหมาะสม การเปลี่ยนตัวคูณความเร็วไม่เปลี่ยนdayfactor
2. minute/hour/day/month/yearboundaryผ่านครั้งเดียวตามสัญญา ชั่วโมง/ฤดู/วันเวร/ปีตรงกัน ไม่เรียกdaily/hourly/spawn/เงินเดือน/rollซ้ำหรือข้ามเมื่อ1.5มีเศษ
3. hunger/rest/stress/healing/age/deadline/cultivation/craftresource/secteconomicเทียบต่อวัน ต้นทุนกิจกรรมมีจริง ไม่แจกกิจกรรมฟรีหรือทำคนหิวซ้ำจนเวลาที่เพิ่มไม่มีประโยชน์
4. 96อยู่ในปุ่มและengineจริง pause/resume/เปลี่ยนความเร็ว/เซฟ/โหลด/autosaveรักษาค่าและpendingTicks ไม่ถูกclampลง48 ไม่ทิ้งเวลาเงียบ ๆ
5. ใช้controlledclockทดสอบelapsedtimeและaccumulator ไม่เทียบแต่walltimeที่เครื่องแกว่ง และใช้browserวัดจริงเรื่องtouch/pause/เลื่อน/เปิดsheetที่96×
6. จำลองseedเดียวจำนวนwork-stepเท่ากันที่1×กับ96× ผลเชิงเกม/RNG/evidenceเท่ากันภายใต้inputsเดียวกัน แยกruntime metadataที่ต่างโดยเจตนา
7. โหลดกลางวันมีremainder กลางศึก/มีpendingticks ที่96/ขณะพักได้ไม่duplicatebonus/daily/epithet; เปิดหน้าNPCสลับกล้องไม่เปลี่ยนRNG/ผลจำลอง

## 5. วัดลูกโซ่และชีวิตระยะยาว

เปรียบเทียบbaselineฉายาล่าสุดกับค่าที่เลือก หลายseed80NPC และช่วงต้น/กลาง/ปลาย ใช้30วันเกมเป็นขั้นต่ำสำหรับสถานการณ์ที่สภาพเครื่องเอื้อ หยุดด้วยปฏิทินจริงไม่ใช้1440tick/dayตายตัวหลังเปลี่ยนเวลา

รายงานอย่างน้อย: timebudgetแยกเดิน/รอ/กิน/พัก/งาน/ฝึก/ล่า/สังคม, deadlock/hunger/rest/การตาย, จำนวนกิจกรรมจบจริง, traitเกิด/ฟื้น/การกระจายและผู้ไม่เคยเกิด, จำนวนฉายา/ข่าวและduplication, qiต่อเวลารวม/วันตามกลุ่ม, จำนวนสัตว์/cap, วัสดุและเงินเข้าออก/stock, ms/work-stepและthroughput/จำนวนtickค้างที่96× พร้อมseed/คำสั่ง/จำนวนNPC

กลไกใหม่ต้องไม่ทำทุกคนเหมือนกันหรือถอยไปเล่นกดสั่ง ถ้าผลดีเฉพาะคนแข็งแรง/อยู่ใกล้ประตูให้ปรับเหตุผล/พื้นที่ ไม่บังคับquotaให้NPCต้องล่าหรือได้trait

## 6. ชุดตรวจฐานที่ควรผูกงาน

ตรวจว่ามีไฟล์และวิธีรันตรงกับโปรเจกต์ล่าสุด คำสั่งด้านล่างอ้างฐานก่อนฉายา รันจากGAME_SOURCE:

```sh
node test/core_lock.js
node tools/validate_data_schema.js
node test/v240_user_audit_regression.js
node test/v360_immortal_endgame_dynasty_suite.js
node test/v400_living_frontier_and_sect_charter_suite.js
node test/v410_sect_expansion_and_architecture_suite.js
node test/land_hunt_rewards.js
node test/wildlife_variety_and_identity.js
node test/wildlife_spawn_integrity.js
node test/onmap_wildlife.js
node test/save_integrity.js
node test/time_controls.js
node test/runtime_timing.js
node tools/run_parallel_tests.js
node tools/build_single.js
```

เพิ่ม/ลงทะเบียนtestsพฤติกรรมใหม่ และรันชุดฉายาของคุณพร้อมsimulation/browserที่เกี่ยวข้อง ตรวจทั้งindexแบบโมดูลและsingleออฟไลน์ อย่าแก้แค่ไฟล์singleแล้วปล่อยซอร์สไม่ตรงกัน บันทึกfullsuiteที่ยังfailเดิมแยกจากregressionใหม่ ไม่อ้างว่าbrowserผ่านหากเปิดไม่ได้

ห้ามลบtestsหรือผ่อนassertionเพื่อให้ผ่านโดยไร้เหตุผล ถ้าtestยึดขนาด240×192/1440/48×เดิม ให้แก้ตามสัญญาที่ตั้งใจเปลี่ยนพร้อมเพิ่มinvariantใหม่—notเพียงเปลี่ยนตัวเลขexpectให้ตรงoutput

## 7. เอกสารและZIPส่งคืนผู้ใช้

ต้องมีREADME/สถานะเกม/รายงาน/registrytraitsและการตัดสินใจครบ72ข้ออ้างอิง, geometry/timecontract, สกิลที่เปลี่ยนและสารบัญ, activehandoffที่ตรงของที่ส่ง ห้ามแก้AGENTS.md

ส่งโปรเจกต์ฉบับเต็มต่อจากฉายาล่าสุด รวม.agents/skills, GAME_SOURCE/index.html/js/data/css/assets, tools/tests/dependencyที่เรียก, standaloneที่buildใหม่, docsและรายงานจริง ไม่ใส่.git/cache/ZIPซ้ำ/ไฟล์ชั่วคราว

ใส่directoryentriesเพื่อมือถือ เปิดZIPปิดสมบูรณ์ตรวจtestzip/CRCแล้วแตกใหม่ ตรวจชื่อไฟล์/จำนวน/SHA256เทียบต้นฉบับและเปิดเกม/รันchecksจากไฟล์ที่แตกเท่าที่ทำได้ แนบคำสั่งผลตรวจผ่าน/ไม่ผ่าน/ยังไม่ตรวจอย่างตรงไปตรงมา ใช้การส่งZIPสำหรับGeminiแอป ไม่กล่าวอ้างpushGitHub

เมื่อเสร็จหยุดรอผู้ใช้ ถ้าต้องเขียนแผนงานถัดไปตามกฎโครงการให้ติดสถานะรอผู้ใช้ ไม่เริ่มทำอัตโนมัติ
