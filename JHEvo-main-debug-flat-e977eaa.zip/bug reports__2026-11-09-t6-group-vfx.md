# T6 Shared Group VFX Implementation Plan

> Execution is inline in the existing isolated checkout under the user's delegated design/implementation authority. Checkboxes record the current execution state; they are not claims that verification preceded implementation.

**Goal:** Deliver approximately 50 different reusable T6 forms, with more group sharing than T7 and room for broader reuse in later lower tiers.

**Architecture:** Keep the existing JS/Canvas event boundary. Add exact selected maps/resolver to skills.js and pure shared painters to render.js; retain factual producer snapshots and old catalogs. No new script or save/gameplay data.

**Tech Stack:** Existing JavaScript Canvas runtime, Node assertions, Chromium browser pixel checks.

**Spec:** [T6 design/assignment registry](../../audits/T6_GROUP_VFX_REGISTRY.md), including the chosen themed-library approach and coverage exclusions.

## Global constraints

- JS2-v2.6.0 / save schema `2.6.0-living-chronicle-and-reporting` / core fingerprint `155:2f9c9dd7` unchanged.
- Main scale 42–47 px, life 1,250 ms; no Legendary apparition/bloom or per-ID T6 decoration.
- Respect user-selected scope, explicit art precedence, actual targets and active-passive/equipment eligibility.

## Review focus

- Attack-sounding mantras with null active profiles must not inflate coverage.
- Explicit child art and authoritative named Legendary override the selected group.
- Support/healing/hostile recipients must come from combat snapshots.
- Same-group members should truly reuse art across all quality/motion modes.
- Mixed tiers, fast repeated casts and broken equipment must not cause stacked spectacle or visual starvation.

### Task 1 — Library and routing

Files: `GAME_SOURCE/js/skills.js`, `GAME_SOURCE/js/render.js`, `GAME_SOURCE/test/t6_group_vfx_suite.js`.

- [x] Audit actual T6 profiles; map 114 active techniques to 50 families and 8 eligible passives to existing family shapes.
- [x] Implement `SK.resolveT6Vfx(techOrMove, moveOpt) → family|null`; `drawT6FamilyGlyph` and `drawT6SkillVfx` consume renderer-only group metadata.
- [x] Preserve child/event overrides, actual anchors, mode limits, read-only behavior and repeat progress.
- [x] Generalize existing T7 equipment accents for selected ordinary T6 at 0.82 finish with alias normalization and broken/usability exclusions.
- [x] Verify `node GAME_SOURCE/test/t6_group_vfx_suite.js`: 114 real producers / 207 child routes, 50 shapes, role/target/mode/cap/purity/gear/passive checks. Early fixture failures exposed required weapon AND armor eligibility; fixtures now satisfy the real conditions.

### Task 2 — Browser evidence and integration

Files: `GAME_SOURCE/test/t6_group_vfx_browser.js`, `GAME_SOURCE/test/run_all.js`, `docs/visuals/t6-group-vfx/`, `GAME_SOURCE/JianghuSect_single.html`.

- [x] Verify 50 distinct nonblank pixel shapes in all four quality/motion modes and 256 normalized same-family pixel comparisons.
- [x] Export actual Canvas galleries and 50-frame / 1,250 ms GIF; inspect images.
- [x] Register suites; run schema/build/core and existing visual targeted checks.
- [x] Run full regression, inspect failures, retain raw results and state any limits: final 161/162 PASS, no FAIL, existing startup overlay timeout.

### Task 3 — Handoff and delivery

Files: registry/report, project status, START_HERE_FOR_AI, README/report index, affected project skills, next T5 handoff.

- [x] Reconcile current coverage/budgets/results in all affected documents.
- [x] Review final diff; verify human_core byte identity, 40-script order, standalone consistency and clean diff.
- [x] Fetch main and prepare reviewed delivery under standing authorization. Final delivery command is `git push origin HEAD:main`; Git history records the resulting commit.
