(function (root, factory) {
  "use strict";
  const value = factory(
    typeof module === "object" && module.exports
      ? require("./human-core.js")
      : root.CompanyCore,
  );
  if (typeof module === "object" && module.exports) module.exports = value;
  else root.CompanyData = value;
})(typeof globalThis !== "undefined" ? globalThis : this, function (H) {
  "use strict";
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const idPattern = /^[a-z][a-zA-Z0-9_-]{0,63}$/;
  const validId = (id) =>
    typeof id === "string" &&
    idPattern.test(id) &&
    !["constructor", "prototype"].includes(id);
  const deepFreeze = (o) => {
    Object.values(o).forEach((v) => {
      if (v && typeof v === "object") deepFreeze(v);
    });
    return Object.freeze(o);
  };

  // Multi-nationality demographic & name pools researched from authentic regional registries:
  // TH: ThaiPod101, Moonboon, Peanut App, Forebears Thailand
  // JP: Kokoro Media, Lingopie, Interac Network
  // CN & VN: China Highlights, wikiHow Vietnamese Last Names, Vinpearl
  // MM: Wikipedia Burmese Names, MomJunction Burmese Names
  // EN: EF English Names, BabyNames US Surnames
  const NATIONALITIES = deepFreeze({
    TH: {
      id: "TH",
      nameTh: "ไทย",
      nameEn: "Thai",
      flag: "🇹🇭",
      codeTh: "TH · ไทย",
      hometowns: ["นนทบุรี", "สมุทรปราการ", "ปทุมธานี", "ชลบุรี", "เชียงใหม่", "ขอนแก่น", "นครราชสีมา", "ระยอง"],
      educations: [
        "ปวส. เทคนิคอุตสาหกรรมและอิเล็กทรอนิกส์",
        "ปริญญาตรี วิศวกรรมอุตสาหการและอิเล็กทรอนิกส์",
        "ปริญญาตรี บริหารธุรกิจและการจัดการซัพพลายเชน",
        "ปวส. ช่างกลโรงงานและควบคุมคุณภาพ"
      ],
      roleWeight: { sales: 0.72, admin: 0.78, engineer: 0.52, assembler: 0.58, inspector: 0.62, logistics: 0.64, coordinator: 0.72 }
    },
    JP: {
      id: "JP",
      nameTh: "ญี่ปุ่น",
      nameEn: "Japanese",
      flag: "🇯🇵",
      codeTh: "JP · ญี่ปุ่น",
      hometowns: ["โอซาก้า", "นาโกย่า", "โยโกฮาม่า", "ฟุกุโอกะ", "เกียวโต"],
      educations: [
        "สถาบันเทคโนโลยีแห่งโตเกียว (Monozukuri & QC)",
        "ปริญญาตรี วิศวกรรมไมโครอิเล็กทรอนิกส์ (Osaka)",
        "ผู้เชี่ยวชาญมาตรฐาน Kaizen & IPC-A-610"
      ],
      roleWeight: { sales: 0.05, admin: 0.04, engineer: 0.18, assembler: 0.04, inspector: 0.14, logistics: 0.03, coordinator: 0.08 }
    },
    CN: {
      id: "CN",
      nameTh: "จีน",
      nameEn: "Chinese",
      flag: "🇨🇳",
      codeTh: "CN · จีน",
      hometowns: ["เซินเจิ้น", "ซูโจว", "กวางโจว", "เซี่ยงไฮ้", "ตงกวน"],
      educations: [
        "วิศวกรรมฮาร์ดแวร์และซัพพลายเชน PCB (Shenzhen)",
        "ปริญญาตรี วิศวกรรมระบบอัตโนมัติและสมองกลฝังตัว",
        "การจัดการโลจิสติกส์และจัดซื้อชิ้นส่วนอิเล็กทรอนิกส์"
      ],
      roleWeight: { sales: 0.08, admin: 0.06, engineer: 0.14, assembler: 0.08, inspector: 0.08, logistics: 0.08, coordinator: 0.08 }
    },
    VN: {
      id: "VN",
      nameTh: "เวียดนาม",
      nameEn: "Vietnamese",
      flag: "🇻🇳",
      codeTh: "VN · เวียดนาม",
      hometowns: ["บั๊กนิญ", "ไฮฟอง", "ดานัง", "โฮจิมินห์", "ฮานอย"],
      educations: [
        "เทคนิคการประกอบ SMT และแผงวงจรความแม่นยำสูง (Bac Ninh)",
        "ปริญญาตรี วิศวกรรมไฟฟ้าและตรวจสอบคุณภาพ",
        "ประกาศนียบัตรวิชาชีพชั้นสูง ช่างอิเล็กทรอนิกส์อุตสาหกรรม"
      ],
      roleWeight: { sales: 0.04, admin: 0.04, engineer: 0.08, assembler: 0.14, inspector: 0.1, logistics: 0.1, coordinator: 0.04 }
    },
    MM: {
      id: "MM",
      nameTh: "เมียนมา",
      nameEn: "Myanmar",
      flag: "🇲🇲",
      codeTh: "MM · เมียนมา",
      hometowns: ["ย่างกุ้ง", "มัณฑะเลย์", "พะโค", "เมาะลำเลิง"],
      educations: [
        "ใบรับรองช่างประกอบชิ้นส่วนอิเล็กทรอนิกส์และคลังสินค้า",
        "เทคนิคการบัดกรีละเอียดและการแพ็กกิ้งมาตรฐานส่งออก",
        "วิชาชีพช่างเทคนิคสายการผลิตและตรวจสอบเบื้องต้น"
      ],
      roleWeight: { sales: 0.02, admin: 0.02, engineer: 0.02, assembler: 0.14, inspector: 0.04, logistics: 0.13, coordinator: 0.03 }
    },
    EN: {
      id: "EN",
      nameTh: "สากล (ตะวันตก)",
      nameEn: "International",
      flag: "🇬🇧",
      codeTh: "EN · สากล",
      hometowns: ["ลอนดอน", "ซานโฮเซ", "ซิดนีย์", "แมนเชสเตอร์", "มิวนิก"],
      educations: [
        "B.Eng. Embedded Systems & Industrial IoT",
        "B.Sc. Global Supply Chain & B2B Key Account Management",
        "M.Eng. Reliability Engineering & Six Sigma"
      ],
      roleWeight: { sales: 0.09, admin: 0.06, engineer: 0.06, assembler: 0.02, inspector: 0.02, logistics: 0.02, coordinator: 0.05 }
    }
  });

  const NAME_POOLS = deepFreeze({
    TH: {
      maleFirst: [
        "ธนกฤต", "กิตติพงศ์", "ณัฐวุฒิ", "ศุภชัย", "ภูริพัฒน์", "ชยุต",
        "ภาคิน", "วรเมธ", "ธีรภัทร", "ปิยะพงษ์", "จิรายุ", "กัมปนาท",
        "อัครเดช", "พีรวิชญ์", "นรภัทร", "ศรัณย์", "พงศกร", "อนุชา"
      ],
      femaleFirst: [
        "กมลชนก", "พิมพ์ชนก", "ณัฐธิดา", "ศิริพร", "ชลธิชา", "กัญญาณัฐ",
        "ภัทรวดี", "วรัญญา", "อารยา", "สุภัสสรา", "นันท์นภัส", "ปภาวรินท์",
        "พิชญาภา", "รุ่งทิวา", "ธัญชนก", "อัญชลี", "ลลิตา", "มนัสนันท์"
      ],
      surnames: [
        "วงศ์สุวรรณ", "เจริญสุข", "ศรีสวัสดิ์", "เกียรติไพศาล", "รัตนโชติ",
        "พงษ์พานิช", "อัครเดชา", "วัฒนากุล", "โชติบริบูรณ์", "ตั้งเจริญ",
        "พิทักษ์สิน", "ธนากิจ", "ศิริวงศ์", "เลิศวิไล", "กิจเจริญ",
        "บุญญะริทธิ์", "สมบูรณ์ผล", "สุวรรณภูมิ", "จรัสแสง", "นิคมรัตน์"
      ],
      nicknamesMale: ["ภัทร", "ต้น", "กานต์", "ธีร์", "ภูมิ", "นนท์", "เจ", "อาร์ต", "แบงค์", "ก้อง", "เอิร์ธ", "ท็อป", "บอส", "พีท"],
      nicknamesFemale: ["มิน", "น้ำ", "อิง", "ป่าน", "แพร", "ฟ้า", "เมย์", "โบว์", "พลอย", "มายด์", "เนย", "พิม", "เฟิร์น", "จูน"]
    },
    JP: {
      maleFirst: ["ฮารุโตะ (Haruto)", "เร็น (Ren)", "ทาคุมิ (Takumi)", "เคนจิ (Kenji)", "โซตะ (Sota)", "ไดกิ (Daiki)", "ยูโตะ (Yuto)", "นาโอกิ (Naoki)"],
      femaleFirst: ["ฮิมาริ (Himari)", "อาโออิ (Aoi)", "ยุย (Yui)", "ซากุระ (Sakura)", "มิโอะ (Mio)", "ริน (Rin)", "อายากะ (Ayaka)", "นานามิ (Nanami)"],
      surnames: ["ซาโต้ (Sato)", "ซูซูกิ (Suzuki)", "ทาคาฮาชิ (Takahashi)", "ทานากะ (Tanaka)", "วาตานาเบะ (Watanabe)", "อิโต้ (Ito)", "ยามามาโตะ (Yamamoto)", "โคบายาชิ (Kobayashi)"],
      nicknamesMale: ["เคน", "ทาคุ", "เร็น", "ฮารุ", "โซตะ", "ได"],
      nicknamesFemale: ["อาโออิ", "ยุย", "มิโอะ", "ริน", "ซากุระ", "นานะ"]
    },
    CN: {
      maleFirst: ["เหว่ย (Wei)", "ฮ่าวหราน (Haoran)", "จื้อหาว (Zihao)", "หมิงเจ๋อ (Mingze)", "เจี้ยนหัว (Jianhua)", "จวิ้นเจี๋ย (Junjie)", "อี้เฉิน (Yichen)", "ข่าย (Kai)"],
      femaleFirst: ["จื่อหาน (Zihan)", "อี้หนัว (Yinuo)", "ซินอี้ (Xinyi)", "เหม่ยหลิง (Meiling)", "เสี่ยวเหวิน (Xiaowen)", "เจียอี้ (Jiayi)", "หยูถง (Yutong)", "หลิน (Lin)"],
      surnames: ["หวัง (Wang)", "หลี่ (Li)", "จาง (Zhang)", "หลิว (Liu)", "เฉิน (Chen)", "หยาง (Yang)", "หวง (Huang)", "จ้าว (Zhao)"],
      nicknamesMale: ["เหว่ย", "ฮ่าว", "หมิง", "เจี้ยน", "ข่าย"],
      nicknamesFemale: ["หลิน", "เหม่ย", "ซิน", "เหวิน", "เจีย"]
    },
    VN: {
      maleFirst: ["มินห์ กวาน (Minh Quan)", "ฮว่าง นาม (Hoang Nam)", "ดึ๊ก อันห์ (Duc Anh)", "แทงห์ ตุง (Thanh Tung)", "กวาง ฮุย (Quang Huy)", "บ๋าว ลอง (Bao Long)"],
      femaleFirst: ["ถวิ ลินห์ (Thuy Linh)", "บิช หง็อก (Bich Ngoc)", "ไม อันห์ (Mai Anh)", "แทงห์ ห่า (Thanh Ha)", "ฟือง เถ่า (Phuong Thao)", "ลาน อันห์ (Lan Anh)"],
      surnames: ["เหงียน (Nguyen)", "เจิ่น (Tran)", "เล (Le)", "ฝ่าม (Pham)", "ฮหว่าง (Hoang)", "หวู (Vu)", "ดัง (Dang)", "บุ่ย (Bui)"],
      nicknamesMale: ["กวาน", "นาม", "ฮุย", "ตุง", "ลอง"],
      nicknamesFemale: ["ลินห์", "หง็อก", "ไม", "ห่า", "เถ่า"]
    },
    MM: {
      maleFirst: ["อ่อง จอ (Aung Kyaw)", "มิน ตัน (Min Thant)", "หม่อง ซอ (Maung Zaw)", "โก โก (Ko Ko)", "เท็ต แนง (Htet Naing)", "ซอ ลวิน (Zaw Lwin)"],
      femaleFirst: ["เม ตะซิน (May Thazin)", "ขิ่น ซู (Khin Su)", "เอ มิ (Aye Mi)", "นันท์ ซานดาร์ (Nand Sandar)", "ซู มยัต (Su Myat)", "พยู ซิน (Phyu Sin)"],
      surnames: ["สายช่างย่างกุ้ง", "สายเทคนิคมัณฑะเลย์", "สายงานพะโค", "สายอิเล็กทรอนิกส์เมียนมา"],
      nicknamesMale: ["อ่อง", "หม่อง", "ซอ", "เท็ต", "โก"],
      nicknamesFemale: ["เม", "ขิ่น", "เอ", "ซู", "พยู"]
    },
    EN: {
      maleFirst: ["อเล็กซานเดอร์ (Alexander)", "เจมส์ (James)", "โอลิเวอร์ (Oliver)", "ลูคัส (Lucas)", "แดเนียล (Daniel)", "มาร์คัส (Marcus)"],
      femaleFirst: ["ชาร์ล็อตต์ (Charlotte)", "เอมิลี่ (Emily)", "โซเฟีย (Sophia)", "คลาร่า (Clara)", "เอเลน่า (Elena)", "ฮันนาห์ (Hannah)"],
      surnames: ["สมิธ (Smith)", "จอห์นสัน (Johnson)", "มิลเลอร์ (Miller)", "แอนเดอร์สัน (Anderson)", "เทย์เลอร์ (Taylor)", "คลาร์ก (Clark)"],
      nicknamesMale: ["อเล็กซ์", "เจมส์", "ลุค", "แดน", "มาร์ค"],
      nicknamesFemale: ["เอมี่", "โซฟี", "คลาร่า", "เอเลน", "ฮันนาห์"]
    }
  });

  const STARTER_IDENTITIES = deepFreeze({
    "employee-1": { nationality: "TH", gender: "F", age: 27, firstName: "มินตรา", lastName: "วงศ์สุวรรณ", educationTh: "ปริญญาตรี บริหารธุรกิจและการตลาดอุตสาหกรรม (ม.เกษตรฯ)", hometownTh: "นนทบุรี" },
    "employee-2": { nationality: "TH", gender: "M", age: 29, firstName: "ภัทรพล", lastName: "เจริญสุข", educationTh: "ปริญญาตรี การจัดการซัพพลายเชนและบัญชีต้นทุน", hometownTh: "สมุทรปราการ" },
    "employee-3": { nationality: "JP", gender: "F", age: 31, firstName: "นานามิ (Nanami)", lastName: "ทาคาฮาชิ (Takahashi)", educationTh: "วิศวกรรมไมโครอิเล็กทรอนิกส์ (Osaka Institute of Tech)", hometownTh: "โอซาก้า" },
    "employee-4": { nationality: "TH", gender: "M", age: 24, firstName: "ต้นกล้า", lastName: "ศรีสวัสดิ์", educationTh: "ปวส. เทคนิคอิเล็กทรอนิกส์และบัดกรีละเอียด", hometownTh: "ชลบุรี" },
    "employee-5": { nationality: "VN", gender: "F", age: 23, firstName: "ถวิ ลินห์ (Thuy Linh)", lastName: "เหงียน (Nguyen)", educationTh: "เทคนิคการประกอบ SMT และแผงวงจรความแม่นยำสูง (Bac Ninh)", hometownTh: "บั๊กนิญ" },
    "employee-6": { nationality: "TH", gender: "M", age: 30, firstName: "กานต์ชนก", lastName: "เกียรติไพศาล", educationTh: "ปริญญาตรี วิศวกรรมควบคุมคุณภาพ มาตรฐาน IPC-A-610", hometownTh: "ปทุมธานี" },
    "employee-7": { nationality: "MM", gender: "F", age: 25, firstName: "เม ตะซิน (May Thazin)", lastName: "สายเทคนิคย่างกุ้ง", educationTh: "วิชาชีพการจัดการคลังสินค้าและแพ็กกิ้งส่งออก", hometownTh: "ย่างกุ้ง" },
    "employee-8": { nationality: "CN", gender: "M", age: 34, firstName: "จื้อหาว (Zihao)", lastName: "เฉิน (Chen)", educationTh: "บริหารอุตสาหกรรมและวางแผนการผลิต (Shenzhen Tech)", hometownTh: "เซินเจิ้น" }
  });

  const CAREER_LADDERS = deepFreeze({
    sales: [
      { level: 1, titleTh: "เจ้าหน้าที่ฝ่ายขาย (Jr. Sales)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "ฝ่ายขายอาวุโส (Sr. Sales Executive)", badge: "Lv.2", minTasks: 2, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.12 },
      { level: 3, titleTh: "ผู้จัดการฝ่ายขาย (Sales Manager)", badge: "Lv.3", minTasks: 6, minSkill: 56, minTenureDays: 5, wageBonus: 7500, mentorPower: 0.24 },
      { level: 4, titleTh: "ผู้อำนวยการฝ่ายพาณิชย์ (Commercial Director)", badge: "Lv.4", minTasks: 12, minSkill: 65, minTenureDays: 10, wageBonus: 14000, mentorPower: 0.36 }
    ],
    admin: [
      { level: 1, titleTh: "เจ้าหน้าที่ธุรการและจัดซื้อ (Jr. Admin)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "นักจัดซื้อและบัญชีอาวุโส (Sr. Procurement)", badge: "Lv.2", minTasks: 2, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.12 },
      { level: 3, titleTh: "ผู้จัดการซัพพลายเชนและบัญชี (Supply Chain Mgr)", badge: "Lv.3", minTasks: 6, minSkill: 56, minTenureDays: 5, wageBonus: 7000, mentorPower: 0.24 },
      { level: 4, titleTh: "ผู้อำนวยการฝ่ายการเงินและธุรการ (VP Finance & Admin)", badge: "Lv.4", minTasks: 12, minSkill: 65, minTenureDays: 10, wageBonus: 13000, mentorPower: 0.36 }
    ],
    engineer: [
      { level: 1, titleTh: "วิศวกรวิจัยและพัฒนา (R&D Engineer)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0.05 },
      { level: 2, titleTh: "วิศวกรอาวุโส (Sr. Hardware Engineer)", badge: "Lv.2", minTasks: 2, minSkill: 50, minTenureDays: 2, wageBonus: 4500, mentorPower: 0.16 },
      { level: 3, titleTh: "หัวหน้าวิศวกรระบบ (Principal Engineer)", badge: "Lv.3", minTasks: 6, minSkill: 58, minTenureDays: 5, wageBonus: 9500, mentorPower: 0.28 },
      { level: 4, titleTh: "ผู้อำนวยการฝ่ายเทคโนโลยี (Chief Technology Officer)", badge: "Lv.4", minTasks: 12, minSkill: 66, minTenureDays: 10, wageBonus: 16000, mentorPower: 0.4 }
    ],
    assembler: [
      { level: 1, titleTh: "ช่างเทคนิคสายประกอบ (Line Technician)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "ช่างเทคนิคฝีมือดี (Skilled SMT Tech)", badge: "Lv.2", minTasks: 3, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.14 },
      { level: 3, titleTh: "หัวหน้ากะสายการผลิต (Line Foreman)", badge: "Lv.3", minTasks: 8, minSkill: 56, minTenureDays: 5, wageBonus: 7500, mentorPower: 0.26 },
      { level: 4, titleTh: "ปรมาจารย์ช่างอุตสาหกรรม (Master Craftsman)", badge: "Lv.4", minTasks: 15, minSkill: 64, minTenureDays: 10, wageBonus: 13500, mentorPower: 0.38 }
    ],
    inspector: [
      { level: 1, titleTh: "เจ้าหน้าที่ตรวจสอบคุณภาพ (QC Inspector)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "ผู้ตรวจสอบคุณภาพอาวุโส (Sr. QA Auditor)", badge: "Lv.2", minTasks: 3, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.14 },
      { level: 3, titleTh: "หัวหน้าควบคุมมาตรฐาน (QA Supervisor)", badge: "Lv.3", minTasks: 8, minSkill: 56, minTenureDays: 5, wageBonus: 7500, mentorPower: 0.26 },
      { level: 4, titleTh: "ผู้อำนวยการประกันคุณภาพ (Quality Assurance Director)", badge: "Lv.4", minTasks: 15, minSkill: 64, minTenureDays: 10, wageBonus: 13500, mentorPower: 0.38 }
    ],
    logistics: [
      { level: 1, titleTh: "เจ้าหน้าที่คลังและจัดส่ง (Logistics Staff)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "หัวหน้าคลังพัสดุอาวุโส (Sr. Logistics Specialist)", badge: "Lv.2", minTasks: 3, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.12 },
      { level: 3, titleTh: "ผู้จัดการคลังสินค้าและจัดส่ง (Logistics Manager)", badge: "Lv.3", minTasks: 7, minSkill: 56, minTenureDays: 5, wageBonus: 7000, mentorPower: 0.24 },
      { level: 4, titleTh: "ผู้อำนวยการศูนย์กระจายสินค้า (Distribution Director)", badge: "Lv.4", minTasks: 14, minSkill: 64, minTenureDays: 10, wageBonus: 13000, mentorPower: 0.35 }
    ],
    coordinator: [
      { level: 1, titleTh: "ผู้ประสานงานบริหาร (Operations Coordinator)", badge: "Lv.1", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0.08 },
      { level: 2, titleTh: "ผู้จัดการฝ่ายปฏิบัติการ (Operations Manager)", badge: "Lv.2", minTasks: 2, minSkill: 50, minTenureDays: 2, wageBonus: 4500, mentorPower: 0.18 },
      { level: 3, titleTh: "ผู้อำนวยการสายปฏิบัติการ (VP of Operations)", badge: "Lv.3", minTasks: 6, minSkill: 58, minTenureDays: 5, wageBonus: 9500, mentorPower: 0.3 },
      { level: 4, titleTh: "ประธานเจ้าหน้าที่ฝ่ายปฏิบัติการ (Chief Executive / COO)", badge: "Lv.4", minTasks: 12, minSkill: 66, minTenureDays: 10, wageBonus: 16000, mentorPower: 0.42 }
    ]
  });

  const MOTIVE_FACTOR_LABELS = deepFreeze({
    effort: "ความทุ่มเทและแรงกายที่ใช้",
    delay: "ความเร่งด่วนของงานที่ค้าง",
    skillFit: "ความถนัดตรงสายงาน",
    change: "ความท้าทายและการปรับเปลี่ยน",
    risk: "การบริหารความเสี่ยง",
    hunger: "การเติมพลังด้วยมื้ออาหาร",
    social: "การพูดคุยและเชื่อมสัมพันธ์กับทีม",
    voice: "การสะท้อนปัญหาและออกความเห็น",
    craft: "ความประณีตและการสร้างผลงานด้วยฝีมือ",
    duty: "ความรับผิดชอบต่อหน้าที่และออเดอร์",
    routine: "ความคุ้นเคยและระเบียบแบบแผน",
    help: "การช่วยเหลือเกื้อกูลเพื่อนร่วมทีม",
    novelty: "การคิดค้นและเรียนรู้สิ่งใหม่",
    energy: "การฟื้นฟูพลังงานร่างกาย",
    stress: "การผ่อนคลายความเครียดสะสม",
    health: "การดูแลสุขภาพร่างกาย",
    burnout: "การป้องกันภาวะหมดไฟ",
    focus: "สมาธิและความต่อเนื่องในการทำงาน",
    mood: "อารมณ์และขวัญกำลังใจ",
    achievement: "คุณค่าความสำเร็จในงาน",
    security: "คุณค่าความมั่นคงปลอดภัย",
    income: "คุณค่ารายได้และผลตอบแทน",
    autonomy: "คุณค่าความเป็นอิสระในการทำงาน",
    fairness: "คุณค่าความเป็นธรรมในองค์กร",
    belonging: "คุณค่าการเป็นส่วนหนึ่งของทีม",
    learning: "คุณค่าการเรียนรู้และพัฒนาตน",
    meaning: "คุณค่าความหมายของงานที่ทำ",
    workLifeBalance: "คุณค่าสมดุลชีวิตและการพักผ่อน",
    recognition: "คุณค่าการได้รับการยอมรับและเกียรติภูมิ",
    family: "คุณค่าการดูแลครอบครัว",
    comfort: "คุณค่าคุณภาพชีวิตและความเป็นอยู่",
    humility: "ความถ่อมตน",
    optimism: "การมองโลกในแง่บวก",
    care: "ความเอื้ออาทรต่อผู้อื่น",
    stewardship: "ความรับผิดชอบต่อส่วนรวม",
    influence: "การมีบทบาทกำหนดทิศทาง",
    tradition: "การเคารพธรรมเนียมปฏิบัติ",
    variety: "ความหลากหลายของประสบการณ์",
    craftsmanship: "คุณค่าของฝีมือและความประณีต",
    sociability: "นิสัยชอบเข้าสังคม",
    conscientiousness: "นิสัยรับผิดชอบและมีวินัย",
    agreeableness: "นิสัยให้ความร่วมมือ",
    openness: "นิสัยเปิดรับสิ่งใหม่",
    riskTaking: "นิสัยกล้าตัดสินใจเสี่ยง",
    stressReactivity: "ความไวต่อความกดดัน",
    assertiveness: "ความกล้าแสดงออก",
    patience: "ความอดทนและใจเย็น",
    integrity: "ความซื่อสัตย์สุจริต",
    adaptability: "ความยืดหยุ่นในการปรับตัว",
    ambition: "แรงผลักดันและความทะเยอทะยาน",
    prudence: "ความรอบคอบก่อนลงมือ"
  });

  function hashStr(str) {
    let h = 2166136261 >>> 0;
    const s = String(str || "");
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function pickDet(arr, seedStr) {
    if (!arr || !arr.length) return "";
    return arr[hashStr(seedStr) % arr.length];
  }

  function getCareerStep(roleId, level) {
    const ladder = CAREER_LADDERS[roleId] || CAREER_LADDERS.assembler;
    const lv = Math.max(1, Math.min(ladder.length, Number(level) || 1));
    return ladder[lv - 1] || ladder[0];
  }

  function getNextCareerStep(roleId, level) {
    const ladder = CAREER_LADDERS[roleId] || CAREER_LADDERS.assembler;
    const lv = Math.max(1, Number(level) || 1);
    return lv < ladder.length ? ladder[lv] : null;
  }

  function createIdentity(seed, personId, baseName, roleId = "assembler") {
    const pid = String(personId || "employee-1");
    const preset = STARTER_IDENTITIES[pid];
    if (preset) {
      const nat = NATIONALITIES[preset.nationality] || NATIONALITIES.TH;
      const genderSymbol = preset.gender === "F" ? "♀" : "♂";
      const genderTh = preset.gender === "F" ? "หญิง" : "ชาย";
      const nickname = baseName || pid;
      const fullName = `${preset.firstName} ${preset.lastName}`;
      return {
        nationality: nat.id,
        nationalityTh: nat.nameTh,
        flag: nat.flag,
        codeTh: nat.codeTh,
        gender: preset.gender,
        genderTh,
        genderSymbol,
        age: preset.age,
        firstName: preset.firstName,
        lastName: preset.lastName,
        nickname,
        fullName,
        displayName: `${fullName} (${nickname})`,
        educationTh: preset.educationTh,
        hometownTh: preset.hometownTh
      };
    }

    const key = `${seed}:${pid}:${roleId}`;
    const h1 = hashStr(key + ":nat");
    const natOrder = ["TH", "JP", "CN", "VN", "MM", "EN"];
    let acc = 0;
    const roll = (h1 % 1000) / 1000;
    let chosenNatId = "TH";
    for (const nid of natOrder) {
      const w = (NATIONALITIES[nid].roleWeight && NATIONALITIES[nid].roleWeight[roleId]) || 0.05;
      acc += w;
      if (roll <= acc) {
        chosenNatId = nid;
        break;
      }
    }
    const nat = NATIONALITIES[chosenNatId] || NATIONALITIES.TH;
    const pool = NAME_POOLS[chosenNatId] || NAME_POOLS.TH;
    const gender = hashStr(key + ":gender") % 2 === 0 ? "M" : "F";
    const genderTh = gender === "F" ? "หญิง" : "ชาย";
    const genderSymbol = gender === "F" ? "♀" : "♂";
    const baseAgeMin = roleId === "engineer" || roleId === "coordinator" ? 25 : 21;
    const age = baseAgeMin + (hashStr(key + ":age") % 19);
    const firstName = pickDet(gender === "F" ? pool.femaleFirst : pool.maleFirst, key + ":first");
    const lastName = pickDet(pool.surnames, key + ":last");
    const nickname = baseName || pickDet(gender === "F" ? pool.nicknamesFemale : pool.nicknamesMale, key + ":nick");
    const fullName = `${firstName} ${lastName}`;
    return {
      nationality: nat.id,
      nationalityTh: nat.nameTh,
      flag: nat.flag,
      codeTh: nat.codeTh,
      gender,
      genderTh,
      genderSymbol,
      age,
      firstName,
      lastName,
      nickname,
      fullName,
      displayName: `${fullName} (${nickname})`,
      educationTh: pickDet(nat.educations, key + ":edu"),
      hometownTh: pickDet(nat.hometowns, key + ":home")
    };
  }

  function translateMotiveFactor(factor, extraLabels = {}) {
    const raw = String(factor || "").trim();
    if (!raw) return "ความเหมาะสมตามสถานการณ์";
    if (MOTIVE_FACTOR_LABELS[raw]) return MOTIVE_FACTOR_LABELS[raw];
    if (extraLabels && extraLabels[raw]) return extraLabels[raw];

    const parts = raw.split(":");
    const prefix = parts.length > 1 ? parts[0] : "";
    const key = parts.length > 1 ? parts.slice(1).join(":") : raw;

    if (MOTIVE_FACTOR_LABELS[key]) return MOTIVE_FACTOR_LABELS[key];
    if (extraLabels && extraLabels[key]) {
      return prefix === "value" ? `คุณค่า${extraLabels[key]}` : extraLabels[key];
    }
    return "ดุลยพินิจตามความเหมาะสมของงาน";
  }

  const INDUSTRY_SKILL_TEMPLATES = deepFreeze({
    software: {
      id: "software",
      nameTh: "วิศวกรรมซอฟต์แวร์และระบบ",
      aptitudes: {
        analytical: 0.45,
        memory: 0.2,
        learningSpeed: 0.2,
        precision: 0.15,
      },
    },
    construction: {
      id: "construction",
      nameTh: "งานก่อสร้างและโครงสร้าง",
      aptitudes: {
        strength: 0.35,
        stamina: 0.3,
        spatial: 0.2,
        dexterity: 0.15,
      },
    },
    architecture: {
      id: "architecture",
      nameTh: "สถาปัตยกรรมและผังโครงสร้าง",
      aptitudes: {
        spatial: 0.4,
        creativity: 0.3,
        analytical: 0.2,
        precision: 0.1,
      },
    },
    driving: {
      id: "driving",
      nameTh: "การขับขี่และควบคุมยานพาหนะ",
      aptitudes: {
        spatial: 0.35,
        composure: 0.25,
        sensory: 0.2,
        dexterity: 0.2,
      },
    },
    design: {
      id: "design",
      nameTh: "การออกแบบและสุนทรียศาสตร์",
      aptitudes: {
        creativity: 0.45,
        sensory: 0.3,
        spatial: 0.15,
        emotionalInsight: 0.1,
      },
    },
    customerCare: {
      id: "customerCare",
      nameTh: "บริการและดูแลลูกค้า",
      aptitudes: {
        emotionalInsight: 0.4,
        communication: 0.35,
        composure: 0.25,
      },
    },
    aerospaceEngineering: {
      id: "aerospaceEngineering",
      nameTh: "วิศวกรรมอวกาศ",
      aptitudes: {
        analytical: 0.25,
        numerical: 0.2,
        spatial: 0.2,
        problemSensitivity: 0.15,
        precision: 0.2,
      },
    },
    missionControl: {
      id: "missionControl",
      nameTh: "ควบคุมภารกิจและระบบวิกฤต",
      aptitudes: {
        attention: 0.25,
        uncertaintyReasoning: 0.25,
        composure: 0.2,
        communication: 0.15,
        problemSensitivity: 0.15,
      },
    },
    automotiveEngineering: {
      id: "automotiveEngineering",
      nameTh: "ออกแบบระบบยานยนต์",
      aptitudes: {
        analytical: 0.3,
        spatial: 0.25,
        numerical: 0.2,
        creativity: 0.15,
        precision: 0.1,
      },
    },
    vehicleMaintenance: {
      id: "vehicleMaintenance",
      nameTh: "วิเคราะห์และซ่อมยานยนต์",
      aptitudes: {
        problemSensitivity: 0.25,
        dexterity: 0.25,
        hearing: 0.15,
        visualAcuity: 0.15,
        analytical: 0.2,
      },
    },
    financialAnalysis: {
      id: "financialAnalysis",
      nameTh: "วิเคราะห์การเงินและการลงทุน",
      aptitudes: {
        numerical: 0.35,
        uncertaintyReasoning: 0.3,
        analytical: 0.2,
        verbal: 0.15,
      },
    },
    riskManagement: {
      id: "riskManagement",
      nameTh: "บริหารความเสี่ยง",
      aptitudes: {
        uncertaintyReasoning: 0.35,
        problemSensitivity: 0.25,
        numerical: 0.2,
        composure: 0.2,
      },
    },
    animalHusbandry: {
      id: "animalHusbandry",
      nameTh: "ดูแลและสังเกตพฤติกรรมสัตว์",
      aptitudes: {
        attention: 0.2,
        emotionalInsight: 0.2,
        problemSensitivity: 0.2,
        dexterity: 0.15,
        sensory: 0.15,
        stamina: 0.1,
      },
    },
    veterinaryCare: {
      id: "veterinaryCare",
      nameTh: "ความรู้และหัตถการสัตวแพทย์",
      aptitudes: {
        analytical: 0.2,
        memory: 0.2,
        dexterity: 0.2,
        precision: 0.2,
        problemSensitivity: 0.2,
      },
    },
    foodPreparation: {
      id: "foodPreparation",
      nameTh: "ประกอบอาหารและควบคุมรสชาติ",
      aptitudes: {
        tasteSmell: 0.25,
        dexterity: 0.2,
        organization: 0.15,
        creativity: 0.15,
        colorDiscrimination: 0.1,
        coordination: 0.15,
      },
    },
    foodSafety: {
      id: "foodSafety",
      nameTh: "สุขอนามัยและความปลอดภัยอาหาร",
      aptitudes: {
        problemSensitivity: 0.25,
        precision: 0.25,
        attention: 0.2,
        memory: 0.15,
        sensory: 0.15,
      },
    },
    structuralEngineering: {
      id: "structuralEngineering",
      nameTh: "วิศวกรรมโครงสร้าง",
      aptitudes: {
        numerical: 0.25,
        spatial: 0.25,
        analytical: 0.3,
        problemSensitivity: 0.2,
      },
    },
    heavyEquipment: {
      id: "heavyEquipment",
      nameTh: "ควบคุมเครื่องจักรหนัก",
      aptitudes: {
        controlPrecision: 0.3,
        reactionSpeed: 0.2,
        spatial: 0.2,
        coordination: 0.15,
        attention: 0.15,
      },
    },
    fieldConstruction: {
      id: "fieldConstruction",
      nameTh: "งานก่อสร้างภาคสนาม",
      aptitudes: {
        strength: 0.2,
        stamina: 0.2,
        balance: 0.2,
        flexibility: 0.15,
        coordination: 0.15,
        spatial: 0.1,
      },
    },
    medicine: {
      id: "medicine",
      nameTh: "ความรู้และดูแลสุขภาพ",
      aptitudes: {
        analytical: 0.25,
        memory: 0.25,
        problemSensitivity: 0.2,
        emotionalInsight: 0.15,
        precision: 0.15,
      },
    },
    law: {
      id: "law",
      nameTh: "กฎหมายและการให้เหตุผล",
      aptitudes: {
        verbal: 0.35,
        analytical: 0.25,
        memory: 0.2,
        communication: 0.2,
      },
    },
    education: {
      id: "education",
      nameTh: "การสอนและอธิบาย",
      aptitudes: {
        verbal: 0.2,
        communication: 0.25,
        emotionalInsight: 0.25,
        speechClarity: 0.15,
        organization: 0.15,
      },
    },
    agriculture: {
      id: "agriculture",
      nameTh: "เพาะปลูกและดูแลระบบเกษตร",
      aptitudes: {
        problemSensitivity: 0.2,
        organization: 0.2,
        sensory: 0.2,
        stamina: 0.2,
        analytical: 0.2,
      },
    },
    creativeProduction: {
      id: "creativeProduction",
      nameTh: "ผลิตสื่อและศิลปะ",
      aptitudes: {
        creativity: 0.3,
        colorDiscrimination: 0.2,
        hearing: 0.15,
        communication: 0.2,
        sensory: 0.15,
      },
    },
    logisticsPlanning: {
      id: "logisticsPlanning",
      nameTh: "วางแผนโลจิสติกส์",
      aptitudes: {
        organization: 0.3,
        numerical: 0.2,
        spatial: 0.2,
        attention: 0.15,
        perceptualSpeed: 0.15,
      },
    },
    energyOperations: {
      id: "energyOperations",
      nameTh: "ปฏิบัติการพลังงานและระบบสาธารณูปโภค",
      aptitudes: {
        attention: 0.25,
        controlPrecision: 0.2,
        problemSensitivity: 0.2,
        composure: 0.2,
        reactionSpeed: 0.15,
      },
    },
  });
  const defaults = {
    version: "1.1.0",
    skills: {
      sales: {
        id: "sales",
        nameTh: "การขายและเจรจา",
        aptitudes: {
          communication: 0.55,
          emotionalInsight: 0.25,
          organization: 0.1,
          composure: 0.1,
        },
      },
      admin: {
        id: "admin",
        nameTh: "บัญชีและธุรการ",
        aptitudes: { organization: 0.5, precision: 0.3, memory: 0.2 },
      },
      engineering: {
        id: "engineering",
        nameTh: "วิศวกรรมและวิจัย",
        aptitudes: {
          analytical: 0.4,
          creativity: 0.3,
          learningSpeed: 0.2,
          spatial: 0.1,
        },
      },
      assembly: {
        id: "assembly",
        nameTh: "ประกอบชิ้นงาน",
        aptitudes: {
          dexterity: 0.45,
          precision: 0.25,
          stamina: 0.2,
          spatial: 0.1,
        },
      },
      quality: {
        id: "quality",
        nameTh: "ตรวจคุณภาพ",
        aptitudes: { precision: 0.5, analytical: 0.3, sensory: 0.2 },
      },
      logistics: {
        id: "logistics",
        nameTh: "คลังสินค้าและจัดส่ง",
        aptitudes: {
          organization: 0.45,
          stamina: 0.25,
          strength: 0.15,
          spatial: 0.15,
        },
      },
      leadership: {
        id: "leadership",
        nameTh: "ประสานงานและช่วยทีม",
        aptitudes: {
          communication: 0.35,
          emotionalInsight: 0.35,
          organization: 0.15,
          composure: 0.15,
        },
      },
    },
    materials: {
      pcb: { id: "pcb", nameTh: "แผงวงจร", unitCost: 9000, leadMinutes: 1440 },
      casing: {
        id: "casing",
        nameTh: "ตัวถัง",
        unitCost: 5000,
        leadMinutes: 720,
      },
      driver: {
        id: "driver",
        nameTh: "ดอกลำโพง",
        unitCost: 6000,
        leadMinutes: 1440,
      },
      led: { id: "led", nameTh: "โมดูลแสง", unitCost: 7500, leadMinutes: 1440 },
      sensor: {
        id: "sensor",
        nameTh: "เซ็นเซอร์",
        unitCost: 6000,
        leadMinutes: 1440,
      },
    },
    products: {
      speaker: {
        id: "speaker",
        nameTh: "ลำโพงบลูทูธ",
        bom: { pcb: 1, casing: 1, driver: 1 },
        assemblyMinutes: 40,
        qaMinutes: 12,
        packingMinutes: 6,
        priceMin: 75000,
        priceMax: 90000,
        researchRequired: 0,
        visualKey: "product.speaker",
      },
      lamp: {
        id: "lamp",
        nameTh: "โคมไฟปรับแสง",
        bom: { pcb: 1, casing: 1, led: 2, sensor: 1 },
        assemblyMinutes: 55,
        qaMinutes: 15,
        packingMinutes: 8,
        priceMin: 120000,
        priceMax: 145000,
        researchRequired: 300,
        visualKey: "product.lamp",
      },
    },
    roles: {
      sales: { nameTh: "ฝ่ายขาย", skill: "sales" },
      admin: { nameTh: "ธุรการ", skill: "admin" },
      engineer: { nameTh: "วิศวกร", skill: "engineering" },
      assembler: { nameTh: "ช่างประกอบ", skill: "assembly" },
      inspector: { nameTh: "ตรวจคุณภาพ", skill: "quality" },
      logistics: { nameTh: "คลังและจัดส่ง", skill: "logistics" },
      coordinator: { nameTh: "ผู้บริหาร/CEO", skill: "leadership" },
    },
    taskKinds: {},
    starters: [
      { name: "มิน", role: "sales", dailyWage: 38000 },
      { name: "ภัทร", role: "admin", dailyWage: 35000 },
      { name: "น้ำ", role: "engineer", dailyWage: 42000 },
      { name: "ต้น", role: "assembler", dailyWage: 40000 },
      { name: "อิง", role: "assembler", dailyWage: 40000 },
      { name: "กานต์", role: "inspector", dailyWage: 36000 },
      { name: "ป่าน", role: "logistics", dailyWage: 36000 },
      { name: "ธีร์", role: "coordinator", dailyWage: 35000 },
    ],
    rules: {
      initialCash: 12000000,
      initialDebt: 6000000,
      rentDaily: 80000,
      interestDaily: 0.0002,
      minimumWage: 28000,
      creditLimit: 20000000,
      paydayInterval: 7,
      maxActiveOrders: 12,
      maxUnits: 160,
      scenarioDays: 90,
      winCash: 6000000,
      winReputation: 60,
      hireFee: 300000,
      maxPeople: 30,
    },
    initialStock: { pcb: 30, casing: 30, driver: 30, led: 0, sensor: 0 },
  };
  function registerSkill(c, spec) {
    if (!spec || !validId(spec.id) || c.skills[spec.id])
      throw new TypeError("invalid/duplicate skill id");
    H.createSkill(H.createProfile("validation", "person"), spec);
    if (typeof spec.nameTh !== "string" || !spec.nameTh)
      throw new TypeError("skill needs name");
    c.skills[spec.id] = clone(spec);
    return c;
  }
  function registerRole(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      c.roles[spec.id] ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !Object.hasOwn(c.skills, spec.skill)
    )
      throw new TypeError("invalid/duplicate role spec");
    c.roles[spec.id] = { nameTh: spec.nameTh, skill: spec.skill };
    return c;
  }
  function registerMaterial(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      c.materials[spec.id] ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !Number.isSafeInteger(spec.unitCost) ||
      spec.unitCost < 1 ||
      spec.unitCost > 1e12 ||
      !Number.isSafeInteger(spec.leadMinutes) ||
      spec.leadMinutes < 5 ||
      spec.leadMinutes > 525600
    )
      throw new TypeError("invalid/duplicate material spec");
    c.materials[spec.id] = clone(spec);
    if (!Object.hasOwn(c.initialStock, spec.id)) c.initialStock[spec.id] = 0;
    return c;
  }
  function registerProduct(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      c.products[spec.id] ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !spec.bom ||
      typeof spec.bom !== "object" ||
      !Object.keys(spec.bom).length ||
      Object.entries(spec.bom).some(
        ([m, n]) =>
          !Object.hasOwn(c.materials, m) ||
          !Number.isSafeInteger(n) ||
          n < 1 ||
          n > 10000,
      )
    )
      throw new TypeError("invalid/duplicate product spec");
    const next = {
      researchRequired: 0,
      visualKey: "product." + spec.id,
      ...clone(spec),
    };
    const copy = clone(c);
    copy.products[spec.id] = next;
    const errors = validateCatalog(copy);
    if (errors.length) throw new TypeError(errors.join("; "));
    c.products[spec.id] = next;
    return c;
  }
  const BUILTIN_TASK_KINDS = [
    "assembly",
    "rework",
    "qa",
    "packing",
    "shipping",
    "purchase",
    "invoice",
    "research",
    "sales",
  ];
  function validateTaskKind(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      BUILTIN_TASK_KINDS.includes(spec.id) ||
      ["constructor", "prototype"].includes(spec.id) ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !Object.hasOwn(c.skills, spec.skill) ||
      !validId(spec.stationKind) ||
      !Number.isSafeInteger(spec.requiredMinutes) ||
      spec.requiredMinutes < 5 ||
      spec.requiredMinutes > 1440
    )
      throw new TypeError("invalid task kind spec");
    for (const [key, max] of [
      ["researchPoints", 1e9],
      ["revenue", 1e12],
    ])
      if (
        spec[key] !== undefined &&
        (!Number.isSafeInteger(spec[key]) || spec[key] < 0 || spec[key] > max)
      )
        throw new TypeError("invalid task effect " + key);
    if (
      spec.reputationDelta !== undefined &&
      (typeof spec.reputationDelta !== "number" ||
        !Number.isFinite(spec.reputationDelta) ||
        Math.abs(spec.reputationDelta) > 10)
    )
      throw new TypeError("invalid reputation effect");
    if (
      spec.domain !== undefined &&
      !["balanced", "physical", "cognitive", "social"].includes(spec.domain)
    )
      throw new TypeError("invalid task domain");
    for (const [key, min, max] of [
      ["workload", 0.2, 2],
      ["hazard", 0, 1],
      ["complexity", 0, 1],
    ])
      if (
        spec[key] !== undefined &&
        (typeof spec[key] !== "number" ||
          !Number.isFinite(spec[key]) ||
          spec[key] < min ||
          spec[key] > max)
      )
        throw new TypeError("invalid task demand " + key);
    H.scoreOptions(H.createProfile("validate", "p"), H.STATE_DEFAULTS, [
      {
        id: spec.id,
        impacts: spec.impacts || { achievement: 0.5 },
        effort: 0.35,
      },
    ]);
  }
  function registerTaskKind(c, spec) {
    validateTaskKind(c, spec);
    if (c.taskKinds && c.taskKinds[spec.id])
      throw new TypeError("duplicate task kind");
    const next = {
      id: spec.id,
      nameTh: spec.nameTh,
      skill: spec.skill,
      stationKind: spec.stationKind,
      requiredMinutes: spec.requiredMinutes,
      domain: spec.domain || "balanced",
      workload: spec.workload === undefined ? 1 : spec.workload,
      hazard: spec.hazard || 0,
      complexity: spec.complexity || 0,
      impacts: clone(
        spec.impacts || { achievement: 0.5, learning: 0.4, duty: 0.4 },
      ),
      researchPoints: spec.researchPoints || 0,
      reputationDelta: spec.reputationDelta || 0,
      revenue: spec.revenue || 0,
    };
    if (!c.taskKinds) c.taskKinds = {};
    c.taskKinds[spec.id] = next;
    return c;
  }
  function validateCatalog(c) {
    const e = [];
    if (!c || typeof c !== "object") return ["catalog missing"];
    for (const k of [
      "skills",
      "materials",
      "products",
      "roles",
      "rules",
      "initialStock",
    ])
      if (!c[k] || typeof c[k] !== "object") e.push(k + " missing");
    if (e.length) return e;
    if (
      !Object.keys(c.skills).length ||
      !Object.keys(c.materials).length ||
      !Object.keys(c.products).length
    )
      e.push("empty catalog");
    for (const [id, s] of Object.entries(c.skills)) {
      try {
        if (
          !validId(id) ||
          ["constructor", "prototype"].includes(id) ||
          id !== s.id
        )
          throw Error();
        H.createSkill(H.createProfile("validate", "p"), s);
      } catch (_) {
        e.push("invalid skill " + id);
      }
    }
    for (const [id, m] of Object.entries(c.materials)) {
      if (
        !m ||
        !validId(id) ||
        ["constructor", "prototype"].includes(id) ||
        id !== m.id ||
        !Number.isSafeInteger(m.unitCost) ||
        m.unitCost < 1 ||
        m.unitCost > 1e12 ||
        !Number.isSafeInteger(m.leadMinutes) ||
        m.leadMinutes < 5 ||
        m.leadMinutes > 525600
      )
        e.push("invalid material " + id);
    }
    for (const [id, p] of Object.entries(c.products)) {
      if (
        !p ||
        !validId(id) ||
        ["constructor", "prototype"].includes(id) ||
        id !== p.id ||
        !p.bom ||
        !Object.keys(p.bom).length
      ) {
        e.push("invalid product " + id);
        continue;
      }
      for (const [mat, n] of Object.entries(p.bom))
        if (
          !Object.hasOwn(c.materials, mat) ||
          !Number.isSafeInteger(n) ||
          n < 1
        )
          e.push("invalid BOM " + id);
      for (const k of [
        "assemblyMinutes",
        "qaMinutes",
        "packingMinutes",
        "priceMin",
        "priceMax",
      ])
        if (
          !Number.isSafeInteger(p[k]) ||
          p[k] < 1 ||
          p[k] > (k.startsWith("price") ? 1e12 : 100000)
        )
          e.push("invalid " + id + "." + k);
      const bomCost = Object.entries(p.bom).reduce(
        (sum, [id, n]) => sum + (c.materials[id]?.unitCost || 0) * n,
        0,
      );
      if (!Number.isSafeInteger(bomCost) || Object.keys(p.bom).length > 64)
        e.push("unsafe BOM economics " + id);
      if (
        p.priceMin > p.priceMax ||
        !Number.isFinite(p.researchRequired) ||
        p.researchRequired < 0
      )
        e.push("invalid product economics " + id);
    }
    for (const [id, n] of Object.entries(c.initialStock))
      if (!Object.hasOwn(c.materials, id) || !Number.isSafeInteger(n) || n < 0)
        e.push("invalid stock " + id);
    for (const [id, r] of Object.entries(c.roles))
      if (
        !validId(id) ||
        ["constructor", "prototype"].includes(id) ||
        !r ||
        !Object.hasOwn(c.skills, r.skill)
      )
        e.push("invalid role " + id);
    if (c.taskKinds !== undefined) {
      if (
        !c.taskKinds ||
        typeof c.taskKinds !== "object" ||
        Array.isArray(c.taskKinds)
      )
        e.push("invalid taskKinds");
      else
        for (const [id, t] of Object.entries(c.taskKinds)) {
          try {
            if (id !== t.id) throw new TypeError("mismatched task id");
            validateTaskKind(c, t);
          } catch (_) {
            e.push("invalid taskKind " + id);
          }
        }
    }
    if (c.lifeGoals !== undefined) {
      try {
        H.deriveAspirations(
          H.createProfile("validate", "p"),
          H.STATE_DEFAULTS,
          { goalSpecs: c.lifeGoals },
        );
      } catch (_) {
        e.push("invalid life goals");
      }
    }
    for (const [k, v] of Object.entries(c.rules))
      if (typeof v !== "number" || !Number.isFinite(v) || v < 0)
        e.push("invalid rule " + k);
    for (const skill of [
      "sales",
      "admin",
      "engineering",
      "assembly",
      "quality",
      "logistics",
      "leadership",
    ])
      if (!Object.hasOwn(c.skills, skill))
        e.push("required skill " + skill + " missing");
    if (
      !Array.isArray(c.starters) ||
      !c.starters.length ||
      c.starters.length > 30
    )
      e.push("invalid starters");
    else
      for (const s of c.starters)
        if (
          !s ||
          typeof s.name !== "string" ||
          !Object.hasOwn(c.roles, s.role) ||
          !Number.isSafeInteger(s.dailyWage) ||
          s.dailyWage < c.rules.minimumWage
        )
          e.push("invalid starter");
    for (const [k, min, max] of [
      ["initialCash", 0, 1e12],
      ["initialDebt", 0, 1e12],
      ["rentDaily", 0, 1e9],
      ["minimumWage", 1, 1e7],
      ["creditLimit", 0, 1e12],
      ["paydayInterval", 1, 30],
      ["maxActiveOrders", 1, 20],
      ["maxUnits", 1, 400],
      ["scenarioDays", 1, 365],
      ["winCash", 0, 1e12],
      ["winReputation", 0, 100],
      ["hireFee", 0, 1e9],
      ["maxPeople", 1, 30],
    ])
      if (
        !Number.isSafeInteger(c.rules[k]) ||
        c.rules[k] < min ||
        c.rules[k] > max
      )
        e.push("invalid rule " + k);
    if (
      typeof c.rules.interestDaily !== "number" ||
      !Number.isFinite(c.rules.interestDaily) ||
      c.rules.interestDaily < 0 ||
      c.rules.interestDaily > 0.1
    )
      e.push("invalid interest rate");
    return e;
  }
  return Object.freeze({
    VERSION: "1.1.0",
    NATIONALITIES,
    NAME_POOLS,
    STARTER_IDENTITIES,
    CAREER_LADDERS,
    MOTIVE_FACTOR_LABELS,
    INDUSTRY_SKILL_TEMPLATES,
    getCareerStep,
    getNextCareerStep,
    createIdentity,
    translateMotiveFactor,
    createCatalog: () => clone(defaults),
    validateCatalog,
    registerSkill,
    registerRole,
    registerMaterial,
    registerProduct,
    registerTaskKind,
  });
});
