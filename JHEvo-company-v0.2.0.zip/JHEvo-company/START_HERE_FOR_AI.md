# เริ่มที่นี่ — Company Simulation (v0.2.0)

งานปัจจุบัน: เกมบริษัทมุมมองภายนอก (`SME Crisis: นิคมอิเล็กทรอนิกส์สยาม`) ผู้เล่นสังเกต NPC และ CEO ดำเนินกิจการเอง ดูสถานะล่าสุดที่ `project_status_and_ai_onboarding.md` และกฎที่ `AGENTS.md` ก่อนทำแพตช์

เปิดเล่น `COMPANY_SOURCE/CompanyFoundation_single.html` (หรือ `COMPANY_SOURCE/Company_single.html`) หรือรัน local server จาก `COMPANY_SOURCE` แล้วเปิด `index.html` ไฟล์ HTML เดี่ยวฝัง CSS/JS สำหรับใช้ออฟไลน์ 100%

## อ่านตามงาน

1. `AGENTS.md` — ขอบเขตผู้เล่น ล็อกแกนมนุษย์ บัญชี และเซฟ
2. `project_status_and_ai_onboarding.md` — สิ่งที่ทำได้จริงใน v0.2.0 ข้อจำกัด และผลตรวจล่าสุด (105/105 tests)
3. `.agents/skills/company-evolution-dev/SKILL.md` และ `.agents/skills/company-for-every-patch/SKILL.md` (รวมถึง `SKILL.md` ที่รากโปรเจกต์) — พิมพ์เขียวสถาปัตยกรรมและรายการตรวจสอบบังคับทุกครั้งที่อัปเดตแพตช์
4. `COMPANY_SOURCE/README.md` — วิธีเปิด สร้างไฟล์เล่น และเครื่องมือทดสอบ
5. `docs/company/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_2_0.md` — รายงานการอัปเดตแพตช์ v0.2.0 (ระบบสัญชาติ ชื่อ-นามสกุล ป้ายหน้าภาพรวม สายอาชีพ 4 ระดับ โบนัส และผลกระทบลูกโซ่)
6. `docs/company/PRESENTATION_API.md`, `HUMAN_CORE_MODEL.md`, `MANUFACTURING_SUPPLY_CHAIN_AND_INVENTORY_SPEC.md`, และ `HIERARCHICAL_WORKFORCE_AND_PROMOTION_SYSTEM.md`
