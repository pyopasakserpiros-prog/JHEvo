---
name: company-evolution-dev
description: Master engineering and patch development blueprint for SME Crisis / Company Simulation (นิคมอิเล็กทรอนิกส์สยาม — Autonomous Company Sim, COMPANY_SOURCE/) up to v0.2.0. Covers the Locked Human Core 1.0.0 (14 Personalities, 18 Values, 30 Aptitudes, 12 Vitality States, Yerkes-Dodson Curve), Multi-Nationality Demographic & Name Pools (TH/JP/CN/VN/MM/EN), 4-Level Career Ladders & Autonomous Promotions, Payday KPI Performance Bonuses & Satisfaction Index, Senior Mentorship & Machine Maintenance, 100% Thai Motive Translation, 2D Bird's-Eye Campus Grounds (8 Buildings), Character Sheet (8 Tabs + Compare), Living Corporate Chronicle, 1/7/30-Day 4-Account Periodic Digest, Tracked NPCs, and Sandbox Edit Hub. Update this skill after every Company patch.
---

# Company Simulation — Master Engineering Blueprint (v0.2.0)

## 1. Core Identity & Autonomous Design Philosophy
- **Game Title**: `SME Crisis: นิคมอิเล็กทรอนิกส์สยาม (Autonomous Company Simulation)`
- **Source Root**: `COMPANY_SOURCE/`
- **Single-File Build**: `COMPANY_SOURCE/CompanyFoundation_single.html` (and `Company_single.html`, built via `node tools/build.cjs`)
- **Core Gameplay Philosophy**:
  - **100% Autonomous NPC & CEO Loop**: Employees and the CEO (`coordinator` role) make all operational decisions autonomously based on their innate personalities, values, aptitudes, learned skills, vitality states, and cash reserves:
    - **Sales / CEO (`autoAccept`)**: Evaluates customer offers against BOM cost, margin, delivery deadline, queue load, achievement value, riskTaking, and prudence.
    - **Purchasing / Admin (`planPurchases`)**: Monitors BOM requirements vs. on-hand + in-transit inventory and orders materials while respecting payroll reserve cash.
    - **CEO Debt Repayment (`evaluateDebtRepayment`)**: Repays bank loan principal from surplus cash above a prudence-weighted safety reserve (`15..25` days of burn + payables).
    - **CEO Facility Investment (`evaluateFacilityInvestment`)**: Evaluates and upgrades 7 upgradable campus buildings (`hq`, `factory`, `warehouse`, `rnd`, `canteen`, `courtyard`, `training`) from Lv.1 to Lv.3 using company cash above reserve.
    - **CEO / HR Recruitment (`evaluateAutonomousHiring`)**: Recruits candidates when job backlog is overloaded and cash runway exceeds 30 days.
    - **Autonomous Merit Promotions (`evaluatePromotions`)**: Promotes qualifying employees across 4 career levels (`Lv.1` ➔ `Lv.2` ➔ `Lv.3` ➔ `Lv.4`) when tasks completed, primary skill, and tenure thresholds are met, raising prospective daily wage and triggering peer morale/drive ripple effects.
    - **Payday KPI Performance Bonuses (`evaluateBonuses`)**: Awards a payday bonus (`bonusAwarded`) to the top KPI performer when company cash exceeds safety reserves, posting to `wages` and crediting employee `wallet`, `totalPaid`, `totalEarned`, and `career.bonusTotal`.
    - **Preventive Machine Maintenance (`evaluateMachineMaintenance`)**: Assembly work wears `w.facilities.machineCondition`; when `< 82%`, an on-duty engineer/assembler/inspector restores machine condition (`machineMaintained`).
  - **Player Role**: Observational Director & Inspector who watches the living campus, inspects deep 8-tab character sheets, tracks favorite NPCs (`⭐`), filters the Living Corporate Chronicle, reviews 1/7/30-day 4-account digests, controls simulation speed/camera, or experiments via the **Sandbox Edit Hub**.

## 2. Permanently Locked Human Core 1.0.0 (`js/human-core.js`)
- **HARD INVARIANT**: Never modify `COMPANY_SOURCE/js/human-core.js` or `COMPANY_SOURCE/CORE_LOCK.json` (`SHA-256: fa83eaa0ef3407f26f21675161f632a4365242f67fea7b0c192e59e75b9d5c32`).
- **Dimensions**:
  - **14 Personalities (`H.PERSONALITY`)**: `sociability`, `conscientiousness`, `agreeableness`, `openness`, `riskTaking`, `stressReactivity`, `assertiveness`, `patience`, `integrity`, `adaptability`, `ambition`, `prudence`, `humility`, `optimism`
  - **18 Values (`H.VALUES`)**: `security`, `income`, `autonomy`, `fairness`, `belonging`, `learning`, `achievement`, `meaning`, `workLifeBalance`, `recognition`, `family`, `comfort`, `care`, `stewardship`, `influence`, `tradition`, `variety`, `craftsmanship`
  - **30 Aptitudes & Potentials (`H.APTITUDES`)**: Cognitive, Social/Executive, Psychomotor/Technical, and Sensory/Physical capacities.
  - **12 Vitality States (`H.STATE_DEFAULTS`)**: `energy`, `focus`, `hunger`, `stress`, `burnout`, `morale`, `health`, `sleepDebt`, `socialNeed`, `lifeBurden`, `fulfillment`, `drive`.

## 3. Multi-Nationality Identity, Career Ladders & Chain-Reaction Realism (v0.2.0)
- **6 Nationalities (`D.NATIONALITIES` & `D.NAME_POOLS`)**:
  - `TH` (`🇹🇭 ไทย`), `JP` (`🇯🇵 ญี่ปุ่น`), `CN` (`🇨🇳 จีน`), `VN` (`🇻🇳 เวียดนาม`), `MM` (`🇲🇲 เมียนมา`), `EN` (`🇬🇧 สากล (ตะวันตก)`)
  - Deterministic generator `D.createIdentity(seed, personId, baseName, roleId)` produces `firstName`, `lastName`, `nickname`, `fullName`, `displayName`, `gender` (`M`/`F`), `genderTh` (`ชาย`/`หญิง`), `genderSymbol` (`♂`/`♀`), `age` (`21..48`), `nationality`, `nationalityTh`, `flag`, `educationTh`, and `hometownTh` without consuming `w.rng`.
- **4-Level Career Ladders (`D.CAREER_LADDERS`)**:
  - Every role (`sales`, `admin`, `engineer`, `assembler`, `inspector`, `logistics`, `coordinator`) has 4 career levels (`Lv.1` ➔ `Lv.2` ➔ `Lv.3` ➔ `Lv.4`) with Thai titles, `minTasks`, `minSkill`, `minTenureDays`, `wageBonus` (in satang), and `mentorPower`.
- **Employee Overview Card (`ป้ายหน้าภาพรวม`) & 100% Thai Motives**:
  - Displays Flag, Full Name + Surname + Nickname, Gender, Age, Nationality, Career Badge + Title, Satisfaction %, KPI Score (`0–100`), Education, Hometown, Building/Indoor status, Daily Wage, Cumulative Bonus, and Mentor name.
  - `D.translateMotiveFactor(factor, extraLabels)` translates 100% of `H.scoreOptions` factors (`effort`, `delay`, `skillFit`, `change`, `risk`, `value:*`, `personality:*`, `state:*`) into natural Thai so raw English keys never leak into the UI.

## 4. Module Architecture (`COMPANY_SOURCE/js/`)
1. `human-core.js`: Locked Human Core 1.0.0.
2. `data.js`: Catalog defaults, `NATIONALITIES`, `NAME_POOLS`, `STARTER_IDENTITIES`, `CAREER_LADDERS`, `MOTIVE_FACTOR_LABELS`, `createIdentity`, `translateMotiveFactor`, and extension registrars.
3. `layout.js`: 40×25 tile grid, 4-direction A* pathfinding, station access coordinates, and site expansion.
4. `economy.js`: Integer-satang closed-loop ledger (`sales`, `materials`, `rent`, `interest`, `wages`, `overtime`, `welfare`, `loan`, `debtRepayment`, `expansion`, `equipment`, `hiring`, `customerRefund`).
5. `sim.js`: 5-minute tick engine, autonomous role/CEO loops, promotions, payday bonuses, machine maintenance, mentorship, and `audit(w)`.
6. `save.js`: Strict JSON schema validator, `identity`/`career`/`facilities` validator, and legacy save migrator.
7. `api.js`: Immutable `CompanyAPI.create` facade, `CAMPUS_BUILDINGS`, `presentChronicleEntry`, `computePeriodDigest` (1/7/30d × 4 accounts), and `compareEmployees`.
8. `campus-render.js`: 2D bird's-eye campus renderer, level-scaled building visuals, smooth walking interpolation, and minimap.
9. `debug.js`: JS2-inspired dark-emerald & gold HUD, 6 bottom nav sheets, 8-tab Character Sheet, Living Chronicle filter, and Sandbox Edit Hub.

## 5. Verification & Build Commands
```bash
cd COMPANY_SOURCE
node tools/verify.cjs
node tools/test.cjs
node tools/build.cjs
node tools/benchmark.cjs
```
- All 105 unit tests in `tools/test.cjs` must pass with 0 failures before packaging.
