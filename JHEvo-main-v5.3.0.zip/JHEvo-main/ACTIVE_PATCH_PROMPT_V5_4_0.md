# ACTIVE_PATCH_PROMPT_V5_4_0.md — แผนงานพัฒนาแพตช์ถัดไป (Patch v5.4.0: Era 5 Phase 5 — Grand Sect War Cinematics, Boss Raid Domain Arenas & Interactive Skill VFX Gallery)

> **เอกสารฉบับนี้คือพิมพ์เขียวสำหรับ AI ในการพัฒนาแพตช์ถัดไป (`v5.4.0`) ต่อเนื่องจาก `v5.3.0`**
> เมื่อเริ่มต้นเซสชันใหม่ ให้ทำตามขั้นตอนใน `START_HERE_FOR_AI.md` แล้วใช้เอกสารนี้เป็นข้อกำหนดหลักของแพตช์ทันที

---

## 🎯 เป้าหมายหลักของแพตช์ v5.4.0 (Era 5 Phase 5: Grand Sect War Cinematics, Boss Raid Domain Visuals & Interactive Skill VFX Gallery)

ต่อยอดจากระบบทัณฑ์สวรรค์ 3 จังหวะและเอฟเฟกต์วิชาเฉพาะตัว 15 กระบวนท่าใน `v5.3.0` สู่การยกระดับ **ฉากศึกสงครามป้องกันสำนัก (Grand Sect Siege & Raid Cinematics)**, **เขตแดนบอสอสูรบรรพกาล (Boss Domain Field Visuals)**, และ **หอแสดงเอฟเฟกต์ยุทธ์แบบโต้ตอบ (Interactive Skill VFX Showcase Canvas)** ในหอคัมภีร์และหน้าวรยุทธ์ตัวละคร:

### 1. หอแสดงเอฟเฟกต์วิชาเฉพาะตัวแบบโต้ตอบ (`Render.skillVfxShowcase` — `js/render.js`, `js/ui.js`)
- เพิ่มแคนวาสพรีวิว `Render.skillVfxShowcase(canvas, techOrSigId, opts)` ในหน้าวรยุทธ์ของศิษย์ (`UI.rNpc` แท็บ `tech`) และในหอคัมภีร์สำนัก (`UI.rSectLibrary`) เพื่อให้ผู้เล่นสามารถชมแอนิเมชันจำลองของวิชาเฉพาะตัวทั้ง 15 ท่าได้โดยตรงในหน้าต่างข้อมูล

### 2. ฉากศึกสงครามป้องกันสำนักและค่ายกลปะทะ (`Grand Sect Siege & Barrier Clash Spectacles` — `js/render.js`, `js/ui.js`)
- เมื่อเกิดศึกบุกสำนัก (`W.threat && W.threat.raid`) หรือเปิดโหมดพรีวิวศึกใหญ่ ให้แสดงผลคลื่นกระแทกบนโดมค่ายกลพิทักษ์สำนัก (`drawSectBarrierDome`), ธงศึกฉุกเฉินสะบัดรอบประตูสำนัก, และปุ่ม `⚔️ ส่องดูแนวรบหน้าด่าน` (`focus-raid-frontline`)

### 3. เขตแดนบอสและอสูรบรรพกาลบนแผนที่สำนัก (`Ancient Beast & Boss Domain Visuals` — `js/render.js`)
- วาดวงแหวนเขตแดนอสูรบรรพกาลใต้ร่างศัตรูระดับหัวหน้า (`f.boss` หรือ `b.legendary`) พร้อมออร่าธาตุประจำตัว

### 4. การจัดระเบียบหมวดย่อยเพิ่มเติมในหอคัมภีร์และหน้าความสัมพันธ์ (`Sub-Category Refinements` — `js/ui.js`)
- เพิ่มตัวกรองหมวดย่อยในหน้าความสัมพันธ์ (`rel`) และหน้าชีวิต (`life`) ของตัวละครเมื่อมีรายการยาว เพื่อให้เลื่อนดูได้สะดวกในคลิกเดียว

---

## 🛡️ กฎเหล็กทางสถาปัตยกรรม (Hard Constraints ที่ห้ามละเมิดเด็ดขาด)
1. **ห้ามแก้ไข `GAME_SOURCE/js/human_core.js` เด็ดขาด**: `HC.FINGERPRINT === '155:2f9c9dd7'` ต้องคงเดิม 100%
2. **Pure Read-Only Rendering & UI**: ฟังก์ชันวาดภาพทั้งหมดห้ามเรียก `W.rng()` และห้ามกลายพันธุ์สถานะจำลอง (`SIM.serialize(W)` ต้องเหมือนเดิม 100% ก่อนและหลังวาด)
3. **งบประสิทธิภาพ (Performance Budget)**: ค่าเฉลี่ยเวลาจำลองที่ 80 NPCs ต้อง `<= 3.5 ms/tick`
4. **คงจำนวน `<script>` ทั้ง 40 แท็กใน `index.html` และ `test/load.js`**

---

## 🧪 เกณฑ์การตรวจสอบและส่งมอบ (Verification & Delivery Checklist)
1. อัปเดต `SIM.PATCH_VERSION = '5.4.0'` และ `SIM.SAVE_SCHEMA_VERSION = '5.4.0-war-cinematics-and-skill-gallery'` ใน `GAME_SOURCE/js/sim.js`
2. สร้างชุดทดสอบใหม่ `GAME_SOURCE/test/v540_war_cinematics_and_skill_gallery_suite.js` และลงทะเบียนใน `GAME_SOURCE/test/run_all.js`
3. รัน `node tools/validate_data_schema.js` (`0 Errors / 0 Warnings`), `node tools/build_single.js`, และ `node tools/run_parallel_tests.js` (`130/130 PASS`)
4. เขียนรายงาน `PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_V5_4_0.md` และเตรียม `ACTIVE_PATCH_PROMPT_V5_5_0.md`
5. บีบอัดไฟล์ส่งมอบ `JHEvo-main-v5.4.0.zip` และแสดงผลผ่าน `google:show_file`
