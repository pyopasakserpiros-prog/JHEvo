# สารบัญรายงานแพตช์และการตรวจสอบ (Patch Reports Index)

- **ล่าสุด: 260c repair บน JS2-v2.6.0 main-debug:** [รายงาน](260C_REPAIR_JS2_V2_6_0.md) — แก้ real producers, stats/active mastery, recovery/receipts, acquired modifier contract และ calendar/work-step/save consistency; เก็บงานฉายา/ผัง/ภาพเดิม
- **Complete Tier-Scaled VFX (T1–T7), Sub-Path Motifs, Equipment & Combat Action VFX บน JS2-v2.6.0:** [COMPLETE_TIER_SUBPATH_EQUIP_VFX_JS2_V2_6_0.md](COMPLETE_TIER_SUBPATH_EQUIP_VFX_JS2_V2_6_0.md) — ครบทุกระดับ T1–T7 (>= 64 ลาย/ระดับ), 64 ตราสายย่อย/มรรคา, 122 มนตรา, 64 เอฟเฟกต์อุปกรณ์, 36 แอคชั่นการรบ และตรวจแก้พิกัดเป้าหมาย/ระยะไกล-ประชิด (164/164 PASS)
- **T6 shared group VFX บน JS2-v2.6.0:** [T6_GROUP_VFX_JS2_V2_6_0.md](T6_GROUP_VFX_JS2_V2_6_0.md) — 50 ลาย / 114 วิชา / 207 ท่าย่อย + 8 พาสซีฟ และ 117 อุปกรณ์; เตรียม T5
- **Ordinary T7 VFX บน JS2-v2.6.0:** [T7_VISUALS_JS2_V2_6_0.md](T7_VISUALS_JS2_V2_6_0.md) — 71 วิชา / 157 ท่าย่อย / 85 อุปกรณ์ใน 25 ประเภท พร้อมส่งต่อ T6
- **Legendary Apex บน JS2-v2.6.0:** [LEGENDARY_APEX_JS2_V2_6_0.md](LEGENDARY_APEX_JS2_V2_6_0.md) — ฉากสำแดง 47 วิชา / 3 พาสซีฟ / 27 อุปกรณ์ พร้อมขยายพื้นที่ภาพ T4–T7 ในอนาคต
- **T3 VFX บน JS2-v2.6.0:** [T3_SKILL_VFX_JS2_V2_6_0.md](T3_SKILL_VFX_JS2_V2_6_0.md) — 24 ลาย / 26 วิชา T3 / 8 พาสซีฟ / 6 สถานะ พร้อมเพดานภาพสำหรับ T4–T7 ในอนาคต
- **Common low-tier VFX บน JS2-v2.6.0:** [COMMON_SKILL_VFX_JS2_V2_6_0.md](COMMON_SKILL_VFX_JS2_V2_6_0.md) — 30 ลายพื้นฐาน / 66 วิชา / 12 พาสซีฟ / 22 สถานะจริง
- **VFX refinement บน `JS2-v2.6.0` main:** [`SKILL_VFX_EXPANSION_JS2_V2_6_0.md`](SKILL_VFX_EXPANSION_JS2_V2_6_0.md) — เพิ่ม 15 ลาย Signature ของวิชาที่ไม่เคยมีเอฟเฟกต์ที่ resolver เลือกได้; รวม 45 ลาย พร้อม [ทะเบียนชื่อ/ID/ลายเพื่อป้องกันการทำซ้ำ](../docs/audits/SKILL_VFX_ASSIGNMENT_REGISTRY.md) และ [ภาพ Canvas เทียบทั้งหมด](../docs/visuals/skill-vfx-expansion/skill-vfx-gallery.png)
- **ล่าสุด (`JS2-v2.6.0`):** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_6_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_6_0.md) — JianghuSect 2 v2.6.0: พงศาวดารมีชีวิต การรายงานยุทธภพ และระบบกรองการรับข่าว (Fact Snapshot ณ เวลาเกิดเหตุ, ประวัติบุคคลย้อนหลังแม้ตาย/ถูกขับ/เปลี่ยนชื่อ, รายงาน 12 รูปแบบพร้อมลิ้นชักอธิบายตัวเลข, สมุดสรุปสถานการณ์ประจำรอบ 1/7/30 วันแยกบัญชีไม่บวกซ้ำ, เส้นเรื่องต่อเนื่อง, แยกตั้งค่ารับข่าว 5 โหมดออกจากตัวกรองค้นอ่านคลัง, คุ้มครองหมุดหมายสำคัญเมื่อตัดคลัง, 148/148 กลุ่มชุดทดสอบผ่าน 100%)
- **`JS2-v2.5.0` visual refinement (on v2.6.0 main):** [`WEAPON_MOTION_VFX_JS2_V2_5_0.md`](WEAPON_MOTION_VFX_JS2_V2_5_0.md) — 17 รูปแบบอาวุธ, แก้ทิศ/ตำแหน่งตามเป้าจริง, marker ผู้รับหลายเป้าหมาย และออร่าบัฟติดตัวผู้รับ
- **`JS2-v2.5.0` (All Equipment Tier Art):** [`ALL_EQUIPMENT_TIER_ART_JS2_V2_5_0.md`](ALL_EQUIPMENT_TIER_ART_JS2_V2_5_0.md) — ภาพไอเท็ม 9 แผ่น / 576 ช่อง ครบ 28 กลุ่มอุปกรณ์ + 13 กลุ่มโอสถ/วัตถุดิบ/ปลาตาม Tier
- **`JS2-v2.5.0` (Item Art Variety):** [`ITEM_ART_VARIETY_JS2_V2_5_0.md`](ITEM_ART_VARIETY_JS2_V2_5_0.md) — ระบบจัดหมวดภาพไอเท็มและเกรดงานหลอม
- **`JS2-v2.5.0` (Legendary Visual Identity):** [`LEGENDARY_VISUAL_IDENTITY_JS2_V2_5_0.md`](LEGENDARY_VISUAL_IDENTITY_JS2_V2_5_0.md) — เอกลักษณ์ภาพ 50 วิชาตำนาน และ 27 อุปกรณ์ตำนาน
- **`JS2-v2.5.0` (Pathbound Ascendant Visuals):** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_5_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_5_0.md) — JianghuSect 2 v2.5.0: Pathbound Ascendant Visuals & Signature Arts (ออร่าขั้นสูงสุดครบ 43/43 มหาวิถีตาม `maxStage` จริง 4/5/8/9, ละอองปราณหลายระดับ P2, 30 Signature Skill VFX ครอบคลุม 241 วิชาจริงผ่าน `COMBAT → castFx → Render`, 142/142 กลุ่มชุดทดสอบผ่าน 100%)
- **`JS2-v2.4.0`:** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_4_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_4_0.md) — JianghuSect 2 v2.4.0: Tactical Composable Grand Dao, Demonic Higher Realms & Comprehensive Bugfix Release (141/141 กลุ่มชุดทดสอบผ่าน 100%)
- **`JS2-v2.3.0`:** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_3_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_3_0.md) — JianghuSect 2 v2.3.0: Grand Dao Deep Parity & Universal Arsenal
- **`JS2-v2.2.0`:** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_2_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_2_0.md) — JianghuSect 2 v2.2.0: Cosmic Pantheon, Shinobi & Manual Lifecycle
- **`JS2-v2.1.0`:** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_1_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_1_0.md) — JianghuSect 2 v2.1.0: Grand Dao Debates & Apex Trials
- **`JS2-v2.0.0`:** [`PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_0_0.md`](PATCH_IMPLEMENTATION_REPORT_JIANGHUSECT2_V2_0_0.md) — JianghuSect 2 v2.0.0: The Grand Dao Epoch
- **ภาค 1 สิ้นสุด (v5.8.0):** [`PATCH_IMPLEMENTATION_REPORT_V5_8_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_8_0.md) — Era 5 Phase 9: Mega 6-Pillar Expansion (วิชาต้องห้าม 37 วิชา + 6 คัมภีร์ T1–T6, 263 พาสซีฟ 6 กลุ่มดาว, หอคัมภีร์ต้องห้าม, แท่นบูชาสายเลือดบรรพกาล, 134/134 ชุดทดสอบผ่าน 100%)
- **v5.7.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_7_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_7_0.md) — Era 5 Phase 8: Support & Auxiliary Arts Overhaul (วิชาสายสนับสนุน 44 วิชา และวิชาเสริม 53 วิชา รวม 97 วิชา 6 อาร์คิไทป์, 3 ท่วงท่ายุทธวิธี, คลื่นเสียงพิณและธงค่ายกล, 133/133 ชุดทดสอบผ่าน 100%)
- **v5.6.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_6_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_6_0.md) — Era 5 Phase 7: Defensive Kungfu & Protective Aegis Overhaul (วิชาคุ้มกาย 6 อาร์คิไทป์, 3 ท่วงท่าตั้งรับ, ปราการเพชรและม่านสวรรค์, 132/132 ชุดทดสอบผ่าน 100%)
- **v5.5.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_5_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_5_0.md) — Era 5 Phase 6: Mantra Resonance, Dynamic Weather & Grand Formation Warfare (122 คัมภีร์ลมปราณ 7 อาร์คิไทป์, ค่ายกลสงครามสำนัก 3 ท่า, ปรากฏการณ์ฟ้าดิน 6 สภาพ, 131/131 ชุดทดสอบผ่าน 100%)
- **v5.4.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_4_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_4_0.md) — Era 5 Phase 5: Qinggong Locomotion, Sword Flight & Celestial Levitation (วิชาตัวเบา 6 ระดับ, กระบี่บินเหินเวหา, เหาะเหินเดินอากาศเซียน, 130/130 ชุดทดสอบผ่าน 100%)
- **v5.3.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_3_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_3_0.md) — Era 5 Phase 4: Heavenly Tribulation Breakthrough Overhaul & 15 Signature Skill VFX (ทัณฑ์สวรรค์ 15 ทิค, สายฟ้า 1/3/6/9 สาย, เอกลักษณ์ 12 วิถี, 15 สกิลเอฟเฟกต์เฉพาะตัว, 129/129 ชุดทดสอบผ่าน 100%)
- **v5.2.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_2_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_2_0.md) — Era 5 Phase 3: Sub-Category Navigation Overhaul, Grand World Atlas Visuals, Portal FX & Relic Showcase (ครบ 5 เสาหลัก, 128/128 ชุดทดสอบผ่าน 100%)
- **v5.1.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_1_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_1_0.md) — Era 5 Phase 2: Interactive Visual Dioramas, Sect Cutscenes & Martial Arena Camera (ครบ 5 เสาหลัก, 127/127 ชุดทดสอบผ่าน 100%)
- **v5.0.0:** [`PATCH_IMPLEMENTATION_REPORT_V5_0_0.md`](PATCH_IMPLEMENTATION_REPORT_V5_0_0.md) — Era 5 Phase 1: Grand Celestial Visual Overhaul, Living Sect Ground Spectacles & Shaders (ครบ 6 เสาหลักกราฟิก, 126/126 ชุดทดสอบผ่าน 100%)
- **v4.1.0:** [`PATCH_IMPLEMENTATION_REPORT_V4_1_0.md`](PATCH_IMPLEMENTATION_REPORT_V4_1_0.md) — Phase 7: Living Sect Expansion, 8-Peak Sanctuary Awakening & Architectural Evolution (ครบ 5 เสาหลักใหม่, 126/126 ชุดทดสอบผ่าน 100%)
- **v4.0.0:** [`PATCH_IMPLEMENTATION_REPORT_V4_0_0.md`](PATCH_IMPLEMENTATION_REPORT_V4_0_0.md) — Phase 6: Living Frontier, Behavioral Mastery & Sect Charter (124/124 ชุดทดสอบผ่าน 100%)
- **v3.6.0:** [`PATCH_IMPLEMENTATION_REPORT_V3_6_0.md`](PATCH_IMPLEMENTATION_REPORT_V3_6_0.md)

### 📚 เอกสารตรวจสอบและข้อเสนอเชิงลึก (Audit & Strategic Documents)
- [`../docs/audits/JS2_V2_6_0_CHRONICLE_COVERAGE_MATRIX_TH.md`](../docs/audits/JS2_V2_6_0_CHRONICLE_COVERAGE_MATRIX_TH.md) — ตารางสำรวจ Producer → UI Coverage Matrix ของแพตช์ `JS2-v2.6.0`
- [`JHEvo_v3.1.0_Full_Game_Audit_Report.pdf`](JHEvo_v3.1.0_Full_Game_Audit_Report.pdf) — รายงานตรวจสอบระบบเกมฉบับเต็ม v3.1.0 (PDF 1.35 MB)
- [`JHEvo_v3.1.0_Development_Proposals_and_Roadmap.pdf`](JHEvo_v3.1.0_Development_Proposals_and_Roadmap.pdf) — แผนงานพัฒนาและข้อเสนอวิวัฒนาการสำนัก v3.1.0 (PDF 1.58 MB)
- [`Jianghu_Sect_Full_Game_Audit_2026-11-06.docx`](Jianghu_Sect_Full_Game_Audit_2026-11-06.docx) — รายงานตรวจสอบโครงสร้างเกมแบบละเอียดยิบ (DOCX)


---
## Latest Patch Update: Life-Experience Traits, Action Masteries, 360×304 Sect Expansion, 1.5× Day Length & 96× Speed (`JS2-v2.6.0` Next Patch)
- **Life-Experience & Behavioral Action-Mastery Traits (`T01`–`T07`)**:
  - Evaluated all **72 proposals** from `TRAIT_01B.pdf` + 6 existing `CULT.EXPERIENCE_TRAITS` + 4 existing `COMBAT.ACTION_MASTERY_TRAITS` + 6 Codex Life-Rhythm & Resilience traits (`88` cataloged entries in `docs/handovers/LIFE_TRAITS_72_REVIEW_TRACKER.csv` & `JD.LIFE_TRAITS_REGISTRY`).
  - Expanded `CULT.EXPERIENCE_TRAITS.CATALOG` to **36** traits with wisdom-preserving recovery (`burdenActive = false, recovered = true`) and episode-watermark deduplication (`episodeWatermarks`).
  - Expanded `COMBAT.ACTION_MASTERY_TRAITS.TRAIT_DEFS` to **24** masteries with an autonomous **3-slot active cap** (`activeMasteryIds`, max 3 with hysteresis) while retaining full lifetime history in `unlockedTraits`, plus `TRAIT_NONLETHAL_SUBDUER` 1 HP clamp.
  - Enforced strict **Birth-Pool Guard** (`birthEligible: false` on all 27 Group E `TR_AC_*` traits and `CULT.EXPERIENCE_TRAITS.stripBirthIneligibleTraits`).
- **Expanded 360×304 Sect Compound & Wilderness (`M01`–`M06`)**:
  - Expanded world grid from `240×192` to `360×304` (`109,440` tiles, `2.37×` area; `MAP.OX = 84, MAP.OY = 56`), inner compound wall `WX0 = 72, WY0 = 56, WX1 = 288, WY1 = 204` (`216×148`), central axis `x = 180`, plaza center `(180, 123)`.
  - Placed all **8 Sacred Peaks** on outer-ring compound terraces with zero road/building overlaps, expanded `MAP.PLOTS` to **8**, added 4 directional gate outposts (`gate_north`, `gate_west`, `gate_east`, `gate`), and implemented true **4-Gate Dynamic Routing** (`S, N, W, E`) with blocked-gate fallback and `M.topologyRev` path-cache invalidation.
  - Shifted Southern Spirit River to `y ≈ 268` (`3` bridges, `26` fishing stations), added **8 physical Beast Dens** (`W.wildlife.dens`), enforced `!MAP.blocked` on beast movement, and upgraded `COG.huntValue` for realm-appropriate hunting.
- **1.5× Day Length & 96× Simulation Speed (`D01`–`D04`)**:
  - `SIM.DAY_FACTOR = 1.5`, `SIM.WORK_STEPS_PER_DAY = 2160` work-steps per `1440`-minute calendar day with `W._isNewCalendarMinute` boundary-once guards and `1 / SIM.DAY_FACTOR` metabolic scaling.
  - `UI.SPEEDS = [0, 1, 2, 4, 8, 16, 32, 48, 96]` with high-speed render throttling (`50ms` at `96×`) and automatic legacy `240×192` save coordinate migration `(+62, +42)`.
