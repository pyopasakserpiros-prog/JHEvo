---
name: gameplay-architecture
description: Use when changing JianghuSect simulation architecture, module loading, world state, sect systems or offline build.
---

# JianghuSect Evolution — Macro-Simulation & Sect Governance Architectural Blueprint (`js/sim.js`, `js/sect.js`, `index.html`, `test/load.js`)

> **Current baseline 4.1.0 (updated from 2.0.28–3.6.0):** This project-specific skill contains historical material from earlier versions. The targeted corrections below do not certify every older formula or API. Before implementing, verify the relevant behavior against current source and tests; use `project_status_and_ai_onboarding.md` for the current feature inventory and `AGENTS.md` for project rules.

This skill is the definitive master specification for JianghuSect Evolution's core engine architecture. It governs the strict 40-script-tag load invariant, the single authoritative world state (`W`), deterministic PRNG simulation lifecycle (`js/sim.js`), comprehensive sect governance, succession, and facility management (`js/sect.js`), strict CA/PA applicant evaluation boundaries, ancestral shrine legacy tablets, and the single-file offline build pipeline (`tools/build_single.js`).

---

## 1. System Architecture & The 40-Script-Tag Invariant

JianghuSect Evolution operates with **zero external build bundlers** (no Webpack, Vite, or Rollup). Every module is an Immediately Invoked Function Expression (IIFE) that runs cleanly in both modern browser DOM/Canvas environments and headless Node.js VM test harnesses (`test/load.js`).

```javascript
(function (g) {
  'use strict';
  // Module definition attaches to global namespace g
  const SECT = {};
  // ...
  g.SECT = SECT;
  if (typeof module === 'object' && module.exports) module.exports = SECT;
})(typeof globalThis !== 'undefined' ? globalThis : this);
```

### 1.1 The Exact 40-Script Load Order (`index.html` lines 42–83 & `test/load.js`)
The execution order is strictly deterministic and hard-wired. Any modification to tag counts breaks regression test suites (`test_overhaul_pack.js` asserts `scriptTags.length === 40`).

| Stage | Script Count | File Path | Global Namespace Attached | Purpose & Invariants |
| :--- | :--- | :--- | :--- | :--- |
| **Data Layer** | 1 | `data/data_core.js` | `g.JD.CORE` | Base definitions, factions, geography |
| | 2 | `data/data_cult.js` | `g.JD.CULT` | 9 Cultivation Paths, stages, stat curves |
| | 3 | `data/data_items.js` | `g.JD.ITEMS` | Equipment, recipes, pill catalogs, drop tables |
| | 4 | `data/data_bt.js` | `g.JD.BT` | Breakthrough tribulations, requirements, gates |
| | 5 | `data/data_cb.js` | `g.JD.CB` | Combat move definitions, archetypes, stances |
| | 6 | `data/data_cp.js` | `g.JD.CP` | Contribution point store tiers, exchange rates |
| | 7 | `data/data_tech.js` | `g.JD.TECH` | Martial manuals, mantras, innate techniques |
| | 8 | `data/data_beasts.js` | `g.JD.BEASTS` | Spirit beasts, species catalog, pack profiles |
| | 9 | `data/data_expansion.js` | `g.JD.EXP` | 78 Subpaths, 9-Realm specialization tracks |
| | 10 | `data/data_martial.js` | `g.JD.MARTIAL` | 18 Equipment resonance sets, weapon families |
| | 11 | `data/data_ecology.js` | `g.JD.ECO` | World ecology nodes, regional resource biomes |
| **Core Systems** | 12 | `js/util.js` | `g.U` | Fast PRNG (`U.RNG`), math helpers, clamp, uuid |
| | 13 | `js/human_core.js` | `g.HC` | 12-layer Human Core model (fingerprint frozen) |
| | 14 | `js/world_map.js` | `g.MAP` | 240×192 World Map, terrain grid, Southern River |
| | 15 | `js/cultivation.js` | `g.CULT`, `g.ELEM` | Qi progression, 9-Realm tracks, elemental matrix |
| | 16 | `js/economy.js` | `g.ECO` | Facility crafting, stockpile, market ledgers |
| | 17 | `js/sect.js` | `g.SECT` | Governance, offices, succession, applicants, Edit Hub |
| | 18 | `js/ai.js` | `g.AI` | NPC Psychological Utility AI, station lifecycle |
| | 19 | `js/combat.js` | `g.COMBAT` | Turn/tick combat engine, weapon tactics, damage |
| | 20 | `js/expedition.js` | `g.EXPED` | Caravans, world map travel, sect defense raids |
| | 21 | `js/explore.js` | `g.EXPLORE` | Nine-Dao Pagoda, 5-Elemental Realms, Sanctums |
| | 22 | `js/bottleneck.js` | `g.BN` | Bottleneck resolution, tribulation failure wounds |
| | 23 | `js/skills.js` | `g.SK` | Combat move selector, cooldowns, channeling |
| | 24 | `js/stats.js` | `g.STATS` | Composite stat calculator, timed buffs, caching |
| | 25 | `js/cpeco.js` | `g.CPE` | Contribution point ledger, item distribution |
| | 26 | `js/external_market.js` | `g.EXT` | Wandering merchants, caravan trade accords |
| | 27 | `js/content.js` | `g.CONTENT` | Cross-sect diplomacy, treaties, political events |
| | 28 | `js/martial.js` | `g.MARTIAL` | Weapon mastery, passive reconciler, resonances |
| | 29 | `js/proficiency.js` | `g.PROF` | Crafting & combat move proficiency mastery |
| | 30 | `js/knowledge.js` | `g.KNOW` | Ancient insights, secret art research |
| | 31 | `js/retraining.js` | `g.RETRAIN` | Cultivation path realignment, foundation cleansing |
| | 32 | `js/cognition.js` | `g.COG` | Goal-Driven Cognition, office directives, agenda |
| | 33 | `js/wildlife.js` | `g.WILD` | Wildlife ecology, roaming spirit packs |
| | 34 | `js/wild_resources.js`| `g.WILD_RES` | Wilderness forage & mining resource nodes |
| | 35 | `js/sim.js` | `g.SIM` | Master clock, tick/hour/day/month simulation |
| | 36 | `js/visitors_clues.js` | `g.VC` | Wandering cultivators, clues, legendary weapons |
| | 37 | `js/fishing.js` | `g.FISHING` | River fishing Monte Carlo loot, rod mastery |
| **Browser Only**| 38 | `js/render.js` | `g.Render` | Canvas 2D renderer, viewport camera, sprites |
| | 39 | `js/ui.js` | `g.UI` | Wuxia DOM UI panels, Edit Hub modal, tabs |
| | 40 | `js/main.js` | `g.G` | Animation loop, requestAnimationFrame, input |

---

## 2. Authoritative Single World State (`W`) & Deterministic PRNG

All simulation state exists inside a single serializable JavaScript object `W`. Modules never store state in local variables across ticks.

### 2.1 Authoritative Schema (`SIM.create` lines 146–218 - v2.0.17)
- `W.v`: engine version `SIM.VERSION` (currently `1.10.11`); `SIM.PATCH_VERSION` currently `2.0.28` is separate.
- `W.seed`: Deterministic root world seed string.
- `W.rng`: Root deterministic pseudorandom number generator instance (`new U.RNG(seed + ':world')`).
- `W.t`: Master timeline integer in simulation minutes (1 tick = 1 minute).
- `W.day`: Current elapsed day index (`Math.floor(W.t / 1440)`).
- `W.season`: Current seasonal cycle (0: Spring, 1: Summer, 2: Autumn, 3: Winter).
- `W.npcs`: Flat array of all living, dead, away, and exiled NPC objects.
- `W.byId`: Fast O(1) hash map indexing NPCs by ID (`W.byId[id]`).
- `W.sect`: Core sect state object:
  - `name`, `archetype`: Sect name and foundational archetype.
  - `masterId`, `deputyId`: Active leadership NPC IDs.
  - `posts`: Record mapping post keys (`'martial'`, `'alchemy'`, etc.) to NPC IDs.
  - `policy`: 7-axis governance policy + 5-axis focus weights.
  - `stones`: Sect spiritual stone treasury balance.
  - `stock`, `gear`, `crystals`: Sect warehouse inventories.
  - `reserveDirectives`, `shortageDirectives`: Autonomous supply chain directives.
  - `legacyTablets`: Ancestral shrine memorial inscriptions.
  - `ascendedLegacyHistory`: Ascended elder records (capped at 50).
  - `mentorship`: Direct disciple bonds, coaching logs, and synthesized heritage arts (`SECT.MENTORSHIP`).
  - `supportDoctrine`, `specialistFacilities`: Support AI & specialist building levels.
- `W.world`: Regional macro-state (`sects`, `politics`, `nodes`, `caravans`):
  - `jianghu`: Tavern rumors, karma bonds, and sworn allies (`SECT.JIANGHU`).
- `W.map`: Sect compound spatial grid, building definitions (`W.map.buildings`), and station states.

### 2.2 Time & Calendar Units (`SIM.calendar`)
```
1 tick          = 1 simulation minute
60 ticks        = 1 hour (runs SIM.hourly)
1440 ticks      = 1 day (runs SIM.dailyUpdate at midnight)
30 days         = 1 month (day % 30 === 0 runs SIM.monthly)
90 days         = 1 season (Spring, Summer, Autumn, Winter)
360 days        = 1 cultivation year (4 seasons × 90 days)
```

---

## 3. The Master Simulation Lifecycle (`js/sim.js`)

Simulation steps execute along strict performance budgets: **< 3.0 ms per tick for 80 NPCs**, supporting simulation speeds up to **80x+**.

```mermaid
flowchart TD
    Tick["SIM.tick(W) - Every Game Minute"] --> Travel["Process Traveling & Exiled NPCs"]
    Tick --> AIStep["AI.step(W, n) for Active Members"]
    Tick --> Subsystems["WILD.tick, WILD_RES.tick, EXPED.raidTick, COMBAT.tick"]
    Tick --> HourlyCheck{"W.t % 60 === 0?"}
    HourlyCheck -- Yes --> Hourly["SIM.hourly(W)"]
    HourlyCheck -- No --> DayCheck{"W.day Changed?"}
    Hourly --> DayCheck
    DayCheck -- Yes --> Daily["SIM.dailyUpdate(W) - Midnight Cycle"]
    DayCheck -- No --> Done["Tick Complete (< 3.0 ms)"]
    Daily --> MonthCheck{"calendar.dom === 1?"}
    MonthCheck -- Yes --> Monthly["SIM.monthly(W) - Macro Economy & Drift"]
    MonthCheck -- No --> Done
    Monthly --> Done
```

### 3.1 Per-Tick Engine Loop (`SIM.tick` lines 290–308)
1. **Clock Advance:** `g.STATS.now = W.t; W.t++;`
2. **Midnight Transition:** If `Math.floor(W.t / 1440) !== W.day`, advances `W.day`, syncs `HC.nowDay = W.day`, and triggers `SIM.dailyUpdate(W)`.
3. **NPC Stepping:**
   - Skips `n.dead`.
   - If `n.travel`: updates coordinates, executes `AI.needs(W, n)`, `EXPED.travelStep(W, n)`, and if `n.away && n.exiled`, triggers `SIM.retire(W, n)`.
   - If active (`!n.away`): executes `AI.step(W, n)`.
4. **Ecological & Combat Subsystems:**
   - Executes `WILD.tick(W)` and `WILD_RES.tick(W)`.
   - If sect compound is under attack (`W.foes.length > 0`), executes `EXPED.raidTick(W)`.
   - Executes `WILD.clampCombat(W)` and `COMBAT.tick(W)`.
5. **Hourly Trigger:** If `W.t % 60 === 0`, invokes `SIM.hourly(W)`.

### 3.2 Hourly Phase Operations (`SIM.hourly` lines 325–375)
- **Timed Buff Expiration:** Calls `STATS.purgeExpired(n, W.t)` for all NPCs to clean expired combat/cultivation modifiers.
- **Support & Regen Updates:** Applies `vitalRegen` passive healing (`+5% hpMax`), cools down puppet constructs (`ms.heat`, `ms.charge`), ticks `AI.healTick`, `STATS.recover`, and `CPE.autoUse`.
- **Equipment Wear:** Deducts durability for active combatants (`-0.5 durability`).
- **Building Construction Complete:** Checks `W.map.buildings` for `b.building.until <= W.t` and invokes `SIM.finishBuilding(W, b)`.
- **Station Congestion Tracking:** Records facility demand spikes into `W.sect.facilityDemand`.
- **Armory Allocation:** Every 6 hours (`W.t % 360 === 0`), evaluates stock distribution via `SECT.distributeSectStock(W, { onlyGear: true, maxGifts: 2 })`.

### 3.3 Midnight Daily Cycle (`SIM.dailyUpdate` lines 454–511)
- **Natural Mortality:** Rolls natural life expectancy checks (`age > lifeExpectancy * 0.92`).
- **Graveyard Cleanliness:** Buries dead corpses after 4 days into `W.graveyard`.
- **Succession Emergency Gate:** If `W.sect.masterId` is dead or missing, immediately triggers `SECT.succession(W, 'เจ้าสำนักเดิมถึงแก่อนิจกรรม')`.
- **Roster & Assistant Sync:** Updates sect guards via `SIM.guardRoster(W)` and assigns facility assistants via `SIM.assistants(W)`.
- **Sequential Daily Domain Updates:**
  ```javascript
  SECT.daily(W);                  // Governance, hall orders, applicant aging
  COG.syncOfficeAuthority(W);     // Synchronize officeholder cognitive authorities
  EXPED.daily(W);                 // Caravan arrivals, raid spawns, world events
  EXPLORE.daily(W);               // Pagoda resets, realm node regeneration
  BN.daily(W);                    // Bottleneck tribulation checks
  CPE.daily(W);                   // Contribution point salary & ledger roll
  CONTENT.daily(W);               // Cross-sect diplomatic treaties & envoy timers
  EXT.daily(W);                   // Wandering merchant refresh
  FISHING.daily(W);               // River bait & fishing spot ecology
  ```
- **Specialist & Pet Maintenance:** Moves orphaned beasts to `W.sect.reservePets`, feeds hungry pets (`CULT.feedPet`), repairs puppets, and checks 9-Realm specialization tracks (`CULT.checkTrackGates`).

### 3.4 Monthly Macro Phase (`SIM.monthly` lines 582–624)
- **Policy Drift:** Blends current sect policy toward the target policy (`tp`) by 20% (`policy[k] += (tp[k] - policy[k]) * 0.2`).
- **Salary & Tribute:** Disburses sect salaries via `SECT.paySalaries(W)` and collects regional protection tribute (`150 + 26 * sqrt(fame)`).
- **Facility Upkeep:** Deducts stone maintenance based on member count and building levels, with discount applied from the Treasury Elder's `administration` skill.
- **Grain/Meal Spoilage:** Applies spoilage decay if grain or meal stockpiles exceed storage capacity thresholds.
- **Mortal Awakening:** Rolls cultivation awakening chance for mortal disciples (`rank 0`), granting them starter cultivation paths.

---

## 4. Sect Governance & Identity Engine (`js/sect.js`)

`js/sect.js` (3,988 lines) is the central governing engine for sect identity, offices, applicant appraisal, succession, and facility progression.

### 4.1 14 Foundational Sect Archetypes (`SECT.ARCHETYPES` & `SECT.ARCHETYPE_WEAPON`)
Each archetype defines the cultural, martial, and economic identity of a sect:

| Archetype ID | Name | Primary Path | Starter Subpaths | Starter Weapon | Master Weapon |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `sword` | สำนักกระบี่เมฆา | `SWORD` | `SWORD_GHOST`, `SWORD_BLOOD` | `W:WOOD_SWORD` | `W:CELESTIAL_SWORD` |
| `blade` | สำนักดาบศิลาดำ | `BLADE` | `BLADE_BERSERK`, `BLADE_SHADOW` | `W:IRON_BLADE` | `W:DRAGON_BLADE` |
| `spear` | สำนักทวนมังกรคราม | `SPEAR` | `SPEAR_PIERCE`, `SPEAR_SWEEP` | `W:IRON_SPEAR` | `W:PHOENIX_SPEAR` |
| `fist` | สำนักหมัดแปดทิศ | `FIST` | `FIST_IRON`, `FIST_PALM` | `W:CLOTH_GLOVES` | `W:VAJRA_GLOVES` |
| `alchemy` | สำนักโอสถสวรรค์ | `PILL` | `PILL_HEAL`, `PILL_POISON` | `W:BRONZE_CENSER` | `W:DIVINE_CAULDRON`|
| `bow` | สำนักธนูเก้าตะวัน | `BOW` | `BOW_SNIPER`, `BOW_RAPID` | `W:HUNTING_BOW` | `W:SUN_FALL_BOW` |
| `staff` | สำนักพลองอรหันต์ | `STAFF` | `STAFF_CRUSH`, `STAFF_WHIRL` | `W:WOODEN_STAFF` | `W:BUDDHA_STAFF` |
| `focus` | สำนักเวทย์ดวงดาว | `FOCUS` | `FOCUS_ASTRAL`, `FOCUS_VOID` | `W:SPIRIT_MIRROR` | `W:VOID_ORB` |
| `god` | อารามเทพยุทธ์ | `BODY` | `GOD_FIST`, `GOD_ARMOR` | `W:HEAVY_GAUNTLET`| `W:GOD_SPLITTER` |
| `demon` | พรรคมารโลหิต | `GHOST` | `DEMON_DEVOUR`, `DEMON_CHAOS` | `W:BONE_DAGGER` | `W:BLOOD_SCYTHE` |
| `mech` | นครกลจักรโบราณ | `FORMATION`| `MECH_PUPPET`, `MECH_ARRAY` | `W:WRENCH_STAFF` | `W:TITAN_CONTROLLER`|
| `karma` | พุทธาวาสวิปัสสนา | `SCHOLAR` | `KARMA_BOND`, `KARMA_REINCARN` | `W:PRAYER_BEADS` | `W:KARMA_BELL` |
| `beast` | หุบเขาสัตว์วิญญาณ | `BEAST` | `BEAST_PACK`, `BEAST_SYMBIOSIS` | `W:BEAST_WHIP` | `W:SOVEREIGN_WHIP` |
| `sage` | สำนักมหาปราชญ์ | `SCHOLAR` | `SAGE_CALLIGRAPHY`, `SAGE_CHESS`| `W:SCHOLAR_BRUSH` | `W:DAO_CHRONICLE` |

### 4.2 7 Sect Ranks & 16 Assignable Offices
- **7 Ranks (`SECT.RANKS`):**
  - `0`: ผู้ฝึกหัด (Mortal Trainee / Novice)
  - `1`: ศิษย์สายนอก (Outer Disciple)
  - `2`: ศิษย์สายใน (Inner Disciple)
  - `3`: ศิษย์แกนกลาง (Core Disciple)
  - `4`: ผู้อาวุโส (Elder)
  - `5`: รองเจ้าสำนัก (Deputy Master)
  - `6`: เจ้าสำนัก (Sect Master)
- **16 Assignable Posts (`SECT.POSTS`):**
  `martial` (ฝึกยุทธ์), `alchemy` (ปรุงโอสถ), `forge` (หลอมศาสตรา), `scripture` (หอคัมภีร์), `discipline` (คุมกฎ), `treasury` (คลังสำนัก), `mission` (ภารกิจ), `guard` (พิทักษ์), `registry` (ทะเบียนศิษย์), `healer` (หอโอสถ), `disciples` (ศิษย์สืบทอด), `commander` (แม่ทัพยุทธ์, ต้องการสมาชิก >= 12), `provision` (เสบียง), `herbal` (สวนสมุนไพร), `wildwarden` (พิทักษ์ป่า), `steward` (ผู้ดูแลทั่วไป, ต้องการสมาชิก >= 16).

### 4.3 Identity-Driven Governance Policy Engine (`SECT.styleOf`, `SECT.targetPolicy`)
Governance policy is not a static configuration file; it is synthesized continuously from the psychological traits (`HC`) of leadership:
- **Weighting Matrix:**
  - **Sect Master:** **78%** influence
  - **Deputy Master:** **14%** influence
  - **Council Elders:** **8%** distributed influence
- **7 Policy Axes:**
  1. `openness`: Derived from `socializing`, `empathy`, inverse `caution`.
  2. `strictness`: Derived from `discipline`, `integrity`, `caution`.
  3. `meritocracy`: Derived from `rationality`, `fairness`, `martialPeak`.
  4. `expansion`: Derived from `ambition`, `courage`, `powerStatus`.
  5. `generosity`: Derived from `empathy`, `hospitality`, inverse `materialism`.
  6. `secrecy`: Derived from `caution`, `intrigue`, `solitude`.
  7. `risk`: Derived from `courage`, `gambling`, inverse `caution`.
- **5 Focus Weights:** `martial`, `craft`, `scholar`, `commerce`, `faith`.

---

## 5. Strict CA/PA Privacy Boundary & Applicant Appraisal

JianghuSect Evolution enforces a strict architectural boundary between **Current Ability (CA)** and **Potential Ability (PA)** to prevent omniscient AI or UI cheats.

```mermaid
classDiagram
    class Applicant {
        +String id
        +Physiology observablePhysique
        +Skills observableSkills
        -Aptitudes hiddenAptitudes
        -Affinities hiddenAffinities
        -Destiny hiddenDestiny
    }
    class Reviewer {
        +readPeople
        +judgement
        +administration
    }
    class ObservableCapability {
        +caScore
        +roleFit
        +zeroLeakage()
    }
    class ExaminedReport {
        +appraisedScore
        +perceivedTier
        +gaussianNoise
    }
    Applicant --> ObservableCapability : Evaluated Strictly Via Physiology/Skills
    Reviewer --> ExaminedReport : Injects Noise Based on Stats
    ObservableCapability --> ExaminedReport : Blended
```

### 5.1 5 Talent Tiers (`SECT.TALENT_TIERS`) & Fame Weighting
- `COMMON` (สามัญ, Tier 1): Aptitudes ~35–50
- `STEADY` (มั่นคง, Tier 2): Aptitudes ~50–65
- `GIFTED` (มีพรสวรรค์, Tier 3): Aptitudes ~65–78
- `PRODIGY` (อัจฉริยะ, Tier 4): Aptitudes ~78–90
- `HEAVENLY_CHILD` (ลูกรักสวรรค์, Tier 5): Aptitudes ~90–100
- **Weighting Formula (`SECT.applicantTierWeights`):** Higher sect fame exponentially increases high-tier rolls while compressing common applicants.

### 5.2 Strict CA/PA Privacy Invariant (`SECT.observableCapability`)
`SECT.observableCapability(W, n)` computes Current Ability strictly from observable exterior attributes:
- **Allowed Attributes:** Observable physical strength, endurance, agility, exterior demeanor, and active skill proficiencies.
- **Strictly Forbidden Attributes (Never Read):**
  - `n.h.aptitudes.*` (Cultivation, comprehension, combat talent)
  - `n.h.affinities.*` (Elemental and weapon affinities)
  - `n.h.life.destiny`, `n.h.intellect.*`, `n.ext.applicant`
- **Zero-Leakage Assurance:** Tests in `test/run_all.js` inspect runtime memory access during appraisal to guarantee no private PA attributes are accessed.

### 5.3 Appraisal Noise Injection (`SECT.examineApplicant`)
The sect appraises applicants through an appointed officer (Priority: `registry` Elder → `master` → `deputy`):
```javascript
const eye = evaluator ? (HC.eff(evaluator, 'intellect.readPeople') * 0.55 + HC.eff(evaluator, 'intellect.judgement') * 0.45) : 40;
const noiseStdDev = Math.max(1.5, (100 - eye) / 10);
const perceivedScore = trueScore + W.rng.gauss(0, noiseStdDev);
```
An evaluator with low perception introduces severe appraisal noise, potentially mistaking a common applicant for a prodigy or rejecting a heavenly genius.

---

## 6. Grand Martial Assembly & Peak Trial Arena (`SECT.assembly`)

Every 90–120 days, the sect convenes the Grand Martial Assembly to evaluate disciples, award Contribution Points (CP), and resolve external disputes.

### 6.1 3 Division Brackets (`SECT.ASSEMBLY_BRACKETS`)
1. **JUNIOR (`รุ่นเยาว์·หลอมปราณ`):** Stages T1–T2. Rewards: 50 CP, 60 stones, T3 tailored gear/recipe, +2 sect fame.
2. **CORE (`รุ่นแกนหลัก·แก่นทองคำ`):** Stages T3–T4. Rewards: 100 CP, 120 stones, T3–T5 tailored gear/recipe, +4 sect fame.
3. **ELDER_PEAK (`รุ่นผู้อาวุโส·ยอดเขายุทธ์`):** Stages T5–T7. Rewards: 180 CP, 220 stones, T5–T6 tailored gear/recipe, +6 sect fame.

### 6.2 Bout Simulation & Tactical Interaction (`SECT.simulateAssemblyBout`)
Bouts simulate dynamic combat math without full tick-by-tick simulation overhead:
```javascript
const tacA = COMBAT.resolveWeaponTactics(a, b, { dist: 2.2 });
const resA = MARTIAL.evaluateResonanceSet(a);
const scoreA = CULT.power(a) * (tacA.dmgMult || 1) * (1 + resA.pieces * 0.04) * (0.88 + W.rng.next() * 0.24);
```
Tactical weapon advantages (e.g. Spear keeping Fist at bay, Blade bypassing light armor) and 18-set resonance pieces provide significant modifiers.

### 6.3 Tailored Equipment Rewards & Allied Guests
- **Tailored Gear Minting (`SECT.tailoredAssemblyReward`):** Champions are awarded bespoke gear and matched crafting recipes suited to their primary weapon and path.
- **Allied Sect Prodigies:** Allied sects (`treaty: 'ALLIANCE'` or `attitude >= 40`) dispatch guest prodigies to compete in the tournament.
- **Rival Envoy Challenges (`SECT.resolveRivalEnvoyChallenge`):** Defeating hostile sect challenge envoys yields massive CP, prestige, and forces treaty negotiations.

---

## 7. Ancestral Shrine, Legacy Tablets & Blessings

When prominent elders or leaders perish, their memory is immortalized in the Ancestral Shrine (`SECT.inscribeLegacyTablet`), granting enduring spiritual blessings to subsequent generations.

### 7.1 Inscription Qualification (`SECT.inscribeLegacyTablet`)
An NPC qualifies for tablet inscription upon death if:
- Rank is `4` (Elder), `5` (Deputy), or `6` (Master).
- Cultivation stage is `T4` (Core Formation) or higher.
- Inscription captures their signature weapon, highest technique, path, and subpath.

### 7.2 Tablet Bonuses & Ancestral Prayer (`SECT.prayAtAncestralShrine`)
- **Breakthrough Bonus:** `+0.04` to `+0.12` breakthrough success rate.
- **Comprehension Bonus:** `+0.08` to `+0.22` manual study speed.
- **Path Synergy Multipliers:**
  - Exact Subpath Match: **1.35x** multiplier + complete tribulation injury shield.
  - Same Major Path: **1.0x** multiplier + tribulation injury shield.
  - Different Path: **0.65x** multiplier (general wisdom).
- **Psychological Cleansing:** Reduces Heart Demon (`-8` to `-12`) and removes stress (`-8`).

---

## 8. Facility Demand, Housing Caps & Autonomous Directives

### 8.1 Authoritative Housing Bed Capacities
Housing capacity is strictly defined by dedicated dormitory facilities:
```javascript
SECT.housingCapacity = W => {
  const outer = W.map.byId.dorm_outer?.level || 1;
  const inner = W.map.byId.dorm_inner?.level || 0;
  const core  = W.map.byId.dorm_core?.level || 0;
  // Outer (max L5): 16, 24, 32, 44, 56 beds
  // Inner (max L4):  0,  8, 16, 28 beds
  // Core  (max L3):  0,  0,  8, 16 beds
  // Absolute maximum capacity = 56 + 28 + 16 = 100 members
};
```
Non-housing facilities (farms, mines, libraries) **never** generate bed stations.

### 8.2 Autonomous Stock Allocation (`SECT.distributeSectStock`)
The sect autonomously balances its treasury through directives:
1. **Safety Reserves:** 14 days of grain, 20 emergency meals, and 4 units of essential recovery medicines (`P:BASIC_HP`, `P:BASIC_WOUND`).
2. **Stock Evaluation Matrix (`SECT.evaluateStockDistribution`):**
   - **Reserve:** Preserved for emergency crises and scheduled sect raids.
   - **Sale:** Exported via external caravans and merchant accords.
   - **Gift:** Distributed to deserving disciples based on merit, combat post, and elemental resonance.
3. **Anti-Exploit Safeguard:** Player-spawned items are tagged (`playerSpawned = true`) and yield **0 CP** when donated to prevent infinite currency exploits.

---

## 9. Support Doctrine & Specialist Facilities (v2.0.9 Engine)

### 9.1 Support Doctrine (`SECT.ensureSupportDoctrine`, `SECT.setSupportDoctrine`)
Configures autonomous NPC healer and support behavior:
- **Triage Priorities:** `BALANCED`, `ELDER_FIRST`, `SEVEREST_FIRST`, `VANGUARD_FIRST`.
- **Health Thresholds:** Trigger emergency healing when ally HP drops below `minHpThreshold` (default 65%).
- **Reserve Qi Protection:** Support units reserve `reserveQiPercent` (20%) to prevent total qi exhaustion.

### 9.2 Specialist Facilities (`SECT.ensureSpecialistFacilities`)
- `mech_workshop`: Speeds up construct readiness recovery and maintains sect guardian puppets.
- `beast_menagerie`: Enhances spirit beast breeding success rates and manages nutrition.
- `harmonic_pavilion`: Boosts support healing efficiency and buff duration by `+15%` per level.

---

## 10. Edit Hub Architecture (`SECT.EDITOR`)

The Edit Hub is an administrative debugging and testing engine embedded in `SECT.EDITOR`:
- `EDITOR.memberEditState(W, npcId)`: Validates whether a character can be edited (guards against dead or exiled states).
- `EDITOR.spawnItem(W, opts)`: Spawns provisions, materials, pills, equipment, technique manuals, and subpath crystals directly into sect warehouses or member bags.
- `EDITOR.applyDiplomacyAction(W, opts)`: Modifies faction relations, signs treaties, and clears diplomatic cooldowns.
- `EDITOR.applySanctumAction(W, opts)`: Simulates instant sanctum runs, sets floor clears, and dispenses refinement catalysts.
- `EDITOR.applyPetAction(W, opts)`: Manages beast pets, awakens sovereign bloodlines, and mutates puppet/karma states.

---

## 11. Single-File Build Pipeline (`tools/build_single.js`)

To guarantee standalone distribution without server dependencies, JianghuSect Evolution compiles into a single monolithic HTML bundle:

```bash
cd /data/data/com.termux/files/home/jhevo-work/GAME_SOURCE
node tools/build_single.js
```

### 11.1 Build Mechanics
1. Reads `index.html`.
2. Inlines all external CSS stylesheets (`css/style.css`).
3. Reads all 40 JavaScript files in exact sequence and inlines them inside `<script>` blocks.
4. Verifies syntax and outputs `GAME_SOURCE/JianghuSect_single.html`.
5. Ensures zero missing asset references or unclosed tags.

---

## 12. Verification & Acceptance Checklist

Whenever modifying system architecture, macro lifecycle, or sect governance:
- [ ] **40-Script Load Invariant:** Ensure script tag count in `index.html` and `test/load.js` remains exactly 40.
- [ ] **Failsafe Fingerprint:** Ensure `GAME_SOURCE/js/human_core.js` is unmodified (`HC.FINGERPRINT === '155:2f9c9dd7'`).
- [ ] **CA/PA Privacy:** Verify that `SECT.observableCapability` never reads hidden potential traits.
- [ ] **Performance Budget:** Ensure per-tick time remains `< 3.0 ms` for 80 NPCs.
- [ ] **Data Schema Validation:** Run `node tools/validate_data_schema.js` and verify **0 Errors**.
- [ ] **Full Test Suite:** Run `node test/run_all.js` and ensure all 83 test suites pass.
- [ ] **Single-File Compilation:** Run `node tools/build_single.js` and ensure clean generation.

## Patch v2.0.18 Additions: World Map Topology & Hegemony Loop
- Integrated `EXPED.ensureWorldTopology(W)`, `EXPED.tickHegemony(W)`, and `EXPED.harvestResourceNodes(W)` into `EXPED.daily(W)` and `CONTENT.ensure(W)` while maintaining `1.351 ms/tick` for 80 active NPCs.
- **Save Policy Update:** Backwards compatibility with older save versions is not required (`"ไม่จำเป็นต้องทำให้เซฟเก่าเล่นต่อได้"`), allowing clean architectural evolution.


## v3.1.0 Governance, Peaks & Dungeon Architecture
- `SECT.DIRECTORATES` (6 Directorates) and `SECT.POSTS` / `SECT.POST_CATALOG` (25 assignable offices including `vanguard`, `warden`, `marketmaster`, plus `SECT.PLANNED_POSTS` linked via `SECT.resolveOfficeId` and unlocked via `SECT.unlockAllOffices(W)`).
- `SECT.runOfficerJurisdictionSingle(W, post, officer, opts)` and `SECT.runOfficerJurisdictions(W, opts)` execute real autonomous office decisions and record to `W.sect.jurisdictionLog`.
- `SECT.PEAKS` manages the 8 canonical Peaks (`PEAK_IDS`), interactive leader appointment/removal, disciple transfers, 4 allocation policies (`MERITOCRATIC`, `REALM_PRIORITY`, `EGALITARIAN`, `NEPOTISTIC_INNER_CIRCLE`), Qi Array (+14%), joint exchanges, and inter-peak tournaments.
- `W.sect.dungeon` (`SECT.capturePrisoner`, `SECT.handleDungeonPrisoner` / `SECT.executePrisonerAction`) handles `RANSOM`, `INTERROGATE`, and `RECRUIT_DEFECTOR`.

---

## Patch v3.2.0 – v4.0.0 Architecture Additions (`SIM.PATCH_VERSION = '2.1.0'`)
- **Version & Save Schema (`js/sim.js`):**
  - `SIM.PATCH_VERSION = '2.1.0'`
  - `SIM.SAVE_SCHEMA_VERSION = '4.0.0-living-frontier-charter'`
  - `SIM.SUPPORTED_PATCHES = ['3.1.1', '3.2.0', '3.3.0', '3.4.0', '3.5.0', '3.6.0', '4.0.0']`
- **Pillar 1 — Living Frontier & Outpost Logistics (`SECT.OUTPOSTS_LOGISTICS` in `js/sect.js`):**
  - 4 Camp Types (`CAMP_REST` +30% Stamina, `CAMP_GUARD` -40% regional caravan ambush risk, `CAMP_SUPPLY` emergency ration draw, `CAMP_MEDIC` severe injury cure & +35% HP restore).
  - `establishOutpost(W, nodeId, campType, garrisonNpcIds, opts)`, `dispatchSupplyConvoy(W, outpostNodeId, grainQty, pillQty, opts)` (strictly Closed-Loop from `W.sect.stock`), and `tickOutpostLogistics(W)` wired into `SECT.daily(W)`.
- **Pillar 3 — Sect Charter & Long-Term Doctrine (`SECT.CHARTER_DOCTRINE` in `js/sect.js`):**
  - Stored in `W.sect.charter` (`activeDoctrine`, `adoptedDay`, `loyaltyBonus`, `perks`, `history`).
  - 5 Doctrines: `CHARTER_MERITOCRACY` (default), `CHARTER_BROTHERHOOD_SANCTUARY`, `CHARTER_SCHOLASTIC_DAO`, `CHARTER_OPEN_MERCHANT`, `CHARTER_RECLUSIVE_HERMIT`.
  - `enactSectCharter(W, charterId)` deducts 50 Spirit Stones via Closed-Loop ceremony and updates disciple loyalty & cultivation rate (`getCharterPerks(W)`).
- **Pillar 4 — 6-Officer Strategic Council Assembly (`SECT.STRATEGIC_COUNCIL` in `js/sect.js`):**
  - `conveneCouncil(W)` aggregates readiness and threat assessments from 6 Grand Officers (`spymaster`, `envoy`, `quartermaster`, `vanguard`, `warden`, `marketmaster`) and presents 3 strategic choices (`FORTIFY_LOGISTICS`, `DIPLOMATIC_OFFENSIVE`, `GRAND_WAR_DRILL`).
  - `resolveCouncilAgenda(W, choiceId)` executes the chosen directive and records to `W.chronicle`.

---

## Patch v4.1.0 Additions: 8-Peak Physical Sanctuary Layout & Conditional Awakening (`js/world_map.js`, `js/sect.js`, `js/ai.js`)
- `SIM.PATCH_VERSION = '2.1.0'`, `SIM.SAVE_SCHEMA_VERSION = '4.1.0-sect-expansion-peaks-sanctuary'`.
- **8-Peak Physical Layout (`MAP.BTYPES`, `MAP.PEAK_LAYOUTS`, `MAP.STN`)**: Adds 8 physical Peak Sanctuary buildings (`peak_sword`, `peak_body`, `peak_chaos`, `peak_alchemy`, `peak_magic`, `peak_array`, `peak_scholar`, `peak_beast`) around the sect perimeter, each with 18 sub-stations (`6 bed, 2 pantry, 6 practice, 4 meditate`) and connected by `1.8x` speed Spirit Roads (`MAP.SPEED[T.ROAD] = 1.8`, `MAP.SPEED[T.PLAZA] = 1.8`).
- **Conditional Peak Awakening (`MAP.isPeakBuildingActive`, `MAP.syncPeakSanctuaries`)**: Unfounded peaks (`founded === false`) block station usage in `AI.freeStation` and render under primordial mist (`Render.drawPeakMist`). Founding a peak via `SECT.PEAKS.foundPeak` immediately activates all 18 stations on the map.


## JianghuSect 2 v2.0.0 Note (The 27 Grand Dao Epoch)
- **Patch / Schema**: `SIM.PATCH_VERSION = '2.1.0'`, `SIM.SAVE_SCHEMA_VERSION = '2.1.0-grand-dao-debates-apex-trials'`
- **Scale**: 27 Major Cultivation Paths (`3^3`), 222 Subpaths, `CULT.MORTAL_INITIATION`, `SECT.PATH_LIBRARY` (1 starter path + 27 Manuals + 27 Crystals), 6 new weapon classes (`ROSARY`, `CLAW`, `NEEDLE`, `FAN`, `ASTROLABE`, `ABACUS`), 15 new Composable Triggers & Actions, 137/137 test suites passing.


## หมายเหตุเฉพาะการแก้บั๊ก JS2-v2.4.0

ผลหลังศึกสำนักใช้ได้ผ่านเส้นทางชัยชนะ, ของขวัญคนพเนจรและรางวัลประตูธาตุจำกัดซ้ำ, duel คนเดิมจำกัดรายวัน คำขอหมดเวลาไม่รับรางวัล และกองรักษาจุดทรัพยากรรับเฉพาะพื้นที่ผู้เล่น/สมาชิกที่ไม่ถูกส่งออก เมื่อเสียพื้นที่จะคืนข้อมูลกองเป็นของฝ่ายใหม่ เก็บ receipt ที่จำเป็นในข้อมูลเซฟปกติ ดู [`docs/audits/JS2_V2_4_0_FIX_TRACKER_TH.md`](../../../docs/audits/JS2_V2_4_0_FIX_TRACKER_TH.md) สำหรับสถานะและข้อจำกัดที่ยังเหลือ

## Patch JS2-v2.5.0 Version & Architecture Update
- `SIM.PATCH_VERSION = '2.5.0'`, `SIM.SAVE_SCHEMA_VERSION = '2.4.0-tactical-composable-grand-dao'` (`'2.5.0'` added to `SIM.SUPPORTED_PATCHES` in `js/sim.js`).
- Preserves `GAME_SOURCE/js/human_core.js` byte-identical (`HC.FINGERPRINT === '155:2f9c9dd7'`, SHA-256 `a0d393284fb4b136848e5b80e12f3edd2c4f9437c419c793c2a7e75d881c0542`) and the exact 40 `<script>` tag load order.


## Patch JS2-v2.6.0 Additions: Living Chronicle, Periodic Digest, Storyline Threads & News Intake Engine (`js/sim.js`, `js/expedition.js`, `js/combat.js`)
- **Version & Save Schema**: `SIM.PATCH_VERSION = '2.6.0'`, `SIM.SAVE_SCHEMA_VERSION = '2.6.0-living-chronicle-and-reporting'` (backwards-compatible with `2.4.0` and `2.5.0` schemas).
- **Enhanced Person Snapshot (`SIM.snapshotPerson(W, n, statusOverride)`)**: Automatically tracks `formerNames` whenever an NPC's full name changes, and records `pathNameTh`, `subNameTh`, `stageNameTh`, `topWhyTh` (`n.why[0][0]`), `goalId`, `goalTitleTh`, `aspirationId`, `merit`, `joinDay`, `deathDay`, `deathWhy`, and `snapshotDay`/`snapshotTick`.
- **12 Chronicle Reporting Formats (`EXPED.CHRONICLE_REPORT_FORMATS`) & Pure Presenter (`EXPED.presentChronicleEntry(W, rec)`)**:
  - Added 12th format `PERIODIC_SECT_DIGEST` (`📊 สมุดสรุปสถานการณ์สำนักประจำรอบ`).
  - `EXPED.buildFactSnapshot(W, entry, actorSnapshots, fmtId)` captures immutable event-time facts and epistemic status (`'VERIFIED'`, `'OBSERVED'`, `'RUMOR'`).
  - `EXPED.presentChronicleEntry(W, rec)` is 100% read-only (uses deterministic FNV-1a `EXPED.chronicleHash`, zero `W.rng` calls, zero state mutation).
- **Periodic Sect Digest (`EXPED.computePeriodDigest(W, { windowDays })` & `EXPED.recordPeriodicDigest(W, opts)`)**:
  - Separates closing stock (`closingStones`, `closingMeals`, `closingGrain`, `foodDaysRemaining` vs `cashReserveFloor`), external stone cashflow (`stoneIncome`, `stoneExpense`, `netStones` from `W.sect.ledger` in `(fromTick, toTick]`), internal sect transfers (`internalGiftsCount`, `internalCpPurchasesCount`, `internalDonationsCount`), and player Edit Hub interventions (`playerInterventionCount`) without double-counting.
- **Milestone-Protected Retention**:
  - `EXPED.trimChroniclesWithMilestoneProtection(W, 200, 60)` trims `ROUTINE` entries first when `W.world.chronicles` exceeds 200, protecting up to 60 milestones and incrementing `W.world.chronicleTrimmedCount`.
  - `SIM.log` protects up to 160 milestones when trimming `W.sect.sectChronicle` at 600 entries and increments `W.sect.sectChronicleTrimmedCount`.

## JS2-v2.5.0 Weapon Motion & Target-Aware VFX refinement (carried on v2.6.0 main)
- Existing `a.castFx` remains the short combat-event boundary from `COMBAT.attack` to `Render.updateCastEffects`. Snapshot `weaponType`, `tier`, `arch`, and `originX/Y` at cast time; don't re-resolve equipment or techniques in the render loop.
- Add bounded `targetPoints` from combat resolution for self, single/area heals, team support, mixed command attacks, and area strikes. Team tint comes from `COMBAT.isAlly`, not the broad NPC `foe` property. Command keeps the enemy as its primary visual while marking friendly recipients.
- Persistent passive/mantra/path/equipment auras remain attached to their owner. Active positive combat statuses may add a small owner-bound aura while `until > W.t`; read snapshots directly and never call mutating status purge helpers from rendering.
- No new timers, save schema, or gameplay state. Run `test/skill_visual_events.js`, `test/weapon_motion_vfx_suite.js`, and `test/weapon_motion_vfx_browser.js` for target routing and read-only visual behavior.

## JS2-v2.6.0 Skill VFX catalog extension
- Signature catalog grew from 30 to 45 Canvas shapes and from 241 to 256 direct technique mappings. New techniques are assigned only after auditing their current resolver result and any object-based child move definitions.
- Combat remains the source of truth for cast anchor, team and actual recipients. The renderer reads the existing event; the faith network draws links from the actual recipient snapshot (bounded at eight units). No combat state or save schema was added.
- See [`docs/audits/SKILL_VFX_ASSIGNMENT_REGISTRY.md`](../../../docs/audits/SKILL_VFX_ASSIGNMENT_REGISTRY.md) for exact mappings and do-not-repeat motifs, and `test/skill_vfx_expansion_suite.js` plus `test/signature_vfx_catalog_browser_audit.js` for producer-to-render checks.


## Legendary Apex presentation boundary (JS2-v2.6.0 refinement)
- All new scene catalogs and four-phase painters stay in `js/render.js`; no additional script/module order or save-schema change. Existing `castFx` / `lastWeaponProc` remain authoritative gameplay boundaries. Renderer-only entries add `ownerId` to prevent simultaneous full cast/relic scenes from stacking on one actor; it is not written back to the actor or save.
- `Render.legendarySceneLife` selects presentation duration from the 47 skill / 27 relic profiles. `drawLegacyLegendaryArtVfx` preserves old inner motifs; new scene/target conduction does not run simulation actions.
- The shared cap is two full scenes (one Low) across all Legendary event types within the existing 24-event queue. Exact catalog, future T4–T7 reservations and tests: `docs/audits/LEGENDARY_APEX_VISUAL_REGISTRY.md`.


## Ordinary T7 visuals (completed layer) (JS2-v2.6.0 refinement)
- `SK.T7_VFX_CATALOG` explicitly reviews all 71 runtime ordinary T7 records; `resolveT7Vfx` requires exact T7 and excludes named-Legendary/named-fx overrides. Prior Signature table/resolver stays unchanged. Some ordinary T7 records have Legendary grade / `LEG_` prefixes but `legendary:false`; do not classify by name alone.
- Renderer-only `t7Vfx` routes `drawT7SkillVfx`: 50–56 px / 1,450 ms, 24 thematic frames retaining old per-move cores, local role-aware release, no Legendary apparition/bloom. Three full forms normally / one Low or with a full Legendary scene; one per owner, compact cores for the rest; total queue 24.
- `drawT7EquipmentAura` / `drawT7EquipmentGlyph`: 85 existing T7 templates, 25 current types; actual equipped usable non-Legendary records only, at most three small owner accents. Broken T7 does not regain the old generic ring. No proc metadata is fabricated.
- `NONLEGENDARY_VFX_BUDGET[7].planned` is now false. T4–T5 remain planned; selected T6 is now implemented. Tests: `t7_skill_vfx_suite` (71 authored producers, 157 child metadata routes, targets/purity/caps/usability) and `t7_skill_vfx_browser` (all modes, 25 types, stress).
- Exact IDs/roles/prior cores: `docs/audits/T7_VISUAL_ASSIGNMENT_REGISTRY.md`. Next requested visual patch: `docs/handovers/NEXT_T5_VISUAL_PATCH.md`; do not restart T7/Legendary or the completed chronicle feature.

T7 rapid-repeat presentation: `updateCastEffects` coalesces the same ordinary T7/kind through 55% of its current lifetime so fast simulation reaches release. The held record keeps its original actual target snapshot; different techniques, explicit overrides and Legendary casts bypass the hold. Only renderer timing is affected. Covered by `t7_skill_vfx_suite`.


## T6 shared group visuals / next requested frontier T5 (JS2-v2.6.0)
- `SK.T6_VFX_FAMILIES`: 50 different silhouette painters / family palette and motion. `TECH_TO_T6_VFX`: 114 real active profiles / 207 authored child routes; `PASSIVE_TO_T6_VFX`: 8 eligible existing passives. **169 ordinary T6 records = 132 active + 31 passive + 6 mantras**; attack-sounding mantras with null `SK.profile` are not active routes. Remaining 18 active / 23 passive / 6 mantras keep earlier rendering.
- `resolveT6Vfx` requires exact selected ordinary T6 and respects explicit child/event/named-fx and named-Legendary precedence. Normal selected T6 uses group art instead of stacking its old automatic Signature core; old catalog 45 / direct maps 256 / every parent-child resolver result are unchanged. Same family/role/angle/phase means identical art: no per-ID seed, recolour or ornament count.
- `drawT6FamilyGlyph` / `drawT6SkillVfx`: 42–47 px / 1,250 ms; compact 18; passive 9.5. One themed form + restrained family motion/release, no Legendary apparition/bloom. Three full T6 normally, one Low or with full T7/Legendary; higher-tier owner gets no second full T6, others compact; overall queue 24. Reduced Motion freezes decoration. Same-tech/kind repeats coalesce through 55% renderer life, preserving the original factual snapshot; different IDs/overrides/Legendary bypass.
- Persistent renderer chooses ONE eligible passive across Common/T3/T6, using existing loadout/unequipped/path/subpath/realm and actual weapon AND armor conditions. Actual caster/friendly/enemy cast anchors, area recipients and status expiry remain authoritative. No new status or buff from a name.
- `drawOrdinaryHighTierEquipmentAura` serves T6/T7; tier-specific wrappers still isolate eligibility. T6 reuses type glyphs at 0.82 finish; 117 ordinary templates, 27 raw tags → 25 semantic types (`LIGHT_ARMOR→LIGHT`, `HEAVY_ARMOR→HEAVY`). Up to three actual equipped usable accents, no broken-item glow fallback, star motes retained, no fabricated procs/victims. A lower ordinary T6 item does not replace a higher named-Legendary halo. Existing T7 85 templates/25 types remains.
- T4 24–29 px / 850 ms and T5 32–39 / 1,050 remain planned; selected T6 and T7 are implemented (`planned:false`). Future lower tiers should share broader mechanic/element/action groups more; no forced reduction of existing lower-tier special catalogs.
- Tests: `t6_group_vfx_suite` (114 real producers / 207 child metadata routes, actual attack-role examples, eligibility/modes/purity/caps/gear); `t6_group_vfx_browser` (50 distinct shapes in all modes, 256 same-group pixel comparisons, 25 gear glyphs, mixed 24-cast Canvas stress). Final combined regression: **161/162 PASS, 0 FAIL, 1 previously recorded `startup_ui` overlay TIMEOUT**; syntax **239 JavaScript files**. New and existing visual suites pass. Mobile 80-NPC stress: **1.417 ms/tick** in the final combined run; unchanged isolated retry **1.818 ms/tick**. Development Canvas timings do not certify physical Android performance.
- Exact assignments, selected exclusions, old artwork and previews: `docs/audits/T6_GROUP_VFX_REGISTRY.md`. Handoff `docs/handovers/NEXT_T5_VISUAL_PATCH.md` starts only when user requests T5; do not repeat T6/T7/Legendary or the completed chronicle feature. Core/save schema and 40-script order unchanged.


## Observer autonomy / reachability audit (2026-11-15)

NPC opportunities อยู่ใน AI → SECT.AUTONOMY → native effects; เหตุการณ์ศัตรูล้อม/วิกฤตธรรมชาติใช้ EXPED.considerNaturalEndgameEvents ใน tick โลกทุก 10 วัน ไม่สร้างผลจาก UI หรือยืนยันผลสำเร็จ มีทางเลือกรอและตรวจวันซ้ำ ห้ามถือ wrapper API อย่างเดียวว่าเชื่อม simulation แล้ว

รายละเอียด: `after debug/04_OBSERVER_AUTONOMY_AND_REACHABILITY.md`; รายชื่อสิทธิ์: `docs/audits/OBSERVER_ACTION_POLICY.json`.

## Living Hunt phase 1

ใช้โมดูล wildlife/combat/cognition เดิมและลำดับ40scriptsเดิม ไม่ขยายแผนที่จริงในระยะแรก; เพดานอสูร60 เป้าหมาย48. ข้อมูลlandInfluenceและfight.ctx.landContributionsเป็นสถานะธรรมดา; loreพื้นที่บันทึกผ่านWILD.initครั้งเดียว. ดูแผนผังและข้อจำกัดใน PATCH_REPORTS/LIVING_HUNT_PHASE1.md; ไม่รับรองความเข้ากันได้เซฟเก่าหรือผลมือถือ.

## Living Jianghu Epithets, Sobriquets, Daoist Styles, Group Titles, Moveable Crowns & Posthumous Honorifics (`JS2-v2.6.0`)
- **Catalog & Review**: `JD.EPITHETS` (`274` active runtime epithets: `258` from PDF volumes `EPITHET_01A/01B/01C` + `16` codebase-grounded originals `EPI_NEW_261..276`). Full 260-row review in `docs/handovers/EPITHET_260_REVIEW_TRACKER.csv` (`0 UNREVIEWED`, `0 BLOCKED`), with audits in `docs/audits/EPITHET_FEATURE_OPPORTUNITIES.md` and `docs/audits/EPITHET_ACTIVE_REGISTRY.md`.
- **Runtime Engine (`CULT.EPITHETS` / `SECT.EPITHETS` / `g.EPITHETS`)**: Evidence-backed `npc.deedStats` with `receiptId` idempotency and 6 anti-farming guards, witness vs. unwitnessed wilderness deeds (`verifySecretDeedWithProof`), rumor propagation (`originEventId` deduplication), multi-perspective `evaluatePerception`, shame stigma & autonomous `wash_shame_epithet` redemption, 12 One-in-the-World Moveable Crowns (`W.world.uniqueCrowns`), Collective Group Epithets (`W.sect.collectiveEpithets`), Daoist/Dharma names (`bestowDaoName`), lineage seniority (`refreshLineageTitles`), posthumous ancestral tablets (`bestowPosthumousTitle`), and Chronicle snapshot immutability (`epithetAtEventTh`). Verified by `node GAME_SOURCE/test/epithets_living_jianghu_suite.js`.

## 260c repair — JS2-v2.6.0 (2026-11-17)

40 script order ใน index.html/test/load.js ต้องคงเดิม ET.installSystemHooks ผูกเมื่อสร้างโลก/NPC หลังโหลดโมดูลครบ คง pure human core และติดตั้ง wrapper ครั้งเดียว ก่อนแก้ producer อ่านลายเซ็น/return value จริง นาฬิกาแยก workSteps จาก W.t/timePhase; ดู TIME_AND_MAP_CONTRACT.md

หลักฐานและขอบเขตตรวจ: `PATCH_REPORTS/260C_REPAIR_JS2_V2_6_0.md`; ทะเบียน: `docs/audits/LIFE_TRAITS_ACTIVE_REGISTRY.md` อ่านผลตรวจจริง ไม่ตีความจำนวนรายการว่าเล่นทุกสถานการณ์ครบแล้ว

### Carbon Compendia Update (`JS2-v2.6.0-CARBON-COMPENDIA` — 31 PDFs `881fecf` & `6670b49`)
- **Gen-7 Lineage & Regalia**: `W.sect.masterGeneration = 7`, 6 Gen 1–6 plaques (`W.sect.patriarchPreHistory`, 0 Upper-World spoilers), `SECT.PATRIARCH_REGALIA` (`REGALIA_ORIGIN_FORMLESS_STONE`, Stages 0–5, 24 polymorphic forms, 11 elements + dual-element Stage 4+, 12 `IMP_*` imprints, 10 `KW_SOV_*` keywords), and Valley Spirit-Beast Qi Crucible (`WILD.awardSpiritBeastCrucible` + non-lethal capture parity).
- **Transcendent Pantheon & Wildcards**: `ARM_TRANSCENDENT_LOOM_OF_SCARS`, `ACC_TRANSCENDENT_OUROBOROS_SUNDIAL`, `WPN_TRANSCENDENT_MYRIAD_ARSENAL_COFFIN`, `SECT.evaluateTranscendentPantheonResonance` (`0.75×` soft-cap past `+55%`), 10 Alchemy-only wildcards (`MAT_TR_ALC_01..10`, `P:<pillId>@TR:<matId>`, `npc.ext.transcendentElixirMarks`), 3 Pure Elixirs (`PILL_TR_PURE_01..03`), 10 Equipment-only wildcards (`MAT_TR_SOV_01..10`, `_basePreTranscendent` non-destructive snapshot, 100% abort refund), and 3 Pure-Forged Genesis Artifacts (`EQ_TR_PURE_WPN/ARM/ACC_GENESIS`).
- **352 Scriptures & Sovereign Codices + Visuals**: `170` `*_LOW_*` + `144` `*_EXP_*` + `38` `T*_SOV_*` stored in `JD.TECH.extraMantras` (77) & `JD.TECH.expansionNonCombatArts` (275) (preserving `JD.TECH.mantras === 122`, `JD.TECH.techniques === 1726`, `ECO.itemById` enumerable `1,177`, recipes `1,402`, `COMBAT.KEYWORDS_CATALOG === 16`). Deterministic 0-RNG 96×96 SVG icons (`UI.render*IconHtml`) & 4-phase 92–118 px Canvas2D VFX (`Render.TRANSCENDENT_VFX_SCENES`). Verified across `184 / 184` suites (`test/carbon_compendia_master_suite.js`).
