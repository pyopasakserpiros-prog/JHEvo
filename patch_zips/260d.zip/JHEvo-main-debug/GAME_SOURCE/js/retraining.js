/* Explicit costly retraining, bounded NPC preparation and access-aware choice. */
(function(g){
'use strict';
const {MARTIAL:M,CULT,CPE,HC,AI,STATS:ST,JD,U,SECT}=g,clamp=U.clamp;
M.retrainingStage=(old,pathChanged)=>pathChanged?1:Math.max(1,old-Math.max(2,Math.ceil(old/2)));
M.retrainingTarget=(n,key)=>{
 const k=M.knowledge(key);if(!n||!n.cult||!k||k.kind!=='sub')return {ok:false,reason:'ต้องมีองค์ความรู้สายย่อยที่ถูกต้อง'};
 if(n.cult.path===k.path&&n.cult.sub===k.id)return {ok:false,reason:'เดินสายนี้อยู่แล้ว'};
 if(n.cult.path===k.path&&n.cult.sub==='NONE')return {ok:false,reason:'ใช้การศึกษาสายเริ่มต้น ไม่ต้องสละขั้น'};
 const effSt=CULT.effectiveTechStage?CULT.effectiveTechStage(n):n.cult.stage;if(effSt<k.tier)return {ok:false,reason:'ขั้นเดิมยังไม่ถึงเกณฑ์ความรู้'};
 return {ok:true,knowledge:k,pathChanged:n.cult.path!==k.path,newStage:M.retrainingStage(n.cult.stage,n.cult.path!==k.path)};
};
M.retrainingQuote=(W,n,key,opts)=>{
 opts=opts||{};const target=M.retrainingTarget(n,key);if(!target.ok)return target;
 if(n.dead||n.away||n.exiled||n.act&&n.act.id==='fight')return {ok:false,reason:'ต้องปลอดภัยและอยู่ในสำนักก่อน'};
 if(W.day<(n.retrainUntil||0))return {ok:false,reason:'พักปรับฐานวิถีถึงวันที่ '+n.retrainUntil,cooldownUntil:n.retrainUntil};
 const id=target.knowledge.id,ownedCrystal=(n.inv&&n.inv.crystals&&n.inv.crystals[key]||0)>0,ownedManual=(n.inv&&n.inv.subManuals||[]).includes(id),sectManual=(W.sect.subLibrary||[]).includes(id)&&SECT.canLearnTier(W,n)>=target.knowledge.tier;
 const pathAllowed=!g.SECT||!g.SECT.PATH_LIBRARY||typeof g.SECT.PATH_LIBRARY.canDiscipleStudyPath!=='function'||g.SECT.PATH_LIBRARY.canDiscipleStudyPath(W,n,target.knowledge.path);
 const source=opts.source||(ownedCrystal?'crystal':(pathAllowed&&ownedManual)?'personalManual':(pathAllowed&&sectManual)?'sectManual':null);
 if(!source||source==='crystal'&&!ownedCrystal||source==='personalManual'&&(!ownedManual||!pathAllowed)||source==='sectManual'&&(!sectManual||!pathAllowed)||!['crystal','personalManual','sectManual'].includes(source))return {ok:false,reason:!pathAllowed&&(ownedManual||sectManual)?'หอคัมภีร์ยังไม่ปลดล็อกวิถีเป้าหมาย':'ไม่มีผลึกหรือคัมภีร์ที่เข้าถึงได้จริง'};
 const fee=source==='crystal'?0:M.studyFee(W,key),cooldownDays=target.pathChanged?60:30;
 if(opts.price!=null&&opts.price!==fee)return {ok:false,reason:'ค่าเรียนเปลี่ยนไป'};
 return Object.assign({},target,{ok:true,key,source,fee,lostStages:n.cult.stage-target.newStage,cooldownDays,affordable:Number.isFinite(n.cp)&&(n.cp>=fee)});
};
M.retrain=(W,n,key,opts)=>{
 const quote=M.retrainingQuote(W,n,key,opts);if(!quote.ok)return quote;if(!quote.affordable)return {ok:false,reason:'แต้มไม่พอ'};
 if(quote.source==='crystal'&&!(n.inv.crystals[key]>=1))return {ok:false,reason:'ผลึกถูกใช้ไปแล้ว'};
 if(quote.fee&&!CPE.spend(W,n,quote.fee,'เปลี่ยนวิถีศึกษาสาย'+quote.knowledge.nameTh))return {ok:false,reason:'แต้มไม่พอ'};
 // No RNG or fallible operation follows payment; consume a unit only on this successful commit.
 if(quote.source==='crystal')M.consumeCrystalUnit(n,key);else CPE.S(W).techSales+=quote.fee;
 const old=n.cult,from=old.path+'/'+old.sub,before=old.stage,k=quote.knowledge;
 const prevLifeMax=CULT.lifespan?CULT.lifespan(n):(((CULT.PATHS[old.path]&&CULT.PATHS[old.path].stages[old.stage-1]&&CULT.PATHS[old.path].stages[old.stage-1].lifespanMax)||70)+(old.lifeBonus||0));
 const newBaseLife=(CULT.PATHS[k.path]&&CULT.PATHS[k.path].stages[quote.newStage-1]&&CULT.PATHS[k.path].stages[quote.newStage-1].lifespanMax)||70;
 const ageNow=HC.ageYears(n),lifeDelta=Math.max(0,prevLifeMax-newBaseLife);
 let nextLifeBonus=old.lifeBonus||0;
 if(!quote.pathChanged){
  nextLifeBonus=Math.max(nextLifeBonus,Math.round(lifeDelta*.85));
  if(ageNow+15>newBaseLife+nextLifeBonus)nextLifeBonus=Math.max(nextLifeBonus,Math.min(lifeDelta,Math.ceil(ageNow+15-newBaseLife)));
 }else if(ageNow+10>newBaseLife+nextLifeBonus){
  nextLifeBonus=Math.max(nextLifeBonus,Math.min(Math.round(lifeDelta*.6),Math.ceil(ageNow+10-newBaseLife)));
 }
 n.cult={path:k.path,sub:k.id,stage:quote.newStage,prog:0,mantra:null,unlockedMantras:Array.isArray(old.unlockedMantras)?old.unlockedMantras.filter(id=>{const m=CULT.tech(id);return !!(m&&(!m.path||m.path==="ANY"||m.path===k.path));}):[],techs:Array.from(new Set(old.techs||[])),learning:null,toxic:old.toxic||0,lifeBonus:nextLifeBonus,since:W.day,attempts:0,secl:null,rate:0,pillT:0,tm:old.tm||{}};
 n.cult.mantra=(CULT.bestMantra(k.path,quote.newStage,n)||{}).id||null;
 if(CULT.isExpansionTrack?CULT.isExpansionTrack(k.id):(CULT.EXPANSION_TRACK_IDS&&CULT.EXPANSION_TRACK_IDS.has(k.id))){
  const trDef=CULT.trackDef&&CULT.trackDef(k.id),trMax=(trDef&&Array.isArray(trDef.realms)&&trDef.realms.length)||9;
  const trOrd=!quote.pathChanged?Math.min(trMax,Math.max(1,quote.newStage)):1;
  n.cult.track=CULT.initTrack(k.id,trOrd,W.day);
 }
 if(quote.pathChanged){
  n.pathGauge=null;n.mechState=null;n.karmaState=null;n.divineWaning=false;n.demonicRealmsGauge=null;
  n.secondaryResources={FROST_QI:0,KILLING_INTENT:0,FORMATION_INK:0,MECH_GEARS:0};
  if(n.grandDaoState)n.grandDaoState=null;
  if(n.ext){delete n.ext._faithZeroDays;delete n.ext.grandDaoPosture;}
 }
 if(n.equip&&M.gearUsable){
  n.inv=n.inv||{};n.inv.gear=n.inv.gear||[];
  for(const slot of ['WEAPON','ARMOR','ACCESSORY']){
   const eq=n.equip[slot];
   if(eq&&!M.gearUsable(n,eq)){n.inv.gear.push(eq);n.equip[slot]=null;}
  }
 }
 if(CULT.ensurePathGauge)CULT.ensurePathGauge(n);
 if(CULT.ensurePets&&n.pets)CULT.ensurePets(n);if(k.path==='MECH_PUPPET'&&CULT.ensureMechState)CULT.ensureMechState(n);if(k.path==='KARMA_SAMSARA'&&CULT.ensureKarmaState)CULT.ensureKarmaState(n);
 if(CULT.GRAND_DAO_MECHANICS&&CULT.GRAND_DAO_MECHANICS.ensureNpcState)CULT.GRAND_DAO_MECHANICS.ensureNpcState(W,n);
 if(CULT.evaluateAutonomousPostures)CULT.evaluateAutonomousPostures(W,n,{trigger:'retrain'});
 if(M.reconcileInnate)M.reconcileInnate(n,W);
 if(M.reconcilePassives)M.reconcilePassives(n);
 n.buffs=[];n.sx=[];n.castFx=null;n._pickCache=null;if(M.invalidateMartialCaches)M.invalidateMartialCaches(n);
 if(n.cognition){n.cognition.goal=null;n.cognition.goalCandidates=[];}
 n.retrainUntil=W.day+quote.cooldownDays;
 n.martialIntent={targetKey:key,action:'restabilize',day:W.day,until:n.retrainUntil,from,oldStage:before,newStage:quote.newStage,reasons:['ยอมลดขั้น '+before+' → '+quote.newStage,'พักปรับรากฐาน '+quote.cooldownDays+' วัน']};
 CULT.refreshLifespan(n);n.h.state.hp=Math.min(n.h.state.hp,CULT.hpMax(n));n.h.state.qi=Math.min(n.h.state.qi||0,CULT.qiMax(n));n.h.state.energy=Math.max(0,n.h.state.energy-12);HC.bump(n);if(g.ELEM&&g.ELEM.syncSpecialAccess)g.ELEM.syncSpecialAccess(n);ST.dirty(n);
 W.log('learn',n.h.name.given+' เปลี่ยนจาก '+from+' เป็น '+k.path+'/'+k.id+' · ขั้น '+before+' → '+quote.newStage+' ตบะเริ่มใหม่ · ใช้'+(quote.source==='crystal'?'ผลึก1ชิ้น':'คัมภีร์ถาวร ค่าเรียน '+quote.fee+' คป.')+' · พักปรับฐาน '+quote.cooldownDays+' วัน',[n.id]);
 return {ok:true,source:quote.source,fee:quote.fee,oldStage:before,newStage:quote.newStage};
};
const affinityCache=new WeakMap();
function affinities(W,n){const c=affinityCache.get(n);if(c&&c.day===W.day&&c.ver===n._ver)return c.values;const values=CULT.pathScores(n);affinityCache.set(n,{day:W.day,ver:n._ver,values});return values;}
M.evaluateRetraining=(W,n,key)=>{
 const structure=M.retrainingTarget(n,key),quote=M.retrainingQuote(W,n,key),base={targetKey:key,accessible:quote.ok,action:'retain',score:-Infinity,reasons:[]};
 if(!structure.ok)return Object.assign(base,{reason:structure.reason,reasons:[structure.reason]});
 if(!quote.ok)return Object.assign(base,{reason:quote.reason,reasons:[quote.reason]});
 const k=structure.knowledge,profile=M.PROFILES[k.id],current=M.PROFILES[n.cult.sub],preferred=profile?profile[3]:M.PATHS[k.path].weapons,oldPreferred=current?current[3]:M.PATHS[n.cult.path].weapons;
 const targetSkill=Math.max(...preferred.map(type=>M.weaponSkill(n,type))),currentSkill=Math.max(...oldPreferred.map(type=>M.weaponSkill(n,type))),ambition=HC.eff(n,'personality.ambition'),caution=HC.eff(n,'personality.caution'),rational=HC.eff(n,'personality.rationality'),curiosity=HC.eff(n,'personality.curiosity');
 const isSubOk=(t,subId)=>CULT.isSubCompatible?CULT.isSubCompatible(t,subId,false):(!t.sub||t.sub===subId);
 const oldActive=M.activeTechs(n).map(CULT.tech).filter(Boolean),lost=oldActive.filter(t=>t.path!=='ANY'&&t.path!==k.path||!isSubOk(t,k.id)),compatible=oldActive.filter(t=>(t.path==='ANY'||t.path===k.path)&&isSubOk(t,k.id));
 const sourcePool=JD.TECH.techniques.filter(t=>!t.innateOnly&&t.path===k.path&&isSubOk(t,k.id)&&(t.reqTier||t.tier)<=Math.max(k.tier,quote.newStage+1)&&((n.cult.techs||[]).includes(t.id)||W.sect.library.includes(t.id)||(n.inv.techs||[]).includes(t.id)||(n.inv.crystals[M.techKey(t.id)]||0)>0));
 const gearReady=preferred.includes(M.equippedType(n)),techReady=sourcePool.length>0;
 const rows=affinities(W,n),target=rows.find(x=>x.sub===k.id),currentAffinity=rows.find(x=>x.sub===n.cult.sub),affinityAdv=clamp((target?target.score:50)-(currentAffinity?currentAffinity.score:50),-25,25)*.4;
 const tgtSubDef=CULT.subInfo(k.path,k.id),curSubDef=CULT.subInfo(n.cult.path,n.cult.sub);
 const tgtElem=g.ELEM?g.ELEM.resolveCompatibility(n,tgtSubDef,'pathChoice').multiplier:1;
 const curElem=g.ELEM?g.ELEM.resolveCompatibility(n,curSubDef,'pathChoice').multiplier:1;
 const elemAdv=clamp((tgtElem-curElem)*32,-12,14);
 const skillAdv=(targetSkill-currentSkill)*.35,investment=quote.lostStages*(5+caution*.20+rational*.07)+lost.reduce((s,t)=>s+t.tier,0)*(1+caution/70),prepared=(gearReady?11:0)+Math.min(18,sourcePool.length*9);
 const advantage=affinityAdv+elemAdv+skillAdv+(ambition-50)*.3+(curiosity-50)*.1+prepared+(compatible.length?3:0);
 const curLifeMax=CULT.lifespan?CULT.lifespan(n):(((CULT.PATHS[n.cult.path]&&CULT.PATHS[n.cult.path].stages[n.cult.stage-1]&&CULT.PATHS[n.cult.path].stages[n.cult.stage-1].lifespanMax)||70)+(n.cult.lifeBonus||0));
 const projBaseLife=(CULT.PATHS[k.path]&&CULT.PATHS[k.path].stages[quote.newStage-1]&&CULT.PATHS[k.path].stages[quote.newStage-1].lifespanMax)||70;
 const projDelta=Math.max(0,curLifeMax-projBaseLife);
 const projLife=projBaseLife+(n.cult.lifeBonus||0)+(!quote.pathChanged?Math.round(projDelta*.85):Math.round(projDelta*.4));
 const ageRisk=HC.ageYears(n)>projLife-8?100:0,needs=n.h.state.energy<35||n.h.state.satiety<35||n.h.state.hp<CULT.hpMax(n)*.6;
 const score=advantage-investment-ageRisk-(needs?35:0)-(!quote.affordable?25:0);
 const reasons=['อาวุธเป้าหมาย '+preferred.map(x=>M.TYPES[x]).join('/')+' ฝีมือ '+Math.round(targetSkill),'ความสอดคล้องธาตุสายย่อย '+Math.round(tgtElem*100)+'% (เทียบสายเดิม '+Math.round(curElem*100)+'%)','เสียขั้น '+n.cult.stage+' → '+quote.newStage+' และพัก '+quote.cooldownDays+' วัน','วิชาเดิมจะหยุดทำงาน '+lost.length+' · ยังใช้ได้ '+compatible.length,'เตรียมอุปกรณ์ '+(gearReady?'พร้อม':'ยังไม่พร้อม')+' / วิชาทดแทน '+sourcePool.length,'นิสัยและความถนัดสุทธิ '+Math.round(advantage)+' · ต้นทุนฝึกใหม่ '+Math.round(investment)];
 if(needs)reasons.push('ต้องดูแลสุขภาพ/อาหารก่อน');if(ageRisk)reasons.push('อายุขัยขั้นใหม่เสี่ยงเกินไป');
 const threshold=18+caution*.08,worth=score>=threshold;
 return Object.assign(base,{quote,score,accessible:true,action:worth&&gearReady&&techReady&&!needs&&quote.affordable?'switch':(targetSkill>=50&&advantage>investment*.5&&!needs?'prepare':'retain'),reasons,gearReady,techReady,targetSkill,lostTechniques:lost.map(t=>t.id),availableTechniques:sourcePool.map(t=>t.id),elemAdv});
};
M.availableRetraining=(W,n)=>Array.from(new Set(Object.keys(n.inv&&n.inv.crystals||{}).filter(key=>key.startsWith('S:')&&n.inv.crystals[key]>0).concat((n.inv&&n.inv.subManuals||[]).map(M.subKey),(W.sect.subLibrary||[]).map(M.subKey))));
M.pickRetraining=(W,n)=>{if(!n||!n.cult||n.cult.stage<2||W.day<(n.retrainUntil||0))return null;const subLibLen=(W.sect.subLibrary||[]).length,crysLen=Object.keys(n.inv&&n.inv.crystals||{}).length,manLen=(n.inv&&n.inv.subManuals||[]).length,pathLibLen=(W.sect.pathLibrary&&Array.isArray(W.sect.pathLibrary.unlockedPaths))?W.sect.pathLibrary.unlockedPaths.length:0;if(!subLibLen&&!crysLen&&!manLen)return null;const rc=n._retrainPickCache;if(rc&&rc.day===W.day&&rc.ver===n._ver&&rc.stage===n.cult.stage&&rc.sub===n.cult.sub&&rc.cp===(n.cp||0)&&rc.subLibLen===subLibLen&&rc.crysLen===crysLen&&rc.manLen===manLen&&rc.pathLibLen===pathLibLen)return rc.val;const val=M.availableRetraining(W,n).map(key=>M.evaluateRetraining(W,n,key)).filter(x=>x.accessible).sort((a,b)=>b.score-a.score)[0]||null;n._retrainPickCache={day:W.day,ver:n._ver,stage:n.cult.stage,sub:n.cult.sub,cp:n.cp||0,subLibLen,crysLen,manLen,pathLibLen,val};return val;};
const decision=M.crystalDecision;M.crystalDecision=(W,n,key)=>{
 const k=M.knowledge(key);
 if(k&&k.kind==='sub'&&M.retrainingTarget(n,key).ok){const d=M.evaluateRetraining(W,n,key);if(d.accessible&&(d.action==='switch'||d.action==='prepare'||d.targetSkill>=55))return {action:'retain',reason:d.action==='switch'?'รอฝึกเปลี่ยนสายอย่างรอบคอบ':d.reasons.join(' · '),fit:d.targetSkill||50};}
 const intent=n.martialIntent,target=intent&&M.knowledge(intent.targetKey);if(k&&k.kind==='tech'&&target&&['prepare','switch'].includes(intent.action)&&k.path===target.path&&(!k.sub||k.sub===target.id))return {action:'retain',reason:'เตรียมวิชาทดแทนก่อนยอมลดขั้น',fit:80};
 return decision(W,n,key);
};
const fit=M.knowledgeFit;M.knowledgeFit=(n,key)=>{const k=M.knowledge(key);if(k&&k.kind==='sub'&&n.cult&&M.PROFILES[k.id])return Math.max(fit(n,key),35+Math.max(...M.PROFILES[k.id][3].map(type=>M.weaponSkill(n,type)))*.5);return fit(n,key);};
M.canAcquireKnowledge=(W,n,key)=>M.eligible(n,key).ok||(M.knowledge(key)&&M.knowledge(key).kind==='sub'&&M.retrainingTarget(n,key).ok);
const daily=M.daily;M.daily=W=>{M.ensure(W);for(const n of W.npcs){if(n.dead||n.away||n.exiled||W.day<(n.retrainUntil||0))continue;const best=M.pickRetraining(W,n);if(best&&best.action!=='retain')n.martialIntent={targetKey:best.targetKey,action:best.action,day:W.day,until:W.day+30,score:Math.round(best.score),reasons:best.reasons.slice(0,6)};else if(n.martialIntent&&n.martialIntent.until<=W.day)n.martialIntent=null;}daily(W);};
AI.ACTS.retrain={nameTh:'ปรับฐานเปลี่ยนวิถี',icon:'🔄',color:'#d6a7e8',can(n,W){const p=M.pickRetraining(W,n);return !!p&&p.action==='switch';},score(n,W,S){const p=M.pickRetraining(W,n);if(p&&p.action==='switch')S.add('ยอมลดขั้นเพื่อสายที่เตรียมไว้',.65+Math.min(1,p.score/70));},where(W,n){const p=M.pickRetraining(W,n);if(!p||p.action!=='switch')return null;const st=AI.freeStation(W,n,'read','scripture');return st?{st,targetKey:p.targetKey}:null;},dur:()=>360,done(n,W,ctx){const p=M.evaluateRetraining(W,n,ctx.targetKey);if(p.action==='switch')M.retrain(W,n,ctx.targetKey,{source:p.quote.source,price:p.quote.fee});}};
const suitable=M.gearSuitability;M.gearSuitability=(n,it,price)=>{const result=suitable(n,it,price),intent=n.martialIntent,target=intent&&intent.action==='prepare'&&M.knowledge(intent.targetKey),profile=target&&M.PROFILES[target.id];if(profile&&it.slot==='WEAPON'&&profile[3].includes(M.gearType(it))&&Number.isFinite(result.score)){return Object.assign({},result,{score:result.score*1.25+18,reasons:result.reasons.concat('เตรียมอาวุธก่อนยอมลดขั้นเปลี่ยนสาย')});}return result;};
})(typeof globalThis!=='undefined'?globalThis:this);
