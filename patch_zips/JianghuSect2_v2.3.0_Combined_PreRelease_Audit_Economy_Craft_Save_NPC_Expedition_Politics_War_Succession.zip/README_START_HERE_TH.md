# JianghuSect 2 v2.3.0 — ZIP รวมรายงานตรวจ Pre-Release ทั้ง 3 ส่วน

**ไฟล์นี้รวม:** เศรษฐกิจ (`AUDIT/`) + การผลิต/สูตรคราฟต์/แหล่งวัตถุดิบ (`CRAFT_AUDIT/`) + **ระบบเซฟ/โหลดและงานค้าง (`SAVE_AUDIT/`)** ทั้งหมดใน ZIP เดียว โดยไม่แตะซอร์สเกม.

**เริ่มอ่านระบบล่าสุด:** `SAVE_AUDIT/00_EXECUTIVE_RELEASE_VERDICT_TH.md` → `SAVE_AUDIT/01_DETAILED_FINDINGS_TH.md` → `SAVE_AUDIT/05_AI_IMPLEMENTER_HANDOFF_AND_REGRESSIONS_TH.md`.

**ภาพรวมใหม่:** เพิ่ม 9 ประเด็น (P1 6, P2 3). ทดสอบใหม่ 12 กรณี + autosave mock; ชุดเดิม 18 ชุดและ schema validator 1 ชุดผ่าน. พบสูญ progress มรรตัย, bypass ผลย้อนกลับอัญเชิญเมื่อ reload, registry leak แม้ import ล้ม, poisoned money, autosave failure เงียบ. ระบบ craft receipt และ expedition replay กลับทำงานถูกต้องในกรณีควบคุม.

**สำคัญ:** `ok:true` ใน repro JSON หมายถึงพิสูจน์สภาพโค้ด *ก่อนแก้* ได้; มีทั้งบัคและ positive controls อย่าตีความว่าเกมผ่าน! ทุกข้อแยกความเป็นไปได้ผ่าน UI, ผล runtime และข้อจำกัด.

**ต่อไปแนะนำตรวจเพียงเรื่องเดียว:** การตัดสินใจและงาน NPC (ดู `SAVE_AUDIT/07_NEXT_AUDIT_ONE_TOPIC_TH.md`).

---

## รายงานเดิม (เก็บครบ)

# JianghuSect 2 v2.3.0 — รายงานตรวจพร้อมปล่อยเกม (เศรษฐกิจ + การผลิต/สูตรคราฟต์/แหล่งวัตถุดิบ)

**แพ็กเกจเดียว:** ZIP นี้เก็บรายงานเศรษฐกิจตรวจใหม่ครบจากชุดเดิม และเพิ่ม `CRAFT_AUDIT/` ซึ่งตรวจแหล่งวัตถุดิบและทุกสูตรที่โหลดจริงแบบเชื่อมโยงทั้งระบบ

**สำหรับ AI ผู้แก้โค้ด:** อ่าน `AGENTS.md` ใน ZIP **ต้นฉบับเกม** ก่อน; อ่าน `AUDIT/` (เศรษฐกิจ) และ `CRAFT_AUDIT/` (การผลิต) แล้วทำตาม acceptance criteria. **ZIP รายงานนี้ไม่ใช่เกมหรือแพตช์** — ไม่มีการแก้ไขไฟล์เกม

**ฐาน:** `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip`
**SHA256 ฐาน:** `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`

## สารบัญแนะนำ

- `AUDIT/01_RELEASE_VERDICT_TH.md` และ `AUDIT/02_DETAILED_FINDINGS_TH.md` — เศรษฐกิจฉบับล่าสุด (เก็บของเดิมไว้ครบ)
- `CRAFT_AUDIT/00_EXECUTIVE_RELEASE_VERDICT_TH.md` — ภาพรวม ปัญหา P0/P1 และความเสี่ยงก่อนปล่อย
- `CRAFT_AUDIT/01_EVIDENCE_AND_ROOT_CAUSE_TH.md` — การอ่านโค้ด/ทดสอบรายประเด็น 13 ข้อ
- `CRAFT_AUDIT/02_MATERIAL_SOURCES_AND_RECIPE_GRAPH_TH.md` — ต้นทางวัตถุดิบ ทุกสูตร ความติดขัดและผลต่อ NPC
- `CRAFT_AUDIT/03_CHAIN_REACTION_SAVE_ECONOMY_TEST_PLAN_TH.md` — ผลลูกโซ่ระยะสั้นและยาวกับเศรษฐกิจ/เซฟ/AI
- `CRAFT_AUDIT/04_IMPLEMENTER_HANDOFF_AND_ACCEPTANCE_TH.md` — แผนแก้เป็นลำดับ บททดสอบและเกณฑ์รับงาน
- `CRAFT_AUDIT/05_TEST_RESULTS_AND_LIMITATIONS_TH.md` — ผลทดสอบจริง/ข้อจำกัด/ความเชื่อมั่น
- `CRAFT_AUDIT/DATA/ALL_RECIPES_1118.csv` — ทุกสูตรพร้อม input และ normalization status
- `CRAFT_AUDIT/DATA/INGREDIENT_DEPENDENCIES_372.csv` — สารตั้งต้นทั้งหมดที่ถูกอ้างโดยสูตร พร้อมผู้ใช้และ provider status
- `CRAFT_AUDIT/DATA/ITEM_ONLY_MATERIALS_24.csv` และ `CRAFT_AUDIT/DATA/INVALID_SCHEMA_RECIPES_415.csv` — รายชื่อครบสำหรับแก้โค้ด
- `CRAFT_AUDIT/FINDINGS.csv`, `.json`, `CRAFT_AUDIT/EVIDENCE/` — เครื่องมือและหลักฐานพิสูจน์ซ้ำ
- `FINDINGS.csv`, `.json`, `EVIDENCE/` ที่ root — ผลตรวจเศรษฐกิจเดิม ไม่ได้ลบทิ้ง

## ลำดับอ่านแบบรวดเร็ว

1. เริ่มที่ `CRAFT_AUDIT/00_EXECUTIVE_RELEASE_VERDICT_TH.md` เพื่อเข้าใจ Release Blockers
2. เทียบผลกระทบกับ `AUDIT/03_CROSS_SYSTEM_CHAINS_TH.md` (เศรษฐกิจ)
3. อ่าน `CRAFT_AUDIT/04_IMPLEMENTER_HANDOFF_AND_ACCEPTANCE_TH.md` แล้วเปิดรายชื่อ ID ใน `DATA/`

**สถานะ:** NO-GO เนื่องจากบัคที่พิสูจน์ได้ — อย่าเปิดให้เล่นจริงก่อนแก้และรัน regression + UI/save/soak. ชุดทดสอบเดิมผ่าน 13 ชุดไม่ได้พิสูจน์ว่าไม่มีบัคใหม่
