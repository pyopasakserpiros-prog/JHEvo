# หลักฐาน, วิธีรัน, และขอบเขตที่ยังไม่ได้รับรอง

## หลักฐานที่รันจริง

- `repro_politics.js`: 11 กรณี P-01…P-11 ตรวจ world state in memory ผ่าน `GAME_SOURCE/test/load.js`
- `repro_politics_more.js`: 7 กรณี P-12…P-18
- `repro_schism_save.js`: 5 กรณี P-19…P-23 (รวม save/load รอบเดียว, trade shipment missing, calendar cadence)
- `postfix_regression_contract.js`: 10 after-fix contracts มีสถานะ RED 10/10 **บนเกมต้นฉบับ** (คาดหมาย / ไม่ใช่ชุดเดิมเสีย)
- focused regressions: **ผ่าน 18/18** ชุดจากไฟล์ `focused_tests.json`; ตัวตรวจ data schema ผ่าน 0 Errors, 0 Warnings
- policy-only soak: 3 seed × 120 วัน (360→480) สำเร็จ; สงครามพบที่วันที่ 420,480 ในแต่ละ seed; ไม่พบ nonfinite stones ในตัวอย่าง; 19 allSects และ 1 alliance leader ต่อฝ่ายในตัวอย่าง

## ข้อจำกัดสำคัญ

1. **ไม่มีการทดสอบคลิกปุ่มจริงใน Chromium/Playwright** คำว่า UI-reachable มาจากการตรวจ code path ของ event handlers ที่เผยปุ่ม และรัน function ภายในด้วย state จริง ไม่ใช่ E2E browser
2. รายการ `Internal API` ยัง **ไม่ได้พิสูจน์** ว่าผู้เล่นทั่วไปสั่งตรงได้; ต้อง trace caller เพิ่มหลังแพตช์ หรือใช้ E2E/debug check
3. การจำลอง 120 วันเป็น **politics tick only** ไม่ใช่การเดินเกมทั้งวัน/ทุก NPC/ทุกฤดูกาลผ่าน `SIM.tick`; ใช้ยืนยัน cadence และ invariants ระดับการเมืองในสถานะทดสอบ ไม่รับรองสมดุลโลกทั้งหมด
4. บาง issue เป็นข้อกำหนดที่ควรตัดสินตาม game design (เช่น `winProb`, คาบสงคราม, splinter) ก่อนแก้ทันที
5. เนื่องจาก ZIP เป็นต้นฉบับก่อนแก้ ผล RED ของ acceptance tests ไม่ใช่การทดสอบว่าแพตช์ใหม่ล้มเหลว
6. ชุดทดสอบ 18 รายการที่ผ่านเป็น regression focus เท่านั้น ไม่ใช่ผลการรัน 139/139 หรือทุก browser suite

## วิธีรันทดสอบซ้ำแบบปลอดภัย

ต้องใช้ Node.js และ source เกมที่มี `test/load.js` (ใช้ได้ทั้ง ZIP ต้นฉบับที่แตกออกหรือแพตช์ใหม่)

```bash
export JIANGHU_GAME_SOURCE=/path/to/GAME_SOURCE
node POLITICS_WAR_SUCCESSION_AUDIT/EVIDENCE/repro_politics.js
node POLITICS_WAR_SUCCESSION_AUDIT/EVIDENCE/repro_politics_more.js
node POLITICS_WAR_SUCCESSION_AUDIT/EVIDENCE/repro_schism_save.js
node POLITICS_WAR_SUCCESSION_AUDIT/EVIDENCE/postfix_regression_contract.js
# RED expected บนต้นฉบับ; should PASS after patch
```

- `repro_*.js` คือ **proof-of-defect**, จึงอาจหยุดรายงาน "ok:true" เมื่อเจอพฤติกรรมผิดตามที่ออกแบบไว้; **ห้ามใช้เป็นเกณฑ์หลังแก้** เพียงเพราะ output เหมือนก่อนหน้า
- `postfix_regression_contract.js` เป็น acceptance contract; เมื่อแก้แล้วควร `exit code 0` และ `passed=10, red=0` รวมถึงต้องขยายเงื่อนไขให้ครอบคลุม 20 ประเด็น
- รัน `node tools/validate_data_schema.js` จาก GAME_SOURCE และชุดเดิมที่เกี่ยวข้องหลังแก้; หากใช้ `run_focused.py` ให้ตรวจว่าพร้อมสำหรับ source path ใหม่

## ตัวอย่างหลักฐานตัวเลข

| เหตุการณ์ | ก่อน → หลัง / ตัวชี้วัด |
|---|---|
| พลุทัพหนุนซ้ำ | stones 1000→1720 รวม +720 โดยไม่มีศึกเริ่มต้น |
| บรรณาการ | วัน361 +168, วัน362 +168; บล็อกได้เฉพาะภายในวันเดียวกัน |
| นโยบายผ่อนปรน | loyalty 21→100 ด้วยการสั่งซ้ำ 14 รอบ |
| ศิษย์แลกเปลี่ยน | 3 ครั้งวันเดียวกัน: stones -180, attitude -4→26, cult progress 75→300; record ID ซ้ำ |
| คลี่คลายกบฏโดยไม่มีวิกฤต | stones 1000→750, crisis ถูกสร้างและปิดในคำสั่งเดียว |
| เติมเงินโลกจากเจรจาไม่สำเร็จ | ผู้เล่นมี1, ระบุจ่าย1000: ผู้เล่นยังมี1 แต่ worldPool +1000 |
| สนธิสัญญาส่วนขยาย | 6 legacy vs 19 canonical, S6 treaty อายุ1วันไม่หมดที่วันที่363 |
| ฆ่าผู้นำซ้ำ | successionHistory เพิ่ม2, master เปลี่ยน2รอบจาก death event เดิม |
| การเมืองจำลอง120วัน | 3 seed; สงครามวันที่ 420,480 ไม่ใช่ 15-day cadence |

**บันทึก:** ผลตัวเลขนี้เป็นสถานะโลกจำลองจาก seed/initial data ที่สคริปต์แนบสร้างขึ้น เพื่อให้ตรวจซ้ำได้ ไม่ใช่ค่าสถิติเฉลี่ยของผู้เล่นจริง
