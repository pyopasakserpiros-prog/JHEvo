# AI IMPLEMENTER — ขั้นตอนซ่อมและตรวจรับแบบข้ามระบบ

> ใช้ร่วมกับ ZIP เกม/ซอร์สล่าสุดจริง ๆ เสมอ ห้ามคัดลอกโค้ดจากรายงานโดยไม่ตรวจ source และ caller ใหม่

## ก่อนแตะซอร์ส

อ่าน `AGENTS.md`, `.agents/skills/gameplay-architecture/SKILL.md`, `ai-behavior-patterns`, `economy-balancing`, `save-system-patterns`, `qa-test-matrix`, `game-ui-ux` และตรวจโค้ดกับ branch ปัจจุบัน; หากแพตช์ถูกแก้โดย AI อื่นแล้วให้ rebase หลักฐาน/รีรัน repro เพื่อไม่ซ่อมซ้ำ

## P0 — สองบัคต้องปิดเป็นอันดับแรก

**1. พลุขอทัพหนุน** (POL-01, POL-02)
- ย้าย guard `activeEnemySiege?.status === 'BESIEGING'` ไปที่ function จริงด้วย ไม่พึ่งการซ่อนปุ่ม
- UI ปกติห้ามส่ง `forceWin:true`; ทดสอบกำลังรบ/การเสริมทัพจริงและแพ้ได้
- ครบเงื่อนไขแล้วจ่ายได้ครั้งเดียว: create `siegeId`, `rewardReceiptId`, terminal state; จ่ายผ่าน transactional reward
- E2E: ไม่มีศึก ปุ่มไม่ควรสร้างศึกหรือให้รางวัล; ศึกจริงชนะ/แพ้/เรียกซ้ำ/เซฟโหลดซ้ำต้องถูกต้อง

**2. บรรณาการ** (POL-03, POL-12)
- normalize `lastCollectedDay`, `nextDueDay` หรือ season number เป็น canonical field เดียวสำหรับ manual และ auto
- เปลี่ยนนโยบายเดิมไม่เพิ่ม loyalty; หากเปลี่ยนจริงต้องกำหนด cooldown/cost/AI trigger เพื่อเลี่ยง NPC exploit
- ทดสอบรอบ 89/90/91 วัน, world tick แบบข้ามวัน, save/load ณ วันครบ, หลายสำนัก, force flag ถูกจำกัด

## P1 — ความสอดคล้องของรัฐ/เศรษฐกิจ/เซฟ

**3. สำนักและการทูต** (POL-04, POL-05, POL-08)
- นิยาม canonical faction registry: allSects vs legacy sects; มี active/world-state contract เดียว
- ข้อมูล legacy ทำ migration โดยไม่ทำให้ของหรือสงครามเข้าซ้ำ; ตรวจ treaty+ledger+vassal+banner ทุก transition
- เขียน test 6 core +13 expansion, expired/rebel/embargo/tribute/trade; ข้ามเซฟต้องตรง

**4. สงคราม** (POL-06, POL-07, POL-16, POL-17)
- ใช้ state machine เต็ม: planned→travel→combat phases→outcome→rewarded/terminal
- enforce participant eligibility, target confirmed, ally check, no UI forceWin, no default S0, no immediate unless admin
- API results must be idempotent: re-entry/retry/callback duplicate/save-reload never duplicate money/manual/mats/history
- ตัดสินว่าจะให้ `winProb` เป็นโอกาสสุ่มจริงหรือเปลี่ยนคำอธิบาย UI ให้ตรง deterministic combat

**5. กบฏ ผู้นำ ศิษย์แลกเปลี่ยน** (POL-11, POL-13–15, POL-18–19)
- death event processed-once; ห้ามตั้ง successor อีกเมื่อ same entity dead แล้ว
- schism resolver ต้องไม่ trigger crisis เอง; รับ pay only when ECO.pay succeeds, then transfer to world pool
- splinter เป็น world entity จริงพร้อม membership, away/exiled, workforce, succession, travel หรือ narrative-only ที่ชัด
- exchange กำหนด unique record, cooldown, active assignment, arrival/return, reward exactly once, NPC AI eligibility
- ทดสอบเซฟระหว่างเดินทาง, ตายระหว่าง exchange, กลับแล้ว reward ไม่ซ้ำ, NPC ย้ายสำนักไม่อาจทำงานซ้อน

## ข้อแลกเปลี่ยนที่ต้องระบุใน pull request

- เปลี่ยนการให้รางวัลทันทีเป็นภารกิจเดินทางทำให้เกมช้าลง: ต้องพิจารณาจังหวะ/UX ทั้งสาย Idle และผู้เล่นที่ชอบ action
- กฎบรรณาการ 90 วันอาจทำให้เศรษฐกิจช่วงต้นขาดสภาพคล่อง: ต้องทดสอบ budget ไม่ใช่เปิด exploit เดิมเพื่อชดเชย
- การกรอง 19 สำนักอาจทำให้การจำลองเพิ่ม CPU แต่มีจำนวนจำกัด; เพิ่ม invariant หนึ่งชุดดีกว่าการแก้สองทะเบียนทีละฟังก์ชัน
- ถ้าใส่ reward receipt ในเซฟเก่า ต้อง migration โดยไม่จ่ายย้อนหลัง และไม่ reset cooldown เมื่อโหลด
- ห้ามแก้ระบบ cultivation, equipment, combat หลักโดยไม่มีหลักฐาน; ให้ทีมอีกแชทซ่อมสาระของหมวดนั้นและประสาน regression

## Definition of Done / เกณฑ์รับแพตช์

1. RED contract 10 กรณีกลายเป็น GREEN และเพิ่ม regression สำหรับข้ออื่นอย่างน้อย 20+ scenarios
2. ปุ่ม UI ที่มีปัญหา E2E ด้วย browser จริง (click disabled / error state / no double event binding) ทุกกรณี P0/P1 แบบ UI
3. ทุก transaction stone/CP/loyalty/loot ผ่าน invariant/receipt; duplicate/reload/retry ไม่สร้างของ
4. การเมือง 19 สำนัก: บันทึก–โหลดถูกต้อง, expiry, trade, wartime allegiance, membership, leadership
5. full integration simulation อย่างน้อยหลาย seed 30/90/360 วัน (ระบุจำนวนจริงและสมมติฐาน) ครอบคลุมไม่มี starvation, corrupted money, endless war, permanently stuck NPC
6. 18 focused suites และ data schema validator ผ่านบน code **หลังแก้**; รัน `node tools/run_parallel_tests.js` เมื่อสภาพแวดล้อมรองรับ
7. สร้าง offline game ใหม่และตรวจทางเข้า UI จาก build; อัปเดตเอกสาร/สกิล/สถานะโปรเจกต์ตาม AGENTS.md
8. เปรียบเทียบก่อน/หลังด้วย test outputs, ระบุ migration และ known residual risks; ไม่ถือว่า 'run passed' ถ้า timeout/skipped

**ห้ามแก้ source ใน ZIP รายงานนี้** — ไฟล์นี้เป็นหลักฐานและเกณฑ์ตรวจรับ ให้ใช้งานกับเกม/ซอร์สเวอร์ชันที่นักพัฒนาแก้จริง
