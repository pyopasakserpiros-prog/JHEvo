'use strict';
// RED tests against v2.3.0; these are acceptance contracts for the patching AI, not baseline tests.
// Run: node POLITICS_WAR_SUCCESSION_AUDIT/EVIDENCE/postfix_regression_contract.js
const assert=require('node:assert/strict');
const fs=require('node:fs'), path=require('node:path');
const candidates=[process.env.JIANGHU_GAME_SOURCE,process.cwd(),path.resolve(process.cwd(),'GAME_SOURCE'),path.resolve(__dirname,'../../GAME_SOURCE'),path.resolve(__dirname,'../../../GAME_SOURCE')].filter(Boolean);
const sourceRoot=candidates.find(p=>fs.existsSync(path.join(p,'test','load.js')));
if(!sourceRoot) throw new Error('Missing GAME_SOURCE; set JIANGHU_GAME_SOURCE=/path/to/GAME_SOURCE');
const g=require(path.join(sourceRoot,'test','load.js'));
const {SIM,EXPED,CONTENT,SECT}=g;
let n=0,passed=0,failed=0;const results=[];
function check(id,fn){const W=SIM.create('contract-'+(++n));EXPED.ensureWorldTopology(W);try{fn(W);passed++;results.push({id,status:'PASS'});}catch(e){failed++;results.push({id,status:'RED_EXPECTED_BEFORE_FIX',error:e.message});}}
check('UI_BEACON_REQUIRES_ACTUAL_SIEGE',W=>{const old=W.sect.stones;const r=EXPED.triggerSiegeReinforcementBeacon(W,{forceWin:true});assert.equal(r.ok,false);assert.equal(W.sect.stones,old);});
check('BEACON_CANNOT_WIN_ENORMOUS_ENEMY_WITHOUT_ALLIES',W=>{W.world.allSects.forEach(s=>{s.attitude=-100;s.treaty='RIVAL_FEUD';s.eternalSwornAlly=false;});EXPED.startEnemyGrandSiege(W,W.world.allSects[0].id,{enemyPower:1e12});const r=EXPED.triggerSiegeReinforcementBeacon(W,{forceReinforcement:false});assert.equal(r.won,false);});
check('VASSAL_TRIBUTE_REQUIRES_SEASONAL_INTERVAL',W=>{const s=W.world.allSects[0];EXPED.applySiegeResolution(W,s.id,'SUBJUGATE');W.day++;const x=EXPED.collectVassalTributes(W);const old=W.sect.stones;W.day++;const y=EXPED.collectVassalTributes(W);assert.equal(x.count,1);assert.equal(y.count,0);assert.equal(W.sect.stones,old);});
check('TRIBUTE_POLICY_REAPPLY_IDEMPOTENT',W=>{const s=W.world.allSects[0];EXPED.applySiegeResolution(W,s.id,'SUBJUGATE');s.loyalty=35;EXPED.setVassalTributePolicy(W,s.id,'LENIENT');const old=s.loyalty;EXPED.setVassalTributePolicy(W,s.id,'LENIENT');assert.equal(s.loyalty,old);});
check('CANONICAL_EXTRA_SECT_TREATY_EXPIRES',W=>{const s=W.world.allSects.find(s=>!W.world.sects.includes(s));s.attitude=100;assert.equal(CONTENT.signTreaty(W,s,'TRADE_PACT',{durationDays:1,quiet:true}).ok,true);W.day+=3;CONTENT.tickPolitics(W);assert.equal(s.treaty,'NONE');assert.equal(W.world.politics.treaties[s.id],undefined);});
check('NO_CRISIS_NO_NEGOTIATION_DEBIT',W=>{const old=W.sect.stones;const res=SECT.resolveFactionSchism(W,'NEGOTIATE');assert.equal(res.ok,false);assert.equal(W.sect.stones,old);});
check('EXCHANGE_ALREADY_IN_PROGRESS_NOT_REPEAT',W=>{const a=SECT.dispatchExchangeDisciple(W,null,null);const b=SECT.dispatchExchangeDisciple(W,null,null);assert.equal(a.ok,true);assert.equal(b.ok,false);});
check('REPLAY_DECEASED_SECT_MASTER_IDEMPOTENT',W=>{const s=W.world.allSects[0],f=s.figures.master;EXPED.killJianghuFigure(W,f,'audit');const current=s.figures.master.id,h=s.successionHistory?.length||0;EXPED.killJianghuFigure(W,f,'audit');assert.equal(s.figures.master.id,current);assert.equal(s.successionHistory.length,h);});
check('REPLAY_RESOLVED_SIEGE_NO_LOOT',W=>{const s=W.world.allSects[0],a=EXPED.marshalStrikeForce(W,null,s.id,{forceWin:true,postResolution:'PILLAGE'});assert.equal(a.ok,true);const before=W.sect.stones;const b=EXPED.resolveSectSiege(W,a.siege,{forceWin:true});assert.equal(b.ok,false);assert.equal(W.sect.stones,before);});
check('SPLINTER_REBELS_EXIT_PLAYER_ROSTER',W=>{SECT.triggerFactionSchismCrisis(W);const out=SECT.resolveFactionSchism(W,'SPLINTER');assert.equal(out.ok,true);for(const id of out.splinterSect.memberIds){assert.equal(W.npcs.some(n=>n.id===id&&!n.dead&&!n.away&&!n.exiled),false);}});
console.log(JSON.stringify({total:n,passed,red:failed,results},null,2));
if(failed)process.exitCode=1;
