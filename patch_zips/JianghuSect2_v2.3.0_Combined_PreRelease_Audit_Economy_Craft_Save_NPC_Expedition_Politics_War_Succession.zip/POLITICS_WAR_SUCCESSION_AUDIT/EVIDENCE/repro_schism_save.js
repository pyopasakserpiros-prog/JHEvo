'use strict';
const fs=require('node:fs'), path=require('node:path');
const candidates=[process.env.JIANGHU_GAME_SOURCE,process.cwd(),path.resolve(process.cwd(),'GAME_SOURCE'),path.resolve(__dirname,'../../GAME_SOURCE'),path.resolve(__dirname,'../../../GAME_SOURCE')].filter(Boolean);
const sourceRoot=candidates.find(p=>fs.existsSync(path.join(p,'test','load.js')));
if(!sourceRoot) throw new Error('Missing GAME_SOURCE; set JIANGHU_GAME_SOURCE=/path/to/GAME_SOURCE');
const G=require(path.join(sourceRoot,'test','load.js'));const {SIM,SECT,EXPED,CONTENT}=G;const rows=[];
function t(id,fn){try{let W=SIM.create('deep-political-'+id);EXPED.ensureWorldTopology(W);rows.push({id,ok:true,detail:fn(W)});}catch(e){rows.push({id,ok:false,error:String(e.stack||e)});}}
t('P-19_UI_click_resolve_no_existing_coup_automatically_creates_crisis',W=>{
 const before={crisis:W.sect.activeSchismCrisis||null,stones:W.sect.stones};
 const r=SECT.resolveFactionSchism(W,'NEGOTIATE');return {before,after:{status:W.sect.activeSchismCrisis?.status,stones:W.sect.stones},paid:r.paidStones,ok:r.ok};
});
t('P-20_save_load_persists_beacon_farm_and_tribute_day',W=>{
 const s=W.world.allSects[0];EXPED.applySiegeResolution(W,s.id,'SUBJUGATE');W.day=361;
 const e=EXPED.collectVassalTributes(W),b=EXPED.triggerSiegeReinforcementBeacon(W,{forceWin:true});
 const before={stones:W.sect.stones,lastTribute:s.lastVassalTributeDay,beaconStatus:W.world.activeEnemySiege?.status};
 const loaded=SIM.deserialize(SIM.serialize(W));const sl=loaded.world.allSects.find(x=>x.id===s.id);
 return {before,after:{stones:loaded.sect.stones,lastTribute:sl.lastVassalTributeDay,beaconStatus:loaded.world.activeEnemySiege?.status},ok:e.ok&&b.ok};
});
t('P-21_tick_war_calendar_12_by_15',W=>{
 let planned=0;const warDays=[];const start=361;
 for(let d=start;d<start+120;d++){W.day=d;if(d%12===0){planned++;const r=EXPED.tickGrandAlliancePolitics(W);if(r&&r.events&&r.events.length)warDays.push(d);}}
 return {start,days:120,tickCount:planned,warDays,warCount:warDays.length,comment:'Daily driver invokes on multiples of 12; internal war gate multiples of 15, so a war every 60 days.'};
});
t('P-22_world_13_extra_sects_trade_shipments_missed',W=>{
 const base=W.world.sects[0],extra=W.world.allSects.find(x=>!W.world.sects.includes(x));
 W.sect.stones=99999;for(const s of [base,extra]){s.attitude=90;CONTENT.signTreaty(W,s.id,'TRADE_PACT',{force:true,quiet:true});}
 const before=W.world.politics.stats.tradeShipments; W.day=370;CONTENT.tickPolitics(W);
 return {base:base.id,extra:extra.id,shipmentsIncrease:W.world.politics.stats.tradeShipments-before,baseActive:base.treaty,extraActive:extra.treaty};
});
t('P-23_coup_with_custom_overpay_ledger_creates_stones',W=>{
 W.world.resourcePool={stones:50000,herbs:5000,ores:5000};W.sect.stones=1;
 SECT.triggerFactionSchismCrisis(W,{demandedStones:1000});const a=W.sect.stones,b=W.world.resourcePool.stones;
 const r=SECT.resolveFactionSchism(W,'NEGOTIATE',{stones:1000});
 return {beforeStones:a,afterStones:W.sect.stones,worldPoolDelta:W.world.resourcePool.stones-b,reportedPaid:r.paidStones};
});
console.log(JSON.stringify({cases:rows},null,2));
