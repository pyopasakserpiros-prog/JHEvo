'use strict';
const fs=require('node:fs'), path=require('node:path');
const candidates=[process.env.JIANGHU_GAME_SOURCE,process.cwd(),path.resolve(process.cwd(),'GAME_SOURCE'),path.resolve(__dirname,'../../GAME_SOURCE'),path.resolve(__dirname,'../../../GAME_SOURCE')].filter(Boolean);
const sourceRoot=candidates.find(p=>fs.existsSync(path.join(p,'test','load.js')));
if(!sourceRoot) throw new Error('Missing GAME_SOURCE; set JIANGHU_GAME_SOURCE=/path/to/GAME_SOURCE');
const G=require(path.join(sourceRoot,'test','load.js'));
const {SIM,EXPED,CONTENT}=G; const seedList=['geo-soak-audit-A','geo-soak-audit-B','geo-soak-audit-C'];const outputs=[];
for(const seed of seedList){
 const W=SIM.create(seed);EXPED.ensureWorldTopology(W);const initDay=W.day;const initStones=W.sect.stones;const start=Date.now();const errors=[];const wars=[];const councils=[];
 for(let offset=1;offset<=120;offset++){
  W.day=initDay+offset;W.t+=1440;
  try{
   CONTENT.tickPolitics(W);
   if(W.day%10===0)EXPED.tickHegemony(W);
   if(W.day%12===0){const res=EXPED.tickGrandAlliancePolitics(W);for(const ev of res?.events||[])wars.push({day:W.day,id:ev.id});}
   if(W.day%14===0){const res=EXPED.tickAllianceCouncil(W);if(res) councils.push({day:W.day,kind:res.kind});}
   if(!Number.isFinite(W.sect.stones))errors.push('bad-stones day '+W.day);
   if((W.world.allSects||[]).length!==19)errors.push('wrong-count day '+W.day);
   const leaders=['RIGHTEOUS','DEMONIC'].map(id=>W.world.allSects.filter(s=>s.alignment===id&&s.isAllianceLeader).length);
   if(leaders.some(v=>v!==1)) errors.push('leader-count day '+W.day+': '+leaders.join('/'));
   if(W.world.allSects.some(s=>s.alignment==='NEUTRAL'&&s.isAllianceLeader))errors.push('neutral-leader day '+W.day);
  }catch(e){errors.push(W.day+': '+String(e));break;}
 }
 outputs.push({seed,mode:'120 political day advances; CONTENT.tickPolitics daily; EXPED.tickHegemony on day%10, tickGrandAlliancePolitics on day%12, tickAllianceCouncil on day%14. Not a full SIM.tick soak.',startDay:initDay,endDay:W.day,initStones,finalStones:W.sect.stones,sects:W.world.sects.length,allSects:W.world.allSects.length,politicalEvents:W.world.politics.events?.length,wars,councilsCount:councils.length,errors,elapsedMs:Date.now()-start});
}
console.log(JSON.stringify({runs:outputs},null,2));
