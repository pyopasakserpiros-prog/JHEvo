import subprocess,time,json,concurrent.futures,pathlib,datetime,os
root=os.environ.get('JIANGHU_GAME_SOURCE') or str(pathlib.Path.cwd())
tests=['v219_sect_tiers_alliances_internal_politics_suite.js','v218_world_map_hegemony_beasts_suite.js','v350_macro_world_politics_and_alchemy_suite.js','v400_living_frontier_and_sect_charter_suite.js','v330_living_sect_and_daily_loop_suite.js','diplomacy_sanctum_ancestral_suite.js','successor_and_archetypes_suite.js','organs_experiments_politics.js','world_rank.js','world_atlas.js','world_atlas_standalone.js','v410_sect_expansion_and_architecture_suite.js','npc_offices.js','save_integrity.js','v210_pagoda_warbeasts_conference_suite.js','v210_grand_dao_debates_and_bugfix_audit_suite.js','v233_peaks_elder_rank_social_cognition_suite.js','v550_mantra_resonance_and_formation_warfare_suite.js']
def run(t):
 start=time.monotonic()
 try:
  p=subprocess.run(['node','test/'+t],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=48,text=True)
  return {'test':t,'status':'passed' if p.returncode==0 else 'failed','exit_code':p.returncode,'seconds':round(time.monotonic()-start,2),'tail':'\n'.join((p.stdout+'\n'+p.stderr).splitlines()[-15:])[-1700:]}
 except subprocess.TimeoutExpired as e: return {'test':t,'status':'timeout','seconds':round(time.monotonic()-start,2),'tail':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex: rows=list(ex.map(run,tests))
pathlib.Path(__file__).with_name('focused_tests.json').write_text(json.dumps({'base':root,'tests':rows},ensure_ascii=False,indent=2),encoding='utf8')
for x in rows:print(x['test'],x['status'],x['seconds'])
