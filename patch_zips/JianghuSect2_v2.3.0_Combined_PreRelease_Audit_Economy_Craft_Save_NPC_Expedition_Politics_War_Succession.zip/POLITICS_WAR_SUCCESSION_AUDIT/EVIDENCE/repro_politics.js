'use strict';
// Read-only audit driver: creates in-memory worlds; never mutates shipped game source.
const fs=require('node:fs'), path=require('node:path');
const candidates=[process.env.JIANGHU_GAME_SOURCE,process.cwd(),path.resolve(process.cwd(),'GAME_SOURCE'),path.resolve(__dirname,'../../GAME_SOURCE'),path.resolve(__dirname,'../../../GAME_SOURCE')].filter(Boolean);
const sourceRoot=candidates.find(p=>fs.existsSync(path.join(p,'test','load.js')));
if(!sourceRoot) throw new Error('Missing GAME_SOURCE; set JIANGHU_GAME_SOURCE=/path/to/GAME_SOURCE');
const g=require(path.join(sourceRoot,'test','load.js'));
const {SIM,EXPED,CONTENT}=g;
const results={engine:{patch:SIM.PATCH_VERSION},cases:[]};
let caseNo=0;
function run(id,fn){try{const W=SIM.create('audit-political-seed-'+(++caseNo));EXPED.ensureWorldTopology(W);const result=fn(W);results.cases.push({id,ok:true,...result});}catch(e){results.cases.push({id,ok:false,error:String(e.stack||e)});}}
const stones=W=>W.sect.stones;
const sect=(W,i=0)=>W.world.allSects[i];
run('P-01_UI_beacon_creates_siege_when_none_then_farms_360',W=>{
 const before=stones(W), siegeBefore=W.world.activeEnemySiege||null;
 const a=EXPED.triggerSiegeReinforcementBeacon(W,{forceWin:true});
 const b=EXPED.triggerSiegeReinforcementBeacon(W,{forceWin:true});
 return {before,after:stones(W),delta:stones(W)-before,initialSiege:!!siegeBefore,first:{ok:a.ok,won:a.won,loot:a.spoilsStones},second:{ok:b.ok,won:b.won,loot:b.spoilsStones},status:W.world.activeEnemySiege.status};
});
run('P-02_default_beacon_wins_when_no_allies_with_tiny_army',W=>{
 const attacker=sect(W,0);
 const a=EXPED.startEnemyGrandSiege(W,attacker.id,{enemyPower:1e12});
 W.world.allSects.forEach(s=>{s.attitude=-90;s.treaty='RIVAL_FEUD';s.eternalSwornAlly=false;});
 const r=EXPED.triggerSiegeReinforcementBeacon(W,{forceReinforcement:false});
 return {attacker:a.ok,enemyPower:r.enemySiege.enemyPower,won:r.won,helpers:r.reinforcements.length,loot:r.spoilsStones};
});
run('P-03_UI_tribute_every_consecutive_day_not_90',W=>{
 const s=sect(W,1); const make=EXPED.applySiegeResolution(W,s.id,'SUBJUGATE',{});
 const firstDay=W.day+1;W.day=firstDay;
 const before=stones(W),a=EXPED.collectVassalTributes(W,{force:false}); const s1=stones(W);
 const againSameDay=EXPED.collectVassalTributes(W,{force:false});
 W.day++;const b=EXPED.collectVassalTributes(W,{force:false});
 return {subjugate:make.ok,day:firstDay,firstCount:a.count,firstDelta:s1-before,sameDayCount:againSameDay.count,nextDayCount:b.count,nextDayDelta:stones(W)-s1,sLast:s.lastVassalTributeDay};
});
run('P-04_Treaty_canonical_13_extra_sects_never_expire',W=>{
 const s=W.world.allSects.find(x=>!W.world.sects.includes(x));s.attitude=100;
 const r=CONTENT.signTreaty(W,s.id,'TRADE_PACT',{durationDays:1,force:true,quiet:true});const before={treaty:s.treaty,record:W.world.politics.treaties[s.id]};
 W.day+=3; CONTENT.tickPolitics(W);
 return {worldSects:W.world.sects.length,allSects:W.world.allSects.length,targetId:s.id,created:r.ok,before,after:{treaty:s.treaty,record:W.world.politics.treaties[s.id]||null},day:W.day};
});
run('P-05_zero_cost_free_trade_treaty_despite_hostility',W=>{
 const s=sect(W,2);s.attitude=-99;W.sect.stones=0;
 const r=CONTENT.signTreaty(W,s.id,'FREE_TRADE_TREATY',{});
 return {ok:r.ok,reason:r.reason||null,cost:r.cost,attitude:s.attitude,treaty:s.treaty,stones:stones(W)};
});
run('P-06_API_siege_replay_doubles_pillage_loot',W=>{
 const s=sect(W,0),startStones=stones(W);
 const r1=EXPED.marshalStrikeForce(W,null,s.id,{postResolution:'PILLAGE',forceWin:true});
 const after1=stones(W); const r2=EXPED.resolveSectSiege(W,r1.siege,{forceWin:true});
 return {first:{ok:r1.ok,won:r1.won,loot:after1-startStones,status:r1.siege&&r1.siege.status},second:{ok:r2.ok,won:r2.won,loot:stones(W)-after1,status:r2.siege&&r2.siege.status},totalGain:stones(W)-startStones};
});
run('P-07_API_impose_free_trade_twice_creates_rewards',W=>{
 const s=sect(W,2);const before=stones(W);
 const a=EXPED.applySiegeResolution(W,s.id,'FREE_TRADE',{}),b=EXPED.applySiegeResolution(W,s.id,'FREE_TRADE',{});
 return {first:a.ok,second:b.ok,totalGain:stones(W)-before,treaty:s.treaty};
});
run('P-08_rebellion_cascade_stale_ledger',W=>{
 const a=sect(W,0),b=sect(W,1);
 for(const s of [a,b]){CONTENT.forceVassalTreaty(W,s.id,{force:true});s.isVassal=true;s.loyalty=10;}
 const before={a:W.world.politics.treaties[a.id]?.type,b:W.world.politics.treaties[b.id]?.type};
 const res=EXPED.triggerVassalRebellion(W,a.id);
 return {before,rebelled:res.rebelled,coalitionIds:res.coalitionIds,after:{aTreaty:a.treaty,aLedger:W.world.politics.treaties[a.id]?.type,bTreaty:b.treaty,bLedger:W.world.politics.treaties[b.id]?.type,bVassal:b.isVassal}};
});
run('P-09_API_distress_reinforce_without_call_party_cost',W=>{
 const s=sect(W,1); EXPED.applySiegeResolution(W,s.id,'SUBJUGATE',{});
 const beforeFame=W.sect.fame,beforeStones=stones(W);
 const a=EXPED.respondVassalDistress(W,s.id,'REINFORCE',[]); const b=EXPED.respondVassalDistress(W,s.id,'REINFORCE',[]);
 return {first:a.ok,second:b.ok,deltaFame:W.sect.fame-beforeFame,deltaStones:stones(W)-beforeStones,calls:W.world.vassalDistressCalls.length,sLoyalty:s.loyalty};
});
run('P-10_API_council_repeat_same_day',W=>{
 const align='RIGHTEOUS';const before=W.world.chronicles.length;const a=EXPED.tickAllianceCouncil(W,{alignment:align});const b=EXPED.tickAllianceCouncil(W,{alignment:align});
 return {first:a&&a.kind,second:b&&b.kind,chroniclesAdded:W.world.chronicles.length-before,day:W.day};
});
run('P-11_API_deceased_master_repeat_kill',W=>{
 const s=sect(W,0),fig=s.figures.master,prior=(s.successionHistory||[]).length;
 const r1=EXPED.killJianghuFigure(W,fig,'audit',{});const m1=s.figures.master.id;
 const r2=EXPED.killJianghuFigure(W,fig,'audit',{});const m2=s.figures.master.id;
 return {first:r1.ok,second:r2.ok,master1:m1,master2:m2,historyAdded:(s.successionHistory||[]).length-prior,oldMasterDead:fig.dead};
});
console.log(JSON.stringify(results,null,2));
