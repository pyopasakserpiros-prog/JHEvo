'use strict';
const fs=require('node:fs'), path=require('node:path');
const candidates=[process.env.JIANGHU_GAME_SOURCE,process.cwd(),path.resolve(process.cwd(),'GAME_SOURCE'),path.resolve(__dirname,'../../GAME_SOURCE'),path.resolve(__dirname,'../../../GAME_SOURCE')].filter(Boolean);
const sourceRoot=candidates.find(p=>fs.existsSync(path.join(p,'test','load.js')));
if(!sourceRoot) throw new Error('Missing GAME_SOURCE; set JIANGHU_GAME_SOURCE=/path/to/GAME_SOURCE');
const G=require(path.join(sourceRoot,'test','load.js'));
const {SIM,EXPED,SECT}=G;
const rows=[];let seq=0;
function test(id,fn){try{const W=SIM.create('political-depth-'+(++seq));EXPED.ensureWorldTopology(W);rows.push({id,status:'ran',result:fn(W)});}catch(e){rows.push({id,status:'error',error:String(e.stack||e)});}}
test('P-12_UI_policy_lenient_repeat_increases_loyalty_free',W=>{
 const s=W.world.allSects[0];EXPED.applySiegeResolution(W,s.id,'SUBJUGATE');s.loyalty=21;
 const v0=s.loyalty;const res=[];for(let i=0;i<14;i++)res.push(EXPED.setVassalTributePolicy(W,s.id,'LENIENT'));
 return {initial:v0,final:s.loyalty,requests:res.length,allOk:res.every(x=>x.ok),tributePolicy:s.tributePolicy};
});
test('P-13_UI_exchange_disciple_repeat_instant_180_cult',W=>{
 const n=W.npcs.find(n=>n.id!==W.sect.masterId), initial={stones:W.sect.stones,att:W.world.allSects[0].attitude,exps:W.sect.exchangeDisciples&&W.sect.exchangeDisciples.length||0,prog:n.cult&&n.cult.prog};
 const out=[];for(let i=0;i<3;i++)out.push(SECT.dispatchExchangeDisciple(W,null,null,{}));
 return {initial,after:{stones:W.sect.stones,att:W.world.allSects[0].attitude,exps:W.sect.exchangeDisciples.length,prog:n.cult&&n.cult.prog,away:n.away},success:out.map(x=>x.ok),recordIds:out.map(x=>x.exchange&&x.exchange.id),recordStatuses:out.map(x=>x.exchange&&x.exchange.status)};
});
test('P-14_API_duel_rebel_always_loses',W=>{
 const non=W.npcs.find(n=>n.id!==W.sect.masterId);const master=W.byId[W.sect.masterId];
 const beforePower={master:G.CULT.power(master),rebel:G.CULT.power(non)};
 const t=SECT.triggerFactionSchismCrisis(W,{leaderId:non.id});
 const a=SECT.resolveFactionSchism(W,'SEAL_DUEL');
 return {beforePower,triggered:t.ok,result:a.mode,masterWon:a.masterWon,code:'masterPow * 1.15 >= rebelPow || true'};
});
test('P-15_API_splinter_leaves_rebels_as_active_player_npcs',W=>{
 const r=SECT.triggerFactionSchismCrisis(W,{});const before=r.crisis.rebelIds.slice();const s=SECT.resolveFactionSchism(W,'SPLINTER');
 return {resolved:s.ok,ids:before,stillInRoster:before.filter(id=>W.npcs.some(n=>n.id===id)),away:before.map(id=>({id,away:W.byId[id]&&W.byId[id].away,exiled:W.byId[id]&&W.byId[id].exiled})),splinterCount:W.world.splinterSects.length,existsInAllSects:W.world.allSects.some(x=>x.id===s.splinterSect.id)};
});
test('P-16_UI_coalition_instant_without_selected_target',W=>{
 const s=W.world.allSects[0], beforeExp=(W.world.expeds||[]).length;
 const out=EXPED.launchCoalitionOffensive(W,null,s.id,null,{allowSoloFallback:true});
 return {success:out.ok,won:out.won,skippedTravel:out.queued!==true,expeditionAdded:(W.world.expeds||[]).length-beforeExp,target:s.id,allies:(out.coalitionAllies||[]).length,states:(W.world.sieges||[]).slice(0,1).map(s=>s.status),source:'UI.launch-coalition-offensive has no data-arg and passes no immediate option'};
});
test('P-17_siege_3_phase_winProb_not_probabilistic',W=>{
 const s=W.world.allSects[0];const r=EXPED.marshalStrikeForce(W,null,s.id,{immediate:true});
 return {ok:r.ok,won:r.won,phases:(r.phases||[]).map(p=>({phase:p.phase,winProb:p.winProb,won:p.won})),formula:'phaseXWon = attack >= defense * threshold, ignores winProb except display'};
});
test('P-18_schism_overpay_creates_world_currency_without_player_debit',W=>{
 W.sect.stones=1; const r=SECT.triggerFactionSchismCrisis(W,{demandedStones:1000}); const pool0=(W.world.resourcePool&&W.world.resourcePool.stones)||0;
 const x=SECT.resolveFactionSchism(W,'NEGOTIATE',{stones:1000});return {trigger:r.ok,success:x.ok,paidStones:x.paidStones,playerStones:W.sect.stones,poolIncrease:W.world.resourcePool.stones-pool0};
});
console.log(JSON.stringify({cases:rows},null,2));
