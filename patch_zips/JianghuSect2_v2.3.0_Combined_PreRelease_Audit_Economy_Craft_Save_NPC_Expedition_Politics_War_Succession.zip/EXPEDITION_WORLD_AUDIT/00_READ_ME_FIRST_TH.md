# อ่านก่อน — ชุดตรวจรวม JianghuSect2 v2.3.0

ชุด ZIP นี้รวมรายงานเดิม 81 รายการไว้ครบและเพิ่มรายงาน **Expedition / Exploration / World Events** ใน `EXPEDITION_WORLD_AUDIT/`.

- เปิด `01_DEEP_FINDINGS_TH.md` เพื่ออ่านหลักฐานแต่ละจุด
- เปิด `02_CROSS_SYSTEM_CHAIN_TH.md` เพื่อดูผลกระทบลูกโซ่
- เปิด `03_TESTS_AND_COVERAGE_TH.md` เพื่อเห็นผลทดสอบจริง/ขีดจำกัด
- เปิด `04_AI_FIX_HANDOFF_TH.md` เพื่อส่งให้ AI ผู้แก้โค้ด
- เปิด `05_RELEASE_GATES_AND_NEXT_SCOPE_TH.md` เพื่อจัดลำดับก่อนปล่อย
- ไฟล์ `FINDINGS.csv`, `FINDINGS.json`, `REGRESSION_MATRIX.csv` นำเข้าเครื่องมือ QA ได้
- `EVIDENCE/repro_expedition.js` ใช้ node รันจาก **root ซอร์สต้นฉบับ**: `node /path/to/repro_expedition.js`; ไม่ใช่ซอร์สเกมที่แก้ไขแล้ว

**ข้อแม้:** แต่ละ probe ให้ผลลัพธ์ที่สังเกตได้ *บนแพ็กเกจ v2.3.0 ที่ผู้ใช้อัปโหลด* ไม่ใช่หลักฐานว่าผู้เล่นทุกคนทำผ่าน UI ได้; tests เดิมที่ผ่านไม่ได้พิสูจน์ว่า bugs ถูกแก้.

