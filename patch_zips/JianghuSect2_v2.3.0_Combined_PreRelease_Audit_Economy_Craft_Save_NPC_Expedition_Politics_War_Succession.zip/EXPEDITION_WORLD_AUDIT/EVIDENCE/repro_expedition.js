'use strict';
// Independent, focused probes against the uploaded v2.3.0 source; DO NOT mutate game source.
const path=require('path');
const root=process.env.JIANGHU_ROOT||process.cwd();
const G=require(path.join(root,'test/load.js'));
require(path.join(root,'js/ui.js'));
const {SIM,ECO,EXPED:X,EXPLORE:EX,SECT,UI,CULT}=G;
const results=[];
function testcase(id,fn){try{const result=fn();results.push({id,observed:true,...result});console.log('OBSERVED',id,JSON.stringify(result).slice(0,600))}catch(e){results.push({id,observed:false,error:e.stack||String(e)});console.log('UNCONFIRMED',id,e.message)}}
const newW=x=>SIM.create('exp-audit-'+x);
testcase('EX-01-HANDOVER-REFERENCEERROR',()=>{
 const W=newW('handover'),n=W.npcs[0],p=SECT.PATH_LIBRARY.getAllPathIds()[0];
 SECT.PATH_LIBRARY.unlockPath(W,p,{quiet:true});ECO.add(W,'MANUAL_PATH_'+p,2);
 const ex=X.depart(W,[n],'gather',X.REGIONS[0]);let caught='';
 try{X.resolve(W,ex,[n])}catch(e){caught=e.name+': '+e.message}
 const before={caught,done:ex.done,expId:n.expId,manual:ECO.count(W,'MANUAL_PATH_'+p),stones:W.sect.stones};
 const L=SIM.deserialize(SIM.serialize(W)),after={expId:L.byId[n.id].expId,away:L.byId[n.id].away,done:L.world.expeds.find(e=>e.id===ex.id)?.done};
 return {before,after};
});
testcase('EX-02-ATLAS-PRISONER-SELECTED',()=>{
 const W=newW('jailed'),node={kind:'EXPEDITION_REGION'},partyBefore=UI.atlasParty(W,node),n=partyBefore[0];n.jail=W.t+90000;
 const selected=UI.atlasParty(W,node).some(m=>m.id===n.id);
 const ex=X.depart(W,UI.atlasParty(W,node),'gather',X.REGIONS[0]);
 return {selected,jailUntil:n.jail,departureSucceeded:!!ex,memberExpId:n.expId,party:ex?.party};
});
testcase('EX-03-ANOMALY-DOUBLE-BOOK',()=>{
 const W=newW('anomaly-overlap'),n=W.npcs[0],first=X.depart(W,[n],'gather',X.REGIONS[0]);
 const anomaly=X.spawnWorldAnomaly(W,{durationDays:20});const second=X.departWorldAnomaly(W,[n],anomaly.id,{immediate:false});
 const state={firstId:first.id,secondOk:second.ok,secondId:second.expedition?.id,firstParty:first.party,expId:n.expId,firstState:first.state};
 if(second.ok){W.t=second.expedition.ret;X.hourly(W);state.after={firstState:first.state,firstDone:first.done,expId:n.expId,secondDone:second.expedition.done,firstRet:first.ret};}
 return state;
});
testcase('EX-04-SIEGE-DOUBLE-BOOK',()=>{
 const W=newW('siege-overlap'),n=W.npcs[0],first=X.depart(W,[n],'gather',X.REGIONS[0]);
 const target=W.world.allSects.find(s=>!s.isVassal);
 const second=X.marshalStrikeForce(W,[n],target.id,{immediate:false});
 return {firstId:first.id,secondOk:second.ok,secondId:second.expedition?.id,expId:n.expId,firstState:first.state};
});
testcase('EX-05-SECRET-REALM-REPEAT-REWARD',()=>{
 const W=newW('realm-replay'),realm=X.spawnSecretRealm(W,null,{quiet:true});
 const before=W.sect.stones,first=X.resolveSecretRealmRace(W,realm,{forcePlayerWin:true,quiet:true}),middle=W.sect.stones;
 const second=X.resolveSecretRealmRace(W,realm,{forcePlayerWin:true,quiet:true}),after=W.sect.stones;
 return {firstOk:first.ok,secondOk:second.ok,winFirst:first.winner?.entrantType,winSecond:second.winner?.entrantType,amountFirst:middle-before,amountSecond:after-middle,realmStatus:realm.status};
});
testcase('EX-06-SECRET-REALM-DEAD-ENTRANT',()=>{
 const W=newW('dead-entrant'),realm=X.spawnSecretRealm(W,null,{quiet:true});
 const entrant=realm.entrants.find(e=>e.entrantType==='PLAYER_SECT');const ids=entrant.npcIds.slice();
 ids.forEach(id=>W.byId[id].dead=true);
 const before=W.sect.stones,res=X.resolveSecretRealmRace(W,realm,{forcePlayerWin:true,quiet:true});
 return {everyoneOnTeamDead:ids.every(id=>W.byId[id].dead),winner:res.winner?.entrantType,earnedDespiteDead:W.sect.stones-before,ids};
});
testcase('EX-07-GARRISON-PHANTOM-POWER',()=>{
 const W=newW('phantom-garrison'),node=Object.values(W.world.resourceNodes)[0],n=W.npcs[0];
 node.ownerSectId='PLAYER';
 const res=X.assignNodeGarrison(W,node.id,{discipleIds:[n.id]});const pre={id:n.id,defense:node.garrison.defensePower,members:node.garrison.discipleIds.slice(),yield:node.garrison.yieldMultiplier};
 n.dead=true;const post={memberDead:n.dead,defense:node.garrison.defensePower,members:node.garrison.discipleIds.slice(),yield:node.garrison.yieldMultiplier};
 const cont=X.contestResourceNode(W,node.id,W.world.allSects[0].id,{attackerPower:pre.defense});
 return {pre,post,contestedWithDeadGuard:cont.defPower,expectedRemoveOnDeath:'recompute or remove dead guard'};
});
testcase('EX-08-DUPLICATE-PARTY-MEMBERS',()=>{
 const W=newW('dup-member'),n=W.npcs[0],party=X.createParty(W,[n,n]);const ex=X.depart(W,[n,n],'gather',X.REGIONS[0]);return {partyAccepted:party.ok,partyMembers:party.members.map(n=>n.id),expedition:ex?.party,unique:new Set(ex?.party||[]).size};
});
testcase('EX-09-CLOSED-REALM-API-DISPATCH',()=>{
 const W=newW('closed-gate'),n=W.npcs[0];W.explore.gate.open=false;W.explore.gate.world=EX.WORLDS[0].id;
 const ex=EX.depart(W,[n],'realm');return {canGo:EX.canGo(W),expeditionLaunched:!!ex,kind:ex?.kind,world:ex?.world};
});
testcase('EX-10-GARRISON-SAME-NPC-HOME-WORK',()=>{
 const W=newW('guard-home'),node=Object.values(W.world.resourceNodes)[0],n=W.npcs[0];node.ownerSectId='PLAYER';X.assignNodeGarrison(W,node.id,{discipleIds:[n.id]});
 return {guardAssigned:node.garrison.discipleIds.includes(n.id),npcAway:n.away,npcExpId:n.expId,npcTravel:n.travel,npcX:n.x,npcY:n.y};
});
testcase('EX-11-SANCTUM-UNKNOWN-TARGET-ALIAS',()=>{
 const W=newW('sanctum-wrong'),n=W.npcs[0],ex=EX.departSanctum(W,[n],'WRONG_SANCTUM_DOES_NOT_EXIST');
 return {invalidAccepted:!!ex,actualSanctumId:ex?.sanctumId};
});
testcase('EX-12-FORTUNE-RECIPE-UNLOCK-BEFORE-HANDOVER',()=>{
 const W=newW('fortune-early'),n=W.npcs[0],pools=Object.values(X.FORTUNE_REGISTRY).flatMap(x=>x).flatMap(site=>site.pools.map(pool=>({site,pool}))).filter(x=>x.pool.recipeIds?.length);
 const {site,pool}=pools[0];const rId=pool.recipeIds.find(id=>!W.sect.knownRecipes.includes(id))||pool.recipeIds[0];
 for(const key of ['SCRIPTURE','ALCHEMY','herbalism','mining','survival','diplomacy'])n.h.skills[key]=100;n.cult.stage=9;
 const ex={kind:'fortune',partyRank:site.rank,siteId:site.id,poolId:pool.id,journal:[]};const out={items:[],stones:0,mats:{},pills:{},gear:[],techs:[],notes:[],rep:0,recipes:[]};
 const prev=W.rng.gauss;W.rng.gauss=()=>100;
 try{X.fortuneEvent(W,ex,[n],out,X.REGIONS[0]);}finally{W.rng.gauss=prev}
 return {site:site.id,pool:pool.id,recipeId:rId,alreadyUnlockedBeforeReturn:W.sect.knownRecipes.includes(rId),discoveredInOut:out.recipes.includes(rId),hasHandoverReceipt:!!ex.settlement};
});
console.log('JSON_RESULTS_START');console.log(JSON.stringify(results,null,2));
