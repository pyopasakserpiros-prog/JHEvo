import concurrent.futures, subprocess, json, pathlib, time
base=pathlib.Path('/mnt/data/econ_audit_work/GAME_SOURCE')
names=['exploration_replay.js','cave_pools.js','world_atlas.js','world_rank.js','content_economy.js','v210_pagoda_warbeasts_conference_suite.js','v218_world_map_hegemony_beasts_suite.js','v219_sect_tiers_alliances_internal_politics_suite.js','v311_economy_dungeon_and_peaks_invariants_suite.js','v400_living_frontier_and_sect_charter_suite.js','v350_macro_world_politics_and_alchemy_suite.js','v330_living_sect_and_daily_loop_suite.js','v200_jianghusect2_grand_dao_epoch_suite.js','v410_sect_expansion_and_architecture_suite.js','explore.js','save_integrity.js','world_atlas_standalone.js']
def run(idx,name):
 args=['node', 'test/'+name];
 if name=='explore.js':args+=['7','audit-tiny-7', '0']
 t=time.time()
 try:
  r=subprocess.run(args,cwd=base,timeout=50,text=True,capture_output=True)
  status='PASS' if r.returncode==0 else 'FAIL';return dict(index=idx,test=name,status=status,exit=r.returncode,seconds=round(time.time()-t,2),tail=(r.stdout+'\n'+r.stderr)[-500:])
 except subprocess.TimeoutExpired as e:return dict(index=idx,test=name,status='TIMEOUT',seconds=round(time.time()-t,2),tail=str(e))
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(run,i,name) for i,name in enumerate(names)]
 for f in concurrent.futures.as_completed(futures):
  r=f.result();results.append(r);print(r['status'],r['test'],r['seconds'],flush=True)
results.sort(key=lambda r:r['index'])
pathlib.Path('/mnt/data/expedition_audit_work/focused_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('SUMMARY', {x:sum(r['status']==x for r in results) for x in ['PASS','FAIL','TIMEOUT']},flush=True)
