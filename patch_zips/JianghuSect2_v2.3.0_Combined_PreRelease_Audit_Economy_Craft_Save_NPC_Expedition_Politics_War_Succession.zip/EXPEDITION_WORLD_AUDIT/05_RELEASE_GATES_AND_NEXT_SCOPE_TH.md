# Release gates / Scope ownership / ระบบถัดไปเพียงหนึ่งหมวด

**สถานะ:** NO-GO เฉพาะพฤติกรรม Expedition/World Events ณ build ที่ตรวจ เพราะ EX-01 ทำให้คณะ NPC ค้างถาวรหลัง handover; รองลงมาความไม่สอดคล้องของ exclusive dispatch และ world settlement.

## คนรับผิดชอบที่ควรประสานงาน
- Expedition/World UI: central eligibility and idempotent mission handover.
- Save owner (ตรวจแล้วในแชทเดิม): migration/reconcile orphan expId, settlement receipt across deserialize.
- NPC AI owner (ตรวจแล้ว): keep scheduler from interrupting/exploiting mission leases.
- Economy and crafting owner (ตรวจแล้ว): verify sales/rewards/formula choice exactly once.
- Other chat (paths/subpaths/equipment): ไม่ตรวจซ้ำ; เฉพาะการคืนคัมภีร์และ world reward contract จะต้องแจ้งเจ้าของระบบ.

## ระบบถัดไปที่แนะนำ: การเมืองโลกและความสัมพันธ์ระหว่างสำนัก
**World Politics / Diplomacy / Alliances / War & Succession** — ตรวจ *หนึ่งหมวดในรอบต่อไป* โดยไม่ย้อนครอบงาน Expedition อีกครั้ง. เหตุผล: จากการตรวจนี้ siege, node contests, secret realm rivalry และ prestige มีผลย้อนสู่สงคราม ความเป็นพันธมิตร การแบ่งอำนาจ การสืบทอด และ NPC/world consequences; หาก flag การเมืองไม่ตรง world simulation อาจขยายความผิดเป็นหลายสำนัก/หลายปีเกม.

สิ่งที่จะตรวจในหมวดนั้น: รอบชีวิตสงครามและสัญญา, ความสมเหตุสมผลทางการทูต, conflict/peace/truce cooldown, สืบทอดเมื่อประมุขตาย, AI faction decision, เอฟเฟกต์เศรษฐกิจ/สถานะลูกสำนัก, เพดานอิทธิพล, atomic settlement และ replays; ไม่ตรวจการเดินทางหรือการคราฟต์ซ้ำ เว้น test interface.
