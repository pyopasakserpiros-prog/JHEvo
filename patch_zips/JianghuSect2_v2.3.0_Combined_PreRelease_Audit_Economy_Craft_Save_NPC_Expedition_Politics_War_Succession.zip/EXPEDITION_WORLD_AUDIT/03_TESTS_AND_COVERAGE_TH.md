# Test evidence, coverage & limitations

## Tests executed
- Targeted `repro_expedition.js`: **12/12 OBSERVED**; เป็นการพิสูจน์สถานะผิดโดยตั้งค่า fixture ตามแต่ละกรณี, ไม่ใช่ test ที่ควร PASS หลังแพตช์ (หลังแก้ควรได้ behavior อื่น)
- Existing focused suites: **17/17 PASS**, 0 FAIL, 0 TIMEOUT. JSON รายรายการใน `EVIDENCE/focused_results.json`.
- `node tools/validate_data_schema.js`: **Errors: 0; Warnings: 0**.
- `node test/explore.js 30 world-audit-a 0`: รันสำเร็จ; at end deaths=0, stones=838, gate opened once, ไม่มีการบังคับคณะสำรวจด้วยมือ.
- `node test/explore.js 30 world-audit-b 0`: รันสำเร็จ; at end deaths=0, stones=839, gate opened once, ไม่มีการบังคับคณะสำรวจด้วยมือ.
- เพิ่มกรณี real `AI.kill()` หลังมอบหมาย guard: defensePower ค้าง **529→529**, guardId ผู้ตายยังอยู่.

## Controls / สิ่งที่ไม่ควรทำให้เสีย
- `test/exploration_replay.js` มี positive control ที่ป้องกันการจ่ายซ้ำสำหรับ cave/delve และ realm; ผ่านแล้ว **อย่านำมาเหมารวม** ว่า secret realm contest ซึ่งใช้ resolver คนละตัวไม่มี bug.
- UI atlas ใช้ predicate กรอง away/expId/travel ในกรณีทั่วไป ทำให้ API double-book บางประเภทไม่ใช่ UI exploit ที่พิสูจน์แล้ว.
- AI death workflow มีการคืนทรัพย์สิน/สืบทอด; การแก้ guard ต้องไม่แตะ logic มรดก/สืบทอดที่ทำงานอยู่.

## ไม่ได้รับรอง / ยังไม่ทดสอบ
- ไม่มี Playwright click test ของปุ่มโลกผ่านเบราว์เซอร์จริง; ตรวจจาก caller UI และ API.
- ไม่มี simulation 90–360 วันหลาย seed ครบทุก event; 30d passive ไม่ครอบคลุมการแย่งชิงและการบาดเจ็บ/ตายภารกิจ.
- ไม่ได้พิสูจน์ exploit ผ่านผู้เล่นสำหรับ EX-03,04,05,08,09,11 และ scenario dead entrant force-win.
- ไม่ได้พิสูจน์ว่านโยบาย outpost guard และการเลือกสูตรต้องออกแบบอย่างไร; ใส่เป็น design decision.
- ไม่ได้รัน regression หลัง patch เนื่องจากไม่ได้แก้ source.

## การทำซ้ำ
วางซอร์สเกม v2.3.0 ที่ root แล้วรัน `node /path/to/repro_expedition.js` โดยมี Node.js; repro script จะใช้ `process.cwd()` เป็น root โดยปริยาย หรือ `JIANGHU_ROOT=/path/to/source`. จากนั้นรัน `python EVIDENCE/run_focused.py` (ชี้ base ไป root), `node tools/validate_data_schema.js`, และ Playwright UI tests เพิ่มก่อน release.
