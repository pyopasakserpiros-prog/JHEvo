# ผลกระทบเป็นลูกโซ่และวงจรย้อนกลับ

## A — ภารกิจสำเร็จแต่ NPC ไม่กลับ (EX-01)
คณะสำรวจ → เจอคัมภีร์ซ้ำ → SELL surplus ถอนคลัง/เพิ่มศิลาก่อน → ReferenceError ระหว่าง handover → ex.done ถูกตั้ง แต่ NPC.expId ค้าง → ระบบ NPC คิดว่าคนติดภารกิจ → ขาดแรงงาน/กำลังรบ/เจ้าหน้าที่ → งานผลิต การคุมโหนด และการจัดเวรลดลง → ความต้องการเศรษฐกิจ/โอกาสสำรวจเปลี่ยน → SAVE persistence ของสถานะเสียหาย → โหลดกลับมาก็ยังค้าง

**ทางแก้ไม่ใช่เพียงประกาศ sold:** ต้องตรวจ settlement atomicity, exit/return cleanup, duplicate-pay prevention, receipt, log, และ rescue migration สำหรับเซฟที่มี ex.done=true แต่ npc.expId ชี้ ex เดิม

## B — ส่งคนที่ไม่ว่างซ้อน (EX-02, 03, 04, 08, 09)
ข้อจำกัด jail/mission/gate แยกกติกากัน → dispatch ประเภทต่าง ๆ ใช้ predicate ไม่เหมือนกัน → ส่งคนพร้อมกัน/นักโทษเดินทาง → expId ทับและ RNG/เวลาภารกิจสองสาย → ได้รางวัล บาดเจ็บ เสียชีวิต หรือกลับบ้านในลำดับขัดแย้ง → AI scheduler เห็นสถานะผิด → เซฟเก็บโลกที่มีหลายคณะอ้างคนเดียว

**กฎกลางที่เสนอ:** one-live-NPC-one-exclusive-deployment, unique party IDs, alive/not-jailed/not-exiled/available plus medical/recovery flags, immutable mission lease id และ transactional release; พิจารณาว่ากองรักษาการเป็น exclusive หรือ abstract support

## C — โลกจำลองเห็น 'คนตายยังรบและให้ผลผลิต' (EX-06, 07, 10)
แยก snapshot power จาก life state จริง → death succession/healing/exile ไม่ invalidate expedition team/garrison → world event ใช้พลังเดิม → ชนะศึกและแร่เพิ่มอย่างไม่ต้องมีคน → เศรษฐกิจและอำนาจสำนักสะสมโดยไม่จ่าย opportunity cost → ความแตกต่างระหว่างเรื่องเล่ากับผล simulation เพิ่มขึ้น

**tradeoff:** ไม่ควรลบ static fortification/base defense; กำหนดว่าพลังใดเป็น fortification vs live troop vs beast. แดนลับ 12 วันอาจตั้งใจใช้ snapshot ตอนสมัคร ต้องเขียนกฎและผลเมื่อทีมถอนตัวตายอย่างชัดเจน

## D — จ่ายรางวัลซ้ำและรางวัลข้ามขั้นตอน (EX-05, 12)
World event OPEN→RESOLVED ควร commit ครั้งเดียว แต่ resolver ที่รับ object โดยไม่เช็ก status อาจจ่ายซ้ำ → หิน/อิทธิพล/ประวัติศาสตร์ซ้ำ → ฝั่งอื่นเห็นโลกไม่สอดคล้อง; ฝั่ง fortune เขียน knownRecipes ก่อนยืนยันของกลับสำนัก → สูตรใหม่/CP/บันทึกเรื่องราวและทางเลือกการบริจาคไม่ตรงกัน

**API invariants ก่อนปล่อย:** settle once / exactly-once observable effect; replay must be no-op; handover receipt must be idempotent and survive save/load; chain monitor `expId`, `ex.done`, stock deltas, source of gems/stones, chronicle IDs.

## มุมมองผู้เล่น
- บริหารสำนัก: คนหายหลังภารกิจที่เสร็จ, กำลังโหนดแร่ค้าง, คำสั่งเดินทางผ่านนักโทษ
- คนชอบสำรวจ: ประตูปิดแต่มีภารกิจ, แดนทดสอบไม่ตรงที่สั่ง, คนตายยังชนะและรับสมบัติ
- คนวางแผนทรัพยากร: บัญชีรางวัลซ้ำ/ขาดรายได้, สูตรใหม่ข้ามขั้นตอนบริจาค, กำลังศึกลวง
- คนเฝ้าดูโลก: เรื่องเล่าผู้ตาย/การเคลื่อนทัพผิดเวลา, สำนักคู่แข่งได้รับผลจากเหตุการณ์ที่ replay อีกครั้ง
- QA/เซฟ: แอ็กชันขาด atomicity, duplicate dispatch และ state migration ของโลกเก่าที่ติดค้าง
