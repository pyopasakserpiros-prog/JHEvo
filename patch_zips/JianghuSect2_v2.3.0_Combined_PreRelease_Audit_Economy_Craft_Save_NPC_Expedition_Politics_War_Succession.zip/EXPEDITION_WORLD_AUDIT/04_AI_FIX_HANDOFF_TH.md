# Handoff สำหรับ AI ที่แก้โค้ด — ไม่ให้แค่ patch แล้วจบ

## กฎเริ่มงาน
1. อ่าน `AGENTS.md` และ `.agents/skills/procedural-gen/SKILL.md`, `ai-behavior-patterns`, `game-data-integrity`, `gameplay-architecture`, `economy-balancing`, `game-ui-ux` ตามขอบเขต.
2. ตรวจซอร์สต้นทาง v2.3.0 ที่ผู้ใช้มอบให้กับ `01_DEEP_FINDINGS_TH.md` ก่อนแก้ อย่าคัดลอกเลขบรรทัดจากรายงานโดยไม่เช็ก.
3. ไม่แตะวิถี/สายย่อย/อุปกรณ์ (มีทีมตรวจอื่น) ยกเว้นเชื่อม interface ที่จำเป็น; รายงาน upstream contract ให้ทีมเจ้าของระบบพิจารณา.
4. เพิ่ม tests ทั้ง unit, integration, UI, replay and save-load. ทุกกรณีใน `REGRESSION_MATRIX.csv` ต้องมีผล PASS/FAIL/SKIP พร้อมเหตุผล.

## ลำดับแก้
- **0. Hotfix EX-01:** ไม่มี `ReferenceError` เมื่อขายคัมภีร์ซ้ำ, cleanup NPC เสมอ, settlement idempotent. เพิ่ม remediation สำหรับเซฟจากรุ่นมีบัค (done ex + npc.expId references).
- **1. Central expedition eligibility / exclusive lease:** X.createParty, X.depart, EX.depart, X.departWorldAnomaly, X.marshalStrikeForce, X.departResourceClaim, UI.atlasParty, EX.departSanctum และ caller โลกต้องตรวจจากกฎเดียวกัน. Reject duplicate NPC and unrecognized IDs. ระวัง user-managed party, NPC volunteer AI, forced scripted storyline.
- **2. World-event settlement once:** resolveSecretRealmRace ต้องตรวจ OPEN, world ownership และ settlement token; ผล cronicle/stone/influence ต้องไม่ซ้ำแม้ retry/reload.
- **3. Garrison lifecycle:** live power/yield, NPC death, exile, travel, moving garrison, beast death, siege, autosave load. อย่าทำลาย base fortifications.
- **4. Design decisions:** 12-day realm snapshot vs live roster; remote garrison work availability; fortune formula immediate unlock vs handover choice. เขียน intent ก่อนแก้ API.
- **5. Validate gating:** realm cannot depart closed gate, sanctum invalid ID no silent fallback.

## วิธีออกแบบแก้ให้ตรงวงจร
- Transactional state machine: DRAFT→RESERVED→TRAVELLING→AWAY→RESOLVING→SETTLED→RETURNING→COMPLETED; มี recovery สำหรับ crash ระหว่างขั้นตอนและ guard ที่อ่าน ledger.
- Idempotency key ผูก {eventId, settlementType, version} พิมพ์ log ได้; payment and reward operations check once, avoid paid-but-not-returned state.
- แยก 'UI-list-ready' กับ 'API validates ready' แต่กฎแกนเดียวกันเพื่อป้องกัน callers ใหม่ bypass.
- Batch update เมื่อ AI.kill เพื่อ performance; garrison recalculation on usage หรือ when needed เพื่อลดงานทุก tick.
- Regression test ต้องมี both existing positive controls and targeted negative controls.

## เกณฑ์อนุมัติ Release
1. P0 และ P1 ทั้งหมดถูกแก้และทดสอบซ้ำ; P2 มี decision ที่ระบุผู้อนุมัติ.
2. ไม่มี pending expedition ที่ done=true แต่ NPC reference ค้างหลัง save/load; no duplicate lease per NPC.
3. Balances, recipes, manual counts, world chronicle, realm status and resource nodes remain consistent after replay, death, mid-tick interruption and reload.
4. Playwright click through atlas / realm / siege + 90-360 day multi-seed active event soak ต้องมี log หากไม่รันให้เป็น 'not verified' ไม่ใช่ PASS.
5. บันทึกการเปลี่ยนสัญญา API ให้ทีมตรวจ NPC AI, economy, save, crafting ทดสอบจุดเชื่อม; ไม่เพิ่มระบบใหม่ที่ไม่เกี่ยวกับ bugfix.
