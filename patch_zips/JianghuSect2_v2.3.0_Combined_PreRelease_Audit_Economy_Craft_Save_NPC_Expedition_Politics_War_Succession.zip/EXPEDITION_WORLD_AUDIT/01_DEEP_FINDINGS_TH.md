# Pre-release deep audit — การสำรวจ ภารกิจนอกสำนัก และเหตุการณ์โลก (JianghuSect2 v2.3.0)

**สถานะ:** รายงานตรวจสอบซอร์สและการทดสอบบนแพ็กเกจต้นฉบับเท่านั้น *ไม่ได้แก้ซอร์สเกม*  
**ขอบเขต:** EXPED, EXPLORE, Atlas UI caller, NPC availability, world anomalies, siege, secret realms, resource garrisons, fortune rewards, save boundary.  
**ไม่ตรวจซ้ำ:** วิถี สายย่อย อุปกรณ์ เศรษฐกิจ การคราฟต์ เซฟ และ NPC AI ในฐานะหมวดหลัก แต่ตรวจ integration ที่เป็นเหตุ–ผลกับการเดินทางโดยตรง  
**วิธีอ่าน:** P0 = ขวางการปล่อย; P1 = ควรแก้ก่อนปล่อย; P2 = ปรับปรุง/ทบทวนดีไซน์/ตรวจเพิ่ม; ผลรันยืนยันพฤติกรรมได้ แต่ไม่ได้พิสูจน์ว่า exploit ได้จากผู้เล่นทุกกรณี

## สรุปสำหรับตัดสินใจปล่อย

พบ 12 ประเด็น: **P0 1, P1 5, P2 6**. จุดขวางปล่อยคือการขายคัมภีร์ส่วนเกินระหว่างส่งมอบที่ทำให้คณะติดค้างจริงแม้ได้รับรายได้แล้ว; อีก 5 ประเด็น P1 กระทบการส่งคนที่ควรไม่ว่าง, รางวัลซ้ำจากแดนลับ และกองรักษาการที่ไม่สะท้อนการตายของ NPC. ปัญหาระบบปกติและ API ภายในถูกแยกสถานะเพื่อไม่กล่าวเกินความสามารถของผู้เล่น.

**ผลการทดสอบ:** 12 probes พบพฤติกรรมตามที่ระบุ, ชุดทดสอบเดิมเฉพาะระบบที่เกี่ยวข้อง **ผ่าน 17/17** และ `tools/validate_data_schema.js` **Errors 0, Warnings 0**; รัน simulation 30 วันเกม 2 seed ได้โดยไม่ crash แต่การรันดังกล่าว **ไม่มีการบังคับส่งคณะสำรวจในทุกวัน** จึงไม่ใช่ soak test ครอบคลุมการแข่งขันแดนลับและการแย่งชิงจุด. ไม่มีการทดสอบคลิก UI บน Playwright และไม่จำลอง 90–360 วันทุกเหตุการณ์. *Test suites เดิมที่ผ่านไม่หักล้างบัคที่ probe ใหม่พบ*.

## ตารางสรุป

| ID | ความสำคัญ | ผลกระทบ | การเข้าถึง | ระดับหลักฐาน |
|---|---|---|---|---|
| EX-01 | P0 | คณะสำรวจขายคัมภีร์ส่วนเกินแล้ว crash ระหว่างคืน NPC | เส้นทางระบบปกติ; เมื่อขายคัมภีร์ส่วนเกินสำเร็จ | รันยืนยัน+ทดสอบเซฟ |
| EX-02 | P1 | ผู้ต้องโทษติดคุกถูกเลือกและส่งออกเดินทางผ่านหน้าจอ Atlas ได้ | มีเส้นทาง UI atlas-depart ในซอร์ส; ยังไม่ได้คลิกเบราว์เซอร์ | ทดสอบ API ที่ UI เรียก+ตรวจ caller UI |
| EX-03 | P1 | คณะสำรวจวาสนาฟ้าดินรับ NPC ที่ติดภารกิจอยู่แล้ว | API ภายใน; UI มักกรอง expId ไว้ | รันยืนยัน |
| EX-04 | P1 | ศึกตีสำนักซ้อนกับภารกิจเดินทางเดิม | API ภายใน; UI atlas เลือกทีมที่ไม่ติด expId | รันยืนยัน |
| EX-05 | P1 | ตัดสินแดนลับโบราณซ้ำแล้วจ่ายรางวัลซ้ำได้ | API ภายใน; daily scheduler จำกัด OPEN และ UI สร้าง event ใหม่ | รันยืนยัน |
| EX-06 | P2 | ผู้ร่วมชิงแดนลับเสียชีวิตก่อนจบ แต่พลังจาก snapshot ยังนับ | เหตุการณ์โลกอัตโนมัติ; ตัวทดสอบใช้ forcePlayerWin จึงไม่ได้พิสูจน์โอกาสชนะตามธรรมชาติ | ทดสอบ synthetic fixture + ตรวจโค้ด |
| EX-07 | P1 | NPC ผู้รักษาจุดทรัพยากรตายแล้ว แต่พลังป้องกันและโบนัสผลผลิตยังคงเดิม | เหตุการณ์โลก/การเสียชีวิตจริงข้ามระบบ | รันยืนยันทั้ง set dead และ AI.kill จริง |
| EX-08 | P2 | API สร้างคณะรับ NPC คนเดียวซ้ำเป็นสองสมาชิก | API ภายใน ไม่ได้ยืนยันการเกิดผ่าน UI | รันยืนยัน |
| EX-09 | P2 | API เดินทางผ่านประตูมิติปิดได้ | API ภายใน; EX.tryVolunteer มีกฎ canGo | รันยืนยัน |
| EX-10 | P2 | NPC ที่มอบหมายประจำจุดทรัพยากรยังใช้ชีวิตและทำงานในสำนักพร้อมกัน | ระบบ world node + NPC AI; อาจเป็น abstraction ที่ตั้งใจ | เห็นข้อมูลสถานะจริง; การตัดสินว่า bug ขึ้นกับดีไซน์ |
| EX-11 | P2 | ระบุแดนทดสอบผิดรหัสแต่ระบบส่งไปอีกแดนหนึ่งแทน | API ภายใน; UI ส่ง node ที่มีอยู่ | รันยืนยัน |
| EX-12 | P2 | วาสนาเพิ่มสูตรเข้า knownRecipes ก่อนขั้นส่งมอบและรับผลตอบแทน | เส้นทางรางวัลคณะสำรวจ; ต้องตรวจความตั้งใจสูตร/CP ก่อนเปลี่ยน | รันยืนยัน+ตรวจ content handover |

## รายละเอียดรายประเด็น

### EX-01 · P0 — คณะสำรวจขายคัมภีร์ส่วนเกินแล้ว crash ระหว่างคืน NPC

**เส้นทาง / Exposure:** เส้นทางระบบปกติ; เมื่อขายคัมภีร์ส่วนเกินสำเร็จ  
**หลักฐาน:** รันยืนยัน+ทดสอบเซฟ  
**ไฟล์/บรรทัด:** `js/expedition.js:485-507`, `js/expedition.js:807-822`, `js/sect.js:16120-16150`

**กลไกผิด:** X.handover ขายคัมภีร์แล้วบวก surp.revenueStones ลงตัวแปร sold ที่ไม่ประกาศ เกิด ReferenceError ภายใต้ strict mode; X.resolve กำหนด ex.done=true ไปก่อนแล้ว จึงขัดจังหวะการล้าง expId/travel ของสมาชิก

**สิ่งที่ทดสอบพบ:** ทดลองปลดล็อกวิถีและเพิ่มคัมภีร์ 2 เล่ม: ขายได้ +2040 ศิลา, คัมภีร์ถูกหัก, ReferenceError, ex.done=true และ npc.expId=1; หลัง serialize/deserialize expId=1 ค้างอยู่

**ผลกระทบลูกโซ่:** ผลผลิตสำรวจ → ขายคัมภีร์ → เงินเปลี่ยนแล้ว → runtime exception → ไม่คืน NPC → แรงงานหาย → ภารกิจ/อาหาร/งานสำนักชะงัก → เซฟค้าง

**แนวทางแก้โดยไม่กระทบระบบอื่น:** ห้ามใช้ตัวแปรที่ไม่ประกาศ; ย้ายการปิดงานและการคืน NPC ไปขั้นตอน finally/transactional settlement ที่ idempotent; แยก SOLD accounting กับ donation; ตรวจ return cleanup แม้ sale ล้มเหลว

**Regression acceptance:** เมื่อมี surplus ต้องจบคณะอย่างถูกต้อง, NPC กลับสำนัก, คัมภีร์และเงินปรับเพียงครั้งเดียว, โหลดซ้ำไม่ค้าง/ซ้ำ

### EX-02 · P1 — ผู้ต้องโทษติดคุกถูกเลือกและส่งออกเดินทางผ่านหน้าจอ Atlas ได้

**เส้นทาง / Exposure:** มีเส้นทาง UI atlas-depart ในซอร์ส; ยังไม่ได้คลิกเบราว์เซอร์  
**หลักฐาน:** ทดสอบ API ที่ UI เรียก+ตรวจ caller UI  
**ไฟล์/บรรทัด:** `js/ui.js:5280-5288`, `js/ui.js:2820-2834`, `js/expedition.js:254-258`

**กลไกผิด:** UI.atlasParty และ X.createParty ตรวจ dead/away/expId/travel แต่ไม่ตรวจ jail > W.t และข้อจำกัดความพร้อมที่เกี่ยวข้อง

**สิ่งที่ทดสอบพบ:** ตั้ง n.jail=W.t+90000 แล้ว n ยังอยู่ใน UI.atlasParty; X.depart รับคนดังกล่าวและสร้าง expId ได้

**ผลกระทบลูกโซ่:** คุกและวินัย → เลือกทีมสำรวจ → เดินทางได้ทั้งที่ยังติดโทษ → การคุมขังขาดความหมาย → กำลังศึก/รางวัลและงานสำนักบิดเบี้ยว

**แนวทางแก้โดยไม่กระทบระบบอื่น:** รวม predicate isAvailableForExpedition(W,n,mode) เดียวที่ UI และทุก API ใช้ ตรวจคุก บาดเจ็บ/รักษาตัว บังคับพัก exiled/travel/active mission พร้อมข้อความเหตุผล

**Regression acceptance:** NPC ติดคุกไม่อยู่ในรายชื่อพร้อมออกและสั่งเดินทางไม่ได้จาก API/UI; หลังพ้นโทษจึงกลับมาเลือกได้

### EX-03 · P1 — คณะสำรวจวาสนาฟ้าดินรับ NPC ที่ติดภารกิจอยู่แล้ว

**เส้นทาง / Exposure:** API ภายใน; UI มักกรอง expId ไว้  
**หลักฐาน:** รันยืนยัน  
**ไฟล์/บรรทัด:** `js/expedition.js:3166-3204`, `js/expedition.js:254-260`

**กลไกผิด:** เมื่อระบุ party เอง departWorldAnomaly คัดแค่ !dead&&!away ไม่ตรวจ expId/travel และเขียน expId ใหม่ทับคณะแรก

**สิ่งที่ทดสอบพบ:** ส่ง gather id=1 แล้วส่ง world anomaly id=3 ด้วยคนเดียวกัน return ok; เมื่อเวลาไปถึง ret ภารกิจสองชุดลงสถานะ done ทั้งคู่

**ผลกระทบลูกโซ่:** สองคณะพร้อมกัน → รางวัล/ความเสี่ยงสองชั้น → expId ทับ → คืนคนผิดคณะ → ความสัมพันธ์กับเซฟและความก้าวหน้าผิด

**แนวทางแก้โดยไม่กระทบระบบอื่น:** บังคับ central availability + unique NPC reservation ก่อนออกทุกรูปแบบ; ปฏิเสธหรือยกเลิกคณะแรกอย่างมีธุรกรรม

**Regression acceptance:** คนใน gather ไม่สามารถเข้าสู่ anomaly หรือคณะอื่นจนจบและคืนตัว

### EX-04 · P1 — ศึกตีสำนักซ้อนกับภารกิจเดินทางเดิม

**เส้นทาง / Exposure:** API ภายใน; UI atlas เลือกทีมที่ไม่ติด expId  
**หลักฐาน:** รันยืนยัน  
**ไฟล์/บรรทัด:** `js/expedition.js:2450-2473`, `js/ui.js:2820-2829`

**กลไกผิด:** marshalStrikeForce กรองคนที่ส่งผ่าน array ด้วย !dead&&!away เท่านั้น ไม่กรอง !expId/!travel ก่อนสร้างคณะศึก

**สิ่งที่ทดสอบพบ:** หลังออก gather ยังเป็น leaving สามารถ marshalStrikeForce ด้วยคนเดียวกันได้สำเร็จ; expId ถูกเปลี่ยนเป็นคณะใหม่

**ผลกระทบลูกโซ่:** ทัพ/ภารกิจสองชุด → ความสามารถรบและบาดเจ็บสองทาง → สถานะอำนาจสำนักผิด → เกิดการคืนตัว/เซฟไม่สอดคล้อง

**แนวทางแก้โดยไม่กระทบระบบอื่น:** ใช้ one-NPC-one-active-deployment invariant ร่วมกับ EXPED, EXPLORE, siege, anomaly, resource claim

**Regression acceptance:** NPC ติดภารกิจใด ๆ ไม่สามารถถูกส่ง siege จนกว่าจะจบหรือถูกยกเลิกโดยสมบูรณ์

### EX-05 · P1 — ตัดสินแดนลับโบราณซ้ำแล้วจ่ายรางวัลซ้ำได้

**เส้นทาง / Exposure:** API ภายใน; daily scheduler จำกัด OPEN และ UI สร้าง event ใหม่  
**หลักฐาน:** รันยืนยัน  
**ไฟล์/บรรทัด:** `js/expedition.js:5199-5214`, `js/expedition.js:5274-5301`

**กลไกผิด:** resolveSecretRealmRace รับ object ของ realm RESOLVED โดยไม่ตรวจ status และไม่ทำ idempotency ก่อนจ่าย

**สิ่งที่ทดสอบพบ:** เรียก object เดิมสองครั้ง forcePlayerWin:true ได้ +580 ศิลาวิญญาณทั้งสองครั้ง; status RESOLVED แต่ second.ok=true

**ผลกระทบลูกโซ่:** เหตุการณ์โลก → รางวัลซ้ำ → เงิน/อิทธิพล/การบ่มเพาะเพิ่มผิด → สมดุลสำนัก/สงครามเปลี่ยน → บันทึกผลซ้ำใน chronicle

**แนวทางแก้โดยไม่กระทบระบบอื่น:** validate realm belongs to W, status OPEN, unique settlementId, settled ledger; ไม่ spawn เงียบหาก ID ไม่พบใน call ที่ควร resolve

**Regression acceptance:** เรียก realm เดิมหลัง RESOLVED และหลัง deserialize ต้องไม่เปลี่ยนทรัพยากร/ผลสงคราม/chronicle แม้เรียกซ้ำ

### EX-06 · P2 — ผู้ร่วมชิงแดนลับเสียชีวิตก่อนจบ แต่พลังจาก snapshot ยังนับ

**เส้นทาง / Exposure:** เหตุการณ์โลกอัตโนมัติ; ตัวทดสอบใช้ forcePlayerWin จึงไม่ได้พิสูจน์โอกาสชนะตามธรรมชาติ  
**หลักฐาน:** ทดสอบ synthetic fixture + ตรวจโค้ด  
**ไฟล์/บรรทัด:** `js/expedition.js:5140-5158`, `js/expedition.js:5199-5226`

**กลไกผิด:** spawn จับ snapshot npcIds,power; resolve หลัง 12 วันใช้ e.power โดยไม่ทบทวน alive/availability; actor dead แล้วอาจยังเป็นผู้ชนะ

**สิ่งที่ทดสอบพบ:** ตั้ง dead=true ให้ทุกคนในทีมก่อน resolve; fixture forcePlayerWin พบสำนักยังรับ +580

**ผลกระทบลูกโซ่:** ความตาย → ทีมไร้สมาชิก → ระบบประลองยังใช้พลังเก่า → รางวัล/ประวัติศาสตร์สวนทางกับโลก

**แนวทางแก้โดยไม่กระทบระบบอื่น:** กำหนดชัดว่าเป็นการแข่งขันช่วง 12 วันหรือ snapshot ณ วันเปิด; ถ้าเชื่อว่ามีการเดินทางจริง ให้ update alive/deployment และ re-score; ถ้าเป็น narrative snapshot ต้องบันทึกเหตุผล

**Regression acceptance:** กรณีทีมตาย/ถูกจองงานอื่นต้องให้ผลสอดคล้องกติกาที่ประกาศ โดยไม่จ่ายรางวัลจากผู้ตายโดยไม่อธิบาย

### EX-07 · P1 — NPC ผู้รักษาจุดทรัพยากรตายแล้ว แต่พลังป้องกันและโบนัสผลผลิตยังคงเดิม

**เส้นทาง / Exposure:** เหตุการณ์โลก/การเสียชีวิตจริงข้ามระบบ  
**หลักฐาน:** รันยืนยันทั้ง set dead และ AI.kill จริง  
**ไฟล์/บรรทัด:** `js/expedition.js:3011-3055`, `js/expedition.js:3059-3104`, `js/ai.js:1765-1831`

**กลไกผิด:** assignNodeGarrison snapshot defensePower/yieldMultiplier แต่ AI.kill ไม่ถอนสมาชิกหรือลดกำลัง; contest/harvest ใช้ snapshot ต่อ

**สิ่งที่ทดสอบพบ:** assign guardian n แล้ว AI.kill(W,n) พบ dead=true แต่ guardIds ยังมี id เดิม พลังป้องกันคง 529→529; test set dead โดยตรง 1776→1776, yield=1.1 ค้าง

**ผลกระทบลูกโซ่:** NPC ตาย → กองรักษาการผี → โหนดไม่เสียกำลัง/โบนัสทรัพยากร → สงครามแย่งจุด/เศรษฐกิจแร่เพี้ยน → ความสมเหตุสมผลโลกเสีย

**แนวทางแก้โดยไม่กระทบระบบอื่น:** คำนวณ live garrison effective power/yield ก่อน harvest/contest หรือ invalidate snapshot เมื่อ kill/exile/travel/relocate; อย่าลบ base defense ของป้อม

**Regression acceptance:** หลังตาย/ย้าย/ถอนกำลัง defense ลดเหลือค่าของกำลังที่มีชีวิตพร้อม base fortification, yield ลดตามคนที่อยู่จริง

### EX-08 · P2 — API สร้างคณะรับ NPC คนเดียวซ้ำเป็นสองสมาชิก

**เส้นทาง / Exposure:** API ภายใน ไม่ได้ยืนยันการเกิดผ่าน UI  
**หลักฐาน:** รันยืนยัน  
**ไฟล์/บรรทัด:** `js/expedition.js:254-260`

**กลไกผิด:** createParty ใช้ party.map/filter โดยไม่ uniqueness ของ npcId

**สิ่งที่ทดสอบพบ:** X.createParty(W,[n,n]) ok=true และ X.depart สร้าง ex.party=[id,id]

**ผลกระทบลูกโซ่:** รายชื่อสมาชิกซ้ำ → กำลัง/ค่าเสบียง/จำนวนรางวัลอาจคำนวณซ้ำ → encounter และ injury ไม่สมเหตุสมผล

**แนวทางแก้โดยไม่กระทบระบบอื่น:** deduplicate หรือ reject duplicate IDs ที่ boundary; คำนวณจาก stable unique ids

**Regression acceptance:** list มีสมาชิกซ้ำต้องถูกปฏิเสธหรือ normalize และไม่ขยายโอกาส/รางวัล

### EX-09 · P2 — API เดินทางผ่านประตูมิติปิดได้

**เส้นทาง / Exposure:** API ภายใน; EX.tryVolunteer มีกฎ canGo  
**หลักฐาน:** รันยืนยัน  
**ไฟล์/บรรทัด:** `js/explore.js:7179-7212`

**กลไกผิด:** EX.canGo(W) ตรวจ gate.open + เวลาคงเหลือ แต่ EX.depart(kind=realm) ไม่เรียก check

**สิ่งที่ทดสอบพบ:** ตั้ง gate.open=false แล้ว EX.canGo(W)=false แต่ EX.depart(W,[n],realm) สร้างคณะใหม่และนับ visits

**ผลกระทบลูกโซ่:** ประตูปิด → ภารกิจ realm ที่ไม่ควรมี → Codex/รางวัล/อันตรายผิดจังหวะ → เซฟมีคณะโลกปิด

**แนวทางแก้โดยไม่กระทบระบบอื่น:** enforce EX.canGo at EX.depart for realm; validate world and remaining lifetime independent UI

**Regression acceptance:** gate ปิด/เวลาเหลือน้อย/ไม่มี realm ID ต้องปฏิเสธโดยไม่มี resource/tick/visit side effect

### EX-10 · P2 — NPC ที่มอบหมายประจำจุดทรัพยากรยังใช้ชีวิตและทำงานในสำนักพร้อมกัน

**เส้นทาง / Exposure:** ระบบ world node + NPC AI; อาจเป็น abstraction ที่ตั้งใจ  
**หลักฐาน:** เห็นข้อมูลสถานะจริง; การตัดสินว่า bug ขึ้นกับดีไซน์  
**ไฟล์/บรรทัด:** `js/expedition.js:3011-3055`

**กลไกผิด:** assignNodeGarrison บันทึกแค่ discipleIds ไม่เปลี่ยน away,expId,travel,location

**สิ่งที่ทดสอบพบ:** NPC ที่อยู่ในกองรักษาการยังมี away=false expId=null travel=null และพิกัดอยู่สำนัก

**ผลกระทบลูกโซ่:** รักษาการพร้อมทำงานที่บ้าน → แรงงานดูเหมือนมีมากกว่าจริง → ผลผลิต/เวรยาม/กำลังคุ้มครองสูงเกินจริง

**แนวทางแก้โดยไม่กระทบระบบอื่น:** ตัดสิน abstraction: remote outpost จริงต้อง lock schedule + travel; abstract defense aura ต้องอธิบายและ balance ค่า opportunity cost

**Regression acceptance:** กติกากองรักษาการชัดเจน UI/AI พฤติกรรมสอดคล้อง และไม่มีการใช้คนเดียวในสองงาน exclusive

### EX-11 · P2 — ระบุแดนทดสอบผิดรหัสแต่ระบบส่งไปอีกแดนหนึ่งแทน

**เส้นทาง / Exposure:** API ภายใน; UI ส่ง node ที่มีอยู่  
**หลักฐาน:** รันยืนยัน  
**ไฟล์/บรรทัด:** `js/explore.js:7573-7579`

**กลไกผิด:** EX.departSanctum ใช้ default SANCTUM_SWORD_ABYSS เมื่อ ID ไม่รู้จัก แทน fail-closed

**สิ่งที่ทดสอบพบ:** ส่ง WRONG_SANCTUM_DOES_NOT_EXIST แล้วได้ ex.sanctumId=SANCTUM_SWORD_ABYSS

**ผลกระทบลูกโซ่:** รหัสปลายทางผิด → ภารกิจสำเร็จที่อื่น → บันทึกเนื้อเรื่อง/รางวัล/เส้นทางไม่ตรงคำสั่ง → debugging ยาก

**แนวทางแก้โดยไม่กระทบระบบอื่น:** reject unknown ID unless caller explicitly requests default; log descriptive reason

**Regression acceptance:** unknown sanctum ID ปฏิเสธไม่เปลี่ยน inventory/party/log; default explicit เท่านั้น

### EX-12 · P2 — วาสนาเพิ่มสูตรเข้า knownRecipes ก่อนขั้นส่งมอบและรับผลตอบแทน

**เส้นทาง / Exposure:** เส้นทางรางวัลคณะสำรวจ; ต้องตรวจความตั้งใจสูตร/CP ก่อนเปลี่ยน  
**หลักฐาน:** รันยืนยัน+ตรวจ content handover  
**ไฟล์/บรรทัด:** `js/expedition.js:514-590`, `js/content.js:1017-1060`

**กลไกผิด:** fortuneEvent เขียนสูตรตรงลง W.sect.knownRecipes ก่อน handover, แต่ handover skip สูตรที่รู้แล้ว; เสี่ยงข้ามขั้นตอนเลือกเก็บ/บริจาคและ event receipt

**สิ่งที่ทดสอบพบ:** pool f1_thorn_beast_lair ให้ REC_V222_EQ_01, knownRecipes เพิ่มแล้วก่อน X.handover; out.recipes บันทึกสูตรแต่ยังไม่มีใบส่งมอบ

**ผลกระทบลูกโซ่:** เจอสูตร → ปลดล็อกทันที → ทางเลือกรับ/บริจาคหาย → แต้มคุณูปการและบันทึกการค้นพบอาจคลาดเคลื่อน → ภาพรวมความก้าวหน้าไม่เป็นเหตุเป็นผล

**แนวทางแก้โดยไม่กระทบระบบอื่น:** กำหนด ownership transfer ชัด: discovery event เก็บ pending formula แล้วค่อย commit ใน handover; ถ้าตั้งใจ unlock ทันทีให้ handover รับรู้สถานะ discovered-now และลง receipt/CP อย่างถูกต้อง

**Regression acceptance:** สูตรใหม่หนึ่งสูตรถูก unlock 1 ครั้ง, ตัวเลือกและ CP มีผลตามกติกา, save/load ไม่ให้ receipt ซ้ำ
