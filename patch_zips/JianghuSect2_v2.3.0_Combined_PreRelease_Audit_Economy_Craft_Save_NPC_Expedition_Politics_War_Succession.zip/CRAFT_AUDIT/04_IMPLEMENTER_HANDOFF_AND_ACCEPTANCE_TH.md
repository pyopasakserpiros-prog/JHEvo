# 04 — คำสั่งส่งต่อ AI แก้โค้ด + Acceptance

**บริบท:** User ขอ audit อย่างเดียว (NO source edits), base SHA256 `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`. AI ผู้แก้ต้องเริ่มจาก `AGENTS.md`, `.agents/skills/game-data-integrity`, `economy-balancing`, `procedural-gen`, `save-system-patterns`, `qa-test-matrix`, `ai-behavior-patterns` และตรวจโค้ด source จริงก่อนเชื่อคำแนะนำนี้.

## แผนแก้แบบไม่ทำให้บัคย้ายที่

**Phase 1 — Fix P0 data-to-runtime recipe contract**

1. ออกแบบ canonical `normalizeRecipe(raw, outputItem)` หรือ schema importer ให้แปลง `out`, `station`, `price`, `kind`, `minMastery`, `outNameTh` เป็น `outType`, `craft`, `yield`, `valid output kind` แบบ deterministic. *ห้าม* default output missing เป็นของจริงโดยไม่ตรวจ kind/price.
2. แยก `EQUIPMENT`, `PILL`, `TALISMAN/CONSUMABLE`, `MATERIAL`, `BEAST_ITEM` และ category ที่เกมรองรับ พร้อม lifecycle/quality/stack/effect ตาม output.
3. ตรวจผลจาก `ECO.finishCraft`, `ECO.personalCraft`, NPC action `start/done`, merchant, inventory UI; โอกาสสำเร็จต้อง finite สำหรับ skill 0,50,100 และไม่ยอมให้คราฟต์ถ้า schema invalid.
4. เพิ่ม validation ที่ runtime registry, ไม่ใช่เฉพาะ concat arrays. เช่น `Number.isFinite(minMastery)`, `Number.isFinite(ECO.outputValue(...))` และ each output route. Migration ของ recipe IDs ต้องไม่ทำให้เซฟที่ยังมี recipeIDs ล้ม.

**Phase 2 — Finance/market data contract (แก้พร้อมรายงานเศรษฐกิจ)**

5. `ECO.outputValue` ใช้ canonical price/value fallback ห้าม NaN; head hall AI scores finite.
6. ห้าม `P:` key ที่ชี้ non-PILL. `EXT.buildStock`/`buildWants`, `EXT.isTradable`, `ECO.isPill`, `ECO.pillInfo` ควรใช้ validator ประเภทเดียวกัน. ต้องมี sanitize merchant inventories ที่เซฟเก่าของเวอร์ชันปัจจุบันอาจมี `P:non-pill` โดยไม่เพิ่มเงิน/ของใหม่. ทดสอบ trade logs และ CPE ledger.
7. ประสาน findings P0 จาก `AUDIT/` เศรษฐกิจ (เช่น free goods / caravan / NaN pay): แก้แต่ละเส้นทางตาม invariants เพื่อไม่ให้ของใหม่ปั๊มได้จากระบบที่ยังเปิดช่อง.

**Phase 3 — Source acquisition and source descriptions**

8. เพิ่ม provider ของ MAT_V230_001..024 ใน registry หรือรองรับ item material ผ่าน adapter เดียวกัน; confirm reward path per ID using actual runtime, not source hints. พิจารณาความยาก rare/gate/biome/world progression.
9. ตรวจ 67 สูตรพึ่ง 24 mat ทุก tier ด้วย seeded playable loops — unlocked, acquired, reserved, crafted, used/sold. เขียน expected days/tier scarcity spec ก่อนเพิ่ม drop rates.
10. ตัดสิน policy cancellation, partial refund, personal brew reservation, time skip spawn. UX แสดงต้นทุน/เหตุการล้มเหลวจริง.

**Phase 4 — Test/Rebuild/Report**

11. เขียน regression tests จาก `EVIDENCE/repro_release_crafting.js`: **สคริปต์นี้ยืนยันบัคเดิม** ดังนั้นจะ fail หลังแก้ — ต้องเขียน assertions ใหม่ตาม expected behavior, อย่าปรับให้ test ผ่านโดยซ่อนบัค.
12. รัน 13 suites ที่บันทึก, `node tools/validate_data_schema.js`, `node tools/run_parallel_tests.js` เมื่อทรัพยากรพอ, browser real flows และ seeded soak 7/30/90/360 วัน; ตัวเลขจากการรันจริงเท่านั้น.
13. บันทึก trade-offs ด้วยข้อมูล: crop speed, resource rarity, black market price, NPC advancement, safety stock, CP/stone sinks. ต้องรักษา `human_core.js` และลำดับโหลดตาม AGENTS.
14. จัดทำ PATCH CHANGELOG พร้อมผลก่อน/หลัง, เซฟก่อน/หลัง, schema/data ids changed, จำนวนสูตรแก้จริง, regressions, ข้อที่ยังทำไม่ได้. **อย่าอ้าง release-ready เมื่อยังไม่ผ่านทุก Gate**.

## Acceptance ที่ตรวจด้วย script ได้ทันที

```text
assert(recipeCount == 1118 or document intentional changes)
assert(invalidRuntimeRecipeSchema == 0)
assert(!Number.isNaN(successChance(n,r))) for all permitted recipes and skill band
assert(nonFiniteOutputValueCount == 0)
assert(all 24 MAT_V230 IDs have tested provider coverage or intentionally gated documented route)
assert(no pseudo P: alias for non-pill recipes in merchant and saved stock)
assert(new 48 kind=PILL items recognized in standard pill flow without duplicated effects)
assert(stockDelta + escrow + output + loss/refund reconciles per recipe)
assert(saveLoad(midAction) preserves ledger/action/stock and no duplicate output)
```

## ข้อควรระวัง

- สูตรผิด 415 กับ valuation ผิด 415 เป็นคนละปัญหา; แก้ schema อย่างเดียวจะปล่อย NaN อยู่ใน AI.
- 67 สูตรที่ขาด item-only materials ทั้งหมดอยู่ในกลุ่ม 415; แก้ provider อย่างเดียวสูตรก็ยังคราฟต์ไม่ได้.
- `ECO.useConsumableItem` อาจทำงานได้กับยาใหม่บางส่วน; อย่าลบหรือทำสองระบบใช้ยาในคราวเดียว.
- `registerCraft` ลบ receipt เก่ามีเทสต์เดิมคาดไว้: ต้องตัดสินนโยบายก่อนเปลี่ยน.
- `craftProceduralNow` ไม่พบ normal caller: อย่าเขียนว่าเป็น exploit ผู้เล่นที่พิสูจน์แล้ว.
