# 03 — Chain Reactions + Save/Economy Tests

## สายเหตุ–ผลที่พิสูจน์และสายเสี่ยง

### A. วัตถุดิบละลายเพราะสูตรผิด (รันยืนยัน)
`knownRecipe → ECO.craftEligible=true → ECO.reserveInputs ลด stock → ECO.successChance=NaN → roll < NaN false → finishCraft ไม่สร้างของ → คืนวัตถุดิบแบบสุ่มไม่ครบเสมอ → stock คงอยู่หลัง save/load`

ผลต่อระบบอื่น: วัตถุดิบสำรองลด → หอช่าง/หอหลอมขาดของ → NPC ซื้อเพิ่ม/เปลี่ยนงาน (ต้องทดสอบ decision tick) → ต้นทุนสำนักเพิ่ม → ยารักษา/อุปกรณ์ใหม่ขาด → ความเสี่ยงบาดเจ็บและเติบโตลด (เป็นผลที่ *คาด*, ยังไม่ได้จำลอง combat เฉพาะทาง).

### B. วงจรแหล่งวัตถุดิบแสดงแต่ไม่มี provider ใน pool (registry confirmed)
`Item-only 24 → source hints ประกาศว่าหาได้ → wild/exploration/market random อ่าน materials registry → ไม่ถูกสุ่ม → 67 recipes ขาด inputs → ไม่มี demand จากสูตรที่ AI skill gate มองไม่เห็น → fallback merchant buyList น้อยลง → deadlock ต่อเนื่อง`

เงื่อนไข: แหล่งจาก bespoke trial/quest/direct market request อาจมี; ห้ามสรุปว่าไม่มีทรัพยากรโดยเด็ดขาดจน trace ครบ.

### C. โอสถปลอมจากสูตรอื่น (รันยืนยัน)
`all recipe IDs → EXT.openVisit medicine pool P:recipeID → ECO.isPill prefix true → ECO.pillInfo any recipe returns {} → trader stock → player/NPC may purchase → ECO.usePill consumes → no actual medicinal effect → stock, money, NPC plan altered`

การทดสอบ fixed seed ของพ่อค้าขายยา 80 ครั้งได้ 67 สินค้าผิดประเภท; ควรใช้ seeds หลายชุดและตรวจ auto-buy, trade history, CP/stock.

### D. Valuation NaN → การผลิตไม่ตอบโจทย์ตลาด
`data item.price but no value → outputValue NaN → pickOrder score NaN → sort/choice unstable → produced item shortage not tracked correctly → buyList malformed/empty → market resources shift → recipes understocked`.

ปัจจุบันปัญหานี้ถูกบดบังบางส่วนโดย `minMastery` undefined; เมื่อแก้ P0 แต่ไม่แก้ valuation เส้นทางความผิดพลาดจะยังคงอยู่.

### E. Personal brew + mid-action interruptions
`personalBrew.start quote OK → other NPC consumes stock or CP changes → personalBrew.done quote null → action finished with no output and no failure log`. ใช้เป็น test scenario, **ยังไม่พิสูจน์ end-to-end UI ในทุกสถานการณ์**.

### F. Save/load boundary
ตรวจก่อน/หลังเซฟของ 1) `sect.stock`, 2) `sect.stones`, 3) `sect.craftTransactions.open`, 4) `npc.act.ctx.craftReceipt`, 5) `sect.gear`, 6) `npc.inv.craftedPills`, 7) `npc.ext.multiPhasePills`/`pendingPillPhases`, 8) market visitor `stock` และ `tradeHistory`, 9) `knownRecipes`, 10) output item aliases. อย่าย้อนคืนของที่เคยใช้แล้วหรือผลิตซ้ำหลังโหลด.

## Test matrix ที่ต้องผ่านก่อน RELEASE

| กรณี | Expected invariant | ระดับ |
|---|---|---|
| ทุก 1118 สูตร (schema contract) | ไม่มี `undefined` ใน required runtime fields; all outputs valid | P0 |
| 415 สูตรซึ่งเดิมผิด (NPC actual craft) | skill 0–100 chance finite, no invalid/forced failed; output right kind | P0 |
| 24 special materials | อย่างน้อยหนึ่ง intended reachable provider per gated ID; drop log clear | P1 |
| ทุก recipe's output valuation | finite price/cost/scores and explicit fallback | P1 |
| ร้านยา 1000 visits × 5 seeds | 0 pseudo pills representing non-PILL recipe | P1 |
| โอสถ 48 สูตร (2-phase) | correct pill handling, no duplicate buffs, delayed effect happens once | P1 |
| ยกเลิกและสั่งงานแทนซ้ำ | receipt settled exactly once, chosen refund policy applied once | P1/P2 |
| ส่วนตัวใช้ owned + bought | CP/stock exactly deducted; no arbitrage from generated items | P1 |
| Save/load ระหว่างงาน | no duplication/no loss outside explicit failure rules; pause/resume stable | P0/P1 |
| 7/30/90/360 in-game days × seeds | all finite counters, no shortage deadlock; record per-day supply/demand | P1 |
| Browser real UI | manual player forge, brew, pill use, trader buy, stock UI feedback | P1 |
| Performance with item catalog/AI tick | bounded ticks, no expensive scan per NPC each frame | P2 |

## Release data metrics ที่ต้องเก็บ

`day,seed,recipeId,station,crafter,skill,source,sourcedQty,reservedQty,consumedQty,refundQty,outputQty,outputType,success,failureReason,stockBefore,stockAfter,cpBefore,cpAfter,stonesBefore,stonesAfter,saveHash`.

**ข้อห้าม:** อย่าแก้สูตรทั้งหมดให้การคราฟต์สำเร็จ 100% เพื่อซ่อน NaN เพราะจะทำให้บาลานซ์/ความหายากผิดเพี้ยน; อย่าเพิ่ม drop-rate แบบทั่วโลกก่อนวัด demand จริง.
