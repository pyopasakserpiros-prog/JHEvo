# 02 — ผังสูตรผลิตและแหล่งวัตถุดิบ (Demand–Supply Graph)

## 1. Scope จริง ไม่เดาจากข้อมูลคำอธิบาย

| รายการ | จำนวน | วิธีนับ |
|---|---:|---|
| สูตรที่ load ลง JD.ITEMS.recipes | 1,118 | `test/load.js` |
| วัตถุดิบ registry `JD.ITEMS.materials` | 377 | ใช้เป็น pool หลักของแหล่งธรรมชาติ/พ่อค้า |
| item definitions | 1,132 | ไม่ใช่จำนวนวัตถุดิบโดยตรง |
| Ingredient ID ที่ทุกสูตรอ้างรวม | 372 | union ของ `r.inputs[].matId` |
| Ingredient ที่อยู่ใน materials registry | 348 | ใช้ได้โดย lookup standard |
| Ingredient item-only | 24 | `MAT_V230_001..024`, ทุกตัวมี item definition แต่ไม่มีใน mat registry |
| Recipes ที่บังคับใช้ item-only | 67 | **เป็น subset ของ 415 schema-invalid** |
| สูตรมี `outType`/`minMastery` ไม่ครบ | 415 | 37.12% ของ canonical recipes |
| สูตร valuation ไม่เป็น finite | 418 | 37.39% ของ canonical recipes |

**ไม่พบห่วงโซ่ craft output → craft input** ในสูตร 1,118 ชุดนี้ (intersection `outItemId` กับ ingredient ids = 0) ดังนั้นในทะเบียนสูตรนี้ dependency graph ส่วนใหญ่เป็น raw ingredients → produced end-items; ผลลูกโซ่ต่อเกมเกิดหลังคราฟต์ผ่าน NPC/พลัง/สำนัก/ตลาด ไม่ใช่ crafting subrecipe โดยตรง. ไม่ได้แปลว่าระบบผลิตอาหาร, facility, refinement และอื่นที่อยู่นอก recipe registry ไม่มีห่วงโซ่

## 2. โค้ดผู้สร้างวัตถุดิบ / ผู้ซื้อ / ผู้ใช้

| ขั้นตอน | ข้อเท็จจริงจากโค้ด | อาการที่ต้องตรวจ |
|---|---|---|
| Wild nodes | `js/wild_resources.js:57-68,72-138` เลือก 70% BASIC_HERB, 15% OTHER_HERB, 12% ORE, 3% OTHER; pool อ่าน JD.ITEMS.materials และจำกัด tier | บางวัตถุดิบสูง/พิเศษไม่อยู่ random pool; ต้องมีแหล่งเฉพาะที่พิสูจน์ได้ |
| Herb garden/mine | `js/economy.js:738-752` pool แบบกำหนดไว้, มีวัสดุเฉพาะงานช่างปน | อัตราผลิตจริงกับความสมเหตุสมผลของแหล่ง |
| Expedition | `js/expedition.js:461-465,657` วัตถุดิบสุ่มจาก materials registry ตาม terrain/tier | item-only ไม่เข้า pool นี้ |
| Visitors/market | `js/external_market.js:123-151` สุ่ม materials registry, เพิ่ม buyList request เป็นลำดับแรก | item-only อาจหาได้เมื่อถูกระบุใน buyList แต่สูตรที่ NPC ทิ้งอาจไม่ก่อ demand |
| Recipe/AI | `js/economy.js:144-155,355-465,866-921`, `js/ai.js:1057` สั่งผลิตจาก known/skill/stock | minMastery undefined → comparison false; success NaN |
| Personal brew | `js/economy.js:470-518`, `js/cpeco.js:917-945` เฉพาะ outType=PILL | 48 pill ใหม่ถูกตัดออก |
| Trading consumables | `js/external_market.js:147-152`, `js/economy.js:611-668` P: alias รับ recipe ทุกประเภท | pseudo-pill / กลืนเงิน/สต็อก |
| Save/load | `js/sim.js:559-653` บันทึก stock, action, receipt, consumed items | เมื่อแก้ข้อมูลจำเป็นต้องมี migration/sanitizer กัน fake keys, double output, lost reservation |

## 3. วัตถุดิบซึ่งมีจำนวนผู้ใช้ในสูตรมาก (Demand hubs)

ตัวเลขเป็น **จำนวนสูตรที่ใช้** ไม่ใช่ drop-rate หรือ scarcity ที่พิสูจน์แล้ว; ต้องจำลอง demand ตามเวลาจริงและ NPC ฝีมือก่อนตัดสินว่าขาดแคลน

| Ingredient ID | จำนวนสูตรที่ใช้ | ทะเบียน |
|---|---:|---|
| `MAT_BP_WOLF_PELT_1` | 70 | materials |
| `MAT_ORE_METEOR_IRON_5` | 69 | materials |
| `MAT_ORE_STAR_COPPER_3` | 66 | materials |
| `MAT_ORE_DIVINE_GOLD_6` | 59 | materials |
| `MAT_ORE_BLACK_IRON_1` | 58 | materials |
| `MAT_ORE_MITHRIL_JADE_4` | 45 | materials |
| `MAT_ORE_PRIMORDIAL_CRYSTAL_7` | 44 | materials |
| `MAT_HERB_DRAGON_GRASS_4` | 35 | materials |
| `MAT_ORE_CINNABAR_1` | 34 | materials |
| `MAT_ORE_COLD_STEEL_2` | 32 | materials |
| `MAT_BP_TIGER_BONE_6` | 32 | materials |
| `MAT_HERB_JADE_LOTUS_2` | 31 | materials |
| `MAT_V234_005` | 30 | materials |
| `MAT_HERB_DEW_GRASS_1` | 29 | materials |
| `MAT_HERB_IMMORTAL_PEACH_6` | 29 | materials |
| `MAT_BP_PYTHON_SCALE_3` | 29 | materials |
| `MAT_V234_002` | 29 | materials |
| `MAT_FORM_SPIRIT_INK_SAND_2` | 28 | materials |
| `MAT_HERB_CINDER_LEAF_1` | 27 | materials |
| `MAT_HERB_SNOW_LOTUS_5` | 27 | materials |

## 4. ข้อมูลแหล่งของ 24 item-only

ใน `DATA/ITEM_ONLY_MATERIALS_24.csv` มีข้อมูลครบทุก ID: tier, ชื่อไทย, source hints, จำนวนสูตรที่ใช้, ที่อยู่ในทะเบียน, output recipes. ที่สำคัญคือ `obtainSources` จาก item definition เป็น **hint ไม่ใช่การยืนยัน drop**. ตัวกรอง `JD.ITEMS.materials` ไม่ใช้ hints นี้สร้างจุดเกิด

## 5. กฎตรวจสมดุลหลังแก้ provider

- สร้าง cohort ผู้เล่น/สำนักยากจน–ปกติ–มั่งคั่ง, 3 กลุ่มฝีมือ NPC/ช่าง/นักสำรวจ, หลายแผนการผลิต; วัด throughput ต่อวันและ stockouts
- สำหรับวัสดุ tier 1–3 ตรวจเวลาไปสู่โอสถกู้ชีพขั้นต่ำ; tier 4–7 ตรวจ rare progression ไม่ตันหรือ flood economy
- บันทึก spawn, pickup, donate, purchases, reserved, consumed, failed+refunded, output, sold, used, dropped และ expiry; ผลรวมต้อง reconcile ต่อ ID
- ไม่ย้าย 24 ชนิดลง random pool ทุกชนิดทันทีโดยไม่ calibrate เพราะอาจลดความหายากและทำให้ทรัพยากรสูงล้นเกม
- ถ้าผู้เล่นยังไม่มีช่าง/สูตร ให้มีการพัฒนาตาม progression โดยไม่ต้องใช้ editor; ไม่ถือว่า recipe unlocked = ingredient obtainable โดยอัตโนมัติ
