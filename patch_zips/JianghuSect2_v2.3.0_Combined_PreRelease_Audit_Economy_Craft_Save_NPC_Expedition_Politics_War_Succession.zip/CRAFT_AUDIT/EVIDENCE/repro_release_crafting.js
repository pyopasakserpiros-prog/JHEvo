'use strict';
// Run: node repro_release_crafting.js /absolute/path/to/GAME_SOURCE
const path=require('node:path');
const assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||path.join(__dirname,'GAME_SOURCE'));
const {JD,ECO,EXT,SIM}=require(path.join(root,'test/load.js'));
const results=[]; function record(id,detail){results.push({id,ok:true,detail});}
function makeWorld(seed){let W=SIM.create(seed,{masterIdx:0});W.sect.recipeTier=9;W.sect.knownRecipes=W.sect.knownRecipes||[];return W;}
const broken=JD.ITEMS.recipes.filter(r=>!Number.isFinite(r.minMastery)||!r.outType);
assert.equal(JD.ITEMS.recipes.length,1118);
assert.equal(broken.length,415);
assert.equal(broken.filter(r=>r.out==='EQUIPMENT').length,343);
assert.equal(broken.filter(r=>r.out==='CONSUMABLE').length,72);
record('C-01-CATALOG',{total:1118,broken:415,gear:343,consumable:72});
{
 const r=ECO.recipeById.REC_V234_001; assert.ok(r);
 let W=makeWorld(234001); const n=W.npcs[0];
 W.sect.knownRecipes.push(r.id);n.h.skills[r.craft]=100;
 for(const i of r.inputs)ECO.add(W,i.matId,i.count);
 const before=Object.fromEntries(r.inputs.map(i=>[i.matId,ECO.count(W,i.matId)]));
 const chance=ECO.successChance(n,r);assert.ok(Number.isNaN(chance));
 const ctx={rid:r.id}; assert.equal(ECO.craftEligible(W,n,r,'forge'),true);
 assert.equal(ECO.reserveInputs(W,r,ctx,n),true);
 assert.ok(r.inputs.every(i=>ECO.count(W,i.matId)===0));
 const gear0=W.sect.gear.length;const origNext=W.rng.next;
 W.rng.next=()=>0;const out=ECO.finishCraft(W,n,r,ctx);W.rng.next=origNext;
 assert.equal(out.ok,false);assert.equal(out.rejected,undefined); assert.equal(W.sect.gear.length,gear0);
 const remaining=Object.fromEntries(r.inputs.map(i=>[i.matId,ECO.count(W,i.matId)]));
 // There can be 40% partial refunds on failure, but no crafted item even at chance draw 0.
 record('C-02-RUNTIME-FAIL',{recipe:r.id,eligible:true,skill:100,chance:'NaN',result:out,inputsBefore:before,inputsAfter:remaining,gearCreated:0});
 const restored=SIM.deserialize(SIM.serialize(W));assert.equal(restored.sect.gear.length,gear0);
 record('C-03-PERSISTENCE',{gearCount:restored.sect.gear.length,stocksAfterSave:Object.fromEntries(r.inputs.map(i=>[i.matId,ECO.count(restored,i.matId)]))});
}
{
 const r=ECO.recipeById.REC_V234_205;let W=makeWorld(234205);const n=W.npcs[0];
 W.sect.knownRecipes.push(r.id);n.h.skills[r.craft]=100; n.cp=100000;
 for(const i of r.inputs)ECO.add(W,i.matId,i.count*2);
 assert.equal(r.outType,undefined);
 assert.equal(ECO.isPill(r.outItemId),false);assert.equal(ECO.pillInfo(r.outItemId),null);
 assert.equal(ECO.personalCraftQuote(W,n,r),null);
 record('C-04-PILL-DUAL-ID',{recipe:r.id,outputItem:r.outItemId,cat:ECO.itemById[r.outItemId].cat,isPill:false,pillInfo:false,personalCraftQuote:null,alternateConsumableAPI:typeof ECO.useConsumableItem});
}
{
 const matIds=Array.from({length:24},(_,i)=>'MAT_V230_'+String(i+1).padStart(3,'0'));
 assert.ok(matIds.every(id=>ECO.itemById[id]&&!ECO.matById[id]));
 const recipes=JD.ITEMS.recipes.filter(r=>r.inputs.some(i=>matIds.includes(i.matId)));
 assert.equal(recipes.length,67);
 record('C-05-MATERIAL-REGISTRY',{itemOnly:24,impactedRecipes:recipes.length,ids:matIds});
}
{
 let W=makeWorld(23441);let fake=0, total=0, example=null;
 for(let i=0;i<80;i++){
  const v=EXT.openVisit(W,{subtype:'medicine'});
  const pseudo=Object.keys(v.stock).filter(x=>x.startsWith('P:'));
  for(const id of pseudo){total++;const r=ECO.recipeById[id.slice(2)];if(r&&r.outType!=='PILL'){fake++;if(!example)example={id,name:ECO.name(id),recipeOutput:r.outType||r.out,quantity:v.stock[id]};}}
 }
 assert.equal(total,80);assert.ok(fake>0);
 record('C-06-FAKE-TRADER-PILLS',{visits:80,pseudoPillListings:total,nonPillListings:fake,example});
}
{
 let W=makeWorld(23402),npc=W.npcs[0];const id='P:REC_V234_001';assert.equal(EXT.isTradable(id),true);
 assert.deepEqual(ECO.pillInfo(id).effect,{});
 assert.equal(ECO.add(W,id,1),true);
 const ret=ECO.usePill(W,npc,id);assert.ok(ret); assert.equal(ECO.count(W,id),0);
 record('C-07-FAKE-PILL-USE',{id,results:ret.msgs,consumed:1});
}
console.log(JSON.stringify({status:'REPRODUCED',count:results.length,results},null,2));
