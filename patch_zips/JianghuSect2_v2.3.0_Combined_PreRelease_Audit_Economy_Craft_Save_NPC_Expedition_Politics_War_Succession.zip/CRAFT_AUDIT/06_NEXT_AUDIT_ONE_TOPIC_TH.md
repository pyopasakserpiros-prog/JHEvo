# 06 — แนะนำหัวข้อที่ควรตรวจถัดไป (เลือกเพียงเรื่องเดียว)

## ถัดไป: **ระบบบันทึก–โหลดเซฟ และวงจรสถานะการกระทำ (Save/Load + Mid-Action Lifecycle)**

**เหตุผลที่เป็นลำดับถัดไปเพียงหัวข้อเดียว:** ปัญหาเศรษฐกิจและสูตรคราฟต์ที่พบเชื่อมกันผ่านสถานะถาวรของการใช้ทรัพยากร การจองวัสดุ การผลิตจบ การใช้ของ และการซื้อขาย. ต่อให้แก้สูตรผลิตแล้ว หากเซฟระหว่างงานทำให้ใบจองหาย/ของเพิ่มซ้ำ/อุปกรณ์สูญหาย ผู้เล่นจริงจะได้รับความเสียหายแบบย้อนคืนยากกว่าปัญหา AI ไม่ชอบงานใดงานหนึ่ง.

### ขอบเขตตรวจรอบหน้าแบบละเอียด (ยังไม่เริ่ม)

- วงจร New Game → Sim Tick → Pause → Save → Reload → Resume; compare full deterministic state and RNG
- จองวัตถุดิบกับ NPC action ที่ระหว่างงานโดนยกเลิก ตาย ถูกย้ายตำแหน่ง บาดเจ็บ ถูกบังคับหยุด หรือถูกเรียกกลับ
- การผลิตสำเร็จ/ล้มเหลวและคืนวัตถุดิบ หลัง save/load: exactly-once semantics
- คลัง สำนัก เงิน CP ต้นทุน รายการคาราวาน และตลาดพ่อค้า ซื้อ/ขาย/เครดิต/หักคลังระหว่างโหลด
- อุปกรณ์ UID, ผลผลิตคราฟต์, pillQuality, consumable multi-phase buffs, cooldowns and deferred events
- สถานะ `W.sect.knownRecipes`, AI action contexts, world visitors, expedition rewards, resource-node remaining/nextSpawnAt
- Serialization sanitization of `NaN`, negative, `null`, duplicates, unknown IDs, invalid P: aliases, orphan receipts
- Saved UI state effects + mixed source versions within same current save schema
- Repeat 100–1000 save/reload cycles on fixed seeds, sample compare hash of stable fields; performance/memory budget, corruption recovery

**ผลลัพธ์ที่ควรส่ง:** ZIP รวมรายงานเดิมพร้อมเอกสาร save audit ใหม่, test cases, repro and pass/fail evidence. **ไม่ตรวจวิถี/สายย่อย/พลังอุปกรณ์ซ้ำ** กับ AI อีกแชท.
