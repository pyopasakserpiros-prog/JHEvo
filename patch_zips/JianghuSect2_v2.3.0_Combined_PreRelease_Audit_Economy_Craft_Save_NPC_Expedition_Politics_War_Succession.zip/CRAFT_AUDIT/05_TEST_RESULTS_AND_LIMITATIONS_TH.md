# 05 — ผลรันจริงและข้อจำกัด (Audit Evidence)

## Source & tools

- Source ZIP `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip` SHA256 `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`
- `AGENTS.md` และสกิลใน `.agents/skills/` อ่านก่อนตรวจ
- Runtime world via `GAME_SOURCE/test/load.js`, isolated SIM.create, JS `node:assert/strict`, graph export; ไม่มีการแก้ซอร์สเกม
- Validator 0 Errors, 0 Warnings, exit 0 — ข้อสำคัญคือ **validator นี้ไม่ตรวจ runtime contract ครบ**

## ผล 13 targeted suites

- `craft_transactions.js`: **PASS** (0.96s)
- `personal_crafting.js`: **PASS** (0.63s)
- `wild_resources.js`: **PASS** (0.62s)
- `recipe_coverage.js`: **PASS** (1.0s)
- `coherent_regions_recipes.js`: **PASS** (1.06s)
- `recipe_scroll_lifecycle.js`: **PASS** (0.63s)
- `ecology_expansion.js`: **PASS** (0.79s)
- `external_market.js`: **PASS** (0.76s)
- `external_market_expansion_suite.js`: **PASS** (0.47s)
- `welfare_production_policies.js`: **PASS** (0.63s)
- `autonomous_economy_facilities.js`: **PASS** (1.07s)
- `save_integrity.js`: **PASS** (0.71s)
- `legacy_save.js`: **PASS** (0.47s)

ผล: **13/13 PASS** ใน environment นี้. การผ่านหมายถึง assertions ที่ชุดนั้นตรวจ ไม่ได้ครอบคลุม 415 recipes และ fake pill.

## Reproduction ใหม่

| Case | Result | Evidence |
|---|---|---|
| C-01 Catalog | REPRODUCED | 1118, malformed 415 (343+72) |
| C-02 Runtime craft | REPRODUCED | REC_V234_001, skill100, NaN chance, material lost, no gear |
| C-03 Save/load | REPRODUCED | Stock after failed craft persists; no gear minted |
| C-04 Pills | REPRODUCED | REC_V234_205 output kind PILL but isPill false and personalCraftQuote null |
| C-05 Materials | REPRODUCED | 24 item-only IDs, 67 dependent recipes |
| C-06 80 merchant visits | REPRODUCED | 67 of 80 medicine P: listings not PILL recipes |
| C-07 False pill use | REPRODUCED | P:REC_V234_001 spent and returned no medicinal messages |

`EVIDENCE/repro_results.json` contains literal results; `EVIDENCE/repro_release_crafting.js` can be run against source directory:

```bash
node /path/to/report/CRAFT_AUDIT/EVIDENCE/repro_release_crafting.js /path/to/JianghuSect2/GAME_SOURCE
```

**Note:** after a fix, the proof script is expected to fail some assertions because it verifies the *old bad behavior*. Replace with true regression asserts from handoff document.

## ยังไม่ตรวจ/ไม่ควรอ้าง

- End-to-end Chromium UI smoke of 415 recipes/24 materials: NOT TESTED.
- All source providers (quest and rare trial) and chance-to-acquire by path: PARTIALLY TRACED, not proven absent globally.
- 90–360 day long horizon, seeds, NPC job decisions, price pressure, growth/health impact: NOT RUN.
- Cross-system balance of detailed equipment power and cultivation paths: intentionally assigned to another AI; not assessed here.
- Data is v2.3.0 snapshot; source skills can reference newer versions and therefore are not treated as truth over actual source.
- No game files modified; combined zip is a **report-only ZIP**, not a patched game deliverable.

## เกณฑ์รันเพิ่ม

1. `node tools/validate_data_schema.js` and relevant suites again after patch
2. Generated schema-check across all 1118 recipes including entire output mapping and every material provider
3. Browser click forge, brew, traders, inventory, save/load and no-gear-loss on multiple seeds
4. 7/30/90/360 day world runs with CPU wall-clock/timeout logs and per-day raw data; if a run times out report TIMEOUT not PASS
