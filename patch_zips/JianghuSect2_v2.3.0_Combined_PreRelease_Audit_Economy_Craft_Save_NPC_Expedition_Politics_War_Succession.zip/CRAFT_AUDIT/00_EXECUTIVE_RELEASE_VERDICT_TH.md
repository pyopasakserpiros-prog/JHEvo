# 00 — Release Verdict: การผลิต สูตรคราฟต์ และแหล่งวัตถุดิบ

## เกณฑ์ตัดสิน
**NO-GO** สำหรับรุ่นนี้ในบริบทเปิดให้ผู้เล่นจริง เพราะพิสูจน์ได้ว่าข้อมูลสูตรจำนวนมากใช้กับเครื่องผลิตปกติไม่ได้และผู้เล่นอาจเสียทรัพยากรโดยไม่มีผลงาน ขณะเดียวกันตลาดสร้างโอสถปลอมจากสูตรประเภทอื่นได้

## ขอบเขตที่ตรวจจริง
- ซอร์ส `economy.js`, `cpeco.js`, `ai.js`, `external_market.js`, `wild_resources.js`, `expedition.js`, `sect.js`, `content.js` และ `data_martial.js`
- ทะเบียนที่ `test/load.js` โหลดจริง: **1,118 สูตร, 377 วัตถุดิบใน materials registry, 1,132 item definitions** (ไม่ใช่จำนวนไอเทมรวมทั้งโลก)
- สารตั้งต้นที่สูตรอ้างถึง: **372 ID**; ในนี้ **24 ID เป็น item-only** และ **348 ID อยู่ใน materials registry**
- **415 สูตร** มี `outType`/`minMastery`/`outNameTh` หาย: **343 EQUIPMENT + 48 PILL-kind + 24 TALISMAN-kind**
- **418 สูตร** ที่ `ECO.outputValue` ไม่เป็น finite เพราะ item output ขาด `.value` (415 สูตรข้างต้น + 3 สูตรอุปกรณ์เดิม)
- **67 สูตร** พึ่งวัตถุดิบ item-only 24 ID และทั้งหมด 67 สูตรอยู่ในกลุ่ม schema ผิดด้วย (ความเสี่ยงซ้อนกัน)
- รูปแบบ `P:<recipeId>` ใช้เป็นยาในตลาดได้จาก **948 สูตรที่ `outType !== 'PILL'`**; ค่า 948 คือชุดที่ตัวกรองผิด *มีสิทธิ์เลือก* ไม่ใช่ยืนยันว่าทุก ID ปรากฏบนตลาดในการเล่นหนึ่งรอบ
- พ่อค้าขายยา 80 ครั้งที่จำลองด้วย fixed seed พบ **67/80** รายการ `P:` อ้างสูตรซึ่งไม่ใช่สูตรยา (ตัวอย่างที่ทดสอบ ไม่ใช่อัตราคาดหมายของผู้เล่นจริง)

## จำนวน Finding ใหม่
- **P0 = 1**, **P1 = 5**, **P2 = 7** (รวม **13**); แยก ROOT CAUSE จากอาการขยายผล และระบุ API ภายใน/พฤติกรรมตั้งใจชัดเจน

## สิ่งที่ทดสอบแล้ว
- พิสูจน์ reproducible **7 checks**: 415 schema, ทดลองเสียทรัพยากรขณะหลอม, เซฟ/โหลดหลังล้มเหลว, 48 pill dual-ID, 24 material registry/67 สูตร, 80 merchant visits, ใช้ยาไม่ใช่ยาที่สร้างจากสูตรหลอม
- **13 test suites ผ่าน**: transaction, personal craft, wild resources, recipe coverage, coherent regions, recipe scroll lifecycle, ecology, merchant, welfare production, autonomous facility, save integrity และ legacy save
- `node tools/validate_data_schema.js`: **exit 0, 0 Errors/0 Warnings** แต่ตรวจ runtime contract ไม่ครบ

## จุดที่ไม่อ้างเกินหลักฐาน
- ยังไม่ทดสอบ UI จริงบน Chromium; มี caller paths จากการอ่านโค้ด แต่ไม่ได้คลิกทุก action
- วัตถุดิบ 24 ชนิดไม่มีอยู่ใน *normal random pools ที่ตรวจ* ไม่ได้พิสูจน์ว่าไม่มีช่องทางพิเศษอื่นได้เลย (buyList/direct quest/editor อาจเพิ่มได้)
- ไม่ได้ simulate ความสมดุลระดับ 90–360 วันและทุก seed; จำนวนสูตรไม่เท่ากับจำนวนที่ผู้เล่นปลดล็อกได้ทันที
- การตรวจรายละเอียดวิถี สายย่อย และสมดุลค่าพลังอุปกรณ์อยู่นอกขอบเขต; เชื่อมเฉพาะผลกระทบ downstream

## ตัดสินใจปล่อยได้เมื่อ
1. แก้สูตรและแหล่งวัตถุดิบพร้อมกัน ไม่แก้เฉพาะท่อน `NaN` แล้วจบ
2. พิสูจน์ไม่มี pseudo-pill จากสูตรอุปกรณ์อีกและ canonical pill effects ใช้งานได้
3. ทุกสูตรที่เปิดให้เล่นมี provider/สถานที่/วัตถุดิบ/เวลา/ผลผลิตที่ไม่ผิดกฎ
4. Regression ใหม่ผ่าน, UI browser critical paths ผ่าน, save/load เหมือนเดิม และ soak หลาย seed เป็นผลที่วัดจริง
