# 01 — รายละเอียดข้อค้นพบและ Root Causes

**หมายเหตุ:** `RUNTIME_CONFIRMED` หมายถึงรันทดสอบ/สถานะจริงยืนยัน; `STATIC_CONFIRMED` คือ code path ชัดแต่ยังไม่พิสูจน์ผู้เล่นเข้าถึง; `CONDITIONAL` และ `DESIGN_REVIEW` ห้ามตีความเป็นบัคผู้เล่นแน่นอน

## CRAFT-P0-001 [P0] สูตร 415 สูตรมี schema ไม่เข้ากับเครื่องผลิต; ค่าโอกาสสำเร็จ NaN และเสียวัตถุดิบ

**หลักฐาน:** RUNTIME_CONFIRMED  
**จุดโค้ด:** `js/economy.js:7-17`, `js/economy.js:355-362`, `js/economy.js:420-465`, `js/ai.js:1007-1058`, `data/data_martial.js (V200/V230/V234 recipe builders)`

**สิ่งที่พบ:** 1118 registered recipes: 415 missing outType, minMastery, outNameTh; 343 EQUIPMENT, 48 PILL-kind and 24 TALISMAN-kind. REC_V234_001 at skill 100 -> successChance NaN; reserveInputs deducts, finishCraft fails even with rng.next=0.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Automatic NPC skills/receipt path and ordinary recipe schema; manual API proof; recipeKnown/craftEligible may expose discovered recipe but NPC filters out missing mastery.

**ผลกระทบลูกโซ่:** แหล่งวัตถุดิบ/ซื้อของ→พบ/ปลดล็อกสูตร→แรงงาน NPC→จองวัตถุดิบ→NaN/ผลิตล้มเหลว→ขาดอุปกรณ์หรือยา→คอขวดความก้าวหน้า→สำนักขาดกำลังและเสียค่าเสียโอกาส

**แนวทางแก้:** Normalize recipe schema once at registry load; require outType,minMastery,valid output mapping, craft+station+facility/yield; implement distinct CONSUMABLE/TALISMAN output, route output by item category. Apply and validate NPC and personal pipelines; do not simply default NaN to guaranteed success.

**เกณฑ์รับงาน:** For every 1118 recipes schema valid; NPC skill gate finite; create success outputs correctly or explicitly unsupported; no ingredients lost due to invalid schema; 415 formerly bad IDs covered by generated tests.

## CRAFT-P1-002 [P1] ECO.outputValue คำนวณ NaN ใน 418 สูตร ทำให้การจัดลำดับงานผลิตผิดเพี้ยน

**หลักฐาน:** RUNTIME_CONFIRMED  
**จุดโค้ด:** `js/economy.js:269-280`, `js/economy.js:902-920`, `data/data_martial.js:51745-52470`

**สิ่งที่พบ:** 415 malformed recipes have output item.price but no .value; ECO.outputValue uses .value * .8 -> NaN. Another 3 valid equipment recipes have baseValue, no value. Together 418/1118 outputValue non-finite.

**ขอบเขตการเข้าถึง/เงื่อนไข:** ECO.pickOrder scores potential projects with Math.max(0, outputValue-inputCost); NaN propagates to score and sort.

**ผลกระทบลูกโซ่:** ราคาข้อมูลไม่ครบ→คะแนนงานผลิต NaN→ลำดับความต้องการ NPC/หัวหน้าหอไม่เสถียร→สั่งซื้อวัตถุดิบไม่ตรงความต้องการ→เงิน/แรงงานสูญเปล่า

**แนวทางแก้:** Define canonical valuation value ?? price ?? baseValue (validate finite positive) with sensible fallback; require finite inputCost, outputValue and scoring; tests against all recipe outputs and stock.

**เกณฑ์รับงาน:** For every recipe isFinite(outputValue), isFinite(inputCost), and finite score; no NaN in purchase wants, UI or save.

## CRAFT-P1-003 [P1] พ่อค้าสุ่มเสนอโอสถปลอมจากสูตรอุปกรณ์/ยันต์ เพราะ P:<recipeId> ใช้ได้กับทุกสูตร

**หลักฐาน:** RUNTIME_CONFIRMED  
**จุดโค้ด:** `js/external_market.js:147-152`, `js/external_market.js:208-218`, `js/external_market.js:27-32`, `js/economy.js:94-97`, `js/economy.js:611-626`, `js/economy.js:733-735`

**สิ่งที่พบ:** 948/1118 recipes are non-PILL by outType. EXT.isTradable(P:REC_V234_001)=true; pillInfo(P:REC_V234_001).effect={} even though recipe outputs gear. 80 medicine merchant visits in fixed seed generated 67/80 invalid pseudo-pill listings. ECO.usePill consumes P:REC_V234_001, returns no effect messages.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Normal trader stock build and player/member trade, not merely a debug API.

**ผลกระทบลูกโซ่:** สูตรอุปกรณ์→เข้า pool ยาพ่อค้า→ผู้เล่นเสียเงิน/CP ซื้อสินค้าไม่ใช่ยา→กินแล้วไม่มีฤทธิ์ตามคาด→อุปทานยาจริงลดและความเชื่อถือระบบเสีย

**แนวทางแก้:** Strictly filter recipe-derived pills by normalized output type PILL and valid effect route; never create a P: alias for other recipe outputs; audit existing save/trader inventory keys and prevent invalid item import.

**เกณฑ์รับงาน:** 1000 seeded trader visits contain 0 non-PILL P: keys; purchase of actual pill works; fake pills cannot be sold/used; save/load repairs invalid merchant keys without economy duplication.

## CRAFT-P1-004 [P1] วัตถุดิบพิเศษ 24 ชนิดอยู่ใน items แต่หายจาก materials registry; เกี่ยวข้อง 67 สูตร

**หลักฐาน:** STATIC_AND_REGISTRY_CONFIRMED  
**จุดโค้ด:** `data/data_martial.js:51745-51809`, `js/economy.js:8-17`, `js/wild_resources.js:57-68`, `js/expedition.js:461-465`, `js/external_market.js:123-126`

**สิ่งที่พบ:** MAT_V230_001..024 all ECO.itemById true, ECO.matById false. Referenced by 67 recipes. Normal wild/expedition randomized pools filter JD.ITEMS.materials; visiting merchant random material pool filters ECO.matById. However demand-directed buyList can sometimes list an item ID, so not proven entirely unobtainable.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Random natural material acquisition pools not include these entries; source metadata is not an executable provider.

**ผลกระทบลูกโซ่:** สูตรระดับสูง→ต้องใช้ MAT_V230→ไม่อยู่ pool แหล่งมาตรฐาน→ผู้เล่นสำรวจ/ล่าสัตว์/ซื้อซ้ำแต่ไม่พบ→67 สูตรติดคอขวด (ซ้ำกับ schema ผิด)→เส้นทางคราฟต์ช่วงกลาง-ท้ายหยุด

**แนวทางแก้:** Register material definitions in canonical material registry (or add explicit provider adaptor) exactly once; implement each declared obtainSources as a real provider or revise descriptions; add drop-coverage tests and max-tier scarcity calibration.

**เกณฑ์รับงาน:** 24 item IDs resolvable by material registry or supported alternate route; at least one reachable non-editor source per intended progression tier; 67 recipe supply chains reachable in tests; no duplicate economy sinks.

## CRAFT-P1-005 [P1] โอสถใหม่ 48 ชนิด (out CONSUMABLE, cat PILL) ไม่ถูกมองเป็นยาโดยระบบโอสถมาตรฐาน

**หลักฐาน:** RUNTIME_CONFIRMED  
**จุดโค้ด:** `js/economy.js:94-97`, `js/economy.js:611-668`, `js/economy.js:470-475`, `js/cpeco.js:917-945`, `data/data_martial.js (V234 pill recipes)`

**สิ่งที่พบ:** 48 output item kind/cat PILL has out CONSUMABLE; ECO.isPill false, ECO.pillInfo null, ECO.personalCraftQuote null even with ingredients+skill+CP. ECO.useConsumableItem understands these defs, so there is an alternate use route; do not claim all effects are absent.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Personal crafting AI and standard sect pill inventory/production / trade pipelines, with separate generic consumable API still available.

**ผลกระทบลูกโซ่:** ผลิตโอสถใหม่ไม่ได้ตามระบบหลัก→NPC ไม่วางแผนปรุง/ไม่จ่ายยารักษา→ผู้บาดเจ็บ/ใกล้ทะลวงไม่ได้รับผล→การเติบโตและความเสี่ยงต่อสู้เปลี่ยน

**แนวทางแก้:** Provide canonical item kind and bridge standard pill interfaces to multi-phase consumable effects without duplicate applying; verify full treatment, toxicity, buffs, expiry, phase queue and save/load.

**เกณฑ์รับงาน:** All 48 recognized as pills where intended; use once spends exactly one stock; personal/sect craft and NPC choice work; deferred phase survives save/load once.

## CRAFT-P1-006 [P1] Schema validator ผ่าน 0 error ทั้งที่ runtime recipe contract ผิด 415 สูตร

**หลักฐาน:** RUNTIME_CONFIRMED  
**จุดโค้ด:** `tools/validate_data_schema.js:112-170`, `js/economy.js:355-362`, `js/economy.js:420-465`

**สิ่งที่พบ:** node tools/validate_data_schema.js exits 0 (Errors:0,Warnings:0; reports 1370 audited entries aggregated from multiple arrays), while 415 canonical runtime recipes invalid; validator validates ID/name/inputs/output references but not outType/minMastery/producer mapping. Duplicate aggregate arrays should not be confused with unique runtime counts.

**ขอบเขตการเข้าถึง/เงื่อนไข:** CI/pre-release quality gate misses release-blocking data contract mismatch.

**ผลกระทบลูกโซ่:** นักพัฒนาเห็นผลผ่าน→เชื่อข้อมูลครบ→ส่งแพตช์จริง→ผู้เล่นใช้ของ/สูตรเสีย→ข้อผิดพลาดขยายหลายระบบ

**แนวทางแก้:** Validate exact runtime ECO.recipeById, schema variants, finite successChance/valuation, registry sources, all outputs and aliases; reject errors instead of treating warnings as pass.

**เกณฑ์รับงาน:** Unpatched source fails new validator with meaningful errors; after fix 0 errors; targeted tests cover every registered recipe.

## CRAFT-P2-007 [P2] ป้าย obtainSources ของวัตถุดิบบางชุดเป็นคำบรรยาย ไม่ใช่แหล่งที่แจกได้จริง

**หลักฐาน:** STATIC_CONFIRMED_RUNTIME_REACH_UNKNOWN  
**จุดโค้ด:** `data/data_martial.js:51754-51809`, `js/wild_resources.js:57-68`, `js/external_market.js:123-126`, `js/content.js:1272-1299`

**สิ่งที่พบ:** V230 items declare WILD_GATHER, PAGODA_TRIAL, MYRIAD_WORLD, CARAVAN etc; no JS generator references obtainSources as a provider. Standard random generators use data.materials. Other bespoke exploration/trial rewards might still exist; cannot categorically rule out all acquisition.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Data/UI hints may guide player to nonfunctional providers; secondary to P1-004 but distinct content traceability issue.

**ผลกระทบลูกโซ่:** แหล่งในคำอธิบายไม่ตรงระบบ→ผู้เล่นเสียเวลาออกสำรวจ→หาของไม่ได้→ตีความว่าเกมยากเกินหรือพัง

**แนวทางแก้:** Machine-readable provider registry keyed by reward ID and source capability; either implement actual source or show accurate source text for each ID.

**เกณฑ์รับงาน:** 100% of crafting inputs have a provider evidence mapping or explicit gated/unobtainable design status; UI hints generated from actual providers.

## CRAFT-P2-008 [P2] ปรุงยาส่วนตัวตรวจทรัพยากรใหม่เมื่อจบงาน โดยไม่มีการจองตั้งแต่ต้น

**หลักฐาน:** STATIC_CONFIRMED  
**จุดโค้ด:** `js/cpeco.js:940-945`, `js/economy.js:470-518`

**สิ่งที่พบ:** personalBrew.start returns bool(personalCraftQuote), but no reserve. On done ECO.personalCraft calls personalCraftQuote again. If stock or CP changes during travel/time, done can return false; AI.done logs only if out.ok, so idle time is spent without clear failure log.

**ขอบเขตการเข้าถึง/เงื่อนไข:** NPC autonomous job; conditional on concurrent usage of stock/CP over duration.

**ผลกระทบลูกโซ่:** NPC เริ่มงาน→คลังถูกใช้อย่างอื่น→สิ้นเวลาวัตถุดิบขาด→ไม่มีผลงาน/ข้อความ→การจัดตารางและศักยภาพแรงงานลด

**แนวทางแก้:** Choose explicit reservation or opportunistic crafting policy; if no reserve, show/log failed and release station; account for labor and CP appropriately.

**เกณฑ์รับงาน:** Start-to-finish shortage has expected documented behavior and player-visible event, no negative stock or CP, no orphan work action.

## CRAFT-P2-009 [P2] เปิดใบจองงานผลิตซ้ำให้ NPC เดิมลบใบจองก่อนโดยไม่มีการคืนของ (อาจเป็นกฎตั้งใจ)

**หลักฐาน:** STATIC_CONFIRMED_INTENTIONAL_POLICY  
**จุดโค้ด:** `js/economy.js:287-310`, `test/craft_transactions.js`

**สิ่งที่พบ:** registerCraft deletes existing open receipts for same NPC; dedicated test expects replacement to consume previous materials. This is currently an explicit tested policy, not automatically a defect.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Interrupt/cancel/reassign production, reload prune; must verify UI informs consequences and whether repeated switches can exhaust all supplies.

**ผลกระทบลูกโซ่:** งานถูกสั่งทับ→ของที่จองหายเป็น sunk cost→งานหอช่างชะงัก→AI สั่งซื้อชดเชย→เศรษฐกิจใช้จ่ายเกินจำเป็น

**แนวทางแก้:** Do not silently change intentional balance: first decide salvage/loss/partial refund rule; add UI description, bounded loss and tests for save/load and repeated reassignment.

**เกณฑ์รับงาน:** Every reserve has explicit lifecycle open/settled/cancelled; interruptions reconciled once and policy observable.

## CRAFT-P2-010 [P2] API หลอม procedural แบบทันทีข้าม craftEligible/knownRecipe และไม่ตรวจผล take; ไม่พบ caller ปกติ

**หลักฐาน:** INTERNAL_API_ONLY  
**จุดโค้ด:** `js/economy.js:1591-1628`

**สิ่งที่พบ:** craftProceduralNow checks materials and forEach(ECO.take), but not craftEligible nor result of each take; search of source finds only its definition, no other direct call sites. Therefore not a confirmed player-accessible exploit.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Internal/debug/future integration API only, absent externally reachable caller in audited source.

**ผลกระทบลูกโซ่:** หากต่อ UI ภายหลัง→ผู้เล่นข้ามปลดล็อก/ต้นทุน→ของขั้นสูงหลั่งไหล→สมดุลอุปกรณ์และเศรษฐกิจเสีย

**แนวทางแก้:** Harden with validated eligibility or explicit trusted debug capability; atomic take and negative test; no current UI exploit claim.

**เกณฑ์รับงาน:** Explicit mode distinguishes player vs debug, all material takes succeed atomically before item mint.

## CRAFT-P2-011 [P2] การเกิดจุดเก็บทรัพยากรไม่ catch up เมื่อเวลาเกมกระโดดหลายช่วง

**หลักฐาน:** CONDITIONAL_STATIC  
**จุดโค้ด:** `js/wild_resources.js:273-281`

**สิ่งที่พบ:** tick performs one spawn batch if W.t>=nextSpawnAt then schedules W.t+120. Under normal minute ticks this is fine; time skips or unloaded clock acceleration could underproduce compared with continuous sim.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Only if time skip or timer jumps across multiple spawn windows; not confirmed on normal gameplay.

**ผลกระทบลูกโซ่:** ข้ามเวลา→แหล่งเกิดน้อย→สมุนไพรตั้งต้นขาด→NPC รักษา/ผลิตลด→แรงงานอื่นเสียโอกาส

**แนวทางแก้:** If fast-forward supported, bounded catch-up respecting node max and seed determinism; else document clock contract and add invariant.

**เกณฑ์รับงาน:** Compare 24-hour fixed-seed simulation with normal ticks vs time jump within declared tolerance; runtime bounded.

## CRAFT-P2-012 [P2] แหล่งสมุนไพร/เหมืองมีวัสดุงานฝีมือบางชนิดผิดบริบททางธรรมชาติ

**หลักฐาน:** DESIGN_REVIEW  
**จุดโค้ด:** `js/economy.js:738-752`

**สิ่งที่พบ:** HERBS pool includes instrument wood/silk/whip tendon; ORES pool includes brush hair/cinnabar. May represent managed foraging vs literal mine; design interpretation needed.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Player expectations and immersion; not necessarily a bug.

**ผลกระทบลูกโซ่:** คำอธิบายงานไม่สอดคล้องผลผลิต→ผู้เล่นหาทรัพยากรผิดแหล่ง→ทิ้งงานที่ควรใช้→อัตรา supply เปลี่ยน

**แนวทางแก้:** Map natural sources based on category and lore or clarify that farm/mine manages procurement; preserve economical supply rates.

**เกณฑ์รับงาน:** Source text and actual item flow agree; no changed supply without calibration.

## CRAFT-P2-013 [P2] เส้นทาง reserveInputs หักหลายรายการโดยไม่ตรวจผลการหักแต่ละรายการหลัง validation

**หลักฐาน:** STATIC_POTENTIAL  
**จุดโค้ด:** `js/economy.js:298-314`, `js/economy.js:155-270`

**สิ่งที่พบ:** All input counts checked before take; then inputs.forEach(ECO.take) without checking returned bool. Synchronous normal state avoids most races, but state mutation/hooks or corrupted inventory could produce orphaned receipt.

**ขอบเขตการเข้าถึง/เงื่อนไข:** Edge-case under state mutation or malformed save/mod; not a confirmed regular UI bug.

**ผลกระทบลูกโซ่:** บางวัตถุดิบหักไม่สำเร็จ→ออกใบรับจอง→ผลิตสินค้าโดยต้นทุนไม่ครบ→เกิดของฟรีหรือยอดบัญชีผิด

**แนวทางแก้:** Atomic transaction with checked take results and rollback, quantity integrity validated before mutation.

**เกณฑ์รับงาน:** Injected failed take yields no receipt/item and restores all balances; all successful inputs sum exactly to receipt.

