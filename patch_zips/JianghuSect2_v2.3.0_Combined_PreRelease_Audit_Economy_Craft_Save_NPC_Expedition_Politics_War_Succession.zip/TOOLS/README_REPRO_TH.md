# ทดสอบซ้ำ

ตั้งโฟลเดอร์ปัจจุบันไปที่ GAME_SOURCE ของเกมต้นฉบับก่อน แล้วรัน Node script นี้:

```bash
node /full/path/EVIDENCE/repro_release_economy.js
```

ตัว script สร้าง World ใหม่ในหน่วยความจำและเรียก `test/load.js`. ไม่แก้ซอร์สเกม และไม่เขียนเซฟไฟล์ลงดิสก์. การผ่าน assert หมายถึงพฤติกรรมผิดตามรายงานยังเกิดอยู่ ไม่ใช่เกมถูกต้อง. 

รัน regression ใหม่ใน source ที่แก้แล้ว จากนั้นรัน tests ข้างต้นและ build ตาม AGENTS.md. โปรดอย่าคัดลอกปัญหาที่สังเกตได้ให้กลายเป็น acceptance test ของ behavior ที่ผิด
