# Save Contract, Serialization Policy, และ Data Integrity

## สถานะที่ “ต้องคงอยู่” vs “คำนวณใหม่ได้”

`SIM.serialize` ใน `js/sim.js:827-828` ใช้ predicate เดียวกับทั้ง world: `if (transientSet.has(k) || (k[0] === '_' && except 4 fields)) drop`. ปัญหาไม่ใช่การใช้ `_` แต่ใช้ชื่อฟิลด์เป็น proxy ของความหมายทางเกมโดยไม่จำแนก.

| Field | ความหมาย | คำแนะนำ | หลักฐาน |
|---|---|---|---|
| `_divineStrain` | จำนวนสะสมความเสี่ยง backlash | **persist** เป็น gameplay state และ migrate | S-02 |
| `_studyHrsAcc` | ชั่วโมงเรียนสะสมเศษส่วน | **persist** | S-03 |
| `_gatherHrsAcc` | ชั่วโมงเก็บของสะสมเศษส่วน | **persist** ถ้านโยบายคง progress | source |
| `_gravityFieldCdUntil` | เวลาก่อนท่านี้ใช้ซ้ำได้ | classify per caller; API ต้องเก็บถ้ากติกาต้องคง | S-01; normal battle uses ignoreCooldown |
| `_duetCdUntil` | เวลาคู่ประสานใช้ซ้ำ | classify/test reachable path | source |
| `_ccImmuneUntil` | ช่วง immune crowd-control | persist if survives midbattle reload | source |
| `_itemEfxCds` | individual item effect ICD timers | persist when effect carry over across reload | source |
| `_beastFusedUntil` | deadline รูปแบบสัตว์หลอมรวม | classify and test midbattle | source |
| `_lastGearSwapAt` | NPC decision hysteresis | persist if non-transient behavior; else document reset | source |
| `_c`, `_wsBase`, `_cultRateBase`, etc | derived caches / computations | **do not persist** if safely recomputed | `TRANSIENT_CACHE_KEYS` |

**Implementation preference:** explicit persisted gameplay fields or `saveState` per module > extend underscore exception ad hoc. Avoid broad `JSON.stringify` of circular runtime refs. Never blindly persist `cb` functions or DOM references. Consider dedicated `exportGameState()` and `restoreGameState()` with versioned schema.

## Contract สำหรับ invalid imported saves

1. Parse + schema validation before constructing or exposing new world.
2. Strict version policy: known exact `schemaVersion`, known/convertible patch. Do not use lexicographic `>` to determine support.
3. Numeric: sect.stones, recipe stock counts, CP, times, quantity, cost, ledger entries must be type number where required, finite, bounded and sign-correct; use `Number.isSafeInteger` for counts/currency if design expects integers.
4. Collections: ledger arrays; `craftTransactions.open` plain object; valid receipt IDs/owner/state; NPC reference resolution; no `__proto__` or unsafe prototype mutation in dynamic map IDs.
5. Calculate derived data in isolated candidate, validate cross-references, ensure migration idempotent.
6. Commit to `G.W`, singleton registries, game clock, `HC.nowDay`, `STATS.now` *after* all potentially throwing steps pass.
7. Failure must not modify current world, global item catalog, UI bindings, clock or storage of last-good save.
8. Do not silently scrub invalid economy values into plausible values when that hides corruption; reject with Thai diagnostic and optional backup/export.

## Runtime timing policy

- `speed` should be validated against allowed UI speeds; `pendingTicks` cannot be unbounded even if finite. Define maximum backlog and user-visible policy for excess ticks (discard with notice, offline progression with explicit cap, or staged catch-up).
- Preserve one unit of time consistently (simulation tick vs milliseconds). Test save/load when paused, speed changed, hidden tab and focus restored.
- Frame budget `SIM_BUDGET_MS` is useful but does **not** mean a huge saved backlog is safe or complete.

## Storage UX contract

- Mark autosave successful only when data and metadata writes succeed; if 1st write succeeds but 2nd fails, recover gracefully from authoritative data blob. Prefer an atomic localStorage slot strategy with version/checksum if appropriate.
- On failure, show non-spam Thai toast/badge (`ยังไม่ได้บันทึก — พื้นที่เก็บอาจเต็ม`), permit manual export and retry, never falsely claim save complete.
- Test with real Chromium quota/blocked-storage; VM mock alone is partial evidence.

## Save migration compatibility

The game's `AGENTS.md` explicitly prioritizes correct save/load for this version; older-save compatibility is not necessarily mandatory. If adding fields or migration, provide defaults only when mathematically consistent and document impossible reconstruction of already lost progress; don't manufacture historical strain/progress. Save-load-save should be idempotent apart from explicitly documented derived ephemeral state.
