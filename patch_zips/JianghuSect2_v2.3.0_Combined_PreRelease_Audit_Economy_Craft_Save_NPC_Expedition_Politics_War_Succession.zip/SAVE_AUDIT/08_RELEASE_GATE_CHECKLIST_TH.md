# Checklist ผู้ทดสอบก่อนประกาศปล่อยแพตช์

## ต้องผ่านก่อน GO

- [ ] เทียบ baseline SHA256 และอ่าน AGENTS.md + project skills
- [ ] SV-01 save/load ไม่รีเซ็ต strain และ backlash ถูกต้องบนการอัญเชิญครั้งที่ 6
- [ ] SV-02 failed import rollback *ทุก* singleton registry และ runtime clock, not just world binding
- [ ] SV-03 reject bad balance/stocks; finite stones/ledger postconditions; ไม่มี JSON null poison
- [ ] SV-04 study/gather fractional progress อยู่ข้าม multiple save-load cycles
- [ ] SV-05 จำแนก transient cache กับ gameplay state โดยทดสอบ callers จริง; ไม่มี unintended bypass
- [ ] SV-07 QuotaExceededError มี UI warning + unsaved state และ export fallback
- [ ] SV-06 custom pill โลก A ไม่รั่วสู่โลก B
- [ ] SV-08 unknown schema rejected safely
- [ ] SV-09 pendingTicks/speed bounded; UI budget and mobile load measured
- [ ] NPC craft reserve/settle/replay guard ผ่านทุก phase
- [ ] Expedition and duel callback recovery full test
- [ ] ทดสอบ save slots, import invalid, background tab, quota และ reload หลังจบ battle/งานจริงผ่าน browser
- [ ] รัน full Node regression suites + schema validator, แสดงผล pass/fail จริง
- [ ] multi-seed soak อย่างน้อย 30–90 วันพร้อมครอบคลุมเศรษฐกิจ NPC/คลัง/CP
- [ ] รายงาน issue ที่เลื่อนแก้ให้ชัด พร้อมผู้รับผิดชอบและ rollback plan

**ห้ามให้คำว่า GO เพียงเพราะ checklist นี้มีเครื่องหมายครบจาก AI:** ต้องมีผลทดสอบซ้ำหลังแก้ใน build ที่จะส่งผู้เล่นจริง และตรวจไม่แทรก regression กับรายงานเศรษฐกิจ/สูตรก่อนหน้า.
