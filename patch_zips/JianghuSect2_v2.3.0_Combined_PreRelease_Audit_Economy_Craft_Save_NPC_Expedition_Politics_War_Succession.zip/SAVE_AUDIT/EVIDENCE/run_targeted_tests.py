import concurrent.futures,subprocess,json,time,os
root='/mnt/data/econ_audit_work/GAME_SOURCE'
cases=['save_integrity.js','legacy_save.js','craft_transactions.js','exploration_replay.js','cave_pools.js','fishing_river_suite.js','runtime_timing.js','content_economy.js','wild_resources.js','cp_economy.js','v300_tactical_combat_and_living_chronicle_suite.js','v350_macro_world_politics_and_alchemy_suite.js','v400_living_frontier_and_sect_charter_suite.js','v230_grand_dao_deep_parity_and_universal_arsenal_suite.js','merchant_guest_lifecycle.js','v320_dormant_awakening_suite.js','v235_comprehensive_mechanics_and_elemental_fusion_suite.js','v560_defensive_kungfu_and_aegis_suite.js']
def run(n):
 t0=time.monotonic(); cmd=['node',f'test/{n}']
 try:
  p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=40)
  return {'suite':n,'status':'PASS' if p.returncode==0 else 'FAIL','exit_code':p.returncode,'seconds':round(time.monotonic()-t0,2),'tail':(p.stdout+'\n'+p.stderr)[-1800:]}
 except subprocess.TimeoutExpired as e: return {'suite':n,'status':'TIMEOUT','seconds':round(time.monotonic()-t0,2),'tail':str(e)[:200]}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 rs=list(pool.map(run,cases))
p=subprocess.run(['node','tools/validate_data_schema.js'],cwd=root,text=True,capture_output=True,timeout=40)
rs.append({'suite':'tools/validate_data_schema.js','status':'PASS' if p.returncode==0 else 'FAIL','exit_code':p.returncode,'tail':(p.stdout+'\n'+p.stderr)[-1800:]})
out='/mnt/data/save_audit_work/targeted_tests.json'
open(out,'w').write(json.dumps(rs,ensure_ascii=False,indent=2));
from collections import Counter
print(Counter(x['status'] for x in rs));print('\n'.join(f"{r['status']:8} {r['seconds'] if 'seconds' in r else '-':>5} {r['suite']}" for r in rs)); print('Saved',out)
