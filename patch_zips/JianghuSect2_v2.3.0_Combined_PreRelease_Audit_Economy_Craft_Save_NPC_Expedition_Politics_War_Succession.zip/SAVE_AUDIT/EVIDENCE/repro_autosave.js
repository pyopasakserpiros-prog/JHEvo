'use strict';
const fs=require('node:fs'), path=require('node:path'), vm=require('node:vm');
const root=path.resolve(process.argv[2]||path.join(process.cwd(),'GAME_SOURCE'));
let toastCount=0,setCalls=0;
const ctx={
  U:{},SIM:{serialize:()=>'dummy-save',deserialize:JSON.parse},HC:{},MAP:{},Render:{},
  UI:{toast:()=>toastCount++},
  localStorage:{getItem:()=>null,setItem:()=>{setCalls++;throw new Error('QuotaExceededError')}},
  document:{readyState:'loading',addEventListener:()=>{}},
  addEventListener:()=>{},console
};
ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'js/main.js'),'utf8'),ctx);
ctx.G.W={t:500,day:1,seed:'autosave-failure',npcs:[],speed:1};
let thrown=false;try{ctx.G.autosave()}catch(e){thrown=true}
console.log(JSON.stringify({scenario:'actual main.js G.autosave localStorage quota error',setCalls,thrown,toastCount,playerNotInformed:!thrown&&toastCount===0},null,2));
