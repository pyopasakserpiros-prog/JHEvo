# ผลทดสอบจริง, รูปแบบพิสูจน์ และข้อจำกัดการรับรอง

## การทดสอบใหม่

- `SAVE_AUDIT/EVIDENCE/repro_save_lifecycle.js` เรียกโค้ดจาก GAME_SOURCE ต้นฉบับใน Node VM; **12 checks**, รันจบและ JSON มี `ok=true` ทั้งหมด แต่ `ok=true` หมายถึงสคริปต์ทำการพิสูจน์ได้ (หลายข้อคือ reproducing failures) **ไม่ใช่เกมผ่านการตรวจทุกข้อ**.
- `SAVE_AUDIT/EVIDENCE/repro_save_results.json` เก็บผลดิบ: `S-01` ถึง `S-09` (9 issue probes), `C-01` ถึง `C-03` (3 positive controls).
- `SAVE_AUDIT/EVIDENCE/repro_autosave.js` VM actual `js/main.js`, mock QuotaExceededError; `SAVE_AUDIT/EVIDENCE/repro_autosave_results.json`: no thrown, toastCount=0.

## ชุดเดิมที่รันผ่าน 19 ชุด (18 suite + 1 validator)

- `save_integrity.js` — PASS
- `legacy_save.js` — PASS
- `craft_transactions.js` — PASS
- `exploration_replay.js` — PASS
- `cave_pools.js` — PASS
- `fishing_river_suite.js` — PASS
- `runtime_timing.js` — PASS
- `content_economy.js` — PASS
- `wild_resources.js` — PASS
- `cp_economy.js` — PASS
- `v300_tactical_combat_and_living_chronicle_suite.js` — PASS
- `v350_macro_world_politics_and_alchemy_suite.js` — PASS
- `v400_living_frontier_and_sect_charter_suite.js` — PASS
- `v230_grand_dao_deep_parity_and_universal_arsenal_suite.js` — PASS
- `merchant_guest_lifecycle.js` — PASS
- `v320_dormant_awakening_suite.js` — PASS
- `v235_comprehensive_mechanics_and_elemental_fusion_suite.js` — PASS
- `v560_defensive_kungfu_and_aegis_suite.js` — PASS
- `tools/validate_data_schema.js` — PASS

**ข้อสรุป:** regression suites เก่าผ่าน = baseline ไม่พังในกรณีเดิม ไม่ใช่รับรองว่า `SV-01..09` ปิดแล้ว; ใหม่เป็น *defect-reproducing* tests ที่ต้องกลายเป็น *regression-preventing* tests หลังแก้.

## Positive controls ที่ยืนยันว่าไม่ควร report เป็นบัค
- `C-01`: จอง NPC brewBasic แล้วโหลด: settle ครั้งแรกสำเร็จ, ครั้งสอง fail, ของเพิ่มครั้งเดียว.
- `C-02`: expedition resolved/replay twice after load: replay does not increase reward.
- `C-03`: duel callback JS function missing on load by design but `cbKind` and resolver present; full UI duel outcome yet untested.

## ข้อจำกัดสำคัญ
- VM ≠ browser/UI automation. Test DOM/storage mocked for autosave; imported malformed saves intentionally modified; cannot claim ordinary player reaches all variants without external editing.
- Several underscore keys used in combat may be limited to transient fight state and some callers bypass cooldown by design. `SV-05` asks for game-design classification, not blanket “all '_' fields must persist”.
- Did not run 90–360 day balance soak; earlier 7/14 day sims belong to the economy report, not repeated here.
- Did not run full 139/139 claimed project suite; ran 18 selected suites plus validator, all passed.
- Cannot establish mobile Chromium storage failures or frame cost from Node VM alone. `SV-09` runtime degradation is risk, not measured.
- No game source, game assets or save file was changed; all audit scripts/data included for another AI to reproduce.

## Running script

```
node SAVE_AUDIT/EVIDENCE/repro_save_lifecycle.js /ABS/PATH/GAME_SOURCE
node SAVE_AUDIT/EVIDENCE/repro_autosave.js /ABS/PATH/GAME_SOURCE
```
Inspect JSON. `repro_save_lifecycle.js` should run on the original source baseline; after applying fixes, expected output of several issue probes must change, which is success for the patch but not for the old defect-presence checker.
