# ผลกระทบเป็นลูกโซ่และวงจรย้อนกลับ (Systemic Chain Reactions)

## Chain A — การหลบต้นทุนทักษะเทพด้วย reload
```
การอัญเชิญเทพ (5 ครั้ง)
  -> _divineStrain = 90
  -> บันทึกเซฟ (ตัวนับ '_' ถูกตัด)
  -> โหลด (strain หาย)
  -> ครั้งที่ 6 ไม่ติด vowBacklash
  -> รบชนะง่าย/บาดเจ็บลด/เวลา recovery ลด
  -> ใช้ยา/วัสดุรักษาน้อยลง + รางวัลสนามรบสูงขึ้น
  -> เงิน/CP/ระดับNPC เร็วกว่าฐานออกแบบ
  -> สงคราม/การเมือง/ตลาด/ความยากเนื้อเรื่องเสียสมดุล
```
**พิสูจน์:** chain 3 ขั้นแรกถึง no-backlash; ส่วนผลตลาดและสงครามเป็นการคาดการณ์ causal chain ที่ต้องทดสอบ balance ไม่ใช่สถิติ live gameplay.

## Chain B — ความคืบหน้างานย่อยถูกริบทุกครั้งที่เซฟ
```
NPC เรียน/เก็บของเป็นช่วง < threshold
  -> สะสม _studyHrsAcc/_gatherHrsAcc
  -> autosave ราย 3 นาที/สลับแท็บ
  -> ตัวนับหายหลัง reload
  -> จำนวน session, การเติบโต, ผลผลิตรายวันคลาดเคลื่อน
  -> NPC รุ่นใหม่ตามไม่ทัน/วัตถุดิบหายจากห่วงโซ่ผลิต
  -> ขาดแคลนสูตร/ตลาดและเวลาเล่นไม่เท่ากันระหว่างคนเซฟบ่อยกับคนเซฟน้อย
```
**พิสูจน์:** study actual 0.8h -> 0.2h after reload; gather เอกสารโค้ดรูปแบบเดียวกัน ยังไม่ได้รัน gather.

## Chain C — Global registry ซึมข้ามโลก
```
ผู้เล่นนำเข้าเซฟที่มี customPills
  -> SIM.deserialize เติม singleton ECO.itemById
  -> ในกรณี import ล้มเหลว, ไม่ rollback registry
  -> โลกเดิมยังอยู่ แต่ catalog กลางเปลี่ยน
  -> UI/ตลาด/สูตรที่ lookup ด้วย global id อาจใช้ชื่อหรือข้อมูลจากโลกอื่น
  -> ถ้ามีการขาย/คราฟต์ต่อ สินค้าและ ledger อาจอ้างอิงข้อมูลไม่ตรงกับ world state
```
**พิสูจน์:** registry ข้ามโลก/แม้โหลดล้ม; downstream UI/ตลาดเป็นความเสี่ยง ต้อง test end-to-end.

## Chain D — ตัวเลขผิดชนิดของเศรษฐกิจถาวรในเซฟ
```
import stones='INVALID'
  -> validation top-level ผ่าน
  -> ECO.pay คืน true จากการเทียบ < ที่ false สำหรับ NaN
  -> หักเงินแล้ว stones = NaN
  -> serialize -> JSON null
  -> โหลดครั้งถัดไป/ระบบซื้อขาย/สร้างอาคาร/จ่ายค่าแรงผิด
  -> ผู้เล่นไม่สามารถเชื่อความถูกต้องของเซฟได้
```
**พิสูจน์:** ทุกขั้นถึง JSON null. อาการ UI/AI ยาว ๆ ยังไม่รัน.

## Chain E — Autosave storage เต็ม
```
เล่นต่อเนื่อง -> localStorage.setItem ล้มเหลว
  -> catch ว่าง + ไม่แจ้ง UI
  -> เวลาเดินเกม แต่ข้อมูลเซฟยังเก่า
  -> ผู้เล่นออกจากเกมด้วยความเชื่อผิด ๆ ว่าบันทึกล่าสุด
  -> กลับมาแล้ว progress สูญหาย -> ผู้เล่นไม่เชื่อถือเกม
```
**พิสูจน์:** mock QuotaExceededError ทำให้ถูก swallow ไม่มี toast; การเกิด quota จริงบนอุปกรณ์ยังไม่ได้ benchmark.

## Chain F — Backlog ticks สูงผิดปกติ
```
import pendingTicks จำนวนมหาศาล
  -> bindWorld accepts
  -> frame ต้องไล่ทำงาน (มี SIM_BUDGET_MS ต่อเฟรม)
  -> backlog ไม่หายตามปกติ/อาจใช้เวลามาก
  -> การตอบสนองเกมและการจำลองถูกกระทบ
```
**พิสูจน์:** import/bind รับค่า; ผล FPS เป็นสมมติฐานต้องรัน browser จริง.

## Cross-team conflict และข้อควรระวัง
- ทีมตรวจ **วิถี/สายย่อย/อุปกรณ์** ควรได้รับเฉพาะ root persistence fields ที่มีผลกับทักษะ และผลจาก `_itemEfxCds` เพื่อไม่แก้ระบบท่า/ค่าสถานะซ้ำกัน.
- ทีมแก้ **เศรษฐกิจ/คราฟต์** ต้องยืนยันว่า transaction receipts ยังคงป้องกันการทำซ้ำ หลังแก้ serializer หรือ migration.
- ทีมแก้ **UI** ต้องทำแถบ/แจ้งเตือน autosave failure แบบไม่ spam และให้ export fallback; อย่าซ่อน error.
- ทีมแก้ **AI NPC** ต้องยืนยันว่า action state/receipt ที่โหลดเป็นคู่สอดคล้องกัน; ไม่รับ reward/ผลิตสินค้าเพิ่มเพราะ retry.
