# JianghuSect 2 v2.3.0 — Save/Load & Mid-Action Lifecycle Pre-Release Audit

**คำตัดสิน: NO-GO (ในภาพรวมยังมี Release Blockers)**  
**ฐานตรวจ:** `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip` · SHA256 `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`  
**ขอบเขต:** บันทึก/โหลด, import save, state persistence, halfway actions, และผลข้ามเศรษฐกิจ/ต่อสู้/NPC  
**ไม่มีการแก้โค้ดเกม** — เอกสารและการรันด้วย VM / Node.js แยกจากต้นฉบับเท่านั้น

## ผลสรุป

- **ข้อค้นพบใหม่ 9 รายการ:** P1 **6** รายการ; P2 **3** รายการ (เก็บหลักฐานไว้ครบใน `01_DETAILED_FINDINGS_TH.md`)
- **ตรวจพิสูจน์เฉพาะทาง 12 กรณี:** 9 ประเด็นทดสอบ + 3 positive controls; กรณี autosave ทดสอบแยกด้วย mock storage
- **ผ่านชุดทดสอบเดิม 19 ชุดงาน:** 18 target suites + `tools/validate_data_schema.js`
- **ข้อยืนยันสำคัญ:** `_divineStrain` หายหลังโหลดทำให้หนี backlash, มรรตัยสะสมเวลาเรียนแล้วเสียเศษส่วน, import ที่ล้มยังใส่ pill ลง registry กลาง, malformed stones ทำยอดเงินกลายเป็น `NaN`, autosave storage error ไม่มีคำเตือน
- **สิ่งที่ยังตรวจไม่ครบ:** คลิก UI ด้วย Chromium/มือถือจริง, restore หลังปิดแท็บจริง, stress import ขนาดใหญ่, resume หลังปิดโปรเซส, และ soak test 90–360 วันหลาย seed

## ทำไมจึงห้ามปล่อยตอนนี้

1. **ความเสี่ยงต่อความยุติธรรม:** reload เปลี่ยนผลลัพธ์ gameplay โดยไม่มี cost/timing เท่ากัน (`SV-01`, `SV-04`, `SV-05`).
2. **ความเสี่ยงต่อความสมบูรณ์ของเซฟ:** import ที่ล้มยัง mutate singleton, schema ที่ไม่รองรับถูกยอมรับ และตัวเลขผิดชนิดกระจายถึงบัญชีเศรษฐกิจ (`SV-02`, `SV-03`, `SV-08`).
3. **ความเสี่ยงสูญความคืบหน้า:** autosave failure แบบเงียบ (`SV-07`); field ที่ต้องคงไว้ถูก serialize ทิ้ง.

## สิ่งที่ไม่พบว่าเป็นบัคในรอบนี้

- **NPC craft receipt:** ทดสอบสั่งงาน NPC → save/reload → จบงานได้ **ครั้งเดียว**; การจบซ้ำถูกปฏิเสธ (`C-01`).
- **Expedition result:** ทำรายการหลัง reload ได้ครั้งเดียว; เรียกซ้ำไม่เพิ่มรางวัล (`C-02`).
- **Duel callback:** ฟังก์ชัน callback ใน RAM หายหลัง serialize ตามปกติ แต่ `cbKind='duel'` มี fallback resolver (`C-03`); ไม่เหมารวมว่า callback ทุกแบบพัง.
- **ใบจองงาน NPC orphan:** `ECO.pruneCraftTransactions()` ลบใบจองที่ไม่มีงานตรงกันโดยไม่คืนของ; เทสต์เดิมระบุเป็นแนวนโยบาย จึงบันทึกเป็นสิ่งที่ต้องทบทวน UX/กติกา ไม่ตัดสินว่าเป็นบัคที่ยืนยันแล้ว.

## แนวทางตัดสินก่อนเผยแพร่

แก้ root ของ `SV-01`, `SV-02`, `SV-03`, `SV-04`, `SV-05`, `SV-07` และเพิ่ม regression tests; ตรวจจริงผ่าน browser normal save/load, import malformed, reload while combat/action, quota error, และทดสอบต่อเนื่อง 30–90 วันหลาย seed โดยไม่ถือว่า test เก่าผ่าน = บัคใหม่หมดไป. ให้ฝ่ายพัฒนา reconcile กับรายงานเศรษฐกิจ/คราฟต์เดิมก่อนประกาศ GO.
