# คำสั่งส่งต่อ AI แก้โค้ด — การแก้ root cause แบบไม่กระทบระบบอื่น

**บทบาท:** AI ผู้แก้ไขต้องอ่าน `AGENTS.md` ใน archive เกมก่อน; อ่าน `.agents/skills/save-system-patterns/SKILL.md`, `qa-test-matrix`, `gameplay-architecture`, `economy-balancing`, `combat-design`, `ai-behavior-patterns` ตามขอบเขต และยึดซอร์ส/ผลทดสอบจริงก่อนข้อเสนอในรายงาน. อย่าแก้แค่เพื่อให้ test ผ่าน และอย่าปรับสมดุลวิถี/อุปกรณ์ซ้ำกับทีมอื่นนอกจาก root persistence.

### Phase 0 — Lock baseline
1. จด archive SHA256 และ copy source for patch; ห้ามแตะ `js/human_core.js` ผิดจาก baseline.
2. รัน `node test/save_integrity.js`, `node test/legacy_save.js`, `node test/craft_transactions.js`, `node tools/validate_data_schema.js`.
3. รัน `node SAVE_AUDIT/EVIDENCE/repro_save_lifecycle.js /path/to/GAME_SOURCE` จาก ZIP รายงานนี้ เพื่อคอนเฟิร์ม behavior ก่อนแก้.

### Phase 1 — Persistence correctness (P1)
1. เขียน tests ก่อน: `GV01` summon 5 times -> save/load -> sixth triggers exactly same backlash; `GV02` study 4×0.2 -> save/load -> 0.2 increments session once; `GV03` gather fractional same.
2. Define gameplay persisted state; avoid blanket persist `_` cache fields. Test cooldown field at every actual caller (especially `ignoreCooldown:true` case). Preserve target game design.
3. Add save/load midbattle with item effect internal cooldown, status immunity, beast fusion; test no unexpected replay and status TTL according to game ticks.
4. Legacy current-version saves that already lost fields: support safe default & disclose that old dropped progress is unrecoverable; no invented historical events.

### Phase 2 — Transactional import (P1)
1. `GV04` failed import with `customPills` and malformed `craftTransactions.open` must leave every singleton unchanged, not just `HC.nowDay`/`STATS.now`.
2. `GV05` loading world A with custom pill, then new world B: B registry does not contain pill A unless an intentionally global static item.
3. `GV06` reject non-finite/wrong-type stones and stock nested values before assigning state. `ECO.pay/earn` must refuse invalid amount/state and preserve ledger invariant.
4. `GV07` bad unknown `schemaVersion` rejected without side effects; intentionally supported legacy version may migrate.

### Phase 3 — Storage and bounded runtime (P1/P2)
1. `GV08` simulate QuotaExceededError from localStorage, verify player-visible Thai message, `unsaved=true`, manual export path; do not claim autosave succeeded.
2. `GV09` imported huge `pendingTicks` and speed rejected/clamped with user-facing policy; benchmark real browser on low-end phone.
3. `GV10` after valid save/load/new game, dynamic registry scope correct, no duplicate prices/recipes.

### Phase 4 — Preserve stable paths (anti-regression)
1. `GV11` NPC craft receipt: reserve → save/load → produce once → replay blocked; ledger and stock exact.
2. `GV12` expedition reward: save while pending → resolve once → replay blocked.
3. `GV13` duel callback: use `cbKind` recovery; run actual result through end-of-fight callback rather than requiring JS function in JSON.
4. `GV14` lifecycle matrix in `03_MID_ACTION_LIFECYCLE_MATRIX_TH.md`, including market/sect orders/caravan/rune after economics patches.
5. `GV15` compare N ticks uninterrupted vs with save/load checkpoints across 3+ seeds (RNG state/inventory/CP/world event), allow documented visual derived diffs only.

### Phase 5 — Release gate
- all P1 fixed and verified by new reproducible regression tests;
- 18 relevant Node suites and schema pass, then full `node tools/run_parallel_tests.js` when resources allow;
- browser UI on Chromium and phone for save, load, slots, quota, hidden tab, import invalid;
- 30–90 day multi-seed soak with bounded resource budget; if not run state `NOT_TESTED`;
- no new duplication/loss of inventory, stones, CP, task receipts, and achievements;
- explicitly report unresolved P2, policy decisions for receipt pruning, and rollback plan.

### Concrete handoff

Please do not code by copying suggested snippets blindly. Confirm every source location against the exact source SHA, patch minimal but systemic, include tests that **fail before** and **pass after**, and provide a change list with code locations and reproducible commands. This ZIP contains **audit only**, not modifications.
