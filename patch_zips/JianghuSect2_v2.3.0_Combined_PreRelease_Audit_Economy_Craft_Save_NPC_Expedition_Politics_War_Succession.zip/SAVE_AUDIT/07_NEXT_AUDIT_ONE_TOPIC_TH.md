# ข้อเสนอ Audit ถัดไป เพียงหนึ่งระบบ: NPC AI / Scheduling / Action Interruption

**แนะนำตรวจต่อ: ระบบตัดสินใจ การจัดคิวงาน และการขัดจังหวะของ NPC (NPC AI, Job Scheduling & Action Lifecycle)**

### เหตุผลที่ต้องทำเป็นลำดับถัดไป

- เศรษฐกิจ/สูตร/คลังถูกกำหนดโดยแรงงาน NPC แต่ตัวเลือกงานจริงมีเงื่อนไขซ้อนกัน ตั้งแต่ผู้มีสิทธิ์ทำงาน ระยะทาง ช่วงเวลา ความเหนื่อย สถานที่ ต้นทุน การพัก และการถูก interrupt.
- เมื่อ save/load ถูกแก้แล้ว จะมองเห็นความแตกต่างระหว่างงานที่ควรดำเนินต่อ กับงานที่หยุดกลางทาง/โดนแทนที่ และพิสูจน์ได้ว่าทรัพยากรไม่หาย/ไม่เพิ่ม/ไม่ทำซ้ำ.
- หาก NPC ตัดสินใจผิดซ้ำ ๆ แม้เศรษฐกิจและสูตรถูกต้อง ระบบอัตโนมัติจะทำให้สำนักขาดอาหารหรืออุปกรณ์ ผลิตยาไม่ได้ และอาจติดทางตันแบบที่ unit tests ตรวจไม่พบ.

### วิธีตรวจละเอียดทีละขั้น

1. ไล่ state machine ของ task: idle → choose → reserve → travel → work → finalize/failed/cancelled; map ทุก entrypoint และ exit.
2. ตรวจ utility/priority starvation: งาน essential (food, healing, crafting required progression) ถูกงานที่ reward สูงกว่าบดบังหรือไม่.
3. ตรวจห่วงโซ่ NPC state เช่น hunger/stamina/injury/discipline → job switching → material/warehouse → production → sect economy → skill progression.
4. ทดสอบ NPC 1/20/80/200 ตัวภายใต้งบ tick; สัดส่วนผู้ทำงาน/เดินทางซ้ำ/idle และการใช้ทรัพยากร.
5. Simulate missing building, missing materials, blocked path, dead worker, station contention, job interruption, save/load midtask, duty assignment change.
6. ตรวจ cooldown การตัดสินใจและการผลิตซ้ำ, priority inversion, duplicate wages/rewards/CP, stock reservation consistency.
7. ทำหลาย seed 30/90/180 วัน เทียบ food stockouts, medicine shortage, debt/cash, NPC mortality, jobs completed, idle percentage; เป็นเกณฑ์ต้องพิสูจน์หลังแก้ไม่ใช่สรุปจากรอบนี้.
8. สรุป bug พร้อมตำแหน่งโค้ด, reproducer, chain impact, game-design intent และ checklist ก่อนปล่อย.

**ไม่ตรวจซ้ำ** วิถี สายย่อย หรือค่าอุปกรณ์ที่อีกแชทดูแล; แตะเฉพาะ integration ของการเลือกงานและผลต่อสำนัก. ข้อมูลเก่าใน `AUDIT/`, `CRAFT_AUDIT/`, `SAVE_AUDIT/` ใช้เป็น baseline เดียวกัน.
