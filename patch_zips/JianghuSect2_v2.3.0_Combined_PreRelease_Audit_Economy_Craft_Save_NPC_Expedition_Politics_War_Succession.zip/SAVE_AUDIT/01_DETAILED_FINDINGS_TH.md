# ข้อค้นพบ Save/Load รายประเด็นพร้อมหลักฐานและแนวทางแก้

**อ่านก่อนใช้งาน:** `CONFIRMED_RUNTIME` หมายถึงพิสูจน์ด้วยการเรียกโมดูลใน Node VM จากโค้ดต้นฉบับ ไม่ได้ยืนยันว่าเส้นทางนี้ผู้เล่นกดได้ทุกกรณีใน UI; `CONFIRMED_MOCK_STORAGE` คือจำลองการโยน error ของ browser storage. ผลแต่ละรายการมีข้อจำกัดของตนเอง ไม่เหมารวมเป็น exploit จากหน้าเกม.

## เกณฑ์ระดับความรุนแรง
- **P0:** เซฟเสีย/ของฟรี/ฉีกกติกาขั้นวิกฤตในทางเข้าผู้เล่นที่พิสูจน์ได้อย่างหนัก ต้อง block release.
- **P1:** เซฟ/ความต่อเนื่อง/ผลเกมผิดที่พิสูจน์ได้ หรือมีแนวทางสูญความคืบหน้า; ต้องแก้ก่อนปล่อย.
- **P2:** รูปแบบข้อมูลผิด ความเสี่ยงฮาร์ดเดนหรือปัญหาจำกัดเงื่อนไข ที่ต้องตรวจ/ปรับให้แน่น.

### SV-01 — [P1] ตัวนับผลเสียจากอัญเชิญเทพหายหลังโหลด ทำให้หลีกเลี่ยง backlash ได้
- **สถานะ:** `CONFIRMED_RUNTIME`
- **ตำแหน่งโค้ด:** `js/sim.js:827-828; js/cultivation.js:9150-9169; js/combat.js:4651,4667,4685`
- **ขั้นตอนก่อปัญหา:** ใช้พลังอัญเชิญ 5 ครั้งจน _divineStrain=90 → เซฟ → โหลด → ใช้ครั้งที่ 6
- **หลักฐานทดสอบ:** ไม่โหลด: ครั้งที่ 6 เกิด vowBacklash; หลังโหลด: ครั้งที่ 6 ไม่เกิด; repro S-02.
- **ผลกระทบต่อระบบอื่น:** ลดต้นทุนการใช้พลังระดับสูง → การต่อสู้ได้เปรียบ → บาดเจ็บ/การใช้โอสถน้อยลง → เศรษฐกิจและความก้าวหน้าเสียสมดุล
- **แนวทางแก้ไขที่เสนอ:** persist ตัวนับเป็น domain state หรือ allowlist เฉพาะ field ที่คงอยู่; ทดสอบก่อน/หลังโหลดและ threshold 100; ไม่ persist cache จริง
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูง: reproduced direct module call; combat callsites confirmed; browser UI execution not tested

---

### SV-02 — [P1] นำเข้าเซฟผิดรูปแบบแล้วล้มเหลว แต่ยังเปลี่ยน registry โอสถกลางของเกม
- **สถานะ:** `CONFIRMED_RUNTIME`
- **ตำแหน่งโค้ด:** `js/sim.js:914-919; js/sim.js:939; js/economy.js:321-326`
- **ขั้นตอนก่อปัญหา:** เซฟมี customPills ใหม่ และ sect.craftTransactions.open=null → deserialize โยน error หลัง insert registry
- **หลักฐานทดสอบ:** repro S-07: โหลดล้มเหลว Cannot convert undefined or null to object แต่ ECO.itemById มี id ของ pill จากเซฟที่ล้มเหลว
- **ผลกระทบต่อระบบอื่น:** การ import ล้มเหลว → global mutable state ปะปน → โลกเดิม/โลกใหม่เห็นของแปลกหรือสูตรชื่อผิด → save/export ต่ออาจพ่วงสิ่งผิดโดยไม่ตั้งใจ
- **แนวทางแก้ไขที่เสนอ:** transactional load: parse/validate nested state ทั้งหมดก่อนแตะ singleton; commit registry เฉพาะหลังสร้างโลกสำเร็จ; rollback ทุก external side effect on error
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูง: confirmed in actual deserializer VM

---

### SV-03 — [P1] เซฟยอดศิลาวิญญาณชนิดผิดได้ → จ่ายเงินแล้วกลายเป็น NaN → เซฟเป็น null
- **สถานะ:** `CONFIRMED_RUNTIME`
- **ตำแหน่งโค้ด:** `js/sim.js:870-892; js/economy.js:128-129; js/sim.js:827-828`
- **ขั้นตอนก่อปัญหา:** แก้ raw.sect.stones='INVALID' แล้วโหลด → ECO.pay(W,1)
- **หลักฐานทดสอบ:** repro S-05: deserialize รับ; ECO.pay คืน true; stones เป็น NaN; serialize เขียน null
- **ผลกระทบต่อระบบอื่น:** เซฟผิดชนิด/ค่าตั้งต้นผิด → รายจ่ายตรวจไม่ผ่าน → ledger และยอดเงินเสีย → กลไกผลิต/อาคาร/ซื้อขายทำงานผิด → เซฟใหม่ถาวรเสีย
- **แนวทางแก้ไขที่เสนอ:** validate nested sect.stones, inventory, ledger, CP, stock and all monetary counters as finite bounded numeric values; guard pay/earn amount and postcondition; reject bad imports before mutation
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูง: malformed import reproduced; ordinary save creation from gameplay not established

---

### SV-04 — [P1] ชั่วโมงเรียน/เก็บรวบรวมที่สะสมเศษส่วนหายเมื่อเซฟ–โหลด
- **สถานะ:** `CONFIRMED_RUNTIME`
- **ตำแหน่งโค้ด:** `js/sim.js:827-828; js/cultivation.js:8369-8372; js/cultivation.js:8395-8398`
- **ขั้นตอนก่อปัญหา:** มรรตัยเรียน 0.2h × 4 ครั้งสะสม _studyHrsAcc=0.8 → โหลด → เรียนอีก 0.2h
- **หลักฐานทดสอบ:** repro S-03: ก่อนโหลด acc=0.8; หลังโหลดเรียนต่อ acc=0.2 และ studySessions ยังคง 0 แทนที่จะเป็น 1; _gatherHrsAcc ใช้รูปแบบเดียวกัน
- **ผลกระทบต่อระบบอื่น:** การทำงานช่วงสั้นหลายรอบถูกริบความคืบหน้า → ผู้เล่นที่เซฟบ่อยเติบโตช้ากว่าผู้เล่นที่เปิดเกมต่อเนื่อง → ผลผลิต/แรงงาน NPC/ความสมดุลเปลี่ยนตามการเซฟ
- **แนวทางแก้ไขที่เสนอ:** save fractional progress ใน state ที่เป็น domain-specific; test partial sessions multiple unload cycles; เคารพนโยบายของ gameplay คงเดิม
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูงสำหรับ study; gather risk confirmed by source symmetry, need focused execution test

---

### SV-05 — [P1] ตัวกรอง _field ลบคูลดาวน์และสถานะต่อสู้ที่ไม่ใช่แคช
- **สถานะ:** `CONFIRMED_RUNTIME_WITH_ACCESS_CAVEAT`
- **ตำแหน่งโค้ด:** `js/sim.js:13,827-828; js/cultivation.js:8871-8896; js/combat.js:2531-2550,5252-5271,5449,5548-5581`
- **ขั้นตอนก่อปัญหา:** สร้าง _gravityFieldCdUntil แล้วใช้ซ้ำก่อนครบเวลา → ถูกห้าม; เซฟ–โหลด → เรียกใช้สำเร็จทันที
- **หลักฐานทดสอบ:** repro S-01, S-08: _gravityFieldCdUntil, _duetCdUntil, _ccImmuneUntil, _itemEfxCds, _beastFusedUntil, _lastGearSwapAt ถูกลบ. CAVEAT: normal MASS_ABSORPTION passes ignoreCooldown:true; duet skill caller via normal UI unverified
- **ผลกระทบต่อระบบอื่น:** cooldown/immune/proc state ที่ควรคงอยู่ถูกรีเซ็ต → ผลต่อความถี่ของ buff/trigger หรือ gear decisions → พลังการต่อสู้และทรัพยากรแตกต่างระหว่างการเล่นต่อเนื่องกับ reload
- **แนวทางแก้ไขที่เสนอ:** inventory ทุก underscore key: classify domain state vs derived cache; persist only domain-required; preserve timing in game ticks; add real battle callsite test, avoid patching cooldown game-design without test
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูง: serialization and API tests; user exploitation for gravity default combat path NOT demonstrated

---

### SV-06 — [P2] โหลดเซฟที่มีโอสถ custom สำเร็จแล้ว singleton registry ยังปะปนไปยังโลกใหม่
- **สถานะ:** `CONFIRMED_RUNTIME`
- **ตำแหน่งโค้ด:** `js/sim.js:914-919; js/economy.js:2418-2468`
- **ขั้นตอนก่อปัญหา:** โหลดโลกที่มี customPills id เฉพาะ → สร้างโลกใหม่ในแท็บเดียวกัน
- **หลักฐานทดสอบ:** repro S-06: newWorldHasCustomPill=false แต่ ECO.itemById[id] ยังมีชื่อจากโลกก่อน
- **ผลกระทบต่อระบบอื่น:** โลกใหม่แม้ไม่มี content พิเศษกลับยังมองเห็น catalog global ส่วนเกิน → inventory/store lookup และ formula assumptions คลาดเคลื่อน → ผู้เล่นสงสัยว่าโลกและเซฟปะปนกัน
- **แนวทางแก้ไขที่เสนอ:** separate registry by world/save scope; rebuild dynamic index on bind/load/new game; clear world-only registration before moving worlds; do not clear static registries
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูง: registry visible after world switch; specific player UI surface not tested

---

### SV-07 — [P1] Autosave กลืน error จาก localStorage จนผู้เล่นไม่รู้ว่าความคืบหน้าไม่ได้บันทึก
- **สถานะ:** `CONFIRMED_MOCK_STORAGE`
- **ตำแหน่งโค้ด:** `js/main.js:34-35; js/main.js:59`
- **ขั้นตอนก่อปัญหา:** จำลอง localStorage.setItem โยน QuotaExceededError ระหว่าง G.autosave()
- **หลักฐานทดสอบ:** repro_autosave.js on original main.js VM: setCalls=1, thrown=false, toastCount=0
- **ผลกระทบต่อระบบอื่น:** พื้นที่เก็บเต็ม/โหมดจำกัด storage → auto-save fail เงียบ → ผู้เล่นปิดเกมโดยคิดว่าเซฟล่าสุดแล้ว → สูญความคืบหน้าหลายชั่วโมง
- **แนวทางแก้ไขที่เสนอ:** catch แยก quota/security/storage; แจ้งเตือนผู้เล่นและ flag unsaved; retain fallback/export hint; do not mark last save successful; test quota, disabled storage, tab background
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูงใน mock storage: browser quota behavior not exercised end-to-end

---

### SV-08 — [P2] ตัวตรวจ version ของ save schema รับสตริง schema ที่ไม่รู้จักบางแบบ
- **สถานะ:** `CONFIRMED_RUNTIME`
- **ตำแหน่งโค้ด:** `js/sim.js:859-865`
- **ขั้นตอนก่อปัญหา:** set schemaVersion='2.0.9999-this-is-not-supported'
- **หลักฐานทดสอบ:** repro S-04: unsupported schema accepted due to lexicographic greater-than fallback
- **ผลกระทบต่อระบบอื่น:** เซฟ schema ไม่รู้จัก → migration ไม่ตรงรูปแบบ → อ้างอิง field ที่ขาด/ไม่ครบ → โลกเกิดพฤติกรรมผิดเงียบหรือโหลดล้มในขั้นตอนลึก
- **แนวทางแก้ไขที่เสนอ:** compare exact supported set + explicit semver parser only for future detection; migrate whitelisted legacy versions; reject unknown schema safely
- **ระดับความเชื่อมั่น/ข้อจำกัด:** สูง: unsupported schema recognized as accepted

---

### SV-09 — [P2] จำนวน tick ค้างที่ฝังในเซฟถูกยอมรับแม้สูงผิดปกติ
- **สถานะ:** `CONFIRMED_INPUT_UNBOUNDED_RUNTIME_UNVERIFIED`
- **ตำแหน่งโค้ด:** `js/sim.js:917; js/main.js:20-23,40-57`
- **ขั้นตอนก่อปัญหา:** ตั้ง runtimeTiming.pendingTicks=1,000,000,000 แล้ว import
- **หลักฐานทดสอบ:** repro S-09: deserializer รับค่า; bindWorld accepts any finite nonnegative; game frame work budget limits work per frame but backlog remains enormous
- **ผลกระทบต่อระบบอื่น:** โหลดเซฟผิดปกติ → ตัวจำลองพยายามไล่ tick ค้างจำนวนมาก → UI ลื่นลดลง/ความคืบหน้าจำลองไม่ตรงที่ผู้เล่นคาด, แม้มีเวลางบ per-frame
- **แนวทางแก้ไขที่เสนอ:** cap pendingTicks and speed to safe policy; on impossible backlog warn/reset or amortize with documented rule; confirm native UI behavior and low-end mobile
- **ระดับความเชื่อมั่น/ข้อจำกัด:** กลาง: validation demonstrated, real browser performance not benchmarked

## ข้อสังเกตที่ต้องไม่แก้ผิดทิศ

- `applyGravityField` ในท่า `MASS_ABSORPTION` เรียก `{ free:true, ignoreCooldown:true }` จริง: จึงห้ามสรุปว่า *ผู้เล่นกดรีโหลดเพื่อข้าม gravity cooldown* ผ่านท่านี้ได้; ทดสอบใน VM ยืนยันเพียงข้อผิดพลาดของ persistence และ API แบบไม่ ignoreCooldown. ตรวจการเข้าถึงท่าอื่นก่อนตั้งสถานะ exploit.
- เอฟเฟกต์ `_ccImmuneUntil` บางอันอาจตั้งใจจบพร้อมไฟต์ ขึ้นกับขอบเขตสถานะในเกม; ต้องกำหนด domain-level spec และทดสอบ mid-fight load ไม่ใช่ persist ทุก key ตามอำเภอใจ.
- โค้ด rollback นาฬิกา `HC.nowDay`/`STATS.now` มีอยู่แล้วใน catch ของ `SIM.deserialize`, แต่ยัง rollback global item registry ไม่ครบ; อย่าลบ logic เดิม.
- ข้อค้นพบเกี่ยวกับ `stones` มี root cause เชื่อม `ECO.pay/earn` ที่ audit เศรษฐกิจพบก่อนหน้า; แยกหน้าที่ **deserialize validation** กับ **payment invariant** ออกจากกัน.
- ถ้าจะเปลี่ยน schema ใหม่ต้องพิจารณา `AGENTS.md` ว่าเซฟเวอร์ชันปัจจุบันต้องโหลดต่อได้ถูกต้อง และระบุแนวทาง migrate/persist ไม่ใช่แค่เปลี่ยนชื่อฟิลด์.
