# Matrix ทดสอบ Mid-Action Lifecycle ทุกจุดตัดที่สำคัญ

**คำจำกัดความ:** ข้อที่เขียนว่า “ต้องทดสอบ” ยังไม่มีผลยืนยันว่า bug เกิดจริง. ตารางนี้คือ acceptance coverage ที่ควรรันก่อน GO. ใช้ save ณ ก่อนสั่ง/หลังจ่าย/ระหว่างทำ/เมื่อสำเร็จ/หลังคืนรางวัล และทดสอบ import เดิมซ้ำ.

| ระบบ | จุดตัดบันทึก/โหลด | invariant ที่ต้องตรวจ | สถานะ audit |
|---|---|---|---|
| เงิน/ledger | ก่อนจ่าย, หลังจ่าย, import ยอดผิด | จ่ายได้เมื่อยอดและจำนวนถูกต้อง; เงิน finite; รายการ ledger ตรงยอด | **พบ SV-03** |
| โอสถ custom | ก่อน import, import error, เปลี่ยนโลก | world registry isolated; unsuccessful load has zero side effects | **พบ SV-02, SV-06** |
| ระบบอัญเชิญ | ก่อนชน backlash, หลังเซฟ/โหลด | strain และผลเสียเท่ากันทั้งเล่นต่อกับ reload | **พบ SV-01** |
| มรรตัยศึกษา | หลัง 0.2h × 4, แล้วโหลด | 0.8h เดิม + 0.2h ใหม่ → session นับครบ | **พบ SV-04** |
| มรรตัยเก็บเกี่ยว | หลังสะสมเศษส่วนไม่ครบ | progress ไม่สูญหายและไม่บวกซ้ำ | **ต้องทดสอบด้วย runtime** |
| คูลดาวน์ท่า/ITEM proc | ก่อน/ระหว่าง battle, โหลดแล้วใช้ต่อ | cooldown/buff immunity ที่ออกแบบให้คงอยู่ไม่ reset | **พบ field stripping; UI ยังต้องทดสอบ** |
| NPC คราฟต์ผ่าน receipt | หลังจองวัตถุดิบ ก่อนจบ | หักครั้งเดียว ผลิตครั้งเดียว receipt settle ได้ครั้งเดียว | **ผ่าน positive control C-01** |
| NPC เปลี่ยนงานขณะจอง | สั่ง A → save → สั่ง B → load | ยกเลิกและ return/refund ตามกติกา; ไม่หายเงียบ | **ต้องตัดสิน policy; existing test intentional** |
| Expedition | ยังไม่รับรางวัลแล้ว save/load | รับผลหนึ่งครั้ง, replay ไม่จ่ายซ้ำ | **ผ่าน C-02** |
| Arena/Duel | ระหว่างไฟต์/ก่อน callback | identity/owner/slot ผลแพ้ชนะถูกต้องหลัง restore | **มี cbKind resolver C-03; outcome ยังต้องทดสอบ** |
| Merchant purchase | ก่อนกดซื้อ, หลังหักเงิน, หลังรับของ | debit และ credit สอดคล้อง, retry ไม่ซื้อซ้ำ | **ต้องทดสอบ UI + save** |
| Caravan | ระหว่างส่ง/รับรางวัล | no duplicate payout on reload, cooldown/route persists | **เชื่อมประเด็น Economy P0 เดิม; ต้องทดสอบหลัง patch** |
| Sect orders | ก่อน/หลังสร้างสินค้าตามราชโองการ | cost charged exactly once, reproducible save | **เชื่อม Economy P0 เดิม** |
| Gear rune | หลังฝัง, ระหว่างไฟต์, หลังโหลด | ไม่มี repeated free growth, passive modifiers match | **เชื่อม Economy audit เดิม** |
| Wild resource | หลัง harvest, ระหว่าง respawn | removed node/remaining stable; no refarm via load | **ยังไม่ทดสอบ direct reload** |
| Fishing | หลัง cast/ก่อน loot | reward once, RNG state stable | **suite เดิมผ่าน; direct mid-cast ยังไม่ทำ** |
| Save slots | slot overwrite, import bad file | existing good slot unmodified on reject | **save_integrity suite pass; nested invalid remains** |
| Autosave | localStorage quota/permission | แจ้ง saved/unsaved อย่างตรงไปตรงมา | **พบ SV-07** |
| Timing | paused, speed 0/48, giant pending | loaded frames bounded, no frozen backlog | **SV-09 input accepts; browser performance pending** |

## Test case boundary ครอบคลุมขั้นต่ำ

- Save at t=0, day boundary, month boundary, exactly on cooldown expiration, one tick before threshold, and after threshold.
- Explicit 0, negative, string, `null`, `NaN` represented as JSON `null`, fractional and >MAX_SAFE_INTEGER for every numeric economy/counter field.
- Action/npc missing, npc dead, orphan receipt, duplicate receipt id, invalid `ledger.open`, invalid enum/status, wrong schema, missing optional sections.
- Load same snapshot repeatedly across different worlds/with different customPills; check clean singleton registries and memory footprint.
- Compare baseline uninterrupted simulation against save/load checkpoints at identical RNG/seed and ticks (ignore visual interpolation cache only).
- Browser quota exceeded, storage disabled, background page hidden and aborted storage write; verify user-visible warning and fallback.
