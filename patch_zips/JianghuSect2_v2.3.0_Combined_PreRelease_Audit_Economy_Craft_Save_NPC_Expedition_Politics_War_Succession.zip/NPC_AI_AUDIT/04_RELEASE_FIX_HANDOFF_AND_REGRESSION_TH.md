# คำสั่งส่งต่อ AI เขียนโค้ด — NPC AI Pre-Release Fix & Regression

**งานนี้เป็น audit ไม่ใช่ซอร์สที่แก้แล้ว**. เริ่มด้วยอ่าน `AGENTS.md` ทั้งฉบับ, `.agents/skills/ai-behavior-patterns/SKILL.md`, สกิล QA/Save/Economy/Performance ที่เกี่ยวข้อง และเทียบกับแพตช์ล่าสุดก่อนแก้ อย่าคัดลอก patch แบบสุ่มโดยไม่รัน test

## ลำดับแก้และข้อแลกเปลี่ยน

### รอบ 1: รักษาความถูกต้องของธุรกรรม [NPC-AI-001/002] — block release

1. สร้าง action lifecycle contract ที่ชัดเจน: `created -> reserved -> in_progress -> settled_success|settled_failure|canceled|expired|death_closed` และห้ามมี receipt ที่ไม่มี owner หรือไม่มี active action โดยไม่มี terminal record
2. ครอบคลุมทุกทางออก `AI.interruptFor`, `AI.cancelAct`, `AI.kill`, expiry, failToMove, forced order changes, save/load migration, death/retirement/exile, restart world
3. เลือกนโยบายต้นทุนอย่างเป็นธรรม (คืนเต็ม/บางส่วน/scrap) และเก็บ “เหตุที่สูญ” ให้ผู้เล่นเห็น; **ห้าม double refund/dup** หรือทำให้สูตรไม่เสียค่าใช้จ่าย
4. ครอบคลุม `brew`, `forge`, `brewBasic`, `cook` และ personal crafting ที่ใช้ resource contract ร่วมกัน; ถ้าเป็นงานพิเศษให้ตรวจสิทธิ์และ receipt เป็นรายทางเข้า
5. หลังแก้ต้องมี idempotence test: cancel ซ้ำ, load ซ้ำ, kill ซ้ำ, finish แล้ว cancel, callback fail, save ก่อนและหลัง settle

### รอบ 2: ระบบตำแหน่ง/คำสั่ง/วิกฤต [NPC-AI-003/004/006/007]

- `authorizedOfficerFor(post)` ต้องเป็น SSOT ทั้ง reviewOffice/performDuty/hasAuthority/แผน/การส่งงาน ให้เลือก delegate ที่พร้อมก่อน holder ที่ไม่พร้อม, ไม่ออกคำสั่งซ้อน
- `officePlan` และ `officeOrder` ใช้ revision/stale invalidation; เมื่อวิกฤตหมด ต้องยกเลิก order ที่เชื่อม target/action เก่า ห้ามทิ้งแรงจูงใจ 1440 นาที
- cache `COG.role` และ `COG.modifiers` ต้องเห็นการเปลี่ยน role/plan/order ทันทีหรือใน latency ที่ออกแบบและทดสอบได้; รักษาประสิทธิภาพที่ 50–100 NPC ด้วยการ version cache เฉพาะเมื่อมี state change
- ห้ามให้เจ้าหน้าที่ที่ away/sealed/jail/dead ปฏิบัติคำสั่งจริง; test การโอนกลับเมื่อหายป่วย และการเปลี่ยนตำแหน่งหลายครั้งในวันเดียว

### รอบ 3: กฎสถานะ NPC แข็ง [NPC-AI-005]

- ใส่ hard gate ของ jail/sealed/away/injured/dead ในทุก API ที่เริ่มงาน; ถ้า cell เต็มให้คง waiting_sentence ที่ไม่เล็ดลอดกิจกรรมปกติ
- ห้ามทำให้ผู้ต้องขังอดอาหาร/รักษาไม่ได้; อาหารและการรักษาเป็น exception ที่ตรวจได้; ถ้าเซลล์ว่าง ให้ retry sentence ไม่ติด cooldown 25 นาที
- เพิ่ม log/เหตุผลให้ผู้เล่นตรวจสอบได้

### รอบ 4: ความถูกต้องเชิงออกแบบและ determinism [NPC-AI-008/009/010]

- ตัดสินความหมาย rewards ของผู้ช่วยว่าจ่ายเพราะเวลา/ผลงานจริงอย่างไร; ถ้ายังคง reward ให้มีหลักฐาน work contribution
- แก้ comparator guardRoster: random score ต่อคนก่อน sort, tie-break deterministic, รัน cross-engine
- แก้ comparator memories: stable total ordering, tests retention > 40, ทดสอบความสัมพันธ์/ความจำข้ามโหลด

## Regression Acceptance Matrix (กรณีต้องเพิ่ม)

| # | Scene/Setup | Assertion ก่อนอนุมัติแพตช์ |
|---|---|---|
| 01 | หิวระหว่าง brew หลัง reserve | ledger ปิดถูกต้อง stock คืน/สูญตามนโยบาย มีบันทึก และไม่มีสินค้าเกิน |
| 02 | หิวระหว่าง cook หลังหัก grain | grain ไม่หายแบบเงียบ, ไม่เกิด meal ฟรี, ledger ปิด |
| 03 | รักษาฉุกเฉินระหว่าง forge | ไม่ซ้ำทรัพยากร/ไม่สร้างอุปกรณ์ฟรี |
| 04 | พักผ่อน/เทศกาลขัดจังหวะงาน NPC | terminal states ทุกทางออกถูกต้อง, cooldown สมเหตุสมผล |
| 05 | NPC ตายหลังจองวัตถุดิบ | เศรษฐกิจและทรัพย์สินหลังตายอนุรักษ์ตามนโยบาย, ไม่มี orphan |
| 06 | NPC เกษียณ/เนรเทศขณะทำงาน | สถานีไม่ค้าง owner, ledger ไม่ orphan, คนใหม่ใช้สถานีได้ |
| 07 | cancel → cancel ซ้ำ | no double refund/scrap |
| 08 | finish → cancel/kill ซ้ำ | ไม่แจกของซ้ำ ไม่คืนของที่ใช้ไปแล้ว |
| 09 | save/load ขณะ reserved/after canceled | stock/output/receipt เหมือนก่อนเซฟ และโหลดซ้ำไม่เพิ่ม |
| 10 | หัวหน้าฝ่ายเสบียง away, ผู้ช่วยว่าง | delegated สร้างแผนได้รอบ daily แรก ไม่หายไป 1 วัน |
| 11 | หัวหน้า sealed / jailed / dead / exiled | authority handoff, ไม่มีคำสั่งจากคนไม่พร้อม |
| 12 | หัวหน้ากลับก่อนคำสั่งหมดอายุ | role/plan/order เปลี่ยนโดยไม่มี double boss |
| 13 | สร้าง shortage → เติม stock → review ใหม่ | stale order ถูกถอนและ modifiers ไม่ชี้ให้ผลิตเกิน |
| 14 | Shortage A→B ต่าง item ในวันเดียว | target/revision/priority เปลี่ยนทันที ไม่ยึด order ผิดตัว |
| 15 | คุก 3 เซลล์เต็มและมีผู้ต้องโทษเพิ่ม | NPC อยู่ใน state รอที่เหมาะสม ไม่เลือกกิจกรรมอิสระ |
| 16 | คุกว่าง 1 เซลล์ในนาทีถัดไป | sentence เลือกได้โดยไม่มี fallback cooldown |
| 17 | ผู้ต้องโทษหิวหรือป่วยระหว่างคุมขัง | ได้อาหาร/รักษา แต่ไม่ไปฝึกหรือทำธุรกิจ |
| 18 | ผู้ช่วยไม่มี delegated authority ทำเวร 1 ครั้ง | reward/efficiency ตรงกับนโยบายที่มีหลักฐาน |
| 19 | guardRoster 2–100 NPC ใน seed เดียวกัน | determinism เมื่อ state/seed เท่ากันและ comparator contract ถูก |
| 20 | memories 41/100 records equal weight | stable retention, ไม่เกิด non-deterministic eviction |
| 21 | 50 NPC เร่งงานพร้อมกัน 1000 ticks | งานต่อเนื่อง, ไม่มีสถานี owner ซ้ำ, throughput สมเหตุสมผล |
| 22 | 90 วัน 10 seeds ทั้งปกติและขาดอาหาร | ยอด stock ไม่มี NaN/Infinity, คนทำงาน/หิว/ตายสมเหตุสมผล |
| 23 | 360 วัน 20 seeds พร้อม raids & leadership handover | ไม่เกิด ghost order/receipt, ความสัมพันธ์ไม่พัง, ไม่รั่วหน่วยความจำ |
| 24 | speed 1×/4×/16×/32×/48× ใน browser | UI ไม่ค้าง/ผล action invariants ไม่ต่างเพราะสปีด, FPS วัดจริง |
| 25 | import legacy save + mid-action state | migration ระบุ policy ไม่ duplicate/lose silently |
| 26 | seed เดียวกัน save/load หลังการเปลี่ยนหัวหน้า | role/cache/plan/order เหมือน run ไม่ reload |
| 27 | station สูญหาย/อาคารปิดระหว่างเดิน | NPC เคลียร์สถานี/receipt/goal แล้วเลือก fallback อย่างเหมาะสม |
| 28 | AI ไม่มีงานที่ station ใช้ได้ | idle/wait มีเหตุผล, cooldown ไม่ทำให้ NPC ฝืนกฎ |
| 29 | NPC ใหม่เข้ามาในสำนักขาดแคลนเสบียง | priority ปรับตามประชากรจริง, ไม่ loop งานว่าง |
| 30 | หน้าจอรายงานงาน NPC และเจ้าหน้าที่ | UI ระบุแหล่งอำนาจ คำสั่งล่าสุด สาเหตุยกเลิกและต้นทุนงานได้ |

## Release Gate

- **ห้ามปล่อย** ขณะ P0 ยัง reproduce ได้; P1 ต้องได้รับการแก้หรือยอมรับความเสี่ยงพร้อมเหตุผล/หลักฐานจาก QA อย่างเป็นทางการ
- รัน focused tests + stock invariants + save invariants + 90/360 day soak + Browser 1×–48× หลัง patch; งด “ผ่านทั้งหมด” ถ้า `playwright` หรือ runtime dependency ยังขาด
- ตรวจ comparison ของ patch กับ Source baseline; อย่าแก้หัวข้ออุปกรณ์/วิถี/สายย่อยที่ทีมอื่นกำลังตรวจ ยกเว้นจำเป็นเพื่อรักษา interface เดิมแล้วต้องประสาน
- ติดตามจำนวน orphan craft receipts, canceled receipts, materials refunded/scrapped, daily effective office orders, NPC idle/blocked work, mean time from shortage to response, behavior after save/load

## How to use evidence

`EVIDENCE/repro_npc.js` ยืนยัน **ข้อผิดพลาดปัจจุบัน** ดังนั้นเมื่อแก้สำเร็จ สคริปต์เดิมบาง assert ควร fail; ต้องสร้าง `test/npc_prerelease_regression.js` ใหม่ที่ assert พฤติกรรมถูกต้องตาม matrix, ห้ามบิดการแก้เพื่อให้ repro ที่รอพบบัคกลับผ่าน
