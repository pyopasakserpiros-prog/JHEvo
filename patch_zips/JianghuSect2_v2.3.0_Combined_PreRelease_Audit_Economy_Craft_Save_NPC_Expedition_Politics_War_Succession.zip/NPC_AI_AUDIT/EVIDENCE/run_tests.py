import subprocess,concurrent.futures,json,time,pathlib,hashlib
root=pathlib.Path('/mnt/data/econ_audit_work/GAME_SOURCE'); out=pathlib.Path('/mnt/data/npc_ai_audit_work')
suites='npc_cognition npc_command npc_life_authority_overhaul npc_offices npc_social_help npc_sheet_tabs_suite perf runtime_timing save_integrity time_controls tracked_npc_feature_test v233_peaks_elder_rank_social_cognition_suite v310_autonomous_governance_and_peaks_sanctuary_suite v330_living_sect_and_daily_loop_suite welfare_authority beast_ecology ecology_expansion'.split()
cmds=[('test/'+s+'.js',['node',str(root/'test'/(s+'.js'))]) for s in suites]+[('tools/validate_data_schema.js',['node',str(root/'tools/validate_data_schema.js')])]
def run(item):
 name,cmd=item;t=time.time()
 try:
  p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=55)
  return dict(name=name,exit=p.returncode,elapsed=round(time.time()-t,3),stdoutTail=p.stdout.strip()[-1300:],stderrTail=p.stderr.strip()[-900:])
 except subprocess.TimeoutExpired as e:
  return dict(name=name,exit='TIMEOUT',elapsed=round(time.time()-t,3),stdoutTail=str(e.stdout)[-300:],stderrTail=str(e.stderr)[-300:])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(run,cmds))
(out/'test_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
for r in results: print(r['name'],r['exit'],r['elapsed'],r['stdoutTail'][-95:])
print('totals',len(results),sum(r['exit']==0 for r in results),sum(r['exit']!=0 for r in results))
