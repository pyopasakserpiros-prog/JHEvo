# รายงานผลรันจริง, Soak, และข้อจำกัดก่อนปล่อย

## 1. เงื่อนไข
- โค้ดต้นฉบับไม่ถูกปรับแก้: `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip` SHA-256 `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`
- โหลด Node runtime แบบเดียวกับชุดทดสอบโครงการ: `test/load.js`, `SIM.create(seed)`, `SIM.tick(W)`
- Soak ใช้ snapshot ทุก 1 วัน, เก็บค่า alive/deaths/meal/grain/stones/average satiety/count คนที่ satiety < 5/จำนวน open craft รวมถึง 12 ประเภท action ที่ใช้เวลามากสุด
- **การเก็บเพียง snapshot รายวันอาจพลาดช่วงวิกฤตระหว่างวัน**; max_open_craft นับจากการสุ่มเก็บรายชั่วโมง; ไม่มีการสุ่มเหตุการณ์บังคับสุดขั้วเช่นคุกทุกห้องเต็ม/หัวหน้าถูกจับตลอด 90 วัน

## 2. Soak รวม 5 seed

| seed | days | initial_alive | final_alive | max_deaths_recorded | final_meal | final_grain | final_stones | lowest_daily_avg_satiety | max_open_craft | days_with_some_starving | lowest_daily_meal | lowest_daily_stones |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| npc-30-a | 30 | 3 | 37 | 0 | 72 | 131 | 1003 | 37 | 9 | 0 | 23 | 183 |
| npc-30-b | 30 | 3 | 41 | 0 | 86 | 156 | 1146 | 36 | 8 | 0 | 13 | 491 |
| npc-30-c | 30 | 3 | 31 | 0 | 83 | 110 | 643 | 32 | 7 | 0 | 4 | 56 |
| npc-90-a | 90 | 7 | 42 | 0 | 115 | 144 | 3006 | 46 | 13 | 0 | 12 | 989 |
| npc-90-b | 90 | 3 | 46 | 0 | 137.19 | 184 | 3465 | 31 | 10 | 0 | 7 | 440 |

**การตีความที่ถูกต้อง:** แบบจำลอง 30/90 วันใน seed เหล่านี้ไม่มี death count เกิดขึ้นและไม่มีช่วง snapshot ปลายวันที่ NPC มี satiety < 5 แต่ไม่พิสูจน์ว่าระบบอยู่รอดใน seed อื่น สถานีแออัด ภัยรุนแรง ข้อมูลเซฟเก่า หรือผู้เล่นเปลี่ยนนโยบายแล้ว จะต้องทำ stress+fuzz อีกชุด

## 3. การพิสูจน์กรณีเฉพาะ

| ID | ผลลัพธ์ | ข้อสังเกต |
|---|---|---|
| `NPC-01-INTERRUPTION_LEAK` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-02-DEATH_LEAK` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-03-DELEGATE_REVIEW_SKIPPED` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-04-ROLE_CACHE_STALE` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-05-JAILED_WORK_WITHOUT_CELL` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-06-ASSISTANT_REWARDED_WITHOUT_AUTHORITY` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-07-MEMORY_ORDER_COMPARATOR` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-08-STALE_URGENT_ORDER_AFTER_RESOLUTION` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-09_OFFICE_MODIFIER_CACHE_DELAY` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |
| `NPC-10-COOK_INTERRUPTION_LEAK` | REPRODUCED | repro เกิดขึ้นตาม assert; ดู `EVIDENCE/repro_results.json` |

**หมายเหตุ:** ตัวพิสูจน์เป็นการตั้งค่าระบบเพื่อเรียก edge case บางรายการโดยตรง; script ออกแบบมาเพื่อ **แสดงว่าบัคยังมีอยู่ในต้นฉบับ** หลัง patch แล้วควรกลับผล assert เป็นเงื่อนไขที่ถูกต้อง ไม่ใช่พยายามทำให้ `repro_npc.js` ผ่านต่อไป

## 4. ชุดทดสอบที่เกี่ยวข้อง (เดิม)

| รายการ | สถานะ | เวลา |
|---|---|---:|
| `test/npc_cognition.js` | ผ่าน | 1.6s |
| `test/npc_command.js` | ผ่าน | 0.6s |
| `test/npc_life_authority_overhaul.js` | ผ่าน | 1.4s |
| `test/npc_offices.js` | ผ่าน | 1.4s |
| `test/npc_social_help.js` | ผ่าน | 0.8s |
| `test/npc_sheet_tabs_suite.js` | ผ่าน | 1.0s |
| `test/perf.js` | ไม่ได้รันเพราะ dependency | 0.0s |
| `test/runtime_timing.js` | ผ่าน | 0.1s |
| `test/save_integrity.js` | ผ่าน | 1.1s |
| `test/time_controls.js` | ผ่าน | 0.0s |
| `test/tracked_npc_feature_test.js` | ผ่าน | 6.4s |
| `test/v233_peaks_elder_rank_social_cognition_suite.js` | ผ่าน | 0.8s |
| `test/v310_autonomous_governance_and_peaks_sanctuary_suite.js` | ผ่าน | 1.1s |
| `test/v330_living_sect_and_daily_loop_suite.js` | ผ่าน | 1.6s |
| `test/welfare_authority.js` | ผ่าน | 0.8s |
| `test/beast_ecology.js` | ผ่าน | 0.6s |
| `test/ecology_expansion.js` | ผ่าน | 0.9s |
| `tools/validate_data_schema.js` | ผ่าน | 0.6s |

**ทำไม test/perf.js ไม่ผ่าน:** ไม่มี dependency `playwright` ที่เครื่องนี้จึง throw `MODULE_NOT_FOUND` ก่อนเปิดเบราว์เซอร์; **ไม่ใช่ performance test fail** และไม่รับรอง FPS/48×. หลัง patch ควรติดตั้ง dependencies ตามโปรเจ็กต์และรันบน browser ที่รองรับ

## 5. พื้นที่ที่ยังไม่ได้รับรอง

1. ไม่ได้คลิก UI จริงเพื่อพิสูจน์ accessibility ทุกทางเข้าของผู้เล่น (เช่น เปิด/ปิดงานผ่านเมนู, คลิกปฏิทิน/มอบหมาย, กดเปลี่ยนความเร็ว)
2. ไม่ได้ทำ 360 วัน/100 seed + สมดุลเชิงสถิติ (การไม่มี death ใน 5 seed ไม่เท่ากับไม่มี death ในเกมจริง)
3. ไม่ได้ทำ cross-browser deterministic guard roster / deterministic memory retention
4. ไม่ได้ทำ chaos suite การสลับงาน NPC หลายสิบคนพร้อมกัน, บันทึก/โหลดระหว่างทุก phase, โจมตี/เทศกาล/โรคระบาด/ภัยธรรมชาติพร้อมกัน
5. ไม่ได้รับการยืนยันว่า AI อีกแชทปิด P0 จาก economy/crafting/save แล้ว; ต้องใช้เวอร์ชันแก้รวมก่อนประกาศ Go
6. โมดูลวิถี/สายย่อย/อุปกรณ์เป็นงานอีกแชท ไม่สรุปความถูกต้องของเนื้อหานั้นจากการ audit นี้

## 6. หลักฐานดิบที่แนบ

- `EVIDENCE/repro_npc.js`, `EVIDENCE/repro_results.json` — บัคที่ reproduce ได้ 10 กรณี
- `EVIDENCE/soak.js`, `EVIDENCE/soak_30days.jsonl`, `EVIDENCE/soak_90days.jsonl` — 5 trace รวม 270 วันเกม (3×30 + 2×90)
- `EVIDENCE/test_results.json` — รันชุดเดิมครบ 18 รายการพร้อม output ของ test/perf.js ที่ขาด dependency
- `EVIDENCE/run_tests.py` — คำสั่ง/เวลา/ผลลัพธ์ของชุดทดสอบที่รัน

## 7. วิธีรันทดสอบซ้ำ (ไม่ต้องมี network ถ้า dependencies อยู่แล้ว)

```bash
cd /path/to/unpacked/JianghuSect2
GAME_ROOT="$PWD" node /path/to/extracted/NPC_AI_AUDIT/EVIDENCE/repro_npc.js
DAYS=30 GAME_ROOT="$PWD" node /path/to/extracted/NPC_AI_AUDIT/EVIDENCE/soak.js seed-A seed-B seed-C
node test/npc_cognition.js
node test/npc_life_authority_overhaul.js
node test/npc_offices.js
node tools/validate_data_schema.js
```

หมายเหตุ `repro_npc.js` จะยืนยันผลผิดแบบเดิมที่ baseline มีเท่านั้น; หลังแก้ให้อัปเดต assertion เป็นเกณฑ์ข้อแก้ใน `04_RELEASE_FIX_HANDOFF_AND_REGRESSION_TH.md`.
