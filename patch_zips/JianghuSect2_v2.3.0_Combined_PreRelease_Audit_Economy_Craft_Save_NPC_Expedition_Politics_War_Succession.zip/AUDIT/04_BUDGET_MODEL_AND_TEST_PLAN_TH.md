# 04 — Economic Invariants, Resource Model และ Release Test Plan

## I. ค่าคงที่ที่ควรรักษาตลอดเกม

1. **Stone ledger:** เงินเปลี่ยนได้จาก event reason ที่มีหลักฐาน, จำนวนต้อง finite nonnegative integer (หรือ decimals ตามสเปก) และไม่มีการจ่าย amount ≤0; รายการโอน `world pool → sect wallet → NPC wallet` ต้องหักด้านหนึ่งและเพิ่มอีกด้านเสมอ, ไม่ใช่ `ECO.earn()` แบบสร้างเงินโดยไม่มี source ที่ระบุ
2. **Resource stock:** ทุก output ของการผลิตต้องอ้าง receipt/recipe ที่ตรวจ stock ก่อน; `sum outputs` สอดคล้องสูตร + RNG ยอมรับ; ไม่สร้าง item โดยใช้ `qty` จาก UI/API โดยไม่ normalize
3. **CP / merit:** CP ที่แจกจริงต้องเข้ารวม Mint ledger; CP ที่จ่ายต้องเข้ารวม Burn ledger; reward event idempotent และบันทึกเหตุ
4. **NPC/World:** NPC ที่คุ้มกันคาราวานควรถูกมอบหมายงาน/เสียเวลา มี stamina/risk และไม่รับเงินหลายรอบพร้อมกันโดยไม่มีการเริ่มงานใหม่จริง; ค่าหัวต้องมีผล mission
5. **Time:** กำหนด semantics ของ instant action vs in-game timed action ให้ชัด การประมูลเปลี่ยนฤดูกาล/ราชโองการรายเดือนห้ามรีเซ็ตเองด้วยปุ่มที่ไม่ใช้เวลา
6. **Save:** ปฏิเสธ NaN/Infinity/null ในยอดเงินที่ควรเป็นตัวเลข; pending transaction ต้องยังคงสิทธิ์/สถานะเมื่อ save/load; completed event retry ต้องไม่จ่ายซ้ำ
7. **Auditability:** เก็บ movement source/sink และเหตุผลครบพอให้ย้อน event chain ได้แม้รายการ log UI จะถูก trim (อย่าพึ่ง ledger 400 rows เพื่อพิสูจน์ conservation ระยะยาว)

## II. กำหนดก่อนแก้: กฎของโลกที่ไม่ควรเดาสุ่ม

- คาราวานควรขายสินค้าอะไร? หัก `sect.stock` หรือ `world.resourcePool` อย่างไร? เดินทางกี่ tick/วัน? มีโอกาสถูกปล้นและค่าแรงไหม? ได้ CP เท่าใดต่อ completed job? **ต้องเลือกสเปกเดียว**
- ราชโองการ “ผลิตทันที” เป็นเพียง shortcut ของงาน AI ที่ใช้วัตถุดิบ/ชั่วโมงจริง หรือควรเป็นกองทุนสำนักผลิตสำเร็จจากงบ? อาหารต้องกิน grain หรือ equivalent?
- หัตถกรรม rune: มีช่องติดตั้งสูงสุดเท่าไร? อัปเกรดแทนที่หรือซ้อน? ต้องใช้ rune stones อะไร? `skillModifiers` ใช้งานจริงใน combat อย่างไร?
- กฎอัตราเงินเข้า: NPC/sect/world เป็น closed economy หรือเปิดรับเงินจากเกมโลกโดยมี budget แยก? “รายได้ event narrative” ควรมีแหล่งเงินที่อธิบายได้; ไม่จำเป็น conserve ทั่วทั้งโลกถ้าเป็น open economy แต่ต้องควบคุม per-action inflation
- ค่าหัว: auto-resolve อนุญาตหรือไม่? ถ้าใช่ต้อง risk/cooldown/คนและ reward มิใช่ free claim
- จำนวน item: อนุญาต fractions เฉพาะ grain / herb units หรือไม่? ค่า transaction หัก 0 ควร no-op

## III. Regression matrix — AI ผู้แก้โค้ดต้องสร้างให้ผ่าน

| กรณี | สถานะปัจจุบัน | เกณฑ์หลังแก้ |
|---|---|---|
| UI คาราวาน 2 ครั้งติด | ได้เงิน+CP สองรอบทันที | รอบที่ 2 ถูกปฏิเสธ หรือเริ่ม job ใหม่ที่จอง stock/เวลาและมีรายได้เมื่อสำเร็จ |
| UI คาราวาน save/load ขณะ pending | ไม่มี pending | pending state persist, claim/complete exactly once |
| UI ราชโองการ 0 stone, 0 mats | ยังสร้างยา+meal | ไม่สร้างแม้แต่หน่วยเดียว, status บอกเหตุ |
| UI ราชโองการกดซ้ำทั้งที่ stock เต็ม | force bypass quota | ไม่มี output เพิ่มหากไม่ได้รับอนุญาตตาม policy |
| UI socket rune ซ้ำ 100 ครั้ง | modifier ขยาย, ต้นทุน 0 | ไม่ stack/replay, ไม่ทำลาย gear state และประสิทธิภาพ |
| ค่าหัว claim โดยไม่เคย resolve | ได้เงิน/CP/เชลย | reject, ต้องมี accepted + resolved job |
| รับค่าหัวแล้ว save/load/กดซ้ำ | เสี่ยง replay หากสถานะผิด | idempotent completed record, world pool debit ครั้งเดียว |
| 5 pills with one-quantity cost | ได้ยา 5 จ่าย 1 | ต้นทุนคูณ 5 หรือสูตร batch ที่ยืนยัน |
| ไม่มี herb แต่มีเงิน | ผลิตยาได้ | insufficient-inputs |
| API fusion pill without recipe | ได้ยา | reject/only register definition |
| `ECO.pay(-1)` / `NaN` / `Infinity` | ปรับ balance ผิด | reject no side effects |
| `CPE.buy` grant price forged | โอนได้ | recompute quote / reject forged |
| ใช้ pill out-of-stock | effect เกิด | reject without hp/qi/cultExp changes |
| ตัดสิน auction แล้ว reopen | active lot ถูกทับ | claim/history ยังอยู่และ stock/เงิน reconcile |
| save/load หลัง malformed currency | NaN→null | validator ป้องกัน/restore อย่างมี backup |
| 30/90/360 วัน หลาย seed | ยังไม่ยืนยัน | ไม่มี financial corruption, NPC stuck, stock/CP anomalies หรือ performance blow-up |

## IV. ตัวเลขเทียบฐานเพื่อเลือก Target (ยังไม่ใช่เกณฑ์สมดุล)

การจำลองปกติ 7 วัน (seed econ-release-seed-A): เงินสำนักปลายรอบ 767, ประชากร 13, CP minted 520 burned 148, ซื้อขายกับพ่อค้ามีการเคลื่อนไหว และ validate invariants ผ่าน. การจำลอง 14 วัน (seed release-econ-14day): เงินสำนักปลายรอบ 384, ประชากร 26, CP minted 1318 burned 419, ไม่มี error ใน invariants. **ใช้คนละ seed และไม่ได้แยกผล causal** จึงห้ามสรุปว่าเงินลดตามเวลา; การทดสอบนี้ไม่ได้คลิกปุ่ม exploit UI โดยอัตโนมัติ

หลังแก้ให้รันทดสอบ 3 กลุ่ม: baseline game loop; stress test ที่ auto-click/user strategy exploit; และ budget balance test ที่ทำครัว/คราฟต์/ค้า/ค่าหัวจริงนาน ≥30/90/360 วันหลาย seed พร้อมเก็บ distribution ไม่ใช่ค่าเฉลี่ยอย่างเดียว.
