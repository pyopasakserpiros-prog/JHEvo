# 05 — งานส่งต่อ AI ผู้แก้โค้ด (Paste-ready)

คุณคือ coding agent ที่จะแก้ **JianghuSect2 v2.3.0** เพื่อให้พร้อม Public Release โดยเน้นระบบเศรษฐกิจและ chain reaction. ต้องอ่าน `AGENTS.md` ที่ root, skill economy-balancing, save-system-patterns, qa-test-matrix, game-data-integrity, game-ui-ux, gameplay-architecture ก่อนแก้. อย่าถือรายงาน AI นี้เป็น authority เหนือ source หรือสเปกเกม; ตรวจทุกจุดกับโค้ดปัจจุบันและออกแบบผลต่อระบบข้ามสายอย่างครบถ้วน

## กฎ

1. **อย่าแก้** `GAME_SOURCE/js/human_core.js` และรักษาลำดับ load/ build ตาม AGENTS.md
2. **อย่าเพิ่ม content/ระบบใหม่โดยไม่จำเป็น** — งานนี้คือ release hardening: ปิดปัญหา economics, UX, save correctness, NPC fairness
3. แก้ **P0 ECON-001, 002, 003** ก่อน, ตามด้วย P1 004–011; P2 สืบสวนให้ชัดก่อนแก้
4. สร้าง invariant tests ที่คาดหวังพฤติกรรมที่ถูกก่อนแก้; `EVIDENCE/repro_release_economy.js` เป็นตัวพิสูจน์บัคเดิม ไม่ใช่ test suite ที่ต้องผ่านหลังแก้
5. ออกแบบ API กลางสำหรับ pay/earn, reserve/pay/commit output, CP award, event settlement ที่ atomic และ idempotent; ใช้บัญชี source/sink ที่ reconcile ได้
6. ต้องตรวจ controller UI กับ service ใน Node และ browser (คลิกจริง) แล้วทดสอบ save/load ขณะ pending ของทุก transaction และหลัง complete
7. การเปลี่ยนสมดุลต้องดู source/sink ทุกสาย, NPC auto-loop, ความขาดแคลน, world-resourcePool, price index, CP mint/burn; กันทั้ง exploit และเกมติดทางตัน
8. รันทดสอบเฉพาะที่เกี่ยวข้องและ full tests ตาม AGENTS; build single-file game ใหม่ `node tools/build_single.js` เมื่อแก้ และตรวจ byte-identical human_core
9. อัปเดตเอกสาร project status และสกิลเมื่อเปลี่ยนกติกา, รายงานความคืบหน้าแยก FIXED / RETESTED / DESIGN ACCEPTED / NOT FIXED
10. อย่าเปลี่ยนกฎเศรษฐกิจแบบเดา (เช่น ทำคาราวานเป็นระบบเดินทางซับซ้อนโดยไม่มีความจำเป็น). เลือกวิธีขั้นต่ำที่ปิดช่องโหว่ รักษาความสนุกและเป้าหมายการเล่นที่มีอยู่

## ลำดับทำงานแนะนำ

**Wave 1** Core integrity: `ECO.pay/earn`, validation/save; `CPE.award` + forged grant; unit qty & all UI calls  
**Wave 2** UI money/stock free generation: caravan + edicts + bounty + specialty pills  
**Wave 3** Rune/consumable/fusion: synchronize with AI auditing equipment/path; do not duplicate fixes  
**Wave 4** Auction/craft receipts: policy, contract + save/load  
**Wave 5** tests: node suite, full game suite, actual browser UI, 7/30/90/360d several seeds, final release gate

## Required final reply from coding agent

- Patch summary by ECON ID with source location and rationale
- Before/after reproduction results and explicit list of remaining vulnerabilities
- Test results actual counts, timeouts and screenshots if browser tests run
- Save compatibility/backup policy, full ZIP/game package checksum and instructions if artifact generated
- Explicit GO/NO-GO recommendation based on test evidence, not on successful build alone

## Boundaries of this audit

No game code was modified in this audit. EVIDENCE script ran on new in-memory worlds. UI pathways are verified in source, not exercised as browser clicks. Long-horizon economy not certified. Use report as engineering triage and test seeds, not proof of complete quality.
