# 02 — รายละเอียดข้อค้นพบ พร้อมจุดอ้างอิงและการทดสอบ

ความหมาย: **UI_TO_SERVICE** = พบ action UI และทดสอบ API ที่ UI เรียก (ยังไม่ใช่ browser click test); **API_ONLY** = เรียก function ตรงผ่าน Node; **SAVE_CROSS_SYSTEM** = พิสูจน์ผล serialize/load; **DESIGN_REVIEW** = ต้องยืนยันสเปกก่อนชี้ว่าผิดแน่. P0 = release blocker ตามผลกระทบ. จำนวนที่พบไม่ใช่จำนวน bug exploit ผ่าน UI ทั้งหมด.

## ECON-001 · P0 / RELEASE BLOCKER — คาราวานผลิตศิลาวิญญาณและรางวัลคนคุ้มกันโดยไม่ใช้สินค้า/เวลา

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `UI_TO_SERVICE`
- **จุดโค้ด:** `js/ui.js:1387-1395; js/sect.js:8965-9055`
- **ชื่อเคสทดสอบ:** `UI_CARAVAN_REPEAT_MONEY; CARAVAN_SAVE_PERSISTENCE`

**หลักฐานและสาเหตุ:** UI เรียก dispatchTradeCaravan(...,{force:true}) โดยตรง; ฟังก์ชันจ่ายรายรับทันทีและบันทึก COMPLETED, ขณะไม่มี debit สินค้า, ไม่มีต้นทุนคาราวาน, cooldown, การเดินทางหรือเหตุการณ์สำเร็จปลายทางในเส้นทางนี้; จัดปาร์ตี้เพิ่ม merit/CP/ตบะทุกครั้ง. สคริปต์แสดงรายได้จากการเรียกสองครั้งในวันเดียวโดยไม่เปลี่ยนจำนวนชนิด stock; ตัวเลขขึ้นกับ seed (รอบก่อนพบ +434 สองครั้ง; สคริปต์ล่าสุด +440 สองครั้ง)

**ผลต่อระบบอื่นแบบลูกโซ่:** กดคาราวานซ้ำ → ศิลาสำนักเพิ่มจากศูนย์ → จ่ายซื้อสินค้า/จ้าง/คราฟต์ได้ไม่จำกัดตามการกด → ความขาดแคลนและราคาสูญความหมาย → CP+merit+cultExp จากการคุ้มกันเพิ่มตาม → ข้ามข้อจำกัดการเติบโต/ความสัมพันธ์สำนักคู่ค้า → เงินผิดปกติคงอยู่หลังเซฟ

**แนวทางแก้ที่เสนอ:** สร้าง order lifecycle: เลือกสินค้าและจำนวนพร้อมตรวจคลัง/จองสินค้าจริง, ล็อก NPC เดินทาง, หน่วงเวลาและประเมินความเสี่ยงระหว่างทาง, จ่ายเงิน+CP/merit ณ COMPLETE เพียงครั้งเดียว, ตรวจ idempotency; ถ้าต้องการนามธรรมแบบ instant ให้มีต้นทุนทรัพยากรและ quota/cooldown ที่มีนัย

**เกณฑ์ตรวจรับหลังแก้:** กด UI 2 ครั้งติดกันต้องไม่รับเงิน/CP ซ้ำโดยไม่มี order ใหม่ที่ใช้ทรัพยากรและผ่านกติกา; stock/ledger/audit trail ตรง; save/load ก่อน–หลัง COMPLETE ไม่รับซ้ำ

---

## ECON-002 · P0 / RELEASE BLOCKER — ราชโองการสร้างยาและอาหารแม้เงิน 0 และกดซ้ำได้

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `UI_TO_SERVICE`
- **จุดโค้ด:** `js/ui.js:1418-1425; js/sect.js:9541-9618`
- **ชื่อเคสทดสอบ:** `UI_EDICT_FREE_STOCK`

**หลักฐานและสาเหตุ:** หากเงินไม่พอหรือเกิน budget cap, เงื่อนไขหักเงินจะถูกข้าม แต่ ECO.add อยู่หลัง if และทำงานต่อ; batch heal/qi ไม่หักสมุนไพร และ meal ไม่หัก grain; UI ส่ง force:true ทำให้ไม่ยึด quota ของคงคลัง. ทดสอบที่เงิน 0 สามครั้ง: +12 โอสถรักษา, +12 โอสถปราณ, +36 อาหาร

**ผลต่อระบบอื่นแบบลูกโซ่:** ฟรียา/อาหาร → ค่าบาดเจ็บและการขาดแคลนอาหารถูกลบล้าง → NPC ดำรงชีวิตและฝึกต่อได้โดยไม่ต้องเก็บเกี่ยว → ราคาตลาดและความเสี่ยง expedition ต่ำลง → แรงงานและพัฒนาสำนักเร่งขึ้น → ระบบเงินและวัตถุดิบไม่มีข้อจำกัด

**แนวทางแก้ที่เสนอ:** ใช้ transactional `reserveInputs + spend + commitOutputs`, ตรวจ budget ก่อนเพิ่มสินค้า, ต้นทุนสมุนไพร/ข้าว/แรงงาน/เวลา, จำกัดจังหวะประมวลผลตาม tick/รอบนโยบาย; UI force หมายถึงตรวจโควตาใหม่ได้ ไม่ใช่บังคับผลิตฟรี

**เกณฑ์ตรวจรับหลังแก้:** เงิน 0 + สต็อกวัตถุดิบ 0 ต้องผลิต 0; กดซ้ำต้องได้ผลตาม quota และช่วงเวลา; กรณี budget ไม่พอห้ามเพิ่มสินค้า; ประวัติ spentStones ตรงเงินหักจริง

---

## ECON-003 · P0 / RELEASE BLOCKER — ฝังรูนซ้ำโดยไม่มีต้นทุน/จำนวนครั้งจำกัด เพิ่ม modifier ต่อเนื่อง

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `UI_TO_SERVICE`
- **จุดโค้ด:** `js/ui.js:1739-1763; js/economy.js:2494-2528`
- **ชื่อเคสทดสอบ:** `UI_RUNE_REPEAT_NO_COST`

**หลักฐานและสาเหตุ:** UI มีคำสั่ง socket-elemental-runes เรียก ECO.socketElementalRunes, สร้าง skillModifiers ใหม่ทุกครั้ง ไม่มีการหักวัสดุหรือเงิน และไม่มีเงื่อนไขปฏิเสธรูนซ้ำ; ผลรัน modifier เพิ่ม 0→2 ทั้งที่ stockTotal และ stones เท่าเดิม. ยังไม่ได้พิสูจน์ตัวคำนวณดาเมจว่า stack ทุก modifier หรือไม่

**ผลต่อระบบอื่นแบบลูกโซ่:** ทำรูนไร้ต้นทุนซ้ำ → modifier สะสมในอุปกรณ์ → *อาจ* เพิ่มพลังต่อสู้หากระบบต่อสู้รวม modifier → บาดเจ็บน้อย/ล่าเร็ว/ของดรอปมาก → เศรษฐกิจเสียสมดุล; แม้ combat dedupe ก็ยังเสี่ยง save บวมและ UX แสดงไม่ตรง

**แนวทางแก้ที่เสนอ:** กำหนด recipe/rune item ที่ถูกใช้จริง, จำนวนช่องและ overwrite/upgrade policy; dedupe ตาม reaction id, ตรวจขีดจำกัด, ตัดสินผลครั้งเดียว; ให้ AI ทีมอุปกรณ์ตรวจ downstream damage stacking

**เกณฑ์ตรวจรับหลังแก้:** เรียกฝังรูนเดิมซ้ำต้องไม่เพิ่ม modifier และไม่ใช้เงินซ้ำเมื่อปฏิเสธ; ฝังรูนใหม่ต้องหักต้นทุน, ผ่าน cap และ save/load modifiers คงที่

---

## ECON-004 · P1 — กระดานค่าหัวรับรางวัลทันทีโดยไม่ต้องล่า/ต่อสู้

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `UI_TO_SERVICE`
- **จุดโค้ด:** `js/ui.js:1920-1923; js/sect.js:14259-14316`
- **ชื่อเคสทดสอบ:** `UI_BOUNTY_INSTANT_PAYOUT`

**หลักฐานและสาเหตุ:** คำสั่ง UI claim-bounty-hunt เรียก claimBountyHunt, ในฟังก์ชันไม่มีด่านออกภารกิจ ระยะเวลา Combat สำเร็จหรือความสามารถผู้ล่า; จ่ายเงินจาก world.resourcePool จริงและเพิ่ม CP/merit/ตบะทันที พร้อมสร้างนักโทษ. ทดสอบกดรับสองค่าหัวในวันเดียวได้ 380+480 ศิลา, CP ผู้ล่า +60; ไม่ใช่สินทรัพย์ไม่มีเพดานเพราะรายการค่าหัวมีจำนวนจำกัด

**ผลต่อระบบอื่นแบบลูกโซ่:** กดค่าหัว → รายได้และ CP โดยไม่มีความเสี่ยง → การทะลวง/ปลดล็อกเร็วขึ้น → ได้เชลยโดยข้ามฉากต่อสู้ → วงจรงานผู้คุม/จัดการเชลยและชื่อเสียงถูกเร่ง; world.resourcePool ถูกตัดจริงดังนั้นอาจทำให้เศรษฐกิจ NPC โลกขาดเงินเร็วกว่าตั้งใจ

**แนวทางแก้ที่เสนอ:** แยก ACCEPT → ASSIGN HUNTER → DEPART → RESOLVE COMBAT/CHASE → CLAIM, ตรวจผลล่าจริงและความเสี่ยง, กัน claim ซ้ำ; ถ้าเป็น narrative auto-resolve ต้องมีเวลาต้นทุน/ความเสี่ยงและเกณฑ์ power

**เกณฑ์ตรวจรับหลังแก้:** คลิก Claim โดยไม่มีหลักฐาน RESOLVED ห้ามเพิ่มเงิน CP เชลย; ดำเนินภารกิจเสร็จแล้วรับได้เพียงครั้ง; ตรวจ worldPool debit และ save/load

---

## ECON-005 · P1 — หลอมโอสถสองระยะได้โดยไม่มีสมุนไพรจริง

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `UI_TO_SERVICE`
- **จุดโค้ด:** `js/ui.js:1930-1933; js/economy.js:2437-2479`
- **ชื่อเคสทดสอบ:** `SPECIALTY_PILL_UNDERPAY_AND_MISSING_HERB`

**หลักฐานและสาเหตุ:** ค่าเริ่มต้น herbCost=2 แต่เงื่อนไขหักสมุนไพร `if herbCost>0 && count(W,"herb")>=herbCost` ทำให้ไม่มี herb ก็ข้ามการหักแล้ว ECO.add ยาได้; คลังหลักใช้รหัสสมุนไพรหลายชนิด, ไม่จำเป็นมี item generic herb. ทาง UI เรียกด้วย opts default จึงได้รับผลด้วยหากมีศิลาพอ; สคริปต์พิสูจน์กรณี herbCost=100 และคงคลัง herb=0

**ผลต่อระบบอื่นแบบลูกโซ่:** ยาจากศิลาโดยไม่มีวัตถุดิบ → demand สมุนไพรจริงไม่เกิด → เก็บเกี่ยว/ขายสมุนไพรไร้ค่า → potion supply เพิ่ม → ลด mortality/เพิ่ม CULT gain → ราคาและเป้าหมาย NPC แปรปรวน

**แนวทางแก้ที่เสนอ:** ให้สูตรระบุ material IDs ที่มีจริง, ตรวจและหักวัตถุดิบแบบ atomic ร่วมกับ stoneCost; หากไม่มีวัตถุดิบต้อง fail ก่อนหักเงิน, ไม่ใช้ generic herb ที่ไม่มีแหล่ง

**เกณฑ์ตรวจรับหลังแก้:** ในโลกที่มีเงินพอแต่ไม่มีวัตถุดิบต้อง return insufficient-inputs และยาไม่เพิ่ม; มีวัตถุดิบครบต้องหักตรงตาม recipe ทั้งเงินและวัสดุ

---

## ECON-006 · P1 — หลอมโอสถหลายเม็ดด้วยค่าครั้งเดียวและรับราคาที่ caller ส่งเอง

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/economy.js:2451-2479`
- **ชื่อเคสทดสอบ:** `SPECIALTY_PILL_UNDERPAY_AND_MISSING_HERB`

**หลักฐานและสาเหตุ:** `opts.qty` ใช้เพิ่ม ECO.add แต่ `stoneCost/herbCost` ใช้ต้นทุนต่อการเรียก ไม่คูณ qty และเป็นราคาที่ caller กำหนด. ทดสอบ `{qty:5,stoneCost:1,herbCost:100}` ได้ยา 5 เสียเงิน 1 และไม่หักสมุนไพร; **UI ปกติส่งแค่ pillId และไม่ได้แสดงปุ่มปรับ qty/cost** จึงเป็นช่องโหว่ service API หรือ extension มากกว่าสาธิตได้ทาง UI

**ผลต่อระบบอื่นแบบลูกโซ่:** caller อื่นหรือ future feature กำหนด qty สูง → สร้างยาปริมาณมากในราคาเดิม → stock เกินอุปสงค์ → ต้นทุนการฝึกและบาดเจ็บลด → ระบบ trade/crafting บิดเบือน

**แนวทางแก้ที่เสนอ:** ห้าม trust ราคาจาก caller; คำนวณ server/game-domain quote จากสูตรและจำนวนที่ตรวจเป็น safe int 1..limit, ตรวจวัตถุดิบรวม, charge total before mint, transaction receipt once

**เกณฑ์ตรวจรับหลังแก้:** การผลิต 5 ต้องหัก 5 เท่าหรือสูตร batch ที่กำหนดชัด; qty 0/-1/NaN/Infinity ต้อง fail; callback retry ห้ามผลิตซ้ำ

---

## ECON-007 · P1 — คลังศิลาจ่ายค่าติดลบ/NaN ได้จนยอดเงินผิด

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/economy.js:126-128`
- **ชื่อเคสทดสอบ:** `TREASURY_NEGATIVE_AND_NONFINITE`

**หลักฐานและสาเหตุ:** `ECO.pay` ตรวจเพียง `W.sect.stones < amt` และลบ amt ตรง ๆ: pay(-50) เพิ่มเงิน +50; pay(NaN) ผ่าน check แล้วทำให้ยอดเป็น NaN; ECO.earn ก็ไม่ตรวจ finite/negative. ต้องหา caller รับ input จากผู้เล่นอีกครั้ง จึงจัด API-only

**ผลต่อระบบอื่นแบบลูกโซ่:** caller ใดก็ตามส่ง amt ผิด → ศิลาสำนักเพิ่มฟรีหรือ NaN → งบทั้งหมดใช้ไม่ได้หรือการตรวจความพอเงินถูก bypass → UI/AI ตัดสินใจผิด → เซฟเสีย

**แนวทางแก้ที่เสนอ:** รวม function `validateCurrencyAmount` Number.isSafeInteger/finite >0, จำกัดการโอนและตรวจยอดก่อน–หลัง; return false ไม่มี side effect หากผิด; ป้องกันใน `ECO.earn` และทุก sink/source; มี ledger ID ซ้ำและ reconciliation

**เกณฑ์ตรวจรับหลังแก้:** pay(-50/NaN/Infinity/0) ต้อง false โดยไม่แก้ ledger, earn ค่าผิดต้อง false, balance คง finite nonnegative; ใช้ property-based test รอบ boundary

---

## ECON-008 · P1 — ยอดศิลา NaN ถูก JSON serialize เป็น null และกู้เซฟแล้วการจ่ายเงินผิด

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `SAVE_CROSS_SYSTEM`
- **จุดโค้ด:** `js/economy.js:126-128; js/sim.js (serialize/deserialize)`
- **ชื่อเคสทดสอบ:** `TREASURY_SAVE_AFTER_NAN`

**หลักฐานและสาเหตุ:** รันจ่าย NaN แล้ว SIM.serialize ทำให้ `sect.stones` ใน JSON กลายเป็น null; SIM.deserialize กลับเป็น null และ `ECO.pay(10)` return false. เป็นการทดสอบผลข้ามระบบของ ECON-007 จัดรายการแยกเพราะเกี่ยวกับข้อมูลผู้เล่นระยะยาว

**ผลต่อระบบอื่นแบบลูกโซ่:** ผิดพลาดชั่วคราวในยอดเงิน → เซฟคงค่า null → โหลดกลับไม่สามารถซื้อหรือคราฟต์ → ผู้เล่นติดทางตัน → ข้อมูล ledger และการเงินย้อนหลังอธิบายไม่ได้

**แนวทางแก้ที่เสนอ:** แก้ต้นตอ ECON-007 และเพิ่ม save-validation ก่อน serialize / load migration validation: ตรวจ finite nonnegative, เขียนนโยบายซ่อมค่าผิดอย่างระมัดระวัง (backup แจ้งผู้เล่น/หลักฐาน) ห้ามแก้ยอดเป็น 0 เงียบ ๆ

**เกณฑ์ตรวจรับหลังแก้:** เซฟหลังทุกธุรกรรมต้อง stones เป็น number finite; ปฏิเสธเซฟ/เตือนเมื่อ invariant แตก; regression save/load ทั้งก่อนและหลังจ่ายเงินที่ถูกต้อง

---

## ECON-009 · P1 — การแลก CP เป็นศิลาส่วนตัวเชื่อราคาและจำนวนศิลาที่ caller ระบุ

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/cpeco.js:407-426`
- **ชื่อเคสทดสอบ:** `CP_STONE_GRANT_FORGED_QUOTE_API`

**หลักฐานและสาเหตุ:** `CPE.buy` สำหรับ `stone_grant` รับ p.stones/p.price ตรง ๆ ต่างจาก pill/gear ซึ่งคำนวณ quote ในฟังก์ชัน; ทดสอบให้ 1000 ศิลาในราคา 1 CP โดยสำนักถูกหัก 1000. `pickPurchase` ปกติให้ราคา/เพดานถูกต้อง จึงยังไม่พบ UI กำหนด quote เอง

**ผลต่อระบบอื่นแบบลูกโซ่:** หาก caller ภายใน/ม็อดส่งค่า forged → CP ต้นทุนต่ำแต่ย้ายทรัพย์สินออกจากสำนักมาก → ความมั่งคั่งตัวบุคคลเพิ่มสวนกับคลัง → เกิดอุปสรรคทางการเงินกับงานสำนักและ NPC อื่น

**แนวทางแก้ที่เสนอ:** คำนวณ grantAmount และ price ใน CPE.buy เองจาก source-of-truth/เงื่อนไข track พร้อม bounded caps, cross-check quote; ใช้ atomic transfer stones และ CP, audit both parties

**เกณฑ์ตรวจรับหลังแก้:** p.price=1 p.stones=1000 ต้องถูก reject หรือบังคับ quote ใหม่; ปกติ pickPurchase ยังทำงานและ balances/CP ledger ตรงกัน

---

## ECON-010 · P1 — API หลอมโอสถผสานธาตุสร้างไอเทมจริงโดยไม่หักทรัพยากร

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/economy.js:2389-2427; js/economy.js:2437-2448`
- **ชื่อเคสทดสอบ:** `FUSION_PILL_ZERO_COST_API`

**หลักฐานและสาเหตุ:** ECO.brewMultiphaseElementalPill เพิ่ม definition และ ECO.add(W,pill.id,1) โดยไม่มี ECO.pay/take; brewMultiPhaseSpecialtyPill array หรือ fallback เรียกผ่านได้. มีฤทธิ์ heal/qi/cultExp/buff, จึงเป็น item economic impact ไม่ใช่แค่ catalog; ยังไม่พบ UI ปกติเรียก array-form

**ผลต่อระบบอื่นแบบลูกโซ่:** อนาคต/AI ที่เรียก API → รับโอสถบัฟ+ตบะฟรี → ระบบคืน HP/พัฒนาฝึกเร็ว → ตลาดโอสถและวัสดุถูกแทน → อาจกระทบการต่อสู้และ progression

**แนวทางแก้ที่เสนอ:** แยก `registerPillDefinition` ที่ไม่เกิด stock จาก `craftFusionPill` ที่ตรวจสูตร+วัตถุดิบ+ฝีมือ+ขั้นตอน และการจ่าย output เพียงครั้งเดียว; ป้องกัน free flag เฉพาะ debug

**เกณฑ์ตรวจรับหลังแก้:** เรียก API ไม่มีสูตร/ต้นทุนต้องไม่เพิ่มยา; craft ด้วย recipe จริงหักวัตถุดิบตรง; catalog registration ไม่เปลี่ยนคลัง

---

## ECON-011 · P1 — รางวัล CP จากคาราวานและค่าหัวเพิ่มให้ NPC โดยไม่บันทึก minted accounting

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `CROSS_SYSTEM_ACCOUNTING`
- **จุดโค้ด:** `js/sect.js:9007-9012; js/sect.js:14288-14295; js/cpeco.js (state minted)`
- **ชื่อเคสทดสอบ:** `UI_CARAVAN_REPEAT_MONEY; UI_BOUNTY_INSTANT_PAYOUT`

**หลักฐานและสาเหตุ:** ระบบคาราวาน/ค่าหัวเพิ่ม `npc.cp += 18/30` โดยตรง แต่ตัวนับ CPE.S(W).minted ไม่เพิ่มตาม (พิสูจน์จากสคริปต์). จำนวน CP ในกระเป๋าและ CP minted รวมจึงไม่ถูก trace เป็น ledger เดียวกันแม้ยอด CP ผู้เล่นเปลี่ยนจริง. อาจเป็นข้อยกเว้น design แต่ต้องระบุอย่างชัดเจน

**ผลต่อระบบอื่นแบบลูกโซ่:** CP สร้างโดยเส้นทางข้างเคียง → ไดนามิก scarcity/price ของ CP ไม่สะท้อนรายได้จริง → NPC จ่ายเรียน/อบรม/ซื้อสินค้าเร็วกว่าแบบจำลอง → เงิน/ของไหลข้ามสำนักต่างจาก economic model → วัด balance ผิด

**แนวทางแก้ที่เสนอ:** กำหนด CPE.awardCp(W,n,amt,cause) จุดเดียวสำหรับทุกการ mint, reason typed + idempotency key, นำ reward ทั้งหมดเข้าระบบ accounting; หาก minted counter ตั้งใจนับเฉพาะรางวัล AI ให้ rename และแยก totalMinted กับ categoryMinted

**เกณฑ์ตรวจรับหลังแก้:** รางวัล CP ทุกช่องทางเพิ่มยอดรวม minted เท่ากับ CP ที่แจก; simulate CP wallet conservation minus burns/legacy adjustments; save/load retains audit

---

## ECON-012 · P2 — ใช้โอสถในคลังเป็นศูนย์แล้วยังได้ผลฟื้นฟู/ตบะ

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/economy.js:2530-2585`
- **ชื่อเคสทดสอบ:** `CONSUMABLE_OUT_OF_STOCK_API`

**หลักฐานและสาเหตุ:** กรณีไอเทมปกติ หาก count==0 จะไม่เรียก ECO.take แต่ทำ effect ต่อ และ return ok. ทดสอบ ITEM_V234_PILL_001 ไม่มี stock ทำ NPC.hp จาก 1 เพิ่มขึ้นอย่างมีนัย. ยังไม่ยืนยันว่า UI เส้นทางหลัก/AI NPC ส่ง itemId โดยไม่ตรวจ stock เองหรือไม่

**ผลต่อระบบอื่นแบบลูกโซ่:** หาก caller ลืม precheck → NPC ใช้ยาไม่มีของ → HP/qi/ตบะฟรี → ดุลการตาย/บาดเจ็บ/กิจกรรม NPC ผิด; นโยบาย gear vs potion ใกล้กันแต่ความเสี่ยงข้ามระบบสูง

**แนวทางแก้ที่เสนอ:** ตรวจ ECO.count และ ECO.take===true ก่อน effect ทุกประเภท (รวม talisman multi-charge/owner inventory), เว้น free ผ่าน internal authorization สำหรับ event-specific; verify precheck caller ไม่พอ

**เกณฑ์ตรวจรับหลังแก้:** ไม่มี stock และไม่มี authorized free ต้อง return out-of-stock ไม่มี effect, no cultivation/buff, no oath change; consume 1 ก่อน apply; charged talisman ถูกต้อง

---

## ECON-013 · P2 — เปิดฤดูกาลประมูลซ้ำทับ activeLots แม้อยู่ฤดูกาลเดิม

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED_DESIGN_REVIEW`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/sect.js:9058-9120; js/sect.js:14321-14332`
- **ชื่อเคสทดสอบ:** `AUCTION_REOPEN_RESET_API`

**หลักฐานและสาเหตุ:** openSeasonalAuction เพิ่ม seq และตั้ง activeLots ใหม่ทุกครั้ง; ในการทดลอง lot ที่ WON_BY_PLAYER หายจาก activeLots เมื่อเปิดซ้ำในฤดูกาลเดียว. หากรายการชัยชนะและสินค้าส่งมอบถูกเก็บที่อื่นอาจเป็นพฤติกรรมตั้งใจ; ต้อง trace settlement/collection และ black-market UI ก่อนฟันธงข้อมูลหาย

**ผลต่อระบบอื่นแบบลูกโซ่:** reopen ก่อนรับรางวัล/ของค้าง → UI อาจหา lot ไม่พบ → ผู้เล่นเสียเงินแต่ไม่ได้ของหรือประวัติที่อธิบายได้; การเปิดตลาดมืดเรียก openSeasonalAuction อาจเร่งผลหากไม่ guard

**แนวทางแก้ที่เสนอ:** เก็บ settled + claimable lots แยกจาก activeLots, unique auction event id และ season gate; ป้องกัน reopen same season ที่ไม่ใช่ admin reset; สร้าง test ของ item delivery และ retry

**เกณฑ์ตรวจรับหลังแก้:** เปิดซ้ำในฤดูกาลเดิมต้องไม่ลบ lot ที่ยังมีเงิน/สิทธิ์รับ; สินค้า+เงินตาม bid ledger reconcile 100%; save/load auction in-progress

---

## ECON-014 · P2 — สัญญาปริมาณ stock ไม่ชัดเจน: ค่าทศนิยมและ take(0) ทำให้ sequence เปลี่ยน

- **สถานะหลักฐาน:** `RUNTIME_CONFIRMED_DESIGN_REVIEW`
- **ทางเข้าถึง:** `API_ONLY`
- **จุดโค้ด:** `js/economy.js:107-124`
- **ชื่อเคสทดสอบ:** `STOCK_QUANTITY_CONTRACT_API`

**หลักฐานและสาเหตุ:** ECO.add(W,"grain",1.5) สำเร็จ และ ECO.take(W,"grain",0) สำเร็จพร้อมเพิ่ม _stockSeq แม้ไม่มีการลดจริง. สินค้าบางชนิดอาจตั้งใจนับหน่วยเศษส่วนได้ ดังนั้นไม่สรุปว่า 1.5 เป็นบัคทุกสินค้า; แต่ zero-spend ส่งผลต่อ cache invalidation/การตัดสินใจ AI ที่อิง stockSeq

**ผลต่อระบบอื่นแบบลูกโซ่:** input จากสูตร/การค้าขัด schema → stock ทศนิยมของของนับเป็นชิ้น → serialize/render ผิด → cache stockSeq เปลี่ยนโดยไร้เหตุ → performance/AI re-plan บ่อย

**แนวทางแก้ที่เสนอ:** กำหนด unit policy ต่อ material, จำนวนเต็มสำหรับยาหรือไอเทมที่นับชิ้น, return false for take(0) หรือ no-op without seq increment, schema validation ทั้ง trade/craft

**เกณฑ์ตรวจรับหลังแก้:** take(0) ต้องไม่แก้ stock/seq; สำหรับ integer-only item ปฏิเสธเศษส่วน; commodity fractional เฉพาะชนิดที่ออกแบบให้รองรับ

---

## ECON-015 · P2 — แทนที่งานคราฟต์ของ NPC ลบใบจองเดิมพร้อมวัตถุดิบโดยไม่มีคืน

- **สถานะหลักฐาน:** `STATIC_REVIEW_ONLY`
- **ทางเข้าถึง:** `DESIGN_REVIEW`
- **จุดโค้ด:** `js/economy.js:287-309; test/craft_transactions.js`
- **ชื่อเคสทดสอบ:** `ไม่มี repro ใหม่; test/craft_transactions.js ยืนยัน behavior intentionally no refunds`

**หลักฐานและสาเหตุ:** registerCraft ลบ ledger.open ของงานเดิมเมื่อ NPC เริ่มงานใหม่และไม่คืนวัตถุดิบ; ชุดทดสอบเดิมระบุว่าตั้งใจให้เสียเป็นค่า interrupted receipt แต่สำหรับผู้เล่นที่สั่งงานผิด/AI เปลี่ยนงานเองอาจถูกมองว่าไอเทมหาย ไม่มี log/UX แสดงต้นทุนสูญเสียชัดเจน. ไม่ใช่บัคยืนยันตามสเปกปัจจุบัน

**ผลต่อระบบอื่นแบบลูกโซ่:** เปลี่ยนคำสั่งผลิตเพราะ NPC เลือกงานใหม่ → วัตถุดิบหาย → อุปกรณ์/โอสถไม่เสร็จ → ขาดวัตถุดิบคราฟต์ซ้ำ/เงินหมด → ผู้เล่นเข้าใจว่าเซฟหรือคลังผิด

**แนวทางแก้ที่เสนอ:** ให้เจ้าของเกมเลือกว่า loss ถือเป็นต้นทุนความล้มเหลวหรือคืนบางส่วน; หากคงไว้ต้องมี cancellation reason, log ใน UI, warning และ AI policy ป้องกัน thrash; อย่าแก้ให้คืนฟรีโดยละเลย arbitrage

**เกณฑ์ตรวจรับหลังแก้:** เมื่อเปลี่ยนงานต้องมีผล deterministic ชัดเจน, UI บอกเหตุผลและจำนวนวัตถุดิบที่สูญ, NPC ไม่วนสั่งเปลี่ยนงานจน resource leak; tests preserve agreed rule

---
