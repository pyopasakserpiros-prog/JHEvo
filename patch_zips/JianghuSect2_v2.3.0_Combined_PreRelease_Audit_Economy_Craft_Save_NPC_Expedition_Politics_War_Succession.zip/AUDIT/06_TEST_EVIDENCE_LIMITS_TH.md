# 06 — Execution Log, Coverage และข้อจำกัด

## ฐานตรวจ

- source ZIP: `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip`; SHA-256: `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`
- `AGENTS.md` และสกิลที่เกี่ยวข้องอ่านก่อนตรวจ, ใช้ซอร์สจาก ZIP เป็นต้นทาง. ไม่มี source modifications
- แยกหน่วยประเมิน: **13 bug-reproduction scenarios** ยืนยันพฤติกรรมที่ไม่พึงประสงค์ (ไม่ใช่ pass regression หลังแก้) และ **13 preexisting tests** ผ่านตามที่เขียนไว้ (ไม่ใช่หลักฐานว่าไม่มีบัค)

## Bug-reproduction scenarios (13/13 confirmed)

- `UI_CARAVAN_REPEAT_MONEY` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `UI_EDICT_FREE_STOCK` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `TREASURY_NEGATIVE_AND_NONFINITE` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `SPECIALTY_PILL_UNDERPAY_AND_MISSING_HERB` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `FUSION_PILL_ZERO_COST_API` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `CP_STONE_GRANT_FORGED_QUOTE_API` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `UI_RUNE_REPEAT_NO_COST` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `CONSUMABLE_OUT_OF_STOCK_API` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `CARAVAN_SAVE_PERSISTENCE` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `UI_BOUNTY_INSTANT_PAYOUT` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `AUCTION_REOPEN_RESET_API` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `STOCK_QUANTITY_CONTRACT_API` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`
- `TREASURY_SAVE_AFTER_NAN` — `CONFIRMED`; details → `EVIDENCE/repro_results.json`

## Existing suites (13/13 PASS)

- `test/cp_economy.js` — **PASS** (exit 0, 1.18s)
- `test/cp_supply_pressure.js` — **PASS** (exit 0, 0.54s)
- `test/craft_transactions.js` — **PASS** (exit 0, 1.45s)
- `test/personal_crafting.js` — **PASS** (exit 0, 0.88s)
- `test/external_market.js` — **PASS** (exit 0, 1.21s)
- `test/content_economy.js` — **PASS** (exit 0, 1.03s)
- `test/v311_economy_dungeon_and_peaks_invariants_suite.js` — **PASS** (exit 0, 2.14s)
- `test/v330_living_sect_and_daily_loop_suite.js` — **PASS** (exit 0, 1.62s)
- `test/v350_macro_world_politics_and_alchemy_suite.js` — **PASS** (exit 0, 1.46s)
- `test/v225_release_readiness_audit_suite.js` — **PASS** (exit 0, 0.58s)
- `test/legacy_save.js` — **PASS** (exit 0, 0.53s)
- `test/recipe_scroll_lifecycle.js` — **PASS** (exit 0, 0.69s)
- `tools/validate_data_schema.js` — **PASS** (exit 0, 0.5s)

- `tools/validate_data_schema.js` รายงาน Errors: 0 และ Warnings: 0 ตามผลรันที่แนบ. ผล suite เน้น invariant เดิมและไม่ได้ทดสอบ UI exploit ที่ค้นพบใหม่

## Native simulation 7 / 14 days

| Seed | วัน | Ticks | Status | ประชากรปลายรอบ | เงินสำนักปลายรอบ | CP minted / burned | เวลารัน |
|---|---:|---:|---|---:|---:|---|---:|
| `econ-release-seed-A` | 7 | 10080 | PASS | 13 | 767 | 520 / 148 | 604ms |
| `release-econ-14day` | 14 | 20160 | PASS | 26 | 384 | 1318 / 419 | 1487ms |


การจำลองระยะสั้นตรวจ invariant รายวัน เช่น stock/CP/NPC/สูตร/market save และไม่พบ exception ใน seed เหล่านี้. **ไม่ได้หมายความว่า economic balance ปกติ:** baseline simulation ไม่จำลองผู้เล่นกด exploit ซ้ำ

## งานที่ยังไม่ยืนยัน

- **90/360 วันหลาย seed:** รันพยายามแล้วแต่หมดเวลาการประมวลผลก่อนจบ; ไม่มี output ที่เชื่อถือได้ จึงไม่ถือว่า pass/fail และไม่ได้สรุปกราฟเงินเฟ้อ long-term
- **คลิก UI จริง:** ไม่ได้เปิด browser และไม่เห็นภาพหน้าจอ; ยืนยัน source handler และทดสอบ service ตัวเดียวกันผ่าน Node เท่านั้น
- **Combat downstream rune:** ยืนยัน modifier เพิ่มซ้ำและต้นทุน 0; ไม่ได้พิสูจน์การ stack จริงในการคำนวณ damage
- **Catalog completo:** ไม่ได้พิสูจน์ทุก recipe, ทุก scarcity, ทุก world resource source/sink และทุกสถานะเซฟ รวมทั้งทุก path ที่เชื่อมกับระบบ
- **UI/API separation:** `free fusion`, `forged CP quote`, `NaN pay`, `consume out-of-stock`, `auction reopen` เป็นการเรียก API ตรงในโลกจำลอง ไม่ควรอ้างว่าผู้เล่นทำผ่านเมนูได้จนกว่าจะพบ call-site
- **Design decisions:** สัญญาจำนวนทศนิยมและการ loss ของ receipt ต้องถามสเปกก่อนเปลี่ยน
- **Test coverage count:** ตัวเลข suite 13 เป็น targeted subsets ของเกม ไม่ใช่การรัน 139/139 suites ตาม AGENTS

## วิธีอ่านผล

`CONFIRMED` = script มี assertion ที่คาดหวังว่า *บัคเกิดขึ้น* แล้วผ่าน; `PASS` = test suite เดิมผ่านเกณฑ์เดิม. หลังแก้บัคแล้ว **CONFIRMED reproduction อาจกลายเป็น ERROR_OR_UNEXPECTED ซึ่งเป็นสัญญาณดีแต่ยังต้องมี new regression pass**. ทุก scenario ใช้ new world และไม่ได้แก้ ZIP เกมต้นฉบับ
