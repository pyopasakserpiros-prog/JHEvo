/* expedition.js — โลกภายนอกที่ไม่มีฉาก: คณะเดินทางออกนอกสำนัก, คาราวาน, ผู้สมัครใหม่, สำนักเพื่อนบ้าน, ศัตรูบุกสำนัก, เหตุการณ์สุ่ม
 * คำนวณผลจาก "ตัวตนจริง" ของผู้เดินทาง (พลัง/โชค/การรับรู้/การเอาตัวรอด/นิสัยซื่อสัตย์-โลภ) ไม่สุ่มลอย ๆ */
(function (g) {
  'use strict';
  const U = g.U || require('./util.js'), HC = g.HC, MAP = g.MAP, CULT = g.CULT, ECO = g.ECO, SECT = g.SECT, AI = g.AI, COMBAT = g.COMBAT, JD = g.JD;
  const clamp = U.clamp;
  const X = {};
  const E = (n, p) => HC.eff(n, p);

  X.REGIONS = [
    { id: 'forest', nameTh: 'ป่าหมอกเขียว', danger: 1, terrain: 'forest', days: 3, beastMax: 3 },
    { id: 'plains', nameTh: 'ทุ่งราบเมฆา', danger: 1, terrain: 'plains', days: 3, beastMax: 2 },
    { id: 'mountain', nameTh: 'ทิวเขาศิลาคราม', danger: 2, terrain: 'mountain', days: 5, beastMax: 4 },
    { id: 'desert', nameTh: 'ทะเลทรายเพลิงอัสดง', danger: 3, terrain: 'desert', days: 8, beastMax: 5 },
    { id: 'water', nameTh: 'ลุ่มน้ำสาบมังกรคราม', danger: 2, terrain: 'water', days: 4, beastMax: 6 },
    { id: 'ruins', nameTh: 'ซากนครโบราณ', danger: 4, terrain: 'mountain', days: 10, beastMax: 6 }
  ];
  X.beastPool = reg => {
    if (!reg) return [];
    if (reg.terrain === 'water' || reg.id === 'water') {
      return JD.BEASTS.species.filter(b => (b.terrain === 'water' || b.archetype === 'AQUATIC') && b.tier <= reg.beastMax && b.tier >= Math.max(1, reg.beastMax - 3));
    }
    return JD.BEASTS.species.filter(b => (reg.beasts && reg.beasts.length ? reg.beasts.includes(b.id) : !b.sourcePack) && b.terrain !== 'water' && b.archetype !== 'AQUATIC' && b.tier <= reg.beastMax && b.tier >= Math.max(1, reg.beastMax - 3));
  };
  X.MISSIONS = {
    fortune: { nameTh: 'ผจญโชควาสนา', icon: '🍀' },
    hunt: { nameTh: 'ล่าสัตว์อสูร', icon: '🐺' },
    gather: { nameTh: 'เก็บสมุนไพร/แร่ในแดนลึก', icon: '🌿' },
    trade: { nameTh: 'นำสินค้าไปค้าขาย', icon: '🐪' },
    diplomacy: { nameTh: 'เยือนสำนักพันธมิตร', icon: '🤝' },
    recruit: { nameTh: 'ตามหาผู้มีพรสวรรค์', icon: '🔎' },
    bounty: { nameTh: 'รับงานจ้างคุ้มกัน', icon: '🛡️' },
    sect_siege: { nameTh: 'กรีฑาทัพตีค่ายสำนักอริ', icon: '⚔️' },
    resource_claim: { nameTh: 'ยึดครองจุดยุทธศาสตร์ทรัพยากร', icon: '🚩' },
    city_visit: { nameTh: 'เยี่ยมเมือง', icon: '🏮' },
    world_anomaly: { nameTh: 'ช่วงชิงวาสนาฟ้าดินจำกัดเวลา', icon: '☄️' }
  };
  const SECT_NAMES = ['สำนักกระบี่เมฆขาว', 'สำนักบัวหยก', 'ตระกูลหลงเหมิน', 'สำนักเสือคำราม', 'หอสุริยาสีทอง', 'สำนักพิรุณหยิน', 'ศาลาฟ้าครามพิรุธ', 'สำนักมังกรหมอก'];
  X.initWorld = (W) => {
    const rng = W.rng; const names = rng.shuffle(SECT_NAMES.slice()).slice(0, 6);
    W.world = { sects: names.map((nm, i) => ({ id: 'S' + i, nameTh: nm, power: Math.round(rng.gauss(1, 0.35) * 100) / 100, attitude: Math.round(rng.gauss(0, 25)), style: rng.pick(['เป็นธรรม', 'โลภ', 'ทะนง', 'ใฝ่สงบ', 'ก้าวร้าว']), contact: 0 })), expeds: [], seq: 0, visitors: [], resourcePool: { stones: 50000, herbs: 5000, ores: 5000 } };
    X.initContinent(W);
    W.threat = { alert: 0, roadBlocked: 0, raidCooldown: W.day + 40 };
  };

  /* ---------- อาสาไปภารกิจ (เรียกจากกิจกรรม errand) ---------- */
  X.volunteer = (W, n) => {
    if (n.away || n.dead) return;
    const opts = [];
    const e = p => E(n, p), pw = CULT.power(n);
    opts.push({ k: 'fortune', w: Math.max(0.1, (e('destiny.luck') - 35) / 40 + (e('temperament.sensationSeeking') - 40) / 40 + (e('interests.exploring') - 40) / 40 + (e('values.freedom') - 40) / 60) });
    if (pw > 60) opts.push({ k: 'hunt', w: Math.max(0.1, (e('interests.combat') - 35) / 30 + (e('personality.courage') - 40) / 50 + (e('values.wealthResource') - 40) / 80) });
    opts.push({ k: 'gather', w: Math.max(0.1, (e('interests.herbs') + e('interests.alchemy') + e('interests.labor') - 120) / 50 + ((n.h.skills.herbalism || 0) + (n.h.skills.mining || 0)) / 80) });
    if (n.rank >= 2) opts.push({ k: 'trade', w: Math.max(0.1, (e('interests.trade') - 35) / 30 + (e('aptitudes.socialCommerce') - 45) / 50) });
    if (n.rank >= 2) opts.push({ k: 'diplomacy', w: Math.max(0.1, (e('social.charisma') + e('interests.socializing') + ((n.h.skills.diplomacy || 0) * 0.5 + e('personality.empathy') * 0.5) - 130) / 50) });
    if (n.rank >= 3) opts.push({ k: 'recruit', w: Math.max(0.1, (e('interests.teaching') - 35) / 30 + (e('values.sectDuty') - 45) / 50 + (e('intellect.judgement') - 45) / 60) });
    if (pw > 80) opts.push({ k: 'bounty', w: Math.max(0.1, (e('values.wealthResource') - 40) / 30 + (e('interests.combat') - 40) / 50) });
    const elder=SECT.holder(W,'mission'),master=W.byId[W.sect.masterId];
    const approver=g.COG?[elder,master,W.byId[W.sect.deputyId]].find(x=>g.COG.available(x,W)):(elder||master);
    if(!approver)return;
    if(g.COG)opts.forEach(o=>o.w*=Math.max(.2,1+g.COG.missionBias(W,approver,o.k)));
    const pick = W.rng.weighted(opts, o => o.w).k;
    if(g.COG)g.COG.officeDecision(W,approver,'พิจารณาภารกิจ '+X.MISSIONS[pick].nameTh,['ตรวจความพร้อม ผู้สมัคร นโยบายและความเสี่ยง']);
    let p = 0.6 + (W.sect.policy.expansion - 50) / 200 + (W.sect.policy.risk - 50) / 250 - (W.sect.policy.strictness - 50) / 300;
    if (pick === 'hunt' || pick === 'bounty') p += (E(approver, 'personality.courage') - 50) / 250;
    if (n.post && SECT.holder(W, n.post) === n && !n.assist) p -= 0.15;
    if (n.rank <= 1 && W.sect.policy.strictness > 65) p -= 0.15 + (E(approver, 'personality.caution') - 50) / 300;
    if (n.rank <= 1 && CULT.power(n) < 40) p -= 0.2;
    const aliveAway = W.npcs.filter(x => x.expId && !x.dead).length; if (aliveAway > W.npcs.length * 0.2) p -= 1.5;
    if (ECO.count(W, 'meal') < 4) p -= 0.5;
    if (W.threat.alert > 0) p -= 0.8;
    if (W.rng.next() > clamp(p, 0.05, 0.95)) { n.lastTrip = W.day - 6; HC.feel(n, { mood: -3 }); AI.mem(W, n, 'ถูกปฏิเสธไม่ให้ออกเดินทาง (' + X.MISSIONS[pick].nameTh + ')', 0.3); if (W.rng.chance(0.2)) W.log('mission', n.h.name.given + ' ขอไปภารกิจ「' + X.MISSIONS[pick].nameTh + '」แต่ไม่ได้รับอนุมัติ', [n.id]); return; }
    const party = [n];
    const want = pick === 'hunt' || pick === 'bounty' ? 2 + (pw < 200 ? 1 : 0) : pick === 'trade' ? 1 : pick === 'fortune' ? (E(n, 'personality.caution') > 55 ? 1 : 0) : (E(n, 'temperament.sociability') > 55 ? 1 : 0);
    if (want > 0) {
      const cands = W.npcs.filter(x => x !== n && !x.dead && !x.away && !x.exiled && x.rank >= 1 && x.rank <= 4 && !(AI.isProtectedAction ? AI.isProtectedAction(W, x, 'expedition') : (x.act && ['sleep', 'breakthrough', 'fight', 'sentence'].includes(x.act.id))) && !x.sealed && !(x.jail > W.t) && !(x.inj && x.inj.length) && !(x.post && x.rank >= 4));
      cands.forEach(c => {
        const ri = (g.COG && g.COG.relInfo) ? g.COG.relInfo(W, n, c) : { affection: (n.h.mind.relations[c.id]?.a || 0), trust: 40, gratitude: 0, respect: 30, bond: '' };
        const rivalCoop = (ri.bond === 'คู่แข่ง' && (pick === 'hunt' || pick === 'bounty') && ri.respect >= 38) ? 0.25 : 0;
        c._s = AI.compat(n, c) + ri.affection / 100 + (ri.trust - 40) / 160 + ri.gratitude / 150 + rivalCoop + (pick === 'hunt' ? CULT.power(c) / 400 : 0) + W.rng.next() * 0.3;
      });
      cands.sort((a, b) => b._s - a._s);
      for (const c of cands) {
        if (party.length > want) break;
        const riB = (g.COG && g.COG.relInfo) ? g.COG.relInfo(W, c, n) : { gratitude: 0, trust: 40 };
        const acc = clamp(0.35 + c._s * 0.4 + riB.gratitude / 200 + (riB.trust - 40) / 220 + (E(c, 'personality.courage') - 50) / 200 - (c.h.state.energy < 40 ? 0.3 : 0), 0.05, 0.92);
        if (c._s > 0.1 && W.rng.next() < acc) party.push(c);
      }
    }
    X.depart(W, party, pick);
  };

  /* ---------- ทะเบียนจุดวาสนาตามระดับแรงค์ยุทธภพ 1..4 (Data-Driven Fortune Registry) ---------- */
  X.FORTUNE_REGISTRY = {
    1: [
      {
        id: 'f1_bamboo_grotto', nameTh: 'ถ้ำไผ่หมอกเขียว', biome: 'forest',
        pools: [
          { id: 'f1_bamboo_herbs', nameTh: 'ดงสมุนไพรรากหยก', skill: 'herbalism', diff: 20, herbs: ['MAT_HERB_DEW_GRASS_1', 'MAT_HERB_CINDER_LEAF_1'], stones: 30 },
          { id: 'f1_bamboo_traps', nameTh: 'ค่ายกลไผ่โบราณ', skill: 'survival', diff: 22, stones: 45, pill: 'P:BASIC_HP', techTier: 2 }
        ]
      },
      {
        id: 'f1_river_pebble', nameTh: 'ตลิ่งหินประกายธาร', biome: 'plains',
        pools: [
          { id: 'f1_river_ore', nameTh: 'สายแร่ตื้นริมน้ำ', skill: 'mining', diff: 20, ore: ['MAT_ORE_BLACK_IRON_1'], stones: 35 },
          { id: 'f1_river_hermit', nameTh: 'ศาลาชาวประมงชรา', skill: 'diplomacy', diff: 18, stones: 25, pill: 'P:BASIC_QI', insight: true }
        ]
      },
      {
        id: 'f1_old_shrine', nameTh: 'ศาลาร้างชายป่า', biome: 'mountain',
        pools: [
          { id: 'f1_shrine_inscription', nameTh: 'จารึกบทสวดโบราณ', skill: 'SCRIPTURE', diff: 22, techTier: 2, insight: true, stones: 30 },
          { id: 'f1_shrine_cache', nameTh: 'ช่องลับใต้แท่นบูชา', skill: 'perceptiveness', diff: 20, gearTier: 1, stones: 40 }
        ]
      },
      {
        id: 'f1_blood_thorn_hollow', nameTh: 'โพรงหนามโลหิตชายเขา', icon: '🩸', biome: 'forest',
        desc: 'โพรงไม้หนามสีชาดที่ซ่อนคราบเลือดอสูรและรอยเล็บกิเลนโลหิตไว้ตามผนังหิน',
        pools: [
          { id: 'f1_thorn_beast_lair', nameTh: 'รังเก่าหมาป่ากิเลนโลหิต', skill: 'survival', diff: 22, beastParts: ['MAT_V222_BP_01', 'MAT_V222_BP_02', 'MAT_V222_BP_03'], recipeIds: ['REC_V222_EQ_01', 'REC_V222_EQ_04'], stones: 42 },
          { id: 'f1_thorn_fist_stele', nameTh: 'รอยหมัดโลหิตบนผาหิน', skill: 'courage', diff: 24, techIds: ['TECH_V222_01'], beastParts: ['MAT_V222_BP_09', 'MAT_V222_BP_10'], stones: 48, insight: true }
        ]
      },
      {
        id: 'f1_frost_echo_gully', nameTh: 'หุบเสียงสะท้อนเหมันต์', icon: '❄️', biome: 'water',
        desc: 'ร่องหุบเขาริมน้ำตกเยือกแข็งที่สายลมและไอเย็นพัดผ่านช่องหินเกิดเสียงดั่งพิณโบราณ',
        pools: [
          { id: 'f1_frost_chord_creek', nameTh: 'ลำธารน้ำค้างแข็งสะท้อนเสียงพิณ', skill: 'SCRIPTURE', diff: 22, techIds: ['TECH_V222_09'], recipeIds: ['REC_V222_EQ_07', 'REC_V222_EQ_12'], stones: 45, insight: true },
          { id: 'f1_frost_bear_den', nameTh: 'ถ้ำน้ำแข็งหมีหนามเหมันต์', skill: 'perceptiveness', diff: 23, beastParts: ['MAT_V222_BP_11', 'MAT_V222_BP_12', 'MAT_V222_BP_15'], gearIds: ['EQ_V222_08_SPEAR_3'], stones: 45 }
        ]
      }
    ],
    2: [
      {
        id: 'f2_mist_valley', nameTh: 'หุบเขาเมฆาคราม', biome: 'mountain',
        pools: [
          { id: 'f2_mist_cliff_lotus', nameTh: 'หน้าผาดอกบัวหยก', skill: 'herbalism', diff: 40, herbs: ['MAT_HERB_JADE_LOTUS_2', 'MAT_HERB_MIST_ORCHID_2'], stones: 70 },
          { id: 'f2_mist_wind_trap', nameTh: 'ช่องลมกระโชกสะบั้นปราณ', skill: 'survival', diff: 42, stones: 90, gearTier: 2, insight: true }
        ]
      },
      {
        id: 'f2_abandoned_mine', nameTh: 'เหมืองแร่ร้างใต้ผา', biome: 'mountain',
        pools: [
          { id: 'f2_mine_crystal_vein', nameTh: 'สายแร่ผลึกวิญญาณ', skill: 'mining', diff: 42, ore: ['MAT_ORE_COLD_STEEL_2', 'MAT_ORE_JADE_SLATE_2'], stones: 80 },
          { id: 'f2_mine_poison_mist', nameTh: 'หมอกพิษในปล่องเหมือง', skill: 'ALCHEMY', diff: 40, pill: 'P:BASIC_HP2', stones: 85 }
        ]
      },
      {
        id: 'f2_ancient_pavilion', nameTh: 'หอพักเซียนยอดเขา', biome: 'plains',
        pools: [
          { id: 'f2_pavilion_scrolls', nameTh: 'หีบม้วนตำราหยก', skill: 'SCRIPTURE', diff: 45, techTier: 3, stones: 75, insight: true },
          { id: 'f2_pavilion_spring', nameTh: 'ตาน้ำปราณวารีทิพย์', skill: 'willpower', diff: 38, spring: true, stones: 60 }
        ]
      },
      {
        id: 'f2_thunder_echo_cliff', nameTh: 'ผาอสนีสะท้อนพิณ', icon: '⚡', biome: 'mountain',
        desc: 'หน้าผาสูงชันที่สายฟ้าฟาดลงใส่แร่เหล็กและรังเสือดาวอสนีจนเกิดเสียงกังวานไม่ขาดสาย',
        pools: [
          { id: 'f2_thunder_leopard_ledge', nameTh: 'ชะง่อนผาเสือดาวปีกอสนี', skill: 'courage', diff: 42, beastParts: ['MAT_V222_BP_05', 'MAT_V222_BP_06', 'MAT_V222_BP_04'], techIds: ['TECH_V222_06', 'TECH_V222_11'], recipeIds: ['REC_V222_EQ_02', 'REC_V222_EQ_08'], stones: 95 },
          { id: 'f2_thunder_crane_perch', nameTh: 'แท่นหินกระเรียนพายุและเขี้ยววายุ', skill: 'perceptiveness', diff: 44, beastParts: ['MAT_V222_BP_13', 'MAT_V222_BP_14', 'MAT_V222_BP_16'], recipeIds: ['REC_V222_EQ_10', 'REC_V222_EQ_15'], gearIds: ['EQ_V222_07_BOW_4'], stones: 105, insight: true }
        ]
      },
      {
        id: 'f2_venom_lotus_marsh', nameTh: 'บึงบัวพิษหมื่นบุปผา', icon: '🪷', biome: 'water',
        desc: 'บึงหมอกสีมรกตที่ดอกบัวโลหิตและเถาวัลย์วิญญาณพันกันแน่น อุดมด้วยชิ้นส่วนอสูรพฤกษาและเงาหยิน',
        pools: [
          { id: 'f2_marsh_mantis_nest', nameTh: 'ดงตั๊กแตนบัวโลหิตและกวางเถาวัลย์', skill: 'herbalism', diff: 41, beastParts: ['MAT_V222_BP_09', 'MAT_V222_BP_10', 'MAT_V222_BP_15', 'MAT_V222_BP_16', 'MAT_V222_BP_18'], recipeIds: ['REC_V222_EQ_13', 'REC_V222_EQ_19'], stones: 90 },
          { id: 'f2_marsh_crow_shrine', nameTh: 'เจดีย์จมน้ำของอีกากระดูกกลืนวิญญาณ', skill: 'willpower', diff: 44, beastParts: ['MAT_V222_BP_19', 'MAT_V222_BP_20', 'MAT_V222_BP_09'], techIds: ['TECH_V222_13', 'TECH_V222_15'], recipeIds: ['REC_V222_EQ_20'], stones: 100, insight: true }
        ]
      }
    ],
    3: [
      {
        id: 'f3_flame_crater', nameTh: 'ปล่องภูเขาไฟเพลิงอัสดง', biome: 'desert',
        pools: [
          { id: 'f3_crater_fire_essence', nameTh: 'ธารลาวาผลึกเพลิง', skill: 'mining', diff: 65, ore: ['MAT_ORE_STAR_COPPER_3'], stones: 160, gearTier: 3 },
          { id: 'f3_crater_heat_endurance', nameTh: 'ลมปราณเพลิงแผดเผา', skill: 'survival', diff: 68, pill: 'P:BASIC_HP', stones: 200, insight: true }
        ]
      },
      {
        id: 'f3_sunken_dragon_lake', nameTh: 'วังบาดาลมังกรคราม', biome: 'water',
        pools: [
          { id: 'f3_lake_pearls', nameTh: 'ดงไข่มุกวิญญาณใต้บาดาล', skill: 'perceptiveness', diff: 65, herbs: ['MAT_HERB_BLOOD_GINSENG_3'], stones: 180 },
          { id: 'f3_lake_pressure', nameTh: 'ม่านค่ายกลแรงดันน้ำลึก', skill: 'willpower', diff: 68, techTier: 4, stones: 190, spring: true }
        ]
      },
      {
        id: 'f3_ruined_sanctuary', nameTh: 'วิหารเก้าอักขระโบราณ', biome: 'ruins',
        pools: [
          { id: 'f3_sanctuary_seal', nameTh: 'ค่ายกลผนึกเก้าชั้น', skill: 'SCRIPTURE', diff: 70, techTier: 4, stones: 220, insight: true },
          { id: 'f3_sanctuary_vault', nameTh: 'คลังศาสตราทหารเทพ', skill: 'courage', diff: 68, gearTier: 3, stones: 210 }
        ]
      },
      {
        id: 'f3_crimson_slaughter_altar', nameTh: 'แท่นบูชาโลหิตอสูรโบราณ', icon: '🩸', biome: 'desert',
        desc: 'แท่นศิลาโบราณกลางทะเลทรายสีเลือดที่ผนึกซากพยัคฆ์ไขกระดูกโลหิตและแรดศิลาเหล็กไหล',
        pools: [
          { id: 'f3_altar_blood_marrow', nameTh: 'สระไขกระดูกพยัคฆ์โลหิต', skill: 'courage', diff: 66, beastParts: ['MAT_V222_BP_03', 'MAT_V222_BP_04', 'MAT_V222_BP_02'], techIds: ['TECH_V222_02', 'TECH_V222_04', 'TECH_V222_20'], recipeIds: ['REC_V222_EQ_03', 'REC_V222_EQ_05'], stones: 225, spring: true },
          { id: 'f3_altar_iron_toad', nameTh: 'ห้องหลอมคางคกทองคำและแรดศิลา', skill: 'mining', diff: 68, beastParts: ['MAT_V222_BP_17', 'MAT_V222_BP_18', 'MAT_V222_BP_19', 'MAT_V222_BP_13'], techIds: ['TECH_V222_17'], recipeIds: ['REC_V222_EQ_09', 'REC_V222_EQ_22'], gearIds: ['EQ_V222_03_BLADE_3'], stones: 240 }
        ]
      },
      {
        id: 'f3_glacier_phoenix_roost', nameTh: 'รังหงส์น้ำแข็งเก้าเหมันต์', icon: '🧊', biome: 'mountain',
        desc: 'ยอดเขาน้ำแข็งพันปีที่หงส์ขาวเหมันต์และอสรพิษวิญญาณน้ำแข็งผลัดขนทิ้งวัตถุดิบระดับสูงไว้',
        pools: [
          { id: 'f3_roost_ice_swan', nameTh: 'แท่นขนหงส์เหมันต์และเกล็ดงูน้ำแข็ง', skill: 'survival', diff: 67, beastParts: ['MAT_V222_BP_07', 'MAT_V222_BP_08', 'MAT_V222_BP_06'], techIds: ['TECH_V222_05', 'TECH_V222_07', 'TECH_V222_19'], recipeIds: ['REC_V222_EQ_11', 'REC_V222_EQ_14'], stones: 230 },
          { id: 'f3_roost_zither_pavilion', nameTh: 'ศาลาพิณสายฟ้าเยือกแข็ง', skill: 'SCRIPTURE', diff: 69, techIds: ['TECH_V222_14', 'TECH_V222_16'], recipeIds: ['REC_V222_EQ_16'], gearIds: ['EQ_V222_14_LIGHT_3'], stones: 245, insight: true }
        ]
      }
    ],
    4: [
      {
        id: 'f4_void_rift', nameTh: 'รอยแยกห้วงมิติสุญญะ', biome: 'ruins',
        pools: [
          { id: 'f4_rift_anomaly', nameTh: 'กระแสปราณผันผวนไร้ระเบียบ', skill: 'willpower', diff: 85, techTier: 5, stones: 450, insight: true },
          { id: 'f4_rift_astral_ore', nameTh: 'ผลึกดาวตกบรรพกาล', skill: 'mining', diff: 88, ore: ['MAT_ORE_MITHRIL_JADE_4'], stones: 500, gearTier: 4 }
        ]
      },
      {
        id: 'f4_celestial_tomb', nameTh: 'สุสานเซียนนิรันดร์', biome: 'mountain',
        pools: [
          { id: 'f4_tomb_scripture', nameTh: 'โลงหยกจารึกคัมภีร์เซียน', skill: 'SCRIPTURE', diff: 90, techTier: 5, stones: 480, insight: true },
          { id: 'f4_tomb_guard_trial', nameTh: 'ด่านทดสอบจิตวิญญาณเซียน', skill: 'courage', diff: 88, spring: true, stones: 400, gearTier: 4 }
        ]
      },
      {
        id: 'f4_primordial_fountain', nameTh: 'ตาน้ำพุปฐมธาตุ', biome: 'water',
        pools: [
          { id: 'f4_fountain_essence', nameTh: 'หยาดน้ำอมฤตปฐมกาล', skill: 'herbalism', diff: 85, herbs: ['MAT_HERB_DRAGON_GRASS_4'], stones: 420, spring: true },
          { id: 'f4_fountain_cleansing', nameTh: 'ชำระล้างเส้นลมปราณเก้าทิศ', skill: 'ALCHEMY', diff: 88, spring: true, stones: 450, insight: true }
        ]
      },
      {
        id: 'f4_astral_starfall_observatory', nameTh: 'หอดูดาวดาราจักรล่มสลาย', icon: '🌠', biome: 'ruins',
        desc: 'ซากหอดูดาวโบราณที่ลอยคว้างเหนือรอยแยกดาราจักร แหล่งพำนักของจิ้งจอกเก้าหางดาราและวาฬสมุทรเหมันต์',
        pools: [
          { id: 'f4_obs_star_fox_sanctum', nameTh: 'แท่นศิลาจิ้งจอกเก้าหางดารา', skill: 'SCRIPTURE', diff: 86, beastParts: ['MAT_V222_BP_21', 'MAT_V222_BP_22', 'MAT_V222_BP_07'], techIds: ['TECH_V222_10', 'TECH_V222_12', 'TECH_V222_21', 'TECH_V222_23'], recipeIds: ['REC_V222_EQ_17', 'REC_V222_EQ_21', 'REC_V222_EQ_23'], stones: 490, insight: true },
          { id: 'f4_obs_astral_armory', nameTh: 'คลังสมบัติเทพดาราจักร', skill: 'perceptiveness', diff: 88, gearIds: ['EQ_V222_17_ROBE_4', 'EQ_V222_22_RING_5'], stones: 520, spring: true }
        ]
      },
      {
        id: 'f4_abyssal_chimera_maw', nameTh: 'หุบเหวอสูรกลืนสวรรค์บรรพกาล', icon: '🕳️', biome: 'ruins',
        desc: 'ปากเหวไร้ก้นบึ้งที่เชื่อมกับคุกมังกรสมุทรโลหิตและอสูรบรรพกาลกลืนดารา เต็มไปด้วยวัตถุดิบระดับตำนาน',
        pools: [
          { id: 'f4_maw_chimera_core', nameTh: 'รังราชันมังกรโลหิตและอสูรกลืนดารา', skill: 'courage', diff: 88, beastParts: ['MAT_V222_BP_23', 'MAT_V222_BP_24', 'MAT_V222_BP_08'], techIds: ['TECH_V222_03', 'TECH_V222_08', 'TECH_V222_22'], recipeIds: ['REC_V222_EQ_06', 'REC_V222_EQ_18', 'REC_V222_EQ_24'], stones: 540 },
          { id: 'f4_maw_primordial_seal', nameTh: 'แท่นผนึกศาสตราและคัมภีร์ห้วงเหว', skill: 'willpower', diff: 90, techIds: ['TECH_V222_18', 'TECH_V222_24'], gearIds: ['EQ_V222_06_SWORD_5', 'EQ_V222_24_CHARM_6'], stones: 560, insight: true }
        ]
      }
    ]
  };
  Object.entries(X.FORTUNE_REGISTRY).forEach(([r, sites]) => {
    sites.forEach(s => { s.rank = Number(r); s.icon = s.icon || '✨'; s.desc = s.desc || s.nameTh; });
  });

  X.isAvailableForExpedition = (W, n, opts) => {
    if (!W || !n || n.dead || n.exiled) return false;
    if (W.byId && Object.keys(W.byId).length > 0 && W.byId[n.id] !== n) return false;
    if (Array.isArray(W.npcs) && !W.npcs.includes(n)) return false;
    if (SECT && SECT.isNpcDetained && SECT.isNpcDetained(W, n)) return false;
    if ((n.jail && n.jail > (W.t || 0)) || (n.punished && n.punished > (W.t || 0)) || (n.detainedUntilDay && n.detainedUntilDay > (W.day || 0))) return false;
    if (!(opts && opts.allowDeployed) && (n.away || n.travel || n.expId)) return false;
    return true;
  };

  X.releaseDeployedGarrisons = (W, members) => {
    if (!W || !W.world || !W.world.resourceNodes || !X.recomputeNodeGarrison) return;
    const ids = new Set((members || []).filter(Boolean).map(n => n.id));
    if (!ids.size) return;
    for (const node of Object.values(W.world.resourceNodes)) {
      if (node && node.garrison && Array.isArray(node.garrison.discipleIds) && node.garrison.discipleIds.some(id => ids.has(id))) {
        X.recomputeNodeGarrison(W, node);
      }
    }
  };

  const regionalMounts = Object.freeze({
    HAWK: { duration:.86, capacity:1.4 },
    GOAT: { duration:.92, capacity:1.15 }
  });

  const mountReady = pet => {
    if (!pet || pet.active === false || pet.dead || pet.injured || (pet.fatigue || 0) >= 95) return false;
    const lineage = CULT.lineageCompanionSpec(pet.speciesId);
    if (lineage) return lineage.familyId === 'KUNPENG' && pet.growthStage >= 3 && pet.hunger >= 38 && pet.fatigue < 75;
    const regional = CULT.regionalCompanionSpec(pet.speciesId);
    if (regional && !pet.fourSymbol) return !!regionalMounts[regional.key] && pet.growthStage >= 2 && pet.hunger >= 38 && pet.fatigue < 75;
    return pet.role === 'MOUNT_CHARGER' || pet.family === 'AVIAN' || pet.family === 'UNGULATE' ||
      pet.fourSymbol === 'VERMILION_PHOENIX' || pet.fourSymbol === 'AZURE_DRAGON';
  };

  X.travelMount = npc => {
    const uid = npc?.travel?.mountUid;
    if (!uid || npc.dead || npc.away || npc.act?.id === 'fight') return null;
    const sameMount = pet => (pet?.uid || pet?.id) === uid && mountReady(pet);
    return npc.pets?.find(sameMount) || (sameMount(npc.pet) ? npc.pet : null);
  };

  X.createParty = (W, party, opts) => {
    opts = opts || {};
    if (!W || !Array.isArray(party) || !party.length) return { ok: false, reason: 'invalid-party', members: [] };
    const members = [];
    const seenIds = new Set();
    for (const x of party) {
      const n = typeof x === 'string' ? (W.byId && W.byId[x]) : x;
      if (!X.isAvailableForExpedition(W, n, opts)) return { ok: false, reason: 'unavailable-member', members: [] };
      if (seenIds.has(n.id)) return { ok: false, reason: 'duplicate-member', members: [] };
      seenIds.add(n.id);
      members.push(n);
    }
    const mounts = [];
    let hasPhoenixMount = false, hasAzureDragonMount = false;
    let fastestMount = 1, mountCapacity = 1;
    for (const n of members) {
      const pets = (Array.isArray(n.pets) ? n.pets : []).concat(n.pet ? [n.pet] : []);
      const pet = pets.find(mountReady);
      if (pet) {
        const lineage = CULT.lineageCompanionSpec(pet.speciesId);
        const regional = !pet.fourSymbol && CULT.regionalCompanionSpec(pet.speciesId);
        const route = regional && regionalMounts[regional.key];
        const mountDuration = lineage ? [.83, .75, .69][lineage.gradeRank - 1] : (route?.duration ?? .75);
        fastestMount = Math.min(fastestMount, mountDuration);
        mountCapacity = Math.max(mountCapacity, route?.capacity ?? 1.4);
        if (pet.fourSymbol === 'VERMILION_PHOENIX' || pet.bloodlineTrait === 'VERMILION_PHOENIX') hasPhoenixMount = true;
        if (pet.fourSymbol === 'AZURE_DRAGON' || pet.bloodlineTrait === 'AZURE_DRAGON') hasAzureDragonMount = true;
        mounts.push({ ownerId: n.id, uid: pet.uid || pet.id || null, nameTh: pet.nameTh || 'พาหนะวิญญาณ', role: pet.role || null, family: pet.family || null, fourSymbol: pet.fourSymbol || null, tier: pet.tier || 1 });
      }
    }
    const fsSummary = (CULT && CULT.sectFourSymbolSummary) ? CULT.sectFourSymbolSummary(W) : null;
    if (fsSummary && fsSummary.hasVermilionPhoenix && opts.useSectPhoenixAura) hasPhoenixMount = true;
    const isWaterRoute = opts.regionId === 'water' || opts.regionId === 'REG_SLEEPING_DRAGON_LAKE' || opts.macroRegion === 'SOUTHERN_WATERS' || opts.terrain === 'water';
    if (isWaterRoute && fsSummary && fsSummary.hasAzureDragon) hasAzureDragonMount = true;
    const hasMount = mounts.length > 0 || hasPhoenixMount;
    const qgBonus = (CULT && CULT.QINGGONG && CULT.QINGGONG.evaluatePartyExpeditionBonus)
      ? CULT.QINGGONG.evaluatePartyExpeditionBonus(W, members, { terrain: isWaterRoute ? 'water' : opts.terrain, nameTh: opts.regionId || '' })
      : { durationMultiplier: 1.0, capacityMultiplier: 1.0, hazardReduction: 0, dominantMode: 'MORTAL_WALK', summaryTh: 'เดินเท้าปกติ' };
    const applyQinggongToTrip = opts.useQinggong === true || (opts.useQinggong !== false && CULT && CULT.QINGGONG && members.some(m => CULT.QINGGONG.hasExplicitWorldQinggong(m)));
    const hasDragonShipNav = members.some(m => m && m.cult && (m.cult.sub === 'DRAGON_SHIP_NAVIGATOR' || m.cult.path === 'TIDE_VOYAGER'));
    const hasPocketArch = members.some(m => m && m.cult && m.cult.sub === 'POCKET_REALM_ARCHITECT');
    const mountDurMult = hasPhoenixMount ? 0.60 : (hasAzureDragonMount && isWaterRoute) ? 0.65 : fastestMount;
    const mountCapMult = hasPhoenixMount ? 1.60 : mountCapacity;
    const navDurFactor = (isWaterRoute && hasDragonShipNav) ? (members.some(m => m && m.cult && m.cult.sub === 'DRAGON_SHIP_NAVIGATOR') ? 0.82 : 0.90) : 1;
    const rawDurMult = applyQinggongToTrip ? mountDurMult * qgBonus.durationMultiplier : mountDurMult;
    const durMult = +(Math.max(0.45, rawDurMult * navDurFactor)).toFixed(3);
    const rawCapMult = applyQinggongToTrip ? mountCapMult * qgBonus.capacityMultiplier : mountCapMult;
    const capMult = +(rawCapMult * (hasPocketArch ? 1.25 : 1)).toFixed(2);
    let supportHazRed = 0;
    if (CULT && CULT.SUPPORT_ARTS) {
      for (let i = 0; i < members.length; i++) {
        const m = members[i];
        if (m && m.supportState && m.cult) {
          const sup = CULT.SUPPORT_ARTS.resolveNpcSupport(W, m);
          if (sup && sup.effExpeditionHazardRed > supportHazRed) supportHazRed = sup.effExpeditionHazardRed;
        }
      }
    }
    const hazRed = Math.min(0.65, (hasPhoenixMount ? 0.35 : (hasMount ? 0.12 : 0)) + (applyQinggongToTrip ? qgBonus.hazardReduction : 0) + supportHazRed);
    const baseDays = Number.isFinite(opts.baseDays) ? Math.max(1, opts.baseDays) : null;
    const baseCapacity = Number.isFinite(opts.baseCapacity) ? Math.max(1, opts.baseCapacity) : 20 + members.length * 12;
    return {
      ok: true, members, mounts, hasMount, hasPhoenixMount, hasAzureDragonMount,
      qinggongBonuses: qgBonus,
      qinggongActive: applyQinggongToTrip,
      durationMultiplier: durMult,
      capacityMultiplier: capMult,
      hazardReduction: +hazRed.toFixed(3),
      baseDays,
      days: baseDays == null ? null : Math.max(0.5, +(baseDays * durMult).toFixed(4)),
      baseCarryCapacity: baseCapacity,
      carryCapacity: Math.max(1, Math.floor(baseCapacity * capMult))
    };
  };

  const tripMountUid = (ex, npc) => Array.isArray(ex.mount)
    ? ex.mount.find(mount => mount.ownerId === npc.id)?.uid || null
    : null;

  X.depart = (W, party, kind, region, opts) => {
    opts = opts || {};
    if (!kind || !X.MISSIONS[kind]) return null;
    const rng = W.rng; const w = W.world;
    const assembled = X.createParty(W, party, { kind });
    if (!assembled.ok) return null;
    party = assembled.members;
    const lead = party[0];
    const partyRank = Math.max(1, ...party.map(x => CULT.worldRank ? CULT.worldRank(x) : 1));
    const regs = X.REGIONS.filter(r => (kind !== 'trade' && kind !== 'diplomacy' || r.danger <= 2));
    const topo = X.ensureWorldTopology(W);
    const travelWeight = r => {
      const route = X.planContinentalRoute(W,topo,topo.nodes[r.id]);
      const reluctance = clamp(.36 + (E(lead,'personality.caution') - E(lead,'interests.exploring')) / 185,.13,.64);
      // Nearby work saves food and duty time. A distant resource still has a chance when there is a reason to go.
      return 1 / (1 + Math.pow((route?.days ?? r.days) * reluctance,1.5));
    };
    if (!region) region = (g.CONTENT && g.CONTENT.chooseRegion(W,party,kind,regs,travelWeight)) ||
      rng.weighted(regs,r => travelWeight(r) * (1 + (kind === 'fortune' || kind === 'hunt' ? r.danger * .32 : 0)));
    if (!region || !X.REGIONS.includes(region)) return null;
    const requestedSite = opts.siteId && kind === 'fortune' && (X.FORTUNE_REGISTRY[partyRank] || []).find(s => s.id === opts.siteId);
    if (opts.siteId && (!requestedSite || !(requestedSite.biome === region.terrain || (requestedSite.biome === 'ruins' && region.terrain === 'mountain')))) return null;
    const seasonHours = (0.7 + rng.next() * 0.6) * (kind === 'trade' ? 1.1 : kind === 'recruit' ? 1.4 : 1);
    const regionNode = topo.nodes[region.id];
    const sites = kind === 'fortune' ? X.FORTUNE_REGISTRY[partyRank] || X.FORTUNE_REGISTRY[1] : [];
    const matching = sites.filter(s => s.biome === region.terrain || (s.biome === 'ruins' && region.terrain === 'mountain'));
    const matchSite = kind === 'fortune' ? requestedSite || rng.pick(matching.length ? matching : sites) : null;
    // A region remains the source of encounter data. The marker identifies its trailhead.
    const destination = matchSite ? X.fortuneMapPoint(topo, matchSite, partyRank, sites.indexOf(matchSite)) : regionNode;
    const route = X.planContinentalRoute(W, topo, destination);
    const fallbackDays = Math.max(2, Math.round(region.days * seasonHours));
    const baseDays = route ? 2 * route.days + seasonHours * 0.65 : fallbackDays;
    const trip = X.createParty(W, party, { kind, regionId: region.id, terrain:region.terrain, baseDays });
    const journeyDays = route ? route.days * trip.durationMultiplier : 0;
    const dwellMinutes = Math.round(seasonHours * 936);
    const days = route ? +(journeyDays * 2 + dwellMinutes / 1440).toFixed(3) : trip.days;
    if (g.SECT && g.SECT.ensureDirectives) g.SECT.ensureDirectives(W);
    const rd = W.sect && W.sect.reserveDirectives;
    const currentMeals = ECO.count(W, 'meal');
    const safetyReserve = (rd && rd.minMealReserve) || 15;
    const capPerDay = (rd && rd.expeditionMealCap) || 6;
    let supplySaveRatio = 0;
    for (const pm of party) {
      if (!pm) continue;
      const bagAndEq = [pm.equip && pm.equip.ACCESSORY, pm.equip && pm.equip.ARMOR].concat((pm.inv && pm.inv.gear) || []).filter(Boolean);
      for (const eq of bagAndEq) {
        const fxL = eq.fx || eq.effects || (ECO && ECO.itemById && ECO.itemById[eq.id] && ECO.itemById[eq.id].effects) || [];
        for (const fx of fxL) {
          if (fx && fx.effectId === 'EFX_SUPPLY_EFFICIENCY') {
            supplySaveRatio = Math.max(supplySaveRatio, (fx.params && fx.params.supplySavingRatio) || 0.25);
          }
        }
      }
    }
    const plannedFood = Math.max(party.length, Math.round(party.length * Math.min(days, capPerDay) * (1 - clamp(supplySaveRatio, 0, 0.40))));
    let takeMax = Math.max(0, currentMeals - safetyReserve);
    if (takeMax < party.length && currentMeals > 0) {
      takeMax = Math.min(currentMeals, party.length);
    }
    const taken = Math.min(plannedFood, takeMax);
    if (taken > 0) ECO.take(W, 'meal', taken);
    if (currentMeals - taken <= safetyReserve) {
      W.log('mission', 'คณะเดินทางเบิกเสบียง ' + taken + ' ชุด ทำให้เสบียงคลังเหลือ ' + (currentMeals - taken) + ' แตะเกณฑ์สำรองฉุกเฉิน (' + safetyReserve + ')', party.map(p => p.id));
    }
    const ex = { id: ++w.seq, kind, region: region.id, party: party.map(p => p.id), partyRank, t0: W.t, ret: W.t + Math.round(days * 1440) + (route ? 0 : rng.int(-300, 300)), days, baseDays, mount: trip.mounts, hasMount: trip.hasMount, durationMultiplier: trip.durationMultiplier, capacityMultiplier: trip.capacityMultiplier, baseCarryCapacity: trip.baseCarryCapacity, carryCapacity: trip.carryCapacity, journal: [], carry: [], supplies: taken, done: false, state: 'leaving', lost: false };
    setJourney(ex, route, journeyDays, dwellMinutes, true);
    if (destination) ex.targetNodeId = destination.id;
    if (matchSite) {
      const chosenPool = rng.pick(matchSite.pools);
      ex.siteId = matchSite.id;
      ex.poolId = chosenPool.id;
      ex.fortuneSite = matchSite;
    }
    if (kind === 'trade') {
      const sell = []; let cargoLeft = ex.carryCapacity;
      Object.keys(W.sect.stock).forEach(k => {
        if (cargoLeft <= 0 || !ECO.isPill(k) || W.sect.stock[k] <= 6 || !ECO.pillInfo(k)) return;
        const n = Math.min(cargoLeft, Math.floor((W.sect.stock[k] - 4) / 2));
        if (n > 0 && ECO.take(W, k, n)) { sell.push({ id: k, n }); cargoLeft -= n; }
      });
      ex.carry = sell; if (!sell.length && (W.sect.stones < 1000)) { ex.kind = kind = 'gather'; }
    }
    w.expeds.push(ex);
    party.forEach(p => { AI.interruptFor(W, p); p.expId = ex.id; p.lastTrip = W.day; p.act = { id: 'idle', stage: 'do', left: 0, total: 0, ctx: {}, why: [] }; p.travel = { to: 'exit', ex: ex.id, mountUid: tripMountUid(ex,p) }; p.path = null; p.run = false; });
    X.releaseDeployedGarrisons(W, party);
    W.log('mission', party.map(p => p.h.name.given).join('、') + ' ออกเดินทาง「' + X.MISSIONS[kind].nameTh + '」ไปยัง' + (destination?.nameTh || region.nameTh) + ' (ราว ' + days.toFixed(1) + ' วัน)', party.map(p => p.id), {location:stampPlace(destination)});
    return ex;
  };
  X.travelStep = (W, n) => {
    const tv = n.travel; if (!tv) return false;
    const qgOverride = X.travelMount(n) ? null : undefined;
    if (tv.to === 'exit') {
      if (!n.path) { if (!AI.goTo(W, n, MAP.EXIT.x, MAP.EXIT.y, qgOverride)) { n.x = MAP.EXIT.x + .5; n.y = MAP.EXIT.y + .5; } }
      n.run = true;
      if (AI.stepMove(W, n, qgOverride) || Math.hypot(n.x - MAP.EXIT.x, n.y - MAP.EXIT.y) < 1.5) { n.away = true; n.travel = null; n.run = false; n.path = null; n.hidden = true; }
      return true;
    }
    if (tv.to === 'home') {
      if (!n.path) { if (!AI.goTo(W, n, MAP.GATE_IN.x, MAP.GATE_IN.y, qgOverride)) { n.x = MAP.GATE_IN.x + .5; n.y = MAP.GATE_IN.y + .5; } }
      if (AI.stepMove(W, n, qgOverride) || Math.hypot(n.x - MAP.GATE_IN.x, n.y - MAP.GATE_IN.y) < 1.5) { n.travel = null; n.path = null; n.run = false; n.act = { id: 'idle', stage: 'do', left: 0, total: 0, ctx: {}, why: [] }; }
      return true;
    }
    return false;
  };

  /* ---------- ตรวจครบกำหนดกลับ + คำนวณผล ---------- */
  X.hourly = W => {
    const w = W.world;
    w.expeds.forEach(ex => {
      if (ex.done) return;
      const members = ex.party.map(i => W.byId[i]).filter(m => m && !m.dead && m.expId === ex.id && !m.fled);
      if (!members.length) { ex.done = true; return; }
      if (ex.state === 'leaving' && members.every(m => m.away)) {
        ex.state = 'away';
        startJourney(ex, W.t);
      }
      if (ex.route && ex.state === 'away' && ex.startedAt == null) startJourney(ex,ex.t0);
      if (ex.route && ex.state === 'away' && W.t >= ex.arriveAt && !ex.arrivalRecorded) {
        ex.arrivalRecorded = true;
        if (ex.kind === 'city_visit') visitCity(W,ex,members);
      }
      if (ex.state !== 'away' || W.t < ex.ret) return;
      const prior = W._expeditionLocation;
      if (ex.route) W._expeditionLocation = routePlace(ex.route);
      try {
        if (ex.kind === 'city_visit' || ex.returnStartedAt != null) {
          finishJourney(W, ex, members);
        } else if (['sect_siege','resource_claim','world_anomaly'].includes(ex.kind)) {
          if (ex.kind === 'sect_siege') X.resolveSectSiege(W, ex, { members });
          else if (ex.kind === 'resource_claim') X.resolveResourceClaim(W, ex, members);
          else X.resolveWorldAnomaly(W, ex.anomalyId || ex, members, { ex });
          const returning = members.filter(m => !m.dead && !m.exiled && !m.fled && m.expId == null);
          if (ex.route && ex.done && returning.length) {
            ex.done = false;
            ex.returnStartedAt = W.t; ex.ret = W.t + ex.travelMinutes;
            for (const m of returning) { m.expId = ex.id; m.away = true; m.hidden = true; m.travel = null; }
          }
        } else X.resolve(W, ex, members);
      } finally {
        if (prior === undefined) delete W._expeditionLocation;
        else W._expeditionLocation = prior;
      }
    });
    w.expeds = w.expeds.filter(e => !e.done || W.t - e.ret < 7 * 1440);
  };

  X.resolve = (W, ex, members) => {
    if (ex.done || ex.settlement || !members.length) return;
    const rng = W.rng; const reg = X.REGIONS.find(r => r.id === ex.region);
    const P = members.reduce((s, m) => s + CULT.power(m), 0);
    const perceive = Math.max(...members.map(m => E(m, 'intellect.perceptiveness'))), surv = Math.max(...members.map(m => m.h.skills.survival || 0)), luck = members.reduce((s, m) => s + E(m, 'destiny.luck'), 0) / members.length;
    const workDays = ex.route ? reg.days || 3 : ex.days;
    const nEnc = Math.max(2, Math.round(workDays * 0.7)); const out = { items: [], stones: 0, mats: {}, pills: {}, gear: [], techs: [], notes: [], rep: 0, newDisciples: 0 };
    const alive = members.slice(); let totalDmg = 0;
    const dangerMult = 0.6 + reg.danger * 0.35;
    for (let i = 0; i < nEnc && alive.length; i++) {
      const roll = rng.next();
      const wBeast = ex.kind === 'hunt' ? 0.7 : ex.kind === 'bounty' ? 0.5 : 0.3 * dangerMult, wFind = ex.kind === 'gather' ? 0.55 : ex.kind === 'fortune' ? 0.35 : 0.2, wFort = ex.kind === 'fortune' ? 0.3 : 0.05 + (luck - 40) / 800;
      const tot = wBeast + wFind + wFort + 0.2; const r = roll * tot;
      if (r < wBeast) {
        const pwAll = alive.reduce((s, m) => s + CULT.power(m), 0) * (0.85 + rng.next() * 0.3);
        const bold = alive.reduce((s, m) => s + E(m, 'personality.courage'), 0) / alive.length;
        let pool = X.beastPool(reg);
        if (ex.kind === 'hunt' || ex.kind === 'bounty') pool = pool.filter(b => b.cp <= pwAll * (0.6 + bold / 100 * 0.7));
        else pool = pool.filter(b => b.cp <= pwAll * 3);
        if (!pool.length) { ex.journal.push('เห็นร่องรอยสัตว์อสูรใหญ่เกินกำลัง จึงหลีกเลี่ยง'); continue; }
        const b = rng.pick(pool);
        const pw = pwAll;
        const bp = b.cp * (0.8 + rng.next() * 0.5);
        const p = pw / (pw + bp);
        const fled = ex.kind !== 'hunt' && p < 0.5 && rng.chance(0.5 + surv / 200);
        if (fled) { ex.journal.push('พบ' + b.nameTh + ' แต่หลบหนีได้'); continue; }
        const win = rng.next() < clamp((p - 0.25) * 1.6, 0.04, 0.97);
        if (win) {
          ex.journal.push('สังหาร' + b.nameTh + ' ได้');
          if (reg.sourcePack) { g.CONTENT.gather(W, ex, alive, out, reg, 'hunt', b); } else {
            const d = rng.pick(b.drops); out.mats[d] = (out.mats[d] || 0) + Math.round((1 + (rng.chance(0.4) ? 1 : 0)) * Math.max(...alive.map(n => g.MARTIAL.lifeMult(n, 'hunting'))));
            if (rng.chance(0.5)) { const d2 = rng.pick(b.drops); out.mats[d2] = (out.mats[d2] || 0) + 1; }
          }
          if (ECO.rollProceduralGear && rng.chance(0.14 + reg.danger * 0.03)) {
            const pGear = ECO.rollProceduralGear(W, { maxTier: clamp(reg.danger + 1, 1, 4), source: 'expedition_hunt' });
            pGear.personalLoot = true;
            out.gear.push(pGear);
            ex.journal.push('ได้ศาสตราสุ่ม「' + pGear.nameTh + '」จากซากศึก');
          }
          if (rng.chance(0.12 + reg.danger * 0.02)) {
            const stTier = clamp(1 + Math.floor(rng.next() * Math.min(4, reg.danger + 1)), 1, 4);
            const stId = 'ITEM_REPAIR_STONE_' + stTier;
            out.mats[stId] = (out.mats[stId] || 0) + 1;
          }
          alive.forEach(m => {
            if (m.equip && ECO.wearGear) {
              for (const sl of ['WEAPON', 'ARMOR', 'ACCESSORY']) {
                if (m.equip[sl] && m.equip[sl].procedural) ECO.wearGear(m.equip[sl], 0.35, W, m);
              }
            }
          });
          const dmgFrac = clamp((1 - p) * 0.55 + rng.next() * 0.1, 0.02, 0.6);
          const v = rng.pick(alive); const dm = CULT.hpMax(v) * dmgFrac; v.h.state.hp = Math.max(1, v.h.state.hp - dm); totalDmg += dmgFrac;
          if (dmgFrac > 0.25) AI.injure(W, v, dmgFrac > 0.45 ? 2 : 1, 'ถูก' + b.nameTh + 'ทำร้าย');
          alive.forEach(m => { HC.experience(m, 'duel_win', 0.2); m.stats = m.stats || {}; m.stats.kills = (m.stats.kills || 0) + (m === v ? 1 : 0); });
        } else {
          const v = rng.pick(alive); const dead = rng.chance(clamp((bp / (pw + bp) - 0.5) * 0.7, 0.01, 0.4) * (1 - E(v, 'destiny.luck') / 300) * (1 - surv / 250));
          ex.journal.push('พ่ายต่อ' + b.nameTh);
          if (dead) { out.notes.push(v.h.name.given + ' เสียชีวิตจากการต่อสู้กับ' + b.nameTh); AI.kill(W, v, 'ถูก' + b.nameTh + 'สังหารระหว่างภารกิจ'); alive.splice(alive.indexOf(v), 1); }
          else { AI.injure(W, v, 2, 'ถูก' + b.nameTh + 'ทำร้ายสาหัส'); v.h.state.hp = Math.max(1, CULT.hpMax(v) * 0.15); }
        }
      } else if (r < wBeast + wFind) {
        if (reg.sourcePack) { g.CONTENT.gather(W, ex, alive, out, reg, 'gather'); continue; }
        const mats = JD.ITEMS.materials.filter(m => !m.sourcePack && (m.terrain === reg.terrain || (reg.terrain === 'plains' && m.terrain === 'forest')) && (m.category === 'HERB' || m.category === 'ORE') && m.tier <= Math.max(1, reg.danger + 1));
        if (!mats.length) continue;
        const m = rng.weighted(mats, x => 1 / (x.tier * x.tier));
        const q = 1 + Math.floor((perceive - 40) / 40 + Math.max(...alive.map(a => a.h.skills.herbalism || 0)) / 60 + rng.next());
        out.mats[m.id] = (out.mats[m.id] || 0) + Math.max(1, Math.round(q * Math.max(...alive.map(n => g.MARTIAL.lifeMult(n, m.category === 'ORE' ? 'mining' : 'herbalism'))))); ex.journal.push('พบ' + m.nameTh);
        alive.forEach(a => (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(a, m.category === 'HERB' ? 'herbalism' : 'mining', 0.4, 1));
      } else if (r < wBeast + wFind + wFort) {
        X.fortuneEvent(W, ex, alive, out, reg);
      } else {
        const ev = rng.pick(['storm', 'lost', 'traveler', 'bandits']);
        if (ev === 'storm') { ex.journal.push('เจอพายุ ต้องหลบอยู่หลายวัน'); alive.forEach(a => HC.feel(a, { stress: 4, energy: -10 })); }
        else if (ev === 'lost') { ex.journal.push('หลงทางในป่า'); if (!ex.route) ex.ret += rng.int(60,600); }
        else if (ev === 'traveler') { const encRes = X.resolveDiscipleSectEncounter(W, alive, null, { quiet: true }); if (encRes && encRes.ok) { ex.journal.push(encRes.summaryTh); out.stones += (encRes.stonesLoot || 0); out.rep += encRes.didClash ? (encRes.won ? 0.5 : -0.1) : 0.25; } else { ex.journal.push('พบนักเดินทางร่วมทาง แลกเปลี่ยนเรื่องราว'); } alive.forEach(a => { HC.feel(a, { mood: 4, novelty: 8 }); (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(a, 'diplomacy', 0.5, 1); }); }
        else {
          const bp = (30 + reg.danger * 70) * (0.6 + rng.next()), pw = alive.reduce((s, m) => s + CULT.power(m), 0);
          if (pw > bp * 1.2 || rng.chance(clamp(pw / (pw + bp), 0.1, 0.9))) { ex.journal.push('ปราบโจรป่า'); const loot = Math.round(15 + rng.next() * 40 * reg.danger); out.stones += loot; HC.experience(rng.pick(alive), 'duel_win', 0.3); }
          else { const loss = Math.min(W.sect.stones * 0.02 + 20, 80); out.stones -= Math.round(loss); ex.journal.push('ถูกโจรปล้น'); const v = rng.pick(alive); AI.injure(W, v, 1, 'ถูกโจรทำร้าย'); }
        }
      }
    }
    if (ex.kind === 'trade') X.tradeResult(W, ex, alive, out);
    if (ex.kind === 'diplomacy') X.diplomacyResult(W, ex, alive, out);
    if (ex.kind === 'recruit') X.recruitResult(W, ex, alive, out);
    if (ex.kind === 'bounty') { const fee = Math.round((60 + P * 0.05) * (0.8 + rng.next() * 0.5) * (1 + (E(alive[0] || members[0], 'aptitudes.socialCommerce') - 50) / 200)); out.stones += fee; ex.journal.push('รับค่าจ้างคุ้มกัน ' + fee + ' ศิลา'); }
    g.CONTENT.complete(W, ex, alive, out, reg);
    ex.done = true; ex.out = out;
    if (alive.length > 1 && reg && reg.danger >= 2) {
      for (let i = 0; i < alive.length; i++) {
        for (let j = i + 1; j < alive.length; j++) {
          const a = alive[i], b = alive[j];
          const ra = SECT.rel(a, b.id), rb = SECT.rel(b, a.id);
          ra.t = clamp((ra.t ?? 40) + 2.5, 0, 100); rb.t = clamp((rb.t ?? 40) + 2.5, 0, 100);
          ra.r = clamp((ra.r ?? 30) + 2, 0, 100); rb.r = clamp((rb.r ?? 30) + 2, 0, 100);
          ra.a = clamp((ra.a || 0) + 1.5, -100, 100); rb.a = clamp((rb.a || 0) + 1.5, -100, 100);
          if (g.COG && g.COG.remember) {
            g.COG.remember(W, a, { kind: 'shared_danger', subjectId: b.id, severity: 0.5 });
            g.COG.remember(W, b, { kind: 'shared_danger', subjectId: a.id, severity: 0.5 });
          }
        }
      }
    }
    try {
      if (alive.length) X.handover(W, ex, alive, out);
    } finally {
      alive.forEach(m => { m.away = false; m.hidden = false; m.x = MAP.EXIT.x + .5 + rng.gauss(0, 0.8); m.y = MAP.EXIT.y + .5; m.travel = { to: 'home', mountUid: tripMountUid(ex,m) }; m.expId = null; m.path = null; m.run = false; m.h.state.satiety = Math.max(30, m.h.state.satiety); HC.experience(m, 'adventure', 0.6); m.merit += 8 + reg.danger * 3; AI.mem(W, m, 'กลับจากภารกิจ「' + X.MISSIONS[ex.kind].nameTh + '」 ณ ' + reg.nameTh + ' ' + (ex.journal.slice(-2).join(', ') || ''), 0.8); });
    }
    const ppl = members.map(m => m.h.name.given).join('、');
    const brief = ex.kind === 'fortune' && out.notes.length ? out.notes.slice(0, 2).join(' / ') : Object.keys(out.mats).length || out.stones || out.gear.length ? ('ได้ ' + X.summarize(out)) : (ex.journal.slice(-1)[0] || 'ไม่ได้อะไรมากนัก');
    W.log('mission', ppl + ' กลับจากภารกิจ「' + X.MISSIONS[ex.kind].nameTh + '」 — ' + brief,
      members.map(m => m.id), {location:routePlace(ex.route)});
    W.fame(out.rep);
  };
  X.summarize = o => {
    const parts = []; const mk = Object.keys(o.mats); let tot = 0; mk.forEach(k => tot += o.mats[k]); if (tot) parts.push('วัตถุดิบ ' + tot + ' ชิ้น'); if (o.organs) { const ok = Object.keys(o.organs); let otot = 0; ok.forEach(k => otot += o.organs[k]); if (otot) parts.push('อวัยวะพิเศษ ' + otot + ' ชิ้น'); }
    if (o.stones) parts.push((o.stones > 0 ? '+' : '') + o.stones + ' ศิลา'); if (o.gear.length) parts.push(o.gear.map(g2 => g2.nameTh).join(',')); if (o.techs.length) parts.push('คัมภีร์วิชา'); const pk = Object.keys(o.pills); if (pk.length) parts.push('โอสถ ' + pk.reduce((s, k) => s + o.pills[k], 0) + ' เม็ด');
    return parts.join(', ');
  };
  X.fortuneEvent = (W, ex, alive, out, reg) => {
    const rng = W.rng;
    const rank = ex.partyRank || (alive.length ? Math.max(1, ...alive.map(n => CULT.worldRank ? CULT.worldRank(n) : 1)) : 1);
    const sites = X.FORTUNE_REGISTRY && X.FORTUNE_REGISTRY[rank];
    let site = sites && (sites.find(s => s.id === ex.siteId) || sites.find(s => s.biome === reg.terrain) || sites[0]);
    let pool = site && (site.pools.find(p => p.id === ex.poolId) || rng.pick(site.pools));
    if (site && pool) {
      ex.siteId = site.id;
      ex.poolId = pool.id;
      const lead = alive[0];
      const skillName = pool.skill;
      let skillVal = 0;
      if (skillName) {
        skillVal = Math.max(...alive.map(a => {
          const s = (a.h.skills && a.h.skills[skillName]) || (skillName === 'SCRIPTURE' ? (a.h.skills.SCRIPTURE || 0) : (skillName === 'ALCHEMY' ? (a.h.skills.ALCHEMY || 0) : 0)) || 0;
          let attr = 50;
          if (skillName === 'herbalism') attr = E(a, 'interests.herbs');
          else if (skillName === 'mining') attr = E(a, 'interests.labor');
          else if (skillName === 'survival') attr = E(a, 'physiology.endurance');
          else if (skillName === 'SCRIPTURE') attr = E(a, 'intellect.comprehension');
          else if (skillName === 'perceptiveness') attr = E(a, 'intellect.perceptiveness');
          else if (skillName === 'willpower') attr = E(a, 'intellect.willpower');
          else if (skillName === 'courage') attr = E(a, 'personality.courage');
          else if (skillName === 'alchemy' || skillName === 'ALCHEMY') attr = E(a, 'interests.alchemy') || E(a, 'aptitudes.crafting') || 50;
          else if (skillName === 'diplomacy') attr = E(a, 'social.charisma');

          const stageBonus = a.cult ? (a.cult.stage || 1) * 3.5 : 0;
          return (s * 0.75) + (attr * 0.25) + stageBonus;
        }));
      }
      const luck = alive.reduce((s, a) => s + E(a, 'destiny.luck'), 0) / alive.length;
      const roll = skillVal + (luck - 50) * 0.2 + rng.gauss(0, 8);
      const passed = roll >= pool.diff;
      if (passed) {
        ex.journal.push('ผ่านอุปสรรค ณ「' + site.nameTh + ' · ' + pool.nameTh + '」สำเร็จ');
        out.notes.push(lead.h.name.given + ' ผ่านบททดสอบ「' + pool.nameTh + '」');
        if (pool.herbs) {
          pool.herbs.forEach(hId => {
            const count = 1 + rng.int(1, 2);
            out.mats[hId] = (out.mats[hId] || 0) + count;
            ex.journal.push('เก็บสมุนไพรล้ำค่า「' + ECO.name(hId) + '」×' + count);
          });
        }
        if (pool.ore) {
          pool.ore.forEach(oId => {
            const count = 1 + rng.int(1, 2);
            out.mats[oId] = (out.mats[oId] || 0) + count;
            ex.journal.push('ขุดพบแร่วิญญาณ「' + ECO.name(oId) + '」×' + count);
          });
        }
        if (pool.beastParts && pool.beastParts.length) {
          const pickedParts = pool.beastParts.slice(0, 2);
          pickedParts.forEach(bpId => {
            const count = 1 + rng.int(0, 1);
            out.mats[bpId] = (out.mats[bpId] || 0) + count;
            ex.journal.push('ได้ชิ้นส่วนอสูรล้ำค่า「' + ECO.name(bpId) + '」×' + count);
          });
        }
        if (pool.recipeIds && pool.recipeIds.length) {
          W.sect.knownRecipes = W.sect.knownRecipes || [];
          out.recipes = out.recipes || [];
          const rId = rng.pick(pool.recipeIds);
          if (!W.sect.knownRecipes.includes(rId) && !out.recipes.includes(rId)) out.recipes.push(rId);
          const rObj = ECO.recipeById && ECO.recipeById[rId];
          ex.journal.push('ค้นพบม้วนตำรับ「' + (rObj ? rObj.nameTh : rId) + '」');
        }
        if (pool.techIds && pool.techIds.length) {
          W.sect.library = W.sect.library || [];
          const tId = rng.pick(pool.techIds);
          if (!W.sect.library.includes(tId)) W.sect.library.push(tId);
          if (!out.techs.includes(tId)) out.techs.push(tId);
          const tObj = CULT.tech ? CULT.tech(tId) : null;
          ex.journal.push('ค้นพบคัมภีร์วิชา「' + (tObj ? tObj.nameTh : tId) + '」');
          out.notes.push('ได้คัมภีร์「' + (tObj ? tObj.nameTh : tId) + '」จาก' + site.nameTh);
        }
        if (pool.gearIds && pool.gearIds.length) {
          const gId = rng.pick(pool.gearIds);
          const rObj = (ECO.recipeByOutItemId && ECO.recipeByOutItemId[gId]) || (ECO.itemById && ECO.itemById[gId] && ECO.recipeById && ECO.recipeById[ECO.itemById[gId].recipeId]);
          if (rObj && ECO.mintGear) {
            const minted = ECO.mintGear(W, rObj, 1.2);
            out.gear.push(minted);
            ex.journal.push('ค้นพบศาสตราโบราณ「' + minted.nameTh + '」');
          }
        }
        if (pool.stones) {
          const lootStones = Math.round(pool.stones * (0.8 + rng.next() * 0.4));
          out.stones += lootStones;
          ex.journal.push('พบศิลาวิญญาณ ' + lootStones + ' ก้อน');
        }
        if (pool.pill) {
          out.pills[pool.pill] = (out.pills[pool.pill] || 0) + 1 + rng.int(0, 1);
          ex.journal.push('ค้นพบโอสถ「' + ECO.name(pool.pill) + '」');
        }
        if (pool.techTier && g.MARTIAL && g.MARTIAL.discover) {
          const drop = g.MARTIAL.discover(W, out, { tier: pool.techTier, rank: site.rank || rank, danger: reg.danger, source: 'expedition' });
          if (drop) {
            ex.journal.push('พบองค์ความรู้หายากขั้น ' + pool.techTier);
            out.notes.push('พบองค์ความรู้หายากใน' + site.nameTh);
          }
        }
        if (pool.gearTier) {
          const rs = ECO.recipesFor(W, ['FORGING']).filter(r => r.outType === 'EQUIPMENT' && r.tier <= pool.gearTier + 1);
          if (rs.length) {
            const r = rng.pick(rs);
            const gear = ECO.mintGear(W, r, 1.1 + rng.next() * 0.3);
            gear.nameTh = (gear.nameTh || 'ศาสตรา') + ' (วาสนาแดนลึก)';
            gear.q = 1.25;
            out.gear.push(gear);
            ex.journal.push('ขุดพบ' + gear.nameTh);
          }
        }
        if (pool.spring) {
          const v = rng.pick(alive);
          if (v && v.cult) CULT.gain(v, CULT.threshold(v) * 0.15);
          v.h.state.hp = CULT.hpMax(v);
          HC.experience(v, 'insight', 0.8);
          ex.journal.push(v.h.name.given + ' ชำระกายที่ตาน้ำปราณ ตบะรุดหน้า');
        }
        if (pool.insight) {
          const v = rng.pick(alive);
          if (v && v.cult) CULT.gain(v, CULT.threshold(v) * 0.1);
          if (skillName) (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(v, skillName, 4, 1.5);
          HC.experience(v, 'insight', 0.7);
        }
      } else {
        ex.journal.push('เผชิญอุปสรรค ณ「' + site.nameTh + ' · ' + pool.nameTh + '」แต่ทักษะยังไม่เพียงพอ');
        const victim = rng.pick(alive);
        HC.feel(victim, { stress: 8, mood: -4 });
        if (rng.chance(0.35)) {
          AI.injure(W, victim, 1, 'บาดเจ็บจากอุปสรรควาสนา (' + pool.nameTh + ')');
          ex.journal.push(victim.h.name.given + ' บาดเจ็บเล็กน้อยจากกับดัก/ไอพิษ');
        }
      }
      out.rep += 0.4;
      return;
    }
    if (g.CONTENT.fortune(W, ex, alive, out, reg)) return;
    const v = rng.weighted(alive, a => 1 + E(a, 'destiny.luck') / 40 + E(a, 'intellect.perceptiveness') / 80);
    const luck = E(v, 'destiny.luck'); const kind = rng.weighted([
      { k: 'herb', w: 3 }, { k: 'pill', w: 1.5 + luck / 60 }, { k: 'gear', w: 1.0 + luck / 80 + reg.danger * 0.2 }, { k: 'scroll', w: 0.8 + E(v, 'intellect.comprehension') / 120 + reg.danger * 0.2 },
      { k: 'master', w: 0.4 + luck / 120 }, { k: 'spring', w: 0.8 + luck / 150 }, { k: 'curse', w: 0.6 + (50 - luck) / 100 }
    ], x => Math.max(0.05, x.w)).k;
    if (kind === 'herb') { const hs = JD.ITEMS.materials.filter(m => !m.sourcePack && m.category === 'HERB' && m.tier <= reg.danger + 2); const m = rng.pick(hs); const n = 1 + rng.int(0, 2); out.mats[m.id] = (out.mats[m.id] || 0) + n; ex.journal.push('พบสมุนไพรหายาก「' + m.nameTh + '」'); out.notes.push(v.h.name.given + ' พบ' + m.nameTh); }
    else if (kind === 'pill') { const ps = Object.keys(W.sect.stock).length ? ECO.recipesFor(W, ['ALCHEMY']).filter(r => r.outType === 'PILL' && r.tier <= reg.danger + 1) : []; if (ps.length) { const r = rng.pick(ps); const key = r.outItemId || 'P:' + r.id; out.pills[key] = (out.pills[key] || 0) + 1 + rng.int(0, 1); ex.journal.push('พบโอสถในซากโบราณ'); out.notes.push(v.h.name.given + ' พบ' + (r.outNameTh)); } }
    else if (kind === 'gear') {
      if (ECO.rollProceduralGear && rng.chance(0.65)) {
        const gear = ECO.rollProceduralGear(W, { maxTier: clamp(reg.danger + 1, 1, 4), source: 'expedition_fortune' });
        out.gear.push(gear); ex.journal.push('ขุดพบ' + gear.nameTh); out.notes.push(v.h.name.given + ' ขุดพบ' + gear.nameTh);
      } else {
        const rs = ECO.recipesFor(W, ['FORGING']).filter(r => r.outType === 'EQUIPMENT' && r.tier <= reg.danger + 2);
        if (rs.length) { const r = rng.pick(rs); const gear = ECO.mintGear(W, r, 1.1 + rng.next() * 0.3); gear.nameTh = (gear.nameTh || 'ศาสตรา') + ' (ของโบราณ)'; gear.q = 1.2; out.gear.push(gear); ex.journal.push('ขุดพบ' + gear.nameTh); out.notes.push(v.h.name.given + ' ขุดพบ' + gear.nameTh); }
      }
    }
    else if (kind === 'scroll') { const drop = g.MARTIAL.discover(W, out, { tier: Math.max(2, reg.danger + 2), rank, danger: reg.danger, source: 'expedition' }); if (drop) { ex.journal.push('พบองค์ความรู้หายาก'); out.notes.push(v.h.name.given + ' พบองค์ความรู้หายาก'); } }
    else if (kind === 'master') { const sk = AI.pickTeachSkill(v, v); (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(v, sk, 6, 2.2); if (v.cult) CULT.gain(v, CULT.threshold(v) * 0.08); HC.experience(v, 'insight', 0.9); ex.journal.push('พบผู้เฒ่าลึกลับชี้แนะ'); out.notes.push(v.h.name.given + ' ได้รับการชี้แนะจากผู้เฒ่าลึกลับ'); }
    else if (kind === 'spring') { if (v.cult) { CULT.gain(v, CULT.threshold(v) * 0.15); } v.h.state.hp = CULT.hpMax(v); HC.trainBody(v, 'vitality', 2); HC.trainBody(v, 'endurance', 2); HC.experience(v, 'insight', 0.5); ex.journal.push('พบสระปราณธรรมชาติ'); out.notes.push(v.h.name.given + ' พบสระปราณลับ ตบะก้าวหน้า'); }
    else { HC.feel(v, { stress: 10, mood: -6 }); v.h.state.heartDemon = clamp(v.h.state.heartDemon + 7, 0, 100); if (rng.chance(0.3)) AI.injure(W, v, 1, 'ถูกคำสาปโบราณ'); ex.journal.push('ต้องคำสาปโบราณ'); out.notes.push(v.h.name.given + ' ต้องคำสาปโบราณ'); }
    out.rep += 0.3;
  };
  X.tradeResult = (W, ex, alive, out) => {
    const best = Math.max(...alive.map(a => E(a, 'aptitudes.socialCommerce') + E(a, 'intellect.numeracy') + (a.h.skills.trading || 0)), 40) / 3;
    let sum = 0; (ex.carry || []).forEach(c => { const pr = ECO.price(W, c.id) * 0.85 * (0.85 + best / 200); sum += Math.round(pr * c.n); });
    if (sum) { out.stones += sum; ex.journal.push('ขายสินค้าได้ ' + sum + ' ศิลา'); }
    const buy = (W.sect.buyList || []).slice(0, 5); let spent = 0;
    buy.forEach(b => { const pr = Math.round(ECO.price(W, b.id) * 1.05 * (1.15 - best / 400)); const cost = pr * b.n; if (W.sect.stones + out.stones - spent >= cost + 100) { spent += cost; out.mats[b.id] = (out.mats[b.id] || 0) + b.n; } });
    if (spent) { out.stones -= spent; ex.journal.push('ซื้อเสบียง/วัตถุดิบใช้ ' + spent + ' ศิลา'); }
    alive.forEach(a => (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(a, 'trading', 1.2, 1));
    out.rep += 0.1;
  };
  // Only an envoy actually participating can contribute; never stack per member.
  X.envoyBonus = party => Math.min(2, (party || []).reduce((best, n) => {
    if (!n || n.dead || !n.cult || n.cult.path !== 'STRATEGY_GOVERNANCE' || n.cult.sub !== 'DIPLOMATIC_ENVOY') return best;
    const sk = g.MARTIAL ? g.MARTIAL.skillRead(n, 'diplomacy') : 0;
    return Math.max(best, Math.max(0, sk) / 50);
  }, 0));
  X.diplomacyResult = (W, ex, alive, out) => {
    const s = W.rng.weighted(W.world.sects, x => 1 + Math.max(0, 50 - x.attitude) / 50); const lead = alive[0]; if (!lead) return;
    ex.lifeHostileRelation=s.attitude;
    const skill = alive.reduce((m, a) => Math.max(m, E(a, 'social.charisma') * .5 + E(a, 'personality.empathy') * .3 + (a.h.skills.diplomacy || 0) * .4), 0);
    const delta = Math.round((skill - 45) / 4 + W.rng.gauss(0, 4) - (s.style === 'ทะนง' ? 3 : 0) + (W.sect.policy.openness - 50) / 15 + X.envoyBonus(alive));
    s.attitude = clamp(s.attitude + delta, -100, 100); s.contact = W.day;
    ex.journal.push('เยือน' + s.nameTh + ' ท่าทีเปลี่ยน ' + (delta >= 0 ? '+' : '') + delta);
    if (delta > 6 && W.rng.chance(.4)) { const drop = g.MARTIAL.discover(W, out, { tier: 3, source: 'diplomacy' }); if (drop) out.notes.push('แลกเปลี่ยนองค์ความรู้กับ' + s.nameTh); }
    if (delta > 8) { const gift = Math.round(30 + W.rng.next() * 60); out.stones += gift; } out.rep += Math.max(0, delta) * 0.05 + 0.2;
    alive.forEach(a => (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(a, 'diplomacy', 1.5, 1.2));
  };
  X.recruitResult = (W, ex, alive, out) => {
    const lead = alive[0]; if (!lead) return;
    const eye = alive.reduce((m, a) => Math.max(m, E(a, 'intellect.judgement') * .5 + E(a, 'intellect.perceptiveness') * .3 + (E(a, 'social.teaching') * .5 + E(a, 'interests.teaching') * .5) * .2), 0);
    const n = W.rng.chance(0.55 + (W.sect.policy.openness - 50) / 200 + W.sect.fame / 600) ? (W.rng.chance(0.25 + eye / 400) ? 2 : 1) : 0;
    for (let i = 0; i < n; i++) {
      const occ = SECT.memberOccupancy ? SECT.memberOccupancy(W) : W.npcs.filter(x => !x.dead && !x.exiled).length;
      const cap = SECT.housingCapacity ? SECT.housingCapacity(W) : 46;
      if (occ >= cap) {
        ex.journal.push('พบผู้สนใจเข้าสำนัก แต่ที่พักในสำนักเต็ม (' + occ + '/' + cap + ') จึงต้องชะลอการรับ');
        break;
      }
      const nn = W.makeNpc({ ageYears: W.rng.int(14, 26), rank: 0, fromExped: true, useTalentTier: true });
      nn.x = MAP.EXIT.x + .5 + i; nn.y = MAP.EXIT.y + .5; nn.travel = { to: 'home' };
      if (SECT.MENTORSHIP && SECT.MENTORSHIP.linkMasterDisciple) SECT.MENTORSHIP.linkMasterDisciple(W, lead, nn);
      else { nn.mentor = lead.id; nn.mentorId = lead.id; (lead.h.life.family.disciples = lead.h.life.family.disciples || []).push(nn.id); nn.h.life.family.master = lead.id; }
      out.newDisciples++;
      const r = SECT.rel(nn, lead.id); r.a = 25; r.t = 55; r.r = 55; r.bond = 'อาจารย์';
      const r2 = SECT.rel(lead, nn.id); r2.a = 12; r2.bond = 'ศิษย์';
      ex.journal.push('พาผู้สมัครชื่อ ' + nn.h.name.given + ' กลับสำนัก');
      W.log('recruit', lead.h.name.given + ' พา ' + nn.h.name.given + ' เข้าสำนักเป็นศิษย์ (' + nn.h.origin.cls + ' จาก' + nn.h.origin.region + ')', [lead.id, nn.id]);
    }
    if (!n) ex.journal.push('ตามหาศิษย์ใหม่ แต่ยังไม่พบผู้เหมาะสม');
    out.rep += out.newDisciples * 0.4;
  };
  X.cargoUnits = out => {
    if (!out) return 0;
    let total = (Array.isArray(out.gear) ? out.gear.length * 3 : 0) + (Array.isArray(out.items) ? out.items.length : 0);
    for (const k of Object.keys(out.mats || {})) total += Math.max(0, Math.floor(out.mats[k] || 0));
    for (const k of Object.keys(out.pills || {})) total += Math.max(0, Math.floor(out.pills[k] || 0));
    return total;
  };
  X.applyCarryCapacity = (ex, out) => {
    if (!ex || !out || !Number.isFinite(ex.carryCapacity) || ex.carryCapacity <= 0) return { used: X.cargoUnits(out), overflow: 0 };
    let remaining = Math.floor(ex.carryCapacity), overflow = 0;
    const gear = Array.isArray(out.gear) ? out.gear : [];
    const keptGear = [];
    for (const item of gear) { if (remaining >= 3) { keptGear.push(item); remaining -= 3; } else overflow += 3; }
    out.gear = keptGear;
    for (const field of ['pills', 'items', 'mats']) {
      if (field === 'items') {
        const items = Array.isArray(out.items) ? out.items : [], kept = items.slice(0, remaining);
        overflow += items.length - kept.length; remaining -= kept.length; out.items = kept;
        continue;
      }
      const bag = out[field] || {};
      const ids = Object.keys(bag).sort((a,b) => (ECO.base(b) || 0) - (ECO.base(a) || 0));
      for (const id of ids) {
        const want = Math.max(0, Math.floor(bag[id] || 0)), keep = Math.min(want, remaining);
        if (keep > 0) bag[id] = keep; else delete bag[id];
        remaining -= keep; overflow += want - keep;
      }
      out[field] = bag;
    }
    const used = Math.min(Math.floor(ex.carryCapacity), X.cargoUnits(out));
    ex.cargoUsed = used; ex.cargoOverflow = (ex.cargoOverflow || 0) + overflow;
    return { used, overflow };
  };
  X.handover = (W, ex, alive, out) => {
    const rng = W.rng;
    if (!alive || !alive.length) return { mats: {}, pills: {}, gear: [], techs: [], stones: 0, stockBefore: {}, techsAccepted: true };
    if (ex && Number.isFinite(ex.carryCapacity)) X.applyCarryCapacity(ex, out);
    const greed = alive.reduce((s, a) => s + clamp((E(a, 'values.wealthResource') + (100 - E(a, 'personality.integrity')) + (100 - E(a, 'personality.loyalty'))) / 3 - 35, 0, 60), 0) / alive.length;
    const keepFrac = clamp(greed / 160 + (W.sect.policy.generosity < 35 ? 0.04 : 0) - (W.sect.policy.generosity > 65 ? 0.03 : 0), 0, 0.4) * (W.sect.policy.strictness > 70 ? 0.5 : 1);
    const donation = out.donation = { mats: {}, pills: {}, gear: [], techs: [], stones: 0, stockBefore: {}, techsAccepted: true };
    const hoarder = () => rng.weighted(alive, a => 1 + clamp((E(a, 'values.wealthResource') + (100 - E(a, 'personality.integrity')) + (100 - E(a, 'personality.loyalty'))) / 3 - 25, 0, 75) / 30);
    Object.keys(out.mats || {}).forEach(k => {
      const n = out.mats[k] || 0, keep = rng.chance(keepFrac) ? Math.floor(n * 0.5) : 0, donated = n - keep;
      donation.stockBefore[k] = ECO.count(W, k);
      if (donated > 0) { ECO.add(W, k, donated); donation.mats[k] = donated; }
      if (keep > 0) {
        const owner = hoarder(); owner.inv.mats = owner.inv.mats || {}; owner.inv.mats[k] = (owner.inv.mats[k] || 0) + keep;
        owner.h.state.stress += keep > 3 ? 1 : 0.2;
        if (keep > 2) W.sect.suspicion = (W.sect.suspicion || 0) + 1;
      }
    });
    Object.keys(out.pills || {}).forEach(k => {
      donation.stockBefore[k] = ECO.count(W, k); ECO.add(W, k, out.pills[k]); donation.pills[k] = out.pills[k];
    });
    (out.gear || []).forEach(gr => {
      if (!gr) return;
      if (!gr.uid && ECO.nextGearUid) gr.uid = ECO.nextGearUid(W, gr.id);
      const owner = gr.personalLoot ? hoarder() : null;
      if (owner && gr.personalLoot && rng.chance(clamp(keepFrac + 0.35, 0.25, 0.75))) {
        owner.inv = owner.inv || {};
        owner.inv.gear = owner.inv.gear || [];
        owner.inv.gear.push(gr);
        if (g.CPE && g.CPE.evaluatePersonalBagGear) g.CPE.evaluatePersonalBagGear(W, owner);
      } else {
        gr.listedAtDay = W.day;
        gr.listedTick = W.t;
        gr.donatedRewarded = true;
        W.sect.gear.push(gr);
        donation.gear.push(gr);
      }
    });
    (out.techs || []).forEach(id => {
      if (W.sect.library.includes(id)) return;
      const owner = hoarder(), honesty = E(owner, 'personality.integrity'), loyalty = E(owner, 'personality.loyalty');
      const techKeep = clamp(keepFrac + (100 - honesty) / 360 + (100 - loyalty) / 520, 0, 0.72) * (W.sect.policy.strictness > 70 ? 0.5 : 1);
      const t = CULT.tech(id), name = t ? t.nameTh : id;
      if (rng.chance(techKeep)) {
        owner.inv.techs = owner.inv.techs || [];
        if (!owner.inv.techs.includes(id)) owner.inv.techs.push(id);
        out.notes.push(owner.h.name.given + ' เก็บคัมภีร์「' + name + '」ไว้กับตัว');
      } else {
        W.sect.library.push(id); donation.techs.push(id);
        out.notes.push('คัมภีร์「' + name + '」เข้าสู่หอคัมภีร์');
      }
    });
    if (out.stones > 0) {
      const wantKeep = Math.round(out.stones * keepFrac), wantDonate = out.stones - wantKeep;
      donation.stones = ECO.earnFromPool ? ECO.earnFromPool(W, wantDonate, 'รายได้จากคณะเดินทาง') : (ECO.earn(W, wantDonate, 'รายได้จากคณะเดินทาง') ? wantDonate : 0);
      if (wantKeep > 0) {
        const holder = hoarder();
        const keep = ECO.transferStones
          ? ECO.transferStones(W, { from: 'worldPool', to: 'npc:' + holder.id, amount: wantKeep, allowPartial: true }).moved
          : (holder.inv.stones += wantKeep, wantKeep);
        if (keep > 20) { holder.h.state.stress += 1; W.sect.suspicion = (W.sect.suspicion || 0) + 1; }
      }
    } else if (out.stones < 0) ECO.pay(W, Math.min(-out.stones, W.sect.stones), 'สูญเสียระหว่างเดินทาง');
    if (g.SECT && g.SECT.PATH_LIBRARY && g.SECT.PATH_LIBRARY.sellSurplusManuals) {
      const surp = g.SECT.PATH_LIBRARY.sellSurplusManuals(W, { quiet: true });
      if (surp && surp.revenueStones > 0) {
        donation.surplusManualStones = (donation.surplusManualStones || 0) + surp.revenueStones;
      }
    }
    if (SECT.notifyStockChanged) SECT.notifyStockChanged(W);
    return donation;
  };

  /* ---------- ผู้สมัครใหม่และการมาเยือน ---------- */
  X.recruitApplicants = (W, why) => {
    const S = W.sect;
    if (!S) return 0;
    if (SECT.sanitizeQueue) SECT.sanitizeQueue(W);
    const q = S.queue || (S.queue = []);
    const maxQueue = SECT.MAX_QUEUE || 6;
    if (q.length >= maxQueue) return 0;
    if (W.threat && W.threat.roadBlocked > 0) return 0;

    const occ = SECT.memberOccupancy ? SECT.memberOccupancy(W) : W.npcs.filter(n => !n.dead && !n.exiled).length;
    const cap = SECT.housingCapacity ? SECT.housingCapacity(W) : 46;
    const totalPending = occ + q.length;
    if (occ >= cap || totalPending >= cap) return 0;

    const totalMeals = ECO.count(W, 'meal') + ECO.count(W, 'grain') * 3;
    const foodPerPerson = totalMeals / Math.max(1, totalPending);
    if (totalMeals <= 0 || foodPerPerson < 1.0) return 0;

    if (why === 'daily' && S.lastRecruitGenDay === W.day) return 0;
    if (why === 'daily') S.lastRecruitGenDay = W.day;

    const open = (S.policy ? S.policy.openness : 50) / 100;
    const isDrive = !!(S.driveUntil && S.driveUntil > W.day);
    const driveBoost = isDrive ? (2.1 + open * 0.6) : 0;
    const foodFactor = foodPerPerson > 6 ? 1 : foodPerPerson >= 3 ? 0.55 : 0.25;
    const roomFactor = clamp((cap - totalPending) / 12, 0.25, 1.45);
    const exp = (0.48 + (S.fame || 0) / 220 + open * 0.8 + driveBoost) * roomFactor * foodFactor;

    let want = Math.floor(exp);
    if (W.rng.next() < exp - want) want++;
    const roomInQueue = Math.max(0, maxQueue - q.length);
    const roomInBeds = Math.max(0, cap - totalPending);
    const limit = Math.min(want, roomInQueue, roomInBeds);

    let added = 0;
    for (let i = 0; i < limit; i++) {
      if (q.length >= maxQueue) break;
      const nn = W.makeNpc({
        ageYears: W.rng.int(13, 28),
        rank: 0,
        fromApplicant: true,
        useTalentTier: true,
        queue: true
      });
      if (!nn || q.some(x => x && x.id === nn.id) || W.byId[nn.id]) continue;
      q.push(nn);
      added++;
      S.recruitmentStats = S.recruitmentStats || { generated: 0, driveGenerated: 0, normalGenerated: 0, admitted: 0, rejected: 0, deferred: 0, expired: 0, tiers: {}, tierCounts: {} }; S.recruitmentStats.tiers = S.recruitmentStats.tiers || {}; S.recruitmentStats.tierCounts = S.recruitmentStats.tiers;
      S.recruitmentStats.generated = (S.recruitmentStats.generated || 0) + 1;
      if (isDrive) S.recruitmentStats.driveGenerated = (S.recruitmentStats.driveGenerated || 0) + 1;
      else S.recruitmentStats.normalGenerated = (S.recruitmentStats.normalGenerated || 0) + 1;
      const tId = nn.ext && nn.ext.applicant && nn.ext.applicant.tier || 'COMMON';
      S.recruitmentStats.tiers[tId] = (S.recruitmentStats.tiers[tId] || 0) + 1;

      W.log('recruit', nn.h.name.given + ' (' + nn.h.origin.cls + ' จาก' + nn.h.origin.region + ') มายืนรอที่หน้าประตู ขอสมัครเข้าสำนัก' + (isDrive ? ' (ตามประกาศเปิดรับศิษย์)' : ''), []);
    }
    return added;
  };

  /* ---------- คาราวานรายเดือน ---------- */
  X.caravan = W => {
    const S = W.sect; const tre = SECT.holder(W, 'treasury');
    let spent = 0, sold = 0;
    if (W.threat.roadBlocked > 0) { W.log('finance', 'ถนนถูกปิด คาราวานของสำนักเข้าไม่ถึง', []); return; }
    const skill = tre ? (E(tre, 'intellect.numeracy') + E(tre, 'aptitudes.socialCommerce')) / 2 : 40;
    (S.buyList || []).slice(0, 6).forEach(b => { const pr = Math.round(ECO.price(W, b.id) * (1.12 - skill / 600)); const n = b.n; const cost = pr * n; if (S.stones - spent >= cost + 150) { spent += cost; ECO.add(W, b.id, n); } });
    if (spent) {
      S.stones -= spent;
      S.ledger.push({ t: W.t, amt: -spent, why: 'คาราวานซื้อวัตถุดิบ/เสบียง' });
      if (W.world && W.world.resourcePool && Number.isFinite(W.world.resourcePool.stones)) W.world.resourcePool.stones += spent;
    }
    Object.keys(S.stock).forEach(k => {
      if (ECO.isPill(k) && S.stock[k] > 10) {
        const n = S.stock[k] - 6;
        if (ECO.take(W, k, n)) {
          const v = Math.round(ECO.price(W, k) * 0.7 * n);
          ECO.earn(W, v, 'ขายโอสถส่วนเกิน', { fromPool: true });
          sold += v;
        }
      }
    });
    // Patch v2.0.0: Caravan rare Grand Dao Path Manual & Path Crystal offering
    if (S.stones >= 1600 && g.SECT && g.SECT.PATH_LIBRARY && W.rng && W.rng.chance(0.35)) {
      const summary = g.SECT.PATH_LIBRARY.getSummary(W);
      if (summary && summary.lockedPaths && summary.lockedPaths.length) {
        const pickPath = W.rng.pick(summary.lockedPaths);
        const manualId = 'MANUAL_PATH_' + pickPath;
        const mPrice = (ECO.itemById && ECO.itemById[manualId] && ECO.itemById[manualId].price) || 1200;
        if ((S.stones - spent) >= mPrice + 400 && ECO.pay(W, mPrice, 'คาราวานซื้อคัมภีร์มหาวิถี ' + manualId)) {
          if (W.world && W.world.resourcePool && typeof W.world.resourcePool.stones === 'number') {
            W.world.resourcePool.stones += mPrice;
          }
          ECO.add(W, manualId, 1);
          g.SECT.PATH_LIBRARY.donatePathManual(W, manualId, tre || null, { quiet: true });
        }
      }
    }
    if (SECT.notifyStockChanged) SECT.notifyStockChanged(W);
    W.log('finance', 'คาราวานประจำเดือน: ซื้อ ' + spent + ' ศิลา' + (sold ? ', ขายโอสถส่วนเกินได้ ' + sold : ''), []);
  };

  /* ---------- ศัตรูบุก ---------- */
  X.raidChance = W => {
    const s = W.sect; const tension = W.world.sects.reduce((m, x) => Math.max(m, -x.attitude), 0) / 100;
    return clamp(0.006 + s.fame / 12000 + Math.max(0, tension) * 0.012 + (s.stones > 4000 ? 0.004 : 0), 0, 0.05);
  };
  X.spawnRaid = (W, kind, strength) => {
    const rng = W.rng; const tops = W.npcs.filter(n => !n.dead && !n.away && n.cult).map(n => CULT.power(n)).sort((a, b) => b - a).slice(0, 8);
    const base = tops.reduce((s, v) => s + v, 0) || 80;
    const total = base * (strength || (0.3 + rng.next() * 0.55));
    let foes = []; let label;
    if (kind === 'beast') {
      const maxTier = Math.max(1, Math.min(5, Math.round(Math.log(Math.max(total, 40) / 70) / Math.log(2.2))));
      const pool = JD.BEASTS.species.filter(b => !b.sourcePack && b.canRaidLand !== false && b.terrain !== 'water' && b.tier <= maxTier && b.tier >= Math.max(1, maxTier - 2));
      const sp = rng.pick(pool); const n = clamp(Math.round(total / sp.cp), 1, 8);
      for (let i = 0; i < n; i++) foes.push({ name: sp.nameTh, tier: sp.tier, power: sp.cp * (0.8 + rng.next() * 0.4), fleeAt: sp.flee / 100, kind: 'beast', sp: sp.id, speciesId: sp.id, element: sp.element, elementProfile: sp.elementProfile, drops: sp.drops });
      label = 'ฝูง' + sp.nameTh + ' ' + n + ' ตัว';
    } else {
      const rival = kind === 'rival' ? W.world.sects.slice().sort((a, b) => a.attitude - b.attitude)[0] : null;
      const n = clamp(Math.round(3 + total / 120), 3, 9);
      const roleTemplates = [
        { suffix: 'แม่ทัพหน้า', weaponType: 'SPEAR', role: ' vanguard' },
        { suffix: 'มือกระบี่', weaponType: 'SWORD', role: 'striker' },
        { suffix: 'มือเกาทัณฑ์', weaponType: 'BOW', role: 'archer' },
        { suffix: 'มือดาบหนัก', weaponType: 'BLADE', role: 'breaker' },
        { suffix: 'ผู้คุมอาคม', weaponType: 'FOCUS', role: 'caster' }
      ];
      for (let i = 0; i < n; i++) {
        const boss = i === 0;
        const tpl = roleTemplates[i % roleTemplates.length];
        const baseName = boss
          ? (rival ? 'หัวหน้าชุด' + rival.nameTh : 'หัวหน้าโจรภูเขา')
          : (rival ? 'ศิษย์' + rival.nameTh + ' (' + tpl.suffix + ')' : 'โจรภูเขา (' + tpl.suffix + ')');
        foes.push({
          name: baseName,
          tier: boss ? 3 : 1,
          power: (total / n) * (boss ? 1.9 : 0.8) * (0.8 + rng.next() * 0.4),
          fleeAt: boss ? 0.15 : 0.3,
          kind: 'human',
          boss,
          weaponType: boss ? (rival && rival.primaryWeapon ? rival.primaryWeapon : 'SWORD') : tpl.weaponType
        });
      }
      label = (rival ? 'ศิษย์จาก' + rival.nameTh : 'โจรภูเขา') + ' ' + n + ' คน';
      if (rival) foes.rivalId = rival.id;
    }
    W.foes = W.foes || []; W.foeById = W.foeById || {};
    const f = COMBAT.startFight(W, [], [], 'raid', { serious: true, cb: X.raidEnd, ctx: { label, kind, total } });
    f.foes = [];
    foes.forEach((s, i) => { const id = 'F' + (++W.foeSeq || (W.foeSeq = 1)); const u = Object.assign({ id, foe: true, x: MAP.EXIT.x + .5 + (i % 4) * 1.1 - 1.6, y: MAP.EXIT.y + 0.5 + Math.floor(i / 4) * 1.1, px: 0, py: 0, face: 1, speed: 0.55 + s.tier * 0.02, dead: false, speedBase: 1 }, s); u.hpMax = Math.round(u.power * 1.3 + 30); u.hp = u.hpMax; W.foes.push(u); W.foeById[id] = u; f.B.push(id); f.foes.push(id); COMBAT.enter(W, f, id); });
    W.threat.alert = 3; W.sect.recentRaid = 1; W.threat.raid = f.id;
    W.log('raid', '⚠ ' + label + ' กำลังบุกสำนัก!', []);
    X.rally(W, f); return f;
  };
  X.rally = (W, f) => {
    const commander=g.COG?g.COG.rallyLeader(W,f):null;
    const mast = W.byId[W.sect.masterId]; const guardHead = SECT.holder(W, 'guard');
    W.npcs.forEach(n => {
      if (n.dead || n.away || n.exiled || n.fled || n.yield || n.act && n.act.id === 'fight' || n.sealed || n.sealedBt || n.jail > W.t) return;
      const pw = CULT.power(n), hpR = n.h.state.hp / CULT.hpMax(n);
      let will = (E(n, 'personality.courage') - 40) / 60 + AI.dutyWeight(n) * 0.6 + (E(n, 'values.sectDuty') - 45) / 120 + (n.rank >= 3 ? 0.35 : 0) - (hpR < 0.6 ? 0.6 : 0) - (E(n, 'personality.caution') - 55) / 200 + (n.rank === 0 ? -0.6 : 0) + (pw < 25 ? -0.5 : 0) + (guardHead && !guardHead.dead ? 0.15 : 0) + (mast && mast.id === n.id ? 0.4 : 0) + (commander ? E(commander,'social.leadership')/600 - (f.ctx.formation==='ตั้งรับรักษากำลัง'&&hpR<.65?.45:0) : 0);
      if (will > 0.55 + W.rng.gauss(0, 0.12) && f.A.length < 14) { COMBAT.join(W, f, n.id, 'A'); n.h.state.stress += 3; AI.mem(W, n, 'ออกรบปกป้องสำนัก', 0.7); }
      else {
        if (!(n.act && ['sleep', 'sentence', 'hide'].includes(n.act.id))) { const s = n.bed != null ? W.map.stations[n.bed] : null; if (s) { AI.interruptFor(W, n); AI.begin(W, n, 'hide', { st: s }, [['หลบภัย', 9]]); } }
        if (n.rank >= 1 && n.rank < 5 && will < 0.15) HC.experience(n, 'cowardice', 0.3);
      }
    });
    if (!f.ctx.gateBeastsDeployed) {
      f.ctx.gateBeastsDeployed = true;
      const menagerie = CULT.ensureMenagerie ? CULT.ensureMenagerie(W) : (W.sect.beasts || []);
      const assigned = Array.isArray(W.sect.gateBeasts) ? W.sect.gateBeasts : (W.sect.gateBeasts = []);
      const eligible = assigned.slice(0, 4).map(uid => menagerie.find(b => b && (b.uid === uid || b.id === uid))).filter(b => b && !b.dead && (b.hp == null || b.hp > 0));
      f.ctx.gateBeastIds = [];
      eligible.forEach((beast, i) => {
        const species = (JD.BEASTS && JD.BEASTS.species || []).find(s => s.id === beast.speciesId || s.id === beast.id) || {};
        const tier = clamp(Math.floor(beast.tier || species.tier || 1), 1, 7);
        const level = clamp(Math.floor(beast.level || beast.growthStage || 1), 1, 9);
        const fourSymbol = beast.fourSymbol || (CULT.FOUR_SYMBOL_BLOODLINES && CULT.FOUR_SYMBOL_BLOODLINES[beast.bloodlineTrait] ? beast.bloodlineTrait : null);
        const trait = fourSymbol || (beast.sovereignAwakened ? 'SOVEREIGN_AWAKENED' : (beast.bloodlineTrait || beast.trait || null));
        let power = Math.max(30, Number(beast.power) || Number(beast.cp) || Number(species.cp) || 75) * (1 + (tier - 1) * 0.12 + (level - 1) * 0.035);
        if (trait === 'ALPHA_FANG') power *= 1.12;
        if (trait === 'IRON_CARAPACE') power *= 1.08;
        if (trait === 'SOVEREIGN_AWAKENED') power *= 1.18;
        if (fourSymbol === 'WHITE_TIGER') power *= 1.55;
        else if (fourSymbol) power *= 1.45;
        const hpMax = Math.max(80, Math.round(Number(beast.hpMax) || power * (fourSymbol === 'BLACK_TORTOISE' ? 2.1 : 1.55)));
        const ratio = Number.isFinite(beast.hp) && Number.isFinite(beast.hpMax) && beast.hpMax > 0 ? clamp(beast.hp / beast.hpMax, 0.08, 1) : 1;
        const id = 'GB_' + f.id + '_' + (++W.foeSeq || (W.foeSeq = 1));
        const unit = {
          id, foe: true, isGateBeast: true, sourceBeastUid: beast.uid || beast.id,
          name: beast.nameTh || species.nameTh || 'อสูรพิทักษ์ประตู', nameTh: beast.nameTh || species.nameTh || 'อสูรพิทักษ์ประตู',
          tier, level, power, hpMax, hp: Math.round(hpMax * ratio), dead: false, gone: false,
          kind: 'beast', family: beast.family || species.family, element: beast.element || species.element,
          bloodlineTrait: trait, fourSymbol, sovereignGuardUsed: false, fleeAt: 0,
          x: MAP.EXIT.x + (i - 1.5) * 1.1, y: MAP.EXIT.y + 2, px: 0, py: 0, face: 1, speed: 0.62 + tier * 0.025, speedBase: 1
        };
        W.foes.push(unit); W.foeById[id] = unit; f.A.push(id); COMBAT.enter(W, f, id); f.ctx.gateBeastIds.push(id);
      });
      if (eligible.length) W.log('raid', '🐾 กองอสูรพิทักษ์ประตูเข้าร่วมแนวหน้า ' + eligible.length + ' ตัว', []);
    }
    // v2.0.17: Sworn Allies from Jianghu Karma Bonds reinforce the sect during raids
    if (W.world && W.world.jianghu && f && f.ctx && !f.ctx.swornAlliesDeployed) {
      const rawBonds = Array.isArray(W.world.jianghu.bonds) ? W.world.jianghu.bonds : Object.values(W.world.jianghu.karmaBonds || {});
      f.ctx.swornAlliesDeployed = true;
      f.ctx.swornAllyIds = f.ctx.swornAllyIds || [];
      const allies = rawBonds.filter(b => b && (b.kind === 'SWORN_ALLY' || b.kind === 'BENEFACTOR') && b.active !== false).slice(0, 2);
      allies.forEach((ally, idx) => {
        const tier = clamp(ally.tier || ally.stage || 4, 2, 7);
        const power = Math.max(120, Math.round(Number(ally.power) || (160 + tier * 85)));
        const hpMax = Math.max(240, Math.round(power * 1.85));
        const id = 'ALLY_' + f.id + '_' + (++W.foeSeq || (W.foeSeq = 1));
        const allyName = ally.figureNameTh || ally.npcNameTh || 'สหายร่วมสาบาน';
        const unit = {
          id, foe: true, isSwornAlly: true, sourceBondId: ally.id,
          name: allyName, nameTh: allyName,
          tier, level: tier * 2, power, hpMax, hp: hpMax, dead: false, gone: false,
          kind: 'human', path: ally.path || 'SWORD', weaponType: ally.weaponType || 'SWORD', fleeAt: 0,
          x: MAP.EXIT.x + (idx - 0.5) * 1.4, y: MAP.EXIT.y + 1.5, px: 0, py: 0, face: 1, speed: 0.72, speedBase: 1
        };
        W.foes.push(unit); W.foeById[id] = unit; f.A.push(id); COMBAT.enter(W, f, id); f.ctx.swornAllyIds.push(id);
        ally.helpCount = (ally.helpCount || 0) + 1;
        ally.lastInteractionDay = W.day;
      });
      if (allies.length) {
        W.log('raid', '🤝 สหายร่วมสาบานยุทธภพ (' + allies.map(a => a.figureNameTh || a.npcNameTh).join('、') + ') รุดมาช่วยต้านศึกหน้าด่านสำนัก!', []);
      }
    }
  };
  X.raidEnd = (W, f, ws, win, lose) => {
    const ctx = f.ctx; W.threat.raid = null; W.threat.alert = 1;
    const gateIds = Array.isArray(ctx.gateBeastIds) ? ctx.gateBeastIds : [];
    for (const id of gateIds) {
      const unit = W.foeById && W.foeById[id];
      if (!unit || !unit.isGateBeast) continue;
      const beast = (W.sect.beasts || []).find(b => b && (b.uid === unit.sourceBeastUid || b.id === unit.sourceBeastUid));
      if (beast) {
        beast.hp = unit.dead ? 0 : Math.max(1, Math.min(beast.hpMax || unit.hpMax, unit.hp || 1));
        beast.fatigue = clamp((beast.fatigue || 0) + (unit.dead ? 35 : 12), 0, 100);
        beast.exp = (beast.exp || beast.bondXp || 0) + (unit.dead ? 2 : 8);
        beast.bondXp = beast.exp;
        if (unit.dead) { beast.dead = true; W.sect.gateBeasts = (W.sect.gateBeasts || []).filter(uid => uid !== beast.uid && uid !== beast.id); }
      }
      W.foes = (W.foes || []).filter(u => u.id !== id);
      delete W.foeById[id];
    }
    const allyIds = Array.isArray(ctx.swornAllyIds) ? ctx.swornAllyIds : [];
    for (const id of allyIds) {
      W.foes = (W.foes || []).filter(u => u.id !== id);
      if (W.foeById) delete W.foeById[id];
    }
    if (ctx._raidEndProcessed) return;
    ctx._raidEndProcessed = true;
    const foes = (f.foes || []).map(i => W.foeById && W.foeById[i]).filter(Boolean);
    const slain = foes.filter(u => u.dead).length;
    const defenders = (f.A || []).map(i => W.byId && W.byId[i]).filter(Boolean);
    const fOutcome = (f.tac && f.tac.outcome) || (ws === 'A' ? 'RAID_WIPED' : 'CORE_BREACHED');
    const cPayload = f.chroniclePayload || (g.COMBAT && g.COMBAT.buildFightChroniclePayload ? g.COMBAT.buildFightChroniclePayload(W, f) : null);
    const tacNote = (cPayload && cPayload.narrativeHighlightTh) ? (' · ไฮไลต์: ' + cPayload.narrativeHighlightTh) : '';

    if (ws === 'A' || fOutcome === 'REPELLED_TIMEOUT' || fOutcome === 'PYRRHIC_DEFENSE' || (foes.length > 0 && foes.every(u => u.dead || u.fled || u.gone))) {
      const outcomeDesc = fOutcome === 'REPELLED_TIMEOUT'
        ? 'ตรึงแนวรับหน้าด่านจนผู้บุกหมดกำลังล่าถอย'
        : (fOutcome === 'PYRRHIC_DEFENSE' ? 'สละชีพต้านทานผู้บุกจนสิ้นซาก' : ('สังหาร ' + slain + ' ราย'));
      const rawLoot = Math.round(Math.min(260, 25 + (ctx.total || 80) * (fOutcome === 'REPELLED_TIMEOUT' ? 0.05 : 0.08)));
      const loot = ECO.earnFromPool
        ? ECO.earnFromPool(W, rawLoot, 'ยึดของจากผู้บุก')
        : (ECO.earn(W, rawLoot, 'ยึดของจากผู้บุก') ? rawLoot : 0);
      W.log('raid', '✔ สำนักต้านการบุกของ' + ctx.label + ' สำเร็จ (' + outcomeDesc + (loot > 0 ? (' · ยึดศิลา ' + loot) : '') + ')' + tacNote, defenders.map(d => d.id), {
        combatSummary: cPayload, outcome: fOutcome, slain, loot
      });
      W.fame(3 + slain * 0.3);
      if (g.CULT && g.CULT.updateDivineFaith) g.CULT.updateDivineFaith(W, 6, 'raid_victory');
      foes.forEach(u => { if (u.dead && u.drops) { const d = W.rng.pick(u.drops); ECO.add(W, d, 1 + W.rng.int(0, 1)); } });
      defenders.forEach(d => { if (!d.dead) { d.merit += 15 + (d.h.state.hp < CULT.hpMax(d) * 0.5 ? 10 : 0); HC.experience(d, 'duel_win', 0.6); d.sat = Math.min(100, (d.sat || 60) + 6); if (d.cult) CULT.gain(d, CULT.threshold(d) * 0.04); } });
      const best = defenders.filter(d => !d.dead).sort((a, b) => ((b.tac && b.tac.interceptCount || 0) * 2 + (b.stats && b.stats.kills || 0)) - ((a.tac && a.tac.interceptCount || 0) * 2 + (a.stats && a.stats.kills || 0)))[0];
      if (best) W.log('raid', best.h.name.given + ' เป็นกำลังสำคัญในการป้องกันสำนัก', [best.id]);
      if (ctx.kind === 'rival') { const r = W.world.sects.slice().sort((a, b) => a.attitude - b.attitude)[0]; if (r) r.attitude = Math.min(100, r.attitude + 8); }
      if (X.recordChronicle) {
        X.recordChronicle(W, {
          category: 'BATTLE',
          reportFormat: 'WAR_PAVILION_RECORD',
          icon: '🛡️',
          titleTh: 'ศึกพิทักษ์สำนัก: ต้านทาน' + ctx.label + ' สำเร็จ',
          storyTh: 'กองกำลังศิษย์และผู้พิทักษ์หน้าด่านยืนหยัดรับมือ' + ctx.label + ' (' + outcomeDesc + ')' + (cPayload && cPayload.narrativeHighlightTh ? (' โดย ' + cPayload.narrativeHighlightTh) : ''),
          originCauseTh: 'ผู้บุกรุก (' + ctx.label + ') ยกกำลังเข้าประชิดประตูสำนัก',
          combatBreakdownTh: cPayload ? cPayload.tacticalSummaryTh : outcomeDesc,
          consequenceTh: 'รักษาคลังสำนักไว้ได้ · ยึดศิลาวิญญาณ ' + loot + ' ก้อน · ชื่อเสียงสำนักเพิ่มขึ้น',
          involvedSects: [W.sect.name],
          involvedFigures: defenders.slice(0, 4).map(d => HC.fullName(d)),
          npcIds: defenders.map(d => d.id),
          combatSummary: cPayload,
          quiet: true
        });
      }
    } else {
      const loss = Math.round(W.sect.stones * clamp(0.1 + W.rng.next() * 0.15, 0.05, 0.3)); W.sect.stones -= loss; W.sect.ledger.push({ t: W.t, amt: -loss, why: 'ถูกปล้นโดย' + ctx.label });
      Object.keys(W.sect.stock).forEach(k => { if (W.rng.chance(0.3)) { const n = Math.floor(W.sect.stock[k] * 0.25); if (n > 0) ECO.take(W, k, n); } });
      W.map.buildings.forEach(b => { if (W.rng.chance(0.25)) b.hp = Math.max(30, b.hp - W.rng.int(10, 35)); });
      W.log('raid', '✘ สำนักถูกบุกและปล้น เสียศิลา ' + loss + ' เสียหายหนัก' + tacNote, defenders.map(d => d.id), {
        combatSummary: cPayload, outcome: fOutcome, loss
      });
      W.fame(-4);
      if (g.CULT && g.CULT.updateDivineFaith) g.CULT.updateDivineFaith(W, -8, 'raid_defeat');
      W.npcs.forEach(n => { if (!n.dead) { HC.experience(n, 'duel_lose', 0.3); n.sat = Math.max(0, (n.sat || 60) - 6); } });
      if (X.recordChronicle) {
        X.recordChronicle(W, {
          category: 'BATTLE',
          reportFormat: 'WAR_PAVILION_RECORD',
          icon: '🔥',
          titleTh: 'วิกฤตศึกหน้าด่าน: ' + ctx.label + ' บุกทะลวงแนวรับสำนัก',
          storyTh: ctx.label + ' ทะลวงแนวป้องกันเข้าถึงโถงสำนัก' + (cPayload && cPayload.narrativeHighlightTh ? (' (' + cPayload.narrativeHighlightTh + ')') : ''),
          originCauseTh: 'ผู้บุกรุก (' + ctx.label + ') โจมตีสำนักและแนวรับต้านทานไม่ไหว',
          combatBreakdownTh: cPayload ? cPayload.tacticalSummaryTh : 'แนวรับแตกพ่าย',
          consequenceTh: 'สูญเสียศิลาวิญญาณ ' + loss + ' ก้อน และเสบียงบางส่วน · อาคารได้รับความเสียหาย',
          involvedSects: [W.sect.name],
          involvedFigures: defenders.slice(0, 4).map(d => HC.fullName(d)),
          npcIds: defenders.map(d => d.id),
          combatSummary: cPayload,
          quiet: true
        });
      }
    }
    W.foes = (W.foes || []).filter(u => !f.foes.includes(u.id)); f.foes.forEach(i => delete W.foeById[i]);
    foes.forEach(u => { u.gone = true; });
    W.npcs.forEach(n => { if (n.act && n.act.id === 'hide') { AI.release(W, n); n.act = { id: 'idle', stage: 'do', left: 0, total: 0, ctx: {}, why: [] }; } });
  };

  X.assignGateBeast = (W, beastUid, assign) => {
    if (!W || !W.sect || !beastUid) return { ok: false, reason: 'invalid-beast' };
    const menagerie = CULT.ensureMenagerie ? CULT.ensureMenagerie(W) : (W.sect.beasts || []);
    const beast = menagerie.find(b => b && (b.uid === beastUid || b.id === beastUid));
    if (!beast) return { ok: false, reason: 'not-a-reserve-beast' };
    if (!Array.isArray(W.sect.gateBeasts)) W.sect.gateBeasts = [];
    const key = beast.uid || beast.id;
    const has = W.sect.gateBeasts.includes(key);
    if (assign === false) {
      W.sect.gateBeasts = W.sect.gateBeasts.filter(uid => uid !== key);
      return { ok: true, assigned: false, beastUid: key };
    }
    if (has) return { ok: true, assigned: true, unchanged: true, beastUid: key };
    if (W.sect.gateBeasts.length >= 4) return { ok: false, reason: 'gate-vanguard-full', max: 4 };
    if (beast.dead || (beast.hp != null && beast.hp <= 0)) return { ok: false, reason: 'beast-injured' };
    W.sect.gateBeasts.push(key);
    return { ok: true, assigned: true, beastUid: key, nameTh: beast.nameTh || 'อสูรพิทักษ์ประตู' };
  };
  X.raidTick = W => {
    if (!W.foes || !W.foes.length) return;
    W.foes.forEach(u => COMBAT.foeStep(W, u));
    if ((W._isNewCalendarMinute !== false && W.t % 20 === 0) && W.threat.raid) { const f = (W.fights || []).find(q => q.id === W.threat.raid); if (f && !f.over) X.rally(W, f); }
  };

  /* ---------- เหตุการณ์สุ่มรายวัน ---------- */
  X.daily = W => {
    const rng = W.rng; const T = W.threat;
    if (W.world && !T.raid && (W.day || 0) > 10 && (W.day % 6 === 0)) {
      const activeAnom = Array.isArray(W.world.anomalies) && W.world.anomalies.find(a => a && !a.resolved && !a.expired && !(W.world.expeds || []).some(e => !e.done && e.kind === 'world_anomaly' && e.anomalyId === a.id));
      if (activeAnom && X.departWorldAnomaly) {
        const avail = (W.npcs || []).filter(n => X.isAvailableForExpedition && X.isAvailableForExpedition(W, n) && CULT.power(n) >= 65).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 3);
        if (avail.length >= 2) X.departWorldAnomaly(W, avail, activeAnom);
      }
    }
    if (T.alert > 0) T.alert--; if (T.roadBlocked > 0) T.roadBlocked--;
    if (W.day >= T.raidCooldown && !T.raid && rng.chance(X.raidChance(W))) {
      const tension = W.world.sects.some(s => s.attitude < -40);
      const kind = tension && rng.chance(0.5) ? 'rival' : rng.chance(0.45) ? 'beast' : 'bandit';
      X.spawnRaid(W, kind); T.raidCooldown = W.day + 25 + rng.int(0, 30);
    }
    W.world.sects.forEach(s => { s.attitude = clamp(s.attitude + (s.attitude > 0 ? -0.15 : 0.15) + (s.style === 'ก้าวร้าว' ? -0.1 : 0) + rng.gauss(0, 0.8), -100, 100); });
    if (rng.chance(0.025)) {
      if (g.VC && g.EXT && typeof g.EXT.openVisit === 'function') {
        if ((g.EXT.activeVisitors(W) || []).length < 2) g.EXT.openVisit(W);
      } else {
        const rawGain = Math.round(40 + rng.next() * 100);
        const gain = ECO.earnFromPool ? ECO.earnFromPool(W, rawGain, 'พ่อค้าเร่') : (ECO.earn(W, rawGain, 'พ่อค้าเร่') ? rawGain : 0);
        if (gain > 0) W.log('event', 'พ่อค้าเร่แวะสำนัก ซื้อโอสถและของเหลือใช้ ได้ ' + gain + ' ศิลา', []);
      }
    }
    if (rng.chance(0.012) && W.season !== 3) {
      if (g.VC && typeof g.VC.spawnGuest === 'function') {
        if ((g.VC.activeGuests(W) || []).length < 4) {
          g.VC.spawnGuest(W, { role: 'scholar', notable: true, withClue: true });
        }
      } else {
        const t = SECT.holder(W, 'scripture') || W.byId[W.sect.masterId];
        if (t) { const drop = g.MARTIAL.personalDiscovery(W, t, { tier: 4, source: 'visitor' }); if (drop) { W.log('event', 'ยอดฝีมือเร่ร่อนมอบองค์ความรู้หายากให้ ' + t.h.name.given, [t.id]); W.fame(1); } }
      }
    }
    if (rng.chance(0.014)) {
      const hit = W.npcs.filter(n => !n.dead && !n.away && rng.chance(0.18 * (1 - E(n, 'physiology.immunity') / 130)));
      if (hit.length) { hit.forEach(n => { n.h.state.hp = Math.max(1, n.h.state.hp * 0.7); HC.feel(n, { mood: -6, stress: 4 }); n.h.state.rest = Math.max(0, n.h.state.rest - 25); }); W.log('event', 'โรคไข้หวัดใหญ่แพร่ในสำนัก ผู้ป่วย ' + hit.length + ' คน' + (SECT.holder(W, 'healer') ? ' หมอหลวงดูแลรักษา' : ' แต่ไม่มีหมอหลวง'), []); }
    }
    if (rng.chance(0.012) && W.season === 3) { T.roadBlocked = 8 + rng.int(0, 8); W.log('event', 'หิมะหนา ถนนเข้าออกถูกปิดหลายวัน', []); }
    if (rng.chance(0.008) && W.season === 0) { const g2 = Math.round(W.npcs.length * 2 + 20); ECO.add(W, 'grain', g2); W.log('event', 'ฤดูใบไม้ผลิฝนดี ผลผลิตเพิ่มพิเศษ ข้าวเพิ่ม ' + g2, []); }
    if (rng.chance(0.007)) { const b = rng.pick(W.map.buildings.filter(x => x.type !== 'gate')); b.hp = Math.max(40, b.hp - rng.int(8, 25)); W.log('event', b.nameTh + ' ชำรุดจากภัยธรรมชาติ ต้องซ่อมแซม', []); }
    W.map.buildings.forEach(b => { if (b.hp < 100) b.hp = Math.min(100, b.hp + 0.6); });
    // ผู้สมัครใหม่: ช่วงปกติทุก 6 วัน ช่วงเปิดรับศิษย์ (Recruiting Drive) ทุก 2 วัน (กันซ้ำด้วย lastRecruitGenDay)
    const isDrive = !!(W.sect && W.sect.driveUntil && W.sect.driveUntil > W.day);
    if (W.day % 6 === 0 || (isDrive && W.day % 2 === 0)) {
      X.recruitApplicants(W, 'daily');
    }
  };


  /* ======================= v2.0.18: Interactive Jianghu World Map, 3-Phase Sieges, Hegemony & Contestable Nodes ======================= */
  X.WORLD_REGIONS = Object.freeze({
    CENTRAL_HEARTLAND: {
      id: 'CENTRAL_HEARTLAND',
      nameTh: 'หุบเขาฟ้าประทาน (แดนกลาง)',
      shortTh: 'แดนกลาง',
      icon: '⛰️',
      terrain: 'forest',
      danger: 1,
      center: { x: 50, y: 48 },
      color: '#4eb883',
      descTh: 'ศูนย์กลางที่ตั้งสำนักของเรา ป่าหมอกเขียว และเจดีย์เก้าวิถีทดสอบสัจธรรม'
    },
    NORTHERN_PEAKS: {
      id: 'NORTHERN_PEAKS',
      nameTh: 'แดนทิวเขาศิลาครามและซากโบราณ (ทิศเหนือ)',
      shortTh: 'แดนเหนือ',
      icon: '🏔️',
      terrain: 'mountain',
      danger: 3,
      center: { x: 48, y: 20 },
      color: '#6ca6cd',
      descTh: 'เทือกเขาสูงชัน ซากนครโบราณ วิหารกระบี่สุญตา มหาวิหารวัชระโลหิต และเหมืองศิลาวิญญาณสวรรค์'
    },
    SOUTHERN_WATERS: {
      id: 'SOUTHERN_WATERS',
      nameTh: 'แดนลุ่มน้ำมังกรและบึงอมฤต (ทิศใต้)',
      shortTh: 'แดนใต้',
      icon: '🌊',
      terrain: 'water',
      danger: 2,
      center: { x: 48, y: 78 },
      color: '#3b9ab2',
      descTh: 'ลุ่มน้ำสาบมังกรคราม ทะเลสาบมังกรหลับ แดนวารีเหมันต์ และบึงสมุนไพรอมฤต'
    },
    EASTERN_PLAINS: {
      id: 'EASTERN_PLAINS',
      nameTh: 'แดนทุ่งราบเมฆาและพงไพรการค้า (ทิศตะวันออก)',
      shortTh: 'แดนตะวันออก',
      icon: '🌾',
      terrain: 'plains',
      danger: 2,
      center: { x: 80, y: 48 },
      color: '#9ec459',
      descTh: 'ทุ่งราบเมฆา ชุมทางการค้าหุบเขาสองแคว แดนพฤกษากำเนิดชีพ และหุบเขาสมุนไพรหมื่นปี'
    },
    WESTERN_BADLANDS: {
      id: 'WESTERN_BADLANDS',
      nameTh: 'แดนทะเลทรายเพลิงและแท่นดารา (ทิศตะวันตก)',
      shortTh: 'แดนตะวันตก',
      icon: '🏜️',
      terrain: 'desert',
      danger: 4,
      center: { x: 18, y: 52 },
      color: '#e2725b',
      descTh: 'ทะเลทรายเพลิงอัสดง แท่นบูชาดาราเทวะ แดนเพลิงชาด และเหมืองศิลาดาราอัสดง'
    }
  });

  X.RESOURCE_NODE_DEFS = Object.freeze({
    MINE_CELESTIAL_STONE: {
      id: 'MINE_CELESTIAL_STONE',
      nameTh: 'เหมืองศิลาวิญญาณสวรรค์',
      category: 'SPIRIT_MINE',
      categoryTh: 'เหมืองศิลาวิญญาณ',
      icon: '💎',
      macroRegion: 'NORTHERN_PEAKS',
      terrain: 'mountain',
      danger: 3,
      x: 50, y: 12,
      baseDays: 5,
      dailyStones: 20,
      seasonalStones: 360,
      mats: ['MAT_ORE_COLD_STEEL_2', 'MAT_ORE_MITHRIL_JADE_4'],
      garrisonPowerBase: 420,
      defaultOwnerFactionId: 'FAC_WHITE_CLOUD',
      descTh: 'สายแร่ผลึกวิญญาณบริสุทธิ์บนยอดเขาเหนือ สร้างรายได้ศิลาวิญญาณและแร่เหล็กเย็นสม่ำเสมอ'
    },
    MINE_STARFALL_CRAG: {
      id: 'MINE_STARFALL_CRAG',
      nameTh: 'เหมืองศิลาดาราอัสดง',
      category: 'SPIRIT_MINE',
      categoryTh: 'เหมืองศิลาวิญญาณ',
      icon: '🌠',
      macroRegion: 'WESTERN_BADLANDS',
      terrain: 'desert',
      danger: 4,
      x: 24, y: 42,
      baseDays: 7,
      dailyStones: 26,
      seasonalStones: 450,
      mats: ['MAT_ORE_METEOR_IRON_5', 'MAT_ORE_STAR_COPPER_3'],
      garrisonPowerBase: 520,
      defaultOwnerFactionId: 'FAC_GOLDEN_SUN',
      descTh: 'หลุมแร่ดาวตกกลางทะเลทรายเพลิง ให้ผลผลิตศิลาวิญญาณและแร่เหล็กดาวตกระดับสูง'
    },
    VALLEY_MILLENNIAL_HERB: {
      id: 'VALLEY_MILLENNIAL_HERB',
      nameTh: 'หุบเขาสมุนไพรหมื่นปี',
      category: 'HERB_VALLEY',
      categoryTh: 'หุบเขาสมุนไพรวิญญาณ',
      icon: '🌿',
      macroRegion: 'EASTERN_PLAINS',
      terrain: 'forest',
      danger: 2,
      x: 76, y: 34,
      baseDays: 4,
      dailyStones: 10,
      seasonalStones: 180,
      mats: ['MAT_HERB_BLOOD_GINSENG_3', 'MAT_HERB_DRAGON_GRASS_4', 'MAT_HERB_JADE_LOTUS_2'],
      garrisonPowerBase: 320,
      defaultOwnerFactionId: 'FAC_AZURE_PAVILION',
      descTh: 'หุบเขาชุ่มปราณพฤกษา ส่งมอบสมุนไพรวิญญาณระดับ T2–T4 เข้าคลังโอสถของสำนักผู้ครอบครอง'
    },
    VALLEY_IMMORTAL_MARSH: {
      id: 'VALLEY_IMMORTAL_MARSH',
      nameTh: 'บึงสมุนไพรอมฤตมังกรหลับ',
      category: 'HERB_VALLEY',
      categoryTh: 'หุบเขาสมุนไพรวิญญาณ',
      icon: '🪷',
      macroRegion: 'SOUTHERN_WATERS',
      terrain: 'water',
      danger: 3,
      x: 40, y: 72,
      baseDays: 4,
      dailyStones: 12,
      seasonalStones: 220,
      mats: ['MAT_HERB_SNOW_LOTUS_5', 'MAT_HERB_DRAGON_GRASS_4', 'MAT_HERB_MIST_ORCHID_2'],
      garrisonPowerBase: 390,
      defaultOwnerFactionId: 'FAC_JADE_LOTUS',
      descTh: 'บึงน้ำทิพย์แดนใต้ที่บัวหิมะและหญ้าเกล็ดมังกรเจริญงอกงาม'
    },
    TOLL_JIANGNAN_CROSSWAY: {
      id: 'TOLL_JIANGNAN_CROSSWAY',
      nameTh: 'ด่านเก็บค่าผ่านทางลำน้ำหยกภาคกลาง',
      category: 'TRADE_TOLL',
      categoryTh: 'ด่านภาษีเส้นทางการค้า',
      icon: '🏮',
      macroRegion: 'EASTERN_PLAINS',
      terrain: 'plains',
      danger: 2,
      x: 86, y: 52,
      baseDays: 4,
      dailyStones: 24,
      seasonalStones: 420,
      mats: ['MAT_HERB_JADE_LOTUS_2'],
      garrisonPowerBase: 360,
      defaultOwnerFactionId: 'FAC_LONGMEN',
      descTh: 'ด่านชุมทางการค้าตะวันออก เก็บค่าผ่านทางจากขบวนคาราวานและพ่อค้าเร่ทั่วลุ่มน้ำหยกภาคกลาง'
    },
    TOLL_SOUTHERN_WATERWAY: {
      id: 'TOLL_SOUTHERN_WATERWAY',
      nameTh: 'ด่านศุลกากรลำน้ำทักษิณ',
      category: 'TRADE_TOLL',
      categoryTh: 'ด่านภาษีเส้นทางการค้า',
      icon: '⛵',
      macroRegion: 'SOUTHERN_WATERS',
      terrain: 'water',
      danger: 2,
      x: 54, y: 68,
      baseDays: 4,
      dailyStones: 22,
      seasonalStones: 380,
      mats: ['MAT_ORE_COLD_STEEL_2'],
      garrisonPowerBase: 350,
      defaultOwnerFactionId: 'FAC_MIST_DRAGON',
      descTh: 'ท่าเรือด่านศุลกากรปากแม่น้ำมังกรคราม เก็บภาษีเรือสินค้าและขบวนแลกเปลี่ยนแดนใต้'
    }
  });

  X.ANOMALY_TEMPLATES = Object.freeze({
    GROTTO_ANCIENT_IMMORTAL: {
      id: 'GROTTO_ANCIENT_IMMORTAL',
      nameTh: 'ถ้ำลับเซียนโบราณเปิดผนึก',
      icon: '🏛️',
      macroRegion: 'NORTHERN_PEAKS',
      terrain: 'mountain',
      danger: 4,
      baseDays: 5,
      durationDays: 16,
      stones: 420,
      catalystId: 'CAT_RESONANCE_JADE_4',
      primordialId: 'CAT_PRIMORDIAL_METAL',
      grantManual: true,
      descTh: 'ม่านค่ายกลพันปีสลายตัว เผยถ้ำพำนักของผู้ลงมาจากโลกเบื้องบนที่บาดเจ็บจนตบะร่วงหล่นติดค้างใต้ผืนฟ้า (เช่นเดียวกับทูตตกสวรรค์ ขงหมิง #21) และยอดฝีมือยุคเทียนกู่ สำนักคู่แข่งกำลังส่งยอดฝีมือมุ่งหน้าไป!'
    },
    BLOOM_CELESTIAL_LOTUS: {
      id: 'BLOOM_CELESTIAL_LOTUS',
      nameTh: 'บัวสวรรค์หมื่นปีเบ่งบาน',
      icon: '🪷',
      macroRegion: 'SOUTHERN_WATERS',
      terrain: 'water',
      danger: 3,
      baseDays: 4,
      durationDays: 14,
      stones: 320,
      mats: { MAT_HERB_SNOW_LOTUS_5: 3, MAT_HERB_DRAGON_GRASS_4: 3 },
      catalystId: 'CAT_PRIMORDIAL_WOOD',
      primordialId: 'CAT_PRIMORDIAL_WATER',
      grantRecipe: true,
      descTh: 'ปราณพฤกษาและวารีบรรจบกันรอบร้อยปี บัวสวรรค์หมื่นปีผลิบานพร้อมแก่นปฐมธาตุพฤกษาและวารี!'
    },
    METEOR_ASTRAL_CRATER: {
      id: 'METEOR_ASTRAL_CRATER',
      nameTh: 'อุกกาบาตดาราตกจากฟากฟ้า',
      icon: '☄️',
      macroRegion: 'WESTERN_BADLANDS',
      terrain: 'desert',
      danger: 4,
      baseDays: 6,
      durationDays: 15,
      stones: 480,
      mats: { MAT_ORE_METEOR_IRON_5: 4, MAT_ORE_MITHRIL_JADE_4: 2 },
      catalystId: 'CAT_ASTRAL_ESSENCE_5',
      primordialId: 'CAT_PRIMORDIAL_FIRE',
      grantRelicCatalyst: true,
      descTh: 'ดาวตกเพลิงดาราพุ่งชนทะเลทรายตะวันตก อัดแน่นด้วยแร่เหล็กดาวตก สุริยธาตุหยาง และผลึกดาราหลอมศาสตราเทพ!'
    }
  });

  /* ---------- Patch v2.0.19: 6-Tier Sect Hierarchy, 3 Alignments & 19 Diverse Jianghu Organizations ---------- */
  X.SECT_TIER_DEFS = Object.freeze({
    SMALL:       { id: 'SMALL',       tierLevel: 1, nameTh: 'สำนักเล็ก',            badgeTh: 'ระดับ 1 · สำนักเล็ก',            minScore: 0,    basePower: 0.72, maxStage: 3, influenceBase: 40,  tributeMult: 0.75 },
    STANDARD:    { id: 'STANDARD',    tierLevel: 2, nameTh: 'สำนักทั่วไป',          badgeTh: 'ระดับ 2 · สำนักทั่วไป/มาตรฐาน',  minScore: 160,  basePower: 1.12, maxStage: 4, influenceBase: 68,  tributeMult: 1.00 },
    LARGE:       { id: 'LARGE',       tierLevel: 3, nameTh: 'สำนักใหญ่',            badgeTh: 'ระดับ 3 · สำนักใหญ่',            minScore: 360,  basePower: 1.60, maxStage: 5, influenceBase: 105, tributeMult: 1.35 },
    LEADING:     { id: 'LEADING',     tierLevel: 4, nameTh: 'สำนักชั้นนำ',          badgeTh: 'ระดับ 4 · สำนักชั้นนำ',          minScore: 680,  basePower: 2.20, maxStage: 6, influenceBase: 155, tributeMult: 1.80 },
    HEGEMON:     { id: 'HEGEMON',     tierLevel: 5, nameTh: 'สำนักมหาอำนาจ',        badgeTh: 'ระดับ 5 · สำนักมหาอำนาจ',        minScore: 1150, basePower: 3.30, maxStage: 7, influenceBase: 230, tributeMult: 2.50 },
    SACRED_LAND: { id: 'SACRED_LAND', tierLevel: 6, nameTh: 'แดนศักดิ์สิทธิ์',      badgeTh: 'ระดับ 6 · แดนศักดิ์สิทธิ์',      minScore: 1800, basePower: 4.85, maxStage: 8, influenceBase: 350, tributeMult: 3.50 }
  });
  X.SECT_TIER_ORDER = Object.freeze(['SMALL', 'STANDARD', 'LARGE', 'LEADING', 'HEGEMON', 'SACRED_LAND']);

  X.ALIGNMENT_DEFS = Object.freeze({
    RIGHTEOUS: {
      id: 'RIGHTEOUS',
      nameTh: 'ฝ่ายธรรมะ',
      fullTh: 'สมาพันธ์คุณธรรมฝ่ายธรรมะ',
      icon: '☀️',
      hasSupremeLeader: true,
      supremeLeaderCodeId: 'FAC_CELESTIAL_SWORD_SACRED',
      descTh: 'ยึดมั่นคุณธรรม รักษากฎเกณฑ์ยุทธภพ ปราบปรามมารอธรรม และมีแดนศักดิ์สิทธิ์เป็นผู้นำสมาพันธ์'
    },
    DEMONIC: {
      id: 'DEMONIC',
      nameTh: 'ฝ่ายอธรรม',
      fullTh: 'ภาคีมารครองภพฝ่ายอธรรม',
      icon: '🩸',
      hasSupremeLeader: true,
      supremeLeaderCodeId: 'FAC_NETHER_BLOOD_SACRED',
      descTh: 'ยึดถือผู้แข็งแกร่งกลืนกินผู้อ่อนแอ ช่วงชิงทรัพยากร และมีแดนศักดิ์สิทธิ์มารเป็นประมุขสูงสุด'
    },
    NEUTRAL: {
      id: 'NEUTRAL',
      nameTh: 'สายกลาง',
      fullTh: 'สำนักอิสระสายกลาง',
      icon: '☯️',
      hasSupremeLeader: false,
      supremeLeaderCodeId: null,
      descTh: 'เป็นอิสระไม่สังกัดสมาพันธ์ธรรมะหรืออธรรม มุ่งเน้นการค้า ปัญญา และการพึ่งพาตนเอง (สายกลางไม่มีสำนักระดับผู้นำสูงสุด)'
    }
  });

  X.CANONICAL_SECTS = Object.freeze([
    // --- 8 Core Regional Organizations (Enriched with Diverse Org Types, Thematic/Eclectic Doctrines & Tiers 2..4) ---
    {
      codeId: 'FAC_WHITE_CLOUD',
      nameTh: 'สำนักกระบี่เมฆขาว',
      aliasNames: ['สำนักกระบี่เมฆขาว'],
      orgType: 'สำนัก',
      sectTier: 'LEADING',
      tierLevel: 4,
      alignment: 'RIGHTEOUS',
      doctrineMode: 'THEMATIC',
      macroRegion: 'NORTHERN_PEAKS',
      x: 38, y: 28, baseDays: 5, terrain: 'mountain', danger: 3,
      majorPath: 'XIAN',
      signatureSubs: ['SWORD_IMMORTAL', 'PURE_SWORD_SAINT', 'MIND_SWORD_TELEKINESIS'],
      signatureWeaponTypes: ['SWORD'],
      signatureTechs: ['ART190_XIAN_001', 'MP_SWORD_SHADOWLESS_SWIFT_T3', 'PASS_SWORD_HEART_CLARITY_T5'],
      signatureGearTh: 'กระบี่เมฆขาวตัดนภา & อาภรณ์เซียนเมฆา',
      leaderNameTh: 'ปรมาจารย์ไป๋หยุน',
      powerBase: 2.15,
      specialtyMatIds: ['MAT_ORE_COLD_STEEL_2', 'MAT_ORE_METEOR_IRON_5'],
      tributeDescTh: 'ศิลาวิญญาณ + แร่เหล็กดาวตก/เหล็กเย็นและศาสตรากระบี่'
    },
    {
      codeId: 'FAC_JADE_LOTUS',
      nameTh: 'หุบเขาโอสถบัวหยก',
      aliasNames: ['สำนักบัวหยก', 'หุบเขาโอสถบัวหยก'],
      orgType: 'หุบเขา',
      sectTier: 'LARGE',
      tierLevel: 3,
      alignment: 'RIGHTEOUS',
      doctrineMode: 'THEMATIC',
      macroRegion: 'SOUTHERN_WATERS',
      x: 34, y: 76, baseDays: 4, terrain: 'water', danger: 2,
      majorPath: 'SAGE_SUPPORT',
      signatureSubs: ['DIVINE_NECTAR_APOTHECARY', 'GOLDEN_NEEDLE_SAINT', 'CELESTIAL_ZITHER_ENVOY'],
      signatureWeaponTypes: ['FOCUS', 'ZITHER'],
      signatureTechs: ['ART_SAGE_SUP_001', 'ART_SAGE_SUP_003', 'ART_V212_SAGE_SANCTUARY_T2'],
      signatureGearTh: 'พิณหยกบงกชทิพย์ & เข็มทองสกัดจุด',
      leaderNameTh: 'เจ้าหุบเขาชิงเหลียน',
      powerBase: 1.55,
      specialtyMatIds: ['MAT_HERB_JADE_LOTUS_2', 'MAT_HERB_SNOW_LOTUS_5'],
      tributeDescTh: 'ศิลาวิญญาณ + บัวหิมะหมื่นปีและโอสถทิพย์ฟื้นฟู'
    },
    {
      codeId: 'FAC_LONGMEN',
      nameTh: 'หมู่ตึกวาณิชย์หลงเหมิน',
      aliasNames: ['ตระกูลหลงเหมิน', 'หมู่ตึกวาณิชย์หลงเหมิน'],
      orgType: 'หมู่ตึก',
      sectTier: 'LARGE',
      tierLevel: 3,
      alignment: 'NEUTRAL',
      doctrineMode: 'ECLECTIC',
      macroRegion: 'EASTERN_PLAINS',
      x: 78, y: 62, baseDays: 4, terrain: 'plains', danger: 2,
      majorPath: 'STRATEGY_GOVERNANCE',
      allowedPaths: ['STRATEGY_GOVERNANCE', 'XIAN', 'BODY', 'CRAFT_CREATION', 'MECH_PUPPET'],
      signatureSubs: ['IMPERIAL_STRATEGIST', 'SWORD_IMMORTAL', 'HEAVENLY_ANVIL_SMITH', 'CELESTIAL_BALLISTA'],
      signatureWeaponTypes: ['SWORD', 'BLADE', 'SPEAR', 'BOW', 'FOCUS'],
      signatureTechs: ['MP_FOCUS_ABACUS_TACTIC_T3', 'PASS_V212_ADAPTIVE_ARSENAL_T2', 'MP_SPEAR_MILITARY_DRILL_T1'],
      signatureGearTh: 'ศาสตราและคัมภีร์หลากสายจากกองคาราวานทั่วหล้า',
      leaderNameTh: 'ประมุขหลงเจิ้นเทียน',
      powerBase: 1.50,
      specialtyMatIds: ['MAT_HERB_BLOOD_GINSENG_3', 'MAT_ORE_STAR_COPPER_3'],
      tributeDescTh: 'ศิลาวิญญาณก้อนโตจากภาษีคาราวาน + สินค้าหายาก'
    },
    {
      codeId: 'FAC_ROARING_TIGER',
      nameTh: 'ป้อมพยัคฆ์คำรามผ่าศิลา',
      aliasNames: ['สำนักเสือคำราม', 'ป้อมพยัคฆ์คำรามผ่าศิลา'],
      orgType: 'ป้อม',
      sectTier: 'STANDARD',
      tierLevel: 2,
      alignment: 'NEUTRAL',
      doctrineMode: 'THEMATIC',
      macroRegion: 'NORTHERN_PEAKS',
      x: 60, y: 24, baseDays: 5, terrain: 'mountain', danger: 3,
      majorPath: 'BODY',
      signatureSubs: ['TIGER_SOVEREIGN', 'OVERLORD_HEAVY_BLADE'],
      signatureWeaponTypes: ['BLADE', 'FIST'],
      signatureTechs: ['ART190_BODY_001', 'MP_BLADE_IRON_CLEAVER_T2', 'PASS_BLADE_HEAVY_CLEAVE_T3'],
      signatureGearTh: 'ดาบใหญ่เขี้ยวพยัคฆ์ & สนับมือเหล็กผ่าผา',
      leaderNameTh: 'ขุนพลพยัคฆ์คลั่งเล่ยหู่',
      powerBase: 1.15,
      specialtyMatIds: ['MAT_HERB_BLOOD_GINSENG_3', 'MAT_ORE_COLD_STEEL_2'],
      tributeDescTh: 'ศิลาวิญญาณ + แก่นอสูรและสมุนไพรชุบกายา'
    },
    {
      codeId: 'FAC_GOLDEN_SUN',
      nameTh: 'หอสุริยาสีทองอัคคีเทวะ',
      aliasNames: ['หอสุริยาสีทอง', 'หอสุริยาสีทองอัคคีเทวะ'],
      orgType: 'หอ',
      sectTier: 'LEADING',
      tierLevel: 4,
      alignment: 'DEMONIC',
      doctrineMode: 'THEMATIC',
      macroRegion: 'WESTERN_BADLANDS',
      x: 22, y: 64, baseDays: 6, terrain: 'desert', danger: 4,
      majorPath: 'GOD',
      signatureSubs: ['SUN_BOW_DEITY', 'WAR_DEITY', 'SOLAR_FORGE'],
      signatureWeaponTypes: ['BOW', 'SPEAR'],
      signatureTechs: ['ART_V212_GOD_SUN_BOW_T1', 'ART_V212_GOD_SUN_BOW_T3', 'MP_BOW_METEOR_STORM'],
      signatureGearTh: 'เกาทัณฑ์สุริยันผลาญฟ้า & ทวนทองคำเพลิงเทวะ',
      leaderNameTh: 'มหาปุโรหิตสุริยันจินหยาง',
      powerBase: 2.25,
      specialtyMatIds: ['MAT_ORE_STAR_COPPER_3', 'MAT_ORE_METEOR_IRON_5'],
      tributeDescTh: 'ศิลาวิญญาณ + แร่สุริยันและยันต์อัคคีเทวะ'
    },
    {
      codeId: 'FAC_YIN_RAIN',
      nameTh: 'นิกายพิรุณหยินเงาโลหิต',
      aliasNames: ['สำนักพิรุณหยิน', 'นิกายพิรุณหยินเงาโลหิต'],
      orgType: 'นิกาย',
      sectTier: 'LARGE',
      tierLevel: 3,
      alignment: 'DEMONIC',
      doctrineMode: 'THEMATIC',
      macroRegion: 'WESTERN_BADLANDS',
      x: 14, y: 50, baseDays: 6, terrain: 'desert', danger: 3,
      majorPath: 'DEMON',
      signatureSubs: ['SHADOW_ASSASSIN', 'VENOM_GU_SOVEREIGN'],
      signatureWeaponTypes: ['WHIP', 'BLADE'],
      signatureTechs: ['ART_DEMON_SHADOW_STRIKE_T1', 'ART_V112_DEMON_SILENT_DAGGER_T3', 'ART_V210_CHAIN_SHADOW_DAGGER'],
      signatureGearTh: 'แส้ไหมพิรุณทมิฬ & มีดสั้นเงาปลิดวิญญาณ',
      leaderNameTh: 'ประมุขเงาพิรุณเย่หมิง',
      powerBase: 1.65,
      specialtyMatIds: ['MAT_HERB_MIST_ORCHID_2', 'MAT_HERB_SNOW_LOTUS_5'],
      tributeDescTh: 'ศิลาวิญญาณ + สมุนไพรหยินเร้นลับและโอสถถอนพิษ'
    },
    {
      codeId: 'FAC_AZURE_PAVILION',
      nameTh: 'ศาลาค่ายกลพู่กันฟ้าคราม',
      aliasNames: ['ศาลาฟ้าครามพิรุธ', 'ศาลาค่ายกลพู่กันฟ้าคราม'],
      orgType: 'ศาลา',
      sectTier: 'LEADING',
      tierLevel: 4,
      alignment: 'NEUTRAL',
      doctrineMode: 'THEMATIC',
      macroRegion: 'EASTERN_PLAINS',
      x: 88, y: 44, baseDays: 5, terrain: 'plains', danger: 3,
      majorPath: 'HEART_SOUL',
      signatureSubs: ['CALLIGRAPHY_PAINTING_SAGE', 'ASTRAL_ARRAY', 'DREAM_ILLUSION_WEAVER'],
      signatureWeaponTypes: ['BRUSH', 'FOCUS'],
      signatureTechs: ['MP_FOCUS_PRIMORDIAL_BRUSH_T7', 'MP_FOCUS_ASTRAL_BANNER_T5', 'ART_V212_SOUL_DREAM_T1'],
      signatureGearTh: 'พู่กันหยกจารึกดารา & จานค่ายกลฟ้าคราม',
      leaderNameTh: 'เจ้านครค่ายกลชิงเทียน',
      powerBase: 2.05,
      specialtyMatIds: ['MAT_ORE_MITHRIL_JADE_4', 'MAT_HERB_DRAGON_GRASS_4'],
      tributeDescTh: 'ศิลาวิญญาณ + หยกค่ายกลและบันทึกปราชญ์'
    },
    {
      codeId: 'FAC_MIST_DRAGON',
      nameTh: 'ตระกูลทวนมังกรหมอกสมุทร',
      aliasNames: ['สำนักมังกรหมอก', 'ตระกูลทวนมังกรหมอกสมุทร'],
      orgType: 'ตระกูล',
      sectTier: 'STANDARD',
      tierLevel: 2,
      alignment: 'NEUTRAL',
      doctrineMode: 'THEMATIC',
      macroRegion: 'SOUTHERN_WATERS',
      x: 62, y: 80, baseDays: 5, terrain: 'water', danger: 3,
      majorPath: 'XIAN',
      signatureSubs: ['CLOUD_DRAGON_SPEAR', 'OCEAN_SOVEREIGN'],
      signatureWeaponTypes: ['SPEAR'],
      signatureTechs: ['PASS_SPEAR_DRAGON_SPINE_T3', 'ART_V212_GOD_OCEAN_T2', 'MP_SPEAR_PHALANX_WALL_T4'],
      signatureGearTh: 'ทวนเกล็ดมังกรหมอก & เกราะวารีสมุทร',
      leaderNameTh: 'ปรมาจารย์มังกรหมอกอวิ๋นหลง',
      powerBase: 1.12,
      specialtyMatIds: ['MAT_HERB_DRAGON_GRASS_4', 'MAT_HERB_JADE_LOTUS_2'],
      tributeDescTh: 'ศิลาวิญญาณ + ไข่มุกบาดาลและสมุนไพรบึงมังกร'
    },

    // --- 11 Additional Organizations Across All 6 Tiers (Tier 1 Small -> Tier 6 Sacred Land) ---
    {
      codeId: 'FAC_GREEN_BAMBOO',
      nameTh: 'สำนักร้อยวิถีไผ่เขียว',
      aliasNames: ['สำนักร้อยวิถีไผ่เขียว'],
      orgType: 'สำนัก',
      sectTier: 'SMALL',
      tierLevel: 1,
      alignment: 'NEUTRAL',
      doctrineMode: 'ECLECTIC',
      macroRegion: 'CENTRAL_HEARTLAND',
      x: 42, y: 62, baseDays: 2, terrain: 'forest', danger: 1,
      majorPath: 'XIAN',
      allowedPaths: ['XIAN', 'BODY', 'SAGE_SUPPORT', 'CRAFT_CREATION', 'BEAST_SOVEREIGN'],
      signatureSubs: ['SWORD_IMMORTAL', 'STAFF_GUARD', 'ELIXIR_DAO', 'MYRIAD_BEAST_PACK'],
      signatureWeaponTypes: ['SWORD', 'STAFF', 'BLADE', 'FIST', 'BOW'],
      signatureTechs: ['ART190_XIAN_001', 'MP_STAFF_VINE_SWEEP_T1', 'PASS_V212_ADAPTIVE_ARSENAL_T2'],
      signatureGearTh: 'ศาสตราและวิชาผสมผสานตามวาสนา (สำนักไร้กรอบจำกัดวิถีเหมือนผู้เล่น)',
      leaderNameTh: 'เจ้าสำนักชิงจู๋',
      powerBase: 0.65,
      specialtyMatIds: ['MAT_HERB_DEW_GRASS_1', 'MAT_HERB_JADE_LOTUS_2'],
      tributeDescTh: 'ศิลาวิญญาณ + สมุนไพรไผ่หยกและใบชาวิญญาณ'
    },
    {
      codeId: 'FAC_IRON_FIST_VALLEY',
      nameTh: 'หุบเขาหมัดวัชระศิลาเหล็ก',
      aliasNames: ['หุบเขาหมัดวัชระศิลาเหล็ก'],
      orgType: 'หุบเขา',
      sectTier: 'SMALL',
      tierLevel: 1,
      alignment: 'RIGHTEOUS',
      doctrineMode: 'THEMATIC',
      macroRegion: 'CENTRAL_HEARTLAND',
      x: 58, y: 58, baseDays: 2, terrain: 'mountain', danger: 1,
      majorPath: 'BODY',
      signatureSubs: ['VAJRA_BODHI', 'TITAN_MOUNTAIN_BODY'],
      signatureWeaponTypes: ['FIST'],
      signatureTechs: ['MP_FIST_IRON_JAB_T1', 'MP_FIST_BAJI_SHOULDER_T3', 'ART190_BODY_003'],
      signatureGearTh: 'สนับมือเหล็กดำทลายผา & เกราะหนักศิลาวัชระ',
      leaderNameTh: 'เจ้าหุบเขาสือถ่า',
      powerBase: 0.72,
      specialtyMatIds: ['MAT_ORE_BLACK_IRON_1', 'MAT_ORE_COLD_STEEL_2'],
      tributeDescTh: 'ศิลาวิญญาณ + แร่เหล็กดำและศิลาขัดเกลา'
    },
    {
      codeId: 'FAC_BLACK_SCORPION',
      nameTh: 'ภาคีพิษแมงป่องทมิฬ',
      aliasNames: ['ภาคีพิษแมงป่องทมิฬ'],
      orgType: 'ภาคี',
      sectTier: 'SMALL',
      tierLevel: 1,
      alignment: 'DEMONIC',
      doctrineMode: 'THEMATIC',
      macroRegion: 'WESTERN_BADLANDS',
      x: 28, y: 58, baseDays: 4, terrain: 'desert', danger: 2,
      majorPath: 'DEMON',
      signatureSubs: ['VENOM_GU_SOVEREIGN', 'POISON_VENOM_CAULDRON'],
      signatureWeaponTypes: ['WHIP', 'FOCUS'],
      signatureTechs: ['ART_V112_DEMON_NIGHT_CLOAK_T1', 'ART_DEMON_SHADOW_STRIKE_T1'],
      signatureGearTh: 'แส้หางแมงป่องพิษ & กระถางกู่พิษร้อยบุปผา',
      leaderNameTh: 'เฒ่าพิษเฮยเซี่ย',
      powerBase: 0.75,
      specialtyMatIds: ['MAT_HERB_VENOM_VINE_3', 'MAT_HERB_MIST_ORCHID_2'],
      tributeDescTh: 'ศิลาวิญญาณ + สมุนไพรพิษและถุงพิษแมงป่อง'
    },
    {
      codeId: 'FAC_WIND_BLADE_POST',
      nameTh: 'ชุมทางจอมยุทธ์พเนจรเมฆาล่อง',
      aliasNames: ['ชุมทางจอมยุทธ์พเนจรเมฆาล่อง'],
      orgType: 'ชุมทาง',
      sectTier: 'STANDARD',
      tierLevel: 2,
      alignment: 'NEUTRAL',
      doctrineMode: 'ECLECTIC',
      macroRegion: 'EASTERN_PLAINS',
      x: 68, y: 42, baseDays: 3, terrain: 'plains', danger: 2,
      majorPath: 'BODY',
      allowedPaths: ['XIAN', 'BODY', 'HEART_SOUL', 'DEMON', 'KARMA_SAMSARA', 'BEAST_SOVEREIGN'],
      signatureSubs: ['OVERLORD_HEAVY_BLADE', 'STAR_ARCHER', 'SIX_PATHS_WHEEL', 'SYMBIOTIC_BEAST_WARRIOR'],
      signatureWeaponTypes: ['BLADE', 'SWORD', 'SPEAR', 'BOW', 'WHIP', 'STAFF'],
      signatureTechs: ['MP_BLADE_SWIFT_DRAW_T1', 'MP_BOW_RAPID_VOLLEY_T2', 'PASS_V212_ADAPTIVE_ARSENAL_T2'],
      signatureGearTh: 'ศาสตราและเคล็ดวิชาหลากหลายที่ผู้ฝึกตนพเนจรได้มาจากแดนลับ',
      leaderNameTh: 'หัวหน้าชุมทางเฟิงเลี่ย',
      powerBase: 1.08,
      specialtyMatIds: ['MAT_ORE_COLD_STEEL_2', 'MAT_HERB_JADE_LOTUS_2'],
      tributeDescTh: 'ศิลาวิญญาณ + ข่าวกรองแดนลับและศาสตราพเนจร'
    },
    {
      codeId: 'FAC_CRIMSON_BONE_CAVE',
      nameTh: 'นิกายมารกระดูกโลหิต',
      aliasNames: ['นิกายมารกระดูกโลหิต'],
      orgType: 'นิกาย',
      sectTier: 'STANDARD',
      tierLevel: 2,
      alignment: 'DEMONIC',
      doctrineMode: 'THEMATIC',
      macroRegion: 'SOUTHERN_WATERS',
      x: 28, y: 82, baseDays: 5, terrain: 'water', danger: 3,
      majorPath: 'DEMON',
      signatureSubs: ['NETHER_GHOST_KING', 'ASHURA_SLAUGHTER_BLADE'],
      signatureWeaponTypes: ['BLADE', 'SPEAR'],
      signatureTechs: ['ART_V212_DEMON_GHOST_T1', 'ART_V212_DEMON_BLOOD_SPEAR_T1'],
      signatureGearTh: 'ดาบกระดูกอสูรโลหิต & ทวนวิญญาณอาฆาต',
      leaderNameTh: 'เจ้านิกายมารกระดูกชื่อกู่',
      powerBase: 1.18,
      specialtyMatIds: ['MAT_HERB_BLOOD_GINSENG_3', 'MAT_ORE_CINNABAR_1'],
      tributeDescTh: 'ศิลาวิญญาณ + โสมโลหิตและผลึกวิญญาณหยิน'
    },
    {
      codeId: 'FAC_THUNDER_PEAK_MONASTERY',
      nameTh: 'อารามพลองโพธิ์อัสนีวัชระ',
      aliasNames: ['อารามพลองโพธิ์อัสนีวัชระ'],
      orgType: 'อาราม',
      sectTier: 'LARGE',
      tierLevel: 3,
      alignment: 'RIGHTEOUS',
      doctrineMode: 'THEMATIC',
      macroRegion: 'NORTHERN_PEAKS',
      x: 48, y: 20, baseDays: 4, terrain: 'mountain', danger: 3,
      majorPath: 'BODY',
      signatureSubs: ['GOLDEN_ARHAT_STAFF', 'STAFF_GUARD', 'THUNDER_BODY'],
      signatureWeaponTypes: ['STAFF', 'FIST'],
      signatureTechs: ['MP_STAFF_ARHAT_EIGHTEEN_T4', 'MP_STAFF_GOLDEN_LIGHT_T2', 'ART_V212_BODY_THUNDER_T3'],
      signatureGearTh: 'พลองทองคำอรหันต์สิบแปดทิศ & จีวรวัชระอสนีบาต',
      leaderNameTh: 'ไต้ซือเหลยอิ๋น',
      powerBase: 1.70,
      specialtyMatIds: ['MAT_ORE_THUNDER_SCORCH_COPPER_3', 'MAT_HERB_BLOOD_GINSENG_3'],
      tributeDescTh: 'ศิลาวิญญาณ + ทองแดงอสนีและโอสถชุบกายาวัชระ'
    },
    {
      codeId: 'FAC_MYRIAD_ORIGIN_VILLA',
      nameTh: 'หมู่ตึกหมื่นวิถีรังสรรค์',
      aliasNames: ['หมู่ตึกหมื่นวิถีรังสรรค์'],
      orgType: 'หมู่ตึก',
      sectTier: 'LEADING',
      tierLevel: 4,
      alignment: 'NEUTRAL',
      doctrineMode: 'ECLECTIC',
      macroRegion: 'EASTERN_PLAINS',
      x: 84, y: 30, baseDays: 5, terrain: 'plains', danger: 3,
      majorPath: 'CRAFT_CREATION',
      allowedPaths: ['CRAFT_CREATION', 'MECH_PUPPET', 'XIAN', 'BODY', 'SAGE_SUPPORT', 'HEART_SOUL'],
      signatureSubs: ['SPIRIT_SWORD_ARTIFICER', 'HEAVENLY_GOLEM', 'ASTRAL_CLOCKWORK_PRIME', 'PILL_FURNACE_IMMORTAL'],
      signatureWeaponTypes: ['FOCUS', 'SWORD', 'BOW', 'ZITHER', 'BRUSH'],
      signatureTechs: ['ART_CRAFT_001', 'ART_MECH_PUPPET_001', 'PASS_V212_ADAPTIVE_ARSENAL_T2'],
      signatureGearTh: 'หุ่นเชิดกลไก ศาสตราหลอมเอง และวิชาหลากหลายตามสิ่งประดิษฐ์ที่ค้นพบ',
      leaderNameTh: 'นายท่านใหญ่ว่านเซี่ยง',
      powerBase: 2.18,
      specialtyMatIds: ['MAT_ORE_MITHRIL_JADE_4', 'MAT_ORE_STAR_COPPER_3'],
      tributeDescTh: 'ศิลาวิญญาณ + หยกมิธริลและพิมพ์เขียวกลจักร'
    },
    {
      codeId: 'FAC_HEAVENLY_VAJRA_TEMPLE',
      nameTh: 'มณฑลพิณสวรรค์วัฏจักรโพธิ์',
      aliasNames: ['มหาวิหารวัชระโพธิ์', 'มณฑลพิณสวรรค์วัฏจักรโพธิ์'],
      orgType: 'มณฑล',
      sectTier: 'HEGEMON',
      tierLevel: 5,
      alignment: 'RIGHTEOUS',
      doctrineMode: 'THEMATIC',
      macroRegion: 'NORTHERN_PEAKS',
      x: 30, y: 18, baseDays: 6, terrain: 'mountain', danger: 4,
      majorPath: 'KARMA_SAMSARA',
      signatureSubs: ['SIX_PATHS_WHEEL', 'LOTUS_MERCY_PURIFIER', 'CELESTIAL_ZITHER_ENVOY'],
      signatureWeaponTypes: ['ZITHER', 'STAFF'],
      signatureTechs: ['ART_KARMA_SAMSARA_001', 'ART_V212_KARMA_MIRROR_T6', 'MP_FOCUS_CELESTIAL_ZITHER_T5'],
      signatureGearTh: 'พิณสวรรค์กงล้อหกภพ & คทาโพธิ์ชำระกรรม',
      leaderNameTh: 'มหาสมณะฝ่าจั้ง',
      powerBase: 3.25,
      specialtyMatIds: ['MAT_ZITHER_PHOENIX_HEARTWOOD_5', 'MAT_HERB_SNOW_LOTUS_5'],
      tributeDescTh: 'ศิลาวิญญาณชั้นสูง + ไม้แก่นหงส์และคัมภีร์วัฏจักร'
    },
    {
      codeId: 'FAC_ASHURA_SLAUGHTER_PALACE',
      nameTh: 'วังอสูรทวนโลหิตซิวหลัว',
      aliasNames: ['วังอสูรสังหารโลหิต', 'วังอสูรทวนโลหิตซิวหลัว'],
      orgType: 'วัง',
      sectTier: 'HEGEMON',
      tierLevel: 5,
      alignment: 'DEMONIC',
      doctrineMode: 'THEMATIC',
      macroRegion: 'WESTERN_BADLANDS',
      x: 12, y: 34, baseDays: 7, terrain: 'desert', danger: 4,
      majorPath: 'DEMON',
      signatureSubs: ['HEAVEN_DEVOURING_DEMON', 'ASHURA_SLAUGHTER_BLADE', 'BLOOD_DRAGON'],
      signatureWeaponTypes: ['SPEAR', 'BLADE'],
      signatureTechs: ['ART_V212_DEMON_BLOOD_SPEAR_T6', 'PASS_BLADE_BLOOD_EDGE_T5', 'ART_V212_KARMA_ASURA_T1'],
      signatureGearTh: 'ทวนโลหิตซิวหลัวผ่าสวรรค์ & เกราะมารกลืนโลหิต',
      leaderNameTh: 'ราชันย์อสูรซิวหลัว',
      powerBase: 3.35,
      specialtyMatIds: ['MAT_ORE_METEOR_IRON_5', 'MAT_HERB_BLOOD_GINSENG_3'],
      tributeDescTh: 'ศิลาวิญญาณชั้นสูง + แร่เหล็กดาวตกและแก่นโลหิตอสูร'
    },
    {
      codeId: 'FAC_CELESTIAL_SWORD_SACRED',
      nameTh: 'ยอดเขากระบี่สวรรค์เทียนเจี้ยน',
      aliasNames: ['ยอดเขากระบี่สวรรค์เทียนเจี้ยน', 'แดนศักดิ์สิทธิ์เทียนเจี้ยน', 'แดนศักดิ์สิทธิ์ยอดเขากระบี่สวรรค์เทียนเจี้ยน'],
      orgType: 'ยอดเขา',
      sectTier: 'SACRED_LAND',
      tierLevel: 6,
      alignment: 'RIGHTEOUS',
      isAllianceLeader: true,
      allianceTitleTh: 'ประมุขสมาพันธ์คุณธรรมฝ่ายธรรมะ',
      doctrineMode: 'THEMATIC',
      macroRegion: 'NORTHERN_PEAKS',
      x: 46, y: 8, baseDays: 7, terrain: 'mountain', danger: 5,
      majorPath: 'XIAN',
      signatureSubs: ['SWORD_IMMORTAL', 'PURE_SWORD_SAINT', 'MIND_SWORD_TELEKINESIS'],
      signatureWeaponTypes: ['SWORD'],
      signatureTechs: ['ART_V212_XIAN_PHANTOM_T6', 'PASS_SWORD_HEART_CLARITY_T5', 'ART190_XIAN_009'],
      signatureGearTh: 'กระบี่เซียนเทียนเจี้ยนบัญชาสวรรค์ & อาภรณ์ศักดิ์สิทธิ์เก้าเมฆา',
      leaderNameTh: 'มหาเซียนกระบี่เทียนหยวน',
      powerBase: 4.80,
      specialtyMatIds: ['MAT_ORE_MITHRIL_JADE_4', 'MAT_ORE_METEOR_IRON_5'],
      tributeDescTh: 'ศิลาวิญญาณระดับเซียน + ผลึกกระบี่สวรรค์และคัมภีร์แดนศักดิ์สิทธิ์'
    },
    {
      codeId: 'FAC_NETHER_BLOOD_SACRED',
      nameTh: 'ภาคีมารกลืนสวรรค์เก้าโลหิต',
      aliasNames: ['ภาคีมารกลืนสวรรค์เก้าโลหิต', 'แดนศักดิ์สิทธิ์มารสวรรค์เก้าโลหิต', 'แดนศักดิ์สิทธิ์ภาคีมารกลืนสวรรค์เก้าโลหิต'],
      orgType: 'ภาคี',
      sectTier: 'SACRED_LAND',
      tierLevel: 6,
      alignment: 'DEMONIC',
      isAllianceLeader: true,
      allianceTitleTh: 'ประมุขสูงสุดภาคีมารครองภพฝ่ายอธรรม',
      doctrineMode: 'THEMATIC',
      macroRegion: 'WESTERN_BADLANDS',
      x: 8, y: 22, baseDays: 8, terrain: 'desert', danger: 5,
      majorPath: 'DEMON',
      signatureSubs: ['HEAVEN_DEVOURING_DEMON', 'NETHER_GHOST_KING', 'VENOM_GU_SOVEREIGN'],
      signatureWeaponTypes: ['BLADE', 'WHIP', 'SPEAR'],
      signatureTechs: ['ART_V212_DEMON_GHOST_T6', 'ART_V212_DEMON_BLOOD_SPEAR_T6', 'ART_CROSS_V208_005'],
      signatureGearTh: 'ดาบมารกลืนสวรรค์เก้าโลหิต & แส้กระดูกยมโลก',
      leaderNameTh: 'จอมมารบรรพกาลจิ่วหมิง',
      powerBase: 4.90,
      specialtyMatIds: ['MAT_WHIP_KARMIC_RED_SILK_5', 'MAT_ORE_METEOR_IRON_5'],
      tributeDescTh: 'ศิลาวิญญาณระดับมารสวรรค์ + ไหมแดงกรรมโลหิตและศาสตรามารบรรพกาล'
    }
  ]);
  X.SECT_FACTION_COORDS = Object.fromEntries(X.CANONICAL_SECTS.map(c => [c.codeId, c]));

  X.WORLD_ROUTES = Object.freeze([
    { from: 'NODE_HOME_SECT', to: 'forest', days: 3, terrain: 'forest' },
    { from: 'NODE_HOME_SECT', to: 'NINE_DAO_PAGODA', days: 2, terrain: 'mountain' },
    { from: 'NODE_HOME_SECT', to: 'mountain', days: 4, terrain: 'mountain' },
    { from: 'NODE_HOME_SECT', to: 'plains', days: 3, terrain: 'plains' },
    { from: 'NODE_HOME_SECT', to: 'water', days: 4, terrain: 'water' },
    { from: 'NODE_HOME_SECT', to: 'desert', days: 6, terrain: 'desert' },
    { from: 'mountain', to: 'ruins', days: 3, terrain: 'mountain' },
    { from: 'mountain', to: 'SANCTUM_SWORD_ABYSS', days: 2, terrain: 'mountain' },
    { from: 'ruins', to: 'SANCTUM_BLOOD_VAJRA', days: 2, terrain: 'mountain' },
    { from: 'mountain', to: 'MINE_CELESTIAL_STONE', days: 2, terrain: 'mountain' },
    { from: 'mountain', to: 'REALM_METAL', days: 2, terrain: 'mountain' },
    { from: 'ruins', to: 'REALM_EARTH', days: 2, terrain: 'mountain' },
    { from: 'water', to: 'REG_SLEEPING_DRAGON_LAKE', days: 2, terrain: 'water' },
    { from: 'water', to: 'VALLEY_IMMORTAL_MARSH', days: 2, terrain: 'water' },
    { from: 'water', to: 'TOLL_SOUTHERN_WATERWAY', days: 2, terrain: 'water' },
    { from: 'water', to: 'REALM_WATER', days: 2, terrain: 'water' },
    { from: 'plains', to: 'NODE_JIANGNAN_CROSSWAY', days: 2, terrain: 'plains' },
    { from: 'plains', to: 'VALLEY_MILLENNIAL_HERB', days: 2, terrain: 'forest' },
    { from: 'NODE_JIANGNAN_CROSSWAY', to: 'TOLL_JIANGNAN_CROSSWAY', days: 1, terrain: 'plains' },
    { from: 'plains', to: 'REALM_WOOD', days: 2, terrain: 'forest' },
    { from: 'desert', to: 'SANCTUM_ASTRAL_DIVINE', days: 2, terrain: 'desert' },
    { from: 'desert', to: 'MINE_STARFALL_CRAG', days: 2, terrain: 'desert' },
    { from: 'desert', to: 'REALM_FIRE', days: 2, terrain: 'desert' }
  ]);

  X.findSect = (W, sectOrId) => {
    if (!W || !W.world || !sectOrId) return null;
    X.ensureWorldTopology(W);
    if (typeof sectOrId === 'object' && sectOrId.id) return sectOrId;
    const key = String(sectOrId);
    const matchFn = s => s && (
      s.id === key ||
      s.factionId === key ||
      s.canonicalId === key ||
      s.code === key ||
      s.nodeId === key ||
      s.nameTh === key ||
      s.rawNameTh === key ||
      (Array.isArray(s.aliasNames) && s.aliasNames.includes(key))
    );
    const inActive = (W.world.sects || []).find(matchFn);
    if (inActive) return inActive;
    const inAll = (W.world.allSects || []).find(matchFn);
    return inAll || null;
  };

  function enrichSectWithCanon(s, canon, f) {
    if (!s || !canon) return s;
    const tierSpec = X.SECT_TIER_DEFS[canon.sectTier] || X.SECT_TIER_DEFS.STANDARD;
    const alignKey = canon.alignment || (f && f.alignment) || s.alignment || 'NEUTRAL';
    // Enforce hard rule: NEUTRAL organizations never hold SACRED_LAND / supreme alliance leadership
    const effectiveTierId = (alignKey === 'NEUTRAL' && tierSpec.id === 'SACRED_LAND') ? 'LEADING' : tierSpec.id;
    const effTierSpec = X.SECT_TIER_DEFS[effectiveTierId] || tierSpec;
    const alignSpec = X.ALIGNMENT_DEFS[alignKey] || X.ALIGNMENT_DEFS.NEUTRAL;

    s.canonicalId = canon.codeId;
    s.orgType = canon.orgType || 'สำนัก';
    s.doctrineMode = canon.doctrineMode || 'THEMATIC';
    s.doctrineModeTh = s.doctrineMode === 'ECLECTIC'
      ? 'สายผสมผสานไร้กรอบ (เปิดรับทุกวิถี/ศาสตราตามวาสนาเหมือนผู้เล่น)'
      : ('สายเอกลักษณ์เฉพาะทาง (' + canon.majorPath + ' · ' + (canon.signatureWeaponTypes || ['SWORD']).join('/') + ')');
    s.sectTier = effTierSpec.id;
    s.tierLevel = effTierSpec.tierLevel;
    s.tierNameTh = effTierSpec.nameTh;
    s.tierBadgeTh = effTierSpec.badgeTh;
    s.alignment = alignSpec.id;
    s.alignmentLabelTh = alignSpec.nameTh;
    s.isAllianceLeader = Boolean(alignSpec.hasSupremeLeader && canon.isAllianceLeader);
    s.allianceTitleTh = s.isAllianceLeader ? (canon.allianceTitleTh || ('ผู้นำสูงสุด' + alignSpec.nameTh)) : null;
    s.majorPath = canon.majorPath || s.majorPath || (f && f.majorPath) || 'XIAN';
    s.allowedPaths = Array.isArray(canon.allowedPaths) ? canon.allowedPaths.slice() : [s.majorPath];
    s.signatureSubs = Array.isArray(canon.signatureSubs) ? canon.signatureSubs.slice() : [];
    s.signatureWeaponTypes = Array.isArray(canon.signatureWeaponTypes) ? canon.signatureWeaponTypes.slice() : ['SWORD'];
    s.signatureTechs = Array.isArray(canon.signatureTechs) ? canon.signatureTechs.slice() : [];
    s.signatureGearTh = canon.signatureGearTh || 'ศาสตราประจำสำนัก';
    s.aliasNames = Array.isArray(canon.aliasNames) ? canon.aliasNames.slice() : [canon.nameTh];
    s.macroRegion = s.macroRegion || canon.macroRegion;
    s.x = Number.isFinite(s.x) ? s.x : canon.x;
    s.y = Number.isFinite(s.y) ? s.y : canon.y;
    s.baseDays = Number.isFinite(s.baseDays) ? s.baseDays : canon.baseDays;
    s.tributeDescTh = s.tributeDescTh || canon.tributeDescTh;
    s.leaderNameTh = s.leaderNameTh || canon.leaderNameTh || (f && f.leaderNameTh) || 'เจ้าสำนัก';
    if (Array.isArray(canon.specialtyMatIds) && canon.specialtyMatIds.length) { const merged = canon.specialtyMatIds.concat(Array.isArray(s.specialtyMatIds) ? s.specialtyMatIds : []); s.specialtyMatIds = Array.from(new Set(merged)); } else if (!Array.isArray(s.specialtyMatIds) || !s.specialtyMatIds.length) { s.specialtyMatIds = (f && f.specialtyMatIds ? f.specialtyMatIds : []).slice(); }
    s.nodeId = s.nodeId || ('NODE_SECT_' + canon.codeId);
    if (!Number.isFinite(s.power) || s.power <= 0) s.power = canon.powerBase || effTierSpec.basePower;
    if (!Number.isFinite(s.influence)) s.influence = effTierSpec.influenceBase;
    return s;
  }

  X.ensureWorldTopology = W => {
    if (!W || !W.world) return null;
    const w = W.world;
    const factions = (JD && JD.EXPANSION && Array.isArray(JD.EXPANSION.factions)) ? JD.EXPANSION.factions : [];
    if (!Array.isArray(w.allSects)) w.allSects = [];
    // Synchronize existing W.world.sects with canonical definitions without consuming W.rng
    (w.sects || []).forEach((s, idx) => {
      if (!s) return;
      const canon = X.CANONICAL_SECTS.find(c =>
        c.nameTh === s.nameTh ||
        c.codeId === s.canonicalId ||
        c.codeId === s.factionId ||
        (Array.isArray(c.aliasNames) && c.aliasNames.includes(s.nameTh))
      ) || X.CANONICAL_SECTS[idx % X.CANONICAL_SECTS.length];
      const f = factions.find(fc => fc.id === s.factionId) || factions[idx % Math.max(1, factions.length)];
      if (f) {
        s.factionId = s.factionId || f.id;
        s.code = s.code || f.code;
        s.factionNameTh = s.factionNameTh || canon.nameTh || f.nameTh;
        s.shortTh = s.shortTh || f.shortTh;
        s.icon = s.icon || f.icon;
        s.specialtyTh = s.specialtyTh || f.specialtyTh;
      }
      s.nameTh = canon.nameTh;
      enrichSectWithCanon(s, canon, f);
      if (s.treaty === 'VASSAL_TREATY') s.isVassal = true;
      if (s.isVassal) {
        if (!Number.isFinite(s.loyalty)) s.loyalty = 68;
        s.suzerainId = 'PLAYER';
        s.bannerTh = s.bannerTh || '[ สำนักบริวารในอาณัติ ]';
        s.tributePolicy = s.tributePolicy || 'STANDARD';
      } else {
        if (!Number.isFinite(s.loyalty)) s.loyalty = 50;
      }
      const exIdx = w.allSects.findIndex(x => x && (x.id === s.id || x.canonicalId === canon.codeId || x.nameTh === canon.nameTh));
      if (exIdx >= 0) w.allSects[exIdx] = Object.assign(w.allSects[exIdx], s);
      if (exIdx >= 0) w.allSects[exIdx] = s;
      else w.allSects.push(s);
    });
    // Ensure all 19 canonical Jianghu organizations exist in w.allSects across all 6 tiers & 3 alignments
    X.CANONICAL_SECTS.forEach((canon, idx) => {
      const existing = w.allSects.find(s => s && (s.canonicalId === canon.codeId || s.nameTh === canon.nameTh || (Array.isArray(canon.aliasNames) && canon.aliasNames.includes(s.nameTh))));
      if (existing) {
        enrichSectWithCanon(existing, canon, factions[idx % Math.max(1, factions.length)]);
        return;
      }
      const f = factions[idx % Math.max(1, factions.length)] || {};
      const tierSpec = X.SECT_TIER_DEFS[canon.sectTier] || X.SECT_TIER_DEFS.STANDARD;
      const extraSect = {
        id: 'S' + w.allSects.length,
        canonicalId: canon.codeId,
        factionId: canon.codeId,
        code: canon.codeId,
        nameTh: canon.nameTh,
        factionNameTh: canon.nameTh,
        shortTh: canon.nameTh.replace(/^แดนศักดิ์สิทธิ์|^สำนัก|^ตระกูล|^หอ|^ศาลา|^หุบเขา|^นิกาย|^ภาคี|^หมู่ตึก|^ป้อม|^ชุมทาง|^อาราม|^มณฑล|^วัง/, ''),
        icon: canon.sectTier === 'SACRED_LAND' ? '👑' : canon.sectTier === 'HEGEMON' ? '🏯' : canon.doctrineMode === 'ECLECTIC' ? '☯️' : (f.icon || '🏯'),
        alignment: canon.alignment || 'NEUTRAL',
        alignmentLabelTh: (X.ALIGNMENT_DEFS[canon.alignment] || X.ALIGNMENT_DEFS.NEUTRAL).nameTh,
        majorPath: canon.majorPath,
        specialtyTh: canon.signatureGearTh + ' · ' + canon.tributeDescTh,
        leaderNameTh: canon.leaderNameTh,
        specialtyMatIds: canon.specialtyMatIds.slice(),
        tributeDescTh: canon.tributeDescTh,
        treatyPref: canon.alignment === 'DEMONIC' ? 'NON_AGGRESSION' : 'TRADE_PACT',
        doctrineBonus: {},
        power: canon.powerBase || tierSpec.basePower,
        attitude: canon.alignment === 'DEMONIC' ? -15 : canon.alignment === 'RIGHTEOUS' ? 10 : 5,
        style: canon.alignment === 'DEMONIC' ? 'ก้าวร้าว' : canon.alignment === 'RIGHTEOUS' ? 'เป็นธรรม' : 'ใฝ่สงบ',
        contact: 0,
        treaty: 'NONE',
        influence: tierSpec.influenceBase,
        loyalty: 50,
        isVassal: false,
        macroRegion: canon.macroRegion,
        x: canon.x,
        y: canon.y,
        baseDays: canon.baseDays,
        nodeId: 'NODE_SECT_' + canon.codeId
      };
      enrichSectWithCanon(extraSect, canon, f);
      w.allSects.push(extraSect);
    });
    w.jianghuSects = w.allSects;
    if (X.ensureJianghuFigures) X.ensureJianghuFigures(W);
    if (X.ensureWanderingLegends) X.ensureWanderingLegends(W);
    if (X.evaluateAllianceLeadership) X.evaluateAllianceLeadership(W);
    if (!Array.isArray(w.chronicles)) w.chronicles = [];
    if (!Array.isArray(w.secretRealms)) w.secretRealms = [];
    if (!w._initChronicleDone && !(w.chronicleSeq > 0) && X.recordChronicle && w.grandPolitics && w.grandPolitics.alliances) {
      w._initChronicleDone = true;
      const rAl = w.grandPolitics.alliances.RIGHTEOUS || {};
      const dAl = w.grandPolitics.alliances.DEMONIC || {};
      const leg0 = (w.wanderingLegends && w.wanderingLegends[0]) ? w.wanderingLegends[0].titleAndNameTh : "ยอดคนพเนจร";
      X.recordChronicle(W, {
        category: "FACTION",
        icon: "📜",
        titleTh: "เปิดศักราชยุทธภพ: สามขั้วอำนาจและสิบเก้าสำนักประชันบารมี",
        storyTh: "บัดนี้ยุทธภพแบ่งออกเป็น 3 ขั้วอุดมการณ์ใหญ่ — ฝ่ายธรรมะนำโดย「" + (rAl.leaderSectNameTh || "ยอดเขากระบี่สวรรค์เทียนเจี้ยน") + "」(ประมุข: " + (rAl.leaderMasterNameTh || "-") + " · แนวทาง" + (rAl.doctrineNameTh || "-") + ") ประจันหน้ากับฝ่ายอธรรมซึ่งนำโดย「" + (dAl.leaderSectNameTh || "ภาคีมารกลืนสวรรค์เก้าโลหิต") + "」(ประมุข: " + (dAl.leaderMasterNameTh || "-") + " · แนวทาง" + (dAl.doctrineNameTh || "-") + ") ขณะที่สำนักอิสระสายกลางและผู้บำเพ็ญในตำนานอย่าง「" + leg0 + "」ต่างเคลื่อนไหวตามวาสนาและชะตากรรม!",
        combatBreakdownTh: "องค์กรในยุทธภพ 19 แห่ง (6 ระดับชั้น) · ผู้บำเพ็ญในตำนานพเนจร 5 คน · สุ่มชื่อและนิสัยใหม่ตามเมล็ดโลก",
        consequenceTh: "ทุกการตัดสินใจ การสืบทอดตำแหน่ง และศึกชิงแดนลับโบราณจะดำเนินไปเองตามธรรมชาติของนิสัยตัวละคร",
        quiet: true
      });
    }

    // Hydrate Grand Alliance Politics state
    if (!w.grandPolitics || typeof w.grandPolitics !== 'object') w.grandPolitics = {};
    if (!w.grandPolitics.righteousLeaderCodeId) w.grandPolitics.righteousLeaderCodeId = 'FAC_CELESTIAL_SWORD_SACRED';
    if (!w.grandPolitics.demonicLeaderCodeId) w.grandPolitics.demonicLeaderCodeId = 'FAC_NETHER_BLOOD_SACRED';
    if (w.grandPolitics.neutralHasLeader === undefined) w.grandPolitics.neutralHasLeader = false;
    if (!Array.isArray(w.grandPolitics.interSectWars)) w.grandPolitics.interSectWars = [];
    if (!w.grandPolitics.discipleEncounters) w.grandPolitics.discipleEncounters = { total: 0, clashes: 0, exchanges: 0, oppositeAlignmentClashes: 0, sameAlignmentClashes: 0 };

    // Hydrate Contestable Resource Nodes
    if (!w.resourceNodes || typeof w.resourceNodes !== 'object' || Array.isArray(w.resourceNodes)) w.resourceNodes = {};
    Object.values(X.RESOURCE_NODE_DEFS).forEach(def => {
      let rn = w.resourceNodes[def.id];
      if (!rn || typeof rn !== 'object') {
        const ownerSect = w.allSects.find(s => s && (s.factionId === def.defaultOwnerFactionId || s.canonicalId === def.defaultOwnerFactionId));
        rn = w.resourceNodes[def.id] = {
          id: def.id,
          nameTh: def.nameTh,
          category: def.category,
          categoryTh: def.categoryTh,
          icon: def.icon,
          macroRegion: def.macroRegion,
          terrain: def.terrain,
          danger: def.danger,
          x: def.x,
          y: def.y,
          baseDays: def.baseDays,
          dailyStones: def.dailyStones,
          seasonalStones: def.seasonalStones,
          mats: def.mats.slice(),
          ownerSectId: ownerSect ? ownerSect.id : 'NEUTRAL',
          ownerFactionId: def.defaultOwnerFactionId,
          ownerNameTh: ownerSect ? ownerSect.nameTh : 'กองกำลังอิสระ',
          claimedDay: 0,
          lastHarvestDay: 0,
          accumulatedStones: 0,
          garrison: {
            discipleIds: [],
            beastUid: null,
            defensePower: def.garrisonPowerBase,
            yieldMultiplier: 1.0,
            bastionActive: false
          }
        };
      }
      if (!rn.garrison || typeof rn.garrison !== 'object') {
        rn.garrison = { discipleIds: [], beastUid: null, defensePower: def.garrisonPowerBase, yieldMultiplier: 1.0, bastionActive: false };
      }
    });

    // Hydrate Timed World Anomalies & Siege/Distress logs
    if (!Array.isArray(w.anomalies)) w.anomalies = [];
    if (!Array.isArray(w.sieges)) w.sieges = [];
    if (!Array.isArray(w.vassalDistressCalls)) w.vassalDistressCalls = [];

    // Hydrate Map Topology & Fog of War
    if (!w.mapTopology || typeof w.mapTopology !== 'object') {
      w.mapTopology = {
        version: '2.0.18',
        selectedNodeId: 'NODE_HOME_SECT',
        discoveredRegions: {
          CENTRAL_HEARTLAND: true,
          NORTHERN_PEAKS: true,
          SOUTHERN_WATERS: true,
          EASTERN_PLAINS: true,
          WESTERN_BADLANDS: false
        },
        nodes: {}
      };
    }
    const topo = w.mapTopology;
    if (!topo.discoveredRegions || typeof topo.discoveredRegions !== 'object') {
      topo.discoveredRegions = { CENTRAL_HEARTLAND: true, NORTHERN_PEAKS: true, SOUTHERN_WATERS: true, EASTERN_PLAINS: true, WESTERN_BADLANDS: false };
    }
    const fsSummary = (CULT && CULT.sectFourSymbolSummary) ? CULT.sectFourSymbolSummary(W) : null;
    if (fsSummary && fsSummary.hasVermilionPhoenix) {
      Object.keys(X.WORLD_REGIONS).forEach(rk => { topo.discoveredRegions[rk] = true; });
      topo.phoenixSkyVision = true;
    }

    // Build unified node dictionary
    const nodes = {};
    nodes.NODE_HOME_SECT = {
      id: 'NODE_HOME_SECT',
      kind: 'HOME_SECT',
      nameTh: (W.sect && W.sect.name) ? (/^สำนัก/.test(W.sect.name) ? W.sect.name : 'สำนัก' + W.sect.name) : 'สำนักของเรา (หุบเขาฟ้าประทาน)',
      icon: '🏯',
      macroRegion: 'CENTRAL_HEARTLAND',
      terrain: 'forest',
      danger: 0,
      x: 50, y: 50,
      baseDays: 0,
      ownerSectId: 'PLAYER',
      ownerNameTh: 'สำนักของเรา',
      descTh: 'ที่ตั้งหลักของสำนัก ศูนย์บัญชาการยุทธภพและค่ายกลพิทักษ์สำนัก'
    };

    const regionCoords = {
      forest: { macroRegion: 'CENTRAL_HEARTLAND', x: 40, y: 56, icon: '🌲' },
      plains: { macroRegion: 'EASTERN_PLAINS', x: 74, y: 48, icon: '🌾' },
      mountain: { macroRegion: 'NORTHERN_PEAKS', x: 44, y: 22, icon: '⛰️' },
      desert: { macroRegion: 'WESTERN_BADLANDS', x: 20, y: 54, icon: '🏜️' },
      water: { macroRegion: 'SOUTHERN_WATERS', x: 46, y: 78, icon: '🌊' },
      ruins: { macroRegion: 'NORTHERN_PEAKS', x: 58, y: 16, icon: '🏛️' },
      REG_SLEEPING_DRAGON_LAKE: { macroRegion: 'SOUTHERN_WATERS', x: 36, y: 84, icon: '🐉' },
      SRC110_MW_ENV_01_ANCIENT_CANOPY: { macroRegion: 'EASTERN_PLAINS', x: 70, y: 26, icon: '🌲' },
      SRC110_MW_ENV_02_MIASMA_MANGROVE: { macroRegion: 'SOUTHERN_WATERS', x: 30, y: 88, icon: '🌿' },
      SRC110_MW_ENV_03_FROZEN_HIGHLANDS: { macroRegion: 'NORTHERN_PEAKS', x: 55, y: 10, icon: '❄️' },
      SRC110_MW_ENV_04_VOLCANIC_CALDERA: { macroRegion: 'WESTERN_BADLANDS', x: 16, y: 30, icon: '🌋' },
      SRC110_MW_ENV_05_MINERAL_DESERT: { macroRegion: 'WESTERN_BADLANDS', x: 12, y: 58, icon: '🏜️' },
      SRC110_MW_ENV_11_CELESTIAL_GARDEN_RUINS: { macroRegion: 'NORTHERN_PEAKS', x: 70, y: 17, icon: '🏛️' }
    };
    (X.REGIONS || []).forEach(r => {
      if (!r || !r.id) return;
      const rc = regionCoords[r.id] || { macroRegion: 'CENTRAL_HEARTLAND', x: 55, y: 55, icon: '🧭' };
      nodes[r.id] = {
        id: r.id,
        kind: 'EXPEDITION_REGION',
        nameTh: r.nameTh,
        icon: rc.icon,
        macroRegion: rc.macroRegion,
        terrain: r.terrain || 'forest',
        danger: r.danger || 1,
        x: rc.x, y: rc.y,
        baseDays: r.days || 3,
        ownerSectId: 'NEUTRAL',
        ownerNameTh: 'เขตสำรวจยุทธภพ',
        descTh: r.desc || ('พื้นที่สำรวจ ล่าสัตว์อสูร เก็บสมุนไพร และผจญโชควาสนา (อันตรายระดับ ' + (r.danger || 1) + ')')
      };
    });

    nodes.NINE_DAO_PAGODA = {
      id: 'NINE_DAO_PAGODA',
      kind: 'PAGODA',
      nameTh: 'เจดีย์เก้าวิถีทดสอบสัจธรรม',
      icon: '🗼',
      macroRegion: 'CENTRAL_HEARTLAND',
      terrain: 'mountain',
      danger: 3,
      x: 52, y: 38,
      baseDays: 2,
      ownerSectId: 'NEUTRAL',
      ownerNameTh: 'แดนทดสอบบรรพกาล',
      descTh: 'มหาเจดีย์สี่สิบสามชั้นพิสูจน์สัจธรรมแห่งมรรคา ปลดล็อกชุดสัจธรรมและเคล็ดวิชาประจำสาย'
    };

    nodes.NODE_JIANGNAN_CROSSWAY = {
      id: 'NODE_JIANGNAN_CROSSWAY',
      kind: 'TRADE_HUB',
      nameTh: 'ชุมทางการค้าหุบเขาสองแคว',
      icon: '🏮',
      macroRegion: 'EASTERN_PLAINS',
      terrain: 'plains',
      danger: 1,
      x: 84, y: 56,
      baseDays: 3,
      ownerSectId: 'NEUTRAL',
      ownerNameTh: 'สมาคมการค้าหุบเขาสองแคว',
      descTh: 'ศูนย์กลางแลกเปลี่ยนสินค้า คาราวานโอสถ และข่าวสารยุทธภพแดนตะวันออก'
    };

    const sanctumCoords = {
      SANCTUM_SWORD_ABYSS: { macroRegion: 'NORTHERN_PEAKS', x: 35, y: 15, icon: '🗡️', nameTh: 'วิหารกระบี่สุญตาบรรพกาล', danger: 4, baseDays: 4 },
      SANCTUM_BLOOD_VAJRA: { macroRegion: 'NORTHERN_PEAKS', x: 66, y: 20, icon: '⛩️', nameTh: 'มหาวิหารวัชระโลหิต', danger: 4, baseDays: 4 },
      SANCTUM_ASTRAL_DIVINE: { macroRegion: 'WESTERN_BADLANDS', x: 14, y: 40, icon: '🕍', nameTh: 'แท่นบูชาดาราเทวะ', danger: 4, baseDays: 5 },
      SANCTUM_MYRIAD_BEAST_TOTEM: { macroRegion: 'NORTHERN_PEAKS', x: 72, y: 27, icon: '🐉', nameTh: 'มหาวิหารหมื่นอสูรและคีตเวทย์โบราณ', danger: 4, baseDays: 1.5 }
    };
    Object.entries(sanctumCoords).forEach(([sid, sc]) => {
      nodes[sid] = {
        id: sid,
        kind: 'SANCTUM',
        nameTh: sc.nameTh,
        icon: sc.icon,
        macroRegion: sc.macroRegion,
        terrain: sc.macroRegion === 'WESTERN_BADLANDS' ? 'desert' : 'mountain',
        danger: sc.danger,
        x: sc.x, y: sc.y,
        baseDays: sc.baseDays,
        ownerSectId: 'NEUTRAL',
        ownerNameTh: 'ผู้พิทักษ์ชุดสัจธรรมโบราณ',
        descTh: 'วิหารโบราณ 3 ชั้น ดรอปผลึกหลอมศาสตราและคัมภีร์ระดับตำนาน'
      };
    });

    const realmCoords = {
      REALM_METAL: { macroRegion: 'NORTHERN_PEAKS', x: 28, y: 24, icon: '⚡', nameTh: 'แดนโลหะบรรพกาล', catalystId: 'CAT_PRIMORDIAL_METAL' },
      REALM_WOOD: { macroRegion: 'EASTERN_PLAINS', x: 82, y: 38, icon: '🌳', nameTh: 'แดนพฤกษากำเนิดชีพ', catalystId: 'CAT_PRIMORDIAL_WOOD' },
      REALM_WATER: { macroRegion: 'SOUTHERN_WATERS', x: 56, y: 86, icon: '❄️', nameTh: 'แดนวารีเหมันต์', catalystId: 'CAT_PRIMORDIAL_WATER' },
      REALM_FIRE: { macroRegion: 'WESTERN_BADLANDS', x: 16, y: 66, icon: '🔥', nameTh: 'แดนเพลิงชาด', catalystId: 'CAT_PRIMORDIAL_FIRE' },
      REALM_EARTH: { macroRegion: 'NORTHERN_PEAKS', x: 62, y: 28, icon: '🪨', nameTh: 'แดนปฐพีหยกเร้น', catalystId: 'CAT_PRIMORDIAL_EARTH' }
    };
    Object.entries(realmCoords).forEach(([rid, rc]) => {
      const catTh = (ECO && ECO.REFINEMENT_CATALYSTS && ECO.REFINEMENT_CATALYSTS[rc.catalystId] && ECO.REFINEMENT_CATALYSTS[rc.catalystId].nameTh) || rc.catalystId;
      nodes[rid] = {
        id: rid,
        kind: 'ELEMENTAL_REALM',
        nameTh: rc.nameTh,
        icon: rc.icon,
        macroRegion: rc.macroRegion,
        terrain: 'mountain',
        danger: 3,
        x: rc.x, y: rc.y,
        baseDays: 4,
        catalystId: rc.catalystId,
        ownerSectId: 'NEUTRAL',
        ownerNameTh: 'แดนปฐมภูมิเบญจธาตุ',
        descTh: 'แดนลับเบญจธาตุ แหล่งกำเนิดแก่นปฐมธาตุ「' + catTh + '」สำหรับปลุกสายเลือด 4 เทพอสูร'
      };
    });

    // Neighboring Sects (All 19 Canonical Jianghu Organizations across 6 Tiers)
    w.allSects.forEach(s => {
      if (!s) return;
      const coord = X.SECT_FACTION_COORDS[s.canonicalId] || X.SECT_FACTION_COORDS[s.factionId] || { macroRegion: s.macroRegion || 'NORTHERN_PEAKS', x: s.x || 40, y: s.y || 30, baseDays: s.baseDays || 5, terrain: 'mountain', danger: 3, tributeDescTh: 'ศิลาวิญญาณและวัตถุดิบประจำสำนัก' };
      const nid = s.nodeId || ('NODE_SECT_' + (s.canonicalId || s.factionId || s.id));
      s.nodeId = nid;
      nodes[nid] = {
        id: nid,
        sectId: s.id,
        factionId: s.factionId,
        canonicalId: s.canonicalId,
        orgType: s.orgType || 'สำนัก',
        sectTier: s.sectTier || 'STANDARD',
        tierLevel: s.tierLevel || 2,
        tierNameTh: s.tierNameTh || 'สำนักทั่วไป',
        tierBadgeTh: s.tierBadgeTh || 'ระดับ 2 · สำนักทั่วไป',
        alignment: s.alignment || 'NEUTRAL',
        alignmentLabelTh: s.alignmentLabelTh || 'สายกลาง',
        doctrineMode: s.doctrineMode || 'THEMATIC',
        doctrineModeTh: s.doctrineModeTh || '',
        isAllianceLeader: !!s.isAllianceLeader,
        kind: 'NEIGHBOR_SECT',
        nameTh: s.nameTh + (s.isVassal ? ' [สำนักบริวาร]' : ''),
        rawNameTh: s.nameTh,
        icon: s.icon || '🏯',
        macroRegion: coord.macroRegion,
        terrain: coord.terrain,
        danger: coord.danger,
        x: coord.x, y: coord.y,
        baseDays: coord.baseDays,
        ownerSectId: s.isVassal ? 'PLAYER' : s.id,
        ownerNameTh: s.isVassal ? ('สำนักบริวารในอาณัติ (' + s.nameTh + ')') : s.nameTh,
        treaty: s.treaty || 'NONE',
        attitude: s.attitude || 0,
        power: s.power || 1,
        loyalty: s.loyalty != null ? s.loyalty : 50,
        isVassal: !!s.isVassal,
        bannerTh: s.bannerTh || null,
        tributeDescTh: coord.tributeDescTh,
        descTh: '[' + (s.tierNameTh || 'สำนัก') + ' · ' + (s.alignmentLabelTh || 'สายกลาง') + '] ' + (s.signatureGearTh || s.specialtyTh || 'สำนักในยุทธภพ') + ' · ประมุข: ' + (s.leaderNameTh || 'ไม่ระบุ')
      };
    });

    // Contestable Resource Nodes
    Object.values(w.resourceNodes).forEach(rn => {
      nodes[rn.id] = {
        id: rn.id,
        kind: 'RESOURCE_NODE',
        category: rn.category,
        categoryTh: rn.categoryTh,
        nameTh: rn.nameTh,
        icon: rn.icon,
        macroRegion: rn.macroRegion,
        terrain: rn.terrain,
        danger: rn.danger,
        x: rn.x, y: rn.y,
        baseDays: rn.baseDays,
        ownerSectId: rn.ownerSectId,
        ownerNameTh: rn.ownerSectId === 'PLAYER' ? 'สำนักของเรา [ยึดครองแล้ว]' : rn.ownerNameTh,
        dailyStones: rn.dailyStones,
        seasonalStones: rn.seasonalStones,
        mats: rn.mats,
        garrison: rn.garrison,
        descTh: X.RESOURCE_NODE_DEFS[rn.id] ? X.RESOURCE_NODE_DEFS[rn.id].descTh : rn.nameTh
      };
    });

    // Active Anomalies as temporary map nodes
    (w.anomalies || []).filter(a => a && !a.resolved && !a.expired).forEach(a => {
      nodes[a.id] = {
        id: a.id,
        anomalyId: a.id,
        kind: 'WORLD_ANOMALY',
        nameTh: a.nameTh,
        icon: a.icon || '☄️',
        macroRegion: a.macroRegion || 'NORTHERN_PEAKS',
        terrain: a.terrain || 'mountain',
        danger: a.danger || 4,
        x: a.x || 52, y: a.y || 26,
        baseDays: a.baseDays || 5,
        ownerSectId: 'CONTESTED',
        ownerNameTh: 'วาสนาจำกัดเวลา (เหลือ ' + Math.max(0, (a.expiresDay || 0) - (W.day || 0)) + ' วัน)',
        expiresDay: a.expiresDay,
        rivalSectNameTh: a.rivalSectNameTh,
        rivalEtaDay: a.rivalEtaDay,
        descTh: a.descTh
      };
    });

    for (const city of Object.values(settlementById)) nodes[city.id] = city;
    topo.nodes = nodes;
    topo.routes = makeContinentalRoutes(topo, nodes);
    if (!topo.selectedNodeId || !nodes[topo.selectedNodeId]) topo.selectedNodeId = 'NODE_HOME_SECT';
    return topo;
  };

  X.estimateTravelTime = (W, party, targetNodeId, opts) => {
    opts = opts || {};
    const topo = opts.topo || X.ensureWorldTopology(W);
    const node = opts.target || (topo && topo.nodes && topo.nodes[targetNodeId]) ||
      Object.values((topo && topo.nodes) || {}).find(n => n.sectId === targetNodeId || n.factionId === targetNodeId);
    const route = X.planContinentalRoute(W, topo, node, opts.fromId);
    const baseDays = route ? route.days : Number.isFinite(opts.baseDays) ? opts.baseDays
      : (node && Number.isFinite(node.baseDays) ? node.baseDays : 4);
    if (baseDays <= 0) return { baseDays: 0, days: 0, durationMultiplier: 1, hasMount: false, hasPhoenixMount: false, hasAzureDragonMount: false };
    const cleanParty = Array.isArray(party) ? party.map(x => typeof x === 'string' ? (W && W.byId && W.byId[x]) : x).filter(Boolean) : [];
    const trip = cleanParty.length
      ? X.createParty(W, cleanParty, { baseDays, regionId: node ? node.id : targetNodeId, macroRegion: node ? node.macroRegion : null, terrain: node ? node.terrain : null, useSectPhoenixAura: !!opts.useSectPhoenixAura })
      : { ok: true, hasMount: false, hasPhoenixMount: false, hasAzureDragonMount: false, durationMultiplier: 1, days: baseDays, carryCapacity: 32 };
    const mult = trip.durationMultiplier || 1;
    const days = Math.max(route ? .08 : .5, Math.round(baseDays * mult * 100) / 100);
    return {
      route,
      distanceLi:route?.distanceLi,
      nodeId: node ? node.id : targetNodeId,
      macroRegion: node ? node.macroRegion : 'CENTRAL_HEARTLAND',
      terrain: node ? node.terrain : 'forest',
      danger: node ? node.danger : 2,
      baseDays,
      days,
      durationMultiplier: mult,
      hasMount: !!trip.hasMount,
      hasPhoenixMount: !!trip.hasPhoenixMount,
      hasAzureDragonMount: !!trip.hasAzureDragonMount,
      qinggongBonuses: trip.qinggongBonuses || null,
      qinggongActive: !!trip.qinggongActive,
      hazardReduction: trip.hazardReduction || 0,
      carryCapacity: trip.carryCapacity || 32
    };
  };

  X.inspectWorldNode = (W, nodeId, party) => {
    const topo = X.ensureWorldTopology(W);
    if (!topo) return null;
    const node = topo.nodes[nodeId] || Object.values(topo.nodes).find(n => n.sectId === nodeId || n.factionId === nodeId);
    if (!node) return null;
    const macro = X.WORLD_REGIONS[node.macroRegion] || X.WORLD_REGIONS.CENTRAL_HEARTLAND;
    const sampleParty = Array.isArray(party) && party.length ? party : (W.npcs || []).filter(n => n && !n.dead && !n.away).slice(0, 3);
    const travel = X.estimateTravelTime(W, sampleParty, node.id, { useSectPhoenixAura: true });
    const activeExpeds = ((W.world && W.world.expeds) || []).filter(e => e && !e.done && (e.region === node.id || e.targetNodeId === node.id || e.sectId === node.sectId || e.anomalyId === node.anomalyId));
    const fogCleared = !!(topo.discoveredRegions && topo.discoveredRegions[node.macroRegion]);
    return {
      node,
      macroRegion: macro,
      fogCleared,
      travel,
      activeExpeditions: activeExpeds.length,
      canLaunchSiege: node.kind === 'NEIGHBOR_SECT' && !node.isVassal,
      canClaimResource: node.kind === 'RESOURCE_NODE' && node.ownerSectId !== 'PLAYER',
      canGarrisonResource: node.kind === 'RESOURCE_NODE' && node.ownerSectId === 'PLAYER',
      canDispatchAnomaly: node.kind === 'WORLD_ANOMALY'
    };
  };

  X.selectWorldNode = (W, nodeId) => {
    const topo = X.ensureWorldTopology(W);
    if (!topo) return { ok: false, reason: 'no-world' };
    const info = X.inspectWorldNode(W, nodeId);
    if (!info) return { ok: false, reason: 'node-not-found' };
    topo.selectedNodeId = info.node.id;
    return { ok: true, selectedNodeId: info.node.id, info };
  };

  X.revealMacroRegion = (W, macroRegionId) => {
    const topo = X.ensureWorldTopology(W);
    if (!topo || !X.WORLD_REGIONS[macroRegionId]) return { ok: false, reason: 'invalid-macro-region' };
    topo.discoveredRegions[macroRegionId] = true;
    return { ok: true, macroRegionId, discoveredRegions: topo.discoveredRegions };
  };

  /* ---------- Pillar 2: Active Sect Warfare, 3-Phase Sieges & Hegemony Dynamics ---------- */
  X.marshalStrikeForce = (W, party, targetSectOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const targetSect = X.findSect(W, targetSectOrId);
    if (!targetSect) return { ok: false, reason: 'invalid-target-sect' };
    if (targetSect.isVassal && !opts.force) return { ok: false, reason: 'already-vassal' };
    if (opts.immediate === false && (W.world.expeds || []).some(e => e && !e.done && e.kind === 'sect_siege' && e.sectId === targetSect.id)) return { ok:false, reason:'already-en-route' };

    let members = [];
    if (Array.isArray(party) && party.length) {
      const seen = new Set();
      for (const x of party) {
        const n = typeof x === 'string' ? (W.byId && W.byId[x]) : x;
        if (!X.isAvailableForExpedition(W, n)) return { ok: false, reason: 'unavailable-member' };
        if (seen.has(n.id)) return { ok: false, reason: 'duplicate-member' };
        seen.add(n.id);
        members.push(n);
      }
    } else {
      members = (W.npcs || []).filter(n => X.isAvailableForExpedition(W, n)).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 4);
    }
    if (!members.length) return { ok: false, reason: 'no-available-disciples' };
    members = members.slice(0, 5);

    const menagerie = (CULT && CULT.ensureMenagerie) ? CULT.ensureMenagerie(W) : ((W.sect && W.sect.beasts) || []);
    const reqBeastUids = Array.isArray(opts.beastUids) ? opts.beastUids : ((W.sect && Array.isArray(W.sect.gateBeasts)) ? W.sect.gateBeasts : []);
    const warBeasts = reqBeastUids.map(uid => menagerie.find(b => b && !b.dead && (b.uid === uid || b.id === uid))).filter(Boolean).slice(0, 3);
    members.forEach(m => {
      const aPets = (CULT && CULT.activePets) ? CULT.activePets(m) : [];
      aPets.forEach(pt => {
        if (pt && !warBeasts.some(wb => (wb.uid || wb.id) === (pt.uid || pt.id))) warBeasts.push(pt);
      });
    });

    const nodeId = targetSect.nodeId || ('NODE_SECT_' + (targetSect.factionId || targetSect.id));
    const travel = X.estimateTravelTime(W, members, nodeId, { useSectPhoenixAura: true });
    const postResolution = opts.postResolution || 'SUBJUGATE';
    const siegeObj = {
      id: 'SIEGE_' + (++W.world.seq),
      sectId: targetSect.id,
      factionId: targetSect.factionId,
      sectNameTh: targetSect.nameTh,
      nodeId,
      partyIds: members.map(m => m.id),
      warBeastUids: warBeasts.map(b => b.uid || b.id),
      postResolution,
      tributePolicy: opts.tributePolicy || 'STANDARD',
      startDay: W.day || 0,
      travelDays: travel.days,
      status: 'MARCHING',
      phases: []
    };
    W.world.sieges.unshift(siegeObj);
    if (W.world.sieges.length > 25) W.world.sieges.length = 25;

    if (opts.immediate !== false) {
      return X.resolveSectSiege(W, siegeObj, Object.assign({}, opts, { members, warBeasts }));
    }

    const ex = {
      id: ++W.world.seq,
      kind: 'sect_siege',
      region: nodeId,
      targetNodeId: nodeId,
      sectId: targetSect.id,
      siegeId: siegeObj.id,
      siege: siegeObj,
      postResolution,
      party: members.map(m => m.id),
      t0: W.t,
      ret: W.t + Math.round(travel.days * 1440),
      days: travel.days,
      baseDays: travel.baseDays,
      hasMount: travel.hasMount,
      durationMultiplier: travel.durationMultiplier,
      journal: ['กรีฑาทัพมุ่งหน้าสู่「' + targetSect.nameTh + '」'],
      carry: [],
      supplies: (() => {
        const planned = Math.max(1, Math.round(members.length * travel.days * 1.5));
        const avail = (W.sect && W.sect.stock && W.sect.stock.meal) || 0;
        const taken = Math.min(planned, avail);
        if (taken > 0 && ECO && ECO.take) ECO.take(W, 'meal', taken);
        return taken;
      })(),
      done: false,
      state: 'away'
    };
    setJourney(ex, travel.route, travel.days, 0, false);
    W.world.expeds.push(ex);
    members.forEach(m => { m.expId = ex.id; m.away = true; m.lastTrip = W.day; });
    X.releaseDeployedGarrisons(W, members);
    W.log('mission', '⚔️ กรีฑาทัพ ' + members.map(m => m.h.name.given).join('、') + ' มุ่งหน้าตีค่าย「' + targetSect.nameTh + '」 (เดินทาง ' + travel.days + ' วัน)', members.map(m => m.id), {location:routePlace(ex.route)});
    return { ok: true, queued: true, siege: siegeObj, expedition: ex, travel };
  };
  X.launchSectSiege = X.marshalStrikeForce;

  // Only the victory path below may grant a post-battle outcome. A public
  // boolean receipt can otherwise be forged or reused to claim rewards.
  const siegeResolutionToken = {};
  X.resolveSectSiege = (W, siegeOrEx, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const isEx = siegeOrEx && siegeOrEx.kind === 'sect_siege';
    const siege = isEx ? (siegeOrEx.siege || W.world.sieges.find(s => s.id === siegeOrEx.siegeId)) : (typeof siegeOrEx === 'object' && siegeOrEx.sectId ? siegeOrEx : null);
    if ((isEx && siegeOrEx.done) || (siege && (siege.settlementApplied || siege.status === 'VICTORY' || siege.status === 'REPELLED' || siege.resolvedDay != null))) {
      return { ok: false, reason: 'already-resolved', siege };
    }
    const targetSect = X.findSect(W, (siege && siege.sectId) || (isEx && siegeOrEx.sectId) || siegeOrEx);
    if (!targetSect) return { ok: false, reason: 'invalid-target-sect' };

    const partyIds = (siege && siege.partyIds) || (isEx && siegeOrEx.party) || (Array.isArray(opts.party) ? opts.party.map(p => typeof p === 'string' ? p : p.id) : []);
    const members = (opts.members || partyIds.map(id => W.byId[id]).filter(Boolean)).filter(n => n && !n.dead);
    if (!members.length) return { ok: false, reason: 'no-members' };

    const menagerie = (CULT && CULT.ensureMenagerie) ? CULT.ensureMenagerie(W) : ((W.sect && W.sect.beasts) || []);
    const warBeasts = opts.warBeasts || ((siege && siege.warBeastUids) || []).map(uid => menagerie.find(b => b && (b.uid === uid || b.id === uid))).filter(Boolean);
    members.forEach(m => {
      const aPets = (CULT && CULT.activePets) ? CULT.activePets(m) : [];
      aPets.forEach(pt => {
        if (pt && !warBeasts.some(wb => (wb.uid || wb.id) === (pt.uid || pt.id))) warBeasts.push(pt);
      });
    });

    const hasWhiteTiger = warBeasts.some(b => b.fourSymbol === 'WHITE_TIGER' || b.bloodlineTrait === 'WHITE_TIGER');
    const hasBlackTortoise = warBeasts.some(b => b.fourSymbol === 'BLACK_TORTOISE' || b.bloodlineTrait === 'BLACK_TORTOISE');
    const hasPhoenix = warBeasts.some(b => b.fourSymbol === 'VERMILION_PHOENIX' || b.bloodlineTrait === 'VERMILION_PHOENIX');
    const hasAzureDragon = warBeasts.some(b => b.fourSymbol === 'AZURE_DRAGON' || b.bloodlineTrait === 'AZURE_DRAGON');

    const coalitionBonusPower = Number.isFinite(opts.coalitionBonusPower)
      ? opts.coalitionBonusPower
      : (siege && Number.isFinite(siege.coalitionBonusPower) ? siege.coalitionBonusPower : 0);
    const basePartyPower = members.reduce((s, m) => s + CULT.power(m), 0) + coalitionBonusPower;
    const beastPower = warBeasts.reduce((s, b) => s + (CULT.petPowerSingle ? CULT.petPowerSingle(b) : 65), 0);
    const sectDefBase = Math.max(180, Math.round((targetSect.power || 1) * 320));
    const phases = [];
    let allPhasesWon = true;

    // Phase 1: Outer Gate & Beast Vanguard Breach
    const breachMult = (hasWhiteTiger ? 1.45 : 1.0) * (hasBlackTortoise ? 1.25 : 1.0) * (warBeasts.length ? 1.15 : 1.0);
    const phase1Attack = (basePartyPower * 0.85 + beastPower * 1.6) * breachMult;
    const phase1Defense = sectDefBase * 0.78;
    const phase1WinProb = clamp(phase1Attack / (phase1Attack + phase1Defense), 0.08, 0.98);
    const phase1Won = opts.forceLosePhase === 1 ? false : (opts.forceWin ? true : (phase1Attack >= phase1Defense * 0.72));
    phases.push({
      phase: 1,
      id: 'OUTER_GATE_BREACH',
      nameTh: 'ด่านที่ 1: ทลายซุ้มประตูค่ายและทัพหน้าอสูร',
      attackerScore: Math.round(phase1Attack),
      defenderScore: Math.round(phase1Defense),
      breachMult: +breachMult.toFixed(2),
      warBeastCount: warBeasts.length,
      hasWhiteTiger,
      hasBlackTortoise,
      winProb: +phase1WinProb.toFixed(3),
      won: phase1Won,
      summaryTh: phase1Won
        ? ('ทัพหน้าและอสูรศึก' + (hasWhiteTiger ? ' [พยัคฆ์ขาวบรรพกาล +45%]' : '') + ' พังซุ้มประตูค่ายของ' + targetSect.nameTh + ' สำเร็จ')
        : ('ซุ้มประตูค่ายของ' + targetSect.nameTh + ' แข็งแกร่งเกินกำลัง ทัพหน้าถูกสกัดกั้น')
    });
    if (!phase1Won) allPhasesWon = false;

    // Phase 2: Sect Protective Array & Elder Clash
    const formSyn = (COMBAT && COMBAT.evaluateFormationSynergy) ? COMBAT.evaluateFormationSynergy(members) : { powerMultiplier: 1.0, damageMitigation: 0, auraNamesTh: [], synergies: [] };
    const lead = members.slice().sort((a, b) => CULT.power(b) - CULT.power(a))[0];
    const elderDummy = { foe: true, equip: { WEAPON: { slot: 'WEAPON', gearType: targetSect.majorPath === 'SWORD' || targetSect.majorPath === 'XIAN' ? 'SWORD' : 'SPEAR' } } };
    const tac = (COMBAT && COMBAT.resolveWeaponTactics && lead) ? COMBAT.resolveWeaponTactics(lead, elderDummy, { dist: 2.2 }) : { dmgMult: 1.0, relation: 'NEUTRAL' };
    const dsh = (COMBAT && COMBAT.evaluateTacticalBoutSummary) ? COMBAT.evaluateTacticalBoutSummary(members, [elderDummy]) : null;
    if (allPhasesWon) {
      const dshMult = dsh ? (1 + clamp(dsh.advantageDelta * 0.5, -0.12, 0.12)) : 1;
      const arrayMult = (formSyn.powerMultiplier || 1) * (tac.dmgMult || 1) * dshMult * (hasWhiteTiger ? 1.18 : 1) * (hasAzureDragon ? 1.15 : 1);
      const phase2Attack = (basePartyPower + beastPower * 0.8) * arrayMult;
      const phase2Defense = sectDefBase * 0.95;
      const phase2WinProb = clamp(phase2Attack / (phase2Attack + phase2Defense), 0.08, 0.98);
      const phase2Won = opts.forceLosePhase === 2 ? false : (opts.forceWin ? true : (phase2Attack >= phase2Defense * 0.75));
      phases.push({
        phase: 2,
        id: 'PROTECTIVE_ARRAY_CLASH',
        nameTh: 'ด่านที่ 2: ทลายค่ายกลพิทักษ์สำนักและศึกผู้อาวุโส',
        attackerScore: Math.round(phase2Attack),
        defenderScore: Math.round(phase2Defense),
        formationMultiplier: +(formSyn.powerMultiplier || 1).toFixed(2),
        tacticalRelation: tac.relation || 'NEUTRAL',
        tacticalSummaryTh: dsh ? dsh.summaryTh : '',
        winProb: +phase2WinProb.toFixed(3),
        won: phase2Won,
        summaryTh: phase2Won
          ? ('ประสานค่ายกลทะลวงม่านพลังพิทักษ์สำนักและโค่นคณะผู้อาวุโสของ' + targetSect.nameTh + ' สำเร็จ')
          : ('ติดค่ายกลพิทักษ์สำนักของ' + targetSect.nameTh + ' ต้องถอยทัพตั้งหลัก')
      });
      if (!phase2Won) allPhasesWon = false;
    }

    // Phase 3: Patriarch Duel & Surrender Negotiation
    if (allPhasesWon) {
      const leadPower = (lead ? CULT.power(lead) : basePartyPower * 0.5) * (hasWhiteTiger ? 1.22 : 1) * (hasPhoenix ? 1.18 : 1) + basePartyPower * 0.45 + beastPower * 0.5;
      const patriarchPower = sectDefBase * 0.82;
      const phase3WinProb = clamp(leadPower / (leadPower + patriarchPower), 0.08, 0.98);
      const phase3Won = opts.forceLosePhase === 3 ? false : (opts.forceWin ? true : (leadPower >= patriarchPower * 0.74));
      phases.push({
        phase: 3,
        id: 'PATRIARCH_DUEL',
        nameTh: 'ด่านที่ 3: ประลองชี้ขาดเจ้าสำนัก (' + (targetSect.leaderNameTh || targetSect.nameTh) + ')',
        attackerScore: Math.round(leadPower),
        defenderScore: Math.round(patriarchPower),
        leaderNameTh: targetSect.leaderNameTh || ('เจ้าสำนัก' + targetSect.nameTh),
        winProb: +phase3WinProb.toFixed(3),
        won: phase3Won,
        summaryTh: phase3Won
          ? ((lead ? lead.h.name.given : 'จอมยุทธ์ของเรา') + ' สยบ ' + (targetSect.leaderNameTh || ('เจ้าสำนัก' + targetSect.nameTh)) + ' ในศึกชี้ขาด บีบให้ยอมจำนน!')
          : ((targetSect.leaderNameTh || ('เจ้าสำนัก' + targetSect.nameTh)) + ' ต้านทานการบุกไว้ได้ ทัพของเราจำต้องถอนกำลัง')
      });
      if (!phase3Won) allPhasesWon = false;
    }

    // Release expedition state if called from expedition
    if (isEx) {
      siegeOrEx.done = true;
    }
    const hpLossFrac = allPhasesWon ? 0.14 : 0.32;
    members.forEach(m => {
      if (m.expId && (!isEx || m.expId === siegeOrEx.id)) {
        m.expId = null; m.away = false; m.hidden = false; m.travel = null;
      }
      if (m.h && m.h.state) {
        const hm = CULT.hpMax(m);
        m.h.state.hp = Math.max(1, Math.round((m.h.state.hp || hm) - hm * hpLossFrac));
        m.h.state.energy = Math.max(10, (m.h.state.energy || 60) - 22);
      }
      m.merit = (m.merit || 0) + (allPhasesWon ? 28 : 8);
    });

    const resolutionChoice = opts.postResolution || (siege && siege.postResolution) || (isEx && siegeOrEx.postResolution) || 'SUBJUGATE';
    let resolutionResult = null;
    if (allPhasesWon) {
      resolutionResult = X.applySiegeResolution(W, targetSect, resolutionChoice, {
        party: members,
        tributePolicy: opts.tributePolicy || (siege && siege.tributePolicy) || 'STANDARD',
        victoryToken: siegeResolutionToken,
        siegeId: siege ? siege.id : ('EX_' + (isEx ? siegeOrEx.id : (W.day || 0)))
      });
      W.fame(6);
    } else {
      targetSect.attitude = clamp((targetSect.attitude || 0) - 25, -100, 100);
      targetSect.treaty = 'RIVAL_FEUD';
      W.fame(-2);
      W.log('mission', '✘ การบุกตีค่าย「' + targetSect.nameTh + '」ไม่สำเร็จ หยุดที่ด่าน ' + phases.length, members.map(m => m.id));
    }

    if (siege) {
      siege.status = allPhasesWon ? 'VICTORY' : 'REPELLED';
      siege.won = allPhasesWon;
      siege.phases = phases;
      siege.resolution = resolutionResult;
      siege.resolvedDay = W.day || 0;
      siege.settlementApplied = true;
    }
    X.ensureWorldTopology(W);
    return {
      ok: true,
      won: allPhasesWon,
      sectId: targetSect.id,
      sectNameTh: targetSect.nameTh,
      phases,
      postResolution: resolutionChoice,
      resolution: resolutionResult,
      siege
    };
  };

  X.applySiegeResolution = (W, sectOrId, resolutionChoice, opts) => {
    opts = opts || {};
    const s = X.findSect(W, sectOrId);
    if (!s) return { ok: false, reason: 'invalid-sect' };
    if (opts.victoryToken !== siegeResolutionToken) return { ok: false, reason: 'requires-siege-victory', sectId: s.id };
    const choice = String(resolutionChoice || 'SUBJUGATE').toUpperCase();
    if (!['PILLAGE', 'FREE_TRADE', 'FREE_TRADE_TREATY', 'SUBJUGATE'].includes(choice)) return { ok: false, reason: 'invalid-resolution', sectId: s.id };
    if (g.CONTENT && g.CONTENT.ensure) g.CONTENT.ensure(W);
    const pol = W.world.politics || (W.world.politics = { treaties: {}, events: [], stats: {} });
    const party = opts.party || [];
    const lead = party[0] || W.byId[W.sect.masterId];

    if (choice === 'PILLAGE') {
      const wantLoot = Math.max(350, Math.round(420 + (s.power || 1) * 240));
      const stonesLoot = (ECO && ECO.earnFromPool)
        ? ECO.earnFromPool(W, wantLoot, 'ปล้นคลังสมบัติของ' + s.nameTh, { rivalSect: s })
        : ((ECO && ECO.earn && ECO.earn(W, wantLoot, 'ปล้นคลังสมบัติของ' + s.nameTh)) ? wantLoot : 0);
      const matsLoot = {};
      const matPool = (Array.isArray(s.specialtyMatIds) && s.specialtyMatIds.length) ? s.specialtyMatIds : ['MAT_ORE_METEOR_IRON_5', 'MAT_HERB_SNOW_LOTUS_5'];
      matPool.forEach(mId => {
        if (ECO.matById && ECO.matById[mId]) {
          ECO.add(W, mId, 4);
          matsLoot[mId] = 4;
        }
      });
      let manualLooted = null;
      const allTechs = (JD && JD.TECH && JD.TECH.techniques) || [];
      const unowned = allTechs.find(t => t && (t.tier || 1) >= 4 && !(W.sect.library || []).includes(t.id));
      if (unowned) {
        W.sect.library = W.sect.library || [];
        W.sect.library.push(unowned.id);
        manualLooted = unowned.id;
      }
      s.attitude = -100;
      s.treaty = 'RIVAL_FEUD';
      s.isVassal = false;
      s.bannerTh = null;
      s.bloodVendetta = true;
      s.power = Math.max(0.45, Math.round((s.power || 1) * 0.75 * 100) / 100);
      pol.treaties[s.id] = { type: 'RIVAL_FEUD', signedDay: W.day || 0, cause: 'PILLAGED' };
      const summaryTh = 'ปล้นคลังสมบัติของ' + s.nameTh + ' ยึดศิลา ' + stonesLoot + ' ก้อน' + (manualLooted ? ' และคัมภีร์ยุทธ์' : '') + ' (เกิดหนี้แค้นโลหิต -100)';
      pol.events.push({ day: W.day || 0, kind: 'SIEGE_PILLAGE', sectId: s.id, treaty: 'RIVAL_FEUD', outcome: 'PILLAGED', stones: stonesLoot, mats: matsLoot, manualId: manualLooted, summaryTh });
      W.log('mission', '🔥 ' + summaryTh, lead ? [lead.id] : []);
      X.ensureWorldTopology(W);
      return { ok: true, mode: 'PILLAGE', sectId: s.id, stonesLoot, matsLoot, manualLooted, attitude: s.attitude, treaty: s.treaty, summaryTh };
    }

    if (choice === 'FREE_TRADE' || choice === 'FREE_TRADE_TREATY') {
      const alreadyFreeTrade = s.treaty === 'FREE_TRADE_TREATY' && s.freeTradeImposedDay != null;
      s.treaty = 'FREE_TRADE_TREATY';
      s.isVassal = false;
      s.tariffFree = true;
      s.bannerTh = '[ ด่านการค้าเสรี ]';
      s.attitude = clamp((s.attitude || 0) + 15, -20, 100);
      const wantDividend = alreadyFreeTrade ? 0 : 180;
      const immediateDividend = wantDividend > 0
        ? ((ECO && ECO.earnFromPool)
          ? ECO.earnFromPool(W, wantDividend, 'ค่าเปิดด่านการค้าเสรีจาก' + s.nameTh, { rivalSect: s })
          : ((ECO && ECO.earn && ECO.earn(W, wantDividend, 'ค่าเปิดด่านการค้าเสรีจาก' + s.nameTh)) ? wantDividend : 0))
        : 0;
      if (!alreadyFreeTrade && W.market && W.market.mult && Array.isArray(s.specialtyMatIds)) {
        s.specialtyMatIds.forEach(mId => {
          W.market.mult[mId] = Math.round(clamp((W.market.mult[mId] || 1) * 0.80, 0.55, 1.5) * 100) / 100;
        });
      }
      s.freeTradeImposedDay = W.day || 0;
      pol.treaties[s.id] = { type: 'FREE_TRADE_TREATY', signedDay: W.day || 0, tariffFree: true };
      pol.stats.treatiesSigned = (pol.stats.treatiesSigned || 0) + 1;
      const summaryTh = 'บังคับเปิดด่านการค้าเสรีไร้ภาษีกับ' + s.nameTh + ' (ลดราคาสินค้าเฉพาะทาง 20% และรับศิลาเปิดด่าน ' + immediateDividend + ' ก้อน)';
      pol.events.push({ day: W.day || 0, kind: 'SIEGE_FREE_TRADE', sectId: s.id, treaty: 'FREE_TRADE_TREATY', outcome: 'FREE_TRADE_IMPOSED', stones: immediateDividend, summaryTh });
      W.log('mission', '🐪 ' + summaryTh, lead ? [lead.id] : []);
      X.ensureWorldTopology(W);
      return { ok: true, mode: 'FREE_TRADE', sectId: s.id, treaty: 'FREE_TRADE_TREATY', tariffFree: true, stones: immediateDividend, summaryTh };
    }

    // Default: SUBJUGATE (Impose Vassalage & Banner)
    if (g.CONTENT && g.CONTENT.forceVassalTreaty) {
      g.CONTENT.forceVassalTreaty(W, s, { force: true, winnerId: lead ? lead.id : null, cause: 'SIEGE_VICTORY' });
    }
    s.treaty = 'VASSAL_TREATY';
    s.isVassal = true;
    s.suzerainId = 'PLAYER';
    s.bannerTh = '[ สำนักบริวารในอาณัติ ]';
    s.loyalty = Number.isFinite(opts.initialLoyalty) ? opts.initialLoyalty : 68;
    s.tributePolicy = opts.tributePolicy || 'STANDARD';
    s.subjugatedDay = W.day || 0;
    s.lastVassalTributeDay = null;
    const summaryTh = 'ปักธง「สำนักบริวารในอาณัติ」เหนือ' + s.nameTh + ' สำเร็จ (ความภักดีเริ่มต้น ' + s.loyalty + '/100)';
    W.log('mission', '🚩 ' + summaryTh, lead ? [lead.id] : []);
    X.ensureWorldTopology(W);
    return { ok: true, mode: 'SUBJUGATE', sectId: s.id, treaty: 'VASSAL_TREATY', isVassal: true, bannerTh: s.bannerTh, loyalty: s.loyalty, tributePolicy: s.tributePolicy, summaryTh };
  };

  X.setVassalTributePolicy = (W, sectOrId, policy) => {
    const s = X.findSect(W, sectOrId);
    if (!s || (!s.isVassal && s.treaty !== 'VASSAL_TREATY')) return { ok: false, reason: 'not-a-vassal' };
    if (!['LENIENT', 'STANDARD', 'HARSH'].includes(policy)) return { ok: false, reason: 'invalid-policy', policy };
    const p = policy;
    if (s.tributePolicy === p) {
      return { ok: true, unchanged: true, sectId: s.id, tributePolicy: p, loyalty: s.loyalty };
    }
    const curDay = (W && W.day) || 0;
    if (s.lastPolicyChangeDay != null && curDay - s.lastPolicyChangeDay < 15) {
      return { ok: false, reason: 'policy-cooldown', sectId: s.id, tributePolicy: s.tributePolicy, loyalty: s.loyalty };
    }
    s.tributePolicy = p;
    s.lastPolicyChangeDay = curDay;
    if (p === 'LENIENT') s.loyalty = clamp((s.loyalty || 60) + 6, 0, 100);
    if (p === 'HARSH') s.loyalty = clamp((s.loyalty || 60) - 8, 0, 100);
    return { ok: true, sectId: s.id, tributePolicy: p, loyalty: s.loyalty };
  };

  X.collectVassalTributes = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, tributes: [] };
    X.ensureWorldTopology(W);
    const vassals = (W.world.allSects || []).filter(s => s && (s.isVassal || s.treaty === 'VASSAL_TREATY'));
    const collected = [];
    const curDay = W.day || 0;
    vassals.forEach(s => {
      if (!opts.force && s.lastVassalTributeDay != null && (curDay === s.lastVassalTributeDay || (curDay - s.lastVassalTributeDay < 90))) return;
      const polMult = s.tributePolicy === 'HARSH' ? 1.45 : s.tributePolicy === 'LENIENT' ? 0.75 : 1.0;
      const rawStones = Math.max(80, Math.round((120 + (s.power || 1) * 45) * polMult));
      const pool = W.world && (W.world.resourcePool || (W.world.resourcePool = { stones: 50000, herbs: 5000, ores: 5000 }));
      const baseStones = (pool && Number.isFinite(pool.stones)) ? Math.min(rawStones, Math.max(0, Math.floor(pool.stones))) : rawStones;
      if (pool && Number.isFinite(pool.stones)) pool.stones -= baseStones;
      if (baseStones > 0) ECO.earn(W, baseStones, 'บรรณาการตามฤดูกาลจากสำนักบริวาร ' + s.nameTh);
      const matsGiven = {};
      const matPool = (Array.isArray(s.specialtyMatIds) && s.specialtyMatIds.length) ? s.specialtyMatIds : ['MAT_HERB_JADE_LOTUS_2', 'MAT_ORE_COLD_STEEL_2'];
      matPool.slice(0, 2).forEach(mId => {
        if (ECO.matById && ECO.matById[mId]) {
          const qty = s.tributePolicy === 'HARSH' ? 3 : 2;
          ECO.add(W, mId, qty);
          matsGiven[mId] = qty;
        }
      });
      // Faction-specific signature tribute bonus
      let bonusItem = null;
      if ((s.factionId === 'FAC_WHITE_CLOUD' || s.canonicalId === 'FAC_WHITE_CLOUD') && ECO.recipesFor) {
        const swordRec = (JD.ITEMS && JD.ITEMS.recipes || []).find(r => r.outType === 'EQUIPMENT' && r.gearType === 'SWORD' && r.tier >= 3);
        if (swordRec && ECO.mintGear) {
          const gr = ECO.mintGear(W, swordRec, 1.2);
          gr.nameTh = (gr.nameTh || 'กระบี่เมฆขาว') + ' (บรรณาการ)';
          W.sect.gear.push(gr);
          bonusItem = gr.nameTh;
        }
      } else if (s.factionId === 'FAC_JADE_LOTUS' || s.canonicalId === 'FAC_JADE_LOTUS') {
        ECO.add(W, 'P:BASIC_HP2', 2);
        bonusItem = 'โอสถฟื้นฟูชั้นสูง ×2';
      }
      s.lastVassalTributeDay = W.day || 0;
      if (W.world.politics && W.world.politics.stats) {
        W.world.politics.stats.vassalTributes = (W.world.politics.stats.vassalTributes || 0) + 1;
      }
      const entry = { sectId: s.id, sectNameTh: s.nameTh, stones: baseStones, mats: matsGiven, bonusItem, tributePolicy: s.tributePolicy || 'STANDARD' };
      collected.push(entry);
      W.log('finance', '👑 สำนักบริวาร「' + s.nameTh + '」ถวายบรรณาการประจำฤดูกาล: ' + baseStones + ' ศิลา' + (bonusItem ? ' และ ' + bonusItem : ''), []);
    });
    return { ok: true, count: collected.length, tributes: collected };
  };

  X.spawnVassalDistressCall = (W, sectOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    const vassals = (W.world.allSects || []).filter(s => s && (s.isVassal || s.treaty === 'VASSAL_TREATY'));
    const target = sectOrId ? X.findSect(W, sectOrId) : vassals[0];
    if (!target) return null;
    const call = {
      id: 'DISTRESS_' + (W.day || 0) + '_' + target.id,
      sectId: target.id,
      sectNameTh: target.nameTh,
      threatNameTh: opts.threatNameTh || 'ฝูงอสูรคลั่งและสำนักอริปิดล้อมชายแดน',
      day: W.day || 0,
      expiresDay: (W.day || 0) + 6,
      resolved: false
    };
    W.world.vassalDistressCalls.unshift(call);
    if (W.world.politics) W.world.politics.activeDistressCall = call;
    W.log('mission', '🚨 สัญญาณขอความช่วยเหลือจากสำนักบริวาร「' + target.nameTh + '」: ถูก' + call.threatNameTh + 'โจมตี!', []);
    return call;
  };

  X.respondVassalDistress = (W, distressOrSectId, choice, party) => {
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const calls = W.world.vassalDistressCalls || [];
    const hasExplicitTarget = distressOrSectId !== undefined && distressOrSectId !== null && distressOrSectId !== '';
    let call = hasExplicitTarget
      ? calls.find(c => c && !c.resolved && (c.id === distressOrSectId || c.sectId === distressOrSectId))
      : ((W.world.politics && W.world.politics.activeDistressCall && !W.world.politics.activeDistressCall.resolved) ? W.world.politics.activeDistressCall : calls.find(c => c && !c.resolved));
    if (!call || call.resolved) return { ok: false, reason: 'no-active-distress-call' };
    if (Number.isFinite(call.expiresDay) && (W.day || 0) > call.expiresDay) {
      call.resolved = true;
      call.outcome = 'EXPIRED';
      call.resolvedDay = W.day || 0;
      if (W.world.politics && W.world.politics.activeDistressCall === call) W.world.politics.activeDistressCall = null;
      return { ok: false, reason: 'distress-expired', callId: call.id };
    }
    const s = X.findSect(W, call.sectId);
    if (!s) return { ok: false, reason: 'invalid-sect' };
    const actChoice = String(choice || 'REINFORCE').toUpperCase();
    if (actChoice === 'REINFORCE' || actChoice === 'AID' || actChoice === 'SEND_AID') {
      const helpers = Array.isArray(party) && party.length
        ? party.map(x => typeof x === 'string' ? W.byId[x] : x).filter(n => n && !n.dead && !n.away && !n.exiled)
        : (W.npcs || []).filter(n => X.isAvailableForExpedition(W, n)).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 2);
      if (!helpers.length) {
        return { ok: false, reason: 'no-available-disciples' };
      }
      const mealCost = Math.min(helpers.length * 2, (W.sect && W.sect.stock && W.sect.stock.meal) || 0);
      if (mealCost > 0 && ECO && ECO.take) ECO.take(W, 'meal', mealCost);
      call.resolved = true;
      call.outcome = actChoice;
      if (W.world.politics && W.world.politics.activeDistressCall === call) W.world.politics.activeDistressCall = null;
      s.loyalty = clamp((s.loyalty != null ? s.loyalty : 60) + 20, 0, 100);
      s.attitude = clamp((s.attitude || 0) + 15, -100, 100);
      W.fame(4);
      helpers.forEach(h => {
        h.merit = (h.merit || 0) + 20;
        if (h.h && h.h.state) h.h.state.energy = Math.max(15, (h.h.state.energy || 60) - 18);
      });
      const summaryTh = 'ส่งกำลังหนุนช่วยคุ้มครองสำนักบริวาร「' + s.nameTh + '」สำเร็จ (ความภักดี +20 เป็น ' + s.loyalty + '/100)';
      W.log('mission', '🛡️ ' + summaryTh, helpers.map(h => h.id));
      return { ok: true, outcome: 'REINFORCED', sectId: s.id, loyalty: s.loyalty, attitude: s.attitude, summaryTh };
    } else {
      call.resolved = true;
      call.outcome = actChoice;
      if (W.world.politics && W.world.politics.activeDistressCall === call) W.world.politics.activeDistressCall = null;
      s.loyalty = clamp((s.loyalty != null ? s.loyalty : 60) - 30, 0, 100);
      s.attitude = clamp((s.attitude || 0) - 25, -100, 100);
      W.fame(-3);
      const summaryTh = 'เพิกเฉยต่อคำขอความช่วยเหลือของสำนักบริวาร「' + s.nameTh + '」 (ความภักดีดิ่งลง -30 เหลือ ' + s.loyalty + '/100)';
      W.log('mission', '⚠️ ' + summaryTh, []);
      if (s.loyalty < 20) {
        const reb = X.triggerVassalRebellion(W, s, { reason: 'abandoned_in_distress' });
        return { ok: true, outcome: 'REFUSED', sectId: s.id, loyalty: s.loyalty, attitude: s.attitude, rebelled: true, rebellion: reb, summaryTh };
      }
      return { ok: true, outcome: 'REFUSED', sectId: s.id, loyalty: s.loyalty, attitude: s.attitude, rebelled: false, summaryTh };
    }
  };

  X.triggerVassalRebellion = (W, sectOrId, opts) => {
    opts = opts || {};
    const s = X.findSect(W, sectOrId);
    if (!s) return { ok: false, reason: 'invalid-sect' };
    s.isVassal = false;
    s.suzerainId = null;
    s.bannerTh = null;
    s.treaty = 'RIVAL_FEUD';
    s.attitude = -90;
    s.rebelledAtDay = W.day || 0;
    if (W.world.politics && W.world.politics.treaties) {
      W.world.politics.treaties[s.id] = { type: 'RIVAL_FEUD', signedDay: W.day || 0, cause: 'VASSAL_REBELLION' };
    }
    const coalition = (W.world.allSects || []).filter(other => other && other.id !== s.id && ((other.isVassal && (other.loyalty || 50) < 35) || other.treaty === 'RIVAL_FEUD' || (other.attitude || 0) <= -50));
    const coalitionIds = [s.id];
    coalition.forEach(c => {
      if ((c.isVassal || c.treaty === 'VASSAL_TREATY') && (c.loyalty || 50) < 35) {
        c.isVassal = false; c.suzerainId = null; c.bannerTh = null; c.treaty = 'RIVAL_FEUD'; c.attitude = -85;
        if (W.world.politics && W.world.politics.treaties) {
          W.world.politics.treaties[c.id] = { type: 'RIVAL_FEUD', signedDay: W.day || 0, cause: 'VASSAL_REBELLION_CASCADE' };
        }
      }
      coalitionIds.push(c.id);
    });
    const summaryTh = 'สำนักบริวาร「' + s.nameTh + '」ฉีกสัญญาและปลดธงบริวาร ก่อกบฏประกาศตนเป็นอิสระ!' + (coalitionIds.length > 1 ? (' พร้อมจับมือพันธมิตรต่อต้านรวม ' + coalitionIds.length + ' สำนัก!') : '');
    if (W.world.politics && Array.isArray(W.world.politics.events)) {
      W.world.politics.events.push({ day: W.day || 0, kind: 'VASSAL_REBELLION', sectId: s.id, coalitionIds, outcome: 'REBELLED', summaryTh });
    }
    W.log('raid', '🔥 ' + summaryTh, []);
    X.ensureWorldTopology(W);
    return { ok: true, rebelled: true, sectId: s.id, sectNameTh: s.nameTh, treaty: s.treaty, attitude: s.attitude, coalitionIds, summaryTh };
  };

  X.tickHegemony = W => {
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    const playerPower = Math.max(100, (W.npcs || []).filter(n => n && !n.dead).reduce((sum, n) => sum + CULT.power(n), 0));
    const rebellions = [];
    (W.world.allSects || []).forEach(s => {
      if (!s || (!s.isVassal && s.treaty !== 'VASSAL_TREATY')) return;
      s.isVassal = true;
      const sectEquivalentPower = (s.power || 1) * 320;
      const powerRatio = sectEquivalentPower / Math.max(1, playerPower);
      let delta = 0;
      if (s.tributePolicy === 'HARSH') delta -= 3.5;
      else if (s.tributePolicy === 'LENIENT') delta += 1.5;
      else delta -= 0.5;
      if (powerRatio > 0.85) delta -= 2.5;
      else if (powerRatio < 0.45) delta += 1.0;
      s.loyalty = clamp((s.loyalty != null ? s.loyalty : 65) + delta, 0, 100);
      if (s.loyalty < 20) {
        rebellions.push(X.triggerVassalRebellion(W, s, { reason: 'low_loyalty' }));
      }
    });
    // Seasonal tributes on Day 1, 91, 181, 271 (or every 90 days)
    if (W.day > 0 && (W.day % 90 === 1 || W.day % 90 === 0)) {
      X.collectVassalTributes(W);
    }
    return { ok: true, rebellions };
  };

  /* ---------- Pillar 4: Contestable Resource Nodes & Timed Serendipitous World Anomalies ---------- */
  X.departResourceClaim = (W, nodeId, party) => {
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const node = W.world.resourceNodes && W.world.resourceNodes[nodeId];
    if (!node) return { ok: false, reason: 'invalid-resource-node' };
    if (node.ownerSectId === 'PLAYER') return { ok: false, reason: 'already-owned' };
    if ((W.world.expeds || []).some(e => e && !e.done && e.kind === 'resource_claim' && e.targetNodeId === nodeId)) return { ok: false, reason: 'already-en-route' };
    const candidates = Array.isArray(party) && party.length ? party : (W.npcs || []).filter(n => n && !n.dead && !n.exiled && !n.away && !n.expId && !n.travel).sort((a,b) => CULT.power(b) - CULT.power(a)).slice(0, 3);
    const trip = X.createParty(W, candidates, { baseDays: node.baseDays, regionId: node.id, macroRegion: node.macroRegion, terrain: node.terrain, useSectPhoenixAura: true });
    if (!trip.ok) return { ok: false, reason: trip.reason || 'no-party' };
    const members = trip.members;
    const travel = X.estimateTravelTime(W, members, node.id, { useSectPhoenixAura: true });
    const ex = { id: ++W.world.seq, kind: 'resource_claim', region: node.id, targetNodeId: node.id,
      party: members.map(n => n.id), t0: W.t, ret: W.t + Math.round(travel.days * 1440), days: travel.days,
      baseDays: travel.baseDays, hasMount: travel.hasMount, durationMultiplier: travel.durationMultiplier,
      journal: ['ออกเดินทางสู่「' + node.nameTh + '」'], carry: [], supplies: 0, done: false, state: 'away' };
    setJourney(ex, travel.route, travel.days, 0, false);
    W.world.expeds.push(ex);
    members.forEach(n => { AI.interruptFor(W, n); n.expId = ex.id; n.away = true; n.lastTrip = W.day; });
    X.releaseDeployedGarrisons(W, members);
    W.log('mission', '🚩 ส่งคณะเข้ายึด「' + node.nameTh + '」 (เดินทาง ' + travel.days + ' วัน)', members.map(n => n.id), {location:routePlace(ex.route)});
    return { ok: true, queued: true, expedition: ex, travel };
  };

  X.claimResourceNode = (W, nodeId, party, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const rn = W.world.resourceNodes && W.world.resourceNodes[nodeId];
    if (!rn) return { ok: false, reason: 'invalid-resource-node' };
    if (rn.ownerSectId === 'PLAYER' && !opts.forceReclaim) return { ok: false, reason: 'already-owned', nodeId: rn.id };
    const members = Array.isArray(party) && party.length
      ? party.map(x => typeof x === 'string' ? W.byId[x] : x).filter(n => n && !n.dead)
      : (W.npcs || []).filter(n => n && !n.dead && !n.away).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 3);
    if (!members.length) return { ok: false, reason: 'no-party' };

    const partyPower = members.reduce((s, m) => s + CULT.power(m), 0);
    const defPower = (rn.garrison && rn.garrison.defensePower) || 320;
    const won = opts.forceFail ? false : (opts.forceWin !== false && (partyPower >= defPower * 0.65 || opts.forceWin));
    if (!won) {
      W.log('mission', '✘ คณะของ ' + members[0].h.name.given + ' บุกยึด「' + rn.nameTh + '」ไม่สำเร็จ', members.map(m => m.id));
      return { ok: true, won: false, nodeId: rn.id, nameTh: rn.nameTh, partyPower, defPower };
    }

    const prevOwnerSect = X.findSect(W, rn.ownerSectId);
    if (prevOwnerSect && !prevOwnerSect.isVassal) {
      prevOwnerSect.attitude = clamp((prevOwnerSect.attitude || 0) - 18, -100, 100);
    }
    rn.ownerSectId = 'PLAYER';
    rn.ownerNameTh = 'สำนักของเรา';
    rn.claimedDay = W.day || 0;
    rn.lastHarvestDay = W.day || 0;
    if (opts.garrison) {
      X.assignNodeGarrison(W, rn.id, opts.garrison);
    } else {
      X.assignNodeGarrison(W, rn.id, { discipleIds: members.slice(0, 2).map(m => m.id), beastUid: opts.beastUid || null });
    }
    X.revealMacroRegion(W, rn.macroRegion);
    X.ensureWorldTopology(W);
    W.fame(3);
    W.log('mission', '🚩 ยึดครองจุดยุทธศาสตร์「' + rn.nameTh + '」สำเร็จ! เริ่มส่งรายได้และทรัพยากรเข้าคลังสำนัก', members.map(m => m.id));
    return { ok: true, won: true, nodeId: rn.id, nameTh: rn.nameTh, ownerSectId: rn.ownerSectId, garrison: rn.garrison };
  };

  X.resolveResourceClaim = (W, ex, members) => {
    if (!ex || ex.done) return null;
    ex.done = true;
    members.forEach(m => { m.expId = null; m.away = false; m.hidden = false; m.travel = null; });
    const target = W.world && W.world.resourceNodes && W.world.resourceNodes[ex.targetNodeId || ex.region];
    if (target && target.ownerSectId === 'PLAYER') return { ok:false, reason:'already-owned' };
    return X.claimResourceNode(W, ex.targetNodeId || ex.region, members, {});
  };

  X.assignNodeGarrison = (W, nodeId, spec) => {
    spec = spec || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const rn = W.world.resourceNodes && W.world.resourceNodes[nodeId];
    if (!rn) return { ok: false, reason: 'invalid-resource-node' };
    if (rn.ownerSectId !== 'PLAYER') return { ok: false, reason: 'not-player-owned' };
    const uniqueDisciples = new Set();
    const disciples = (spec.discipleIds || []).map(id => typeof id === 'string' ? W.byId[id] : id).filter(n => {
      if (!X.isAvailableForExpedition(W, n) || uniqueDisciples.has(n.id)) return false;
      uniqueDisciples.add(n.id);
      return true;
    }).slice(0, 3);
    const menagerie = (CULT && CULT.ensureMenagerie) ? CULT.ensureMenagerie(W) : ((W.sect && W.sect.beasts) || []);
    let beast = spec.beastUid ? menagerie.find(b => b && !b.dead && (b.uid === spec.beastUid || b.id === spec.beastUid)) : null;
    if (!beast && spec.beast && typeof spec.beast === 'object') beast = spec.beast;
    const discIdSet = new Set(disciples.map(d => d.id));
    const targetBeastUid = beast ? (beast.uid || beast.id) : null;
    Object.values(W.world.resourceNodes || {}).forEach(other => {
      if (!other || other.id === nodeId || !other.garrison) return;
      if (Array.isArray(other.garrison.discipleIds) && discIdSet.size) {
        other.garrison.discipleIds = other.garrison.discipleIds.filter(id => !discIdSet.has(id));
      }
      if (targetBeastUid && other.garrison.beastUid === targetBeastUid) {
        other.garrison.beastUid = null;
        other.garrison.beastNameTh = null;
      }
    });

    const fsSummary = (CULT && CULT.sectFourSymbolSummary) ? CULT.sectFourSymbolSummary(W) : null;
    const isBlackTortoise = !!(
      (beast && (beast.fourSymbol === 'BLACK_TORTOISE' || beast.bloodlineTrait === 'BLACK_TORTOISE')) ||
      disciples.some(d => (CULT.activePets ? CULT.activePets(d) : []).some(p => p.fourSymbol === 'BLACK_TORTOISE')) ||
      (fsSummary && fsSummary.hasBlackTortoise && spec.useSectBastion !== false)
    );
    const discPower = disciples.reduce((s, d) => s + CULT.power(d), 0);
    const beastPower = beast ? (CULT.petPowerSingle ? CULT.petPowerSingle(beast) : 120) : 0;
    const baseDef = (X.RESOURCE_NODE_DEFS[nodeId] && X.RESOURCE_NODE_DEFS[nodeId].garrisonPowerBase) || 320;
    const bastionMult = isBlackTortoise ? 1.45 : 1.0;
    const defensePower = Math.round((baseDef * 0.65 + discPower + beastPower * 1.5) * bastionMult);
    const yieldMultiplier = isBlackTortoise ? 1.25 : (disciples.length || beast ? 1.10 : 1.0);

    rn.garrison = {
      discipleIds: disciples.map(d => d.id),
      beastUid: beast ? (beast.uid || beast.id) : null,
      beastNameTh: beast ? beast.nameTh : null,
      defensePower,
      yieldMultiplier,
      bastionActive: isBlackTortoise,
      playerManaged: true
    };
    X.ensureWorldTopology(W);
    return { ok: true, nodeId: rn.id, garrison: rn.garrison };
  };

  X.recomputeNodeGarrison = (W, rn) => {
    if (!W || !rn || !rn.garrison) return null;
    const gObj = rn.garrison;
    if (rn.ownerSectId !== 'PLAYER' && gObj.playerManaged) {
      const baseDef = (X.RESOURCE_NODE_DEFS[rn.id] && X.RESOURCE_NODE_DEFS[rn.id].garrisonPowerBase) || 320;
      rn.garrison = { discipleIds: [], beastUid: null, defensePower: baseDef, yieldMultiplier: 1.0, bastionActive: false };
      return rn.garrison;
    }
    if (rn.ownerSectId !== 'PLAYER' && !gObj.playerManaged && (!Array.isArray(gObj.discipleIds) || !gObj.discipleIds.length)) {
      return gObj;
    }
    const aliveDisciples = (gObj.discipleIds || []).map(id => W.byId && W.byId[id]).filter(n => X.isAvailableForExpedition(W, n));
    gObj.discipleIds = aliveDisciples.map(d => d.id);
    const menagerie = (CULT && CULT.ensureMenagerie) ? CULT.ensureMenagerie(W) : ((W.sect && W.sect.beasts) || []);
    const beast = gObj.beastUid ? menagerie.find(b => b && !b.dead && (b.uid === gObj.beastUid || b.id === gObj.beastUid)) : null;
    if (!beast && gObj.beastUid) {
      gObj.beastUid = null;
      gObj.beastNameTh = null;
    }
    const fsSummary = (CULT && CULT.sectFourSymbolSummary) ? CULT.sectFourSymbolSummary(W) : null;
    const isBlackTortoise = !!(
      (beast && (beast.fourSymbol === 'BLACK_TORTOISE' || beast.bloodlineTrait === 'BLACK_TORTOISE')) ||
      aliveDisciples.some(d => (CULT.activePets ? CULT.activePets(d) : []).some(p => p.fourSymbol === 'BLACK_TORTOISE')) ||
      (fsSummary && fsSummary.hasBlackTortoise && gObj.bastionActive && (aliveDisciples.length > 0 || beast))
    );
    const discPower = aliveDisciples.reduce((s, d) => s + CULT.power(d), 0);
    const beastPower = beast ? (CULT.petPowerSingle ? CULT.petPowerSingle(beast) : 120) : 0;
    const baseDef = (X.RESOURCE_NODE_DEFS[rn.id] && X.RESOURCE_NODE_DEFS[rn.id].garrisonPowerBase) || 320;
    const bastionMult = isBlackTortoise ? 1.45 : 1.0;
    gObj.defensePower = Math.round((baseDef * 0.65 + discPower + beastPower * 1.5) * bastionMult);
    gObj.yieldMultiplier = isBlackTortoise ? 1.25 : (aliveDisciples.length || beast ? 1.10 : 1.0);
    gObj.bastionActive = isBlackTortoise;
    return gObj;
  };

  X.harvestResourceNodes = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, totalStones: 0, mats: {} };
    X.ensureWorldTopology(W);
    let totalStones = 0;
    const matsHarvested = {};
    const nodesHarvested = [];
    const curDay = W.day || 0;
    const seasonPeriod = Math.floor(curDay / 90);
    Object.values(W.world.resourceNodes || {}).forEach(rn => {
      if (!rn || rn.ownerSectId !== 'PLAYER') return;
      if (opts.seasonal) {
        const canSeasonal = !!(opts.force || (curDay > 0 && (curDay % 90 === 0) && rn.lastSeasonalHarvestPeriod !== seasonPeriod));
        if (!canSeasonal) return;
      } else {
        if (!opts.force && rn.lastDailyHarvestDay === curDay && curDay > 0) return;
      }
      X.recomputeNodeGarrison(W, rn);
      const mult = (rn.garrison && rn.garrison.yieldMultiplier) || 1.0;
      const isSeasonal = !!opts.seasonal;
      const rawStones = Math.round((isSeasonal ? (rn.seasonalStones || 300) : (rn.dailyStones || 16)) * mult);
      const pool = W.world && (W.world.resourcePool || (W.world.resourcePool = { stones: 50000, herbs: 5000, ores: 5000 }));
      const stones = pool && Number.isFinite(pool.stones) ? Math.min(rawStones, Math.max(0, Math.floor(pool.stones))) : 0;
      if (stones > 0) {
        if (pool && Number.isFinite(pool.stones) && pool.stones >= stones) pool.stones -= stones;
        ECO.earn(W, stones, 'รายได้จากจุดยุทธศาสตร์「' + rn.nameTh + '」');
        totalStones += stones;
        rn.accumulatedStones = (rn.accumulatedStones || 0) + stones;
      }
      if (Array.isArray(rn.mats) && rn.mats.length && (isSeasonal || opts.includeMats !== false)) {
        const matId = rn.mats[curDay % rn.mats.length];
        const qty = isSeasonal ? Math.round(3 * mult) : (rn.garrison && rn.garrison.bastionActive ? 2 : 1);
        if (ECO.matById && ECO.matById[matId]) {
          ECO.add(W, matId, qty);
          matsHarvested[matId] = (matsHarvested[matId] || 0) + qty;
        }
      }
      rn.lastHarvestDay = curDay;
      rn._lastHarvestedDay = curDay;
      if (isSeasonal) rn.lastSeasonalHarvestPeriod = seasonPeriod;
      else rn.lastDailyHarvestDay = curDay;
      nodesHarvested.push({ nodeId: rn.id, nameTh: rn.nameTh, stones, seasonal: isSeasonal });
    });
    return { ok: true, totalStones, mats: matsHarvested, nodes: nodesHarvested };
  };

  X.contestResourceNode = (W, nodeId, attackerSectOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const rn = W.world.resourceNodes && W.world.resourceNodes[nodeId];
    if (!rn) return { ok: false, reason: 'invalid-resource-node' };
    X.recomputeNodeGarrison(W, rn);
    const attacker = X.findSect(W, attackerSectOrId) || (W.world.sects && W.world.sects[0]);
    const atkPower = opts.attackerPower || Math.round(((attacker && attacker.power) || 1.1) * 310);
    const defPower = (rn.garrison && rn.garrison.defensePower) || 260;
    const repelled = opts.forceLose ? false : (opts.forceRepel ? true : defPower >= atkPower * 0.85);
    if (repelled) {
      W.fame(2);
      W.log('raid', '🛡️ กองกำลังประจำการ ณ「' + rn.nameTh + '」' + (rn.garrison && rn.garrison.bastionActive ? ' [ปราการเต่าดำเสวียนอู่]' : '') + ' ต้านทานการโจมตีแย่งชิงของ' + (attacker ? attacker.nameTh : 'ศัตรู') + ' สำเร็จ!', []);
      return { ok: true, repelled: true, nodeId: rn.id, defPower, atkPower, ownerSectId: rn.ownerSectId };
    } else {
      rn.ownerSectId = attacker ? attacker.id : 'NEUTRAL';
      rn.ownerNameTh = attacker ? attacker.nameTh : 'กองกำลังอิสระ';
      X.recomputeNodeGarrison(W, rn);
      X.ensureWorldTopology(W);
      W.log('raid', '⚠️ จุดยุทธศาสตร์「' + rn.nameTh + '」ถูก' + rn.ownerNameTh + 'ตีแตกและแย่งชิงไป!', []);
      return { ok: true, repelled: false, nodeId: rn.id, defPower, atkPower, ownerSectId: rn.ownerSectId };
    }
  };

  /* ---------- Timed Serendipitous World Anomalies ---------- */
  X.spawnWorldAnomaly = (W, spec) => {
    spec = spec || {};
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    const tplKey = spec.templateId || spec.kind || Object.keys(X.ANOMALY_TEMPLATES)[(W.day || 0) % Object.keys(X.ANOMALY_TEMPLATES).length];
    const tpl = X.ANOMALY_TEMPLATES[tplKey] || X.ANOMALY_TEMPLATES.GROTTO_ANCIENT_IMMORTAL;
    const fsSummary = (CULT && CULT.sectFourSymbolSummary) ? CULT.sectFourSymbolSummary(W) : null;
    const phoenixBonusDays = (fsSummary && fsSummary.hasVermilionPhoenix) ? 4 : 0;
    const durationDays = (spec.durationDays || tpl.durationDays || 14) + phoenixBonusDays;
    const rival = X.findSect(W, spec.rivalSectId) || (W.world.sects || []).find(s => !s.isVassal) || (W.world.sects && W.world.sects[0]);
    const coords = {
      NORTHERN_PEAKS: { x: 48, y: 18 },
      SOUTHERN_WATERS: { x: 44, y: 82 },
      EASTERN_PLAINS: { x: 80, y: 40 },
      WESTERN_BADLANDS: { x: 18, y: 46 },
      CENTRAL_HEARTLAND: { x: 56, y: 44 }
    };
    const macroRegion = spec.macroRegion || tpl.macroRegion || 'NORTHERN_PEAKS';
    const pos = coords[macroRegion] || coords.NORTHERN_PEAKS;
    const anomaly = {
      id: spec.id || ('ANOMALY_' + (W.day || 0) + '_' + (++W.world.seq)),
      templateId: tpl.id,
      nameTh: spec.nameTh || tpl.nameTh,
      icon: spec.icon || tpl.icon,
      macroRegion,
      terrain: spec.terrain || tpl.terrain,
      danger: spec.danger || tpl.danger,
      x: spec.x || pos.x,
      y: spec.y || pos.y,
      baseDays: spec.baseDays || tpl.baseDays || 5,
      spawnDay: W.day || 0,
      durationDays,
      expiresDay: (W.day || 0) + durationDays,
      rivalSectId: rival ? rival.id : 'S0',
      rivalSectNameTh: rival ? rival.nameTh : 'สำนักคู่แข่ง',
      rivalEtaDay: (W.day || 0) + (spec.rivalEtaDays != null ? spec.rivalEtaDays : Math.max(5, Math.round(durationDays * 0.65))),
      rivalPower: spec.rivalPower || Math.round(((rival && rival.power) || 1.1) * 280),
      phoenixDetectedEarly: phoenixBonusDays > 0,
      resolved: false,
      expired: false,
      claimedBy: null,
      descTh: tpl.descTh
    };
    W.world.anomalies.unshift(anomaly);
    if (spec.rivalEtaDays == null && rival) {
      const topo = X.ensureWorldTopology(W);
      const route = X.planContinentalRoute(W,topo,topo.nodes[anomaly.id],rival.nodeId);
      if (route) anomaly.rivalEtaDay = (W.t || 0) / 1440 + 1 + route.days;
    }
    X.revealMacroRegion(W, macroRegion);
    X.ensureWorldTopology(W);
    W.log('explore', '☄️ วาสนาฟ้าดินปรากฏ ณ ' + (X.WORLD_REGIONS[macroRegion]?.shortTh || macroRegion) + ':「' + anomaly.nameTh + '」 (คงอยู่ ' + durationDays + ' วัน · ' + anomaly.rivalSectNameTh + ' กำลังส่งคนไปแย่งชิง!)', []);
    return anomaly;
  };

  X.departWorldAnomaly = (W, party, anomalyOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const anomaly = typeof anomalyOrId === 'object' ? anomalyOrId : (W.world.anomalies || []).find(a => a && a.id === anomalyOrId);
    if (!anomaly || anomaly.resolved || anomaly.expired) return { ok: false, reason: 'anomaly-unavailable' };
    if (!opts.immediate && (W.world.expeds || []).some(e => e && !e.done && e.kind === 'world_anomaly' && e.anomalyId === anomaly.id)) return { ok:false, reason:'already-en-route' };
    let members = [];
    if (Array.isArray(party) && party.length) {
      const seen = new Set();
      for (const x of party) {
        const n = typeof x === 'string' ? (W.byId && W.byId[x]) : x;
        if (!X.isAvailableForExpedition(W, n)) return { ok: false, reason: 'unavailable-member' };
        if (seen.has(n.id)) return { ok: false, reason: 'duplicate-member' };
        seen.add(n.id);
        members.push(n);
      }
    } else {
      members = (W.npcs || []).filter(n => X.isAvailableForExpedition(W, n)).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 3);
    }
    if (!members.length) return { ok: false, reason: 'no-party' };

    const travel = X.estimateTravelTime(W, members, anomaly.id, { baseDays: anomaly.baseDays, useSectPhoenixAura: true });
    if (opts.immediate) {
      return X.resolveWorldAnomaly(W, anomaly, members, Object.assign({}, opts, { travel }));
    }
    const ex = {
      id: ++W.world.seq,
      kind: 'world_anomaly',
      region: anomaly.id,
      anomalyId: anomaly.id,
      party: members.map(m => m.id),
      t0: W.t,
      ret: W.t + Math.round(travel.days * 1440),
      days: travel.days,
      baseDays: travel.baseDays,
      hasMount: travel.hasMount,
      hasPhoenixMount: travel.hasPhoenixMount,
      durationMultiplier: travel.durationMultiplier,
      journal: ['เร่งเดินทางสู่วาสนาฟ้าดิน「' + anomaly.nameTh + '」'],
      carry: [],
      supplies: 0,
      done: false,
      state: 'away'
    };
    setJourney(ex, travel.route, travel.days, 0, false);
    W.world.expeds.push(ex);
    members.forEach(m => { m.expId = ex.id; m.away = true; m.lastTrip = W.day; });
    X.releaseDeployedGarrisons(W, members);
    W.log('explore', '☄️ ส่งคณะของ ' + members.map(m => m.h.name.given).join('、') + ' เร่งเดินทางสู่「' + anomaly.nameTh + '」 (ใช้เวลา ' + travel.days + ' วัน)', members.map(m => m.id), {location:routePlace(ex.route)});
    return { ok: true, queued: true, anomaly, expedition: ex, travel };
  };

  X.resolveWorldAnomaly = (W, anomalyOrId, party, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const anomaly = typeof anomalyOrId === 'object' ? anomalyOrId : (W.world.anomalies || []).find(a => a && a.id === anomalyOrId);
    if (!anomaly || anomaly.resolved || anomaly.expired) {
      // An event can expire while a party is en route. Always settle the
      // expedition and release its members even though no reward is available.
      if (opts.ex && !opts.ex.done) {
        opts.ex.done = true;
        const returned = (opts.ex.party || []).map(id => W.byId[id]).filter(n => n && !n.dead && n.expId === opts.ex.id);
        returned.forEach(n => { n.expId = null; n.away = false; n.hidden = false; n.travel = null; });
        if (returned.length) W.log('explore', 'คณะถึงจุดหมายหลังวาสนาฟ้าดินสิ้นสุด จึงเดินทางกลับ', returned.map(n => n.id));
      }
      return { ok: false, reason: anomaly ? 'already-resolved' : 'anomaly-not-found', claimedBy: anomaly && anomaly.claimedBy };
    }

    const members = Array.isArray(party) && party.length
      ? party.map(x => typeof x === 'string' ? W.byId[x] : x).filter(n => n && !n.dead)
      : (W.npcs || []).filter(n => n && !n.dead).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 3);
    if (!members.length) return { ok: false, reason: 'no-party' };

    const travel = opts.travel || (opts.ex?.route && {days:opts.ex.travelMinutes / 1440, hasPhoenixMount:opts.ex.hasPhoenixMount}) ||
      X.estimateTravelTime(W, members, anomaly.id, { baseDays: anomaly.baseDays, useSectPhoenixAura: true });
    const arrivalDay = opts.ex?.arriveAt != null ? opts.ex.arriveAt / 1440 :
      (W.day || 0) + (opts.immediate ? travel.days : 0);
    const arrivedBeforeRival = arrivalDay <= (anomaly.rivalEtaDay || 999999);
    const partyPower = members.reduce((s, m) => s + CULT.power(m), 0) * (travel.hasPhoenixMount ? 1.15 : 1.0);
    const wonContest = opts.forceRivalWin ? false : (opts.forceWin || (arrivedBeforeRival ? partyPower >= (anomaly.rivalPower || 250) * 0.65 : partyPower >= (anomaly.rivalPower || 250) * 1.25));

    if (opts.ex) {
      opts.ex.done = true;
    }
    members.forEach(m => {
      m.expId = null; m.away = false; m.hidden = false; m.travel = null;
      if (!arrivedBeforeRival && m.h && m.h.state) {
        const hm = CULT.hpMax(m);
        m.h.state.hp = Math.max(1, Math.round((m.h.state.hp || hm) - hm * (wonContest ? 0.15 : 0.25)));
      }
    });

    if (!wonContest) {
      anomaly.resolved = true;
      anomaly.claimedBy = anomaly.rivalSectId || 'RIVAL';
      X.ensureWorldTopology(W);
      W.log('explore', '✘ คณะเดินทางไปถึง「' + anomaly.nameTh + '」ช้ากว่า' + anomaly.rivalSectNameTh + ' สมบัติหลักถูกชิงตัดหน้าไป!', members.map(m => m.id));
      return { ok: true, won: false, claimedBy: anomaly.claimedBy, anomalyId: anomaly.id, arrivedBeforeRival };
    }

    const tpl = X.ANOMALY_TEMPLATES[anomaly.templateId] || X.ANOMALY_TEMPLATES.GROTTO_ANCIENT_IMMORTAL;
    const pool = W.world && (W.world.resourcePool || (W.world.resourcePool = { stones: 50000, herbs: 5000, ores: 5000 }));
    const rawStones = tpl.stones || 350;
    const anomStones = (pool && Number.isFinite(pool.stones)) ? Math.min(rawStones, Math.max(0, Math.floor(pool.stones))) : rawStones;
    if (pool && Number.isFinite(pool.stones)) pool.stones -= anomStones;
    const rewards = { stones: anomStones, mats: {}, catalysts: [], manualId: null, recipeId: null };
    if (anomStones > 0) ECO.earn(W, rewards.stones, 'พิชิตวาสนาฟ้าดิน「' + anomaly.nameTh + '」');
    if (tpl.mats) {
      Object.entries(tpl.mats).forEach(([mId, qty]) => {
        if (ECO.matById && ECO.matById[mId]) {
          ECO.add(W, mId, qty);
          rewards.mats[mId] = qty;
        }
      });
    }
    [tpl.catalystId, tpl.primordialId].filter(Boolean).forEach(cId => {
      if (ECO.addCatalyst) ECO.addCatalyst(W, cId, 1);
      else ECO.add(W, cId, 1);
      rewards.catalysts.push(cId);
    });
    if (tpl.grantManual) {
      const allTechs = (JD && JD.TECH && JD.TECH.techniques) || [];
      const pickTech = allTechs.find(t => t && (t.tier || 1) >= 4 && !(W.sect.library || []).includes(t.id)) || allTechs[0];
      if (pickTech) {
        W.sect.library = W.sect.library || [];
        if (!W.sect.library.includes(pickTech.id)) W.sect.library.push(pickTech.id);
        rewards.manualId = pickTech.id;
      }
    }
    if (tpl.grantRecipe) {
      const allRecs = (JD && JD.ITEMS && JD.ITEMS.recipes) || [];
      const pickRec = allRecs.find(r => r && r.discoverable && !(W.sect.knownRecipes || []).includes(r.id));
      if (pickRec) {
        W.sect.knownRecipes = W.sect.knownRecipes || [];
        W.sect.knownRecipes.push(pickRec.id);
        rewards.recipeId = pickRec.id;
      }
    }
    anomaly.resolved = true;
    anomaly.claimedBy = 'PLAYER';
    anomaly.resolvedDay = W.day || 0;
    anomaly.rewards = rewards;
    members.forEach(m => { m.merit = (m.merit || 0) + 22; HC.experience(m, 'duel_win', 0.7); });
    W.fame(4.5);
    X.ensureWorldTopology(W);
    const catalystNamesTh = rewards.catalysts.map(cId => (ECO && ECO.REFINEMENT_CATALYSTS && ECO.REFINEMENT_CATALYSTS[cId] && ECO.REFINEMENT_CATALYSTS[cId].nameTh) || cId);
    W.log('explore', '🌟 ช่วงชิงวาสนาฟ้าดิน「' + anomaly.nameTh + '」สำเร็จก่อน' + anomaly.rivalSectNameTh + '! ได้รับศิลาวิญญาณ ' + rewards.stones + ' ก้อน และแก่นวิเศษ「' + catalystNamesTh.join(', ') + '」', members.map(m => m.id));
    return { ok: true, won: true, claimedBy: 'PLAYER', anomalyId: anomaly.id, arrivedBeforeRival, travelDays: travel.days, rewards };
  };

  /* ---------- Patch v2.0.19: Thematic vs Eclectic Disciple Loadouts, Cross-Alignment Clashes & Grand Alliance Politics ---------- */
  X.buildSectDiscipleLoadout = (W, sectOrId, index, stageOverride) => {
    const s = X.findSect(W, sectOrId) || (W && W.world && W.world.allSects && W.world.allSects[0]) || X.CANONICAL_SECTS[0];
    const idx = Math.max(0, Number(index) || 0);
    const tierLv = s.tierLevel || 2;
    const stage = clamp(stageOverride != null ? stageOverride : Math.max(1, tierLv - (idx === 0 ? 0 : 1)), 1, 7);
    const isEclectic = s.doctrineMode === 'ECLECTIC';

    const pathPool = isEclectic && Array.isArray(s.allowedPaths) && s.allowedPaths.length
      ? s.allowedPaths
      : [s.majorPath || 'XIAN'];
    const chosenPath = pathPool[idx % pathPool.length] || 'XIAN';

    let subPool = Array.isArray(s.signatureSubs) && s.signatureSubs.length ? s.signatureSubs : [];
    if (isEclectic && CULT && CULT.PATHS && CULT.PATHS[chosenPath] && Array.isArray(CULT.PATHS[chosenPath].subPaths)) {
      const pSubs = CULT.PATHS[chosenPath].subPaths.map(sp => sp.id);
      if (pSubs.length) subPool = pSubs;
    }
    const chosenSub = subPool.length ? subPool[idx % subPool.length] : 'NONE';

    const wpnPool = Array.isArray(s.signatureWeaponTypes) && s.signatureWeaponTypes.length
      ? s.signatureWeaponTypes
      : (isEclectic ? ['SWORD', 'BLADE', 'SPEAR', 'BOW', 'FIST', 'STAFF', 'FOCUS', 'ZITHER', 'BRUSH', 'WHIP'] : ['SWORD']);
    const chosenWeapon = wpnPool[idx % wpnPool.length] || 'SWORD';

    let techs = Array.isArray(s.signatureTechs) ? s.signatureTechs.slice() : [];
    if (isEclectic && JD && JD.TECH && Array.isArray(JD.TECH.techniques)) {
      const pathTechs = JD.TECH.techniques.filter(t => t && (t.path === chosenPath || t.path === 'ANY') && (t.tier || 1) <= stage + 1).slice(0, 3).map(t => t.id);
      if (pathTechs.length) techs = Array.from(new Set(techs.concat(pathTechs))).slice(0, 4);
    }

    const wNameTh = (JD && JD.MARTIAL && JD.MARTIAL.types && JD.MARTIAL.types[chosenWeapon]) || chosenWeapon;
    return {
      sectId: s.id || s.codeId,
      sectNameTh: s.nameTh,
      orgType: s.orgType || 'สำนัก',
      doctrineMode: s.doctrineMode || 'THEMATIC',
      alignment: s.alignment || 'NEUTRAL',
      sectTier: s.sectTier || 'STANDARD',
      tierLevel: tierLv,
      path: chosenPath,
      sub: chosenSub,
      stage,
      weaponType: chosenWeapon,
      weaponNameTh: (s.doctrineMode === 'THEMATIC' && s.signatureGearTh) ? s.signatureGearTh.split('&')[0].trim() : ('ศาสตรา' + wNameTh + 'ประจำตัว'),
      techs
    };
  };

  X.computeDiscipleClashChance = (W, partyOrAlignment, otherSectOrId, opts) => {
    opts = opts || {};
    const s = typeof otherSectOrId === 'object' && otherSectOrId ? otherSectOrId : X.findSect(W, otherSectOrId);
    const otherAlign = (s && s.alignment) || opts.otherAlignment || 'NEUTRAL';
    let playerAlign = 'NEUTRAL';
    let party = [];
    if (typeof partyOrAlignment === 'string') {
      playerAlign = partyOrAlignment;
    } else if (Array.isArray(partyOrAlignment)) {
      party = partyOrAlignment;
      playerAlign = (W && W.sect && W.sect.alignment) || 'NEUTRAL';
    } else if (W && W.sect && W.sect.alignment) {
      playerAlign = W.sect.alignment;
    }

    // Base ideological clash rate:
    // - Opposite alignment (RIGHTEOUS vs DEMONIC): 0.62
    // - One side NEUTRAL vs RIGHTEOUS/DEMONIC: 0.28
    // - Same alignment: 0.14 (or 0.22 for DEMONIC vs DEMONIC) -> same side can still clash over resources/grudges!
    const isOpposite = (playerAlign === 'RIGHTEOUS' && otherAlign === 'DEMONIC') || (playerAlign === 'DEMONIC' && otherAlign === 'RIGHTEOUS');
    const isSame = playerAlign === otherAlign;
    let baseProb = isOpposite ? 0.62 : isSame ? (playerAlign === 'DEMONIC' ? 0.22 : 0.14) : 0.28;

    // Attitude & Treaty modifiers
    const att = s && Number.isFinite(s.attitude) ? s.attitude : 0;
    let mod = -att * 0.0028;
    const treaty = s && s.treaty ? s.treaty : 'NONE';
    if (treaty === 'RIVAL_FEUD' || treaty === 'EMBARGO') mod += 0.24;
    else if (['ALLIANCE', 'ALLIANCE_PACT', 'VASSAL_TREATY', 'NON_AGGRESSION'].includes(treaty)) mod -= 0.32;

    // Party leader personality modifier
    const lead = party[0] || (W && W.byId && W.sect && W.byId[W.sect.masterId]) || null;
    if (lead && lead.h) {
      const aggr = E(lead, 'personality.aggression');
      const pride = E(lead, 'personality.pride');
      const caution = E(lead, 'personality.caution');
      const emp = E(lead, 'personality.empathy');
      mod += ((aggr - 50) * 0.0022) + ((pride - 50) * 0.0014) - ((caution - 50) * 0.0018) - ((emp - 50) * 0.0012);
    }

    // Active ideological crusade & Faction Leadership Doctrine modifier (v2.0.20)
    if (isOpposite && W && W.world && W.world.grandPolitics && W.world.grandPolitics.activeCrusade) {
      mod += 0.16;
    }
    const alliances = W && W.world && W.world.grandPolitics && W.world.grandPolitics.alliances;
    if (!isSame && alliances && alliances[otherAlign] && Number.isFinite(alliances[otherAlign].clashChanceMod)) {
      mod += alliances[otherAlign].clashChanceMod * (isOpposite ? 1.0 : 0.35);
    }

    const probability = clamp(+(baseProb + mod).toFixed(4), 0.04, 0.95);
    return {
      probability,
      baseProb,
      playerAlignment: playerAlign,
      otherAlignment: otherAlign,
      isOppositeAlignment: isOpposite,
      isSameAlignment: isSame,
      reasonTh: isOpposite
        ? ('ต่างขั้วอุดมการณ์ (' + playerAlign + ' ปะทะ ' + otherAlign + ') โอกาสปะทะสูง')
        : isSame
        ? ('อยู่ฝ่ายเดียวกัน (' + playerAlign + ') แต่อาจขัดแย้งเรื่องทรัพยากรหรือศักดิ์ศรี')
        : ('สำนักสายกลางพบปะฝ่าย' + (otherAlign === 'RIGHTEOUS' ? 'ธรรมะ' : 'อธรรม'))
    };
  };

  X.resolveDiscipleSectEncounter = (W, party, otherSectOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const members = (Array.isArray(party) ? party.map(x => typeof x === 'string' ? W.byId[x] : x).filter(n => n && !n.dead) : []).slice(0, 5);
    const lead = members[0] || (W.npcs && W.npcs.find(n => n && !n.dead));
    if (!lead) return { ok: false, reason: 'no-party' };

    const pool = (W.world.allSects || []).filter(s => s && !s.isVassal);
    const targetSect = (otherSectOrId && X.findSect(W, otherSectOrId)) || (pool.length ? pool[(W.day || 0) % pool.length] : W.world.allSects[0]);
    if (!targetSect) return { ok: false, reason: 'no-target-sect' };

    const clashInfo = X.computeDiscipleClashChance(W, members.length ? members : [lead], targetSect, opts);
    const roll = opts.forceClash === true ? 0 : opts.forceClash === false ? 0.999 : (W.rng ? W.rng.next() : 0.5);
    const didClash = roll < clashInfo.probability;
    const rivalLoadout = X.buildSectDiscipleLoadout(W, targetSect, (W.day || 0) % 4);
    const gp = W.world.grandPolitics || (W.world.grandPolitics = { discipleEncounters: { total: 0, clashes: 0, exchanges: 0, oppositeAlignmentClashes: 0, sameAlignmentClashes: 0 }, interSectWars: [] });
    gp.discipleEncounters.total = (gp.discipleEncounters.total || 0) + 1;

    if (didClash) {
      gp.discipleEncounters.clashes = (gp.discipleEncounters.clashes || 0) + 1;
      if (clashInfo.isOppositeAlignment) gp.discipleEncounters.oppositeAlignmentClashes = (gp.discipleEncounters.oppositeAlignmentClashes || 0) + 1;
      if (clashInfo.isSameAlignment) gp.discipleEncounters.sameAlignmentClashes = (gp.discipleEncounters.sameAlignmentClashes || 0) + 1;

      const activeParty = members.length ? members : [lead];
      const rivalDummy = { foe: true, kind: 'human', weaponType: rivalLoadout.weaponType || 'SWORD', equip: { WEAPON: { slot: 'WEAPON', gearType: rivalLoadout.weaponType || 'SWORD' } } };
      const dsh = (COMBAT && COMBAT.evaluateTacticalBoutSummary) ? COMBAT.evaluateTacticalBoutSummary(activeParty, [rivalDummy]) : null;
      const dshMult = dsh ? (1 + clamp(dsh.advantageDelta * 0.5, -0.10, 0.10)) : 1;
      const ourPower = activeParty.reduce((sum, m) => sum + CULT.power(m), 0) * dshMult;
      const theirPower = Math.round((targetSect.power || 1.1) * 190 * Math.max(1, (members.length || 1) * 0.65));
      const won = opts.forceWin === true ? true : opts.forceWin === false ? false : (ourPower >= theirPower * 0.82);
      const wantLoot = won ? Math.round(35 + (targetSect.tierLevel || 2) * 22) : 0;
      const stonesLoot = (won && wantLoot > 0 && ECO)
        ? (ECO.earnFromPool ? ECO.earnFromPool(W, wantLoot, 'ปราบศิษย์' + targetSect.nameTh + 'ระหว่างเดินทาง', { rivalSect: targetSect }) : (ECO.earn && ECO.earn(W, wantLoot, 'ปราบศิษย์' + targetSect.nameTh + 'ระหว่างเดินทาง') ? wantLoot : 0))
        : 0;
      if (won) {
        (members.length ? members : [lead]).forEach(m => { m.merit = (m.merit || 0) + 12; HC.experience(m, 'duel_win', 0.35); });
        W.fame(clashInfo.isOppositeAlignment ? 2.5 : 1.0);
        targetSect.attitude = clamp((targetSect.attitude || 0) - (clashInfo.isOppositeAlignment ? 10 : 6), -100, 100);
      } else {
        targetSect.attitude = clamp((targetSect.attitude || 0) - 4, -100, 100);
        if (AI && AI.injure) AI.injure(W, lead, 1, 'ปะทะกับศิษย์' + targetSect.nameTh);
      }
      const rivalFig = (targetSect.figures && targetSect.figures.successor) || (targetSect.figures && targetSect.figures.deputy);
      const rivalNameTh = rivalFig ? rivalFig.titleAndNameTh : ('ศิษย์เอกแห่ง' + targetSect.nameTh);
      const summaryTh = HC.fullName(lead) + ' โคจรมาพบกับ ' + rivalNameTh + ' แห่ง「' + targetSect.nameTh + '」(' + rivalLoadout.path + ' · ถือครอง' + rivalLoadout.weaponNameTh + ') นอกสำนัก! ด้วยความต่างขั้วและศักดิ์ศรีจึงเปิดฉากปะทะกันอย่างดุเดือด — ' + (won ? ('ฝ่ายเราสำแดงวิชายุทธ์เหนือชั้น สยบคู่ต่อสู้และยึดศิลาวิญญาณได้ ' + stonesLoot + ' ก้อน!') : 'คู่ต่อสู้มีกระบวนท่าเฉียบคม ฝ่ายเราจำต้องล่าถอยกลับมาตั้งหลัก');
      if (X.recordChronicle) {
        X.recordChronicle(W, {
          category: 'BATTLE',
          icon: '⚔️',
          macroRegion: targetSect.macroRegion || 'CENTRAL_HEARTLAND',
          involvedSects: [W.sect.name, targetSect.nameTh],
          involvedFigures: [HC.fullName(lead), rivalNameTh],
          titleTh: 'ศึกปะทะนอกสำนัก: ' + HC.fullName(lead) + ' ประมือ ' + rivalNameTh + ' (' + targetSect.nameTh + ')',
          storyTh: summaryTh,
          combatBreakdownTh: 'โอกาสปะทะ: ' + Math.round(clashInfo.probability * 100) + '% (' + clashInfo.reasonTh + ') · อาวุธคู่ต่อสู้: ' + rivalLoadout.weaponNameTh + (dsh && dsh.summaryTh ? (' · ' + dsh.summaryTh) : ''),
          consequenceTh: won ? ('ชนะศึก ได้รับ +' + stonesLoot + ' ศิลาวิญญาณ และชื่อเสียงยุทธภพ') : (HC.fullName(lead) + ' ได้รับบาดเจ็บจากการปะทะ'),
          combatSummary: dsh || null,
          quiet: true
        });
      }
      if (!opts.quiet && W.log) W.log('mission', '⚔️ ' + summaryTh, (members.length ? members : [lead]).map(m => m.id));
      return {
        ok: true,
        outcome: 'SECT_CLASH',
        didClash: true,
        won,
        stonesLoot,
        clashInfo,
        rivalSectId: targetSect.id,
        rivalSectNameTh: targetSect.nameTh,
        rivalLoadout,
        tacticalSummary: dsh,
        summaryTh
      };
    } else {
      gp.discipleEncounters.exchanges = (gp.discipleEncounters.exchanges || 0) + 1;
      targetSect.attitude = clamp((targetSect.attitude || 0) + 3, -100, 100);
      (members.length ? members : [lead]).forEach(m => {
        if (m.cult) CULT.gain(m, 8, W, 'jianghu_exchange');
        (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(m, 'diplomacy', 0.4, 1);
      });
      const summaryTh = HC.fullName(lead) + ' พบปะแลกเปลี่ยนวิชายุทธ์กับศิษย์ของ「' + targetSect.nameTh + '」(' + rivalLoadout.weaponNameTh + ') อย่างฉันมิตร (+ความสัมพันธ์ +3)';
      if (!opts.quiet && W.log) W.log('mission', '🤝 ' + summaryTh, (members.length ? members : [lead]).map(m => m.id));
      return {
        ok: true,
        outcome: 'SECT_EXCHANGE',
        didClash: false,
        won: false,
        stonesLoot: 0,
        clashInfo,
        rivalSectId: targetSect.id,
        rivalSectNameTh: targetSect.nameTh,
        rivalLoadout,
        summaryTh
      };
    }
  };

  X.computeSectWarProbability = (W, sectAOrPlayer, sectBOrId) => {
    const isPlayerA = !sectAOrPlayer || sectAOrPlayer === 'PLAYER' || (W && W.sect && sectAOrPlayer === W.sect);
    const alignA = isPlayerA ? ((W && W.sect && W.sect.alignment) || 'NEUTRAL') : (sectAOrPlayer.alignment || 'NEUTRAL');
    const tierA = isPlayerA ? ((W && W.sect && W.sect.tierLevel) || 1) : (sectAOrPlayer.tierLevel || 2);
    const sB = typeof sectBOrId === 'object' && sectBOrId ? sectBOrId : X.findSect(W, sectBOrId);
    const alignB = (sB && sB.alignment) || 'NEUTRAL';
    const tierB = (sB && sB.tierLevel) || 2;
    const att = (sB && Number.isFinite(sB.attitude)) ? sB.attitude : 0;
    const treaty = (sB && sB.treaty) || 'NONE';

    const isOpposite = (alignA === 'RIGHTEOUS' && alignB === 'DEMONIC') || (alignA === 'DEMONIC' && alignB === 'RIGHTEOUS');
    const isSame = alignA === alignB;
    let prob = isOpposite ? 0.48 : isSame ? (alignA === 'DEMONIC' ? 0.20 : 0.10) : 0.22;
    prob += clamp(-att * 0.003, -0.20, 0.30);
    if (treaty === 'RIVAL_FEUD' || treaty === 'EMBARGO') prob += 0.25;
    if (['ALLIANCE', 'ALLIANCE_PACT', 'VASSAL_TREATY', 'NON_AGGRESSION'].includes(treaty)) prob -= 0.35;
    if (Math.abs(tierA - tierB) <= 1) prob += 0.05; // Peer-tier rivalry
    return {
      probability: clamp(+prob.toFixed(4), 0.02, 0.95),
      alignA,
      alignB,
      isOppositeAlignment: isOpposite,
      isSameAlignment: isSame
    };
  };

  X.tickGrandAlliancePolitics = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    const gp = W.world.grandPolitics;
    const all = W.world.allSects || [];
    const playerAlign = (W.sect && W.sect.alignment) || 'NEUTRAL';
    const events = [];

    // 1. Apply alignment affinity drift toward Player Sect when Player has chosen RIGHTEOUS or DEMONIC
    if (playerAlign !== 'NEUTRAL') {
      all.forEach(s => {
        if (!s || s.isVassal) return;
        if (s.alignment === playerAlign) {
          s.attitude = clamp((s.attitude || 0) + 2, -100, 100);
        } else if ((playerAlign === 'RIGHTEOUS' && s.alignment === 'DEMONIC') || (playerAlign === 'DEMONIC' && s.alignment === 'RIGHTEOUS')) {
          s.attitude = clamp((s.attitude || 0) - 4, -100, 100);
        }
      });
    }

    // 2. Simulate an inter-sect conflict or alliance mobilization across the 19 Jianghu organizations
    const righteousSects = all.filter(s => s && s.alignment === 'RIGHTEOUS' && !s.isVassal);
    const demonicSects = all.filter(s => s && s.alignment === 'DEMONIC' && !s.isVassal);
    if (righteousSects.length && demonicSects.length && (opts.forceWar || (W.day || 0) % 15 === 0)) {
      const rSect = righteousSects[(W.day || 0) % righteousSects.length];
      const dSect = demonicSects[(W.day || 0) % demonicSects.length];
      const rScore = (rSect.power || 1) * (1 + (rSect.tierLevel || 2) * 0.12);
      const dScore = (dSect.power || 1) * (1 + (dSect.tierLevel || 2) * 0.12);
      const winner = rScore >= dScore ? rSect : dSect;
      const loser = winner === rSect ? dSect : rSect;
      winner.influence = (winner.influence || 60) + 8;
      loser.influence = Math.max(20, (loser.influence || 60) - 6);
      const wMaster = winner.figures && winner.figures.master;
      const lMaster = loser.figures && loser.figures.master;
      const warRec = {
        id: 'JHWAR_' + (W.day || 0) + '_' + winner.code,
        day: W.day || 0,
        attackerId: rSect.id,
        attackerNameTh: rSect.nameTh,
        defenderId: dSect.id,
        defenderNameTh: dSect.nameTh,
        winnerId: winner.id,
        winnerNameTh: winner.nameTh,
        kind: 'ALIGNMENT_WAR',
        summaryTh: 'ศึกปะทะสองขั้วอำนาจ:「' + winner.nameTh + '」(' + winner.tierNameTh + ' · นำโดย ' + (wMaster ? wMaster.titleAndNameTh : winner.leaderNameTh) + ') เปิดศึกถล่มค่ายหน้าด่านของ「' + loser.nameTh + '」(' + (lMaster ? lMaster.titleAndNameTh : loser.leaderNameTh) + ') ด้วยวิชา「' + (wMaster ? wMaster.signatureTechNameTh : 'เคล็ดวิชาประจำสำนัก') + '」คว้าชัยชนะอย่างดุเดือด!'
      };
      gp.interSectWars.unshift(warRec);
      if (gp.interSectWars.length > 20) gp.interSectWars.length = 20;
      events.push(warRec);
      if (X.recordChronicle) {
        X.recordChronicle(W, {
          category: 'BATTLE',
          icon: '🔥',
          macroRegion: loser.macroRegion || 'CENTRAL_HEARTLAND',
          involvedSects: [winner.nameTh, loser.nameTh],
          involvedFigures: [wMaster && wMaster.titleAndNameTh, lMaster && lMaster.titleAndNameTh].filter(Boolean),
          titleTh: 'ศึกยุทธภพ: 「' + winner.nameTh + '」เปิดศึกปะทะ「' + loser.nameTh + '」',
          storyTh: warRec.summaryTh,
          combatBreakdownTh: winner.nameTh + ' (กำลังรบ ' + winner.power + ') เอาชนะ ' + loser.nameTh + ' (กำลังรบ ' + loser.power + ')',
          consequenceTh: winner.nameTh + ' บารมีเพิ่มขึ้น +8 · ' + loser.nameTh + ' สูญเสียอิทธิพล -6',
          quiet: opts.quiet
        });
      }
      if (opts.lethalMasterClash && lMaster && X.resolveSectSuccession) {
        X.resolveSectSuccession(W, loser, 'สิ้นชีพในการศึกปะทะกับ「' + winner.nameTh + '」', { quiet: opts.quiet });
      }
    }

    gp.lastTickDay = W.day || 0;
    return { ok: true, playerAlignment: playerAlign, events, grandPolitics: gp };
  };

  const origDailyV218 = X.daily;
  X.daily = W => {
    X.initContinent(W);
    origDailyV218(W);
    X.ensureWorldTopology(W);
    X.tickContinentalCourts(W);
    // Daily resource node income & hegemony tick
    if (W.day > 0) {
      X.harvestResourceNodes(W, { seasonal: W.day % 90 === 0, includeMats: W.day % 5 === 0 });
      if (W.day % 10 === 0) { X.tickHegemony(W); X.considerNaturalEndgameEvents(W); }
      if (W.day % 12 === 0 || W.day % 15 === 0) X.tickGrandAlliancePolitics(W);
      if (W.day % 14 === 0 && X.tickAllianceCouncil) X.tickAllianceCouncil(W);
      if (W.day % 16 === 0 && X.tickAutonomousVisitorsV2) X.tickAutonomousVisitorsV2(W);
      if (W.day % 30 === 0 && X.holdGrandMartialAssembly) X.holdGrandMartialAssembly(W);
      if (W.day % 36 === 0 && X.tickHeavenlyCalamity) X.tickHeavenlyCalamity(W);
      (W.world.secretRealms || []).forEach(sr => {
        if (sr && sr.status === 'OPEN' && W.day >= (sr.expiresDay || 0) && X.resolveSecretRealmRace) {
          X.resolveSecretRealmRace(W, sr);
        }
      });
      if (W.day % 28 === 0 && X.spawnSecretRealm && !(W.world.secretRealms || []).some(sr => sr && sr.status === 'OPEN')) {
        X.spawnSecretRealm(W);
      }
      // Expire or rival-claim overdue anomalies
      (W.world.anomalies || []).forEach(a => {
        if (!a || a.resolved || a.expired) return;
        if (W.day >= a.expiresDay) {
          a.expired = true;
          a.resolved = true;
          a.claimedBy = a.rivalSectId || 'RIVAL';
        }
      });
      if (W.day % 24 === 0 && !(W.world.anomalies || []).some(a => a && !a.resolved && !a.expired)) {
        X.spawnWorldAnomaly(W);
      }
      // Natural expiration and non-forced occurrence of vassal distress calls under real geopolitical pressure
      if (Array.isArray(W.world.vassalDistressCalls)) {
        W.world.vassalDistressCalls.forEach(c => {
          if (c && !c.resolved && Number.isFinite(c.expiresDay) && W.day > c.expiresDay) {
            c.resolved = true;
            c.outcome = 'EXPIRED';
            c.resolvedDay = W.day;
            const vs = X.findSect(W, c.sectId);
            if (vs) vs.loyalty = clamp((vs.loyalty == null ? 60 : vs.loyalty) - 10, 0, 100);
            if (W.world.politics && W.world.politics.activeDistressCall === c) W.world.politics.activeDistressCall = null;
          }
        });
      }
      if (W.day >= 30 && W.day % 18 === 0 && !(W.world.vassalDistressCalls || []).some(c => c && !c.resolved)) {
        const vassals = (W.world.allSects || []).filter(s => s && (s.isVassal || s.treaty === 'VASSAL_TREATY') && (s.lastDistressDay == null || W.day - s.lastDistressDay >= 60));
        if (vassals.length) {
          const hostiles = (W.world.allSects || []).filter(s => s && !s.isVassal && s.treaty !== 'VASSAL_TREATY' && ((s.attitude || 0) <= -30 || s.treaty === 'RIVAL_FEUD'));
          const candidate = vassals[Math.floor(W.day / 18) % vassals.length];
          const chance = 0.22 + (hostiles.length ? 0.14 : 0) + ((candidate.loyalty != null && candidate.loyalty < 45) ? 0.12 : 0);
          const rollHit = !W.rng ? false : (typeof W.rng.chance === 'function' ? W.rng.chance(chance) : (W.rng.next() < chance));
          if (rollHit) {
            const threat = hostiles.length ? ('กองกำลังของ「' + hostiles[W.day % hostiles.length].nameTh + '」บุกประชิดชายแดน') : 'ฝูงอสูรคลั่งและกองโจรป่าปิดล้อมชายแดน';
            candidate.lastDistressDay = W.day;
            X.spawnVassalDistressCall(W, candidate, { threatNameTh: threat });
          }
        }
      }
    }
  };


  /* ============================================================================
   * Patch v2.0.20: 100% Procedural Sect Figures, Wandering Legends Reemergence,
   * Sect Succession Crisis (Deputy vs Successor), Faction Leadership Doctrines,
   * Seasonal Secret Realms Ruin-Racing, Autonomous Visitors 2.0 & Wuxia Chronicles
   * ============================================================================ */

  X.ALLIANCE_DOCTRINES = Object.freeze({
    HAWK_CRUSADE: {
      id: 'HAWK_CRUSADE',
      nameTh: 'สายเหยี่ยวพิชิตหล้า',
      badgeTh: '🦅 สายเหยี่ยว · รุกฆาตพิชิตหล้า',
      icon: '🦅',
      clashChanceMod: 0.16,
      warProbMod: 0.20,
      tradeBonusMult: 0.90,
      realmAggression: 0.78,
      descTh: 'ผู้นำฝ่ายมีนิสัยดุดันและทะเยอทะยาน มุ่งระดมพลเปิดศึกกวาดล้างฝ่ายตรงข้าม ช่วงชิงเหมืองแร่ และหนุนให้ศิษย์ในสังกัดเปิดฉากสังหารเมื่อพบศัตรูนอกสำนัก'
    },
    DOVE_HARMONY: {
      id: 'DOVE_HARMONY',
      nameTh: 'สายพิราบสันติภาพ',
      badgeTh: '🕊️ สายพิราบ · สันติและไมตรี',
      icon: '🕊️',
      clashChanceMod: -0.10,
      warProbMod: -0.15,
      tradeBonusMult: 1.20,
      realmAggression: 0.25,
      descTh: 'ผู้นำฝ่ายเปี่ยมเมตตาและคุณธรรม เน้นการเจรจาไกล่เกลี่ยข้อพิพาท แลกเปลี่ยนคัมภีร์ยุทธ์ และลดการปะทะนองเลือดโดยไม่จำเป็น'
    },
    MERCHANT_HEGEMONY: {
      id: 'MERCHANT_HEGEMONY',
      nameTh: 'สายพาณิชย์และผลประโยชน์',
      badgeTh: '🪙 สายพาณิชย์ · ครองเส้นทางทรัพย์',
      icon: '🪙',
      clashChanceMod: -0.04,
      warProbMod: -0.05,
      tradeBonusMult: 1.38,
      realmAggression: 0.48,
      descTh: 'ผู้นำฝ่ายให้ความสำคัญกับศิลาวิญญาณ ด่านภาษี และเส้นทางคาราวาน มุ่งขยายอิทธิพลทางเศรษฐกิจและเรียกเก็บผลประโยชน์จากสำนักน้อยใหญ่'
    },
    ORTHODOX_INQUISITION: {
      id: 'ORTHODOX_INQUISITION',
      nameTh: 'สายจารีตพิพากษา',
      badgeTh: '⚖️ สายจารีต · พิพากษากฎเหล็ก',
      icon: '⚖️',
      clashChanceMod: 0.12,
      warProbMod: 0.14,
      tradeBonusMult: 1.00,
      realmAggression: 0.62,
      descTh: 'ผู้นำฝ่ายยึดมั่นกฎระเบียบและศักดิ์ศรีอย่างเคร่งครัด ลงทัณฑ์สำนักที่ฝ่าฝืนมติสภา และไม่ยอมประนีประนอมกับพวกนอกรีต'
    },
    MYSTIC_SECLUSION: {
      id: 'MYSTIC_SECLUSION',
      nameTh: 'สายเร้นกายมรรคาเซียน',
      badgeTh: '🌌 สายเร้นกาย · มุ่งค้นแดนลับโบราณ',
      icon: '🌌',
      clashChanceMod: -0.06,
      warProbMod: -0.08,
      tradeBonusMult: 1.05,
      realmAggression: 0.55,
      descTh: 'ผู้นำฝ่ายฝักใฝ่สัจธรรมและคัมภีร์โบราณ ไม่สนใจศึกชิงเมืองทั่วไป แต่จะทุ่มกำลังยอดฝีมือทั้งหมดเมื่อแดนลับโบราณเปิดผนึก'
    }
  });

  const EPITHET_PREFIX_BY_PATH = Object.freeze({
    XIAN: ['กระบี่เมฆา', 'เซียนวายุ', 'ดาราพิสุทธิ์', 'ปราชญ์เก้าสวรรค์', 'รัศมีกระบี่'],
    BODY: ['วัชระทลายผา', 'พยัคฆ์เหล็ก', 'หมัดอสนีคลั่ง', 'กายาทองคำ', 'ขุนพลสะท้านภพ'],
    GOD: ['สุริยันเทวะ', 'เนตรสวรรค์', 'เพลิงเทวราช', 'ทัณฑ์สายฟ้า', 'มหาพรหมพิพากษา'],
    DEMON: ['มารโลหิต', 'เงาปลิดวิญญาณ', 'อสูรกลืนสวรรค์', 'พิษทมิฬเก้ากู่', 'ทวนกระดูกซิวหลัว'],
    HEART_SOUL: ['พู่กันวาดฝัน', 'พิณสะกดวิญญาณ', 'จิตว่างไร้ลักษณ์', 'มายาจันทร์คราม', 'ปราชญ์ใจกระจ่าง'],
    MECH_PUPPET: ['หุ่นเชิดพันสาย', 'กลจักรดารา', 'ปรมาจารย์ค่ายกล', 'เกาทัณฑ์กลไก', 'เชิดเงาเหล็ก'],
    KARMA_SAMSARA: ['กงล้อหกภพ', 'โพธิ์ชำระกรรม', 'ด้ายแดงตัดชะตา', 'กระจกอดีตชาติ', 'ระฆังวัฏจักร'],
    BEAST_SOVEREIGN: ['ราชันย์หมื่นอสูร', 'พยัคฆ์มังกรคู่', 'เจ้าฝูงกู่สวรรค์', 'ปราการเต่าดำ', 'วิหคเพลิงสวรรค์'],
    SAGE_SUPPORT: ['หัตถ์เทวะบัวหยก', 'หมอเทวดาเข็มทอง', 'พิณทิพย์เมตตา', 'โอสถทิพย์เก้าสุริยัน', 'โคมวิญญาณนำทาง'],
    CRAFT_CREATION: ['เตาหลอมเทวะ', 'ค้อนสวรรค์พันชั่ง', 'ช่างหลอมศาสตราเทพ', 'อัคคีหลอมพิภพ', 'หัตถ์รังสรรค์'],
    ARRAY_TALISMAN: ['ค่ายกลแปดทิศ', 'ยันต์สยบมาร', 'ชีพจรปฐพี', 'ค่ายกลลวงตาดารา', 'อักขระฟ้าคราม'],
    STRATEGY_GOVERNANCE: ['กุนซือพิชิตหล้า', 'พัดขนนกบัญชาทัพ', 'เนตรพันลี้', 'ตราหยกครองยุทธภพ', 'เจ้าคลังหมื่นสมุทร']
  });

  const EPITHET_SUFFIX_BY_TRAIT = Object.freeze({
    HAWK_CRUSADE: ['ผู้ไร้พ่าย', 'ผ่าสวรรค์', 'สะท้านโลกันตร์', 'พิชิตสิบทิศ'],
    DOVE_HARMONY: ['ผู้เปี่ยมเมตตา', 'ใจกระจ่าง', 'ร่มโพธิ์ยุทธภพ', 'พิทักษ์คุณธรรม'],
    MERCHANT_HEGEMONY: ['พันตำลึงทอง', 'เจ้าสมุทรวาณิชย์', 'หัตถ์ทองคำ', 'คลังสวรรค์'],
    ORTHODOX_INQUISITION: ['กฎเหล็กไร้ปราณี', 'พิพากษาฟ้าดิน', 'ผู้คุมกฎสูงสุด', 'เที่ยงธรรมดั่งขุนเขา'],
    MYSTIC_SECLUSION: ['เร้นกายพันปี', 'ผู้หยั่งรู้ฟ้าดิน', 'ท่องเมฆา', 'ค้นสัจธรรม']
  });

  X.computeFigureDoctrine = fig => {
    if (!fig || !fig.h) return X.ALLIANCE_DOCTRINES.ORTHODOX_INQUISITION;
    const e = p => figTrait(fig, p);
    const sHawk = e('personality.aggression') * 0.42 + e('personality.ambition') * 0.35 + e('personality.courage') * 0.23;
    const sDove = e('personality.empathy') * 0.45 + e('personality.integrity') * 0.35 + (100 - e('personality.aggression')) * 0.20;
    const sMerch = e('values.wealthResource') * 0.48 + e('aptitudes.socialCommerce') * 0.32 + e('personality.ambition') * 0.20;
    const sOrth = e('personality.discipline') * 0.42 + e('personality.pride') * 0.30 + e('values.honorLegacy') * 0.28;
    const sMyst = e('personality.curiosity') * 0.42 + e('intellect.comprehension') * 0.35 + e('values.knowledgeCraft') * 0.23;
    const ranked = [
      ['HAWK_CRUSADE', sHawk],
      ['DOVE_HARMONY', sDove],
      ['MERCHANT_HEGEMONY', sMerch],
      ['ORTHODOX_INQUISITION', sOrth],
      ['MYSTIC_SECLUSION', sMyst]
    ].sort((a, b) => b[1] - a[1]);
    return X.ALLIANCE_DOCTRINES[ranked[0][0]] || X.ALLIANCE_DOCTRINES.ORTHODOX_INQUISITION;
  };

  const FAST_SURNAMES = (g.SIM && g.SIM.NAME_POOLS && g.SIM.NAME_POOLS.FAMILY) || [
    'หลิน', 'เฉิน', 'จาง', 'หลี่', 'หวัง', 'จ้าว', 'เย่', 'เซียว', 'ไป๋', 'ซู', 'กู้', 'ลู่', 'ฉู่', 'มู่หรง', 'ตงฟาง', 'ซ่างกวน', 'โอวหยาง', 'ซือหม่า', 'ซือถู', 'ซือคง',
    'จูกัด', 'หนานกง', 'เป่ยถัง', 'ซีเหมิน', 'เซี่ยโหว', 'กงซุน', 'หวงฝู่', 'ต้วนมู่', 'ตูกู', 'เฮ่อเหลียน', 'เหวินเหริน', 'จงหลี', 'อวี้เหวิน', 'ฉางซุน', 'ไป๋หลี่', 'หลิงหู',
    'หาน', 'เว่ย', 'เฟิง', 'หลง', 'เสิ่น', 'อวิ๋น', 'หวง', 'สวี', 'หม่า', 'หู', 'กัว', 'เหอ', 'เจิ้ง', 'ซ่ง', 'ถาน', 'เติ้ง', 'สวี่', 'ฝู', 'เผิง', 'เจียง', 'ไช่', 'พาน', 'ไต้', 'เถา', 'ชี', 'หยวน', 'หลาน', 'โม่', 'ซาง', 'ชิว', 'จี้', 'ลั่ว', 'ฮัว', 'หลิว', 'เนี่ย', 'เยียน'
  ];
  const FAST_GIVEN_M = (g.SIM && g.SIM.NAME_POOLS && g.SIM.NAME_POOLS.GIVEN_M) || [
    'เทียนหยา', 'เจี้ยนซิน', 'อู๋จี๋', 'ชิงอวิ๋น', 'เสวียนหมิง', 'ฮ่าวหราน', 'เจิ้นเทียน', 'ปู้ไป่', 'หลิงเซียว', 'จื่อหาน', 'เฟยหลง', 'ฉางชิง', 'เย่ไป๋', 'หานซาน', 'จิ่งเทียน', 'อี้เฉิน', 'โม่โฉว', 'ชางไห่', 'ซิงเหอ', 'อวิ๋นฟาน',
    'เจี้ยนเฉิน', 'หลงหยวน', 'เสวียนอู่', 'ชิงเฟิง', 'ไป๋อวิ๋น', 'จื่อหยาง', 'เทียนหลง', 'หานเฟิง', 'อู๋ซวง', 'จิ่วเซียว', 'เมิ่งเฉิน', 'ฉู่เหอ', 'เย่หลาน', 'หลิงเฟิง', 'เจ๋อหยวน', 'อวี้เหิง', 'ชิงซาน', 'เฟิงเหลย', 'เสวียนเย่', 'ไท่ชู'
  ];
  const FAST_GIVEN_F = (g.SIM && g.SIM.NAME_POOLS && g.SIM.NAME_POOLS.GIVEN_F) || [
    'ชิงเสวี่ย', 'รั่วสุ่ย', 'หว่านเอ๋อร์', 'จื่อเยียน', 'อวิ๋นซี', 'หลิงหลง', 'ชิงเหลียน', 'เยว่ซิน', 'ซู่อี้', 'ไป๋ลู่', 'เสี่ยวหาน', 'ชิงชิง', 'เหมยเซียน', 'อวี้เหยา', 'เฟยเยียน', 'หนิงซวง', 'รั่วหลาน', 'ซินอี๋', 'เมิ่งเหยา', 'ฉู่ฉู่',
    'เสวี่ยฉี', 'ปี้เหยา', 'ลู่เสวี่ย', 'หว่านชิง', 'จื่อรั่ว', 'เสี่ยวอวี้', 'ชิงเหยา', 'อวิ๋นเมิ่ง', 'เยว่ฉาน', 'ซิงหลาน', 'ฮว่านซา', 'หนิงเซียง', 'ไป๋เสวี่ย', 'หงอวี้', 'ชิงซวง', 'หลิงเอ๋อร์', 'เยียนหราน', 'ซูซิน', 'จิ่นซี', 'อวี้หลาน'
  ];

  function generateFastFigureCore(rng, sex) {
    const sur = rng.pick(FAST_SURNAMES);
    const given = rng.pick(sex === 'F' ? FAST_GIVEN_F : FAST_GIVEN_M);
    const rTrait = () => clamp(Math.round(50 + (rng.next() + rng.next() - 1) * 38), 12, 96);
    return {
      sex,
      name: { sur, given, full: sur + given },
      personality: {
        ambition: rTrait(),
        discipline: rTrait(),
        caution: rTrait(),
        curiosity: rTrait(),
        rationality: rTrait(),
        empathy: rTrait(),
        loyalty: rTrait(),
        integrity: rTrait(),
        aggression: rTrait(),
        courage: rTrait(),
        pride: rTrait(),
        composure: rTrait()
      },
      values: {
        wealthResource: rTrait(),
        honorLegacy: rTrait(),
        martialPeak: rTrait(),
        knowledgeCraft: rTrait(),
        sectDuty: rTrait(),
        powerStatus: rTrait()
      },
      social: {
        charisma: rTrait(),
        leadership: rTrait(),
        persuasion: rTrait(),
        diplomacy: rTrait()
      },
      intellect: {
        comprehension: rTrait(),
        perceptiveness: rTrait()
      },
      aptitudes: {
        socialCommerce: rTrait()
      },
      skills: {
        diplomacy: rTrait(),
        stealth: rTrait()
      }
    };
  }
  function figTrait(fig, path) {
    if (!fig || !fig.h) return 50;
    const parts = path.split('.');
    const grp = fig.h[parts[0]];
    return (grp && Number.isFinite(grp[parts[1]])) ? grp[parts[1]] : 50;
  }
  function figFullName(fig) {
    if (!fig || !fig.h || !fig.h.name) return 'จอมยุทธ์';
    return fig.h.name.full || ((fig.h.name.sur || '') + (fig.h.name.given || ''));
  }
  function hideFigCaches(fig) { return fig; }
  function ensureFiguresMap(w) {
    if (!w.figuresById || typeof w.figuresById !== "object") {
      Object.defineProperty(w, "figuresById", { value: {}, writable: true, enumerable: false, configurable: true });
    } else {
      Object.defineProperty(w, "figuresById", { value: w.figuresById, writable: true, enumerable: false, configurable: true });
    }
    return w.figuresById;
  }
  function makeChildRng(W, tag) {
    const baseSeed = (W && W.seed) ? String(W.seed) : 'jhevo_v220';
    return new U.RNG(baseSeed + ':v220:' + tag);
  }

  /* Continental geography and civil government. Distances use map units, never CSS pixels. */
  const continent = JD.CONTINENT;
  const homeId = 'NODE_HOME_SECT';
  const settlementById = {};
  const settlementIds = [homeId];
  const terrainFor = { river:'plains', farm:'plains', ferry:'plains', academy:'plains', road:'plains',
    port:'plains', forge:'mountain', mountain:'mountain', desert:'desert', marsh:'marsh', hunt:'forest' };
  continent.rows.forEach(([id, nameTh, x, y, tier, owner, specialty], i) => {
    const polity = continent.polities[owner];
    settlementIds.push(id);
    settlementById[id] = Object.freeze({
      id, nameTh, x, y, tier, order:i + 1, specialty, polityId:polity?.id || null,
      macroRegion:polity?.macroRegion || 'SOUTHERN_WATERS',
      kind:'SETTLEMENT', icon:tier >= 4 ? '🏛️' : tier === 2 ? '🚩' : specialty === 'port' ? '⚓' : tier === 1 ? '🏘️' : '🏮',
      terrain:terrainFor[specialty], danger:tier === 2 ? 2 : 1
    });
  });
  const polityById = Object.fromEntries(continent.polities.map(p => [p.id, p]));
  X.SETTLEMENTS = Object.freeze(settlementById);
  X.POLITY_DEFS = Object.freeze(polityById);
  Object.defineProperty(X,'LI_PER_MAP_UNIT',{value:10,enumerable:true});
  const terrainPace = { plains:1, forest:1.13, mountain:1.32, desert:1.24, marsh:1.4, water:1.08 };
  const mapDistance = (a,b) => Math.hypot(b.x - a.x,b.y - a.y);
  function routeLeg(a, b, terrain, bends = []) {
    const start = {x:a.x, y:a.y}, end = {x:b.x, y:b.y};
    const points = [start,...bends.map(([x,y]) => ({x,y})),end];
    const units = points.slice(1).reduce((sum,p,i) => sum + mapDistance(points[i],p),0);
    const distanceLi = Math.round(units * X.LI_PER_MAP_UNIT);
    const days = Math.max(.08, +(distanceLi / 123 * (terrainPace[terrain] || 1)).toFixed(3));
    return {from:a.id, to:b.id, terrain, days, distanceLi, a:start, b:end, points, units};
  }
  const routeMaps = new WeakMap();
  function makeContinentalRoutes(topo, nodes) {
    const old = routeMaps.get(topo);
    if (old) return old;
    const links = [];
    const linked = new Set();
    function add(a, b, terrain, bends) {
      if (!a || !b || a.id === b.id) return;
      links.push(routeLeg(a, b, terrain || b.terrain || 'plains',bends));
      linked.add(a.id); linked.add(b.id);
    }
    for (const [a,b,terrain,bends] of continent.roads) add(nodes[settlementIds[a]],nodes[settlementIds[b]],terrain,bends);
    // Anchor old routes to the settled road network; cross-country trails fill out existing physical destinations.
    for (const r of X.WORLD_ROUTES) {
      if (r.from === homeId) continue;
      add(nodes[r.from], nodes[r.to], r.terrain);
    }
    add(nodes['PASS_BM_HANLONG_GATE'],nodes.mountain,'mountain');
    add(nodes['TOWN_YH_WUYUN_POST'],nodes.plains,'plains');
    add(nodes['PASS_YH_XIFENG_GORGE'],nodes.forest,'forest');
    add(nodes['TOWN_BM_BAIMEI_OLD_FORT'],nodes.SANCTUM_SWORD_ABYSS,'mountain');
    add(nodes['CITY_BM_XINGYUN_CITADEL'],nodes.ruins,'mountain');
    const anchors = ['forest','plains','mountain','desert','water','REG_SLEEPING_DRAGON_LAKE'];
    for (const id of anchors) {
      const n = nodes[id];
      if (!n) continue;
      const candidate = Object.values(settlementById).filter(s => n.terrain === 'water'
        ? ['port','river','ferry'].includes(s.specialty) : s.specialty !== 'port');
      add(nearestPlace(n, candidate), n);
    }
    const destinations = Object.values(nodes).filter(n => !linked.has(n.id) && n.id !== homeId &&
      ['NEIGHBOR_SECT','EXPEDITION_REGION','RESOURCE_NODE','TRADE_HUB','PAGODA','SANCTUM','ELEMENTAL_REALM'].includes(n.kind));
    for (const n of destinations) {
      const nearby = Object.values(settlementById).concat(anchors.map(id => nodes[id]).filter(Boolean))
        .filter(s => s.specialty !== 'port' || n.terrain === 'water');
      add(nearestPlace(n, nearby), n);
    }
    routeMaps.set(topo, links);
    return links;
  }
  function nearestPlace(point, options) {
    let nearest = null, best = Infinity;
    for (const other of options) {
      const distance = Math.hypot(point.x - other.x, point.y - other.y);
      if (distance < best) { best = distance; nearest = other; }
    }
    return nearest;
  }
  X.fortuneMapPoint = (topo, site, rank, index) => {
    const id = topo.nodes[site.biome] ? site.biome : 'forest';
    const anchor = topo.nodes[id];
    return {id:'FORTUNE:' + site.id, anchorId:id, nameTh:site.nameTh, terrain:anchor.terrain,
      macroRegion:anchor.macroRegion, x:clamp(anchor.x + ((index * 7 + rank * 3) % 11) - 5, 3, 97),
      y:clamp(anchor.y + ((index * 5 + rank * 4) % 11) - 5, 3, 97)};
  };
  const roadCondition = (W, leg) => {
    const a = W.world?.continent?.cities[leg.from], b = W.world?.continent?.cities[leg.to];
    const average = ((a?.safety ?? 65) + (b?.safety ?? 65)) / 2;
    return 1 + Math.max(0, 60 - average) / 160;
  };
  X.planContinentalRoute = (W, topo, target, fromId = homeId) => {
    if (!target || !topo?.nodes?.[fromId]) return null;
    if (target.id === fromId) return {fromId, targetId:target.id, legs:[], days:0, distanceLi:0};
    const edges = topo.routes.slice();
    if (!edges.some(e => e.to === target.id || e.from === target.id)) {
      if (target.kind !== 'WORLD_ANOMALY' && !target.anchorId) return null;
      const near = topo.nodes[target.anchorId] || nearestPlace(target, Object.values(settlementById).filter(s => s.specialty !== 'port'));
      if (!near) return null;
      edges.push(routeLeg(near, target, target.terrain));
    }
    const adjacency = new Map();
    for (const leg of edges) {
      if (!adjacency.has(leg.from)) adjacency.set(leg.from, []);
      if (!adjacency.has(leg.to)) adjacency.set(leg.to, []);
      const days = leg.days * roadCondition(W, leg);
      adjacency.get(leg.from).push(Object.assign({}, leg, {days}));
      adjacency.get(leg.to).push({...leg,from:leg.to,to:leg.from,days,a:leg.b,b:leg.a,points:leg.points.slice().reverse()});
    }
    const open = new Set([fromId]), costs = new Map([[fromId, 0]]), prev = new Map();
    while (open.size) {
      let id = null;
      for (const candidate of open) if (id === null || costs.get(candidate) < costs.get(id)) id = candidate;
      open.delete(id);
      if (id === target.id) break;
      for (const leg of adjacency.get(id) || []) {
        const next = costs.get(id) + leg.days;
        if (next >= (costs.get(leg.to) ?? Infinity)) continue;
        costs.set(leg.to, next); prev.set(leg.to, leg); open.add(leg.to);
      }
    }
    if (!prev.has(target.id)) return null;
    const legs = [];
    for (let id = target.id; id !== fromId;) {
      const leg = prev.get(id);
      legs.unshift(leg); id = leg.from;
    }
    return {fromId, targetId:target.id, nameTh:target.nameTh, macroRegion:target.macroRegion, legs, days:costs.get(target.id),
      distanceLi:legs.reduce((sum, leg) => sum + leg.distanceLi, 0)};
  };
  X.routePosition = (route, fraction) => {
    if (!route?.legs.length) return null;
    let left = route.days * clamp(fraction, 0, 1);
    for (const leg of route.legs) {
      if (left <= leg.days) {
        let distance = leg.units * clamp(left / leg.days,0,1);
        for (let i = 1; i < leg.points.length; i++) {
          const a = leg.points[i - 1], b = leg.points[i], length = mapDistance(a,b);
          if (distance <= length && length) {
            const f = distance / length;
            return {x:a.x + (b.x-a.x)*f,y:a.y + (b.y-a.y)*f};
          }
          distance -= length;
        }
        return leg.b;
      }
      left -= leg.days;
    }
    return route.legs[route.legs.length - 1].b;
  };
  const stampPlace = n => n && {nodeId:n.id,nameTh:n.nameTh,x:n.x,y:n.y,macroRegion:n.macroRegion};
  const routePlace = route => route?.legs.length && {
    nodeId:route.targetId, nameTh:route.nameTh, macroRegion:route.macroRegion,
    x:route.legs[route.legs.length - 1].b.x, y:route.legs[route.legs.length - 1].b.y
  };
  X.prepareTrialJourney = (W,ex,targetId,dwellDays,travel) => {
    if (!travel.route) return;
    ex.targetNodeId = targetId;
    ex.days = +(2 * travel.days + dwellDays).toFixed(2);
    ex.ret = ex.t0 + Math.round(ex.days * 1440);
    setJourney(ex,travel.route,travel.days,Math.round(dwellDays * 1440),true);
  };
  X.locationOfJourney = ex => routePlace(ex.route);
  function setJourney(ex, route, days, dwellMinutes, roundTrip) {
    if (!route?.legs.length) return;
    ex.route = route;
    ex.travelMinutes = Math.max(1, Math.round(days * 1440));
    ex.dwellMinutes = dwellMinutes;
    ex.roundTrip = roundTrip;
    ex.ret = ex.t0 + ex.travelMinutes * (roundTrip ? 2 : 1) + (roundTrip ? dwellMinutes : 0);
    if (ex.state === 'away') startJourney(ex, ex.t0);
  }
  function startJourney(ex, start) {
    if (!ex.route || ex.startedAt != null) return;
    ex.startedAt = start;
    ex.arriveAt = start + ex.travelMinutes;
    ex.leaveAt = ex.arriveAt + ex.dwellMinutes;
    ex.ret = ex.roundTrip ? ex.leaveAt + ex.travelMinutes : ex.arriveAt;
  }
  function finishJourney(W, ex, members) {
    ex.done = true;
    members.forEach(m => {
      m.expId = null; m.away = false; m.hidden = false;
      m.x = MAP.EXIT.x + .5; m.y = MAP.EXIT.y + .5;
      m.path = null; m.travel = {to:'home', mountUid:tripMountUid(ex,m)};
    });
  }
  X.journeyProgress = (W, ex) => {
    if (!ex.route) return null;
    const t = W.t || 0, start = ex.startedAt ?? t;
    const back = ex.returnStartedAt != null || (ex.roundTrip && t >= (ex.leaveAt ?? Infinity));
    const atDestination = !back && t >= (ex.arriveAt ?? Infinity);
    const f = back ? 1 - (t - (ex.returnStartedAt ?? ex.leaveAt)) / ex.travelMinutes
      : (t - start) / ex.travelMinutes;
    return {point:X.routePosition(ex.route, f), back, atDestination, remaining:Math.max(0, ex.ret - t)};
  };

  const originGroups = {
    'ภูเขาสูง':['mountain','hunt'], 'หมู่บ้านลุ่มน้ำ':['river','ferry','farm','marsh'],
    'เมืองการค้า':['road','port','river','forge'], 'เมืองหลวง':['capital'], 'ที่ราบกลาง':['farm','road'],
    'ชายฝั่งทะเล':['port'], 'ทะเลทรายตะวันตก':['desert'], 'ป่าลึก':['hunt','marsh'],
    'วงศ์แพทย์':['academy','marsh'], 'ตระกูลยุทธ์':['mountain','capital']
  };
  X.assignHometown = (W, n, preferredId) => {
    if (!n?.h || n.ext?.world?.hometownNodeId) return;
    const tags = originGroups[n.h.origin?.region];
    const pool = Object.values(settlementById).filter(s => s.tier !== 2 &&
      (!tags || tags.includes(s.specialty) || (tags.includes('capital') && s.tier >= 4)));
    const rng = makeChildRng(W, 'birthplace:' + n.id);
    const city = settlementById[preferredId] || rng.weighted(pool, s => s.polityId === 'POL_YUNHE' ? 2.2 : 1);
    if (!city) return;
    n.ext = n.ext || {};
    n.ext.world = Object.assign({}, n.ext.world, {
      hometownNodeId:city.id, birthPolityId:city.polityId, originPublic:!!preferredId || !!tags
    });
  };
  X.originView = n => {
    const origin = n?.ext?.world;
    if (!origin) return null;
    const city = settlementById[origin.hometownNodeId];
    const polity = polityById[origin.birthPolityId];
    return city ? {city, polity} : null;
  };
  function borderKey(a, b) { return a < b ? a + ':' + b : b + ':' + a; }
  X.polityOpinion = (W, a, b) => {
    if (!a || !b || a === b) return 0;
    return W.world?.continent?.relations[borderKey(a,b)] || 0;
  };
  X.homelandFeeling = (W, observer, other, relation) => {
    const a = observer.ext?.world, b = other.ext?.world;
    if (!a?.originPublic || !b?.originPublic || !a.birthPolityId || !b.birthPolityId) return 0;
    const samePolity = a.birthPolityId === b.birthPolityId;
    const opinion = samePolity ? 0 : X.polityOpinion(W,a.birthPolityId,b.birthPolityId);
    const trust = relation?.t ?? 40;
    if (!samePolity && (opinion >= -24 || trust >= 88)) return 0;
    const rooted = clamp((E(observer,'values.familyClan') * .42 + E(observer,'personality.loyalty') * .34 +
      E(observer,'values.honorLegacy') * .24 - E(observer,'values.freedom') * .30 - 22) / 48, 0, 1);
    if (!rooted) return 0;
    const familiarity = clamp(1 - (relation?.n || 0) / 70, .18, 1);
    const local = a.hometownNodeId === b.hometownNodeId ? .24 : .15;
    if (samePolity) return rooted * local * familiarity;
    const openness = clamp((E(observer,'personality.empathy') + E(observer,'personality.trustfulness')) / 200, 0, 1);
    return -(Math.min(1, (-opinion - 24) / 52) * rooted * (1 - openness * .65) *
      clamp(1 - (trust - 40) / 48, 0, 1) * .33);
  };

  const civilRoles = {
    ruler:['ผู้ปกครอง','social.leadership'],
    minister:['อัครเสนาบดี','personality.rationality'],
    governor:['เจ้าเมือง','social.leadership'],
    marshal:['แม่ทัพประจำด่าน','personality.courage'],
    revenue:['ขุนนางคลัง','aptitudes.socialCommerce'],
    envoy:['ราชทูต','social.diplomacy'],
    censor:['ผู้ตรวจการ','personality.integrity'],
    scholar:['ราชครู','intellect.comprehension']
  };
  const rulerTitles = {council:'ประธานสภาเจ็ดวาณิช', dynasty:'เจ้าแผ่นดิน', bureaucracy:'จักรพรรดิ',
    military:'จอมทัพผู้ปกครอง', guild:'ประธานสมาพันธ์ช่าง', monastic:'ประมุขสภาธรรม', tribal:'ผู้นำสภาชนเผ่า'};
  const civilSeason = W => Math.floor((W.day || 0) / 30);
  X.initContinent = W => {
    if (W.world.continent) return;
    const state = W.world.continent = {cities:{}, courts:{}, relations:{}, figures:{}, figureSeq:0, lastMonth:civilSeason(W), lastVisitDay:W.day};
    const rng = makeChildRng(W, 'continent:courts');
    Object.values(settlementById).forEach(n => {
      state.cities[n.id] = {safety:67 + rng.int(-10, 10), prosperity:43 + n.tier * 7, visits:0};
    });
    function seedSeat(p, stationId, role, titleTh, vacant = false) {
      const court = state.courts[p.id];
      const id = p.id + ':' + role + ':' + stationId;
      const seat = court.seats[id] = {id, role, nameTh:titleTh || civilRoles[role][0], stationId, holderId:null};
      if (!vacant) seat.holderId = newCourtFigure(W, state, p, stationId, rng).id;
    }
    for (const p of continent.polities) {
      const capital = settlementIds[p.capital];
      state.courts[p.id] = {seats:{}, reserveIds:[], stability:65, policy:'balance'};
      seedSeat(p,capital,'ruler',rulerTitles[p.government]);
      seedSeat(p,capital,p.government === 'guild' ? 'revenue' : 'minister',
        p.government === 'monastic' ? 'ผู้อำนวยการโรงทาน' : undefined);
      if (p.government !== 'guild') seedSeat(p,capital,'revenue',p.government === 'council' ? 'นายคลังเจ็ดวาณิช' : undefined);
      seedSeat(p,capital,'envoy');
      seedSeat(p,capital,p.government === 'military' ? 'censor' : 'scholar',undefined,true);
      for (const city of Object.values(settlementById)) {
        if (city.polityId !== p.id) continue;
        if (city.tier === 2) seedSeat(p,city.id,'marshal');
        if (city.tier === 3) seedSeat(p,city.id,'governor');
      }
      for (let i = 0; i < 4; i++) {
        state.courts[p.id].reserveIds.push(newCourtFigure(W,state,p,capital,rng).id);
      }
    }
    for (const [a,b,opinion] of [
      ['BEIMING','DONGHUANG',-58],['XIRONG','DONGHUANG',-49],['XIRONG','YUNHE',-29],
      ['DONGHUANG','YUNXIAO',-40],['XIRONG','CHIYAN',-26],['BEIMING','YOUMING',19],
      ['GUJIAO','SUVARNABODHI',-34],['YUNHE','SUVARNABODHI',23]
    ]) state.relations[borderKey('POL_' + a, 'POL_' + b)] = opinion;
  };
  function newCourtFigure(W, state, polity, hometownId, rng) {
    const id = 'court:' + (++state.figureSeq);
    const h = generateFastFigureCore(rng, rng.chance(.5) ? 'F' : 'M');
    const age = rng.int(21, 67);
    const figure = {id, h, bornDay:W.day - age * 360, retirementAge:rng.int(62, 86),
      residenceId:hometownId, officeSince:W.day,
      ext:{world:{hometownNodeId:hometownId, birthPolityId:polity.id, originPublic:true}}};
    state.figures[id] = figure;
    return figure;
  }
  function courtEvent(W, seat, text) {
    const city = settlementById[seat.stationId];
    W.log('appoint','🏛️ ' + text + ' ณ ' + city.nameTh, [], {
      location:stampPlace(city), storyThreadId:'court:' + city.polityId
    });
  }
  X.tickContinentalCourts = W => {
    const state = W.world.continent;
    const month = civilSeason(W);
    if (!state || month <= state.lastMonth) return;
    state.lastMonth = month;
    const rng = makeChildRng(W, 'continent:' + month);
    const retired = new Set();
    for (const p of continent.polities) {
      const court = state.courts[p.id], capital = settlementIds[p.capital];
      const seats = Object.values(court.seats);
      for (const seat of seats) {
        const f = state.figures[seat.holderId];
        if (!f || (W.day - f.bornDay) / 360 < f.retirementAge) continue;
        if (!rng.chance(.28)) continue;
        retired.add(f.id); seat.holderId = null;
        courtEvent(W, seat, figFullName(f) + ' วางมือจากตำแหน่ง' + seat.nameTh);
      }
      if (court.reserveIds.length < 4) court.reserveIds.push(newCourtFigure(W,state,p,capital,rng).id);
      for (const seat of seats.filter(s => !s.holderId)) {
        const applicants = court.reserveIds.map(id => state.figures[id]).filter(f => f &&
          (W.day - f.bornDay) / 360 < f.retirementAge &&
          rng.chance(clamp(.36 + (figTrait(f,'personality.ambition') - 50) / 105, .10, .73)));
        if (!applicants.length || !rng.chance(seat.role === 'ruler' ? .83 : .62)) continue;
        const sponsor = state.figures[seats.find(s => s.role === 'ruler')?.holderId];
        const f = rng.weighted(applicants, candidate => {
          const fit = figTrait(candidate, civilRoles[seat.role][1]);
          const patronage = sponsor && candidate.h.name.sur === sponsor.h.name.sur
            ? (100 - figTrait(sponsor,'personality.integrity')) / 20 : 0;
          return 1 + Math.pow(fit / 35, 2) + patronage;
        });
        seat.holderId = f.id; f.officeSince = W.day; f.residenceId = seat.stationId;
        court.reserveIds = court.reserveIds.filter(id => id !== f.id);
        courtEvent(W,seat,figFullName(f) + ' เข้ารับตำแหน่ง' + seat.nameTh);
      }
      court.reserveIds = court.reserveIds.filter(id => {
        const f = state.figures[id];
        if (!f) return false;
        if ((W.day - f.bornDay) / 360 < f.retirementAge) return true;
        retired.add(id); return false;
      });
      const rulerSeat = seats.find(s => s.role === 'ruler');
      const ruler = state.figures[rulerSeat.holderId];
      const holder = role => state.figures[seats.find(s => s.role === role)?.holderId];
      const coordination = holder('minister') ? (figTrait(holder('minister'),'personality.rationality') - 25) / 10 : 0;
      const budgetSkill = holder('revenue') ? (figTrait(holder('revenue'),'aptitudes.socialCommerce') - 25) / 11 : 0;
      const inspection = holder('censor') ? figTrait(holder('censor'),'personality.integrity') / 20 : 0;
      const towns = Object.values(settlementById).filter(city => city.polityId === p.id);
      const distress = towns.reduce((v,city) => v + Math.max(0, 65 - state.cities[city.id].safety),0) / towns.length;
      const policies = [
        ['guard', .8 + distress / 8 + (figTrait(ruler,'personality.caution') - 25) / 66],
        ['market', .8 + (figTrait(ruler,'values.wealthResource') - 25) / 30],
        ['balance', 1.2 + (figTrait(ruler,'personality.empathy') - 25) / 40]
      ];
      const policy = ruler ? rng.weighted(policies, ([id,w]) => Math.max(.1, w + (id === court.policy ? 1.4 : 0)))[0] : 'balance';
      if (policy !== court.policy && W.day >= (court.lastPolicyDay || 0) + 90) {
        court.policy = policy; court.lastPolicyDay = W.day;
        const reason = {guard:'ให้รักษาด่านและคุ้มทาง', market:'หนุนตลาดและเสบียงเมือง', balance:'จัดกำลังดูแลทั้งตลาดและทางหลวง'};
        courtEvent(W,rulerSeat,(ruler ? figFullName(ruler) : p.nameTh) + ' มีมติ' + reason[policy]);
      }
      for (const city of towns) {
        const stats = state.cities[city.id];
        const hasWatch = seats.some(s => s.stationId === city.id && s.holderId && (s.role === 'marshal' || s.role === 'governor'));
        const pressure = 62 + coordination + inspection + (hasWatch ? 10 : 0) + (court.policy === 'guard' ? 11 : 0) - (ruler ? 0 : 5);
        stats.safety = clamp(stats.safety + (pressure - stats.safety) * .20 + rng.int(-5,5), 25, 95);
        const prosperity = 40 + budgetSkill + city.tier * 7 + (court.policy === 'market' ? 9 : 0) - Math.max(0, 65 - stats.safety) / 3;
        stats.prosperity = clamp(stats.prosperity + (prosperity - stats.prosperity) * .22 + rng.int(-3,3),20,95);
      }
      court.stability = Math.round(towns.reduce((v,city) => v + (state.cities[city.id].safety + state.cities[city.id].prosperity) / 2,0) / towns.length);
    }
    for (const id of retired) delete state.figures[id];

    const pairs = new Map();
    for (const [i,j] of continent.roads) {
      const a = settlementById[settlementIds[i]], b = settlementById[settlementIds[j]];
      if (!a?.polityId || !b?.polityId || a.polityId === b.polityId) continue;
      const key = borderKey(a.polityId,b.polityId);
      if (!pairs.has(key)) pairs.set(key,[a,b]);
    }
    for (const [key,[a,b]] of pairs) {
      const stateA = state.courts[a.polityId], stateB = state.courts[b.polityId];
      const envoys = [stateA,stateB].map(c => state.figures[Object.values(c.seats).find(s => s.role === 'envoy')?.holderId]);
      const base = state.relations[key] || 0;
      const safety = (state.cities[a.id].safety + state.cities[b.id].safety) / 2;
      const dialogue = envoys.every(Boolean) && rng.chance(.36 + (figTrait(envoys[0],'social.diplomacy') + figTrait(envoys[1],'social.diplomacy') - 100) / 300);
      const delta = dialogue ? rng.int(1,5) : safety < 63 ? -rng.int(1,5) : rng.int(-3,1);
      const next = state.relations[key] = clamp(base * .98 + delta, -85, 75);
      if ((base < -24) !== (next < -24)) {
        W.log('diplomacy', '🏛️ ' + polityById[a.polityId].nameTh + ' กับ ' + polityById[b.polityId].nameTh +
          (next < -24 ? ' ตึงเครียดเรื่องชายแดน' : ' ลดความตึงเครียดชายแดน') + ' ที่ ' + a.nameTh, [], {location:stampPlace(a)});
      }
    }
  };

  X.cityVisitDrive = (W,npc) => {
    const state = W.world?.continent;
    if (!state || npc.rank < 1 || npc.id === W.sect.masterId || npc.sealed || npc.sealedBt ||
      npc.inj?.length || W.day < state.lastVisitDay + 3 || W.threat?.roadBlocked || W.threat?.raid ||
      W.day - (npc.lastTrip ?? -100) < 7 || ECO.count(W,'meal') < 12 ||
      npc.h.state.rest < 40 || npc.h.state.satiety < 45 ||
      (W.world.expeds || []).some(e => e.kind === 'city_visit' && !e.done)) return 0;
    const residents = (W.npcs || []).filter(n => !n.dead && !n.exiled && !n.away && !n.expId).length;
    if (residents < 3) return 0;
    const stateNeeds = npc.h.state;
    const belonging = E(npc,'values.familyClan') * .28 + E(npc,'temperament.sociability') * .23;
    const exploration = E(npc,'personality.curiosity') * .24 + E(npc,'values.freedom') * .25;
    return clamp((belonging + exploration - 16) / 56 + (stateNeeds.loneliness || 0) / 180, .1, 1.8);
  };
  X.departCityVisit = (W,npc) => {
    if (!X.cityVisitDrive(W,npc) || !X.isAvailableForExpedition(W,npc) || npc.h.state.hp < CULT.hpMax(npc) * .65) {
      return {ok:false,reason:'city-visit-unavailable'};
    }
    const state = W.world.continent, topo = X.ensureWorldTopology(W);
    const rng = makeChildRng(W,'city-visit:' + W.day + ':' + npc.id);
    const cities = Object.values(settlementById).filter(n => n.polityId === 'POL_YUNHE' && n.tier !== 2);
    const origin = npc.ext?.world?.originPublic ? X.originView(npc) : null;
    if (origin?.city && origin.city.tier !== 2 && origin.city.polityId !== 'POL_YUNHE') cities.push(origin.city);
    const tolerance = E(npc,'personality.courage') > 65 ? 7 : 4.5;
    const available = ECO.count(W,'meal') - 10;
    const options = cities.map(city => {
      const route = X.planContinentalRoute(W,topo,city);
      const travel = X.createParty(W,[npc],{kind:'city_visit',regionId:city.id,terrain:city.terrain});
      const days = (route?.days || 0) * (travel.durationMultiplier || 1);
      return {city,route,travel,days,meals:Math.ceil(2 * days + .2)};
    }).filter(o => o.route && o.travel.ok && o.days <= tolerance && o.meals <= available);
    if (!options.length) return {ok:false,reason:'no-feasible-city'};
    const stay = rng.weighted(options, ({city,days}) => {
      const home = city.id === origin?.city.id ? E(npc,'values.familyClan') / 27 : .35;
      const safety = state.cities[city.id].safety / 100;
      const school = city.specialty === 'academy' ? E(npc,'values.knowledgeCraft') / 125 : 0;
      return (home + .5 + school + (city.tier >= 3 ? E(npc,'interests.socializing') / 100 : 0)) *
        Math.pow(safety, E(npc,'personality.caution') / 40) / (1 + days * .8);
    });
    const {travel,days:tripDays,meals} = stay;
    if (!ECO.take(W,'meal',meals)) return {ok:false,reason:'insufficient-meals'};
    const ex = {id:++W.world.seq, kind:'city_visit', region:stay.city.id, targetNodeId:stay.city.id, party:[npc.id],
      t0:W.t, days:tripDays * 2 + .2, ret:W.t + Math.round((2 * tripDays + .2) * 1440), supplies:meals,
      mount:travel.mounts, state:'leaving', done:false, carry:[], journal:[]};
    setJourney(ex, stay.route, tripDays, 288, true);
    W.world.expeds.push(ex);
    state.lastVisitDay = W.day;
    AI.interruptFor(W,npc);
    npc.expId = ex.id; npc.lastTrip = W.day;
    npc.act = {id:'idle',stage:'do',left:0,total:0,ctx:{},why:[]};
    npc.travel = {to:'exit',ex:ex.id,mountUid:tripMountUid(ex,npc)}; npc.path = null;
    X.releaseDeployedGarrisons(W,[npc]);
    const reason = origin?.city.id === stay.city.id ? 'เดินทางกลับไปเยี่ยมบ้านเกิด' : 'ออกไปพบปะผู้คน';
    W.log('mission',HC.fullName(npc) + ' ' + reason + 'ที่' + stay.city.nameTh,[npc.id],{location:stampPlace(stay.city)});
    return {ok:true,expedition:ex};
  };
  function visitCity(W, ex, members) {
    const city = settlementById[ex.targetNodeId], stats = W.world.continent?.cities[ex.targetNodeId];
    if (!city || !stats) return;
    stats.visits++;
    stats.lastVisitDay = W.day;
    for (const npc of members) {
      const homecoming = X.originView(npc)?.city.id === city.id;
      HC.feel(npc,{mood:homecoming ? 9 : 4, loneliness:homecoming ? -14 : -7, novelty:8});
      HC.practice(npc,'diplomacy',.25,1);
      AI.mem(W,npc,homecoming ? 'ได้กลับไปเยี่ยมบ้านเกิดที่' + city.nameTh : 'พบผู้คนใหม่ที่' + city.nameTh,.55);
    }
    W.log('mission',members.map(HC.fullName).join('、') + ' เดินทางถึง' + city.nameTh,
      members.map(n => n.id),{location:stampPlace(city),storyThreadId:'city:' + city.id});
    if (typeof X.onCityVisitLore === 'function') X.onCityVisitLore(W, ex, members);
  }

  /* =========================================================================
   * JS2-v2.6.0 — Living Chronicle, Fact Snapshot, 12-Format Narrative Presenter,
   * Periodic Sect Digest, Continuing Storyline Threads & News Intake Preferences
   * ========================================================================= */

  X.CHRONICLE_REPORT_FORMATS = Object.freeze({
    PIGEON_DISPATCH: {
      id: 'PIGEON_DISPATCH',
      nameTh: '🕊️ สารพิราบสื่อวิญญาณด่วนพิเศษ',
      shortTh: '🕊️ สารลับพิราบ',
      toneTh: 'กระชับ ฉับไว ดั่งกระบอกสารผูกขาพิราบปราณจากหน่วยลาดตระเวนหรือกองคาราวานแดนไกล',
      leadPrefixTh: '【สารด่วนพิราบสื่อวิญญาณ】',
      impactLabelTh: 'ผลต่อสถานการณ์ยุทธภพ',
      followUpDefaultTh: 'เครือข่ายสายสืบของหอข่าวกรองกำลังเฝ้าจับตาความเคลื่อนไหวในแคว้นที่เกี่ยวข้องอย่างใกล้ชิด',
      descTh: 'รายงานข่าวกรองด่วนจากเครือข่ายพิราบสื่อวิญญาณและผู้ตรวจการยุทธภพ'
    },
    WAR_PAVILION_RECORD: {
      id: 'WAR_PAVILION_RECORD',
      nameTh: '⚔️ จดหมายเหตุศึกหอยุทธ์โลหิต',
      shortTh: '⚔️ บันทึกศึก',
      toneTh: 'น้ำเสียงขุนพลบันทึกการรบ เน้นสภาพสมรภูมิ จังหวะพลิกผันจริง ผู้กอบกู้ศึก และความสูญเสีย',
      leadPrefixTh: '【จดหมายเหตุศึกหอยุทธ์โลหิต】',
      impactLabelTh: 'ผลลัพธ์ทางยุทธวิธีและกำลังพล',
      followUpDefaultTh: 'ศิษย์ที่บาดเจ็บกำลังทยอยเข้าหอหมอยา ส่วนโรงหลอมและเวรยามหน้าด่านกำลังฟื้นฟูแนวป้องกันตามลำดับ',
      descTh: 'บันทึกรายงานการรบ กำลังพล กระบวนท่า และผลแพ้ชนะจากหอยุทธ์โลหิต'
    },
    DISCIPLINE_EDICT: {
      id: 'DISCIPLINE_EDICT',
      nameTh: '⛓️ หมายอาญาและคำพิพากษาหอวินัย',
      shortTh: '⛓️ หมายอาญาหอวินัย',
      toneTh: 'เฉียบขาด เที่ยงธรรมดั่งไม้บรรทัดเหล็ก บันทึกคดีทุจริต การฝ่าฝืนกฎ และโทษทัณฑ์ที่ได้รับ',
      leadPrefixTh: '【หมายอาญาและคำพิพากษาหอวินัย】',
      impactLabelTh: 'ผลบังคับใช้ทางวินัยและการทูต',
      followUpDefaultTh: 'ผู้คุมกฎหอวินัยและโถงสภากำลังบังคับใช้บทลงโทษและเฝ้าดูคลื่นใต้น้ำภายในสำนักต่อเนื่อง',
      descTh: 'หมายจับ สารทวงตัวผู้ลี้ภัย มติสภา และการตัดสินโทษโดยหอวินัย'
    },
    ANCESTRAL_INSCRIPTION: {
      id: 'ANCESTRAL_INSCRIPTION',
      nameTh: '🕯️ ศิลาจารึกหอบรรพชนและทำเนียบเซียน',
      shortTh: '🕯️ จารึกบรรพชน',
      toneTh: 'เปี่ยมความเคารพและโศกนาฏกรรม บันทึกการดับขันธ์ของยอดคน การสลักป้ายวิญญาณ และการผลัดแผ่นดิน',
      leadPrefixTh: '【ศิลาจารึกหอบรรพชน】',
      impactLabelTh: 'มรดกสืบทอดและผลต่อรากฐานสำนัก',
      followUpDefaultTh: 'เหล่าศิษย์ร่วมสายกำลังทยอยเข้าจุดธูปคารวะป้ายวิญญาณและรับช่วงสืบทอดเจตจำนงในหอบรรพชน',
      descTh: 'จารึกเหตุการณ์เปลี่ยนผ่านยุคสมัย การผลัดแผ่นดิน และการสืบทอดมรดกบรรพชน'
    },
    TAVERN_BALLAD: {
      id: 'TAVERN_BALLAD',
      nameTh: '🍶 ลำนำซุบซิบจากโรงเตี๊ยมริมทาง',
      shortTh: '🍶 ลำนำโรงเตี๊ยม',
      toneTh: 'น้ำเสียงนักเล่านิทานเคาะกรับไม้ในโรงน้ำชา แยกแยะชัดเจนว่าเป็นคำร่ำลือในวงสุราที่รอการพิสูจน์',
      leadPrefixTh: '【ลำนำซุบซิบจากโรงเตี๊ยม】',
      impactLabelTh: 'เบาะแสและกระแสข่าวลือในยุทธภพ',
      followUpDefaultTh: 'เรื่องนี้ยังเป็นเพียงคำร่ำลือในวงสุรา ศิษย์สายข่าวกรองและผู้ใฝ่หาความจริงจะทยอยออกพิสูจน์เบาะแส',
      descTh: 'ข่าวลือและลำนำขับขานของนักเล่านิทานเกี่ยวกับจอมยุทธ์พเนจรและแดนลับ'
    },
    LINEAGE_COMPANION_SCROLL: {
      id: 'LINEAGE_COMPANION_SCROLL',
      nameTh: '🧧 ม้วนแพรแดงสายสัมพันธ์และสืบทอดมรรคา',
      shortTh: '🧧 ม้วนแพรแดงวาสนา',
      toneTh: 'อบอุ่น ลึกซึ้ง กินใจ บันทึกพิธีคำนับน้ำชา การผูกด้ายแดงคู่บำเพ็ญ และการกำเนิดทายาทสายเลือดใหม่',
      leadPrefixTh: '【บันทึกม้วนแพรแดงหอวาสนา】',
      impactLabelTh: 'ผลต่อสายสัมพันธ์และตบะสืบทอด',
      followUpDefaultTh: 'สายสัมพันธ์อาจารย์–ศิษย์และคู่บำเพ็ญจะส่งผลเกื้อหนุนการฝึกฝนและการคุ้มกันในสมรภูมิโดยอัตโนมัติ',
      descTh: 'บันทึกพิธีผูกด้ายแดงคู่บำเพ็ญ การกำเนิดทายาท และการสืบทอดเจตจำนงแห่งจิตมรรคา'
    },
    IMPERIAL_COUNCIL_DECREE: {
      id: 'IMPERIAL_COUNCIL_DECREE',
      nameTh: '🏛️ ประกาศิตโถงสภาและตราเจ้าสำนัก',
      shortTh: '🏛️ ประกาศิตโถงสภา',
      toneTh: 'ขลัง สง่างาม ดั่งราชโองการประทับตราหยก แสดงเหตุผลเชิงนโยบาย งบสำรองคลัง และมติขุนนางทั้ง 25 ตำแหน่ง',
      leadPrefixTh: '【ประกาศิตโถงสภาและตราเจ้าสำนัก】',
      impactLabelTh: 'ผลต่อการบริหารและงบประมาณสำนัก',
      followUpDefaultTh: 'ขุนนางผู้รับผิดชอบแต่ละหอกำลังนำมติสภาและโควตาราชโองการไปบังคับใช้ตามสายงาน',
      descTh: 'บันทึกการลงมติสภาผู้อาวุโส 4 ขั้วการเมือง วาระประจำฤดูกาล โควตาราชโองการ และการตรวจสอบผู้ถือตำแหน่ง'
    },
    SECRET_REALM_LOGBOOK: {
      id: 'SECRET_REALM_LOGBOOK',
      nameTh: '🧭 สมุดบันทึกบุกเบิกแดนลับและโบราณสถาน',
      shortTh: '🧭 บันทึกแดนลับ/โบราณสถาน',
      toneTh: 'น้ำเสียงผจญภัยลี้ลับ บันทึกชั้นมหาเจดีย์ 43 วิถี ปริศนาประตูธาตุ ร่องรอยยุคเทียนกู่ และสมบัติที่กู้คืนมาได้',
      leadPrefixTh: '【สมุดปูมบุกเบิกแดนลับ】',
      impactLabelTh: 'สิ่งค้นพบและทรัพยากรที่นำกลับสำนัก',
      followUpDefaultTh: 'คณะสำรวจนำของวิเศษและเศษคัมภีร์เข้าเก็บรักษาในคลังสำนัก ก่อนแยกย้ายไปพักฟื้นกำลัง',
      descTh: 'บันทึกการเดินหมากโหนดแดนลับ ด่านตรวจทักษะมรรคา สายใยผู้ช่วยชีวิต และการบูรณะเศษคัมภีร์โบราณ'
    },
    CONTINENTAL_ASSEMBLY_GAZETTE: {
      id: 'CONTINENTAL_ASSEMBLY_GAZETTE',
      nameTh: '🌏 ประกาศทำเนียบยุทธภพและหอการค้าใหญ่',
      shortTh: '🌏 ทำเนียบยุทธภพ/การค้า',
      toneTh: 'น้ำเสียงจดหมายเหตุระดับมหาทวีป รายงานผลการประลองชุมนุมเซียน สนธิสัญญาการค้า และตลาดประมูล',
      leadPrefixTh: '【ประกาศทำเนียบยุทธภพและหอการค้า】',
      impactLabelTh: 'ดุลการค้า ชื่อเสียง และรางวัลที่ได้รับ',
      followUpDefaultTh: 'หอคลังและหอทูตกำลังปรับแผนแลกเปลี่ยนสินค้าและท่าทีทางการทูตตามดุลอำนาจใหม่',
      descTh: 'บันทึกผลการประชัน 4 สายในมหาชุมนุมยุทธภพ งานเลี้ยงฉลองสำนักปราณโอชา กองคาราวาน และหอประมูลแดนเซียน'
    },
    HEAVENLY_DAO_OMEN_SCROLL: {
      id: 'HEAVENLY_DAO_OMEN_SCROLL',
      nameTh: '🌌 จารึกนิมิตดาราและลางแปรปรวนแห่งม่านฟ้า',
      shortTh: '🌌 นิมิตดารา/ม่านฟ้า',
      toneTh: 'น้ำเสียงพยากรณ์ระดับมหากาพย์ บันทึกปรากฏการณ์ดาวเรียงตัว จันทร์สีเลือด รอยร้าวม่านกั้นภพ และวัฏจักรยุคสมัย',
      leadPrefixTh: '【จารึกนิมิตดาราและม่านฟ้า】',
      impactLabelTh: 'ผลกระทบระดับมหภาคและชีพจรปราณ',
      followUpDefaultTh: 'เหล่าผู้บำเพ็ญและหอค่ายกลกำลังปรับจังหวะโคจรปราณให้สอดรับกับกระแสฟ้าดินยุคใหม่',
      descTh: 'บันทึกการเปลี่ยนผ่านยุคสมัยแห่งปราณ บททดสอบจากผู้กำกับชะตาฟ้าดิน ค่ายกลฮวงจุ้ย 10 ธาตุ และตราหยกสำนัก'
    },
    PEAK_HALL_SCROLL: {
      id: 'PEAK_HALL_SCROLL',
      aliasId: 'SECT_SCRIBE_SCROLL',
      nameTh: '📜 ม้วนไม้ไผ่หออาลักษณ์และทำเนียบแปดยอดเขา',
      shortTh: '📜 หออาลักษณ์/แปดยอดเขา',
      toneTh: 'น้ำเสียงอาลักษณ์ประจำสำนัก สะท้อนชีวิตภายใน 8 ยอดเขา การแต่งตั้งเจ้าหุบเขา และสายใยระหว่างศิษย์ร่วมสำนัก',
      leadPrefixTh: '【ม้วนไม้ไผ่หออาลักษณ์สำนัก】',
      impactLabelTh: 'ผลต่อโบนัสยอดเขาและขวัญกำลังใจศิษย์',
      followUpDefaultTh: 'เจ้าหุบเขาและศิษย์ประจำยอดเขากำลังดำเนินกิจวัตรและเกื้อหนุนกันตามสายสัมพันธ์ภายในสำนัก',
      descTh: 'บันทึกการสถาปนายอดเขา การจัดสรรทรัพยากรหุบเขา การประลองระหว่างยอดเขา ยศผู้อาวุโส และสายใยความสัมพันธ์เชิงลึก'
    },
    PERIODIC_SECT_DIGEST: {
      id: 'PERIODIC_SECT_DIGEST',
      nameTh: '📊 สมุดฎีกาสรุปราชการหกหอประจำรอบ',
      shortTh: '📊 สมุดฎีกาหกหอ',
      toneTh: 'รายงานสังเคราะห์ประจำรอบด้วยน้ำเสียงขุนนางประจำหอ แยกบัญชีคลังหลวง การโอนภายใน คอขวดตบะ วิกฤตอายุขัย และความแออัดอาคาร',
      leadPrefixTh: '【สมุดฎีกาถวายรายงานหกหอประจำรอบ】',
      impactLabelTh: 'สถานะคงคลังและความเสี่ยงที่ต้องเฝ้าระวัง',
      followUpDefaultTh: 'ขุนนางทั้งหกหอและศิษย์ในสำนักกำลังปรับแผนการผลิต การบ่มเพาะ และการดูแลผู้บาดเจ็บตามฎีกาฉบับนี้โดยอัตโนมัติ',
      descTh: 'สรุปรายวัน/รายสัปดาห์/รายเดือน แสดงดุลศิลาจริง คงคลัง การโอนภายใน 28 ตัวชี้วัดเชิงลึก และฎีกาถวายรายงานจากขุนนางทั้ง 6 หอ'
    }
  });

  /* Pure deterministic 32-bit FNV-1a hash — NEVER touches W.rng or Math.random() */
  X.chronicleHash = str => {
    const s = String(str == null ? '' : str);
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0);
  };

  /* ---------- Pillar 4: News Intake & Notification Preferences (Separated from Archive Filters) ---------- */
  X.NEWS_CATEGORIES = Object.freeze({
    BATTLE: { id: 'BATTLE', nameTh: '⚔️ ศึกและการป้องกัน', logTypes: ['combat', 'raid', 'duel', 'spar', 'tournament', 'conflict', 'challenge', 'hunt', 'beast'] },
    CULT: { id: 'CULT', nameTh: '✨ ตบะและการทะลวงด่าน', logTypes: ['breakthrough', 'insight', 'learn', 'cult', 'seclusion', 'train'] },
    PEOPLE: { id: 'PEOPLE', nameTh: '👥 ชีวิตศิษย์และสายสัมพันธ์', logTypes: ['death', 'injury', 'heal', 'care', 'marriage', 'relation', 'recruit', 'disciple', 'awaken', 'desert', 'expel', 'punish'] },
    CRAFT: { id: 'CRAFT', nameTh: '⚗️ การผลิตและสิ่งปลูกสร้าง', logTypes: ['craft', 'alchemy', 'forge', 'harvest', 'fish', 'organ', 'research', 'build', 'building'] },
    ECONOMY: { id: 'ECONOMY', nameTh: '🪙 คลังและการค้า', logTypes: ['economy', 'finance', 'trade', 'shop', 'gear', 'welfare', 'donation', 'surplus', 'shortage', 'salary'] },
    GOVERNANCE: { id: 'GOVERNANCE', nameTh: '🏛️ การปกครองและสภาสำนัก', logTypes: ['decision', 'appoint', 'dismiss', 'promote', 'demote', 'succession', 'politics', 'scandal', 'crisis', 'banquet', 'policy', 'sect', 'system'] },
    JIANGHU: { id: 'JIANGHU', nameTh: '🧭 ยุทธภพและแดนลับ', logTypes: ['explore', 'mission', 'exped', 'diplomacy', 'legend', 'event'] },
    RUMOR: { id: 'RUMOR', nameTh: '🍶 ข่าวลือโรงเตี๊ยม', logTypes: ['rumor'] }
  });

  X.NEWS_PRESETS = Object.freeze({
    ALL: {
      id: 'ALL',
      nameTh: '📡 รับข่าวทั้งหมดตามปกติ',
      descTh: 'แสดงข่าวในฟีดครบทุกหมวด แจ้งเตือนด่วนสำหรับเรื่องสำคัญและวิกฤต (ประวัติทุกเรื่องถูกบันทึกครบ)',
      toastEnabled: true,
      minToastSeverity: 'NOTABLE',
      criticalAlertPolicy: 'ALWAYS_TOAST',
      onlyTrackedInToast: false,
      digestIntervalDays: 7,
      channelByCategory: { BATTLE: 'INSTANT', CULT: 'INSTANT', PEOPLE: 'INSTANT', CRAFT: 'FEED_ONLY', ECONOMY: 'FEED_ONLY', GOVERNANCE: 'INSTANT', JIANGHU: 'INSTANT', RUMOR: 'FEED_ONLY' }
    },
    MAJOR_ONLY: {
      id: 'MAJOR_ONLY',
      nameTh: '⭐ เฉพาะเรื่องสำคัญและวิกฤต',
      descTh: 'แจ้งเตือนด่วนเฉพาะหมุดหมายใหญ่และศึกวิกฤต เรื่องทั่วไปพับเก็บในสรุปประจำรอบและคลังประวัติ',
      toastEnabled: true,
      minToastSeverity: 'MAJOR',
      criticalAlertPolicy: 'ALWAYS_TOAST',
      onlyTrackedInToast: false,
      digestIntervalDays: 7,
      channelByCategory: { BATTLE: 'INSTANT', CULT: 'FEED_ONLY', PEOPLE: 'FEED_ONLY', CRAFT: 'DIGEST_ONLY', ECONOMY: 'DIGEST_ONLY', GOVERNANCE: 'INSTANT', JIANGHU: 'FEED_ONLY', RUMOR: 'DIGEST_ONLY' }
    },
    SECT_FOCUS: {
      id: 'SECT_FOCUS',
      nameTh: '🏯 โฟกัสกิจการภายในสำนัก',
      descTh: 'เน้นข่าวศิษย์ ตบะ การปกครอง คลัง และศึกหน้าด่าน ลดเสียงรบกวนจากข่าวลือและยุทธภพภายนอก',
      toastEnabled: true,
      minToastSeverity: 'NOTABLE',
      criticalAlertPolicy: 'ALWAYS_TOAST',
      onlyTrackedInToast: false,
      digestIntervalDays: 7,
      channelByCategory: { BATTLE: 'INSTANT', CULT: 'INSTANT', PEOPLE: 'INSTANT', CRAFT: 'FEED_ONLY', ECONOMY: 'FEED_ONLY', GOVERNANCE: 'INSTANT', JIANGHU: 'DIGEST_ONLY', RUMOR: 'DIGEST_ONLY' }
    },
    TRACKED_ONLY: {
      id: 'TRACKED_ONLY',
      nameTh: '🎯 เฉพาะศิษย์ที่ติดตาม + วิกฤต',
      descTh: 'ป้ายแจ้งเตือนด่วนแสดงเฉพาะเหตุการณ์ของศิษย์ที่ติดดาว (⭐) และภัยวิกฤตสำนัก',
      toastEnabled: true,
      minToastSeverity: 'NOTABLE',
      criticalAlertPolicy: 'ALWAYS_TOAST',
      onlyTrackedInToast: true,
      digestIntervalDays: 7,
      channelByCategory: { BATTLE: 'INSTANT', CULT: 'FEED_ONLY', PEOPLE: 'FEED_ONLY', CRAFT: 'DIGEST_ONLY', ECONOMY: 'DIGEST_ONLY', GOVERNANCE: 'FEED_ONLY', JIANGHU: 'DIGEST_ONLY', RUMOR: 'DIGEST_ONLY' }
    },
    QUIET_DIGEST: {
      id: 'QUIET_DIGEST',
      nameTh: '🌙 โหมดเงียบ (รวบอ่านสรุปประจำรอบ)',
      descTh: 'ปิดป้ายแจ้งเตือนทั่วไปทั้งหมดเพื่อปล่อยเกมไหลลื่น ยกเว้นภัยวิกฤตตามนโยบายที่ตั้งไว้ และเก็บประวัติครบ 100%',
      toastEnabled: false,
      minToastSeverity: 'CRITICAL',
      criticalAlertPolicy: 'ALWAYS_TOAST',
      onlyTrackedInToast: false,
      digestIntervalDays: 7,
      channelByCategory: { BATTLE: 'FEED_ONLY', CULT: 'DIGEST_ONLY', PEOPLE: 'DIGEST_ONLY', CRAFT: 'DIGEST_ONLY', ECONOMY: 'DIGEST_ONLY', GOVERNANCE: 'FEED_ONLY', JIANGHU: 'DIGEST_ONLY', RUMOR: 'DIGEST_ONLY' }
    },
    CUSTOM: {
      id: 'CUSTOM',
      nameTh: '⚙️ กำหนดเอง',
      descTh: 'ปรับแต่งช่องทางการรับข่าวและระดับความสำคัญด้วยตนเอง'
    }
  });

  const SEVERITY_RANK = { ROUTINE: 1, NOTABLE: 2, MAJOR: 3, CRITICAL: 4 };

  X.ensureNewsPrefs = W => {
    if (!W || !W.sect) return null;
    const def = X.NEWS_PRESETS.ALL;
    if (!W.sect.newsPrefs || typeof W.sect.newsPrefs !== 'object') {
      W.sect.newsPrefs = {
        preset: 'ALL',
        toastEnabled: true,
        minToastSeverity: 'NOTABLE',
        criticalAlertPolicy: 'ALWAYS_TOAST',
        onlyTrackedInToast: false,
        digestIntervalDays: 7,
        dedupeCooldownMins: 15,
        channelByCategory: Object.assign({}, def.channelByCategory),
        mutedCategories: [],
        readState: {
          lastReadLogSeq: 0,
          lastReadChronSeq: 0,
          readIds: []
        }
      };
    }
    const np = W.sect.newsPrefs;
    if (!np.preset || !X.NEWS_PRESETS[np.preset]) np.preset = 'ALL';
    if (typeof np.toastEnabled !== 'boolean') np.toastEnabled = true;
    if (!SEVERITY_RANK[np.minToastSeverity]) np.minToastSeverity = 'NOTABLE';
    if (!['ALWAYS_TOAST', 'STRICT_MUTE'].includes(np.criticalAlertPolicy)) np.criticalAlertPolicy = 'ALWAYS_TOAST';
    if (typeof np.onlyTrackedInToast !== 'boolean') np.onlyTrackedInToast = false;
    if (![0, 1, 7, 30].includes(np.digestIntervalDays)) np.digestIntervalDays = 7;
    if (!Number.isFinite(np.dedupeCooldownMins) || np.dedupeCooldownMins < 0) np.dedupeCooldownMins = 15;
    if (!np.channelByCategory || typeof np.channelByCategory !== 'object') {
      np.channelByCategory = Object.assign({}, def.channelByCategory);
    } else {
      Object.keys(def.channelByCategory).forEach(k => {
        if (!['INSTANT', 'FEED_ONLY', 'DIGEST_ONLY'].includes(np.channelByCategory[k])) {
          np.channelByCategory[k] = def.channelByCategory[k];
        }
      });
    }
    if (!Array.isArray(np.mutedCategories)) np.mutedCategories = [];
    if (!np.readState || typeof np.readState !== 'object') {
      np.readState = { lastReadLogSeq: 0, lastReadChronSeq: 0, readIds: [] };
    }
    if (!Number.isFinite(np.readState.lastReadLogSeq) || np.readState.lastReadLogSeq < 0) np.readState.lastReadLogSeq = 0;
    if (!Number.isFinite(np.readState.lastReadChronSeq) || np.readState.lastReadChronSeq < 0) np.readState.lastReadChronSeq = 0;
    if (!Array.isArray(np.readState.readIds)) np.readState.readIds = [];
    if (np.readState.readIds.length > 200) np.readState.readIds = np.readState.readIds.slice(-200);
    return np;
  };

  X.ensureNewsSystem = W => {
    if (!W || !W.sect) return null;
    X.ensureNewsPrefs(W);
    if (!Array.isArray(W.sect.digestHistory)) W.sect.digestHistory = [];
    if (W.sect.digestHistory.length > 24) W.sect.digestHistory = W.sect.digestHistory.slice(0, 24);
    if (!W.sect.historicalPeople || typeof W.sect.historicalPeople !== 'object') W.sect.historicalPeople = {};
    if (W.world) {
      if (!Array.isArray(W.world.chronicles)) W.world.chronicles = Array.isArray(W.chronicle) ? W.chronicle : [];
      W.chronicle = W.world.chronicles;
    }
    return W.sect.newsPrefs;
  };

  X.applyNewsPreset = (W, presetId) => {
    const np = X.ensureNewsPrefs(W);
    const p = X.NEWS_PRESETS[presetId];
    if (!np || !p || presetId === 'CUSTOM') return np;
    np.preset = presetId;
    np.toastEnabled = p.toastEnabled;
    np.minToastSeverity = p.minToastSeverity;
    np.criticalAlertPolicy = p.criticalAlertPolicy;
    np.onlyTrackedInToast = p.onlyTrackedInToast;
    np.digestIntervalDays = p.digestIntervalDays;
    np.channelByCategory = Object.assign({}, p.channelByCategory);
    np.mutedCategories = Object.keys(np.channelByCategory).filter(k => np.channelByCategory[k] === 'DIGEST_ONLY');
    return np;
  };

  X.classifyNewsCategory = item => {
    if (!item) return 'JIANGHU';
    if (item.isRumor || item.epistemicStatus === 'RUMOR' || item.reportFormat === 'TAVERN_BALLAD') return 'RUMOR';
    if (item.category) {
      const c = String(item.category);
      if (c === 'BATTLE') return 'BATTLE';
      if (c === 'SUCCESSION' || c === 'FACTION' || c === 'INTERNAL' || c === 'ELDER_COUNCIL_EDICT' || c === 'SECT_PEAK_POLITICS') return 'GOVERNANCE';
      if (c === 'DAO_HEART_SUTRA') return 'CULT';
      if (c === 'ECONOMY_AUCTION') return 'ECONOMY';
      if (c === 'FENG_SHUI_ARRAY') return 'CRAFT';
      return 'JIANGHU';
    }
    const t = String(item.type || '');
    for (const [catKey, spec] of Object.entries(X.NEWS_CATEGORIES)) {
      if (spec.logTypes.includes(t)) return catKey;
    }
    return 'JIANGHU';
  };

  X.classifyNewsSeverity = item => {
    if (!item) return 'ROUTINE';
    if (item.severity && SEVERITY_RANK[item.severity]) return item.severity;
    const t = String(item.type || '');
    const txt = String(item.text || item.titleTh || '');
    if (['death', 'succession', 'crisis', 'scandal'].includes(t) || item.category === 'SUCCESSION' || (t === 'raid' && /กำลังบุกสำนัก|ถูกบุกและปล้น|แตกพ่าย/.test(txt))) {
      return 'CRITICAL';
    }
    if (['marriage', 'tournament', 'challenge', 'expel', 'sect', 'policy', 'diplomacy', 'raid'].includes(t) || item.isMilestone || item.category === 'BATTLE') {
      return 'MAJOR';
    }
    if (['breakthrough', 'recruit', 'research', 'build', 'explore', 'mission', 'legend'].includes(t) || item.id && String(item.id).startsWith('CHRON_')) {
      return 'NOTABLE';
    }
    return 'ROUTINE';
  };

  X.shouldDeliverToast = (W, item) => {
    if (!W || !W.sect || !item) return false;
    const np = X.ensureNewsPrefs(W);
    const sev = X.classifyNewsSeverity(item);
    const cat = X.classifyNewsCategory(item);
    const isCritical = sev === 'CRITICAL';

    // Critical alert rule: honest and explicit!
    if (isCritical) {
      if (np.criticalAlertPolicy === 'STRICT_MUTE' && (!np.toastEnabled || np.channelByCategory[cat] === 'DIGEST_ONLY')) {
        return false;
      }
      if (np.criticalAlertPolicy === 'ALWAYS_TOAST') {
        return true;
      }
    }

    if (!np.toastEnabled) return false;
    const chan = np.channelByCategory[cat] || 'INSTANT';
    if (chan !== 'INSTANT') return false;
    if (Array.isArray(np.mutedCategories) && np.mutedCategories.includes(cat)) return false;
    if ((SEVERITY_RANK[sev] || 1) < (SEVERITY_RANK[np.minToastSeverity] || 2)) return false;

    if (np.onlyTrackedInToast) {
      const tracked = (W.sect && Array.isArray(W.sect.trackedNpcIds)) ? W.sect.trackedNpcIds : [];
      const itemIds = item.ids || item.npcIds || [];
      if (!itemIds.some(id => tracked.includes(id))) return false;
    }

    // Deduplication cooldown check (on transient world cache so it never bloats save)
    const cooldownTicks = Math.max(0, Number(np.dedupeCooldownMins) || 0);
    if (cooldownTicks > 0) {
      if (!W._toastDedupeMap) W._toastDedupeMap = {};
      const sig = (item.eventKey || ((item.type || item.category || 'ev') + ':' + String(item.text || item.titleTh || '').slice(0, 36)));
      const prevT = W._toastDedupeMap[sig];
      const nowT = Number.isFinite(item.t) ? item.t : (W.t || 0);
      if (prevT != null && Math.abs(nowT - prevT) < cooldownTicks && !isCritical) {
        return false;
      }
      W._toastDedupeMap[sig] = nowT;
    }
    return true;
  };

  X.shouldShowInLiveFeed = (W, item, includeDigestMuted) => {
    if (!W || !W.sect || !item) return true;
    if (includeDigestMuted) return true;
    const np = X.ensureNewsPrefs(W);
    const sev = X.classifyNewsSeverity(item);
    if (sev === 'CRITICAL' && np.criticalAlertPolicy === 'ALWAYS_TOAST') return true;
    const cat = X.classifyNewsCategory(item);
    if (np.channelByCategory[cat] === 'DIGEST_ONLY' || (Array.isArray(np.mutedCategories) && np.mutedCategories.includes(cat))) {
      return false;
    }
    return true;
  };

  X.isEntryUnread = (W, item) => {
    if (!W || !W.sect || !item) return false;
    const np = X.ensureNewsPrefs(W);
    const rs = np.readState;
    const key = String(item.id || item.eventKey || '');
    if (key && rs.readIds.includes(key)) return false;
    if (typeof item.id === 'number') {
      return item.id > (rs.lastReadLogSeq || 0);
    }
    if (typeof item.id === 'string' && item.id.startsWith('CHRON_')) {
      const seq = Number(item.id.slice(6)) || 0;
      return seq > (rs.lastReadChronSeq || 0);
    }
    return false;
  };

  X.markNewsRead = (W, opts) => {
    if (!W || !W.sect) return null;
    opts = opts || {};
    const np = X.ensureNewsPrefs(W);
    const rs = np.readState;
    if (opts.all) {
      rs.lastReadLogSeq = W.logSeq || 0;
      rs.lastReadChronSeq = (W.world && W.world.chronicleSeq) || 0;
      const chrons = (W.world && Array.isArray(W.world.chronicles)) ? W.world.chronicles : [];
      chrons.slice(0, 50).forEach(c => {
        if (c && c.id && !rs.readIds.includes(String(c.id))) rs.readIds.push(String(c.id));
      });
      if (rs.readIds.length > 200) rs.readIds = rs.readIds.slice(-200);
      return rs;
    }
    if (opts.id != null) {
      const k = String(opts.id);
      if (!rs.readIds.includes(k)) {
        rs.readIds.push(k);
        if (rs.readIds.length > 200) rs.readIds.shift();
      }
    }
    return rs;
  };

  X.getUnreadNewsSummary = W => {
    if (!W || !W.sect) return { unreadChronicles: 0, unreadMajorLogs: 0, unreadCritical: 0, totalUnread: 0 };
    X.ensureNewsPrefs(W);
    const chrons = (W.world && Array.isArray(W.world.chronicles)) ? W.world.chronicles : [];
    const sChrons = (W.sect && Array.isArray(W.sect.sectChronicle)) ? W.sect.sectChronicle : [];
    let unreadChronicles = 0, unreadMajorLogs = 0, unreadCritical = 0;
    for (let i = 0; i < chrons.length; i++) {
      const c = chrons[i];
      if (c && X.isEntryUnread(W, c)) {
        unreadChronicles++;
        if (X.classifyNewsSeverity(c) === 'CRITICAL') unreadCritical++;
      }
    }
    for (let i = 0; i < sChrons.length; i++) {
      const sc = sChrons[i];
      if (sc && X.isEntryUnread(W, sc)) {
        unreadMajorLogs++;
        if (X.classifyNewsSeverity(sc) === 'CRITICAL') unreadCritical++;
      }
    }
    return {
      unreadChronicles,
      unreadMajorLogs,
      unreadCritical,
      totalUnread: unreadChronicles + unreadMajorLogs
    };
  };

  function inferChronicleReportFormat(entry) {
    if (entry.reportFormat === 'SECT_SCRIBE_SCROLL') return 'PEAK_HALL_SCROLL';
    if (entry.reportFormat && X.CHRONICLE_REPORT_FORMATS[entry.reportFormat]) return entry.reportFormat;
    const cat = entry.category || 'JIANGHU';
    const title = String(entry.titleTh || '');
    if (cat === 'PERIODIC_DIGEST' || title.includes('สรุปสถานการณ์สำนักประจำรอบ')) return 'PERIODIC_SECT_DIGEST';
    if (cat === 'SECT_PEAK_POLITICS' || title.includes('ยอดเขา') || title.includes('หุบเขา') || title.includes('ผู้อาวุโสกิตติมศักดิ์')) return 'PEAK_HALL_SCROLL';
    if (cat === 'ELDER_COUNCIL_EDICT' || title.includes('สภาผู้อาวุโส') || title.includes('ราชโองการ') || title.includes('ตรวจสอบตำแหน่ง') || title.includes('ธรรมนูญสำนัก') || title.includes('สภาแผนยุทธศาสตร์')) return 'IMPERIAL_COUNCIL_DECREE';
    if (cat === 'SECRET_REALM_NODE' || title.includes('บูรณะคัมภีร์โบราณ') || title.includes('โหนดแดนลับ') || title.includes('ผู้มีพระคุณช่วยชีวิต') || title.includes('จุดสำรวจย่อย')) return 'SECRET_REALM_LOGBOOK';
    if (cat === 'GRAND_ASSEMBLY' || cat === 'ECONOMY_AUCTION' || title.includes('มหาชุมนุม') || title.includes('งานเลี้ยงฉลอง') || title.includes('คาราวาน') || title.includes('ประมูล') || title.includes('ขบวนเสบียง')) return 'CONTINENTAL_ASSEMBLY_GAZETTE';
    if (cat === 'HEAVENLY_DAO_ERA' || cat === 'FENG_SHUI_ARRAY' || title.includes('ยุคสมัย') || title.includes('ผู้กำกับชะตาฟ้าดิน') || title.includes('ตราหยก') || title.includes('ฮวงจุ้ย')) return 'HEAVENLY_DAO_OMEN_SCROLL';
    if (title.includes('คู่บำเพ็ญ') || title.includes('ทายาทสายเลือด') || cat === 'DAO_HEART_SUTRA') return 'LINEAGE_COMPANION_SCROLL';
    if (title.includes('สารทวงตัว') || title.includes('ฉีกสาร') || title.includes('ไถ่ถอนข้อกล่าวหา') || title.includes('ส่งตัวผู้ลี้ภัย') || title.includes('เชลยศึก') || cat === 'FACTION') return 'DISCIPLINE_EDICT';
    if (cat === 'BATTLE') return 'WAR_PAVILION_RECORD';
    if (cat === 'SUCCESSION') return 'ANCESTRAL_INSCRIPTION';
    if (cat === 'LEGEND' || cat === 'SECRET_REALM' || (cat === 'VISITOR' && (title.includes('พเนจร') || title.includes('หมอยา') || title.includes('จอมโจร') || title.includes('ค่ายกล')))) return 'TAVERN_BALLAD';
    return 'PIGEON_DISPATCH';
  }

  /* Deterministic causal story thread inference — ONLY assigns a thread when real entity/topic keys match */
  X.inferStoryThread = (W, entry) => {
    if (!entry) return { storyThreadId: null, storyThreadTitleTh: null };
    if (entry.storyThreadId) {
      return {
        storyThreadId: String(entry.storyThreadId),
        storyThreadTitleTh: entry.storyThreadTitleTh || ('เส้นเรื่อง: ' + (entry.titleTh || entry.storyThreadId))
      };
    }
    const cat = entry.category || '';
    const title = String(entry.titleTh || '');
    const npcIds = Array.isArray(entry.npcIds) ? entry.npcIds.filter(id => id && !/^(?:GUEST|ENVOY)_/.test(String(id))) : [];
    const day = Number.isFinite(entry.day) ? entry.day : ((W && W.day) || 0);
    const sects = Array.isArray(entry.involvedSects) ? entry.involvedSects.filter(Boolean) : [];
    const sectName = (W && W.sect && W.sect.name) || '';
    const foreignSect = sects.find(s => s !== sectName) || sects[0] || '';

    if (cat === 'SUCCESSION' || title.includes('ชิงบัลลังก์') || title.includes('สืบทอดตำแหน่งเจ้าสำนัก')) {
      const targetSect = foreignSect || sectName || 'สำนัก';
      return {
        storyThreadId: 'thread:succ:' + targetSect + ':' + Math.floor(day / 30),
        storyThreadTitleTh: 'วิกฤตสืบทอดอำนาจ: ' + targetSect
      };
    }
    if (title.includes('สารทวงตัว') || title.includes('ผู้ลี้ภัย') || title.includes('แปรพักตร์') || title.includes('ทวงคืนหนี้แค้น')) {
      const keyNpc = npcIds[0] || foreignSect || 'renegade';
      return {
        storyThreadId: 'thread:renegade:' + keyNpc,
        storyThreadTitleTh: 'ปมผู้ลี้ภัยและหนี้แค้นยุทธภพ' + (foreignSect ? (' (' + foreignSect + ')') : '')
      };
    }
    if (cat === 'BATTLE' && (title.includes('ศึกพิทักษ์สำนัก') || title.includes('วิกฤตศึกหน้าด่าน') || title.includes('บุกสำนัก'))) {
      return {
        storyThreadId: 'thread:raid:' + Math.floor(day / 5),
        storyThreadTitleTh: 'ศึกป้องกันหน้าด่านสำนัก (ช่วงวันที่ ' + day + ')'
      };
    }
    if (cat === 'DAO_HEART_SUTRA' && npcIds.length === 1) {
      const figName = (Array.isArray(entry.involvedFigures) && entry.involvedFigures[0]) || npcIds[0];
      return {
        storyThreadId: 'thread:daoheart:' + npcIds[0],
        storyThreadTitleTh: 'เส้นทางจิตมรรคาและศาสตราของ ' + figName
      };
    }
    if ((cat === 'SECRET_REALM' || cat === 'SECRET_REALM_NODE') && entry.macroRegion) {
      const regName = (X.WORLD_REGIONS && X.WORLD_REGIONS[entry.macroRegion] && X.WORLD_REGIONS[entry.macroRegion].shortTh) || entry.macroRegion;
      return {
        storyThreadId: 'thread:realm:' + entry.macroRegion + ':' + Math.floor(day / 30),
        storyThreadTitleTh: 'การสำรวจแดนลับเขต' + regName
      };
    }
    return { storyThreadId: null, storyThreadTitleTh: null };
  };

  function buildDefaultCausalMeta(W, entry, fmtId, actorSnapshots) {
    const cat = entry.category || "JIANGHU";
    const isRumor = !!(entry.isRumor || entry.epistemicStatus === "RUMOR" || (fmtId === "TAVERN_BALLAD" && entry.unverified));
    const sects = Array.isArray(entry.involvedSects) && entry.involvedSects.length ? entry.involvedSects.join(" ↔ ") : ((W && W.sect && W.sect.name) || "สำนักเมฆาหยก");
    const figs = Array.isArray(entry.involvedFigures) && entry.involvedFigures.length
      ? entry.involvedFigures.join(" · ")
      : (Array.isArray(actorSnapshots) && actorSnapshots.length ? actorSnapshots.map(a => a.fullName).filter(Boolean).join(" · ") : "ผู้ฝึกตนในยุทธภพ");
    const regName = (X.WORLD_REGIONS && entry.macroRegion && X.WORLD_REGIONS[entry.macroRegion] && X.WORLD_REGIONS[entry.macroRegion].nameTh) || "เขตแดนยุทธภพ";
    const cs = entry.combatSummary || null;
    const csHighlightTxt = cs && Array.isArray(cs.highlights) && cs.highlights.length
      ? cs.highlights.slice(0, 3).map(h => h.textTh || h).join(" · ")
      : (cs && (cs.summaryLineTh || cs.tacticalSummaryTh) ? (cs.summaryLineTh || cs.tacticalSummaryTh) : "");

    const topActorWhy = (Array.isArray(actorSnapshots) && actorSnapshots[0] && actorSnapshots[0].topWhyTh)
      ? ("แรงขับเคลื่อนหลัก: " + actorSnapshots[0].fullName + " (" + actorSnapshots[0].topWhyTh + ")")
      : "";

    const defaultOrigin = {
      BATTLE: "การปะทะทางยุทธศาสตร์ในเขต" + regName + (sects ? (" (" + sects + ")") : ""),
      SUCCESSION: "การเปลี่ยนผ่านอำนาจนำภายใน " + sects + (topActorWhy ? (" · " + topActorWhy) : ""),
      FACTION: "การเจรจาและถ่วงดุลผลประโยชน์ระหว่าง " + sects,
      SECRET_REALM: "ชีพจรปราณฟ้าดินในเขต" + regName + " เปิดทางสู่โบราณสถาน",
      LEGEND: "ความเคลื่อนไหวของยอดฝีมือระดับสูงในเขต" + regName,
      VISITOR: "ผู้ฝึกตนพเนจรเดินทางมาถึงหน้าด่าน " + sects,
      INTERNAL: topActorWhy || ("เหตุการณ์ภายในและการตัดสินใจของสมาชิก " + sects),
      FENG_SHUI_ARRAY: "การจัดวางค่ายกลฮวงจุ้ยและชีพจรปฐพีของ " + sects,
      DAO_HEART_SUTRA: topActorWhy || "สภาวะจิตใจ ปมมารในใจ และความผูกพันกับศาสตราคู่กาย",
      ECONOMY_AUCTION: "การหมุนเวียนทรัพยากรขบวนคาราวานและคลังสำนัก",
      PERIODIC_DIGEST: "การประมวลผลบัญชีคลัง ผลงานศิษย์ และความเสี่ยงจริงตามรอบเวลา"
    }[cat] || ("เหตุปัจจัยเชื่อมโยงในเขต" + regName);

    const defaultImpact = {
      BATTLE: entry.consequenceTh || (csHighlightTxt ? ("ผลศึกเชิงยุทธวิธี: " + csHighlightTxt) : "ส่งผลต่อกำลังพลและชื่อเสียงสำนักที่เกี่ยวข้อง"),
      SUCCESSION: entry.consequenceTh || "เปลี่ยนผู้นำและสมดุลอำนาจการปกครองภายในสำนัก",
      FACTION: entry.consequenceTh || "ปรับเปลี่ยนท่าทีทางการทูตและพันธะสัญญาระหว่างสำนัก",
      SECRET_REALM: entry.consequenceTh || "ส่งผลต่อตบะ คัมภีร์ และวัตถุดิบที่นำกลับเข้าคลังสำนัก",
      LEGEND: entry.consequenceTh || "เปลี่ยนดุลกำลังของยอดฝีมือในเขต" + regName,
      VISITOR: entry.consequenceTh || "ส่งผลต่อไมตรีผู้มาเยือนและโอกาสแลกเปลี่ยนทรัพยากร",
      INTERNAL: entry.consequenceTh || "ส่งผลต่อความพึงพอใจ อารมณ์ และสายสัมพันธ์ในสำนัก",
      FENG_SHUI_ARRAY: entry.consequenceTh || "ส่งผลต่อโบนัสสิ่งปลูกสร้างและอัตราบ่มเพาะปราณ",
      DAO_HEART_SUTRA: entry.consequenceTh || "ส่งผลต่อโอกาสทะลวงด่านและอานุภาพวิชาประจำตัว",
      ECONOMY_AUCTION: entry.consequenceTh || "ส่งผลต่อดุลศิลาวิญญาณและพัสดุคงคลัง",
      ELDER_COUNCIL_EDICT: entry.consequenceTh || "ส่งผลต่อมติสภาผู้อาวุโสและการใช้งบสำรองสำนัก",
      SECRET_REALM_NODE: entry.consequenceTh || "ส่งผลต่อความคืบหน้าการสำรวจโหนดแดนลับและคัมภีร์โบราณ",
      GRAND_ASSEMBLY: entry.consequenceTh || "ส่งผลต่อชื่อเสียงสำนักและรางวัลจากมหาชุมนุม",
      HEAVENLY_DAO_ERA: entry.consequenceTh || "ส่งผลต่อกระแสปราณยุคสมัยและเงื่อนไขฟ้าดิน",
      SECT_PEAK_POLITICS: entry.consequenceTh || "ส่งผลต่อโบนัสยอดเขาและสายสัมพันธ์ของศิษย์ในสังกัด",
      PERIODIC_DIGEST: entry.consequenceTh || "สรุปสถานะคลัง ผลงาน และความเสี่ยงประจำรอบ"
    }[cat] || (entry.consequenceTh || "บันทึกไว้ในพงศาวดารยุทธภพ");

    const originCauseTh = entry.originCauseTh || defaultOrigin;
    const actorChainTh = entry.actorChainTh || (
      "ผู้เกี่ยวข้อง: " + figs + " (" + sects + ")" +
      (cs && cs.mvp && cs.mvp.nameTh ? (" · ผู้โดดเด่นในศึก: " + cs.mvp.nameTh) : "") +
      (topActorWhy && !originCauseTh.includes(topActorWhy) ? (" · " + topActorWhy) : "")
    );
    const systemImpactTh = entry.systemImpactTh || defaultImpact;
    const fmtSpec = X.CHRONICLE_REPORT_FORMATS[fmtId] || X.CHRONICLE_REPORT_FORMATS.PIGEON_DISPATCH;
    const followUpTh = entry.followUpTh || fmtSpec.followUpDefaultTh || "ติดตามผลต่อเนื่องในหน้าต่างสำนักหรือแผนที่ยุทธภพ";

    const directorInsightTh = entry.directorInsightTh || (
      (isRumor ? "[ข่าวลือโรงเตี๊ยม — รอการพิสูจน์] " : "[ข้อสังเกตเชิงระบบ] ") +
      "ต้นเหตุจาก" + originCauseTh + " ➔ แนวโน้มต่อจากนี้: " + followUpTh
    );
    const playerLensHighlights = entry.playerLensHighlights || {
      WORLD_WATCHER: "🌍 [มุมมองผู้เฝ้ามองโลก]: " + sects + " — " + systemImpactTh,
      NOVEL_READER: "📖 [มุมมองนักอ่านนิยาย]: " + (entry.storyTh || entry.titleTh || ""),
      NPC_OBSERVER: "🔍 [มุมมองผู้จับตาดู NPC]: " + actorChainTh,
      GRAND_STRATEGIST: "♟️ [มุมมองนักวางแผนยุทธศาสตร์]: " + (csHighlightTxt ? (csHighlightTxt + " · " + followUpTh) : (systemImpactTh + " · " + followUpTh))
    };
    return {
      originCauseTh,
      actorChainTh,
      systemImpactTh,
      followUpTh,
      directorInsightTh,
      playerLensHighlights,
      combatBreakdownTh: entry.combatBreakdownTh || csHighlightTxt || ""
    };
  }

  /* Build authoritative fact snapshot at the exact moment of the event */
  X.buildFactSnapshot = (W, entry, actorSnapshots, fmtId) => {
    const isRumor = !!(entry.isRumor || (fmtId === 'TAVERN_BALLAD' && entry.unverified));
    const epistemicStatus = entry.epistemicStatus || (isRumor ? 'RUMOR' : (entry.partiallyObserved ? 'OBSERVED' : 'VERIFIED'));
    const certaintyLabelTh = epistemicStatus === 'RUMOR'
      ? '🍶 ข่าวลือโรงเตี๊ยม (คำบอกเล่า ยังไม่ยืนยันข้อเท็จจริงทั้งหมด)'
      : epistemicStatus === 'OBSERVED'
      ? '👁️ รายงานสังเกตการณ์ (ข้อมูลเท่าที่สายสืบพบเห็น)'
      : '📜 บันทึกข้อเท็จจริงยืนยันจากระบบ';

    const cs = entry.combatSummary || null;
    const verifiedFacts = [];
    if (Array.isArray(actorSnapshots) && actorSnapshots.length) {
      actorSnapshots.slice(0, 4).forEach(a => {
        if (!a) return;
        const stTxt = a.stageNameTh ? (' · ' + a.stageNameTh) : (a.stage ? (' · ขั้น ' + a.stage) : '');
        const whyTxt = a.topWhyTh ? (' · แรงจูงใจขณะนั้น: ' + a.topWhyTh) : '';
        verifiedFacts.push('ผู้เกี่ยวข้อง ณ เวลาเกิดเหตุ: ' + a.fullName + ' (' + (a.roleTh || 'ผู้ฝึกตน') + stTxt + ')' + whyTxt);
      });
    }
    if (cs) {
      if (cs.outcomeLabelTh || cs.outcome) {
        verifiedFacts.push('ผลศึกที่บันทึก: ' + (cs.outcomeLabelTh || cs.outcome) + ' (ระยะเวลา ' + (cs.durationTicks || 1) + ' นาที)');
      }
      if (cs.stats) {
        const stParts = [];
        if (cs.stats.intercepts > 0) stParts.push('เข้าขวางคุ้มกัน ' + cs.stats.intercepts + ' ครั้ง');
        if (cs.stats.zocStrikes > 0) stParts.push('สกัดเขตคุกคาม ' + cs.stats.zocStrikes + ' ครั้ง');
        if (cs.stats.interrupts > 0) stParts.push('ขัดจังหวะวิชา ' + cs.stats.interrupts + ' ครั้ง');
        if (cs.stats.targetSwitches > 0) stParts.push('เบนเป้าหมาย ' + cs.stats.targetSwitches + ' ครั้ง');
        if (stParts.length) verifiedFacts.push('สถิติยุทธวิธีจริง: ' + stParts.join(' · '));
      }
      if (Array.isArray(cs.casualties) && cs.casualties.length) {
        verifiedFacts.push('ผู้เสียชีวิตในศึก: ' + cs.casualties.map(x => x.nameTh).join(', '));
      }
    }
    if (entry.factDeltas && typeof entry.factDeltas === 'object') {
      for (const [dk, dv] of Object.entries(entry.factDeltas)) {
        if (dv != null && dv !== '') verifiedFacts.push(dk + ': ' + dv);
      }
    }

    return {
      location:entry.location || entry.meta?.location || null,
      capturedAtTick: Number.isFinite(entry.t) ? entry.t : ((W && W.t) || 0),
      capturedAtDay: Number.isFinite(entry.day) ? entry.day : ((W && W.day) || 0),
      epistemicStatus,
      certaintyLabelTh,
      isRumor,
      actorsAtEvent: (actorSnapshots || []).slice(0, 6).map(a => ({
        id: a.id,
        fullName: a.fullName,
        given: a.given,
        surname: a.surname,
        roleTh: a.roleTh,
        pathNameTh: a.pathNameTh || a.path || null,
        stage: a.stage || 0,
        stageNameTh: a.stageNameTh || null,
        topWhyTh: a.topWhyTh || null,
        deadAtEvent: !!a.dead
      })),
      factDeltas: entry.factDeltas ? Object.assign({}, entry.factDeltas) : null,
      verifiedFacts,
      unknownsTh: isRumor ? 'รายละเอียดบางส่วนมาจากคำบอกเล่าในโรงเตี๊ยม อาจคลาดเคลื่อนจากความจริงจนกว่าจะส่งคนไปพิสูจน์' : null
    };
  };

  /* Trim W.world.chronicles to <= 200 while protecting milestone entries from routine eviction */
  X.trimChroniclesWithMilestoneProtection = (W, maxCap, maxPinned) => {
    if (!W || !W.world || !Array.isArray(W.world.chronicles)) return;
    const cap = maxCap || 200;
    const pinLim = maxPinned || 60;
    const list = W.world.chronicles;
    if (list.length <= cap) return;
    const overflow = list.length - cap;
    let removed = 0;
    let pinnedCount = 0;
    for (let i = list.length - 1; i >= 0 && removed < overflow; i--) {
      const c = list[i];
      const isPin = c && (c.isMilestone || c.severity === 'CRITICAL' || ['SUCCESSION', 'HEAVENLY_DAO_ERA'].includes(c.category));
      if (isPin && pinnedCount < pinLim) {
        pinnedCount++;
        continue;
      }
      list.splice(i, 1);
      removed++;
    }
    if (list.length > cap) {
      list.length = cap;
    }
    W.world.chronicleTrimmedCount = (W.world.chronicleTrimmedCount || 0) + overflow;
  };

  X.recordChronicle = (W, entry) => {
    if (!W || !W.world || !entry) return null;
    if (W._expeditionLocation && !entry.location) entry = {...entry,location:W._expeditionLocation};
    if (!Array.isArray(W.world.chronicles)) W.world.chronicles = Array.isArray(W.chronicle) ? W.chronicle : [];
    W.chronicle = W.world.chronicles;
    if (W.sect) X.ensureNewsPrefs(W);

    const day = Number.isFinite(entry.day) ? entry.day : (Number.isFinite(W.day) ? W.day : 0);
    const t = Number.isFinite(entry.t) ? entry.t : (Number.isFinite(W.t) ? W.t : day * 1440);
    const eventKey = entry.eventKey || ((entry.category || "JIANGHU") + ":" + (entry.titleTh || "") + ":" + day);
    const dedupeWindow = Number.isFinite(entry.dedupeWindowTicks) ? entry.dedupeWindowTicks : 10;
    const existing = W.world.chronicles.find(c => c && c.eventKey === eventKey && Math.abs((c.t || 0) - t) <= dedupeWindow);
    if (existing && !entry.allowDuplicate) return existing;

    W.world.chronicleSeq = (W.world.chronicleSeq || 0) + 1;
    const fmtId = inferChronicleReportFormat(entry);
    const fmtDef = X.CHRONICLE_REPORT_FORMATS[fmtId] || X.CHRONICLE_REPORT_FORMATS.PIGEON_DISPATCH;
    const npcIds = Array.isArray(entry.npcIds) ? entry.npcIds.filter(id => id && !/^(?:GUEST|ENVOY)_/.test(String(id))) : [];
    const actorSnapshots = npcIds.map(id => {
      const live = W.byId && W.byId[id];
      if (live && g.SIM && g.SIM.snapshotPerson) {
        return Object.assign({}, g.SIM.snapshotPerson(W, live));
      }
      const hp = W.sect && W.sect.historicalPeople && W.sect.historicalPeople[id];
      if (hp) return Object.assign({}, hp);
      const fig = (W.world && W.world.figuresById && W.world.figuresById[id]) || null;
      if (fig) {
        return {
          id,
          fullName: fig.titleAndNameTh || fig.nameTh || id,
          given: fig.nameTh || id,
          surname: "",
          roleTh: fig.roleTh || "จอมยุทธ์ยุทธภพ",
          path: fig.cult && fig.cult.path,
          stage: (fig.cult && fig.cult.stage) || 1,
          statusTh: fig.sectNameTh || "จอมยุทธ์นอกสำนัก"
        };
      }
      return { id, fullName: id, given: id, surname: "", roleTh: "ผู้ฝึกตน", statusTh: "ไม่ปรากฏข้อมูลปัจจุบัน" };
    });

    const causal = buildDefaultCausalMeta(W, entry, fmtId, actorSnapshots);
    const isRumor = !!(entry.isRumor || (fmtId === "TAVERN_BALLAD" && entry.unverified));
    const epistemicStatus = entry.epistemicStatus || (isRumor ? "RUMOR" : (entry.partiallyObserved ? "OBSERVED" : "VERIFIED"));
    const threadInfo = X.inferStoryThread(W, Object.assign({}, entry, { day, npcIds }));
    const factSnapshot = X.buildFactSnapshot(W, Object.assign({}, entry, { day, t, isRumor, epistemicStatus }), actorSnapshots, fmtId);
    const severity = entry.severity || X.classifyNewsSeverity({ category: entry.category, titleTh: entry.titleTh, isMilestone: entry.isMilestone });
    const isMilestone = !!(entry.isMilestone || severity === 'CRITICAL' || ['SUCCESSION', 'HEAVENLY_DAO_ERA'].includes(entry.category));

    const rec = {
      id: entry.id || ("CHRON_" + W.world.chronicleSeq),
      eventKey,
      day,
      t,
      isRumor,
      epistemicStatus,
      severity,
      isMilestone,
      storyThreadId: threadInfo.storyThreadId,
      storyThreadTitleTh: threadInfo.storyThreadTitleTh,
      verificationStatusTh: isRumor ? "🍶 ข่าวลือโรงเตี๊ยม" : (epistemicStatus === "OBSERVED" ? "👁️ รายงานสังเกตการณ์" : (entry.verificationStatusTh || "📜 บันทึกยืนยัน")),
      reportFormat: fmtId,
      reportFormatTh: entry.reportFormatTh || fmtDef.nameTh,
      reportFormatShortTh: fmtDef.shortTh,
      category: entry.category || "JIANGHU",
      categoryTh: entry.categoryTh || {
        BATTLE: "⚔️ ศึกปะทะยุทธภพ",
        SUCCESSION: "👑 วิกฤตสืบทอดบัลลังก์สำนัก",
        FACTION: "⚖️ มติสภาและการเมือง 3 ฝ่าย",
        SECRET_REALM: "🌌 ศึกชิงมรดกแดนลับโบราณ",
        LEGEND: "🐉 ตำนานยอดคนหวนคืนยุทธภพ",
        VISITOR: "🎐 เหตุการณ์ผู้มาเยือนหน้าด่าน",
        INTERNAL: "🏛️ คลื่นใต้น้ำและการเมืองในสำนัก",
        FENG_SHUI_ARRAY: "☯️ ค่ายกลฮวงจุ้ย & ปรากฏการณ์ฟ้าดิน",
        DAO_HEART_SUTRA: "🪷 ปมมารในใจ · จิตศาสตรา & คัมภีร์มรดก",
        ECONOMY_AUCTION: "🐪 คาราวานการค้า & หอประมูลแดนเซียน",
        ELDER_COUNCIL_EDICT: "🏛️ สภาผู้อาวุโส & ราชโองการสำนัก",
        SECRET_REALM_NODE: "🧭 สำรวจโหนดแดนลับ & บูรณะคัมภีร์โบราณ",
        GRAND_ASSEMBLY: "🏆 มหาชุมนุมยุทธภพ 4 สาย & งานเลี้ยงปราณโอชา",
        HEAVENLY_DAO_ERA: "🌌 ผู้กำกับชะตาฟ้าดิน & วัฏจักรยุคสมัย",
        SECT_PEAK_POLITICS: "🏔️ การเมืองยอดเขา · ยศผู้อาวุโส & สายใยความสัมพันธ์",
        PERIODIC_DIGEST: "📊 สรุปสถานการณ์สำนักประจำรอบ"
      }[entry.category || "JIANGHU"] || "📜 จดหมายเหตุยุทธภพ",
      icon: entry.icon || "📜",
      titleTh: entry.titleTh || "บันทึกเหตุการณ์ยุทธภพ",
      storyTh: entry.storyTh || "",
      originCauseTh: causal.originCauseTh,
      actorChainTh: causal.actorChainTh,
      systemImpactTh: causal.systemImpactTh,
      followUpTh: causal.followUpTh,
      directorInsightTh: causal.directorInsightTh,
      playerLensHighlights: causal.playerLensHighlights,
      combatBreakdownTh: causal.combatBreakdownTh,
      combatSummary: entry.combatSummary || null,
      consequenceTh: entry.consequenceTh || "",
      macroRegion: entry.macroRegion || "CENTRAL_HEARTLAND",
      involvedSects: Array.isArray(entry.involvedSects) ? entry.involvedSects : [],
      involvedFigures: Array.isArray(entry.involvedFigures) && entry.involvedFigures.length
        ? entry.involvedFigures
        : actorSnapshots.map(a => a.fullName).filter(Boolean),
      npcIds,
      actorSnapshots,
      factSnapshot,
      digestPayload: entry.digestPayload || null
    };
    W.world.chronicles.unshift(rec);
    X.trimChroniclesWithMilestoneProtection(W, 200, 60);
    if (!entry.quiet && W.log && !W._founding) {
      const logType = entry.logType || (entry.category === "SUCCESSION" || entry.category === "FACTION" || entry.category === "INTERNAL" ? "politics" : entry.category === "SECRET_REALM" ? "explore" : "mission");
      const fullLog = rec.icon + " 【" + rec.titleTh + "】 " + rec.storyTh + (rec.consequenceTh ? " ➔ " + rec.consequenceTh : "");
      W.log(logType, fullLog, npcIds, {
        eventKey,
        combatSummary: rec.combatSummary,
        chronicleId: rec.id,
        storyThreadId: rec.storyThreadId,
        storyThreadTitleTh: rec.storyThreadTitleTh,
        originCauseTh: rec.originCauseTh,
        consequenceTh: rec.consequenceTh,
        followUpTh: rec.followUpTh,
        severity: rec.severity,
        isMilestone: rec.isMilestone
      });
    }
    return rec;
  };

  /* ---------- Pillar 2: Format-Specific Narrative Presenter (Pure Read-Only, Zero RNG) ---------- */
  X.presentChronicleEntry = (W, rec) => {
    if (!rec) return null;
    const rawFmt = rec.reportFormat === 'SECT_SCRIBE_SCROLL' ? 'PEAK_HALL_SCROLL' : rec.reportFormat;
    const fmtId = (rawFmt && X.CHRONICLE_REPORT_FORMATS[rawFmt]) ? rawFmt : 'PIGEON_DISPATCH';
    const fmtDef = X.CHRONICLE_REPORT_FORMATS[fmtId];
    const snap = rec.factSnapshot || X.buildFactSnapshot(W, rec, rec.actorSnapshots || [], fmtId);
    const cs = rec.combatSummary || null;
    const sev = rec.severity || X.classifyNewsSeverity(rec);
    const sevBadge = {
      CRITICAL: { labelTh: '🔥 วิกฤต', color: '#ef476f' },
      MAJOR: { labelTh: '⭐ สำคัญ', color: '#ffd166' },
      NOTABLE: { labelTh: '📌 น่าสนใจ', color: '#4fb2f2' },
      ROUTINE: { labelTh: '· ทั่วไป', color: '#9aa5b1' }
    }[sev] || { labelTh: '📌 บันทึก', color: '#4fb2f2' };

    // Build non-redundant turning point / causal line based on format & real snapshot data
    let turningPointLabelTh = '🌱 ต้นเหตุและจุดเปลี่ยน';
    let turningPointBodyTh = '';
    if (fmtId === 'WAR_PAVILION_RECORD') {
      turningPointLabelTh = '⚔️ จังหวะชี้ขาดในสมรภูมิ';
      const hlList = (cs && Array.isArray(cs.highlights) && cs.highlights.length)
        ? cs.highlights.slice(0, 3).map(h => h.textTh || h).filter(Boolean)
        : [];
      const tacLine = (cs && (cs.tacticalSummaryTh || cs.summaryLineTh)) || rec.combatBreakdownTh || '';
      const mvpTxt = (cs && cs.mvp && (cs.mvp.nameTh || cs.mvp.name)) ? ('ผู้โดดเด่น: ' + (cs.mvp.nameTh || cs.mvp.name) + (cs.mvp.intercepts > 0 ? (' (คุ้มกัน ' + cs.mvp.intercepts + ' ครั้ง)') : '')) : '';
      turningPointBodyTh = [tacLine, hlList.join(' · '), mvpTxt].filter(Boolean).join(' — ');
    } else if (fmtId === 'TAVERN_BALLAD') {
      turningPointLabelTh = '🍶 ที่มาของคำร่ำลือ';
      turningPointBodyTh = (rec.originCauseTh || 'นักเดินทางในโรงเตี๊ยมเล่าต่อกันมา') + (rec.isRumor ? ' (ยังไม่มีหลักฐานยืนยันครบทุกส่วน)' : '');
    } else if (fmtId === 'IMPERIAL_COUNCIL_DECREE' || fmtId === 'DISCIPLINE_EDICT') {
      turningPointLabelTh = '⚖️ เหตุผลและฐานอำนาจตัดสินใจ';
      turningPointBodyTh = rec.originCauseTh || '';
    } else if (fmtId === 'LINEAGE_COMPANION_SCROLL' || fmtId === 'ANCESTRAL_INSCRIPTION') {
      turningPointLabelTh = '🕯️ สายใยเหตุปัจจัยและผู้สืบทอด';
      turningPointBodyTh = [rec.originCauseTh, rec.actorChainTh].filter(Boolean).join(' · ');
    } else if (fmtId === 'SECRET_REALM_LOGBOOK') {
      turningPointLabelTh = '🧭 บันทึกเส้นทางและด่านทดสอบ';
      turningPointBodyTh = rec.originCauseTh || '';
    } else if (fmtId === 'PERIODIC_SECT_DIGEST') {
      turningPointLabelTh = '📊 ภาพรวมดุลทรัพยากรและกำลังคน';
      turningPointBodyTh = rec.originCauseTh || '';
    } else {
      turningPointBodyTh = rec.originCauseTh || '';
    }

    // Impact & actionable follow-up (avoiding duplicate text if storyTh already contains consequenceTh)
    const impactTh = rec.consequenceTh || ( rec.systemImpactTh !== rec.storyTh ? rec.systemImpactTh : '' ) || '';
    const followUpTh = rec.followUpTh || fmtDef.followUpDefaultTh || '';

    // Structured collapsible numeric & reference details (with in-game meaning explanations!)
    const numericDetails = [];
    const cal = (g.SIM && g.SIM.calendar && Number.isFinite(rec.t)) ? g.SIM.calendar(rec.t) : null;
    if (cal) {
      numericDetails.push({
        labelTh: 'เวลาเกิดเหตุในโลกจำลอง',
        valueTh: 'ปีที่ ' + cal.year + ' เดือน ' + cal.month + ' วันที่ ' + cal.dom + ' (' + g.U.pad2(cal.hour) + ':' + g.U.pad2(cal.minute) + ' น.)',
        meaningTh: 'อ้างอิงตามปฏิทินจำลอง 360 วัน/ปี (วันที่ ' + rec.day + ' นับจากก่อตั้ง)'
      });
    }
    numericDetails.push({
      labelTh: 'สถานะความน่าเชื่อถือของข้อมูล',
      valueTh: snap.certaintyLabelTh,
      meaningTh: snap.isRumor ? 'ข้อมูลจากข่าวลืออาจคลาดเคลื่อน คณะสอดแนมของหอข่าวกรองและผู้ใฝ่รู้จะทยอยพิสูจน์ความจริงตามลำดับ' : 'บันทึกจากเหตุการณ์ที่เกิดขึ้นจริงในระบบจำลอง ณ เวลานั้น'
    });
    if (Array.isArray(snap.actorsAtEvent) && snap.actorsAtEvent.length) {
      snap.actorsAtEvent.forEach(a => {
        const curLive = W && W.byId && W.byId[a.id];
        const statusNow = curLive
          ? (curLive.dead ? 'ปัจจุบันเสียชีวิตแล้ว' : (curLive.exiled ? 'ปัจจุบันออกจากสำนักแล้ว' : 'ปัจจุบันยังอยู่ในสำนัก'))
          : 'ไม่อยู่ในทำเนียบปัจจุบัน (ดูได้จากระเบียนประวัติ)';
        numericDetails.push({
          labelTh: 'สถานะผู้เกี่ยวข้อง ณ เวลาเกิดเหตุ: ' + a.fullName,
          valueTh: (a.roleTh || 'ผู้ฝึกตน') + (a.stageNameTh ? (' · ' + a.stageNameTh) : '') + (a.topWhyTh ? (' · เหตุผลขณะนั้น: ' + a.topWhyTh) : ''),
          meaningTh: statusNow + ' (ข้อมูลนี้เก็บจาก Snapshot ณ เวลาเกิดเหตุ ไม่ถูกเขียนทับด้วยสถานะปัจจุบัน)'
        });
      });
    }
    if (cs) {
      numericDetails.push({
        labelTh: 'ระยะเวลาและผลลัพธ์การปะทะ',
        valueTh: (cs.outcomeLabelTh || cs.outcome || 'ยุติศึก') + ' · ใช้เวลา ' + (cs.durationTicks || 1) + ' นาทีเกม',
        meaningTh: '1 นาทีเกม = 1 Tick การจำลองสมรภูมิ'
      });
      if (cs.stats) {
        const s = cs.stats;
        numericDetails.push({
          labelTh: 'จังหวะแก้ทางยุทธวิธี (Tactical Counters)',
          valueTh: 'คุ้มกัน ' + (s.intercepts || 0) + ' · บังวิถี ' + (s.losBlocks || 0) + ' · สกัดเขตคุกคาม ' + (s.zocStrikes || 0) + ' · ขัดจังหวะร่าย ' + (s.interrupts || 0) + ' · เปลี่ยนเป้า ' + (s.targetSwitches || 0),
          meaningTh: 'จำนวนครั้งที่ระบบคำนวณระยะอาวุธและตำแหน่งทำงานจริงในศึกนี้'
        });
      }
    }
    if (snap.factDeltas) {
      for (const [k, v] of Object.entries(snap.factDeltas)) {
        if (v == null || v === '') continue;
        const labelMap = {
          chancePct: ['โอกาสสำเร็จที่คำนวณ ณ เวลานั้น', '%', 'คำนวณจากตบะ รากปราณ โอสถ และสภาพจิตใจขณะตัดสินใจ'],
          targetPct: ['เกณฑ์ความมั่นใจขั้นต่ำของตัวละคร', '%', 'คำนวณจากนิสัยความรอบคอบ (Caution) เทียบความกล้า (Courage)'],
          stonesNow: ['ศิลาวิญญาณคงคลังขณะตัดสินใจ', ' ศิลา', 'ยอดคงเหลือในคลังสำนัก (W.sect.stones) ณ เวลาเกิดเหตุ'],
          cashReserve: ['เกณฑ์สำรองศิลาปลอดภัยขั้นต่ำ', ' ศิลา', 'กันชนงบประมาณที่หอคลังกันไว้สำหรับเบี้ยหวัดและยามฉุกเฉิน'],
          buildCost: ['ค่าก่อสร้าง/ขยายอาคาร', ' ศิลา', 'ต้นทุนศิลาวิญญาณที่ต้องใช้ในการยกระดับอาคาร'],
          neededTotal: ['ยอดศิลาที่ต้องมีรวมกันชนสำรอง', ' ศิลา', 'ค่าก่อสร้าง + เกณฑ์สำรองปลอดภัยขั้นต่ำ'],
          embezzledAmt: ['ยอดศิลาที่ถูกยักยอกสะสม', ' ศิลา', 'จำนวนศิลาที่ผู้ดูแลคลังแอบเบียดบังไปก่อนถูกตรวจพบ'],
          recoveredAmt: ['ยอดศิลาที่ยึดคืนเข้าคลัง', ' ศิลา', 'จำนวนศิลาที่หอวินัยริบคืนเข้าคลังสำนัก (60% ของยอดที่ยักยอก)'],
          meritDelta: ['แต้มผลงานสำนัก (Merit) ที่เปลี่ยน', ' แต้ม', 'ส่งผลต่อการเลื่อนขั้นและสิทธิ์รับการจัดสรรของจากคลัง']
        }[k];
        if (labelMap) {
          numericDetails.push({
            labelTh: labelMap[0],
            valueTh: String(v) + labelMap[1],
            meaningTh: labelMap[2]
          });
        }
      }
    }

    return {
      id: rec.id,
      day: rec.day,
      t: rec.t,
      formatId: fmtId,
      formatNameTh: fmtDef.nameTh,
      formatShortTh: fmtDef.shortTh,
      leadPrefixTh: fmtDef.leadPrefixTh,
      impactLabelTh: fmtDef.impactLabelTh,
      category: rec.category,
      categoryTh: rec.categoryTh,
      severity: sev,
      severityBadge: sevBadge,
      epistemicStatus: snap.epistemicStatus,
      epistemicBadgeTh: rec.verificationStatusTh || snap.certaintyLabelTh,
      isRumor: snap.isRumor,
      isUnread: X.isEntryUnread(W, rec),
      storyThreadId: rec.storyThreadId || null,
      storyThreadTitleTh: rec.storyThreadTitleTh || null,
      headlineTh: (rec.icon || '📜') + ' ' + (rec.titleTh || 'บันทึกเหตุการณ์ยุทธภพ'),
      leadTh: rec.storyTh || rec.titleTh || '',
      turningPointLabelTh,
      turningPointBodyTh,
      impactTh,
      followUpTh,
      numericDetails,
      npcIds: rec.npcIds || [],
      actorSnapshots: rec.actorSnapshots || [],
      digestPayload: rec.digestPayload || null
    };
  };

  /* ---------- Pillar 3: Periodic Sect Digest & Continuing Storyline Threads ---------- */
  X.computePeriodDigest = (W, opts) => {
    if (!W || !W.sect) return null;
    opts = opts || {};
    const windowDays = Math.max(1, Math.min(90, Number(opts.windowDays) || 7));
    const toTick = Number.isFinite(opts.toTick) ? opts.toTick : (W.t || 0);
    const fromTick = Number.isFinite(opts.fromTick) ? opts.fromTick : Math.max(0, toTick - windowDays * 1440);
    const toDay = Math.floor(toTick / 1440);
    const fromDay = Math.floor(fromTick / 1440);

    // 1. Treasury Ledger Analysis (External Stone Income vs Expense — strictly bounded to (fromTick, toTick])
    const ledger = Array.isArray(W.sect.ledger) ? W.sect.ledger : [];
    let stoneIncome = 0, stoneExpense = 0;
    const incByReason = {}, expByReason = {};
    let internalLedgerTransferCount = 0;
    for (let i = 0; i < ledger.length; i++) {
      const tx = ledger[i];
      if (!tx || !Number.isFinite(tx.t) || !Number.isFinite(tx.amt)) continue;
      if (tx.t <= fromTick || tx.t > toTick) continue;
      if (tx.internalTransfer) {
        internalLedgerTransferCount++;
        continue;
      }
      const why = String(tx.why || 'รายการทั่วไป').split(':')[0].trim();
      if (tx.amt > 0) {
        stoneIncome += tx.amt;
        incByReason[why] = (incByReason[why] || 0) + tx.amt;
      } else if (tx.amt < 0) {
        const absAmt = Math.abs(tx.amt);
        stoneExpense += absAmt;
        expByReason[why] = (expByReason[why] || 0) + absAmt;
      }
    }
    stoneIncome = Math.round(stoneIncome);
    stoneExpense = Math.round(stoneExpense);
    const netStones = stoneIncome - stoneExpense;
    const topIncomeReasons = Object.entries(incByReason).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([why, amt]) => ({ why, amt: Math.round(amt) }));
    const topExpenseReasons = Object.entries(expByReason).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([why, amt]) => ({ why, amt: Math.round(amt) }));

    // 2. Stock & Internal Transfers vs Player Interventions (Never mixed with external stone income/expense!)
    const closingStones = Math.round(W.sect.stones || 0);
    const closingMeals = g.ECO ? g.ECO.count(W, 'meal') : 0;
    const closingGrain = g.ECO ? g.ECO.count(W, 'grain') : 0;
    const closingFoodEquiv = closingMeals + closingGrain * 3;
    const aliveNpcs = (W.npcs || []).filter(n => n && !n.dead && !n.exiled);
    const alivePop = Math.max(1, aliveNpcs.length);
    const foodDaysRemaining = +(closingFoodEquiv / Math.max(1, alivePop * 2.2)).toFixed(1);
    const generosity = (W.sect.policy && W.sect.policy.generosity != null) ? W.sect.policy.generosity : 50;
    const cashReserveFloor = Math.max(300, alivePop * 20) + Math.round(alivePop * 10 * (1 - generosity / 200));

    const logs = Array.isArray(W.logs) ? W.logs : [];
    let internalGiftsCount = 0;
    let internalCpPurchasesCount = 0;
    let internalDonationsCount = 0;
    let playerInterventionCount = 0;
    let breakthroughSuccessCount = 0;
    let breakthroughFailCount = 0;
    let deathsInWindow = 0;
    let recruitsInWindow = 0;
    let battlesInWindow = 0;
    let craftsInWindow = 0;
    let craftFailsInWindow = 0;

    const contribScores = {};
    const addContrib = (npcId, pts, featTh) => {
      if (!npcId) return;
      if (!contribScores[npcId]) contribScores[npcId] = { id: npcId, score: 0, feats: [] };
      contribScores[npcId].score += pts;
      if (featTh && !contribScores[npcId].feats.includes(featTh) && contribScores[npcId].feats.length < 3) {
        contribScores[npcId].feats.push(featTh);
      }
    };

    for (let i = 0; i < logs.length; i++) {
      const l = logs[i];
      if (!l || !Number.isFinite(l.t) || l.t <= fromTick || l.t > toTick) continue;
      const txKind = l.txKind || (l.meta && l.meta.txKind) || null;
      const txt = String(l.text || '');
      const primaryId = Array.isArray(l.ids) && l.ids[0] ? l.ids[0] : null;

      if (txKind === 'player-spawn' || txKind === 'player-edit' || txKind === 'player-edit-undo' || txt.includes('[เสกโดยผู้เล่น]') || txt.includes('[แก้ไขโดยผู้เล่น]')) {
        playerInterventionCount++;
        continue;
      }
      if (txKind === 'gift' || txt.includes('[มอบของรางวัล]')) {
        internalGiftsCount++;
      } else if (txKind === 'purchase' && (l.type === 'shop' || l.type === 'gear' || txt.includes('แลกคุณูปการ'))) {
        internalCpPurchasesCount++;
      } else if (txKind === 'donation' || (l.type === 'economy' && txt.includes('บริจาค'))) {
        internalDonationsCount++;
        if (primaryId) addContrib(primaryId, 2, 'บริจาคพัสดุเข้าคลังสำนัก');
      }

      if (l.type === 'breakthrough') {
        if (/สำเร็จ/.test(txt)) {
          breakthroughSuccessCount++;
          if (primaryId) addContrib(primaryId, 8, txt.replace(/^[^\s]+\s+/, ''));
        } else if (/ล้มเหลว/.test(txt)) {
          breakthroughFailCount++;
        }
      } else if (l.type === 'death') {
        deathsInWindow++;
      } else if (l.type === 'recruit' && /ผ่านการพิจารณา|เข้าสำนักเป็นศิษย์|ตามคณะสำรวจมาเข้าสำนัก/.test(txt)) {
        recruitsInWindow++;
      } else if (l.type === 'raid' || l.type === 'duel' || l.type === 'tournament') {
        if (/ต้านการบุก|ชนะเลิศ|กำลังสำคัญในการป้องกัน/.test(txt)) {
          battlesInWindow++;
          if (primaryId) addContrib(primaryId, 7, txt);
        }
      } else if (l.type === 'craft') {
        if (/ล้มเหลว/.test(txt)) {
          craftFailsInWindow++;
        } else if (/สำเร็จ|คุณภาพชั้นเลิศ/.test(txt)) {
          craftsInWindow++;
          if (primaryId) addContrib(primaryId, /คุณภาพชั้นเลิศ/.test(txt) ? 5 : 2, /คุณภาพชั้นเลิศ/.test(txt) ? 'สร้างผลงานคุณภาพชั้นเลิศ' : 'ผลิตพัสดุเข้าคลังสำนัก');
        }
      } else if ((l.type === 'mission' || l.type === 'explore') && /กลับจาก|สำเร็จ|พิชิต|ได้ของวิเศษ/.test(txt)) {
        if (primaryId) addContrib(primaryId, 5, 'นำคณะสำรวจ/ภารกิจสำเร็จ');
      }
    }

    const topContributors = Object.values(contribScores)
      .sort((a, b) => b.score - a.score)
      .slice(0, 4)
      .map(c => {
        const n = W.byId && W.byId[c.id];
        const hp = W.sect.historicalPeople && W.sect.historicalPeople[c.id];
        const fullName = n ? g.HC.fullName(n) : (hp ? hp.fullName : c.id);
        const roleTh = (n && g.SECT && g.SECT.title) ? g.SECT.title(n) : (hp ? hp.roleTh : 'สมาชิกสำนัก');
        return {
          id: c.id,
          fullName,
          roleTh,
          score: c.score,
          featsTh: c.feats.join(' · ') || 'ปฏิบัติหน้าที่สม่ำเสมอ'
        };
      });

    // 3. Troubled Disciples (Injured, Bottlenecked, High Heart Demon, Detained, or Emergency Goal Suspension)
    const troubledDisciples = [];
    for (let i = 0; i < aliveNpcs.length; i++) {
      const n = aliveNpcs[i];
      const issues = [];
      let urgency = 0;
      if (Array.isArray(n.inj) && n.inj.length > 0) {
        const maxSev = Math.max(...n.inj.map(x => x.sev || 1));
        issues.push('บาดเจ็บ ' + n.inj.length + ' จุด (' + (n.inj[0].part || n.inj[0].why || ('ระดับ ' + maxSev)) + ')');
        urgency += maxSev * 4;
      }
      const hd = (n.h && n.h.state && n.h.state.heartDemon) || 0;
      if (hd >= 55) {
        issues.push('มารในใจสูง (' + Math.round(hd) + '%)');
        urgency += 5;
      }
      if (n.cult && n.cult.bn) {
        issues.push('ติดคอขวด ' + (g.CULT && g.CULT.stageName ? g.CULT.stageName(n) : ('ขั้น ' + n.cult.stage)) + ' (' + (n.cult.bn.why || 'รอโอกาสทะลวง') + ')');
        urgency += 4;
      }
      if (n.cognition && n.cognition.suspendedGoal && n.cognition.goal && n.cognition.goal.id === 'recovery') {
        issues.push('พักเป้าหมาย「' + (n.cognition.suspendedGoal.title || n.cognition.suspendedGoal.id) + '」ชั่วคราวเพื่อฟื้นฟูร่างกาย');
        urgency += 3;
      }
      if (n.jail && n.jail > toTick) {
        issues.push('ถูกคุมขังตามวินัยสำนัก');
        urgency += 3;
      }
      if (urgency > 0) {
        troubledDisciples.push({
          id: n.id,
          fullName: g.HC.fullName(n),
          roleTh: (g.SECT && g.SECT.title) ? g.SECT.title(n) : 'ศิษย์สำนัก',
          urgency,
          issuesTh: issues.join(' · ')
        });
      }
    }
    troubledDisciples.sort((a, b) => b.urgency - a.urgency);

    // 4. Verified Active Risks & Pending Follow-Ups
    const verifiedRisks = [];
    if (W.threat && W.threat.raid) {
      verifiedRisks.push({
        severity: 'CRITICAL',
        titleTh: 'ข้าศึกกำลังบุกประชิดสำนัก',
        detailTh: 'ตรวจพบภัยคุกคามหน้าด่าน ควรตรวจสอบแนวป้องกันและอสูรเฝ้าประตูทันที'
      });
    }
    if (foodDaysRemaining < 7) {
      verifiedRisks.push({
        severity: foodDaysRemaining < 3 ? 'CRITICAL' : 'MAJOR',
        titleTh: 'เสบียงสำรองต่ำกว่าเกณฑ์ 7 วัน (เหลือราว ' + foodDaysRemaining + ' วัน)',
        detailTh: 'มีอาหารปรุงสุก ' + closingMeals + ' ชุด และข้าวสาร ' + closingGrain + ' กระสอบ สำหรับสมาชิก ' + alivePop + ' คน'
      });
    }
    if (closingStones < cashReserveFloor) {
      verifiedRisks.push({
        severity: closingStones < cashReserveFloor * 0.5 ? 'CRITICAL' : 'MAJOR',
        titleTh: 'ศิลาคงคลัง (' + closingStones + ') ต่ำกว่าเกณฑ์กันชนปลอดภัย (' + cashReserveFloor + ' ศิลา)',
        detailTh: 'หอคลังจะชะลอการขยายอาคารและการสั่งซื้อสินค้าที่ไม่จำเป็นโดยอัตโนมัติ'
      });
    }
    const shortages = (W.sect && Array.isArray(W.sect.shortageDirectives)) ? W.sect.shortageDirectives.filter(d => d && d.deficit > 0) : [];
    if (shortages.length > 0) {
      const topShort = shortages.slice(0, 3).map(d => (g.ECO ? g.ECO.name(d.id) : d.id) + ' (ขาด ' + d.deficit + ')').join(', ');
      verifiedRisks.push({
        severity: 'NOTABLE',
        titleTh: 'พัสดุขาดแคลนตามคำสั่งหอคลัง (' + shortages.length + ' รายการ)',
        detailTh: topShort
      });
    }
    if (troubledDisciples.length > 0) {
      verifiedRisks.push({
        severity: troubledDisciples[0].urgency >= 6 ? 'MAJOR' : 'NOTABLE',
        titleTh: 'มีศิษย์บาดเจ็บ/ติดคอขวด/มารในใจสูง ' + troubledDisciples.length + ' คน',
        detailTh: troubledDisciples.slice(0, 2).map(d => d.fullName + ' (' + d.issuesTh + ')').join(' · ')
      });
    }

    // 5. Compute the 28 Untapped Simulation Metrics (14A Section 2 — 100% Deterministic, Zero W.rng)
    const calNow = (g.SIM && g.SIM.calendar) ? g.SIM.calendar(toTick) : { season: 0, year: 1 };
    const dyingLampElders = aliveNpcs.filter(n => {
      const age = (g.HC && g.HC.ageYears) ? g.HC.ageYears(n) : 20;
      const maxL = n.lifespanMax || (g.CULT && g.CULT.lifespan ? g.CULT.lifespan(n) : 80);
      return maxL > 0 && (age / maxL) >= 0.88;
    });
    const bottleneckedNpcs = aliveNpcs.filter(n => n.cult && n.cult.bn);
    const qiDeviationRiskNpcs = aliveNpcs.filter(n => ((n.h && n.h.state && n.h.state.heartDemon) || 0) >= 65 || ((n.cult && n.cult.toxic) || 0) >= 35 || ((n.forbiddenArtState && n.forbiddenArtState.tabooStrain) || 0) >= 60);
    const suspendedGoalNpcs = aliveNpcs.filter(n => n.cognition && n.cognition.suspendedGoal);
    const facDem = (W.sect && W.sect.facilityDemand) || {};
    let topCongestedId = null, topCongestedHours = 0, topUnmet = 0;
    Object.entries(facDem).forEach(([bid, fd]) => {
      const ch = (fd && fd.congestedHours) || 0;
      if (ch > topCongestedHours) { topCongestedHours = ch; topCongestedId = bid; topUnmet = (fd && fd.unmetDemands) || 0; }
    });
    const bedlessCount = aliveNpcs.filter(n => !n.away && n.bed == null).length;
    const cpPriceMult = +((W.sect && W.sect.cp && W.sect.cp.price) || 1.0).toFixed(2);
    const personalStonesArr = aliveNpcs.map(n => (n.inv && n.inv.stones) || 0).sort((a, b) => b - a);
    const richestStones = personalStonesArr[0] || 0;
    const needSum = (g.ECO && g.ECO.needSummary) ? g.ECO.needSummary(W) : { noWeapon: 0, noArmor: 0 };
    let topRelicKills = 0, topRelicName = 'ยังไม่มีศาสตราดื่มโลหิต';
    aliveNpcs.forEach(n => {
      const wpn = n.equip && n.equip.WEAPON;
      if (wpn && (wpn.kills || 0) > topRelicKills) { topRelicKills = wpn.kills; topRelicName = wpn.nameTh || wpn.id; }
    });
    const pathCounts = {};
    aliveNpcs.forEach(n => { const p = (n.cult && n.cult.path) || 'MORTAL'; pathCounts[p] = (pathCounts[p] || 0) + 1; });
    const dominantPathEntry = Object.entries(pathCounts).sort((a, b) => b[1] - a[1])[0] || ['XIAN', 0];
    const mentorCount = aliveNpcs.filter(n => Array.isArray(n.apprenticeIds) && n.apprenticeIds.length > 0).length;
    let romancePairs = 0, feudPairs = 0;
    aliveNpcs.forEach(n => {
      const rels = (n.h && n.h.mind && n.h.mind.relations) || {};
      Object.entries(rels).forEach(([oid, r]) => {
        if (n.id < oid && r) {
          if ((r.l || 0) >= 45 || r.bond === 'คนรัก' || r.bond === 'คู่ครอง' || r.bond === 'TAOIST_COMPANION') romancePairs++;
          if ((r.a || 0) < -30 && (r.v || 0) > 40) feudPairs++;
        }
      });
    });
    const cliqueCount = (W.sect && W.sect.cliques && Object.keys(W.sect.cliques).length) || 4;
    const suspicionVal = Math.round((W.sect && W.sect.suspicion) || 0);
    const petitionsCount = (W.sect && Array.isArray(W.sect.petitions) && W.sect.petitions.length) || 0;
    const peaksCount = (W.sect && W.sect.peaks && Object.keys(W.sect.peaks).length) || 8;
    const fsScore = (W.sect && W.sect.fengShui && W.sect.fengShui.sectAverageScore) || 68;
    const reservePetsCount = (W.sect && Array.isArray(W.sect.reservePets) && W.sect.reservePets.length) || 0;
    const worldSects = (W.world && Array.isArray(W.world.sects)) ? W.world.sects : [];
    const hostileSectsCount = worldSects.filter(s => s && (s.relation || 0) <= -35).length;
    const worldPoolStones = Math.round((W.world && W.world.resourcePool && W.world.resourcePool.stones) || 50000);
    const pagodaFloorMax = (W.sect && W.sect.pagoda && W.sect.pagoda.highestFloorCleared) || (W.explore && W.explore.maxPagodaFloor) || 1;
    const vowKeepersCount = aliveNpcs.filter(n => (Array.isArray(n.voluntaryVows) && n.voluntaryVows.length > 0) || n.daoOath).length;

    const metrics28 = {
      M01_famineRunwayDays: foodDaysRemaining,
      M02_dyingLampEldersCount: dyingLampElders.length,
      M03_bottleneckStalledCount: bottleneckedNpcs.length,
      M04_qiDeviationRiskCount: qiDeviationRiskNpcs.length,
      M05_suspendedGoalsCount: suspendedGoalNpcs.length,
      M06_topCongestedHall: { buildingId: topCongestedId, congestedHours: topCongestedHours, unmetDemands: topUnmet },
      M07_bedlessDisciplesCount: bedlessCount,
      M08_cpInflationMult: cpPriceMult,
      M09_topPersonalStones: richestStones,
      M10_cashReserveGap: closingStones - cashReserveFloor,
      M11_workshopCraftSummary: { crafted: craftsInWindow, failed: craftFailsInWindow },
      M12_unarmedDisciplesCount: needSum.noWeapon || 0,
      M13_topBloodiedWeapon: { nameTh: topRelicName, kills: topRelicKills },
      M14_dominantPath: { pathId: dominantPathEntry[0], count: dominantPathEntry[1] },
      M15_activeMentorsCount: mentorCount,
      M16_buddingRomancesCount: romancePairs,
      M17_festeringFeudsCount: feudPairs,
      M18_elderCliquesCount: cliqueCount,
      M19_corruptionAndPetitions: { suspicion: suspicionVal, petitions: petitionsCount },
      M20_sacredPeaksActive: peaksCount,
      M21_fengShuiScore: fsScore,
      M22_orphanedSpiritBeasts: reservePetsCount,
      M23_sectFame: Math.round(W.sect.fame || 0),
      M24_hostileRivalSects: hostileSectsCount,
      M25_worldStonePoolRemaining: worldPoolStones,
      M26_pagodaFrontierFloor: pagodaFloorMax,
      M27_battlesWonInWindow: battlesInWindow,
      M28_vowKeepersCount: vowKeepersCount
    };

    // 6. Build the 6 Officer-Voiced Court Memorial Sections (สมุดฎีกาถวายรายงานหกหอ — 14A Section 3)
    const buildOfficerHeader = (postId, fallbackPostNameTh) => {
      const holder = (g.SECT && g.SECT.holder) ? g.SECT.holder(W, postId) : null;
      const pNameTh = (g.SECT && g.SECT.POSTS && g.SECT.POSTS[postId] && g.SECT.POSTS[postId].nameTh) || fallbackPostNameTh;
      if (!holder) {
        return {
          postId,
          postNameTh: pNameTh,
          officerId: null,
          officerNameTh: 'เสมียนเวรประจำหอ',
          headerTh: 'บันทึกชั่วคราวโดยเสมียนเวร (ตำแหน่ง ' + pNameTh + ' ยังว่างเว้นผู้ดูแล)',
          tone: 'CLERK'
        };
      }
      const full = (g.HC && g.HC.fullName) ? g.HC.fullName(holder) : holder.h.name.given;
      const p = (holder.h && holder.h.personality) || {};
      const integrity = p.integrity != null ? p.integrity : 50;
      const caution = p.caution != null ? p.caution : 50;
      const ambition = p.ambition != null ? p.ambition : 50;
      const aggression = p.aggression != null ? p.aggression : 50;
      const tone = (integrity < 42 && (holder.embezzled || 0) > 0) ? 'CORRUPT_SMOOTH'
        : (caution >= 65 ? 'CAUTIOUS'
        : ((ambition >= 65 || aggression >= 65) ? 'BOLD' : 'BALANCED'));
      return {
        postId,
        postNameTh: pNameTh,
        officerId: holder.id,
        officerNameTh: full,
        headerTh: 'ฎีกาจาก ' + pNameTh + ' · ' + full,
        tone
      };
    };

    const treOff = buildOfficerHeader('treasury', 'เจ้าหอคลังและบรรณาการ');
    const cultOff = buildOfficerHeader('scripture', 'เจ้าหอคัมภีร์');
    const marOff = buildOfficerHeader('martial', 'เจ้าหอยุทธ์');
    const crfOff = buildOfficerHeader('alchemy', 'เจ้าหอปรุงโอสถ');
    const govOff = buildOfficerHeader('discipline', 'ผู้คุมกฎหอวินัย');
    const dipOff = buildOfficerHeader('diplomat', 'ทูตยุทธภพ');

    const netSignStr = netStones >= 0 ? ('+' + netStones) : String(netStones);
    const winterWarn = calNow.season === 2 ? ' อนึ่ง อีกไม่นานจะย่างเข้าสู่เหมันตฤดูที่นาข้าวชะงักงัน สมควรสำรองเสบียงไว้แต่เนิ่นๆ' : '';
    const treClosingLine = treOff.tone === 'CORRUPT_SMOOTH'
      ? 'บัญชีคลังหลวงเรียบร้อยร่มเย็นเป็นสุข มิมีสิ่งใดน่ากังวลขอรับ'
      : (treOff.tone === 'CAUTIOUS'
        ? ('สมควรรักษากันชนสำรอง ' + cashReserveFloor + ' ก้อนไว้อย่างเคร่งครัดเพื่อรับมือเหตุฉุกเฉิน' + winterWarn)
        : ('ดุลการค้าหมุนเวียนคล่องตัว พร้อมหนุนการเติบโตของสำนักในรอบหน้า' + winterWarn));

    const memorialSections = [
      {
        id: 'TREASURY',
        icon: '💰',
        titleTh: 'ฎีกาหอคลังและยุ้งฉาง',
        headerTh: treOff.headerTh,
        officerId: treOff.officerId,
        tone: treOff.tone,
        bodyTh: 'ในรอบ ' + windowDays + ' วันที่ผ่านมา รายรับศิลาวิญญาณจากภายนอก +' + stoneIncome + ' ก้อน หักรายจ่าย -' + stoneExpense + ' ก้อน คงเหลือสุทธิ ' + netSignStr + ' ก้อน (ยอดคลังหลวงรวม ' + closingStones + ' ก้อน · หมุนเวียนภายในผ่านการแลกแต้มคุณูปการ ' + internalCpPurchasesCount + ' รายการ และศิษย์ส่งของเข้าคลัง ' + internalDonationsCount + ' รายการ) ส่วนยุ้งฉางมีเสบียงพอเลี้ยงดูสมาชิกทั้ง ' + alivePop + ' ชีวิตไปได้อีกราว ' + foodDaysRemaining + ' วัน — ' + treClosingLine
      },
      {
        id: 'CULTIVATION',
        icon: '🕯️',
        titleTh: 'ฎีกาหอบำเพ็ญและชะตาชีวิต',
        headerTh: cultOff.headerTh,
        officerId: cultOff.officerId,
        tone: cultOff.tone,
        bodyTh: 'เวลานี้มีศิษย์ติดคอขวดด่านใหญ่รอวันฝ่าทัณฑ์สวรรค์ ' + bottleneckedNpcs.length + ' คน (ทะลวงสำเร็จในรอบนี้ ' + breakthroughSuccessCount + ' ครั้ง / พลาด ' + breakthroughFailCount + ' ครั้ง) ' +
          (dyingLampElders.length > 0 ? ('อนึ่ง ตะเกียงอายุขัยของ ' + dyingLampElders.slice(0, 2).map(e => g.HC.fullName(e)).join(', ') + ' เหลือเวลาชีวิตน้อยกว่า 12% กำลังเร่งหาทางทะลวงขั้นต่อชะตาหรือสั่งเสียผู้สืบทอด ') : 'ผู้ฝึกตนอาวุโสยังมีปราณอายุขัยมั่นคง ') +
          (topCongestedHours > 0 ? ('ส่วนความแออัด อาคาร ' + topCongestedId + ' มีผู้แย่งเบาะนั่งเต็มพิกัดรวม ' + topCongestedHours + ' ชั่วยาม') : 'เบาะนั่งบำเพ็ญและหอคัมภีร์ยังรองรับศิษย์ได้เพียงพอ')
      },
      {
        id: 'MARTIAL',
        icon: '⚔️',
        titleTh: 'ฎีกาหอยุทธ์และคลังแสง',
        headerTh: marOff.headerTh,
        officerId: marOff.officerId,
        tone: marOff.tone,
        bodyTh: 'ในรอบนี้เกิดศึกปะทะสำคัญ ' + battlesInWindow + ' ครั้ง · ศิษย์ไร้ศาสตราคู่กายต้องออกศึกมือเปล่า ' + (needSum.noWeapon || 0) + ' คน และไร้เสื้อเกราะ ' + (needSum.noArmor || 0) + ' คน · ศาสตราที่ดื่มโลหิตสูงสุดคือ「' + topRelicName + '」(' + topRelicKills + ' ศพ) ' +
          (feudPairs > 0 ? ('ด้านคลื่นใต้น้ำในลานฝึก มีคู่ศิษย์บาดหมางรุนแรง ' + feudPairs + ' คู่ ที่เสี่ยงชักดาบดวลสะสางแค้น') : 'ระเบียบวินัยในลานฝึกยุทธ์ยังเรียบร้อยดี')
      },
      {
        id: 'CRAFT',
        icon: '⚗️',
        titleTh: 'ฎีกาหอโอสถและโรงหลอม',
        headerTh: crfOff.headerTh,
        officerId: crfOff.officerId,
        tone: crfOff.tone,
        bodyTh: 'เตาหลอมโอสถและทั่งตีเหล็กผลิตผลงานสำเร็จเข้าคลัง ' + craftsInWindow + ' ชิ้น และเกิดเหตุไฟปราณสะดุดสูญเสียวัตถุดิบ ' + craftFailsInWindow + ' ครั้ง · ดัชนีค่าครองชีพแต้มคุณูปการปัจจุบันอยู่ที่ ×' + cpPriceMult + ' · ' +
          (shortages.length > 0 ? ('มีรายการพัสดุขาดแคลนเร่งด่วน ' + shortages.length + ' รายการที่ศิษย์สายผลิตกำลังเร่งมือ') : 'วัตถุดิบหลักในคลังยังหมุนเวียนได้ตามปกติ')
      },
      {
        id: 'GOVERNANCE',
        icon: '⚖️',
        titleTh: 'ฎีกาโถงสภาและหอวินัย',
        headerTh: govOff.headerTh,
        officerId: govOff.officerId,
        tone: govOff.tone,
        bodyTh: 'ศิษย์ที่ต้องพับปณิธานชั่วคราวเพื่อรักษาชีวิตมี ' + suspendedGoalNpcs.length + ' คน · ศิษย์ไร้เตียงประจำต้องนอนตากน้ำค้าง ' + bedlessCount + ' คน · ศิษย์ที่มารในใจหรือพิษโอสถสะสมสูงมี ' + qiDeviationRiskNpcs.length + ' คน · ระดับพิรุธทางบัญชีคลังอยู่ที่ ' + suspicionVal + '/100 และมีฎีการ้องทุกข์ค้างพิจารณา ' + petitionsCount + ' ฉบับ'
      },
      {
        id: 'DIPLOMACY',
        icon: '🌏',
        titleTh: 'ฎีกาหอทูตและสำรวจยุทธภพ',
        headerTh: dipOff.headerTh,
        officerId: dipOff.officerId,
        tone: dipOff.tone,
        bodyTh: 'บารมีสำนักในยุทธภพอยู่ที่ ' + Math.round(W.sect.fame || 0) + ' แต้ม · มีสำนักต่างแดนตั้งตนเป็นอริ ' + hostileSectsCount + '/' + worldSects.length + ' สำนัก · ชีพจรแร่ศิลาปราณทั่วแผ่นดินคงเหลือ ' + worldPoolStones + ' ก้อน · สถิติบุกเบิกมหาเจดีย์ 43 วิถีไปถึงชั้นที่ ' + pagodaFloorMax
      }
    ];

    return {
      periodKey: 'digest:' + fromDay + ':' + toDay + ':' + windowDays,
      windowDays,
      fromTick,
      toTick,
      fromDay,
      toDay,
      periodLabelTh: 'รอบ ' + windowDays + ' วัน (วันที่ ' + fromDay + ' – วันที่ ' + toDay + ')',
      treasury: {
        closingStones,
        cashReserveFloor,
        stoneIncome,
        stoneExpense,
        netStones,
        topIncomeReasons,
        topExpenseReasons
      },
      stockAndInternal: {
        closingMeals,
        closingGrain,
        closingFoodEquiv,
        foodDaysRemaining,
        internalGiftsCount,
        internalCpPurchasesCount,
        internalDonationsCount,
        playerInterventionCount
      },
      activity: {
        alivePop,
        breakthroughSuccessCount,
        breakthroughFailCount,
        deathsInWindow,
        recruitsInWindow,
        battlesInWindow,
        craftsInWindow,
        craftFailsInWindow
      },
      topContributors,
      troubledDisciples: troubledDisciples.slice(0, 5),
      verifiedRisks,
      metrics28,
      memorialSections
    };
  };

  X.recordPeriodicDigest = (W, opts) => {
    if (!W || !W.sect) return null;
    opts = opts || {};
    X.ensureNewsSystem(W);
    const d = X.computePeriodDigest(W, opts);
    if (!d) return null;
    const existing = W.sect.digestHistory.find(x => x && x.periodKey === d.periodKey);
    if (existing && !opts.force) return existing;

    W.sect.digestHistory.unshift(d);
    if (W.sect.digestHistory.length > 24) W.sect.digestHistory.length = 24;

    if (opts.alsoRecordChronicle !== false) {
      const netSign = d.treasury.netStones >= 0 ? ('+' + d.treasury.netStones) : String(d.treasury.netStones);
      const contribTxt = d.topContributors.length
        ? ('ผู้ทำผลงานเด่น: ' + d.topContributors.slice(0, 2).map(c => c.fullName + ' (' + c.featsTh + ')').join(' · '))
        : 'ยังไม่มีหมุดหมายผลงานใหญ่ในรอบนี้';
      const riskTxt = d.verifiedRisks.length
        ? ('ข้อควรระวัง: ' + d.verifiedRisks.map(r => r.titleTh).join(' · '))
        : 'สถานะคลังและเสบียงอยู่ในเกณฑ์ปกติ';
      X.recordChronicle(W, {
        eventKey: d.periodKey,
        category: 'PERIODIC_DIGEST',
        reportFormat: 'PERIODIC_SECT_DIGEST',
        icon: '📊',
        titleTh: 'สมุดสรุปสถานการณ์สำนัก (' + d.periodLabelTh + ')',
        storyTh: 'คงคลังศิลา ' + d.treasury.closingStones + ' ก้อน (รายรับ +' + d.treasury.stoneIncome + ' / รายจ่าย -' + d.treasury.stoneExpense + ' / สุทธิ ' + netSign + ' ศิลา) · เสบียงพอใช้ราว ' + d.stockAndInternal.foodDaysRemaining + ' วัน · ' + contribTxt,
        originCauseTh: 'ประมวลผลจากสมุดบัญชีคลัง (แยกจากการโอนภายใน ' + (d.stockAndInternal.internalGiftsCount + d.stockAndInternal.internalCpPurchasesCount + d.stockAndInternal.internalDonationsCount) + ' รายการ) และเหตุการณ์จริงใน ' + d.periodLabelTh,
        consequenceTh: riskTxt,
        followUpTh: d.troubledDisciples.length ? ('หอหมอยาและผู้อาวุโสกำลังประคองอาการของ ' + d.troubledDisciples.slice(0, 2).map(t => t.fullName).join(', ') + ' อย่างใกล้ชิด') : 'ขุนนางทั้งหกหอดำเนินการจัดสรรทรัพยากรและแผนการฝึกตามปกติ',
        npcIds: d.topContributors.map(c => c.id).concat(d.troubledDisciples.map(t => t.id)).slice(0, 4),
        digestPayload: d,
        severity: d.verifiedRisks.some(r => r.severity === 'CRITICAL') ? 'CRITICAL' : (d.verifiedRisks.length ? 'MAJOR' : 'NOTABLE'),
        quiet: true
      });
    }
    return d;
  };

  X.dailyChronicleDigestTick = W => {
    if (!W || !W.sect || W._founding) return;
    const np = X.ensureNewsPrefs(W);
    const interval = np.digestIntervalDays || 0;
    if (interval <= 0 || !W.day || W.day <= 0) return;
    if (W.day % interval === 0) {
      X.recordPeriodicDigest(W, { windowDays: interval, alsoRecordChronicle: true });
    }
  };

  /* Group continuing storylines across world.chronicles & sect.sectChronicle (Deterministic, Never Guessed) */
  X.getStoryThreads = (W, filterThreadId) => {
    if (!W || !W.sect) return [];
    const byThread = {};
    const addEvent = (id, titleTh, ev) => {
      if (!id) return;
      if (!byThread[id]) {
        byThread[id] = {
          threadId: id,
          titleTh: titleTh || id,
          events: [],
          npcIds: new Set()
        };
      }
      if (titleTh && (byThread[id].titleTh === id || byThread[id].titleTh.startsWith('เส้นเรื่อง:'))) {
        byThread[id].titleTh = titleTh;
      }
      if (!byThread[id].events.some(x => x.eventKey === ev.eventKey && Math.abs((x.t || 0) - (ev.t || 0)) <= 5)) {
        byThread[id].events.push(ev);
      }
      (ev.npcIds || []).forEach(nid => { if (nid) byThread[id].npcIds.add(nid); });
    };

    const chrons = (W.world && Array.isArray(W.world.chronicles)) ? W.world.chronicles : [];
    for (let i = 0; i < chrons.length; i++) {
      const c = chrons[i];
      if (!c || !c.storyThreadId) continue;
      addEvent(c.storyThreadId, c.storyThreadTitleTh, {
        id: c.id,
        eventKey: c.eventKey || c.id,
        t: c.t || 0,
        day: c.day || 0,
        source: 'world',
        headlineTh: (c.icon || '📜') + ' ' + c.titleTh,
        summaryTh: c.storyTh || c.consequenceTh || '',
        originCauseTh: c.originCauseTh || '',
        consequenceTh: c.consequenceTh || '',
        followUpTh: c.followUpTh || '',
        npcIds: c.npcIds || []
      });
    }

    const sChrons = (W.sect && Array.isArray(W.sect.sectChronicle)) ? W.sect.sectChronicle : [];
    for (let i = 0; i < sChrons.length; i++) {
      const sc = sChrons[i];
      if (!sc || !sc.storyThreadId) continue;
      addEvent(sc.storyThreadId, sc.storyThreadTitleTh, {
        id: sc.id,
        eventKey: sc.eventKey || ('sc:' + sc.id),
        t: sc.t || 0,
        day: sc.day != null ? sc.day : Math.floor((sc.t || 0) / 1440),
        source: 'sect',
        headlineTh: sc.text,
        summaryTh: sc.consequenceTh || sc.text,
        originCauseTh: sc.originCauseTh || '',
        consequenceTh: sc.consequenceTh || '',
        followUpTh: sc.followUpTh || '',
        npcIds: sc.ids || []
      });
    }

    const threads = Object.values(byThread).map(th => {
      th.events.sort((a, b) => (a.t || 0) - (b.t || 0));
      const firstEv = th.events[0];
      const lastEv = th.events[th.events.length - 1];
      const midEv = th.events.length > 2 ? th.events[Math.floor(th.events.length / 2)] : null;
      const isResolved = /สำเร็จ|คลี่คลาย|ขึ้นเป็นเจ้าสำนัก|ยึดศิลา|เสร็จสมบูรณ์|ถึงแก่ชีวิต/.test(lastEv.headlineTh + ' ' + lastEv.consequenceTh);
      return {
        threadId: th.threadId,
        titleTh: th.titleTh,
        eventCount: th.events.length,
        firstDay: firstEv ? firstEv.day : 0,
        lastDay: lastEv ? lastEv.day : 0,
        lastTick: lastEv ? lastEv.t : 0,
        statusTh: isResolved ? '✅ คลี่คลายแล้ว' : '⏳ กำลังดำเนินอยู่ / รอติดตามผล',
        originEvent: firstEv,
        turningPointEvent: midEv,
        latestEvent: lastEv,
        followUpTh: (lastEv && lastEv.followUpTh) || 'ติดตามความคืบหน้าในบันทึกเหตุการณ์',
        npcIds: Array.from(th.npcIds),
        events: th.events
      };
    }).sort((a, b) => (b.lastTick - a.lastTick) || (b.eventCount - a.eventCount));

    if (filterThreadId && filterThreadId !== 'all') {
      return threads.filter(t => t.threadId === filterThreadId);
    }
    return threads;
  };

  X.generateProceduralSectFigure = (W, sectOrId, role, opts) => {
    opts = opts || {};
    const s = typeof sectOrId === 'object' && sectOrId ? sectOrId : X.findSect(W, sectOrId);
    if (!s) return null;
    W.world.figureSeq = (W.world.figureSeq || 0) + 1;
    const seq = opts.seq != null ? opts.seq : W.world.figureSeq;
    const rng = opts.rng || makeChildRng(W, (s.canonicalId || s.id) + ':' + role + ':' + seq + ':' + (W.day || 360));

    const tierLv = s.tierLevel || 2;
    const masterBaseStage = clamp(tierLv + 2, 3, 8);
    const roleStage = opts.stage != null
      ? opts.stage
      : role === 'master'
      ? masterBaseStage
      : role === 'ancestor'
      ? Math.min(9, masterBaseStage + 1)
      : (role === 'deputy' || role === 'disciplineElder' || role === 'craftElder' || role === 'warMarshal')
      ? Math.max(3, masterBaseStage - 1)
      : Math.max(2, masterBaseStage - 2); // successor / coreDisciple

    const ageYears = opts.ageYears != null
      ? opts.ageYears
      : role === 'ancestor'
      ? rng.int(72, 118)
      : role === 'master'
      ? rng.int(42, 74)
      : role === 'deputy'
      ? rng.int(36, 66)
      : (role === 'disciplineElder' || role === 'craftElder' || role === 'warMarshal')
      ? rng.int(38, 68)
      : rng.int(19, 32); // young prodigy / designated successor / coreDisciple

    const rank = role === 'master' ? 6 : (role === 'ancestor' || role === 'deputy') ? 5 : (role === 'disciplineElder' || role === 'craftElder' || role === 'warMarshal') ? 4 : 3;
    const figId = 'JHFIG_' + (s.canonicalId || s.id) + '_' + role.toUpperCase() + '_' + seq;
    const sex = rng.chance(0.62) ? 'M' : 'F';
    const h = generateFastFigureCore(rng, sex);

    // Alignment personality shaping (while preserving rich individual variation!)
    if (s.alignment === 'DEMONIC' && rng.chance(0.65)) {
      h.personality.aggression = clamp((h.personality.aggression || 50) + rng.int(8, 22), 20, 98);
      h.personality.ambition = clamp((h.personality.ambition || 50) + rng.int(8, 22), 20, 98);
    } else if (s.alignment === 'RIGHTEOUS' && rng.chance(0.65)) {
      h.personality.integrity = clamp((h.personality.integrity || 50) + rng.int(6, 18), 20, 98);
      h.personality.discipline = clamp((h.personality.discipline || 50) + rng.int(6, 18), 20, 98);
    }
    if (role === 'disciplineElder') {
      h.personality.integrity = clamp((h.personality.integrity || 50) + rng.int(18, 32), 68, 98);
      h.personality.aggression = clamp((h.personality.aggression || 50) + rng.int(16, 30), 65, 98);
      h.personality.discipline = clamp((h.personality.discipline || 50) + rng.int(18, 32), 70, 98);
    } else if (role === 'craftElder') {
      h.values.knowledgeCraft = clamp((h.values.knowledgeCraft || 50) + rng.int(20, 35), 72, 98);
      h.intellect.comprehension = clamp((h.intellect.comprehension || 50) + rng.int(18, 30), 70, 98);
      h.skills.ALCHEMY = clamp(rng.int(74, 96), 70, 99);
      h.skills.FORGING = clamp(rng.int(72, 95), 68, 99);
    } else if (role === 'warMarshal') {
      h.personality.aggression = clamp((h.personality.aggression || 50) + rng.int(18, 32), 68, 98);
      h.personality.courage = clamp((h.personality.courage || 50) + rng.int(18, 32), 70, 98);
      h.social.leadership = clamp((h.social.leadership || 50) + rng.int(16, 28), 66, 98);
    }

    const isEclectic = s.doctrineMode === 'ECLECTIC';
    const pathPool = (isEclectic && Array.isArray(s.allowedPaths) && s.allowedPaths.length)
      ? s.allowedPaths
      : [s.majorPath || 'XIAN'];
    const chosenPath = opts.path || rng.pick(pathPool) || 'XIAN';

    let subPool = Array.isArray(s.signatureSubs) && s.signatureSubs.length ? s.signatureSubs.slice() : [];
    if (isEclectic && CULT && CULT.PATHS && CULT.PATHS[chosenPath] && Array.isArray(CULT.PATHS[chosenPath].subPaths)) {
      const pSubs = CULT.PATHS[chosenPath].subPaths.map(sp => sp.id);
      if (pSubs.length) subPool = pSubs;
    }
    const chosenSub = opts.sub || (subPool.length ? rng.pick(subPool) : 'NONE');

    const wpnPool = (Array.isArray(s.signatureWeaponTypes) && s.signatureWeaponTypes.length)
      ? s.signatureWeaponTypes
      : ['SWORD', 'BLADE', 'SPEAR', 'FIST', 'BOW', 'STAFF', 'FOCUS', 'ZITHER', 'BRUSH', 'WHIP'];
    const chosenWeapon = opts.weaponType || rng.pick(wpnPool) || 'SWORD';
    const wTypeTh = (JD && JD.MARTIAL && JD.MARTIAL.types && JD.MARTIAL.types[chosenWeapon]) || chosenWeapon;

    let techs = Array.isArray(s.signatureTechs) ? s.signatureTechs.slice() : [];
    if (isEclectic && JD && JD.TECH && Array.isArray(JD.TECH.techniques)) {
      const compat = JD.TECH.techniques.filter(t => t && (t.path === chosenPath || t.path === 'ANY') && (t.tier || 1) <= roleStage + 1);
      if (compat.length) {
        const picked = rng.pick(compat);
        if (picked && !techs.includes(picked.id)) techs.unshift(picked.id);
      }
    }
    const topTechObj = (techs[0] && CULT && CULT.tech && CULT.tech(techs[0])) || null;
    const signatureTechNameTh = topTechObj ? topTechObj.nameTh : ('เคล็ดวิชา' + wTypeTh + 'ประจำสำนัก');

    const ROLE_TH_MAP = {
      master: 'เจ้าสำนัก',
      deputy: 'รองเจ้าสำนัก',
      successor: 'ศิษย์สืบทอด',
      ancestor: 'บรรพชนพิทักษ์',
      disciplineElder: 'ผู้อาวุโสหอวินัย',
      craftElder: 'ผู้อาวุโสหอโอสถและหลอมสร้าง',
      warMarshal: 'ผู้อาวุโสแม่ทัพศึก',
      coreDisciple: 'ศิษย์เอกสายตรง'
    };
    const cognitionTier = (role === 'master' || role === 'deputy' || role === 'successor' || role === 'ancestor')
      ? 1
      : (role === 'disciplineElder' || role === 'craftElder' || role === 'warMarshal')
      ? 2
      : 3;
    const domain = role === 'disciplineElder'
      ? 'DISCIPLINE_PURSUIT'
      : role === 'craftElder'
      ? 'ALCHEMY_FORGE'
      : role === 'warMarshal'
      ? 'WAR_DIPLOMACY'
      : role === 'coreDisciple'
      ? 'MARTIAL_COMPETITION'
      : 'SUPREME_GOVERNANCE';

    const fig = {
      id: figId,
      kind: 'SECT_FIGURE',
      role,
      roleTh: ROLE_TH_MAP[role] || 'ผู้อาวุโสสำนัก',
      cognitionTier,
      domain,
      sectId: s.id,
      canonicalSectId: s.canonicalId,
      sectNameTh: s.nameTh,
      orgType: s.orgType || 'สำนัก',
      alignment: s.alignment || 'NEUTRAL',
      doctrineMode: s.doctrineMode || 'THEMATIC',
      h,
      rank,
      ageYears,
      bornDay: (W.day || 360) - ageYears * 360,
      lifespanYears: 95 + roleStage * 32,
      cult: {
        path: chosenPath,
        sub: chosenSub,
        stage: roleStage,
        techs
      },
      weaponType: chosenWeapon,
      weaponNameTh: (s.doctrineMode === 'THEMATIC' && s.signatureGearTh)
        ? s.signatureGearTh.split('&')[0].trim()
        : ('ศาสตรา' + wTypeTh + 'หลอมปราณขั้น ' + roleStage),
      signatureTechNameTh,
      power: Math.round((95 + Math.pow(roleStage, 2.25) * 42) * (role === 'master' ? 1.18 : role === 'ancestor' ? 1.32 : role === 'warMarshal' ? 1.14 : (role === 'deputy' || role === 'disciplineElder' || role === 'craftElder') ? 1.0 : 0.86)),
      hpMax: Math.round(450 + Math.pow(roleStage, 2.1) * 180),
      hp: Math.round(450 + Math.pow(roleStage, 2.1) * 180),
      backingBonus: role === 'successor' ? rng.int(8, 28) : 0,
      inv: { stones: rng.int(120, 450) * tierLv, pills: {}, relics: [] },
      dead: false,
      kills: 0
    };

    hideFigCaches(fig, W);
    const doc = X.computeFigureDoctrine(fig);
    fig.doctrineId = doc.id;
    fig.doctrineNameTh = doc.nameTh;
    fig.doctrineBadgeTh = doc.badgeTh;
    const prefList = EPITHET_PREFIX_BY_PATH[chosenPath] || EPITHET_PREFIX_BY_PATH.XIAN;
    const sufList = EPITHET_SUFFIX_BY_TRAIT[doc.id] || EPITHET_SUFFIX_BY_TRAIT.ORTHODOX_INQUISITION;
    fig.epithetTh = rng.pick(prefList) + rng.pick(sufList);
    fig.fullNameTh = figFullName(fig);
    fig.titleAndNameTh = fig.fullNameTh + ' 「' + fig.epithetTh + '」';
    fig.personalitySummaryTh = 'นิสัย: ' + doc.nameTh + ' (ทะเยอทะยาน ' + Math.round(figTrait(fig, 'personality.ambition')) + ' · คุณธรรม ' + Math.round(figTrait(fig, 'personality.integrity')) + ' · ดุดัน ' + Math.round(figTrait(fig, 'personality.aggression')) + ' · ภักดี ' + Math.round(figTrait(fig, 'personality.loyalty')) + ')';

    if (W.world && W.world.figuresById) {
      W.world.figuresById[fig.id] = fig;
    }
    return fig;
  };

  X.ensureJianghuFigures = W => {
    if (!W || !W.world) return null;
    ensureFiguresMap(W.world);
    const all = W.world.allSects || [];
    all.forEach((s, idx) => {
      if (!s) return;
      if (!s.figures || typeof s.figures !== 'object') s.figures = {};
      let _baseRng = null;
      const getBaseRng = () => _baseRng || (_baseRng = makeChildRng(W, 'init_sect_' + (s.canonicalId || s.id || idx)));
      if (!s.figures.master || s.figures.master.dead) {
        s.figures.master = X.generateProceduralSectFigure(W, s, 'master', { rng: getBaseRng(), seq: idx * 10 + 1 });
      }
      if (!s.figures.deputy || s.figures.deputy.dead) {
        s.figures.deputy = X.generateProceduralSectFigure(W, s, 'deputy', { rng: getBaseRng(), seq: idx * 10 + 2 });
      }
      if (!s.figures.successor || s.figures.successor.dead) {
        s.figures.successor = X.generateProceduralSectFigure(W, s, 'successor', { rng: getBaseRng(), seq: idx * 10 + 3 });
      }
      if ((s.tierLevel || 1) >= 3 && (!s.figures.ancestor || s.figures.ancestor.dead)) {
        s.figures.ancestor = X.generateProceduralSectFigure(W, s, 'ancestor', { rng: getBaseRng(), seq: idx * 10 + 4 });
      }
      if (s.figures.master) {
        hideFigCaches(s.figures.master, W);
        s.leaderNameTh = s.figures.master.titleAndNameTh;
        s.masterDoctrineId = s.figures.master.doctrineId;
        s.masterDoctrineNameTh = s.figures.master.doctrineNameTh;
        W.world.figuresById[s.figures.master.id] = s.figures.master;
      }
      if (s.figures.deputy) { hideFigCaches(s.figures.deputy, W); W.world.figuresById[s.figures.deputy.id] = s.figures.deputy; }
      if (s.figures.successor) { hideFigCaches(s.figures.successor, W); W.world.figuresById[s.figures.successor.id] = s.figures.successor; }
      if (s.figures.ancestor) { hideFigCaches(s.figures.ancestor, W); W.world.figuresById[s.figures.ancestor.id] = s.figures.ancestor; }

      // Patch v2.0.30: Tier 2 Specialized Domain Elders & Tier 3 Core Disciples (using isolated child RNG)
      let _v230Rng = null;
      const getV230Rng = () => _v230Rng || (_v230Rng = makeChildRng(W, 'init_sect_v230_' + (s.canonicalId || s.id || idx)));
      if (!s.figures.disciplineElder || s.figures.disciplineElder.dead) {
        s.figures.disciplineElder = X.generateProceduralSectFigure(W, s, 'disciplineElder', { rng: getV230Rng(), seq: idx * 20 + 11 });
      }
      if (!s.figures.craftElder || s.figures.craftElder.dead) {
        s.figures.craftElder = X.generateProceduralSectFigure(W, s, 'craftElder', { rng: getV230Rng(), seq: idx * 20 + 12 });
      }
      if (!s.figures.warMarshal || s.figures.warMarshal.dead) {
        s.figures.warMarshal = X.generateProceduralSectFigure(W, s, 'warMarshal', { rng: getV230Rng(), seq: idx * 20 + 13 });
      }
      if (!Array.isArray(s.figures.coreDisciples)) {
        s.figures.coreDisciples = [];
      }
      s.figures.coreDisciples = s.figures.coreDisciples.filter(cd => cd && !cd.dead && !cd.recruitedToPlayer);
      while (s.figures.coreDisciples.length < 3) {
        const cdIdx = s.figures.coreDisciples.length + 1;
        const cdFig = X.generateProceduralSectFigure(W, s, 'coreDisciple', { rng: getV230Rng(), seq: idx * 20 + 13 + cdIdx });
        s.figures.coreDisciples.push(cdFig);
      }
      if (s.figures.disciplineElder) { hideFigCaches(s.figures.disciplineElder, W); W.world.figuresById[s.figures.disciplineElder.id] = s.figures.disciplineElder; }
      if (s.figures.craftElder) { hideFigCaches(s.figures.craftElder, W); W.world.figuresById[s.figures.craftElder.id] = s.figures.craftElder; }
      if (s.figures.warMarshal) { hideFigCaches(s.figures.warMarshal, W); W.world.figuresById[s.figures.warMarshal.id] = s.figures.warMarshal; }
      s.figures.coreDisciples.forEach(cd => {
        if (cd && cd.id) { hideFigCaches(cd, W); W.world.figuresById[cd.id] = cd; }
      });
    });
    return W.world.figuresById;
  };

  /* ---------- Wandering Legends (ผู้บำเพ็ญในตำนานพเนจร & การหวนคืนหลังสาบสูญ) ---------- */
  const LEGEND_REEMERGE_STORIES = Object.freeze([
    'เคยสาบสูญไปในหุบเขาเหวลึกเมื่อกว่าร้อยปีก่อน ผู้คนต่างคิดว่ามอดม้วยไปแล้ว บัดนี้ทลายศิลาปิดด่านทะลวงขั้นหวนคืนสู่ยุทธภพอีกครั้ง!',
    'ปรมาจารย์เร้นกายที่เคยสั่นสะเทือนยุทธภพเมื่อยุคก่อน เพิ่งก้าวออกจากถ้ำน้ำแข็งพันปีพร้อมตบะที่ลึก้ำเกินหยั่งคาด!',
    'อดีตยอดคนผู้เบื่อหน่ายโลกียะและเร้นกายเข้าสู่แดนร้างตะวันตก บัดนี้สัมผัสได้ถึงคลื่นลมปั่นป่วนในยุทธภพจึงหวนคืนสู่หล้า!',
    'ยอดฝีมือในตำนานที่เคยถูกบันทึกว่าหายสาบสูญในรอยแยกมิติ บัดนี้แหวกม่านหมอกฟ้าดินกลับมาเยือนยุทธภพพร้อมศาสตราคู่กาย!'
  ]);

  X.generateWanderingLegend = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    W.world.legendSeq = (W.world.legendSeq || 0) + 1;
    const seq = opts.seq != null ? opts.seq : W.world.legendSeq;
    const rng = opts.rng || makeChildRng(W, 'legend:' + seq + ':' + (W.day || 360));

    const stage = opts.stage || rng.int(7, 9);
    const ageYears = opts.ageYears || rng.int(85, 165);
    const legId = 'JHLEG_' + seq + '_' + (W.day || 360);
    const sex = rng.chance(0.58) ? 'M' : 'F';
    const h = generateFastFigureCore(rng, sex);

    const pathIds = (CULT && CULT.PATHS && Object.keys(CULT.PATHS).length)
      ? Object.keys(CULT.PATHS)
      : ['XIAN', 'BODY', 'GOD', 'DEMON', 'HEART_SOUL', 'KARMA_SAMSARA', 'BEAST_SOVEREIGN', 'SAGE_SUPPORT', 'CRAFT_CREATION', 'ARRAY_TALISMAN'];
    const chosenPath = opts.path || rng.pick(pathIds);
    const subObjs = (CULT && CULT.PATHS && CULT.PATHS[chosenPath] && Array.isArray(CULT.PATHS[chosenPath].subPaths))
      ? CULT.PATHS[chosenPath].subPaths
      : [];
    const chosenSub = opts.sub || (subObjs.length ? rng.pick(subObjs).id : 'NONE');
    const wpnTypes = ['SWORD', 'BLADE', 'SPEAR', 'FIST', 'BOW', 'STAFF', 'FOCUS', 'ZITHER', 'BRUSH', 'WHIP'];
    const chosenWeapon = opts.weaponType || rng.pick(wpnTypes);
    const wTypeTh = (JD && JD.MARTIAL && JD.MARTIAL.types && JD.MARTIAL.types[chosenWeapon]) || chosenWeapon;

    let techs = [];
    if (JD && JD.TECH && Array.isArray(JD.TECH.techniques)) {
      const highTechs = JD.TECH.techniques.filter(t => t && (t.path === chosenPath || t.path === 'ANY') && (t.tier || 1) >= 4);
      if (highTechs.length) {
        const t1 = rng.pick(highTechs);
        const t2 = rng.pick(highTechs);
        techs = Array.from(new Set([t1 && t1.id, t2 && t2.id].filter(Boolean)));
      }
    }
    const topTech = (techs[0] && CULT && CULT.tech && CULT.tech(techs[0])) || null;
    const signatureTechNameTh = topTech ? topTech.nameTh : ('มหาวิชา' + wTypeTh + 'บรรพกาล');

    const alignRoll = figTrait({ h }, 'personality.integrity') - figTrait({ h }, 'personality.aggression');
    const alignment = alignRoll >= 12 ? 'RIGHTEOUS' : alignRoll <= -12 ? 'DEMONIC' : 'NEUTRAL';
    const doc = X.computeFigureDoctrine({ h });
    const prefList = EPITHET_PREFIX_BY_PATH[chosenPath] || EPITHET_PREFIX_BY_PATH.XIAN;
    const sufList = EPITHET_SUFFIX_BY_TRAIT[doc.id] || EPITHET_SUFFIX_BY_TRAIT.MYSTIC_SECLUSION;
    const epithetTh = rng.pick(prefList) + rng.pick(sufList);
    const regions = Object.keys(X.WORLD_REGIONS);
    const macroRegion = opts.macroRegion || rng.pick(regions) || 'NORTHERN_PEAKS';
    const reemergenceOriginTh = opts.isReemergence
      ? rng.pick(LEGEND_REEMERGE_STORIES)
      : 'ยอดคนเร้นกายผู้ท่องไปในยุทธภพอย่างอิสระ ไม่ขึ้นตรงต่อสำนักใด';

    const leg = {
      id: legId,
      kind: 'WANDERING_LEGEND',
      role: 'legend',
      roleTh: 'ผู้บำเพ็ญในตำนานพเนจร',
      sectId: null,
      sectNameTh: 'อิสระไร้สังกัด (ยอดคนในตำนาน)',
      alignment,
      alignmentLabelTh: (X.ALIGNMENT_DEFS[alignment] || X.ALIGNMENT_DEFS.NEUTRAL).nameTh,
      h,
      rank: 6,
      ageYears,
      lifespanYears: 180 + stage * 35,
      cult: {
        path: chosenPath,
        sub: chosenSub,
        stage,
        techs
      },
      weaponType: chosenWeapon,
      weaponNameTh: 'ศาสตราเทพ' + wTypeTh + '「' + epithetTh + '」',
      signatureTechNameTh,
      doctrineId: doc.id,
      doctrineNameTh: doc.nameTh,
      doctrineBadgeTh: doc.badgeTh,
      epithetTh,
      fullNameTh: figFullName({ h }),
      titleAndNameTh: figFullName({ h }) + ' 「' + epithetTh + '」',
      macroRegion,
      power: Math.round(520 + Math.pow(stage, 2.35) * 48),
      hpMax: Math.round(950 + Math.pow(stage, 2.15) * 220),
      hp: Math.round(950 + Math.pow(stage, 2.15) * 220),
      isReemergence: !!opts.isReemergence,
      reemergenceOriginTh,
      inv: { stones: rng.int(800, 2200), pills: {}, relics: [] },
      dead: false,
      kills: 0
    };
    hideFigCaches(leg, W);
    leg.personalitySummaryTh = 'นิสัย: ' + doc.nameTh + ' (ทะเยอทะยาน ' + Math.round(figTrait(leg, 'personality.ambition')) + ' · คุณธรรม ' + Math.round(figTrait(leg, 'personality.integrity')) + ' · ดุดัน ' + Math.round(figTrait(leg, 'personality.aggression')) + ' · เมตตา ' + Math.round(figTrait(leg, 'personality.empathy')) + ')';
    if (W.world && W.world.figuresById) W.world.figuresById[leg.id] = leg;
    return leg;
  };

  X.ensureWanderingLegends = (W, targetCount) => {
    if (!W || !W.world) return [];
    const want = targetCount || 5;
    if (!Array.isArray(W.world.wanderingLegends)) W.world.wanderingLegends = [];
    if (!Array.isArray(W.world.fallenLegends)) W.world.fallenLegends = [];
    ensureFiguresMap(W.world);

    const alive = W.world.wanderingLegends.filter(l => l && !l.dead);
    let idx = W.world.wanderingLegends.length;
    while (alive.length < want) {
      idx++;
      const rng = makeChildRng(W, 'init_legend_' + idx);
      const leg = X.generateWanderingLegend(W, { rng, seq: idx, isReemergence: idx > want });
      W.world.wanderingLegends.push(leg);
      alive.push(leg);
    }
    W.world.wanderingLegends.forEach(l => {
      if (l && l.id) { hideFigCaches(l, W); W.world.figuresById[l.id] = l; }
    });
    return W.world.wanderingLegends;
  };

  X.reemergeWanderingLegend = (W, deadLegendOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    if (!Array.isArray(W.world.wanderingLegends)) W.world.wanderingLegends = [];
    if (!Array.isArray(W.world.fallenLegends)) W.world.fallenLegends = [];
    const deadLeg = typeof deadLegendOrId === 'object' && deadLegendOrId
      ? deadLegendOrId
      : (W.world.wanderingLegends || []).find(l => l && l.id === deadLegendOrId);
    if (deadLeg && !deadLeg.dead) {
      deadLeg.dead = true;
      deadLeg.diedDay = W.day || 360;
    }
    if (deadLeg && !W.world.fallenLegends.some(f => f && f.id === deadLeg.id)) {
      W.world.fallenLegends.unshift(deadLeg);
      if (W.world.fallenLegends.length > 30) W.world.fallenLegends.length = 30;
    }
    W.world.wanderingLegends = (W.world.wanderingLegends || []).filter(l => l && !l.dead);

    const newLeg = X.generateWanderingLegend(W, { isReemergence: true });
    W.world.wanderingLegends.push(newLeg);
    const regName = (X.WORLD_REGIONS[newLeg.macroRegion] && X.WORLD_REGIONS[newLeg.macroRegion].nameTh) || newLeg.macroRegion;

    const chron = X.recordChronicle(W, {
      category: 'LEGEND',
      icon: '🐉',
      macroRegion: newLeg.macroRegion,
      involvedFigures: [newLeg.titleAndNameTh].concat(deadLeg ? [deadLeg.titleAndNameTh] : []),
      titleTh: 'ปรมาจารย์เร้นกายหวนคืนยุทธภพ: ' + newLeg.titleAndNameTh,
      storyTh: (deadLeg ? ('ภายหลังการดับสูญของ「' + deadLeg.titleAndNameTh + '」คลื่นลมในยุทธภพยังไม่ทันสงบ ') : '') +
        'เกิดปราณฟ้าดินสั่นสะเทือนเลื่อนลั่นเหนือเขต' + regName + '! มีผู้พบเห็น「' + newLeg.titleAndNameTh + '」(' + newLeg.cult.path + ' ขั้น ' + newLeg.cult.stage + ' · ถือครอง' + newLeg.weaponNameTh + ') ' + newLeg.reemergenceOriginTh,
      combatBreakdownTh: 'ตบะขั้น ' + newLeg.cult.stage + ' · พลังรบประเมิน ' + newLeg.power + ' · เคล็ดวิชาคู่กาย「' + newLeg.signatureTechNameTh + '」 · ' + newLeg.personalitySummaryTh,
      consequenceTh: newLeg.titleAndNameTh + ' ปรากฏตัวออกท่องยุทธภพในฐานะผู้บำเพ็ญในตำนานคนใหม่!',
      quiet: opts.quiet
    });
    return { ok: true, fallenLegend: deadLeg || null, newLegend: newLeg, chronicle: chron };
  };

  /* ---------- Sect Succession Crisis & 3-Tier Promotion Ladder ---------- */
  X.promoteToSuccessor = (W, s) => {
    if (!W || !s || !s.figures) return null;
    const figs = s.figures;
    const aliveCore = (figs.coreDisciples || []).filter(cd => cd && !cd.dead);
    if (aliveCore.length) {
      aliveCore.sort((a, b) => (b.power || 0) - (a.power || 0));
      const promoted = aliveCore[0];
      const idx = figs.coreDisciples.indexOf(promoted);
      promoted.role = 'successor';
      promoted.roleTh = 'ศิษย์สืบทอด';
      promoted.rank = 3;
      if (promoted.cult) {
        promoted.cult.stage = Math.min(9, (promoted.cult.stage || 3) + 1);
      }
      promoted.power = Math.round((promoted.power || 220) * 1.25);
      promoted.backingBonus = (promoted.backingBonus || 10) + 12;
      promoted.promotedFromRole = 'core_disciple';
      promoted.promotedDay = (W && W.day) || 360;
      promoted.titleAndNameTh = promoted.fullNameTh + ' 「ศิษย์สืบทอด' + (s.shortTh || s.nameTh) + '」';
      figs.successor = promoted;
      const replacementCore = X.generateProceduralSectFigure(W, s, 'core_disciple', { slotIdx: idx >= 0 ? idx : 0 });
      if (idx >= 0) figs.coreDisciples[idx] = replacementCore;
      else figs.coreDisciples.push(replacementCore);
      return promoted;
    }
    figs.successor = X.generateProceduralSectFigure(W, s, 'successor');
    return figs.successor;
  };

  X.promoteToDeputy = (W, s) => {
    if (!W || !s || !s.figures) return null;
    const figs = s.figures;
    const elderSlots = [
      ['warMarshal', figs.warMarshal],
      ['disciplineElder', figs.disciplineElder],
      ['craftElder', figs.craftElder]
    ].filter(([, el]) => el && !el.dead);
    if (elderSlots.length) {
      elderSlots.sort((a, b) => (b[1].power || 0) - (a[1].power || 0));
      const [slotKey, promoted] = elderSlots[0];
      promoted.promotedFromRole = promoted.role;
      promoted.role = 'deputy';
      promoted.roleTh = 'รองเจ้าสำนัก';
      promoted.rank = 5;
      if (promoted.cult) {
        promoted.cult.stage = Math.min(9, (promoted.cult.stage || 4) + 1);
      }
      promoted.power = Math.round((promoted.power || 340) * 1.18);
      promoted.promotedDay = (W && W.day) || 360;
      promoted.titleAndNameTh = promoted.fullNameTh + ' 「รองเจ้าสำนัก' + (s.shortTh || s.nameTh) + '」';
      figs.deputy = promoted;
      const roleMap = { warMarshal: 'war_marshal', disciplineElder: 'discipline_elder', craftElder: 'craft_elder' };
      figs[slotKey] = X.generateProceduralSectFigure(W, s, roleMap[slotKey] || 'war_marshal');
      return promoted;
    }
    figs.deputy = X.generateProceduralSectFigure(W, s, 'deputy');
    return figs.deputy;
  };

  X.resolveSectSuccession = (W, sectOrId, causeTh, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    const s = typeof sectOrId === 'object' && sectOrId ? sectOrId : X.findSect(W, sectOrId);
    if (!s || !s.figures) return { ok: false, reason: 'sect-not-found' };

    const oldMaster = s.figures.master;
    if (oldMaster) {
      oldMaster.dead = true;
      oldMaster.diedDay = W.day || 360;
      oldMaster.deathCauseTh = causeTh || 'สิ้นอายุขัย/ดับสูญในศึกยุทธภพ';
    }

    const deputy = (s.figures.deputy && !s.figures.deputy.dead)
      ? s.figures.deputy
      : X.generateProceduralSectFigure(W, s, 'deputy');
    const succ = (s.figures.successor && !s.figures.successor.dead)
      ? s.figures.successor
      : X.generateProceduralSectFigure(W, s, 'successor');
    const ancestor = (s.figures.ancestor && !s.figures.ancestor.dead) ? s.figures.ancestor : null;

    // 1. Evaluate Deputy's usurpation drive from HC traits
    const dAmb = figTrait(deputy, 'personality.ambition');
    const dPride = figTrait(deputy, 'personality.pride');
    const dAggr = figTrait(deputy, 'personality.aggression');
    const dInt = figTrait(deputy, 'personality.integrity');
    const dLoy = figTrait(deputy, 'personality.loyalty');
    const dEmp = figTrait(deputy, 'personality.empathy');

    const deputyUsurpDrive = Math.round(
      (dAmb - 50) * 0.55 +
      (dPride - 50) * 0.32 +
      (dAggr - 50) * 0.30 -
      (dInt - 50) * 0.48 -
      (dLoy - 50) * 0.42 -
      (dEmp - 50) * 0.20 +
      (s.alignment === 'DEMONIC' ? 14 : s.alignment === 'RIGHTEOUS' ? -6 : 2) +
      (opts.forceUsurpAttempt ? 40 : opts.forceHonorable ? -45 : 0)
    );

    // 2. Evaluate Designated Successor's backing inside the sect
    const sChar = figTrait(succ, 'social.charisma');
    const sLead = figTrait(succ, 'social.leadership');
    const powerRatio = (succ.power || 200) / Math.max(100, deputy.power || 250);
    const ancestorBacksSuccessor = ancestor
      ? (figTrait(ancestor, 'personality.integrity') >= 48 || figTrait(ancestor, 'values.honorLegacy') >= 50)
      : false;
    const ancestorScore = ancestor ? (ancestorBacksSuccessor ? 24 : -14) : 0;
    const successorBacking = clamp(Math.round(
      28 +
      powerRatio * 24 +
      (sChar - 50) * 0.30 +
      (sLead - 50) * 0.30 +
      (succ.backingBonus || 0) +
      ancestorScore +
      (opts.successorBackingMod || 0)
    ), 5, 100);

    let outcome = 'HONORABLE_SUPPORT';
    let newMaster = succ;
    let casualtyFigure = null;
    let renegadeSpawned = null;
    let storyTh = '';
    let combatBreakdownTh = '';
    let consequenceTh = '';

    if (deputyUsurpDrive < 10) {
      // CASE 1: Honorable Regency — Deputy respects the late Master's decree and supports the Successor
      outcome = 'HONORABLE_SUPPORT';
      newMaster = succ;
      newMaster.role = 'master';
      newMaster.roleTh = 'เจ้าสำนัก';
      newMaster.rank = 6;
      newMaster.power = Math.round(newMaster.power * 1.18);
      s.figures.master = newMaster;
      s.figures.deputy = deputy;
      X.promoteToSuccessor(W, s);

      storyTh = 'เมื่อเจ้าสำนัก「' + (oldMaster ? oldMaster.titleAndNameTh : s.nameTh) + '」สิ้นชีพลงเพราะ' + (causeTh || 'ภัยยุทธภพ') +
        ' ทั่วทั้ง「' + s.nameTh + '」ตกอยู่ในความโศกเศร้า รองเจ้าสำนัก「' + deputy.titleAndNameTh + '」ผู้มีคุณธรรม (' + Math.round(dInt) + ') และความภักดี (' + Math.round(dLoy) + ') ได้นำตราพินัยกรรมออกประกาศกลางโถงใหญ่ ประคองศิษย์สืบทอด「' + succ.titleAndNameTh + '」ขึ้นครองบัลลังก์เจ้าสำนักคนใหม่อย่างสมเกียรติ พร้อมแต่งตั้ง「' + s.figures.successor.titleAndNameTh + '」เป็นศิษย์สืบทอดรุ่นถัดไป!';
      combatBreakdownTh = 'แรงขับชิงอำนาจของรองเจ้าสำนัก: ' + deputyUsurpDrive + ' (ยึดมั่นคุณธรรม) · แรงหนุนหลังศิษย์สืบทอด: ' + successorBacking + '/100' + (ancestorBacksSuccessor ? (' · บรรพชน「' + ancestor.fullNameTh + '」ออกโรงหนุนพินัยกรรม') : '');
      consequenceTh = newMaster.titleAndNameTh + ' ขึ้นเป็นเจ้าสำนักคนใหม่ (' + newMaster.doctrineNameTh + ') โดยไร้ศึกสายเลือด';
    } else if (successorBacking < 52 && !opts.forceSchism) {
      // CASE 2: Bloodless/Political Usurpation — Ambitious Deputy sidelines weak Successor and seizes the throne
      outcome = 'DEPUTY_USURP';
      newMaster = deputy;
      newMaster.role = 'master';
      newMaster.roleTh = 'เจ้าสำนัก';
      newMaster.rank = 6;
      newMaster.power = Math.round(newMaster.power * 1.15);
      // Old successor is demoted/sidelined or flees; promote Tier 2 Elder -> Deputy and Tier 3 Core Disciple -> Successor
      s.figures.master = newMaster;
      X.promoteToDeputy(W, s);
      X.promoteToSuccessor(W, s);
      s.influence = Math.max(20, (s.influence || 70) - 6);

      storyTh = 'สิ้นเสียงระฆังไว้อาลัยของ「' + (oldMaster ? oldMaster.titleAndNameTh : 'เจ้าสำนักคนก่อน') + '」(' + (causeTh || 'ดับสูญ') + ') รองเจ้าสำนัก「' + deputy.titleAndNameTh + '」ผู้มีความทะเยอทะยานสูง (' + Math.round(dAmb) + ') และถือดี (' + Math.round(dPride) + ') ได้สั่งปิดประตูโถงสภาแห่ง「' + s.nameTh + '」อ้างว่าศิษย์สืบทอด「' + succ.titleAndNameTh + '」ยังอ่อนด้อยประสบการณ์และไร้ฐานอำนาจหนุนหลัง (' + successorBacking + '/100) จึงฉีกพินัยกรรมและสถาปนาตนเองขึ้นเป็นเจ้าสำนักคนใหม่ทันที พร้อมตั้ง「' + s.figures.deputy.fullNameTh + '」เป็นรองเจ้าสำนัก และตั้ง「' + s.figures.successor.fullNameTh + '」เป็นศิษย์สืบทอดคนใหม่!';
      combatBreakdownTh = 'แรงขับฮุบอำนาจของรองเจ้าสำนัก: +' + deputyUsurpDrive + ' (ทะเยอทะยาน ' + Math.round(dAmb) + '/คุณธรรม ' + Math.round(dInt) + ') เหนือกว่าแรงหนุนหลังของศิษย์สืบทอด (' + successorBacking + '/100)';
      consequenceTh = deputy.titleAndNameTh + ' ยึดครองตำแหน่งเจ้าสำนัก「' + s.nameTh + '」สำเร็จ แนวทางสำนักเปลี่ยนเป็น「' + newMaster.doctrineNameTh + '」!';
    } else {
      // CASE 3: Succession Schism / Civil Strife — Ambitious Deputy clashes with Strongly-Backed Successor!
      outcome = 'SUCCESSION_SCHISM';
      const deputyCombatScore = deputy.power * (1 + deputyUsurpDrive / 140);
      const succCombatScore = succ.power * (1 + successorBacking / 110) + (ancestorBacksSuccessor && ancestor ? ancestor.power * 0.35 : 0);
      const succWins = opts.forceWinner === 'SUCCESSOR' ? true : opts.forceWinner === 'DEPUTY' ? false : (succCombatScore >= deputyCombatScore);

      if (succWins) {
        newMaster = succ;
        newMaster.role = 'master';
        newMaster.roleTh = 'เจ้าสำนัก';
        newMaster.rank = 6;
        newMaster.power = Math.round(newMaster.power * 1.22);
        deputy.dead = true;
        deputy.diedDay = W.day || 360;
        deputy.deathCauseTh = 'พ่ายแพ้และถูกสังหารในศึกชิงบัลลังก์สำนัก';
        casualtyFigure = deputy;
        s.figures.master = newMaster;
        X.promoteToDeputy(W, s);
        X.promoteToSuccessor(W, s);
        s.power = +(Math.max(0.5, (s.power || 1.2) * 0.92)).toFixed(2);

        storyTh = 'ศึกสายเลือดชิงบัลลังก์ปะทุขึ้นกลาง「' + s.nameTh + '」หลังการจากไปของ「' + (oldMaster ? oldMaster.fullNameTh : 'เจ้าสำนักคนก่อน') + '」! รองเจ้าสำนัก「' + deputy.titleAndNameTh + '」คิดก่อการยึดอำนาจด้วยวิชา「' + deputy.signatureTechNameTh + '」แต่ศิษย์สืบทอด「' + succ.titleAndNameTh + '」มีผู้อาวุโสและ' + (ancestorBacksSuccessor && ancestor ? ('บรรพชน「' + ancestor.fullNameTh + '」') : 'กลุ่มศิษย์สายตรง') + 'หนุนหลังอย่างเหนียวแน่น (' + successorBacking + '/100) จึงชัก' + succ.weaponNameTh + 'ออกฟาดฟันด้วย「' + succ.signatureTechNameTh + '」สังหารรองเจ้าสำนักผู้ทรยศลงหน้าหอบรรพชน และก้าวขึ้นครองตำแหน่งเจ้าสำนักคนใหม่ พร้อมแต่งตั้งรองเจ้าสำนักและศิษย์สืบทอดชุดใหม่!';
        combatBreakdownTh = 'ศึกภายในสำนัก: ศิษย์สืบทอด (คะแนนรบ+แรงหนุน ' + Math.round(succCombatScore) + ') เอาชนะ รองเจ้าสำนักผู้กบฏ (' + Math.round(deputyCombatScore) + ') · รองเจ้าสำนักสิ้นชีพในที่รบ!';
        consequenceTh = succ.titleAndNameTh + ' ปราบกบฏสำเร็จและขึ้นเป็นเจ้าสำนักคนใหม่ (กำลังสำนักลดลงเล็กน้อยเป็น ' + s.power + ' จากศึกภายใน)';
      } else {
        newMaster = deputy;
        newMaster.role = 'master';
        newMaster.roleTh = 'เจ้าสำนัก';
        newMaster.rank = 6;
        newMaster.power = Math.round(newMaster.power * 1.18);
        // Defeated successor either dies, escapes as a wandering renegade, or defects to player sect!
        const succCaut = (succ.h && succ.h.personality && succ.h.personality.caution) || 50;
        const succAmb = (succ.h && succ.h.personality && succ.h.personality.ambition) || 50;
        const escaped = succCaut >= 40;
        if (!escaped) {
          succ.dead = true;
          succ.diedDay = W.day || 360;
          succ.deathCauseTh = 'ถูกสังหารในศึกชิงบัลลังก์สำนักโดยรองเจ้าสำนัก';
          casualtyFigure = succ;
        } else {
          renegadeSpawned = succ;
          succ.role = 'renegade_successor';
          succ.roleTh = 'อดีตศิษย์สืบทอดผู้ลี้ภัย';
          // Check if renegade seeks refuge with the player's sect
          const playerFame = (W.sect && W.sect.fame) || 0;
          if ((playerFame >= 80 || succCaut >= 55 || succAmb >= 65) && opts.allowPlayerRefuge !== false) {
            X.hydrateFigureToNpc(W, succ, { rank: 2, merit: 25 });
          }
        }
        s.figures.master = newMaster;
        X.promoteToDeputy(W, s);
        X.promoteToSuccessor(W, s);
        s.power = +(Math.max(0.5, (s.power || 1.2) * 0.90)).toFixed(2);

        storyTh = 'เกิดเหตุนองเลือดสะท้าน「' + s.nameTh + '」! รองเจ้าสำนัก「' + deputy.titleAndNameTh + '」ฉวยโอกาสหลัง「' + (oldMaster ? oldMaster.fullNameTh : 'เจ้าสำนัก') + '」สิ้นชีพ นำกำลังเข้าล้อมสังหารศิษย์สืบทอด「' + succ.titleAndNameTh + '」! แม้ศิษย์สืบทอดจะมีคนหนุนหลัง (' + successorBacking + '/100) และสู้สุดชีวิตด้วย「' + succ.signatureTechNameTh + '」แต่ตบะของรองเจ้าสำนักเหนือกว่า (' + Math.round(deputyCombatScore) + ' ต่อ ' + Math.round(succCombatScore) + ') ฟาดด้วย' + deputy.weaponNameTh + 'จนฝ่ายศิษย์สืบทอดพ่ายแพ้ยับเยิน — ' +
          (escaped ? (succ.fullNameTh + ' บาดเจ็บสาหัสฝ่าวงล้อมหนีตายออกนอกสำนัก!') : (succ.fullNameTh + ' สิ้นใจตายคาคมศาสตรา!')) +
          ' 「' + newMaster.titleAndNameTh + '」จึงก้าวขึ้นเป็นเจ้าสำนักคนใหม่และตั้งรองเจ้าสำนักกับศิษย์สืบทอดสายตนเองขึ้นแทน!';
        combatBreakdownTh = 'ศึกภายในสำนัก: รองเจ้าสำนัก (' + Math.round(deputyCombatScore) + ') บดขยี้ฝ่ายศิษย์สืบทอด (' + Math.round(succCombatScore) + ') · ' + (escaped ? 'ศิษย์สืบทอดหนีรอดเป็นจอมยุทธ์ลี้ภัย' : 'ศิษย์สืบทอดถูกสังหาร');
        consequenceTh = newMaster.titleAndNameTh + ' ชิงบัลลังก์เจ้าสำนักด้วยเลือดสำเร็จ เปลี่ยนแนวทางสำนักเป็น「' + newMaster.doctrineNameTh + '」!';
      }
    }

    s.leaderNameTh = newMaster.titleAndNameTh;
    s.masterDoctrineId = newMaster.doctrineId;
    s.masterDoctrineNameTh = newMaster.doctrineNameTh;
    if (!Array.isArray(s.successionHistory)) s.successionHistory = [];
    const rec = {
      day: W.day || 360,
      sectId: s.id,
      sectNameTh: s.nameTh,
      oldMasterNameTh: oldMaster ? oldMaster.titleAndNameTh : '-',
      newMasterId: newMaster.id,
      newMasterNameTh: newMaster.titleAndNameTh,
      newMasterDoctrineId: newMaster.doctrineId,
      newMasterDoctrineNameTh: newMaster.doctrineNameTh,
      newDeputyNameTh: s.figures.deputy ? s.figures.deputy.titleAndNameTh : '-',
      newSuccessorNameTh: s.figures.successor ? s.figures.successor.titleAndNameTh : '-',
      outcome,
      deputyUsurpDrive,
      successorBacking,
      casualtyFigureId: casualtyFigure ? casualtyFigure.id : null,
      renegadeFigureId: renegadeSpawned ? renegadeSpawned.id : null,
      storyTh
    };
    s.successionHistory.unshift(rec);
    if (s.successionHistory.length > 15) s.successionHistory.length = 15;

    // Re-evaluate Alliance Leadership Doctrine if this sect leads its faction
    X.evaluateAllianceLeadership(W);

    const chron = X.recordChronicle(W, {
      category: 'SUCCESSION',
      icon: outcome === 'HONORABLE_SUPPORT' ? '👑' : outcome === 'DEPUTY_USURP' ? '🐍' : '🩸',
      macroRegion: s.macroRegion || 'CENTRAL_HEARTLAND',
      involvedSects: [s.nameTh],
      involvedFigures: [oldMaster && oldMaster.fullNameTh, newMaster.fullNameTh, deputy.fullNameTh, succ.fullNameTh].filter(Boolean),
      titleTh: 'ผลัดแผ่นดิน「' + s.nameTh + '」: ' + (outcome === 'HONORABLE_SUPPORT' ? 'รองเจ้าสำนักชูศิษย์สืบทอดขึ้นครองบัลลังก์' : outcome === 'DEPUTY_USURP' ? 'รองเจ้าสำนักฮุบอำนาจฉีกพินัยกรรม' : 'ศึกสายเลือดชิงตำแหน่งเจ้าสำนัก'),
      storyTh,
      combatBreakdownTh,
      consequenceTh,
      quiet: opts.quiet
    });

    return { ok: true, outcome, sect: s, newMaster, newDeputy: s.figures.deputy, newSuccessor: s.figures.successor, deputyUsurpDrive, successorBacking, chronicle: chron, record: rec };
  };

  X.killJianghuFigure = (W, figOrId, causeTh, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    X.ensureWanderingLegends(W);

    let fig = typeof figOrId === 'object' && figOrId ? figOrId : (W.world.figuresById && W.world.figuresById[figOrId]);
    if (!fig) {
      const s = X.findSect(W, figOrId);
      if (s && s.figures && s.figures.master) fig = s.figures.master;
    }
    if (!fig) return { ok: false, reason: 'figure-not-found' };
    if (fig.dead) return { ok: false, reason: 'already-dead', slainFigure: fig };

    fig.dead = true;
    fig.hp = 0;
    fig.diedDay = W.day || 360;
    fig.deathCauseTh = causeTh || 'สิ้นชีพในศึกยุทธภพ';

    if (fig.kind === 'WANDERING_LEGEND') {
      const reRes = X.reemergeWanderingLegend(W, fig, opts);
      return { ok: true, kind: 'WANDERING_LEGEND', slainFigure: fig, reemergence: reRes };
    }

    const s = X.findSect(W, fig.sectId || fig.canonicalSectId);
    if (!s || !s.figures) return { ok: true, kind: 'SECT_FIGURE', slainFigure: fig };

    if (fig.role === 'master' || (s.figures.master && s.figures.master.id === fig.id)) {
      const succRes = X.resolveSectSuccession(W, s, causeTh, opts);
      return { ok: true, kind: 'SECT_MASTER', slainFigure: fig, succession: succRes };
    } else if (fig.role === 'deputy' || (s.figures.deputy && s.figures.deputy.id === fig.id)) {
      X.promoteToDeputy(W, s);
      const chron = X.recordChronicle(W, {
        category: 'SUCCESSION',
        icon: '⚔️',
        macroRegion: s.macroRegion,
        involvedSects: [s.nameTh],
        titleTh: 'รองเจ้าสำนัก「' + s.nameTh + '」สิ้นชีพ! เลื่อนขั้นผู้อาวุโสขึ้นเป็นรองเจ้าสำนักคนใหม่',
        storyTh: '「' + fig.titleAndNameTh + '」รองเจ้าสำนักแห่ง「' + s.nameTh + '」สิ้นชีพลงเพราะ' + (causeTh || 'การศึก') + ' เจ้าสำนักจึงมีคำสั่งเลื่อนขั้นผู้อาวุโส「' + s.figures.deputy.titleAndNameTh + '」ขึ้นดำรงตำแหน่งรองเจ้าสำนักแทนทันที',
        consequenceTh: s.figures.deputy.titleAndNameTh + ' ก้าวขึ้นเป็นรองเจ้าสำนักคนใหม่',
        quiet: opts.quiet
      });
      return { ok: true, kind: 'SECT_DEPUTY', slainFigure: fig, newDeputy: s.figures.deputy, chronicle: chron };
    } else if (fig.role === 'successor' || (s.figures.successor && s.figures.successor.id === fig.id)) {
      X.promoteToSuccessor(W, s);
      const chron = X.recordChronicle(W, {
        category: 'SUCCESSION',
        icon: '🕯️',
        macroRegion: s.macroRegion,
        involvedSects: [s.nameTh],
        titleTh: 'ศิษย์สืบทอด「' + s.nameTh + '」ดับสูญ! เลื่อนขั้นศิษย์เอกขึ้นเป็นศิษย์สืบทอดคนใหม่',
        storyTh: 'ข่าวร้ายสะเทือน「' + s.nameTh + '」เมื่อศิษย์เอกผู้สืบทอด「' + fig.titleAndNameTh + '」สิ้นชีพลงเพราะ' + (causeTh || 'ภัยในยุทธภพ') + ' เจ้าสำนักจึงเลื่อนขั้นศิษย์เอกอันดับหนึ่ง「' + s.figures.successor.titleAndNameTh + '」ขึ้นรับตราตั้งเป็นศิษย์สืบทอดคนต่อไป!',
        consequenceTh: s.figures.successor.titleAndNameTh + ' ได้รับตราตั้งเป็นศิษย์สืบทอดคนใหม่',
        quiet: opts.quiet
      });
      return { ok: true, kind: 'SECT_SUCCESSOR', slainFigure: fig, newSuccessor: s.figures.successor, chronicle: chron };
    } else if (fig.role === 'discipline_elder' || (s.figures.disciplineElder && s.figures.disciplineElder.id === fig.id)) {
      s.figures.disciplineElder = X.generateProceduralSectFigure(W, s, 'discipline_elder');
      return { ok: true, kind: 'SECT_DISCIPLINE_ELDER', slainFigure: fig, newElder: s.figures.disciplineElder };
    } else if (fig.role === 'craft_elder' || (s.figures.craftElder && s.figures.craftElder.id === fig.id)) {
      s.figures.craftElder = X.generateProceduralSectFigure(W, s, 'craft_elder');
      return { ok: true, kind: 'SECT_CRAFT_ELDER', slainFigure: fig, newElder: s.figures.craftElder };
    } else if (fig.role === 'war_marshal' || (s.figures.warMarshal && s.figures.warMarshal.id === fig.id)) {
      s.figures.warMarshal = X.generateProceduralSectFigure(W, s, 'war_marshal');
      return { ok: true, kind: 'SECT_WAR_MARSHAL', slainFigure: fig, newElder: s.figures.warMarshal };
    } else if (fig.role === 'core_disciple' && Array.isArray(s.figures.coreDisciples)) {
      const cIdx = s.figures.coreDisciples.findIndex(c => c && c.id === fig.id);
      const rep = X.generateProceduralSectFigure(W, s, 'core_disciple', { slotIdx: cIdx >= 0 ? cIdx : 0 });
      if (cIdx >= 0) s.figures.coreDisciples[cIdx] = rep;
      return { ok: true, kind: 'SECT_CORE_DISCIPLE', slainFigure: fig, newCoreDisciple: rep };
    } else if (fig.role === 'ancestor') {
      s.figures.ancestor = X.generateProceduralSectFigure(W, s, 'ancestor');
      return { ok: true, kind: 'SECT_ANCESTOR', slainFigure: fig, newAncestor: s.figures.ancestor };
    }
    return { ok: true, kind: 'SECT_FIGURE', slainFigure: fig };
  };

  /* ---------- Faction Alliance Leadership, Doctrines & Council Politics ---------- */
  X.evaluateAllianceLeadership = W => {
    if (!W || !W.world) return null;
    const gp = W.world.grandPolitics || (W.world.grandPolitics = {});
    const all = W.world.allSects || [];
    if (!gp.alliances || typeof gp.alliances !== 'object') gp.alliances = {};

    ['RIGHTEOUS', 'DEMONIC', 'NEUTRAL'].forEach(alignId => {
      const members = all.filter(s => s && s.alignment === alignId);
      members.sort((a, b) => ((b.tierLevel || 1) * 100 + (b.power || 1) * 25 + (b.influence || 50) * 0.2) - ((a.tierLevel || 1) * 100 + (a.power || 1) * 25 + (a.influence || 50) * 0.2));

      if (alignId === 'NEUTRAL') {
        // Hard Rule: NEUTRAL has NO Supreme Alliance Leader (ไม่มีสำนักระดับผู้นำสูงสุด)
        members.forEach(m => { m.isAllianceLeader = false; m.allianceTitleTh = null; });
        const coordinator = members[0] || null;
        const coordMaster = coordinator && coordinator.figures ? coordinator.figures.master : null;
        const doc = coordMaster ? X.computeFigureDoctrine(coordMaster) : X.ALLIANCE_DOCTRINES.MERCHANT_HEGEMONY;
        gp.alliances.NEUTRAL = {
          alignment: 'NEUTRAL',
          nameTh: 'เครือข่ายสำนักอิสระสายกลาง',
          hasSupremeLeader: false,
          leaderSectId: null,
          leaderSectNameTh: 'ไม่มีสำนักระดับผู้นำสูงสุด (สภาอิสระ)',
          coordinatorSectNameTh: coordinator ? coordinator.nameTh : '-',
          leaderMasterNameTh: coordMaster ? coordMaster.titleAndNameTh : '-',
          doctrineId: doc.id,
          doctrineNameTh: doc.nameTh,
          doctrineBadgeTh: doc.badgeTh,
          doctrineDescTh: doc.descTh,
          clashChanceMod: doc.clashChanceMod,
          memberCount: members.length,
          totalPower: +members.reduce((sum, m) => sum + (m.power || 1), 0).toFixed(2)
        };
      } else {
        let leader = members.find(m => m.isAllianceLeader) || members[0];
        if (leader) {
          members.forEach(m => {
            m.isAllianceLeader = (m.id === leader.id);
            m.allianceTitleTh = m.isAllianceLeader
              ? (alignId === 'RIGHTEOUS' ? 'ประมุขสมาพันธ์คุณธรรมฝ่ายธรรมะ' : 'ประมุขสูงสุดภาคีมารครองภพฝ่ายอธรรม')
              : null;
          });
        }
        const master = leader && leader.figures ? leader.figures.master : null;
        const doc = master ? X.computeFigureDoctrine(master) : (alignId === 'DEMONIC' ? X.ALLIANCE_DOCTRINES.HAWK_CRUSADE : X.ALLIANCE_DOCTRINES.ORTHODOX_INQUISITION);
        if (alignId === 'RIGHTEOUS') gp.righteousLeaderCodeId = leader ? leader.canonicalId : 'FAC_CELESTIAL_SWORD_SACRED';
        if (alignId === 'DEMONIC') gp.demonicLeaderCodeId = leader ? leader.canonicalId : 'FAC_NETHER_BLOOD_SACRED';
        gp.alliances[alignId] = {
          alignment: alignId,
          nameTh: X.ALIGNMENT_DEFS[alignId].fullTh,
          hasSupremeLeader: true,
          leaderSectId: leader ? leader.id : null,
          leaderSectCodeId: leader ? leader.canonicalId : null,
          leaderSectNameTh: leader ? leader.nameTh : '-',
          leaderMasterId: master ? master.id : null,
          leaderMasterNameTh: master ? master.titleAndNameTh : (leader ? leader.leaderNameTh : '-'),
          doctrineId: doc.id,
          doctrineNameTh: doc.nameTh,
          doctrineBadgeTh: doc.badgeTh,
          doctrineDescTh: doc.descTh,
          clashChanceMod: doc.clashChanceMod,
          warProbMod: doc.warProbMod,
          tradeBonusMult: doc.tradeBonusMult,
          memberCount: members.length,
          totalPower: +members.reduce((sum, m) => sum + (m.power || 1), 0).toFixed(2)
        };
      }
    });
    return gp.alliances;
  };

  X.tickAllianceCouncil = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    const alliances = X.evaluateAllianceLeadership(W);
    const all = W.world.allSects || [];
    const alignId = opts.alignment || (((W.day || 360) % 2 === 0) ? 'RIGHTEOUS' : 'DEMONIC');
    const gp = W.world.grandPolitics || (W.world.grandPolitics = {});
    gp.lastCouncilDayByAlignment = gp.lastCouncilDayByAlignment || {};
    const curDay = W.day || 360;
    if (!opts.force && gp.lastCouncilDayByAlignment[alignId] === curDay) {
      return { ok: false, reason: 'already-convened-today', alignment: alignId };
    }
    const members = all.filter(s => s && s.alignment === alignId && !s.isVassal);
    if (members.length < 2) return null;
    gp.lastCouncilDayByAlignment[alignId] = curDay;

    const leader = members.find(s => s.isAllianceLeader) || members[0];
    const leaderMaster = leader.figures && leader.figures.master;
    const challengers = members.filter(s => s.id !== leader.id).sort((a, b) => ((b.power || 1) * (b.tierLevel || 1)) - ((a.power || 1) * (a.tierLevel || 1)));
    const topChallenger = challengers[0];
    const chalMaster = topChallenger && topChallenger.figures && topChallenger.figures.master;

    // Check if an ambitious challenger sect challenges the current Alliance Leader for faction supremacy!
    const chalAmb = chalMaster ? figTrait(chalMaster, 'personality.ambition') : 50;
    const canChallengeLeadership = opts.forceLeadershipChallenge || (
      topChallenger &&
      chalMaster &&
      chalAmb >= 64 &&
      ((topChallenger.power || 1) >= (leader.power || 1) * 0.92 || (topChallenger.tierLevel || 1) >= 5)
    );

    if (canChallengeLeadership && topChallenger && chalMaster && leaderMaster) {
      const chalScore = (topChallenger.power || 1) * 180 + chalMaster.power * (1 + chalAmb / 200);
      const leadScore = (leader.power || 1) * 185 + leaderMaster.power * (1 + figTrait(leaderMaster, 'personality.pride') / 220);
      const challengerWins = opts.forceChallengerWin === true ? true : opts.forceChallengerWin === false ? false : (chalScore > leadScore);

      if (challengerWins) {
        leader.isAllianceLeader = false;
        leader.allianceTitleTh = null;
        topChallenger.isAllianceLeader = true;
        topChallenger.tierLevel = Math.max(topChallenger.tierLevel || 5, 6);
        topChallenger.sectTier = 'SACRED_LAND';
        topChallenger.tierNameTh = X.SECT_TIER_DEFS.SACRED_LAND.nameTh;
        topChallenger.tierBadgeTh = X.SECT_TIER_DEFS.SACRED_LAND.badgeTh;
        X.evaluateAllianceLeadership(W);

        const chron = X.recordChronicle(W, {
          category: 'FACTION',
          icon: '👑',
          macroRegion: topChallenger.macroRegion,
          involvedSects: [topChallenger.nameTh, leader.nameTh],
          involvedFigures: [chalMaster.titleAndNameTh, leaderMaster.titleAndNameTh],
          titleTh: 'เปลี่ยนขั้วประมุข' + X.ALIGNMENT_DEFS[alignId].nameTh + '! 「' + topChallenger.nameTh + '」โค่นบัลลังก์ผู้นำฝ่าย',
          storyTh: 'กลางสภาใหญ่แห่ง' + X.ALIGNMENT_DEFS[alignId].fullTh + ' เจ้าสำนัก「' + chalMaster.titleAndNameTh + '」แห่ง「' + topChallenger.nameTh + '」ผู้มีความทะเยอทะยานสูง (' + Math.round(chalAmb) + ') ได้ก้าวออกท้าประลองชิงตราประมุขฝ่ายจาก「' + leaderMaster.titleAndNameTh + '」แห่ง「' + leader.nameTh + '」! การปะทะด้วย「' + chalMaster.signatureTechNameTh + '」และ' + chalMaster.weaponNameTh + 'สั่นสะเทือนขุนเขา ในที่สุด「' + chalMaster.fullNameTh + '」เป็นฝ่ายคว้าชัย ก้าวขึ้นเป็นประมุข' + X.ALIGNMENT_DEFS[alignId].nameTh + 'คนใหม่ และประกาศใช้นโยบาย「' + chalMaster.doctrineNameTh + '」ชี้นำทั่วทั้งฝ่าย!',
          combatBreakdownTh: 'ผู้ท้าชิง ' + chalMaster.fullNameTh + ' (พลังรวม ' + Math.round(chalScore) + ') เอาชนะ ประมุขเดิม ' + leaderMaster.fullNameTh + ' (' + Math.round(leadScore) + ')',
          consequenceTh: topChallenger.nameTh + ' ขึ้นเป็นประมุข' + X.ALIGNMENT_DEFS[alignId].nameTh + ' · แนวทางฝ่ายเปลี่ยนเป็น「' + chalMaster.doctrineNameTh + '」!',
          quiet: opts.quiet
        });
        return { ok: true, kind: 'LEADERSHIP_CHANGE', alignment: alignId, newLeaderSect: topChallenger, oldLeaderSect: leader, chronicle: chron };
      }
    }

    // Standard Council Resolution driven by Leader's Doctrine & Sect Master voting
    const alInfo = alliances[alignId];
    const doc = X.ALLIANCE_DOCTRINES[alInfo.doctrineId] || X.ALLIANCE_DOCTRINES.ORTHODOX_INQUISITION;
    let ayeVotes = 0, nayVotes = 0;
    const ayeNames = [], nayNames = [];
    members.forEach(m => {
      const mm = m.figures && m.figures.master;
      if (!mm) return;
      const mDoc = X.computeFigureDoctrine(mm);
      const agrees = (m.id === leader.id) || (mDoc.id === doc.id) || (doc.id === 'HAWK_CRUSADE' && figTrait(mm, 'personality.aggression') >= 52) || (doc.id === 'DOVE_HARMONY' && figTrait(mm, 'personality.empathy') >= 50) || figTrait(mm, 'personality.loyalty') >= 55;
      if (agrees) { ayeVotes++; ayeNames.push(m.nameTh); }
      else { nayVotes++; nayNames.push(m.nameTh); }
    });

    const oppAlign = alignId === 'RIGHTEOUS' ? 'DEMONIC' : 'RIGHTEOUS';
    const oppSects = all.filter(s => s && s.alignment === oppAlign);
    const targetOpp = oppSects[(W.day || 0) % Math.max(1, oppSects.length)];

    let resolutionTitleTh = '';
    let storyTh = '';
    let consequenceTh = '';
    if (doc.id === 'HAWK_CRUSADE' && targetOpp) {
      leader.power = +((leader.power || 2) + 0.08).toFixed(2);
      targetOpp.power = +(Math.max(0.5, (targetOpp.power || 1.5) - 0.06)).toFixed(2);
      resolutionTitleTh = 'สภา' + X.ALIGNMENT_DEFS[alignId].nameTh + 'ลงมติสายเหยี่ยว: ระดมพลกดดัน「' + targetOpp.nameTh + '」';
      storyTh = 'ประมุขฝ่าย「' + (leaderMaster ? leaderMaster.titleAndNameTh : leader.nameTh) + '」แห่ง「' + leader.nameTh + '」เปิดประชุมสภาเจ้าสำนัก' + X.ALIGNMENT_DEFS[alignId].nameTh + ' ผลักดันมติ「' + doc.nameTh + '」(เห็นชอบ ' + ayeVotes + ' สำนัก / คัดค้าน ' + nayVotes + ' สำนัก) สั่งการให้สำนักสมาชิกส่งยอดฝีมือออกลาดตระเวนและกดดันเขตแดนของ「' + targetOpp.nameTh + '」อย่างหนัก!';
      consequenceTh = 'โอกาสปะทะนอกสำนักเพิ่มขึ้น (+16%) · ' + leader.nameTh + ' ขยายอิทธิพลรบ';
    } else if (doc.id === 'DOVE_HARMONY') {
      members.forEach(m => { m.influence = (m.influence || 60) + 4; });
      resolutionTitleTh = 'สภา' + X.ALIGNMENT_DEFS[alignId].nameTh + 'ลงมติสายพิราบ: เปิดชุมนุมแลกเปลี่ยนคัมภีร์และผ่อนปรนศึก';
      storyTh = 'ด้วยอุปนิสัยใฝ่สันติของประมุขฝ่าย「' + (leaderMaster ? leaderMaster.titleAndNameTh : leader.nameTh) + '」แห่ง「' + leader.nameTh + '」ที่ประชุมสภาเจ้าสำนักมีมติ (' + ayeVotes + ' ต่อ ' + nayVotes + ' เสียง) ให้จัดตั้งข้อตกลงลดการปะทะและเปิดแลกเปลี่ยนอรรถาธิบายยุทธ์ระหว่างสำนักสมาชิก เพื่อสั่งสมตบะและฟื้นฟูกำลังพล';
      consequenceTh = 'สำนักในสังกัด' + X.ALIGNMENT_DEFS[alignId].nameTh + 'ได้รับอิทธิพลบารมี +4 และลดความตึงเครียดศึกสายเลือด';
    } else if (doc.id === 'MERCHANT_HEGEMONY') {
      members.forEach(m => { m.power = +((m.power || 1) + 0.04).toFixed(2); });
      resolutionTitleTh = 'สภา' + X.ALIGNMENT_DEFS[alignId].nameTh + 'ลงมติสายพาณิชย์: ขยายเส้นทางคาราวานและกองทุนศิลาวิญญาณ';
      storyTh = 'ประมุขฝ่าย「' + (leaderMaster ? leaderMaster.titleAndNameTh : leader.nameTh) + '」ใช้นโยบาย「' + doc.nameTh + '」รวบรวมเสียงเจ้าสำนัก (' + ayeVotes + ':' + nayVotes + ') จัดตั้งขบวนคาราวานคุ้มกันร่วมและแบ่งปันผลประโยชน์ศิลาวิญญาณ ทำให้ทุกสำนักในฝ่ายมั่งคั่งขึ้นอย่างรวดเร็ว';
      consequenceTh = 'กำลังสำนักในฝ่ายเพิ่มขึ้น +0.04 และผลตอบแทนการค้าเพิ่มขึ้น +38%';
    } else {
      resolutionTitleTh = 'สภา' + X.ALIGNMENT_DEFS[alignId].nameTh + 'ประกาศมติ「' + doc.nameTh + '」';
      storyTh = 'ประมุขฝ่าย「' + (leaderMaster ? leaderMaster.titleAndNameTh : leader.nameTh) + '」แห่ง「' + leader.nameTh + '」เรียกประชุมเจ้าสำนักทั้ง ' + members.length + ' แห่งของ' + X.ALIGNMENT_DEFS[alignId].nameTh + ' ลงมติ (' + ayeVotes + ':' + nayVotes + ') บังคับใช้แนวทาง「' + doc.nameTh + '」(' + doc.descTh + ')' + (nayNames.length ? (' แม้เจ้าสำนักจาก ' + nayNames.slice(0, 2).join(', ') + ' จะแสดงความเห็นต่างในที่ประชุมก็ตาม') : '');
      consequenceTh = 'แนวทาง「' + doc.nameTh + '」มีผลบังคับใช้ทั่วทั้ง' + X.ALIGNMENT_DEFS[alignId].nameTh;
    }

    const chron = X.recordChronicle(W, {
      category: 'FACTION',
      icon: doc.icon,
      macroRegion: leader.macroRegion,
      involvedSects: [leader.nameTh].concat(nayNames.slice(0, 2)),
      involvedFigures: leaderMaster ? [leaderMaster.titleAndNameTh] : [],
      titleTh: resolutionTitleTh,
      storyTh,
      combatBreakdownTh: 'มติสภาเจ้าสำนัก: เห็นชอบ ' + ayeVotes + ' สำนัก · คัดค้าน ' + nayVotes + ' สำนัก · ผู้นำฝ่าย: ' + (leaderMaster ? leaderMaster.titleAndNameTh : leader.nameTh),
      consequenceTh,
      quiet: opts.quiet
    });

    return { ok: true, kind: 'COUNCIL_RESOLUTION', alignment: alignId, doctrine: doc, ayeVotes, nayVotes, chronicle: chron };
  };

  /* ---------- Seasonal Ancient Secret Realms & Multi-Sect Ruin Racing ---------- */
  X.SECRET_REALM_TEMPLATES = Object.freeze({
    REALM_EMPEROR_SWORD_TOMB: {
      id: 'REALM_EMPEROR_SWORD_TOMB',
      nameTh: 'สุสานกระบี่จักรพรรดิบรรพกาล',
      icon: '🗡️',
      macroRegion: 'NORTHERN_PEAKS',
      danger: 5,
      guardianNameTh: 'หุ่นศิลาองครักษ์กระบี่หมื่นปี',
      prizeNameTh: 'คัมภีร์มหาเวทกระบี่สวรรค์ & แก่นปฐมธาตุทองคำ',
      stones: 580,
      catalystId: 'CAT_PRIMORDIAL_METAL',
      descTh: 'สุสานโบราณกลางยอดเขาหิมะที่เต็มไปด้วยเจตจำนงกระบี่พันปี เปิดผนึกเพียงชั่วคราวให้ยอดฝีมือทุกสำนักเข้าไปช่วงชิงมรดก!'
    },
    REALM_NINE_NETHER_BLOOD_SEA: {
      id: 'REALM_NINE_NETHER_BLOOD_SEA',
      nameTh: 'วังบาดาลสมุทรโลหิตเก้ายมโลก',
      icon: '🌊',
      macroRegion: 'SOUTHERN_WATERS',
      danger: 5,
      guardianNameTh: 'อสรพิษมังกรสมุทรเก้าเศียร',
      prizeNameTh: 'มุกวิญญาณสมุทรบรรพกาล & คัมภีร์ลับวังบาดาล',
      stones: 620,
      catalystId: 'CAT_PRIMORDIAL_WATER',
      descTh: 'วังโบราณใต้ก้นบึงมังกรหลับที่โผล่พ้นน้ำขึ้นมาพร้อมคลื่นปราณโบราณ สำนักธรรมะและอธรรมต่างส่งยอดคนเข้าแย่งชิง!'
    },
    REALM_PRIMORDIAL_ALCHEMIST_PALACE: {
      id: 'REALM_PRIMORDIAL_ALCHEMIST_PALACE',
      nameTh: 'ตำหนักโอสถเทวะหมื่นกัลป์',
      icon: '⚗️',
      macroRegion: 'CENTRAL_HEARTLAND',
      danger: 4,
      guardianNameTh: 'วิญญาณเตาหลอมอัคคีสวรรค์',
      prizeNameTh: 'โอสถทิพย์ทะลวงขั้นบรรพกาล & ตำรับยาเทวะ',
      stones: 520,
      catalystId: 'CAT_PRIMORDIAL_WOOD',
      descTh: 'ตำหนักเร้นลับของปรมาจารย์ปรุงยายุคบรรพกาล กลิ่นหอมของโอสถหมื่นปีดึงดูดทั้งศิษย์เอกและผู้บำเพ็ญในตำนานให้เข้ามาประหัตประหาร!'
    },
    REALM_ASTRAL_GOD_RUINS: {
      id: 'REALM_ASTRAL_GOD_RUINS',
      nameTh: 'ซากวิหารดาราจักรเทพโบราณ',
      icon: '☄️',
      macroRegion: 'WESTERN_BADLANDS',
      danger: 5,
      guardianNameTh: 'เทวรูปสุริยันเพลิงผลาญกัลป์',
      prizeNameTh: 'ศาสตราเทพดาราจักร & แก่นสุริยธาตุหยาง',
      stones: 680,
      catalystId: 'CAT_PRIMORDIAL_FIRE',
      rewardMatIds: ['MAT_V222_BP_21', 'MAT_V222_BP_22', 'MAT_V222_BP_17'],
      rewardRecipeIds: ['REC_V222_EQ_17', 'REC_V222_EQ_21', 'REC_V222_EQ_23'],
      rewardTechIds: ['TECH_V222_17', 'TECH_V222_18'],
      descTh: 'วิหารเทพโบราณที่จมอยู่ใต้พายุทรายเพลิงผุดขึ้นรับแสงดาวตก ยอดคนทั่วหล้าต่างมุ่งหน้าเข้าชิงมรดกเทพ!'
    },
    REALM_THUNDER_ZITHER_SANCTUARY: {
      id: 'REALM_THUNDER_ZITHER_SANCTUARY',
      nameTh: 'ตำหนักพิณอสนีเก้าสวรรค์',
      icon: '⚡',
      macroRegion: 'EASTERN_PLAINS',
      danger: 5,
      guardianNameTh: 'พญากระเรียนพายุและกระทิงราชันอสนี',
      prizeNameTh: 'คัมภีร์คีตเวทย์สายฟ้าสวรรค์ & แก่นอสนีม่วง',
      stones: 640,
      catalystId: 'CAT_PRIMORDIAL_METAL',
      rewardMatIds: ['MAT_V222_BP_05', 'MAT_V222_BP_06', 'MAT_V222_BP_13', 'MAT_V222_BP_14'],
      rewardRecipeIds: ['REC_V222_EQ_02', 'REC_V222_EQ_08', 'REC_V222_EQ_15', 'REC_V222_EQ_16'],
      rewardTechIds: ['TECH_V222_11', 'TECH_V222_12', 'TECH_V222_14', 'TECH_V222_22', 'TECH_V222_23'],
      descTh: 'ตำหนักลอยฟ้ากลางทุ่งบูรพาที่เปิดออกยามพายุสายฟ้าฟาด เก็บรักษาสุดยอดคัมภีร์สายฟ้า วายุ และพิณสวรรค์!'
    },
    REALM_FROST_BLOOD_BEAST_ABYSS: {
      id: 'REALM_FROST_BLOOD_BEAST_ABYSS',
      nameTh: 'ห้วงเหวราชันอสูรเหมันต์โลหิต',
      icon: '🐉',
      macroRegion: 'NORTHERN_PEAKS',
      danger: 5,
      guardianNameTh: 'ราชันมังกรสมุทรโลหิตและวาฬเหมันต์บรรพกาล',
      prizeNameTh: 'มรดกราชันอสูรเหมันต์โลหิต & แก่นอสูรบรรพกาล',
      stones: 700,
      catalystId: 'CAT_PRIMORDIAL_WATER',
      rewardMatIds: ['MAT_V222_BP_01', 'MAT_V222_BP_03', 'MAT_V222_BP_07', 'MAT_V222_BP_11', 'MAT_V222_BP_23', 'MAT_V222_BP_24'],
      rewardRecipeIds: ['REC_V222_EQ_01', 'REC_V222_EQ_03', 'REC_V222_EQ_06', 'REC_V222_EQ_11', 'REC_V222_EQ_18', 'REC_V222_EQ_24'],
      rewardTechIds: ['TECH_V222_01', 'TECH_V222_03', 'TECH_V222_05', 'TECH_V222_06', 'TECH_V222_19', 'TECH_V222_21'],
      descTh: 'รอยแยกใต้ยอดเขาเหมันต์ที่ปราณโลหิตอสูรและไอเย็นบรรพกาลปะทะกัน แหล่งกำเนิดชิ้นส่วนอสูรและวิชาสายโลหิต-เหมันต์ในตำนาน!'
    }
  });

  X.spawnSecretRealm = (W, tplId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    X.ensureWanderingLegends(W);
    if (!Array.isArray(W.world.secretRealms)) W.world.secretRealms = [];

    const keys = Object.keys(X.SECRET_REALM_TEMPLATES);
    const chosenKey = (tplId && X.SECRET_REALM_TEMPLATES[tplId]) ? tplId : keys[(W.day || 0) % keys.length];
    const tpl = X.SECRET_REALM_TEMPLATES[chosenKey];

    // Pick 3 external sects + 1 wandering legend to autonomously enter the race
    const allSects = (W.world.allSects || []).slice().sort((a, b) => (b.power || 1) - (a.power || 1));
    const entrants = [];
    const pickedSects = [];
    const rSect = allSects.find(s => s.alignment === 'RIGHTEOUS');
    const dSect = allSects.find(s => s.alignment === 'DEMONIC');
    const nSect = allSects.find(s => s.alignment === 'NEUTRAL');
    [rSect, dSect, nSect].filter(Boolean).forEach(s => {
      if (!pickedSects.includes(s)) pickedSects.push(s);
    });
    allSects.forEach(s => {
      if (pickedSects.length < 4 && !pickedSects.includes(s)) pickedSects.push(s);
    });

    pickedSects.slice(0, 3).forEach((s, i) => {
      const topCore = (s.figures && Array.isArray(s.figures.coreDisciples)) ? s.figures.coreDisciples.find(c => c && !c.dead) : null;
      const fig = (i === 0 && s.figures && s.figures.warMarshal && !s.figures.warMarshal.dead)
        ? s.figures.warMarshal
        : (i === 2 && topCore)
        ? topCore
        : (s.figures && (s.figures.successor || s.figures.deputy || s.figures.master));
      if (fig && !fig.dead) {
        entrants.push({
          entrantType: 'SECT_FIGURE',
          sectId: s.id,
          sectNameTh: s.nameTh,
          alignment: s.alignment,
          figureId: fig.id,
          nameTh: fig.titleAndNameTh,
          roleTh: fig.roleTh,
          weaponNameTh: fig.weaponNameTh,
          signatureTechNameTh: fig.signatureTechNameTh,
          doctrineId: fig.doctrineId,
          power: fig.power
        });
      }
    });

    const activeLeg = (W.world.wanderingLegends || []).find(l => l && !l.dead);
    if (activeLeg) {
      entrants.push({
        entrantType: 'WANDERING_LEGEND',
        sectId: null,
        sectNameTh: 'ยอดคนพเนจรไร้สังกัด',
        alignment: activeLeg.alignment,
        figureId: activeLeg.id,
        nameTh: activeLeg.titleAndNameTh,
        roleTh: activeLeg.roleTh,
        weaponNameTh: activeLeg.weaponNameTh,
        signatureTechNameTh: activeLeg.signatureTechNameTh,
        doctrineId: activeLeg.doctrineId,
        power: activeLeg.power
      });
    }

    // Autonomous Player Sect expedition entrant (chosen from top combat-ready disciples/elders)
    const playerAlive = (W.npcs || []).filter(n => n && !n.dead && !n.exiled && !n.away).sort((a, b) => CULT.power(b) - CULT.power(a));
    if (playerAlive.length) {
      const pLead = playerAlive[0];
      const pTeam = playerAlive.slice(0, Math.min(3, playerAlive.length));
      const pPower = Math.round(pTeam.reduce((sum, m) => sum + CULT.power(m), 0) * 0.85);
      entrants.push({
        entrantType: 'PLAYER_SECT',
        sectId: 'PLAYER',
        sectNameTh: 'สำนัก' + (W.sect && W.sect.name ? W.sect.name : 'ของเรา'),
        alignment: (W.sect && W.sect.alignment) || 'NEUTRAL',
        npcIds: pTeam.map(m => m.id),
        nameTh: HC.fullName(pLead) + (pTeam.length > 1 ? (' และคณะศิษย์รวม ' + pTeam.length + ' คน') : ''),
        roleTh: SECT.title ? SECT.title(pLead) : 'ตัวแทนสำนัก',
        weaponNameTh: (pLead.equip && pLead.equip.WEAPON && pLead.equip.WEAPON.nameTh) || 'ศาสตราประจำกาย',
        signatureTechNameTh: 'เคล็ดวิชาประจำสำนัก',
        doctrineId: 'PLAYER',
        power: pPower
      });
    }

    W.world.secretRealmSeq = (W.world.secretRealmSeq || 0) + 1;
    const realm = {
      id: 'SREALM_' + (W.day || 360) + '_' + W.world.secretRealmSeq,
      templateId: tpl.id,
      nameTh: tpl.nameTh,
      icon: tpl.icon,
      macroRegion: tpl.macroRegion,
      danger: tpl.danger,
      guardianNameTh: tpl.guardianNameTh,
      prizeNameTh: tpl.prizeNameTh,
      stones: tpl.stones,
      catalystId: tpl.catalystId,
      descTh: tpl.descTh,
      openedDay: W.day || 360,
      expiresDay: (W.day || 360) + 12,
      status: 'OPEN',
      entrants,
      stageReports: [],
      winner: null
    };
    W.world.secretRealms.unshift(realm);
    if (W.world.secretRealms.length > 20) W.world.secretRealms.length = 20;

    if (!opts.quiet) {
      X.recordChronicle(W, {
        category: 'SECRET_REALM',
        icon: tpl.icon,
        macroRegion: tpl.macroRegion,
        involvedSects: entrants.map(e => e.sectNameTh),
        involvedFigures: entrants.map(e => e.nameTh),
        titleTh: 'แดนลับโบราณคลายผนึก: 「' + tpl.nameTh + '」ปรากฏขึ้น!',
        storyTh: tpl.descTh + ' ขบวนยอดฝีมือและศิษย์สืบทอดที่มุ่งหน้าเข้าสู่แดนลับได้แก่: ' + entrants.map(e => e.nameTh + ' (' + e.sectNameTh + ')').join(', ') + '!',
        consequenceTh: 'ศึกชิงมรดกเซียน 3 ด่านเริ่มต้นขึ้นแล้ว!'
      });
    }
    return realm;
  };

  X.resolveSecretRealmRace = (W, realmOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    X.ensureWanderingLegends(W);
    if (!Array.isArray(W.world.secretRealms)) W.world.secretRealms = [];

    let realm = null;
    if (typeof realmOrId === 'object' && realmOrId) {
      if (realmOrId.status && realmOrId.status !== 'OPEN') {
        return { ok: false, reason: 'already-resolved', realm: realmOrId };
      }
      if (!W.world.secretRealms.includes(realmOrId)) {
        return { ok: false, reason: 'realm-not-found' };
      }
      realm = realmOrId;
    } else if (realmOrId) {
      const existingAny = W.world.secretRealms.find(r => r && (r.id === realmOrId || r.templateId === realmOrId));
      if (existingAny && existingAny.status !== 'OPEN') {
        return { ok: false, reason: 'already-resolved', realm: existingAny };
      }
      realm = existingAny || (X.SECRET_REALM_TEMPLATES[realmOrId] ? X.spawnSecretRealm(W, realmOrId, { quiet: true }) : null);
    } else {
      realm = W.world.secretRealms.find(r => r && r.status === 'OPEN') || X.spawnSecretRealm(W, null, { quiet: true });
    }
    if (!realm || realm.status !== 'OPEN' || !Array.isArray(realm.entrants) || !realm.entrants.length) {
      return { ok: false, reason: 'no-realm' };
    }

    // Re-evaluate live entrant survival & power (EX-06)
    const liveEntrants = [];
    for (const e of realm.entrants) {
      if (!e) continue;
      if (e.entrantType === 'PLAYER_SECT') {
        const aliveMembers = (e.npcIds || []).map(id => W.byId && W.byId[id]).filter(m => m && !m.dead && !m.exiled);
        if (!aliveMembers.length) continue;
        e.npcIds = aliveMembers.map(m => m.id);
        e.power = Math.round(aliveMembers.reduce((sum, m) => sum + CULT.power(m), 0) * 0.85);
        liveEntrants.push(e);
      } else if (e.figureId) {
        const fig = W.world.figuresById && W.world.figuresById[e.figureId];
        if (fig && fig.dead) continue;
        liveEntrants.push(e);
      } else {
        liveEntrants.push(e);
      }
    }
    if (!liveEntrants.length) {
      realm.status = 'EXPIRED';
      return { ok: false, reason: 'no-living-entrants', realm };
    }

    const rng = makeChildRng(W, 'resolve_realm_' + realm.id + '_' + (W.day || 360));
    const stage1Log = '【ด่านที่ 1 · ฝ่าค่ายกลโบราณชั้นนอก】 คณะผู้ท้าชิงทั้ง ' + liveEntrants.length + ' ฝ่ายทะลวงม่านค่ายกลพันปีของ「' + realm.nameTh + '」เข้าสู่โถงกลางสำเร็จ';
    const stage2Log = '【ด่านที่ 2 · ปะทะ' + realm.guardianNameTh + '】 ยอดฝีมือแต่ละสำนักสำแดงเคล็ดวิชาฟาดฟันกับ「' + realm.guardianNameTh + '」จนปราการโบราณพังทลาย เผยให้เห็นแท่นมรดก「' + realm.prizeNameTh + '」!';

    // Score each entrant in Stage 3 (Inner Sanctum Inheritance Duel)
    const scored = liveEntrants.map(e => {
      const roll = 0.85 + rng.next() * 0.35;
      const bonus = (opts.forcePlayerWin && e.entrantType === 'PLAYER_SECT') ? 999999 : 0;
      return { entrant: e, finalScore: Math.round(e.power * roll + bonus) };
    }).sort((a, b) => b.finalScore - a.finalScore);

    const winEntry = scored[0].entrant;
    const runnerUp = scored[1] ? scored[1].entrant : winEntry;
    let casualtyResult = null;

    // Check if the clash between Winner and Runner-Up is lethal (especially if Hawk or Opposite Alignment!)
    const isHawkOrOpposite = winEntry.doctrineId === 'HAWK_CRUSADE' ||
      (winEntry.alignment === 'RIGHTEOUS' && runnerUp.alignment === 'DEMONIC') ||
      (winEntry.alignment === 'DEMONIC' && runnerUp.alignment === 'RIGHTEOUS');

    if (runnerUp && runnerUp !== winEntry && runnerUp.figureId && (opts.forceLethalClash || (isHawkOrOpposite && rng.chance(0.42)))) {
      casualtyResult = X.killJianghuFigure(W, runnerUp.figureId, 'ถูก「' + winEntry.nameTh + '」สังหารในการชิงมรดกห้องชั้นในของ「' + realm.nameTh + '」', { quiet: true });
    }

    if (winEntry.entrantType === 'PLAYER_SECT') {
      const realmStones = realm.stones || 500;
      if (ECO) {
        if (ECO.earnFromPool) ECO.earnFromPool(W, realmStones, 'คว้าชัยศึกชิงมรดกแดนลับ「' + realm.nameTh + '」');
        else if (ECO.earn) ECO.earn(W, realmStones, 'คว้าชัยศึกชิงมรดกแดนลับ「' + realm.nameTh + '」');
      }
      if (realm.catalystId && ECO && ECO.addCatalyst) ECO.addCatalyst(W, realm.catalystId, 1);
      const rTpl = X.SECRET_REALM_TEMPLATES[realm.templateId] || {};
      if (Array.isArray(rTpl.rewardMatIds) && ECO && ECO.add) {
        rTpl.rewardMatIds.slice(0, 2).forEach(mId => ECO.add(W, mId, 2));
      }
      if (Array.isArray(rTpl.rewardRecipeIds) && W.sect) {
        W.sect.knownRecipes = W.sect.knownRecipes || [];
        rTpl.rewardRecipeIds.forEach(rId => { if (!W.sect.knownRecipes.includes(rId)) W.sect.knownRecipes.push(rId); });
      }
      if (Array.isArray(rTpl.rewardTechIds) && W.sect) {
        W.sect.library = W.sect.library || [];
        const pickTech = rTpl.rewardTechIds.find(tId => !W.sect.library.includes(tId)) || rTpl.rewardTechIds[0];
        if (pickTech && !W.sect.library.includes(pickTech)) W.sect.library.push(pickTech);
      }
      W.fame(6);
      (winEntry.npcIds || []).forEach(id => {
        const m = W.byId[id];
        if (m && !m.dead) { m.merit = (m.merit || 0) + 28; if (m.cult) CULT.gain(m, 35, W, 'secret_realm_win'); }
      });
    } else if (winEntry.sectId) {
      const winSect = X.findSect(W, winEntry.sectId);
      if (winSect) {
        winSect.power = +((winSect.power || 1.2) + 0.18).toFixed(2);
        winSect.influence = (winSect.influence || 60) + 14;
      }
      if (winEntry.figureId && W.world.figuresById && W.world.figuresById[winEntry.figureId]) {
        const wFig = W.world.figuresById[winEntry.figureId];
        if (!wFig.dead) {
          if (wFig.cult) wFig.cult.stage = Math.min(9, (wFig.cult.stage || 3) + 1);
          wFig.power = Math.round((wFig.power || 260) * 1.18);
          wFig.backingBonus = (wFig.backingBonus || 0) + 10;
        }
      }
    }

    const stage3Log = '【ด่านที่ 3 · ศึกชิงมรดกห้องชั้นใน】 เกิดการปะทะดุเดือดหน้าแท่นมรดกระหว่าง「' + winEntry.nameTh + '」(' + winEntry.sectNameTh + ') กับ「' + runnerUp.nameTh + '」(' + runnerUp.sectNameTh + ')! ' +
      winEntry.nameTh + ' สำแดงวิชา「' + winEntry.signatureTechNameTh + '」ควบคู่กับ' + winEntry.weaponNameTh + ' บดขยี้คู่ต่อสู้และคว้า「' + realm.prizeNameTh + '」ไปครองได้สำเร็จ!' +
      (casualtyResult && casualtyResult.slainFigure ? (' ท่ามกลางศึกอำมหิต「' + casualtyResult.slainFigure.titleAndNameTh + '」พลาดท่าถูกสังหารสิ้นชีพคาแดนลับ!') : '');

    realm.stageReports = [stage1Log, stage2Log, stage3Log];
    realm.status = 'RESOLVED';
    realm.resolvedDay = W.day || 360;
    realm.winner = winEntry;
    realm.runnerUp = runnerUp;
    realm.casualtyResult = casualtyResult;

    const chron = X.recordChronicle(W, {
      category: 'SECRET_REALM',
      icon: realm.icon || '🌌',
      macroRegion: realm.macroRegion,
      involvedSects: [winEntry.sectNameTh, runnerUp.sectNameTh],
      involvedFigures: [winEntry.nameTh, runnerUp.nameTh],
      titleTh: 'ศึกชิงแดนลับ「' + realm.nameTh + '」ยุติ! ' + winEntry.nameTh + ' คว้ามรดกเซียน',
      storyTh: stage1Log + ' ' + stage2Log + ' ' + stage3Log,
      combatBreakdownTh: 'ผู้ชนะ: ' + winEntry.nameTh + ' (พลังปะทะ ' + scored[0].finalScore + ') เหนือกว่า ' + runnerUp.nameTh + ' (' + (scored[1] ? scored[1].finalScore : 0) + ')',
      consequenceTh: 'รางวัลมรดก「' + realm.prizeNameTh + '」ตกเป็นของ ' + winEntry.sectNameTh + (casualtyResult && casualtyResult.succession ? (' · เกิดการผลัดเปลี่ยนเจ้าสำนักคนใหม่ที่ ' + casualtyResult.succession.sect.nameTh + '!') : casualtyResult && casualtyResult.reemergence ? (' · ยอดคนในตำนานคนใหม่「' + casualtyResult.reemergence.newLegend.titleAndNameTh + '」ปรากฏกายขึ้นแทนที่!') : ''),
      quiet: opts.quiet
    });

    return { ok: true, realm, winner: winEntry, runnerUp, casualtyResult, chronicle: chron };
  };

  /* ---------- Autonomous Visitors 2.0 (ทูตสำนัก, ผู้ลี้ภัยศึก, ยอดคนในตำนานแวะเยือน, สายลับแฝงตัว) ---------- */
  X.tickAutonomousVisitorsV2 = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world || !W.sect) return null;
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    X.ensureWanderingLegends(W);

    const rng = makeChildRng(W, 'visitor_v2_' + (W.day || 360) + '_' + (opts.kind || 'auto'));
    const kinds = ['ENVOY_DELEGATION', 'WAR_REFUGEE_PRODIGY', 'VISITING_WANDERING_LEGEND', 'COVERT_INFILTRATOR'];
    const kind = opts.kind && kinds.includes(opts.kind) ? opts.kind : rng.pick(kinds);

    const master = (W.byId && W.sect.masterId && W.byId[W.sect.masterId]) || (W.npcs && W.npcs.find(n => n && !n.dead));
    const envoyOfficer = (SECT && SECT.holder && SECT.holder(W, 'envoy')) || master;
    const spyOfficer = (SECT && SECT.holder && SECT.holder(W, 'spymaster')) || (SECT && SECT.holder && SECT.holder(W, 'censor')) || master;
    const allSects = W.world.allSects || [];
    const targetSect = allSects[(W.day || 0) % Math.max(1, allSects.length)];

    let titleTh = '', storyTh = '', consequenceTh = '', outcome = '';

    if (kind === 'ENVOY_DELEGATION' && targetSect) {
      const fig = (targetSect.figures && targetSect.figures.deputy) || (targetSect.figures && targetSect.figures.master);
      const dipSkill = envoyOfficer ? ((envoyOfficer.h.skills.diplomacy || 0) + HC.eff(envoyOfficer, 'social.charisma')) : 90;
      const wantGift = Math.round(65 + (targetSect.tierLevel || 2) * 28);
      if (dipSkill >= 85 || HC.eff(envoyOfficer || master, 'personality.empathy') >= 48) {
        targetSect.attitude = clamp((targetSect.attitude || 0) + 10, -100, 100);
        const giftStones = (ECO && ECO.earnFromPool)
          ? ECO.earnFromPool(W, wantGift, 'ของกำนัลเชื่อมไมตรีจากคณะทูต' + targetSect.nameTh, { rivalSect: targetSect })
          : ((ECO && ECO.earn && ECO.earn(W, wantGift, 'ของกำนัลเชื่อมไมตรีจากคณะทูต' + targetSect.nameTh)) ? wantGift : 0);
        outcome = 'CORDIAL_ACCORD';
        titleTh = 'คณะทูตจาก「' + targetSect.nameTh + '」เดินทางมาเยือนหน้าประตูสำนัก';
        storyTh = '「' + (fig ? fig.titleAndNameTh : targetSect.leaderNameTh) + '」นำคณะทูตจาก「' + targetSect.nameTh + '」(' + targetSect.tierNameTh + ') เดินทางมาเยือนสำนักของเรา 「' + (envoyOfficer ? HC.fullName(envoyOfficer) : 'ผู้แทนสำนัก') + '」ออกต้อนรับและเจรจาด้วยวาจาหลักแหลม จนบรรลุข้อตกลงแลกเปลี่ยนสิ่งของ' + (giftStones > 0 ? ('และมอบศิลาวิญญาณกำนัล ' + giftStones + ' ก้อน!') : 'ด้วยความเคารพซึ่งกันและกัน!');
        consequenceTh = 'ความสัมพันธ์กับ ' + targetSect.nameTh + ' เพิ่มขึ้น +10' + (giftStones > 0 ? (' · ได้รับศิลาวิญญาณ +' + giftStones + ' ก้อน') : '');
      } else {
        targetSect.attitude = clamp((targetSect.attitude || 0) - 6, -100, 100);
        outcome = 'TENSE_STANDOFF';
        titleTh = 'คณะทูตจาก「' + targetSect.nameTh + '」เจรจาตึงเครียดหน้าโถงสำนัก';
        storyTh = 'คณะทูตจาก「' + targetSect.nameTh + '」เดินทางมาเจรจาเรื่องเขตแดนยุทธภพ แต่ด้วยท่าทีแข็งกร้าวของฝ่ายรับรอง ทำให้การเจรจาจบลงด้วยการประชันแรงกดดันปราณก่อนที่คณะทูตจะสะบัดแขนเสื้อกลับไป';
        consequenceTh = 'ความสัมพันธ์กับ ' + targetSect.nameTh + ' ลดลง -6';
      }
    } else if (kind === 'WAR_REFUGEE_PRODIGY' && targetSect) {
      const mEmp = master ? HC.eff(master, 'personality.empathy') : 55;
      const mCaut = master ? HC.eff(master, 'personality.caution') : 50;
      const refugeeFig = targetSect.figures && (targetSect.figures.successor || targetSect.figures.deputy);
      if (mEmp >= mCaut - 10) {
        W.fame(3.5);
        W.sect.alignmentDeedScore = clamp((W.sect.alignmentDeedScore || 0) + 6, -100, 100);
        let recruitedDisciple = null;
        if (refugeeFig && !refugeeFig.dead && !refugeeFig.recruitedToPlayer) {
          const hyd = X.hydrateFigureToNpc(W, refugeeFig, { rank: 2, merit: 20 });
          if (hyd && hyd.ok) recruitedDisciple = hyd.npc;
        }
        const allTechs = (JD && JD.TECH && JD.TECH.techniques) || [];
        const bonusTech = allTechs.find(t => t && !(W.sect.library || []).includes(t.id));
        if (bonusTech && W.sect.library) W.sect.library.push(bonusTech.id);
        outcome = 'SHELTERED_REFUGEE';
        titleTh = 'ยอดศิษย์ผู้ลี้ภัยศึกยุทธภพหนีตายมาขอพึ่งใบบุญหน้าประตูสำนัก!';
        storyTh = 'อดีตยอดฝีมือผู้รอดชีวิตจากการกวาดล้าง「' + (recruitedDisciple ? HC.fullName(recruitedDisciple) : 'ผู้ลี้ภัย') + '」แห่ง「' + targetSect.nameTh + '」โซซัดโซเซมาคุกเข่าหน้าประตูสำนัก「' + W.sect.name + '」ด้วยจิตเมตตาของ「' + (master ? HC.fullName(master) : 'เจ้าสำนัก') + '」จึงสั่งเปิดค่ายกลคุ้มครอง รักษาอาการบาดเจ็บ และรับเข้าเป็นศิษย์ในสำนักทันที! ผู้ลี้ภัยซาบซึ้งคุณธรรมจึงมอบคัมภีร์ยุทธ์ที่ติดตัวมาตอบแทนบุญคุณ!';
        consequenceTh = 'ชื่อเสียงสำนัก +3.5 · คะแนนคุณธรรมฝ่ายธรรมะ +6' + (recruitedDisciple ? (' · ได้รับ ' + HC.fullName(recruitedDisciple) + ' เข้าร่วมสำนัก') : '') + (bonusTech ? (' · ได้รับคัมภีร์「' + bonusTech.nameTh + '」เข้าหอคัมภีร์') : '');
      } else {
        outcome = 'TURNED_AWAY';
        titleTh = 'ปฏิเสธผู้ลี้ภัยศึกยุทธภพเพื่อรักษาความปลอดภัยของสำนัก';
        storyTh = 'มีผู้ฝึกตนที่ถูกสำนักใหญ่ไล่ล่าหนีมาขอพึ่งพิงที่หน้าด่านสำนัก แต่ด้วยความรอบคอบของ「' + (master ? HC.fullName(master) : 'เจ้าสำนัก') + '」เกรงว่าจะชักศึกเข้าบ้าน จึงมอบโอสถรักษาเบื้องต้นแล้วเชิญให้ออกเดินทางต่อไป';
        consequenceTh = 'สำนักรอดพ้นจากความขัดแย้งกับสำนักผู้ไล่ล่า';
      }
    } else if (kind === 'VISITING_WANDERING_LEGEND') {
      const leg = (W.world.wanderingLegends || []).find(l => l && !l.dead) || X.generateWanderingLegend(W);
      const luckyDisciple = (W.npcs || []).find(n => n && !n.dead && n.cult && n.id !== W.sect.masterId) || master;
      if (luckyDisciple && luckyDisciple.cult) {
        CULT.gain(luckyDisciple, 42, W, 'legend_pointer');
      }
      outcome = 'LEGEND_IMPARTS_INSIGHT';
      titleTh = 'ผู้บำเพ็ญในตำนาน「' + leg.titleAndNameTh + '」แวะจิบชาและชี้แนะมรรคาในสำนัก!';
      storyTh = '「' + leg.titleAndNameTh + '」(' + leg.cult.path + ' ขั้น ' + leg.cult.stage + ') ยอดคนพเนจรในตำนานเดินทางผ่านมายังสำนัก「' + W.sect.name + '」และประทับใจในบรรยากาศสวนชา จึงเอ่ยปากชี้แนะเคล็ดวิชา「' + leg.signatureTechNameTh + '」ให้แก่「' + (luckyDisciple ? HC.fullName(luckyDisciple) : 'ศิษย์ในสำนัก') + '」จนเกิดความกระจ่างแจ้งทางตบะก่อนจะเหินกระบี่จากไป!',
      consequenceTh = (luckyDisciple ? HC.fullName(luckyDisciple) : 'ศิษย์สำนัก') + ' ได้รับตบะความเข้าใจพุ่งทะยาน +42 แต้ม!';
    } else {
      // COVERT_INFILTRATOR
      const spySkill = spyOfficer ? ((spyOfficer.h.skills.stealth || 0) + HC.eff(spyOfficer, 'intellect.perceptiveness')) : 95;
      const pol = SECT && SECT.ensureHierarchyAndPolitics ? SECT.ensureHierarchyAndPolitics(W) : null;
      if (spySkill >= 75) {
        if (pol) pol.undercurrent = clamp((pol.undercurrent || 0) - 6, 0, 100);
        W.fame(2.0);
        outcome = 'INFILTRATOR_FOILED';
        titleTh = 'เจ้าหอข่าวกรองเปิดโปงสายลับต่างสำนักที่แฝงตัวเข้ามาในสำนัก!';
        storyTh = 'สายลับจาก「' + (targetSect ? targetSect.nameTh : 'สำนักศัตรู') + '」ปลอมตัวเป็นคนงานแฝงเข้ามาสืบผังค่ายกลและคลังสมบัติ แต่ไม่อาจรอดพ้นสายตาอันเฉียบคมของ「' + (spyOfficer ? HC.fullName(spyOfficer) : 'ผู้ตรวจการสำนัก') + '」ถูกสกัดจับกุมได้คาหนังคาเขาและริบศิลาวิญญาณเข้าคลัง!';
        consequenceTh = 'คลื่นใต้น้ำลดลง -6 · ชื่อเสียงสำนัก +2.0';
      } else {
        if (pol) pol.undercurrent = clamp((pol.undercurrent || 0) + 8, 0, 100);
        outcome = 'INFILTRATOR_ESCAPED';
        titleTh = 'พบร่องรอยสายลับลอบเข้ามาสืบข่าวในเขตสำนักยามวิกาล!';
        storyTh = 'เวรยามตรวจพบร่องรอยเงาร่างลึกลับลอบเข้ามาใกล้หอคัมภีร์และปลุกปั่นข่าวลือในหมู่ศิษย์ แม้จะไล่ล่าจนคนร้ายหนีเตลิดไปได้ แต่ก็ทิ้งความระแวงไว้ในสำนัก';
        consequenceTh = 'คลื่นใต้น้ำในสำนักเพิ่มขึ้น +8';
      }
    }

    const chron = X.recordChronicle(W, {
      category: 'VISITOR',
      icon: '🎐',
      macroRegion: 'CENTRAL_HEARTLAND',
      involvedSects: targetSect ? [targetSect.nameTh, W.sect.name] : [W.sect.name],
      titleTh,
      storyTh,
      consequenceTh,
      quiet: opts.quiet
    });

    if (!Array.isArray(W.world.visitorEventsV2)) W.world.visitorEventsV2 = [];
    const ev = { id: chron.id, day: W.day || 360, kind, outcome, titleTh, storyTh, consequenceTh };
    W.world.visitorEventsV2.unshift(ev);
    if (W.world.visitorEventsV2.length > 25) W.world.visitorEventsV2.length = 25;
    return { ok: true, kind, outcome, event: ev, chronicle: chron };
  };

  /* ---------- Edit Hub Intervention for Jianghu Figures & Wandering Legends ---------- */
  X.interveneJianghuFigure = (W, figOrId, action, payload) => {
    payload = payload || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    X.ensureWanderingLegends(W);

    let fig = typeof figOrId === 'object' && figOrId ? figOrId : (W.world.figuresById && W.world.figuresById[figOrId]);
    if (!fig) {
      const s = X.findSect(W, figOrId);
      if (s && s.figures && s.figures.master) fig = s.figures.master;
    }
    if (!fig) return { ok: false, reason: 'figure-not-found' };

    const act = String(action || 'GIFT_RELIC').toUpperCase();
    const s = fig.sectId ? X.findSect(W, fig.sectId) : null;

    if (act === 'GIFT_RELIC' || act === 'SPAWN_GEAR') {
      const gearName = payload.gearNameTh || ('ศาสตราเทพประทานฟ้า「' + fig.epithetTh + '」');
      fig.weaponNameTh = gearName;
      fig.power = Math.round((fig.power || 300) * 1.28 + 120);
      fig.backingBonus = (fig.backingBonus || 0) + 22;
      if (s) s.power = +((s.power || 1.2) + 0.25).toFixed(2);
      const chron = X.recordChronicle(W, {
        category: 'LEGEND',
        icon: '✨',
        macroRegion: (s && s.macroRegion) || fig.macroRegion || 'CENTRAL_HEARTLAND',
        involvedFigures: [fig.titleAndNameTh],
        titleTh: 'ปาฏิหาริย์ศาสตราประทานฟ้าแก่「' + fig.titleAndNameTh + '」',
        storyTh: 'เกิดลำแสงสีทองพุ่งลงจากฟากฟ้าประทาน「' + gearName + '」และโอสถทิพย์ให้แก่「' + fig.titleAndNameTh + '」(' + fig.roleTh + 'แห่ง' + (fig.sectNameTh || 'ยุทธภพ') + ') ทำให้พลังรบและบารมีหนุนหลังพุ่งทะยานขึ้นอย่างก้าวกระโดด!',
        consequenceTh: fig.fullNameTh + ' พลังรบเพิ่มเป็น ' + fig.power + (fig.role === 'successor' ? ' · แรงหนุนหลังศิษย์สืบทอด +22' : ''),
        quiet: payload.quiet
      });
      return { ok: true, action: act, figure: fig, chronicle: chron };
    } else if (act === 'BOOST_STAGE' || act === 'GIFT_PILL') {
      const maxSt = (CULT && CULT.PATHS && fig.cult && CULT.PATHS[fig.cult.path] && CULT.PATHS[fig.cult.path].maxStage) || 9;
      fig.cult.stage = Math.min(maxSt, (fig.cult.stage || 4) + 1);
      fig.power = Math.round((fig.power || 300) * 1.32 + 150);
      fig.hpMax = Math.round((fig.hpMax || 800) * 1.25);
      fig.hp = fig.hpMax;
      fig.backingBonus = (fig.backingBonus || 0) + 25;
      if (s) s.power = +((s.power || 1.2) + 0.30).toFixed(2);
      const chron = X.recordChronicle(W, {
        category: 'LEGEND',
        icon: '💊',
        macroRegion: (s && s.macroRegion) || fig.macroRegion || 'CENTRAL_HEARTLAND',
        involvedFigures: [fig.titleAndNameTh],
        titleTh: '「' + fig.titleAndNameTh + '」ได้รับโอสถสวรรค์ทะลวงสู่ขั้น ' + fig.cult.stage + '!',
        storyTh: '「' + fig.titleAndNameTh + '」(' + fig.roleTh + 'แห่ง' + (fig.sectNameTh || 'ยุทธภพ') + ') ได้รับโอสถทิพย์ประทานฟ้า ทะลวงคอขวดก้าวขึ้นสู่ตบะขั้น ' + fig.cult.stage + ' ปราณคุ้มกายแผ่พุ่งสะท้านทั่วสำนัก!',
        consequenceTh: fig.fullNameTh + ' เลื่อนเป็นขั้น ' + fig.cult.stage + ' (พลังรบ ' + fig.power + ')',
        quiet: payload.quiet
      });
      return { ok: true, action: act, figure: fig, chronicle: chron };
    } else if (act === 'SMITE' || act === 'SLAY') {
      return X.killJianghuFigure(W, fig, payload.causeTh || 'ทัณฑ์สวรรค์ฟาดผ่ากลางยุทธภพ', { quiet: payload.quiet });
    }
    return { ok: false, reason: 'unknown-action' };
  };


  /* ============================================================================
   * Patch v2.0.21: Grand Jianghu Martial Assembly (งานประลองยุทธภพสิบทิศ)
   * & Heavenly Calamities / Beast Waves (วิกฤตฟ้าพิโรธ & มหาคลื่นอสูรคลั่ง)
   * ============================================================================ */

  X.NAME_POOLS = Object.freeze({
    SURNAMES: FAST_SURNAMES,
    GIVEN_M: FAST_GIVEN_M,
    GIVEN_F: FAST_GIVEN_F
  });

  X.holdGrandMartialAssembly = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    X.ensureWanderingLegends(W);

    const rng = makeChildRng(W, 'martial_assembly_' + (W.day || 360) + '_' + ((W.world.assemblySeq = (W.world.assemblySeq || 0) + 1)));
    const allSects = (W.world.allSects || []).slice().sort((a, b) => (b.tierLevel || 1) - (a.tierLevel || 1) || (b.power || 1) - (a.power || 1));
    const hostSect = allSects[0] || X.CANONICAL_SECTS[0];

    // Assemble 8 Contenders: 6 external sect prodigies/masters + 1 wandering legend + 1 player sect champion
    const contenders = [];
    allSects.slice(0, 6).forEach((s, idx) => {
      const topCore = (s.figures && Array.isArray(s.figures.coreDisciples)) ? s.figures.coreDisciples.find(c => c && !c.dead) : null;
      const fig = (s.figures && (idx % 3 === 0 ? s.figures.successor : idx % 3 === 1 ? (topCore || s.figures.warMarshal || s.figures.successor) : s.figures.master)) || (s.figures && s.figures.master);
      if (fig && !fig.dead) {
        contenders.push({
          id: fig.id,
          isPlayer: false,
          nameTh: fig.titleAndNameTh,
          shortNameTh: fig.fullNameTh,
          sectId: s.id,
          sectNameTh: s.nameTh,
          weaponNameTh: fig.weaponNameTh,
          techNameTh: fig.signatureTechNameTh,
          power: fig.power
        });
      }
    });

    const leg = (W.world.wanderingLegends || []).find(l => l && !l.dead);
    if (leg && contenders.length < 7) {
      contenders.push({
        id: leg.id,
        isPlayer: false,
        nameTh: leg.titleAndNameTh,
        shortNameTh: leg.fullNameTh,
        sectId: null,
        sectNameTh: 'ผู้บำเพ็ญในตำนานอิสระ',
        weaponNameTh: leg.weaponNameTh,
        techNameTh: leg.signatureTechNameTh,
        power: Math.round(leg.power * 0.85)
      });
    }

    const pAlive = (W.npcs || []).filter(n => n && !n.dead && !n.exiled).sort((a, b) => CULT.power(b) - CULT.power(a));
    const pChamp = (opts.playerNpcId && W.byId[opts.playerNpcId]) || pAlive[0];
    if (pChamp) {
      contenders.push({
        id: pChamp.id,
        isPlayer: true,
        npcId: pChamp.id,
        nameTh: HC.fullName(pChamp),
        shortNameTh: HC.fullName(pChamp),
        sectId: 'PLAYER',
        sectNameTh: 'สำนัก' + (W.sect && W.sect.name ? W.sect.name : 'ของเรา'),
        weaponNameTh: (pChamp.equip && pChamp.equip.WEAPON && pChamp.equip.WEAPON.nameTh) || 'ศาสตราประจำตัว',
        techNameTh: 'เคล็ดวิชาเอกประจำสำนัก',
        power: Math.round(CULT.power(pChamp) * (opts.forcePlayerWin ? 50 : 1.15))
      });
    }

    // Score and simulate brackets (Quarterfinals -> Semifinals -> Grand Final)
    const scored = contenders.map(c => ({
      c,
      score: Math.round(c.power * (0.85 + rng.next() * 0.32) + (opts.forcePlayerWin && c.isPlayer ? 999999 : 0))
    })).sort((a, b) => b.score - a.score);

    const champion = scored[0].c;
    const finalist = scored[1] ? scored[1].c : champion;
    const semi1 = scored[2] ? scored[2].c : finalist;
    const semi2 = scored[3] ? scored[3].c : finalist;

    const qfReport = '【รอบคัดเลือกและรอบ 8 ยอดฝีมือ】 ตัวแทนจาก ' + contenders.length + ' ขั้วอำนาจประลองฝีมือกันอย่างดุเดือด จนได้ 4 ยอดฝีมือเข้าสู่รอบรองชนะเลิศ ได้แก่ ' + [champion, finalist, semi1, semi2].map(x => x.shortNameTh + ' (' + x.sectNameTh + ')').join(', ');
    const sfReport = '【รอบรองชนะเลิศ】 「' + champion.nameTh + '」สำแดงวิชา「' + champion.techNameTh + '」เอาชนะ「' + semi1.nameTh + '」ขณะที่「' + finalist.nameTh + '」ฟาดฟันด้วย' + finalist.weaponNameTh + 'เฉือนชนะ「' + semi2.nameTh + '」ผ่านเข้าสู่รอบชิงชนะเลิศ!';
    const finalReport = '【รอบชิงชนะเลิศยุทธภพสิบทิศ】 ท่ามกลางสายตาผู้ชมทั่วหล้า ณ ลานประลองของ「' + hostSect.nameTh + '」「' + champion.nameTh + '」(' + champion.sectNameTh + ') ปะทะเดือดกับ「' + finalist.nameTh + '」(' + finalist.sectNameTh + ') นานนับร้อยกระบวนท่า ก่อนที่ ' + champion.shortNameTh + ' จะเร่งปราณสูงสุดสำแดง「' + champion.techNameTh + '」คู่กับ' + champion.weaponNameTh + ' คว้าตำแหน่งเจ้ายุทธภพสิบทิศประจำปีไปครองอย่างยิ่งใหญ่!';

    let stonePrize = 0;
    if (champion.isPlayer) {
      stonePrize = (ECO && ECO.earnFromPool)
        ? ECO.earnFromPool(W, 480, 'รางวัลชนะเลิศงานประลองยุทธภพสิบทิศ')
        : ((ECO && ECO.earn && ECO.earn(W, 480, 'รางวัลชนะเลิศงานประลองยุทธภพสิบทิศ')) ? 480 : 0);
      W.fame(12);
      const pm = W.byId[champion.npcId];
      if (pm && !pm.dead) {
        pm.merit = (pm.merit || 0) + 45;
        if (pm.cult) CULT.gain(pm, 55, W, 'grand_assembly_champion');
      }
      if (SECT && SECT.evaluateSectTier) SECT.evaluateSectTier(W);
    } else if (champion.sectId) {
      const winSect = X.findSect(W, champion.sectId);
      if (winSect) {
        winSect.influence = (winSect.influence || 70) + 18;
        winSect.power = +((winSect.power || 1.2) + 0.12).toFixed(2);
      }
      if (champion.id && W.world.figuresById && W.world.figuresById[champion.id]) {
        const cFig = W.world.figuresById[champion.id];
        if (!cFig.dead) {
          cFig.power = Math.round((cFig.power || 280) * 1.15);
          cFig.backingBonus = (cFig.backingBonus || 0) + 15;
        }
      }
    }

    W.world.martialRankings = scored.slice(0, 6).map((s, idx) => ({
      rank: idx + 1,
      nameTh: s.c.nameTh,
      sectNameTh: s.c.sectNameTh,
      weaponNameTh: s.c.weaponNameTh,
      techNameTh: s.c.techNameTh,
      score: s.score,
      isPlayer: s.c.isPlayer
    }));

    const chron = X.recordChronicle(W, {
      category: 'BATTLE',
      icon: '🏆',
      macroRegion: hostSect.macroRegion || 'NORTHERN_PEAKS',
      involvedSects: [hostSect.nameTh, champion.sectNameTh, finalist.sectNameTh],
      involvedFigures: [champion.nameTh, finalist.nameTh],
      titleTh: 'งานประลองยุทธภพสิบทิศ: 「' + champion.nameTh + '」ผงาดคว้าแชมป์ยุทธภพ!',
      storyTh: qfReport + ' ' + sfReport + ' ' + finalReport,
      combatBreakdownTh: 'อันดับ 1: ' + champion.shortNameTh + ' (' + scored[0].score + ') · อันดับ 2: ' + finalist.shortNameTh + ' (' + (scored[1] ? scored[1].score : 0) + ') · อันดับ 3: ' + semi1.shortNameTh,
      consequenceTh: champion.sectNameTh + ' ได้รับเกียรติยศสูงสุด' + (champion.isPlayer ? (' (+' + stonePrize + ' ศิลาวิญญาณ · ชื่อเสียงสำนัก +12)') : ' (+อิทธิพลสำนัก +18)'),
      quiet: opts.quiet
    });

    return {
      ok: true,
      hostSectNameTh: hostSect.nameTh,
      champion,
      finalist,
      rankings: W.world.martialRankings,
      reports: [qfReport, sfReport, finalReport],
      chronicle: chron
    };
  };

  X.CALAMITY_TEMPLATES = Object.freeze({
    BEAST_WAVE_STAMPEDE: {
      id: 'BEAST_WAVE_STAMPEDE',
      nameTh: 'มหาคลื่นอสูรคลั่งถล่มแคว้น',
      icon: '🐗',
      descTh: 'ดวงดาวอสูรโคจรวิปริต ฝูงสัตว์อสูรนับพันในป่ารวมตัวกันคลุ้มคลั่งถาโถมเข้าใส่ค่ายสำนักน้อยใหญ่ในภูมิภาค!'
    },
    HEAVENLY_THUNDER_TEMPEST: {
      id: 'HEAVENLY_THUNDER_TEMPEST',
      nameTh: 'พายุอัสนีสวรรค์เก้าชั้นฟ้า',
      icon: '⚡',
      descTh: 'เมฆดำทะมึนปกคลุมทั่วหล้า สายฟ้าทัณฑ์สวรรค์ฟาดผ่าลงมาอย่างต่อเนื่อง ทดสอบค่ายกลและเปิดโอกาสให้ผู้ฝึกกายาดูดซับปราณอัสนี!'
    },
    QI_DROUGHT_ECLIPSE: {
      id: 'QI_DROUGHT_ECLIPSE',
      nameTh: 'สุริยุปราคากลืนปราณฟ้าดิน',
      icon: '🌑',
      descTh: 'เกิดคราสบดบังดวงอาทิตย์ ปราณธรรมะอ่อนกำลังลงชั่วคราวขณะที่ปราณหยินและอสูรพุ่งทะยานขึ้น!'
    }
  });

  X.tickHeavenlyCalamity = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    X.ensureWorldTopology(W);
    const rng = makeChildRng(W, 'calamity_' + (W.day || 360));
    const keys = Object.keys(X.CALAMITY_TEMPLATES);
    const tplId = (opts.templateId && X.CALAMITY_TEMPLATES[opts.templateId]) ? opts.templateId : rng.pick(keys);
    const tpl = X.CALAMITY_TEMPLATES[tplId];
    const regKeys = Object.keys(X.WORLD_REGIONS);
    const regId = opts.macroRegion || rng.pick(regKeys);
    const reg = X.WORLD_REGIONS[regId] || X.WORLD_REGIONS.CENTRAL_HEARTLAND;
    const regSects = (W.world.allSects || []).filter(s => s && s.macroRegion === regId);
    const leadSect = regSects[0] || (W.world.allSects && W.world.allSects[0]);

    let consequenceTh = '';
    if (tpl.id === 'BEAST_WAVE_STAMPEDE') {
      const m = leadSect && leadSect.figures && leadSect.figures.master;
      consequenceTh = (leadSect ? ('「' + leadSect.nameTh + '」นำโดย ' + (m ? m.titleAndNameTh : 'เจ้าสำนัก') + ' ออกปราบจ่าฝูงอสูรคลั่งสำเร็จ ได้รับแก่นอสูรและบารมี +10') : 'สำนักในภูมิภาคร่วมมือกันต้านทานคลื่นอสูรไว้ได้');
      if (leadSect) leadSect.influence = (leadSect.influence || 60) + 10;
    } else if (tpl.id === 'HEAVENLY_THUNDER_TEMPEST') {
      const bodyNpcs = (W.npcs || []).filter(n => n && !n.dead && n.cult && (n.cult.path === 'BODY' || n.cult.path === 'XIAN'));
      bodyNpcs.forEach(n => CULT.gain(n, 25, W, 'thunder_temper'));
      consequenceTh = 'ศิษย์สายหลอมกายาและเซียนในสำนักดูดซับปราณอัสนีสวรรค์ ตบะเพิ่มขึ้น +25!';
    } else {
      consequenceTh = 'สำนักฝ่ายอธรรมในเขต' + reg.shortTh + 'ฮึกเหิมขึ้น ขณะที่สำนักฝ่ายธรรมะตรึงค่ายกลตั้งรับ';
    }

    const chron = X.recordChronicle(W, {
      category: 'BATTLE',
      icon: tpl.icon,
      macroRegion: regId,
      involvedSects: regSects.map(s => s.nameTh),
      titleTh: 'วิกฤตฟ้าดินเหนือ' + reg.nameTh + ': 「' + tpl.nameTh + '」!',
      storyTh: tpl.descTh + ' บรรดาสำนักในเขต' + reg.nameTh + (regSects.length ? (' อาทิ ' + regSects.slice(0, 3).map(s => '「' + s.nameTh + '」').join(', ')) : '') + ' ต่างเร่งเปิดค่ายกลพิทักษ์เขาและส่งยอดฝีมือออกรับมือวิกฤตการณ์ครั้งใหญ่นี้!',
      consequenceTh,
      quiet: opts.quiet
    });

    return { ok: true, templateId: tpl.id, nameTh: tpl.nameTh, macroRegion: regId, chronicle: chron };
  };

  /* ============================================================================
   * Patch v2.0.29: Hierarchical Jianghu Cognition & Exact Identity Hydration
   * & Enhanced Multi-Category Epic Chronicle Engine
   * ============================================================================ */

  /**
   * Hydrates an exterior Jianghu figure into a full, resident sect NPC (`W.npcs`).
   * Preserves exact personality, traits, cultivation, and equipment without rerolling.
   */
  X.hydrateFigureToNpc = (W, figOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world || !W.sect) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);

    let fig = typeof figOrId === 'object' && figOrId ? figOrId : (W.world.figuresById && W.world.figuresById[figOrId]);
    if (!fig) {
      const s = X.findSect(W, figOrId);
      if (s && s.figures && s.figures.master) fig = s.figures.master;
    }
    if (!fig) return { ok: false, reason: 'figure-not-found' };
    if (fig.dead) return { ok: false, reason: 'figure-is-dead' };

    // Check if already in W.npcs
    const existing = (W.npcs || []).find(n => n && (n.id === fig.id || n._origFigureId === fig.id));
    if (existing) return { ok: true, npc: existing, alreadyResident: true };

    const rng = makeChildRng(W, 'hydrate_' + fig.id + '_' + (W.day || 360));
    const sex = fig.h && fig.h.sex ? fig.h.sex : (rng.chance(0.6) ? 'M' : 'F');
    const ageYears = fig.ageYears || rng.int(22, 45);

    // 1. Generate full resident body/genome/mind baseline using HC.generate
    const fullNpc = HC.generate(rng, {
      id: fig.id,
      day: W.day || 360,
      sex,
      ageYears,
      quality: fig.quality || 0,
      trainedness: 0.6
    });

    // 2. PRESERVE EXACT IDENTITY: Transfer all authored/fig traits into fullNpc.h
    if (fig.h) {
      if (fig.h.name) {
        const fam = fig.h.name.family || fig.h.name.sur || fullNpc.h.name.family || fullNpc.h.name.sur || 'หลิน';
        const giv = fig.h.name.given || fullNpc.h.name.given || 'เจี้ยนซิน';
        fullNpc.h.name = {
          family: fam,
          sur: fam,
          given: giv,
          style: fullNpc.h.name.style || null,
          full: fig.h.name.full || (fam + giv)
        };
      }
      // Exact Personality transfer
      if (fig.h.personality) {
        Object.keys(fig.h.personality).forEach(k => {
          if (typeof fig.h.personality[k] === 'number') fullNpc.h.personality[k] = fig.h.personality[k];
        });
      }
      // Exact Values transfer
      if (fig.h.values) {
        Object.keys(fig.h.values).forEach(k => {
          if (typeof fig.h.values[k] === 'number') fullNpc.h.values[k] = fig.h.values[k];
        });
      }
      // Exact Social & Skills transfer
      if (fig.h.social) {
        Object.keys(fig.h.social).forEach(k => {
          if (typeof fig.h.social[k] === 'number') fullNpc.h.social[k] = fig.h.social[k];
        });
      }
      if (fig.h.intellect) {
        Object.keys(fig.h.intellect).forEach(k => {
          if (typeof fig.h.intellect[k] === 'number') fullNpc.h.intellect[k] = fig.h.intellect[k];
        });
      }
      if (fig.h.skills) {
        Object.keys(fig.h.skills).forEach(k => {
          if (typeof fig.h.skills[k] === 'number') fullNpc.h.skills[k] = fig.h.skills[k];
        });
      }
      if (fig.h.aptitudes) {
        Object.keys(fig.h.aptitudes).forEach(k => {
          if (typeof fig.h.aptitudes[k] === 'number') fullNpc.h.aptitudes[k] = fig.h.aptitudes[k];
        });
      }
    }

    // Ensure weapon skill matching fig.weaponType (both canonical uppercase and lowercase)
    if (fig.weaponType && fullNpc.h.skills) {
      const wpnUpper = fig.weaponType === 'FIST' ? 'FIST_PALM' : String(fig.weaponType).toUpperCase();
      const wpnLower = String(fig.weaponType).toLowerCase();
      const targetVal = Math.round(55 + (fig.cult ? fig.cult.stage * 4 : 10));
      fullNpc.h.skills[wpnUpper] = Math.max(fullNpc.h.skills[wpnUpper] || 0, targetVal);
      fullNpc.h.skills[wpnLower] = Math.max(fullNpc.h.skills[wpnLower] || 0, targetVal);
    }

    // 3. Populate Resident State & Sect Membership
    const assignedRank = opts.rank != null ? opts.rank : (fig.role === 'master' ? 5 : fig.role === 'deputy' ? 4 : 3);
    Object.assign(fullNpc, {
      x: MAP.EXIT ? MAP.EXIT.x + 0.5 : 118,
      y: MAP.EXIT ? MAP.EXIT.y + 0.5 : 70,
      px: MAP.EXIT ? MAP.EXIT.x + 0.5 : 118,
      py: MAP.EXIT ? MAP.EXIT.y + 0.5 : 70,
      face: 1,
      dir: 0,
      rank: assignedRank,
      post: null,
      assist: null,
      merit: opts.merit || 25,
      sat: 70,
      mentor: null,
      bed: null,
      joinDay: W.day || 360,
      inv: (() => {
        const rawSt = (fig.inv && Number.isFinite(fig.inv.stones)) ? fig.inv.stones : rng.int(50, 180);
        const pool = W.world && W.world.resourcePool;
        const stVal = (pool && Number.isFinite(pool.stones)) ? Math.min(rawSt, Math.max(0, Math.floor(pool.stones))) : rawSt;
        if (pool && Number.isFinite(pool.stones)) pool.stones -= stVal;
        return {
          stones: stVal,
          pills: {},
          mats: {}
        };
      })(),
      equip: {},
      inj: [],
      cool: {},
      recent: [],
      act: { id: 'idle', stage: 'do', left: 0, total: 0, ctx: {}, why: [] },
      path: null,
      pi: 0,
      hidden: false,
      away: false,
      dead: false,
      stats: {},
      why: [],
      travel: { to: 'home' },
      _origFigureId: fig.id,
      _recruitedFromSectTh: fig.sectNameTh || 'สำนักภายนอก',
      _renegadeTitleTh: fig.roleTh || 'ยอดฝีมือแปรพักตร์'
    });

    // 4. Cultivation Path & Techniques Synchronization
    if (fig.cult) {
      const pPath = (fig.cult.path && CULT.PATHS && CULT.PATHS[fig.cult.path]) ? fig.cult.path : 'XIAN';
      const pStage = Math.max(1, Number(fig.cult.stage) || 3);
      const pathSubs = (CULT.PATHS && CULT.PATHS[pPath] && Array.isArray(CULT.PATHS[pPath].subPaths)) ? CULT.PATHS[pPath].subPaths : [];
      const validSub = (fig.cult.sub && fig.cult.sub !== 'NONE' && pathSubs.some(s => s.id === fig.cult.sub))
        ? fig.cult.sub
        : (pathSubs[0] ? pathSubs[0].id : 'SWORD_IMMORTAL');
      const mant = CULT.bestMantra ? CULT.bestMantra(pPath, pStage, fullNpc) : null;
      fullNpc.cult = {
        path: pPath,
        sub: validSub,
        stage: pStage,
        prog: 0,
        mantra: mant ? mant.id : null,
        techs: Array.isArray(fig.cult.techs) ? fig.cult.techs.slice() : [],
        learning: null,
        toxic: 0,
        lifeBonus: 0,
        since: (W.day || 360) - ageYears * 360,
        attempts: 0,
        secl: null,
        rate: 0,
        pillT: 0
      };
      const threshVal = (CULT.threshold && Number.isFinite(CULT.threshold(fullNpc))) ? CULT.threshold(fullNpc) : 200;
      fullNpc.cult.prog = Math.round(threshVal * 0.45);
      if (CULT.trackDef && CULT.trackDef(validSub)) {
        fullNpc.cult.track = CULT.initTrack(validSub, Math.min(9, pStage), W.day || 360);
      }
      if (CULT.ensurePathGauge) CULT.ensurePathGauge(fullNpc);
    }

    if (g.MARTIAL && g.MARTIAL.ensureSkills) g.MARTIAL.ensureSkills(fullNpc, rng);
    if (g.ELEM && g.ELEM.ensureNpcElementalState) g.ELEM.ensureNpcElementalState(fullNpc);
    if (g.ELEM && g.ELEM.syncSpecialAccess) g.ELEM.syncSpecialAccess(fullNpc);
    CULT.refreshLifespan(fullNpc);
    fullNpc.h.state.hp = CULT.hpMax(fullNpc);
    fullNpc.h.state.qi = CULT.qiMax(fullNpc);

    // Equip Starter / Existing Gear (with guaranteed weapon fallback for all weapon types)
    if (fig.weaponType && ECO && ECO.mintGear) {
      const wpnRecipes = ECO.recipesFor ? ECO.recipesFor(W, ['FORGING']).filter(r => r.outType === 'EQUIPMENT' && (r.gearType === fig.weaponType || r.weaponType === fig.weaponType)) : [];
      const allRecipes = (!wpnRecipes.length && JD && JD.ITEMS && Array.isArray(JD.ITEMS.recipes))
        ? JD.ITEMS.recipes.filter(r => r && r.outType === 'EQUIPMENT' && (r.gearType === fig.weaponType || r.weaponType === fig.weaponType))
        : wpnRecipes;
      if (allRecipes.length) {
        const pickedR = allRecipes.find(r => r.tier === (fullNpc.cult ? fullNpc.cult.stage : 3)) || allRecipes[0];
        fullNpc.equip.WEAPON = ECO.mintGear(W, pickedR, 1.15);
        if (fullNpc.equip.WEAPON && fig.weaponNameTh) fullNpc.equip.WEAPON.nameTh = fig.weaponNameTh;
      }
    }
    if (!fullNpc.equip.WEAPON) {
      const stg = (fullNpc.cult && fullNpc.cult.stage) || 3;
      const wType = fig.weaponType || 'SWORD';
      fullNpc.equip.WEAPON = {
        uid: 'GEAR_HYD_' + fig.id + '_' + (W.day || 360),
        id: 'WPN_' + wType + '_' + stg,
        nameTh: fig.weaponNameTh || ('ศาสตรา' + wType + 'ประจำกาย'),
        slot: 'WEAPON',
        weaponType: wType,
        gearType: wType,
        tier: stg,
        q: 1.15,
        quality: 1.15,
        combatMult: +(0.12 + stg * 0.04).toFixed(3),
        dur: 100,
        maxDur: 100,
        listedAtDay: W.day || 0
      };
    }

    // Patch v2.0.30: Record renegadeOrigin when a foreign sect figure defects or seeks refuge
    const isForeignSectMember = !!(fig.sectId && fig.kind !== 'WANDERING_LEGEND' && fig.kind !== 'WANDERING_FIGURE');
    if (opts.renegadeOrigin || opts.isRenegade || fig.role === 'renegade_successor' || (isForeignSectMember && opts.markRenegade !== false)) {
      const rOrigin = Object.assign({
        sectId: fig.sectId || 'S0',
        sectNameTh: fig.sectNameTh || 'สำนักภายนอก',
        formerPost: fig.role || 'disciple',
        formerPostTh: fig.roleTh || 'อดีตศิษย์สำนัก',
        bounty: opts.bounty || Math.round(260 + ((fullNpc.cult && fullNpc.cult.stage) || 3) * 120),
        offenseType: opts.offenseType || (fig.role === 'renegade_successor' || fig.role === 'successor' ? 'SUCCESSION_DEFECTION' : 'SECT_DEFECTION'),
        defectedDay: W.day || 360,
        ultimatumDueDay: (W.day || 360) + (opts.ultimatumDelayDays != null ? opts.ultimatumDelayDays : 30),
        pursuitStatus: 'PENDING_ULTIMATUM',
        gratitude: opts.gratitude || 20
      }, opts.renegadeOrigin || {});
      fullNpc.renegadeOrigin = rOrigin;
      fullNpc.h.renegadeOrigin = rOrigin;
    }

    // Deep Cross-System Link: Record biographical history, memory, and initial social/mental state
    if (fullNpc.h) {
      if (fullNpc.h.life && Array.isArray(fullNpc.h.life.bio)) {
        fullNpc.h.life.bio.push({
          age: Math.round(ageYears),
          t: 'ลี้ภัย/สวามิภักดิ์จาก「' + (fig.sectNameTh || 'ยุทธภพภายนอก') + '」(เดิมดำรงตำแหน่ง ' + (fig.roleTh || 'ยอดฝีมือ') + ') เข้าสู่「' + (W.sect.name || 'สำนักเมฆาหยก') + '」'
        });
      }
      if (fullNpc.h.mind && Array.isArray(fullNpc.h.mind.memories)) {
        fullNpc.h.mind.memories.unshift({
          day: W.day || 360,
          kind: 'sect_refuge',
          text: 'ได้รับความเมตตาจากเจ้าสำนัก「' + (W.sect.name || 'สำนักเมฆาหยก') + '」ให้ที่พักพิงหลังเหตุผันผวนจาก「' + (fig.sectNameTh || 'ภายนอก') + '」'
        });
      }
    }
    // Register into World Simulation
    fullNpc.personalStones = (fullNpc.inv && fullNpc.inv.stones) || 0;
    if (W.sect && W.sect.totemPillars && Array.isArray(W.sect.totemPillars.activeTotems) && W.sect.totemPillars.activeTotems.length) {
      fullNpc.sectTotems = W.sect.totemPillars.activeTotems.slice();
      fullNpc._sectTotems = fullNpc.sectTotems;
    }
    X.assignHometown(W, fullNpc);
    W.npcs.push(fullNpc);
    W.byId[fullNpc.id] = fullNpc;
    if (g.AI && g.AI.assignBed && W.map) g.AI.assignBed(W, fullNpc);
    if (g.SIM && g.SIM.snapshotPerson) g.SIM.snapshotPerson(W, fullNpc);

    if (fullNpc.renegadeOrigin && fullNpc.renegadeOrigin.offenseType === 'SUCCESSION_DEFECTION' && g.SECT && g.SECT.HEART_DEMON && g.SECT.HEART_DEMON.spawnFromCause) {
      g.SECT.HEART_DEMON.spawnFromCause(W, fullNpc, 'DEFEAT_HUMILIATION', {
        severity: 28,
        originEventTh: 'บาดแผลในใจจากการถูกแย่งชิงบัลลังก์และต้องหนีตายออกจาก「' + (fig.sectNameTh || 'สำนักเดิม') + '」'
      });
    }

    // Mark exterior figure as recruited/defected and clean up foreign sect/wandering slots
    fig.recruitedToPlayer = true;
    fig.residentNpcId = fullNpc.id;
    if (fig.sectId) {
      const homeSect = X.findSect(W, fig.sectId);
      if (homeSect && homeSect.figures) {
        if (Array.isArray(homeSect.figures.coreDisciples)) {
          homeSect.figures.coreDisciples = homeSect.figures.coreDisciples.filter(cd => cd && cd.id !== fig.id);
        }
        ['disciplineElder', 'craftElder', 'warMarshal', 'deputy', 'successor'].forEach(rKey => {
          if (homeSect.figures[rKey] && homeSect.figures[rKey].id === fig.id) {
            homeSect.figures[rKey] = X.generateProceduralSectFigure(W, homeSect, rKey);
          }
        });
      }
    }
    if (Array.isArray(W.world.wanderingFigures)) {
      W.world.wanderingFigures = W.world.wanderingFigures.filter(wf => wf && wf.id !== fig.id);
      W.wandering = W.world.wanderingFigures;
    }

    // Record Chronicle Announcement
    const chron = X.recordChronicle(W, {
      reportFormat: fullNpc.renegadeOrigin ? 'DISCIPLINE_EDICT' : 'PIGEON_DISPATCH',
      category: 'SUCCESSION',
      icon: '🤝',
      macroRegion: fig.macroRegion || 'CENTRAL_HEARTLAND',
      involvedSects: [fig.sectNameTh || 'สำนักภายนอก', W.sect.name || 'สำนักของเรา'],
      involvedFigures: [HC.fullName(fullNpc)],
      titleTh: 'ยอดฝีมือแปรพักตร์สวามิภักดิ์! 「' + HC.fullName(fullNpc) + '」เข้าสู่สำนัก',
      storyTh: 'หลังเหตุการณ์คลื่นลมผันผวนในยุทธภพ 「' + HC.fullName(fullNpc) + '」(' + (fig.roleTh || 'อดีตยอดฝีมือ') + 'แห่ง' + (fig.sectNameTh || 'สำนักภายนอก') + ') ผู้บำเพ็ญ' + (fullNpc.cult ? (((CULT.PATHS && CULT.PATHS[fullNpc.cult.path] && CULT.PATHS[fullNpc.cult.path].nameTh) || fullNpc.cult.path) + ' ขั้น ' + fullNpc.cult.stage) : '') + ' มีความทะเยอทะยาน (' + Math.round(figTrait(fig, 'personality.ambition')) + ') ได้เดินทางมาขอกราบคารวะเข้าพึ่งพิงสำนัก「' + (W.sect.name || 'สำนักของเรา') + '」! เจ้าสำนักพิจารณาแล้วรับเข้าเป็นศิษย์ชั้นสูงทันที!',
      originCauseTh: fullNpc.renegadeOrigin ? ('วิกฤตชิงบัลลังก์และความขัดแย้งภายใน「' + (fig.sectNameTh || 'สำนักเดิม') + '」บีบให้ต้องลี้ภัย') : ('ความเลื่อมใสในชื่อเสียงของสำนักเราและการชักชวนยอดฝีมือพเนจร'),
      actorChainTh: HC.fullName(fullNpc) + ' (' + (fig.roleTh || 'ยอดฝีมือ') + ') ➔ เดินทางเข้าพึ่งใบบุญ「' + (W.sect.name || 'สำนักของเรา') + '」',
      systemImpactTh: 'ขึ้นทำเนียบเป็นศิษย์ประจำสำนักอย่างเป็นทางการ โดยคงพื้นฐานนิสัย วิชา และศาสตราเดิมครบถ้วน' + (fullNpc.renegadeOrigin ? ' · สำนักเดิมอาจส่งหน่วยล่าสังหารตามทวงตัว และศิษย์ผู้นี้ยังคงมีปมในใจรอการชี้แนะ' : ''),
      consequenceTh: HC.fullName(fullNpc) + ' เข้าร่วมเป็นสมาชิกสำนักเราอย่างสมบูรณ์ รักษาอุปนิสัยและวิชาเดิมครบถ้วน!',
      quiet: opts.quiet
    });

    W.log('disciple', '🤝 ต้อนรับศิษย์ใหม่ผู้ลี้ภัยยุทธภพ: ' + HC.fullName(fullNpc) + ' (' + (fig.roleTh || 'ยอดฝีมือ') + 'จาก' + (fig.sectNameTh || 'ภายนอก') + ')', [fullNpc.id]);

    return { ok: true, npc: fullNpc, figure: fig, chronicle: chron };
  };

  /**
   * Recruits a defecting/renegade figure or candidate from visitor/succession queue into player sect.
   */
  X.recruitForeignProdigy = (W, figOrId, opts) => {
    return X.hydrateFigureToNpc(W, figOrId, opts);
  };

  /* ============================================================================
   * Patch v2.0.30:
   * - Pillar 1: 3-Tier Foreign Sect Cognition (Master/Deputy/Successor, Domain Elders, Core Disciples)
   * - Pillar 2: Emergent Unaffiliated Figures (Wandering Solitary NPCs)
   * - Pillar 3: Renegade Pursuit, Extradition Ultimatum & Vendetta Reclamation
   * - Pillar 5: Coalition Sect War & Grand Siege Reinforcement Beacon
   * ============================================================================ */

  X.WANDERING_ARCHETYPES = Object.freeze({
    SWORD_SEEKER: {
      id: 'SWORD_SEEKER',
      nameTh: 'จอมยุทธ์พเนจรแสวงหาคู่ประลอง',
      badgeTh: '⚔️ จอมยุทธ์แสวงพ่าย',
      icon: '⚔️',
      defaultPath: 'XIAN',
      defaultWeapon: 'SWORD',
      descTh: 'ยอดฝีมือผู้แบกกระบี่ท่องไปทั่วหล้าเพื่อท้าประลองกับศิษย์เอกของแต่ละสำนัก ขัดเกลาเจตจำนงยุทธ์ให้ถึงขีดสุด'
    },
    HERMIT_DOCTOR: {
      id: 'HERMIT_DOCTOR',
      nameTh: 'หมอยาเทวดาเร้นกาย',
      badgeTh: '⚕️ หมอยาเทวดาเร้นกาย',
      icon: '⚕️',
      defaultPath: 'SAGE_SUPPORT',
      defaultWeapon: 'NEEDLE',
      descTh: 'หมอเทวดาผู้เร้นกายเก็บสมุนไพรวิญญาณตามหุบเขา มีโอสถทิพย์รักษาอาการบาดเจ็บสาหัสและขับพิษสะสม'
    },
    UNORTHODOX_BANDIT: {
      id: 'UNORTHODOX_BANDIT',
      nameTh: 'จอมโจรคุณธรรม / ผู้บำเพ็ญนอกรีต',
      badgeTh: '🎭 จอมโจรคุณธรรมนอกรีต',
      icon: '🎭',
      defaultPath: 'DEMON',
      defaultWeapon: 'BLADE',
      descTh: 'ผู้ฝึกตนนอกขนบที่ดักปล้นชิงคาราวานของสำนักฝ่ายอธรรมและช่วยเหลือผู้ลี้ภัย สามารถผูกมิตรแบ่งสมบัติหรือปราบปรามได้'
    },
    ROGUE_ARRAYIST: {
      id: 'ROGUE_ARRAYIST',
      nameTh: 'นักวางค่ายกลพเนจร',
      badgeTh: '🧭 นักวางค่ายกลพเนจร',
      icon: '🧭',
      defaultPath: 'ARRAY_TALISMAN',
      defaultWeapon: 'FOCUS',
      descTh: 'ผู้เชี่ยวชาญค่ายกลโบราณที่ออกสำรวจชีพจรปฐพีทั่วหล้า มีแผ่นหยกค่ายกลขายและล่วงรู้พิกัดแดนลับโบราณแห่งใหม่'
    }
  });

  X.generateWanderingFigure = (W, archetypeId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return null;
    ensureFiguresMap(W.world);
    W.world.wanderingSeq = (W.world.wanderingSeq || 0) + 1;
    const seq = opts.seq != null ? opts.seq : W.world.wanderingSeq;
    const rng = opts.rng || makeChildRng(W, 'wandering_fig:' + seq + ':' + (W.day || 360));
    const archKeys = Object.keys(X.WANDERING_ARCHETYPES);
    const chosenArchId = (archetypeId && X.WANDERING_ARCHETYPES[archetypeId]) ? archetypeId : rng.pick(archKeys);
    const arch = X.WANDERING_ARCHETYPES[chosenArchId];

    const stage = opts.stage || rng.int(3, 6);
    const ageYears = opts.ageYears || rng.int(24, 58);
    const sex = opts.sex || (rng.chance(0.58) ? 'M' : 'F');
    const h = generateFastFigureCore(rng, sex);

    if (chosenArchId === 'SWORD_SEEKER') {
      h.personality.courage = clamp((h.personality.courage || 50) + 22, 68, 98);
      h.personality.aggression = clamp((h.personality.aggression || 50) + 15, 58, 92);
      h.values.martialPeak = clamp((h.values.martialPeak || 50) + 25, 75, 99);
    } else if (chosenArchId === 'HERMIT_DOCTOR') {
      h.personality.empathy = clamp((h.personality.empathy || 50) + 24, 72, 99);
      h.personality.integrity = clamp((h.personality.integrity || 50) + 18, 65, 98);
      h.skills.ALCHEMY = clamp(rng.int(75, 96), 72, 99);
      h.skills.MEDICINE = clamp(rng.int(78, 98), 75, 99);
    } else if (chosenArchId === 'UNORTHODOX_BANDIT') {
      h.personality.courage = clamp((h.personality.courage || 50) + 18, 65, 96);
      h.personality.caution = clamp((h.personality.caution || 50) + 16, 60, 95);
      h.skills.stealth = clamp(rng.int(72, 95), 70, 99);
    } else if (chosenArchId === 'ROGUE_ARRAYIST') {
      h.intellect.comprehension = clamp((h.intellect.comprehension || 50) + 24, 74, 99);
      h.personality.curiosity = clamp((h.personality.curiosity || 50) + 22, 70, 98);
      h.skills.ARRAY = clamp(rng.int(76, 97), 74, 99);
    }

    const chosenPath = opts.path || (CULT && CULT.PATHS && CULT.PATHS[arch.defaultPath] ? arch.defaultPath : 'XIAN');
    const subObjs = (CULT && CULT.PATHS && CULT.PATHS[chosenPath] && Array.isArray(CULT.PATHS[chosenPath].subPaths))
      ? CULT.PATHS[chosenPath].subPaths
      : [];
    const chosenSub = opts.sub || (subObjs.length ? rng.pick(subObjs).id : 'NONE');
    const wpnTypes = ['SWORD', 'BLADE', 'SPEAR', 'FIST', 'STAFF', 'FOCUS', 'ZITHER', 'BRUSH'];
    const chosenWeapon = opts.weaponType || (wpnTypes.includes(arch.defaultWeapon) ? arch.defaultWeapon : rng.pick(wpnTypes));
    const wTypeTh = (JD && JD.MARTIAL && JD.MARTIAL.types && JD.MARTIAL.types[chosenWeapon]) || chosenWeapon;

    let techs = [];
    if (JD && JD.TECH && Array.isArray(JD.TECH.techniques)) {
      const compat = JD.TECH.techniques.filter(t => t && (t.path === chosenPath || t.path === 'ANY') && (t.tier || 1) <= stage + 1);
      if (compat.length) {
        const p1 = rng.pick(compat);
        if (p1) techs.push(p1.id);
      }
    }
    const topTech = (techs[0] && CULT && CULT.tech && CULT.tech(techs[0])) || null;
    const signatureTechNameTh = topTech ? topTech.nameTh : ('เคล็ดวิชา' + wTypeTh + 'พเนจร');

    const doc = X.computeFigureDoctrine({ h });
    const prefList = EPITHET_PREFIX_BY_PATH[chosenPath] || EPITHET_PREFIX_BY_PATH.XIAN;
    const sufList = EPITHET_SUFFIX_BY_TRAIT[doc.id] || EPITHET_SUFFIX_BY_TRAIT.MYSTIC_SECLUSION;
    const epithetTh = rng.pick(prefList) + rng.pick(sufList);
    const regions = Object.keys(X.WORLD_REGIONS || { CENTRAL_HEARTLAND: 1, NORTHERN_PEAKS: 1, SOUTHERN_WATERS: 1, EASTERN_PLAINS: 1, WESTERN_BADLANDS: 1 });
    const macroRegion = opts.macroRegion || rng.pick(regions) || 'CENTRAL_HEARTLAND';
    const nodeKeys = Object.keys((W.world.mapTopology && W.world.mapTopology.nodes) || {});
    const currentNodeId = opts.currentNodeId || (nodeKeys.length ? rng.pick(nodeKeys) : 'NODE_PLAYER_SECT');

    const figId = 'JHWAND_' + chosenArchId + '_' + seq;
    const fig = {
      id: figId,
      kind: 'WANDERING_FIGURE',
      archetypeId: chosenArchId,
      archetypeNameTh: arch.nameTh,
      archetypeBadgeTh: arch.badgeTh,
      icon: arch.icon,
      role: 'wandering_' + chosenArchId.toLowerCase(),
      roleTh: arch.nameTh,
      cognitionTier: 2,
      sectId: null,
      sectNameTh: 'ยอดคนอิสระไร้สังกัด',
      alignment: chosenArchId === 'HERMIT_DOCTOR' ? 'RIGHTEOUS' : 'NEUTRAL',
      h,
      rank: 3,
      ageYears,
      lifespanYears: 110 + stage * 30,
      cult: {
        path: chosenPath,
        sub: chosenSub,
        stage,
        techs
      },
      weaponType: chosenWeapon,
      weaponNameTh: 'ศาสตรา' + wTypeTh + '「' + epithetTh + '」',
      signatureTechNameTh,
      doctrineId: doc.id,
      doctrineNameTh: doc.nameTh,
      doctrineBadgeTh: doc.badgeTh,
      epithetTh,
      fullNameTh: figFullName({ h }),
      titleAndNameTh: figFullName({ h }) + ' 「' + epithetTh + '」',
      macroRegion,
      currentNodeId,
      visitingPlayerSect: !!opts.visitingPlayerSect,
      affinity: opts.affinity != null ? opts.affinity : rng.int(15, 40),
      power: Math.round(140 + Math.pow(stage, 2.2) * 42),
      hpMax: Math.round(520 + Math.pow(stage, 2.05) * 170),
      hp: Math.round(520 + Math.pow(stage, 2.05) * 170),
      inv: { stones: rng.int(180, 650), pills: {}, relics: [] },
      descTh: arch.descTh,
      recruitedToPlayer: false,
      dead: false
    };
    hideFigCaches(fig, W);
    W.world.figuresById[fig.id] = fig;
    return fig;
  };

  X.ensureWanderingFigures = (W, targetCount) => {
    if (!W || !W.world) return [];
    ensureFiguresMap(W.world);
    if (!Array.isArray(W.world.wanderingFigures)) {
      W.world.wanderingFigures = Array.isArray(W.wandering) ? W.wandering : [];
    }
    W.world.wanderingFigures = W.world.wanderingFigures.filter(f => f && !f.dead && !f.recruitedToPlayer);
    const want = clamp(targetCount || 6, 4, 8);
    const archKeys = Object.keys(X.WANDERING_ARCHETYPES);
    let idx = W.world.wanderingFigures.length;
    while (W.world.wanderingFigures.length < want) {
      idx++;
      const rng = makeChildRng(W, 'init_wandering_fig_' + idx + '_' + (W.day || 360));
      const archId = archKeys[(idx - 1) % archKeys.length];
      const wf = X.generateWanderingFigure(W, archId, { rng, seq: (W.world.wanderingSeq || 0) + idx, visitingPlayerSect: idx === 1 });
      if (wf) W.world.wanderingFigures.push(wf);
    }
    if (W.world.wanderingFigures.length > 8) {
      W.world.wanderingFigures.length = 8;
    }
    W.world.wanderingFigures.forEach(wf => {
      if (wf && wf.id) {
        hideFigCaches(wf, W);
        W.world.figuresById[wf.id] = wf;
      }
    });
    W.wandering = W.world.wanderingFigures;
    return W.world.wanderingFigures;
  };

  X.tickWanderingFigures = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    const list = X.ensureWanderingFigures(W, opts.targetCount || 6);
    const rng = makeChildRng(W, 'tick_wandering_' + (W.day || 360));
    const regions = Object.keys(X.WORLD_REGIONS || { CENTRAL_HEARTLAND: 1 });
    const nodeKeys = Object.keys((W.world.mapTopology && W.world.mapTopology.nodes) || {});
    const events = [];

    list.forEach((wf, idx) => {
      if (!wf || wf.dead || wf.recruitedToPlayer) return;
      wf.macroRegion = rng.pick(regions) || wf.macroRegion;
      if (nodeKeys.length) wf.currentNodeId = rng.pick(nodeKeys);
      wf.visitingPlayerSect = (idx === ((W.day || 360) % list.length)) || rng.chance(0.28);
      if (wf.visitingPlayerSect && events.length < 1 && !opts.noAutoEvent) {
        let autoRes = null;
        if (opts.autoInteractOnVisit !== false && (W.npcs || []).length > 0 && rng.chance(0.55)) {
          autoRes = X.interactWanderingFigure(W, wf, 'INTERACT', { free: true, quiet: opts.quiet });
        }
        events.push({
          day: W.day || 360,
          figureId: wf.id,
          archetypeId: wf.archetypeId,
          titleAndNameTh: wf.titleAndNameTh,
          autoEncounter: autoRes && autoRes.ok ? autoRes.action : null,
          summaryTh: wf.icon + ' 「' + wf.titleAndNameTh + '」(' + wf.archetypeNameTh + ' ขั้น ' + wf.cult.stage + ') เดินทางมาปรากฏตัวใกล้เขตสำนักของเรา!'
        });
      }
    });

    W.wandering = W.world.wanderingFigures;
    return { ok: true, count: list.length, wanderingFigures: list, events };
  };

  X.interactWanderingFigure = (W, figOrId, action, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWanderingFigures(W);
    let wf = typeof figOrId === 'object' && figOrId
      ? figOrId
      : (W.world.wanderingFigures || []).find(f => f && f.id === figOrId) || (W.world.figuresById && W.world.figuresById[figOrId]);
    if (!wf || wf.dead) return { ok: false, reason: 'wandering-figure-not-found' };

    const act = String(action || 'INTERACT').toUpperCase();
    if (!['INTERACT', 'RECRUIT', 'DUEL', 'HEAL_DISCIPLE', 'BUY_PILL', 'BEFRIEND', 'SUPPRESS', 'BUY_ARRAY', 'REVEAL_SECRET_REALM'].includes(act)) {
      return { ok: false, reason: 'invalid-action' };
    }
    const isBanditGift = act === 'BEFRIEND' || (act === 'INTERACT' && wf.archetypeId === 'UNORTHODOX_BANDIT');
    const isArrayistGift = act === 'REVEAL_SECRET_REALM' || act === 'BUY_ARRAY' || (act === 'INTERACT' && wf.archetypeId === 'ROGUE_ARRAYIST');
    if ((isBanditGift && wf.banditGiftClaimed) || (isArrayistGift && wf.arrayistGiftClaimed)) {
      return { ok: false, reason: 'interaction-already-claimed', wanderingFigure: wf };
    }
    const alive = (W.npcs || []).filter(n => n && !n.dead && !n.exiled).sort((a, b) => CULT.power(b) - CULT.power(a));
    const champ = (opts.npcId && W.byId[opts.npcId]) || alive[0];

    if (act === 'RECRUIT') {
      if (wf.recruitedToPlayer || (W.byId && W.byId[wf.id]) || (Array.isArray(W.npcs) && W.npcs.some(n => n && (n.id === wf.id || n._origFigureId === wf.id)))) {
        return { ok: false, reason: 'already-recruited', wanderingFigure: wf };
      }
      const playerFame = (W.sect && W.sect.fame) || 0;
      const canRecruit = opts.force || opts.helpedInCrisis || (wf.affinity || 0) >= 50 || playerFame >= 80;
      if (!canRecruit) {
        return { ok: false, reason: 'insufficient-affinity-or-fame', affinity: wf.affinity || 0, requiredAffinity: 50 };
      }
      const hyd = X.hydrateFigureToNpc(W, wf, { rank: opts.rank || 3, merit: 35, markRenegade: false, quiet: opts.quiet });
      return Object.assign({ action: 'RECRUIT', wanderingFigure: wf }, hyd);
    }

    let titleTh = '', storyTh = '', consequenceTh = '';
    const extra = {};

    if (act === 'DUEL' || (act === 'INTERACT' && wf.archetypeId === 'SWORD_SEEKER')) {
      const day = Number.isFinite(W.day) ? W.day : 0;
      if (wf.lastWanderingDuelDay === day) return { ok: false, reason: 'duel-cooldown-same-day', wanderingFigure: wf };
      wf.lastWanderingDuelDay = day;
      const pScore = champ ? CULT.power(champ) * (opts.forceWin ? 5.0 : 1.15) : 250;
      const wScore = (wf.power || 220) * (opts.forceLose ? 5.0 : 0.92);
      const won = opts.forceWin ? true : opts.forceLose ? false : (pScore >= wScore);
      wf.affinity = clamp((wf.affinity || 25) + (won ? 35 : 18), 0, 100);
      if (champ) {
        if (champ.h && champ.h.state) {
          champ.h.state.energy = Math.max(0, (champ.h.state.energy || 50) - 20);
          if (!won) {
            const hm = CULT.hpMax(champ);
            champ.h.state.hp = Math.max(1, Math.round((champ.h.state.hp || hm) - hm * 0.18));
          }
        }
        if (champ.cult) {
          const xpGain = won ? 85 : 35;
          CULT.gain(champ, xpGain, W, 'wandering_duel');
          if (won) champ.merit = (champ.merit || 0) + 30;
          extra.cultGain = xpGain;
        }
      }
      if (won) W.fame(6);
      extra.won = won;
      extra.championId = champ ? champ.id : null;
      titleTh = 'ประลองยุทธ์ยอดคนพเนจร: 「' + (champ ? HC.fullName(champ) : 'ศิษย์เอก') + '」ปะทะ「' + wf.titleAndNameTh + '」';
      storyTh = wf.titleAndNameTh + ' (' + wf.archetypeNameTh + ') เดินทางมาขอท้าประลองกระบวนท่ากับ ' + (champ ? HC.fullName(champ) : 'ศิษย์เอกของเรา') + ' ทั้งสองแลกเปลี่ยนเพลงยุทธ์อย่างดุเดือด — ' + (won ? (HC.fullName(champ) + ' เป็นฝ่ายคว้าชัยอย่างสง่างาม ทำให้ ' + wf.fullNameTh + ' เลื่อมใสยิ่งนัก!') : ('การประลองสูสีคู่คี่ ต่างฝ่ายต่างได้รับความรู้แจ้งในวิถียุทธ์!'));
      consequenceTh = (won ? 'ชื่อเสียงสำนัก +6 · ตบะศิษย์เอก +85 · ' : 'ตบะศิษย์เอก +35 · ') + 'ความสนิทของ ' + wf.fullNameTh + ' เพิ่มเป็น ' + wf.affinity + '/100';
    } else if (act === 'HEAL_DISCIPLE' || act === 'BUY_PILL' || (act === 'INTERACT' && wf.archetypeId === 'HERMIT_DOCTOR')) {
      const fee = opts.free ? 0 : 120;
      if (!opts.free && W.sect.stones < fee) return { ok: false, reason: 'insufficient-stones', required: fee };
      if (fee > 0 && ECO && ECO.pay) ECO.pay(W, fee, 'ค่ารักษาและโอสถทิพย์จากหมอยาเทวดาเร้นกาย');
      const patient = (opts.npcId && W.byId[opts.npcId]) || alive.find(n => (n.inj && n.inj.length) || (n.cult && n.cult.toxic > 0) || (n.h && n.h.state && n.h.state.hp < CULT.hpMax(n))) || champ;
      if (patient) {
        patient.inj = [];
        if (patient.h && patient.h.state) {
          patient.h.state.hp = CULT.hpMax(patient);
          patient.h.state.qi = CULT.qiMax(patient);
          patient.h.state.heartDemon = Math.max(0, (patient.h.state.heartDemon || 0) - 25);
        }
        if (patient.cult) {
          patient.cult.toxic = 0;
          CULT.gain(patient, 45, W, 'hermit_doctor_elixir');
        }
        extra.healedNpcId = patient.id;
      }
      wf.affinity = clamp((wf.affinity || 30) + 32, 0, 100);
      titleTh = 'หมอยาเทวดาเร้นกาย「' + wf.titleAndNameTh + '」ปรุงโอสถทิพย์ช่วยรักษาศิษย์สำนัก!';
      storyTh = 'คณะศิษย์ได้พบ「' + wf.titleAndNameTh + '」เร้นกายเก็บสมุนไพรอยู่กลางหุบเขา จึงมอบศิลาวิญญาณแลกเปลี่ยนโอสถทิพย์และรับการฝังเข็มทองชำระพิษสะสมให้แก่ ' + (patient ? HC.fullName(patient) : 'ศิษย์ในสำนัก') + ' จนหายขาดเป็นปลิดทิ้ง!';
      consequenceTh = 'รักษาอาการบาดเจ็บและขับพิษโอสถครบถ้วน · ไมตรีของ ' + wf.fullNameTh + ' เพิ่มเป็น ' + wf.affinity + '/100';
    } else if (act === 'BEFRIEND' || act === 'SUPPRESS' || (act === 'INTERACT' && wf.archetypeId === 'UNORTHODOX_BANDIT')) {
      if (act === 'SUPPRESS') {
        const pool = W.world.resourcePool || (W.world.resourcePool = { stones: 50000, herbs: 5000, ores: 5000 });
        const bountyStones = Math.min(260, Number.isFinite(pool.stones) ? Math.max(0, Math.floor(pool.stones)) : 260);
        if (Number.isFinite(pool.stones)) pool.stones -= bountyStones;
        if (ECO && ECO.earn) ECO.earn(W, bountyStones, 'รางวัลปราบปรามผู้บำเพ็ญนอกรีต');
        W.fame(8);
        wf.dead = true;
        W.world.wanderingFigures = (W.world.wanderingFigures || []).filter(x => x && x.id !== wf.id);
        W.wandering = W.world.wanderingFigures;
        extra.stonesEarned = bountyStones;
        titleTh = 'ปราบปรามผู้บำเพ็ญนอกรีต「' + wf.titleAndNameTh + '」สร้างชื่อเสียงขจรขจาย!';
        storyTh = (champ ? HC.fullName(champ) : 'ยอดฝีมือสำนักเรา') + ' ออกสกัดกั้นและปราบปราม「' + wf.titleAndNameTh + '」ยึดทรัพย์สินที่ได้จากการปล้นชิงเข้าคลังสำนัก!';
        consequenceTh = 'คลังสำนัก +' + bountyStones + ' ศิลาวิญญาณ · ชื่อเสียงสำนัก +8';
      } else {
        const pool = W.world.resourcePool || (W.world.resourcePool = { stones: 50000, herbs: 5000, ores: 5000 });
        const sharedStones = Math.min(220, Number.isFinite(pool.stones) ? Math.max(0, Math.floor(pool.stones)) : 0);
        pool.stones -= sharedStones;
        wf.banditGiftClaimed = true;
        if (ECO && ECO.earn) ECO.earn(W, sharedStones, 'ส่วนแบ่งคาราวานจากจอมโจรคุณธรรม');
        wf.affinity = clamp((wf.affinity || 30) + 35, 0, 100);
        extra.stonesEarned = sharedStones;
        titleTh = 'ผูกมิตรจอมโจรคุณธรรม「' + wf.titleAndNameTh + '」แบ่งปันเสบียงและศิลาวิญญาณ!';
        storyTh = 'สำนักเราให้ที่พักพิงและร่วมดื่มสุรากับ「' + wf.titleAndNameTh + '」จอมโจรคุณธรรมผู้ปล้นคนชั่วช่วยคนยาก จึงได้รับส่วนแบ่งศิลาวิญญาณที่ยึดมาจากคาราวานสำนักอธรรมจำนวน ' + sharedStones + ' ก้อน!';
        consequenceTh = 'คลังสำนัก +' + sharedStones + ' ศิลาวิญญาณ · ไมตรีของ ' + wf.fullNameTh + ' เพิ่มเป็น ' + wf.affinity + '/100';
      }
    } else {
      // ROGUE_ARRAYIST: BUY_ARRAY or REVEAL_SECRET_REALM
      const sr = X.spawnSecretRealm ? X.spawnSecretRealm(W, null, { quiet: true }) : null;
      if (!sr) return { ok: false, reason: 'realm-unavailable' };
      wf.arrayistGiftClaimed = true;
      wf.affinity = clamp((wf.affinity || 30) + 35, 0, 100);
      if (ECO && ECO.add) ECO.add(W, 'CAT_PRIMORDIAL_METAL', 2);
      extra.secretRealm = sr;
      titleTh = 'นักวางค่ายกลพเนจร「' + wf.titleAndNameTh + '」มอบแผ่นหยกค่ายกลและเปิดเผยพิกัดแดนลับ!';
      storyTh = '「' + wf.titleAndNameTh + '」ตรวจสอบชีพจรปฐพีรอบสำนักและมอบแผ่นหยกค่ายกลโบราณพร้อมบอกพิกัดของ「' + (sr ? sr.nameTh : 'แดนลับโบราณ') + '」ที่เพิ่งคลายผนึกแก่สำนักเรา!';
      consequenceTh = 'เปิดพิกัดแดนลับ「' + (sr ? sr.nameTh : 'แดนลับโบราณ') + '」· ไมตรีเพิ่มเป็น ' + wf.affinity + '/100';
    }

    const chron = X.recordChronicle(W, {
      category: 'VISITOR',
      icon: wf.icon || '🎐',
      macroRegion: wf.macroRegion || 'CENTRAL_HEARTLAND',
      involvedFigures: [wf.titleAndNameTh, champ && HC.fullName(champ)].filter(Boolean),
      titleTh,
      storyTh,
      consequenceTh,
      quiet: opts.quiet
    });

    return Object.assign({ ok: true, action: act, wanderingFigure: wf, affinity: wf.affinity, chronicle: chron }, extra);
  };

  X.recruitWanderingFigure = (W, figOrId, opts) => {
    return X.interactWanderingFigure(W, figOrId, 'RECRUIT', opts);
  };

  /* ---------- Pillar 1 & 3: Foreign Sect 3-Tier Cognition, Craft Trade, Assassin Pursuit & Vendetta Reclamation ---------- */
  X.exchangeWithCraftElder = (W, sectOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world || !W.sect) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    const s = X.findSect(W, sectOrId) || (W.world.allSects && W.world.allSects[0]);
    if (!s || !s.figures || !s.figures.craftElder || s.figures.craftElder.dead) {
      return { ok: false, reason: 'craft-elder-unavailable' };
    }
    if ((s.attitude || 0) < -20 && !opts.force) {
      return { ok: false, reason: 'hostile-sect', attitude: s.attitude || 0 };
    }
    const cost = opts.free ? 0 : (opts.cost || 150);
    if (!opts.free && (W.sect.stones || 0) < cost) {
      return { ok: false, reason: 'insufficient-stones', required: cost };
    }
    if (cost > 0 && ECO && ECO.pay) {
      ECO.pay(W, cost, 'แลกเปลี่ยนโอสถและแร่ปราณกับผู้อาวุโสหลอมสร้างแห่ง「' + s.nameTh + '」', { toPool: true });
    }
    const ce = s.figures.craftElder;
    const alch = (ce.h && ce.h.skills && ce.h.skills.ALCHEMY) || 80;
    const forg = (ce.h && ce.h.skills && ce.h.skills.FORGING) || 80;
    const rewardItems = [];
    if (alch >= forg) {
      if (ECO && ECO.add) {
        ECO.add(W, 'P:BASIC_QI', 3);
        ECO.add(W, 'herb', 6);
      }
      rewardItems.push('โอสถรวบรวมปราณ ×3', 'สมุนไพรปราณ ×6');
    } else {
      if (ECO && ECO.add) {
        ECO.add(W, 'ore', 6);
        ECO.add(W, 'CAT_PRIMORDIAL_METAL', 1);
      }
      rewardItems.push('แร่เหล็กปราณ ×6', 'สื่อนำทองคำบรรพกาล ×1');
    }
    s.attitude = clamp((s.attitude || 0) + 6, -100, 100);
    // Cross-System Hook: Friendly Craft Elder shares a Feng Shui Elemental Leyline Core
    if ((s.attitude || 0) >= 35 && g.SECT && g.SECT.FENG_SHUI && g.SECT.FENG_SHUI.ensure) {
      const fs = g.SECT.FENG_SHUI.ensure(W);
      if (fs && fs.leylineCoresStock) {
        const elKey = alch >= forg ? 'WOOD' : 'FIRE';
        fs.leylineCoresStock[elKey] = (fs.leylineCoresStock[elKey] || 0) + 1;
        rewardItems.push('แก่นชีพจรฮวงจุ้ยธาตุ' + (elKey === 'WOOD' ? 'ไม้' : 'ไฟ') + ' ×1');
      }
    }
    const chron = X.recordChronicle(W, {
      reportFormat: 'PIGEON_DISPATCH',
      category: 'FACTION',
      icon: '⚗️',
      macroRegion: s.macroRegion || 'CENTRAL_HEARTLAND',
      involvedSects: [W.sect.name, s.nameTh],
      involvedFigures: [ce.titleAndNameTh],
      titleTh: 'แลกเปลี่ยนศาสตร์หลอมสร้างกับ「' + ce.titleAndNameTh + '」แห่ง「' + s.nameTh + '」',
      storyTh: 'สำนักเราส่งทูตการค้าไปแลกเปลี่ยนวัตถุดิบและตำรับหลอมสร้างกับ「' + ce.titleAndNameTh + '」(ผู้อาวุโสหอโอสถ/หลอมสร้างแห่ง「' + s.nameTh + '」) ได้รับ ' + rewardItems.join(' และ ') + ' เข้าสู่คลังสำนัก!',
      originCauseTh: 'ผู้อาวุโสสายหลอมสร้าง (Tier 2: ' + ce.fullNameTh + ' · ทักษะปรุงยา ' + Math.round(alch) + '/ตีเหล็ก ' + Math.round(forg) + ') เปิดช่องทางแลกเปลี่ยนผลผลิตส่วนเกินระหว่างสำนัก',
      actorChainTh: (W.sect.name || 'สำนักเรา') + ' ➔ เจรจาแลกเปลี่ยนกับ ' + ce.titleAndNameTh + ' (' + s.nameTh + ')',
      systemImpactTh: 'การทูตสายช่างหลอมโอสถจากสำนักพันธมิตร ➔ เติมเต็มคลังวัตถุดิบและโอสถหายาก ➔ หนุนเนื่องแก่นชีพจรฮวงจุ้ยประจำสำนัก',
      consequenceTh: 'ได้รับ ' + rewardItems.join(' · ') + ' · ไมตรีกับ ' + s.nameTh + ' +6',
      quiet: opts.quiet
    });
    return { ok: true, sect: s, craftElder: ce, cost, rewardItems, attitude: s.attitude, chronicle: chron };
  };

  X.triggerRenegadePursuitClash = (W, sectOrId, renegadeNpcOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world || !W.sect) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    const s = X.findSect(W, sectOrId) || (W.world.allSects && W.world.allSects.find(x => x && x.assassinThreat));
    if (!s) return { ok: false, reason: 'pursuing-sect-not-found' };
    const npc = typeof renegadeNpcOrId === 'object' && renegadeNpcOrId
      ? renegadeNpcOrId
      : (renegadeNpcOrId && W.byId && W.byId[renegadeNpcOrId]) || (W.npcs || []).find(n => n && !n.dead && !n.exiled && n.renegadeOrigin && n.renegadeOrigin.sectId === s.id);
    if (!npc || npc.dead || npc.exiled) return { ok: false, reason: 'renegade-not-found' };

    const discElder = (s.figures && s.figures.disciplineElder && !s.figures.disciplineElder.dead)
      ? s.figures.disciplineElder
      : (s.figures && s.figures.master);
    const squadPower = Math.round(((discElder && discElder.power) || 340) * 0.95);
    const guards = (W.npcs || []).filter(n => n && !n.dead && !n.exiled && !n.away && (n.id === npc.id || ['guard', 'commander', 'discipline', 'spymaster'].includes(n.post) || (W.sect.guardRoster && W.sect.guardRoster.includes(n.id)))).slice(0, 4);
    if (!guards.includes(npc)) guards.unshift(npc);
    const defPower = Math.round(guards.reduce((sum, gNpc) => sum + CULT.power(gNpc), 0) * 1.15);
    const repelled = opts.forceBreach ? false : (opts.forceRepel || defPower >= squadPower * 0.75);

    s.assassinThreat = false;
    s.lastPursuitClashDay = W.day || 360;

    if (repelled) {
      guards.forEach(gNpc => {
        if (gNpc.cult) CULT.gain(gNpc, 35, W, 'repel_assassin_squad');
        gNpc.merit = (gNpc.merit || 0) + 15;
      });
      W.fame(4);
    } else if (g.AI && g.AI.injure) {
      g.AI.injure(W, npc, 2, 'ถูกหน่วยล่าสังหารหอวินัยของ' + s.nameTh + 'ลอบโจมตี');
    }

    const elderName = discElder ? discElder.titleAndNameTh : ('ผู้อาวุโสหอวินัยแห่ง' + s.nameTh);
    const titleTh = repelled
      ? ('สกัดกั้นหน่วยล่าสังหารหอวินัย! ปกป้อง「' + HC.fullName(npc) + '」จากเงื้อมมือ「' + s.nameTh + '」สำเร็จ!')
      : ('หน่วยล่าสังหารของ「' + s.nameTh + '」ลอบบุกทำร้าย「' + HC.fullName(npc) + '」กลางดึก!');
    const storyTh = '「' + elderName + '」ส่งหน่วยมือสังหารหอวินัยลอบฝ่าความมืดเข้ามาหมายปลิดชีพผู้ลี้ภัย「' + HC.fullName(npc) + '」ถึงในเขตสำนัก! ' +
      (repelled
        ? ('เวรยามและยอดฝีมือสำนักเราร่วมมือกับ「' + HC.fullName(npc) + '」(กำลังป้องกัน ' + defPower + ' ต่อ ' + squadPower + ') ตีโต้หน่วยล่าสังหารจนแตกพ่ายหนีกลับไป!')
        : ('แม้เวรยามจะเข้าขวางกั้น แต่คมกระบี่ของมือสังหารได้ฝากบาดแผลให้แก่「' + HC.fullName(npc) + '」ก่อนจะถอยหนีไป!'));
    const consequenceTh = repelled
      ? (HC.fullName(npc) + ' และผู้พิทักษ์ได้รับตบะ +35 · ชื่อเสียงสำนัก +4 · ภัยลอบสังหารสงบลง')
      : (HC.fullName(npc) + ' ได้รับบาดเจ็บปานกลาง · สำนักเพิ่มการเฝ้าระวัง');

    const chron = X.recordChronicle(W, {
      category: 'BATTLE',
      icon: repelled ? '🛡️' : '🗡️',
      macroRegion: s.macroRegion || 'CENTRAL_HEARTLAND',
      involvedSects: [W.sect.name, s.nameTh],
      involvedFigures: [HC.fullName(npc), elderName],
      titleTh,
      storyTh,
      combatBreakdownTh: 'กำลังป้องกันสำนัก (' + defPower + ') ปะทะ หน่วยล่าสังหารหอวินัย (' + squadPower + ')',
      consequenceTh,
      quiet: opts.quiet
    });

    return { ok: true, repelled, defPower, squadPower, renegadeNpc: npc, sect: s, chronicle: chron };
  };

  X.tickForeignSectCognitionTiers = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    const all = W.world.allSects || [];
    const tierActions = [];

    // 0. Idle Auto-Resolution for expired extradition ultimatums based on Player Sect Master's Human Core traits
    if (Array.isArray(W.world.extraditionUltimatums)) {
      W.world.extraditionUltimatums.forEach(ult => {
        if (!ult || ult.status !== 'PENDING') return;
        if ((W.day || 360) >= (ult.expiresDay || 0) || opts.autoResolveExpiredUltimatums) {
          const m = W.sect && W.sect.masterId && W.byId ? W.byId[W.sect.masterId] : null;
          const mInt = (m && HC && HC.eff) ? HC.eff(m, 'personality.integrity') : 65;
          const mCour = (m && HC && HC.eff) ? HC.eff(m, 'personality.courage') : 65;
          const mCaut = (m && HC && HC.eff) ? HC.eff(m, 'personality.caution') : 50;
          let autoChoice = 'DEFY_PROTECT';
          if (mInt + mCour >= 110) {
            autoChoice = 'DEFY_PROTECT';
          } else if (W.sect && (W.sect.stones || 0) >= (ult.indemnityStones || 350) * 1.25 && mCaut >= 48) {
            autoChoice = 'INDEMNITY_SETTLEMENT';
          } else if (mInt < 42 && mCaut >= 65) {
            autoChoice = 'EXTRADITE_RENEGADE';
          }
          const autoRes = X.resolveExtraditionUltimatum(W, ult, autoChoice, { quiet: opts.quiet });
          if (autoRes && autoRes.ok) {
            tierActions.push({ tier: 1, role: 'playerMasterAuto', sectId: ult.sectId, action: 'AUTO_RESOLVE_ULTIMATUM', choice: autoChoice, ultimatum: ult });
          }
        }
      });
    }

    all.forEach(s => {
      if (!s || !s.figures) return;
      const figs = s.figures;
      // Tier 1: Master / Deputy / Successor strategic posture
      if (figs.master && !figs.master.dead) {
        s.masterDoctrineId = figs.master.doctrineId;
        s.masterDoctrineNameTh = figs.master.doctrineNameTh;
      }
      // Tier 2: Discipline Elder checks for renegades in player sect OR dispatches assassin squad if defied!
      if (figs.disciplineElder && !figs.disciplineElder.dead) {
        const renegadeInPlayer = (W.npcs || []).find(n => n && !n.dead && !n.exiled && n.renegadeOrigin && n.renegadeOrigin.sectId === s.id && n.renegadeOrigin.pursuitStatus === 'PENDING_ULTIMATUM');
        if (renegadeInPlayer && ((W.day || 360) >= (renegadeInPlayer.renegadeOrigin.ultimatumDueDay || 0) || opts.forcePursuitCheck)) {
          const ultRes = X.issueExtraditionUltimatum(W, renegadeInPlayer, { quiet: opts.quiet });
          if (ultRes && ultRes.ok) tierActions.push({ tier: 2, role: 'disciplineElder', sectId: s.id, action: 'ISSUE_EXTRADITION_ULTIMATUM', ultimatum: ultRes.ultimatum });
        } else if (s.assassinThreat) {
          const protectedRenegade = (W.npcs || []).find(n => n && !n.dead && !n.exiled && n.renegadeOrigin && n.renegadeOrigin.sectId === s.id && n.renegadeOrigin.pursuitStatus === 'PROTECTED');
          if (protectedRenegade) {
            const clashRes = X.triggerRenegadePursuitClash(W, s, protectedRenegade, { quiet: opts.quiet });
            if (clashRes && clashRes.ok) tierActions.push({ tier: 2, role: 'disciplineElder', sectId: s.id, action: 'ASSASSIN_PURSUIT_CLASH', repelled: clashRes.repelled });
          } else {
            s.assassinThreat = false;
          }
        }
      }
      // Tier 2: Craft Elder updates specialty alchemy/forge trade readiness
      if (figs.craftElder && !figs.craftElder.dead) {
        s.craftSurplusOffer = {
          elderId: figs.craftElder.id,
          elderNameTh: figs.craftElder.titleAndNameTh,
          alchemySkill: (figs.craftElder.h && figs.craftElder.h.skills && figs.craftElder.h.skills.ALCHEMY) || 80,
          forgingSkill: (figs.craftElder.h && figs.craftElder.h.skills && figs.craftElder.h.skills.FORGING) || 80,
          bonusTradeMult: 1.15
        };
      }
      // Tier 2: War Marshal updates coalition & patrol readiness
      if (figs.warMarshal && !figs.warMarshal.dead) {
        s.marshalReadiness = {
          marshalId: figs.warMarshal.id,
          marshalNameTh: figs.warMarshal.titleAndNameTh,
          combatPower: figs.warMarshal.power || 400,
          readyForCoalition: (s.attitude || 0) >= 60 || !!s.eternalSwornAlly
        };
      }
      // Tier 3: Core Disciples incremental training
      if (Array.isArray(figs.coreDisciples)) {
        figs.coreDisciples.forEach(cd => {
          if (cd && !cd.dead) cd.power = Math.round((cd.power || 180) * 1.01);
        });
      }
    });

    // Annual/Monthly Eternal Sworn Ally Tribute
    all.filter(s => s && s.eternalSwornAlly).forEach(s => {
      if (opts.collectSwornTribute || ((W.day || 360) % 360 === 0)) {
        const wantTrib = s.annualTributeStones || 450;
        const trib = (ECO && ECO.earnFromPool)
          ? ECO.earnFromPool(W, wantTrib, 'บรรณาการพันธมิตรร่วมสาบานนิรันดร์จาก「' + s.nameTh + '」', { rivalSect: s })
          : ((ECO && ECO.earn && ECO.earn(W, wantTrib, 'บรรณาการพันธมิตรร่วมสาบานนิรันดร์จาก「' + s.nameTh + '」')) ? wantTrib : 0);
        tierActions.push({ tier: 1, role: 'master', sectId: s.id, action: 'SWORN_ALLY_TRIBUTE', stones: trib });
      }
    });

    return { ok: true, tierActions };
  };

  X.issueExtraditionUltimatum = (W, npcOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    if (!Array.isArray(W.world.extraditionUltimatums)) W.world.extraditionUltimatums = [];

    const npc = typeof npcOrId === 'object' && npcOrId
      ? npcOrId
      : (W.byId && W.byId[npcOrId]) || (W.npcs || []).find(n => n && !n.dead && !n.exiled && n.renegadeOrigin);
    if (!npc || npc.dead || npc.exiled) return { ok: false, reason: 'renegade-npc-not-found' };

    const ro = npc.renegadeOrigin || (npc.h && npc.h.renegadeOrigin);
    if (!ro) return { ok: false, reason: 'not-a-renegade' };

    const existing = W.world.extraditionUltimatums.find(u => u && u.npcId === npc.id && u.status === 'PENDING');
    if (existing && !opts.force) return { ok: true, ultimatum: existing, alreadyPending: true };

    const s = X.findSect(W, ro.sectId) || (W.world.allSects && W.world.allSects[0]);
    const discElder = (s && s.figures && s.figures.disciplineElder) || (s && s.figures && s.figures.master);
    const bounty = ro.bounty || Math.round(280 + ((npc.cult && npc.cult.stage) || 3) * 120);
    const indemnityStones = Math.round(bounty * 1.1);

    W.world.ultimatumSeq = (W.world.ultimatumSeq || 0) + 1;
    const ult = {
      id: 'ULT_' + W.world.ultimatumSeq + '_' + (W.day || 360),
      day: W.day || 360,
      expiresDay: (W.day || 360) + 30,
      npcId: npc.id,
      npcNameTh: HC.fullName(npc),
      formerPost: ro.formerPost || 'successor',
      formerPostTh: ro.formerPostTh || 'อดีตศิษย์สืบทอด',
      offenseType: ro.offenseType || 'SUCCESSION_DEFECTION',
      sectId: s ? s.id : ro.sectId,
      sectNameTh: s ? s.nameTh : ro.sectNameTh,
      disciplineElderId: discElder ? discElder.id : null,
      disciplineElderNameTh: discElder ? discElder.titleAndNameTh : 'ผู้อาวุโสหอวินัย',
      bounty,
      indemnityStones,
      status: 'PENDING',
      titleTh: 'สารทวงตัวผู้ลี้ภัยจาก「' + (s ? s.nameTh : ro.sectNameTh) + '」: ทวงตัว「' + HC.fullName(npc) + '」!',
      descTh: (discElder ? discElder.titleAndNameTh : 'ผู้อาวุโสหอวินัย') + ' แห่ง「' + (s ? s.nameTh : ro.sectNameTh) + '」ส่งทูตถือสารคำขาดมาถึงหน้าด่าน เรียกร้องให้สำนักเราส่งตัว「' + HC.fullName(npc) + '」(' + (ro.formerPostTh || 'ผู้ลี้ภัย') + ') กลับไปรับโทษตามกฎหอวินัย มิฉะนั้นจะถือเป็นศัตรูคู่แค้น!'
    };
    ro.pursuitStatus = 'ULTIMATUM_ISSUED';
    ro.activeUltimatumId = ult.id;
    npc.renegadeOrigin = ro;
    if (npc.h) npc.h.renegadeOrigin = ro;

    W.world.extraditionUltimatums.unshift(ult);
    if (W.world.extraditionUltimatums.length > 25) W.world.extraditionUltimatums.length = 25;

    const chron = X.recordChronicle(W, {
      category: 'SUCCESSION',
      icon: '📜',
      macroRegion: (s && s.macroRegion) || 'CENTRAL_HEARTLAND',
      involvedSects: [s ? s.nameTh : ro.sectNameTh, W.sect.name],
      involvedFigures: [discElder ? discElder.titleAndNameTh : 'ผู้อาวุโสหอวินัย', HC.fullName(npc)],
      titleTh: ult.titleTh,
      storyTh: ult.descTh,
      consequenceTh: 'รอการตัดสินใจของเจ้าสำนัก: ปกป้องศิษย์ / เจรจาไถ่ตัวด้วยศิลาวิญญาณ / ส่งตัวคืนสำนักเดิม',
      quiet: opts.quiet
    });

    return { ok: true, ultimatum: ult, chronicle: chron };
  };

  X.resolveExtraditionUltimatum = (W, ultimatumOrNpcId, choice, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    if (!Array.isArray(W.world.extraditionUltimatums)) W.world.extraditionUltimatums = [];

    let ult = typeof ultimatumOrNpcId === 'object' && ultimatumOrNpcId
      ? ultimatumOrNpcId
      : W.world.extraditionUltimatums.find(u => u && (u.id === ultimatumOrNpcId || u.npcId === ultimatumOrNpcId) && u.status === 'PENDING');
    if (!ult) {
      const candidateNpc = (W.byId && W.byId[ultimatumOrNpcId]) || (W.npcs || []).find(n => n && !n.dead && n.renegadeOrigin);
      if (candidateNpc) {
        const gen = X.issueExtraditionUltimatum(W, candidateNpc, { quiet: true, force: true });
        ult = gen && gen.ultimatum;
      }
    }
    if (!ult) return { ok: false, reason: 'ultimatum-not-found' };

    const npc = W.byId && W.byId[ult.npcId];
    const s = X.findSect(W, ult.sectId);
    const act = String(choice || 'DEFY_PROTECT').toUpperCase();
    const ro = (npc && (npc.renegadeOrigin || (npc.h && npc.h.renegadeOrigin))) || {};

    let titleTh = '', storyTh = '', consequenceTh = '';
    let attitudeDelta = 0;

    if (act === 'DEFY_PROTECT' || act === 'PROTECT') {
      ult.status = 'PROTECTED';
      ult.resolvedChoice = 'DEFY_PROTECT';
      ult.resolvedDay = W.day || 360;
      if (npc) {
        ro.gratitude = (ro.gratitude || 0) + 50;
        ro.pursuitStatus = 'PROTECTED';
        ro.vendettaUnlocked = (npc.cult && npc.cult.stage >= 5);
        npc.renegadeOrigin = ro;
        npc.gratitude = (npc.gratitude || 0) + 50;
        npc.sat = 100;
        if (npc.h) {
          npc.h.renegadeOrigin = ro;
          if (npc.h.personality) npc.h.personality.loyalty = 100;
          if (npc.h.state) {
            npc.h.state.mood = 100;
            npc.h.state.heartDemon = Math.max(0, (npc.h.state.heartDemon || 0) - 20);
          }
          if (npc.h.life && Array.isArray(npc.h.life.bio)) {
            npc.h.life.bio.push({
              age: HC.ageYears ? Math.round(HC.ageYears(npc)) : 22,
              t: 'สำนักฉีกสารคำขาดของ「' + ult.sectNameTh + '」ออกปกป้องด้วยชีวิต สาบานภักดีชั่วนิรันดร์'
            });
          }
          if (npc.h.mind && Array.isArray(npc.h.mind.memories)) {
            npc.h.mind.memories.unshift({
              day: W.day || 360,
              kind: 'protected_from_extradition',
              text: 'เจ้าสำนักฉีกสารคำขาดของ「' + ult.sectNameTh + '」ต่อหน้าทูตเพื่อปกป้องข้า บุญคุณนี้ต้องทดแทนด้วยชีวิต!'
            });
          }
        }
        if (W.sect && W.sect.masterId && g.SECT && g.SECT.rel) {
          const rM = g.SECT.rel(npc, W.sect.masterId);
          rM.a = clamp((rM.a || 20) + 35, -100, 100);
          rM.r = clamp((rM.r || 25) + 40, -100, 100);
          rM.g = clamp((rM.g || 20) + 50, 0, 100);
          rM.bond = 'ผู้มีพระคุณคุ้มกะลาหัว';
        }
      }
      // Righteous disciples in the sect feel proud of the Master's courage
      (W.npcs || []).forEach(n => {
        if (n && !n.dead && !n.exiled && n !== npc && HC.eff(n, 'personality.integrity') >= 58) {
          n.sat = clamp((n.sat || 70) + 4, 0, 100);
          if (n.h && n.h.state) n.h.state.mood = clamp((n.h.state.mood || 60) + 5, 0, 100);
        }
      });
      attitudeDelta = opts.attitudeDrop != null ? -Math.abs(opts.attitudeDrop) : -50;
      if (s) {
        s.attitude = clamp((s.attitude || 0) + attitudeDelta, -100, 100);
        s.treaty = 'RIVAL_FEUD';
        s.assassinThreat = true;
      }
      W.fame(5);
      titleTh = 'ฉีกสารทวงตัว! 「' + W.sect.name + '」ประกาศปกป้อง「' + ult.npcNameTh + '」ด้วยศักดิ์ศรี!';
      storyTh = 'เจ้าสำนักฉีกสารคำขาดของ「' + ult.disciplineElderNameTh + '」แห่ง「' + ult.sectNameTh + '」ต่อหน้าทูต ประกาศก้องว่าผู้ที่ก้าวเข้าสู่ประตูสำนักเราแล้วคือคนของเรา! 「' + ult.npcNameTh + '」คุกเข่าโขกศีรษะด้วยความซาบซึ้งใจอย่างสุดซึ้ง (ความซาบซึ้ง +50 · ความภักดีเต็ม 100) ขณะที่「' + ult.sectNameTh + '」โกรธเกรี้ยวตัดสัมพันธ์ทางการค้าและส่งมือสังหารออกตามล่า!';
      consequenceTh = ult.npcNameTh + ' ซาบซึ้งใจ +50 (ภักดี 100%) · ความสัมพันธ์กับ ' + ult.sectNameTh + ' ลดลง ' + attitudeDelta + ' (ปลดล็อกเส้นทางศึกทวงคืนสำนักเดิมเมื่อตบะถึงขั้น 5)';
    } else if (act === 'INDEMNITY_SETTLEMENT' || act === 'SETTLE') {
      const cost = opts.free ? 0 : (ult.indemnityStones || 320);
      if (!opts.free && W.sect.stones < cost) {
        return { ok: false, reason: 'insufficient-stones', required: cost };
      }
      if (cost > 0 && ECO && ECO.pay) {
        ECO.pay(W, cost, 'ค่าไถ่ถอนข้อกล่าวหาให้แก่「' + ult.npcNameTh + '」ต่อ' + ult.sectNameTh);
      }
      ult.status = 'SETTLED';
      ult.resolvedChoice = 'INDEMNITY_SETTLEMENT';
      ult.resolvedDay = W.day || 360;
      if (npc) {
        ro.gratitude = (ro.gratitude || 0) + 25;
        ro.bounty = 0;
        ro.pursuitStatus = 'SETTLED';
        npc.renegadeOrigin = ro;
        if (npc.h) npc.h.renegadeOrigin = ro;
        npc.sat = clamp((npc.sat || 70) + 15, 0, 100);
      }
      attitudeDelta = 5;
      if (s) s.attitude = clamp((s.attitude || 0) + attitudeDelta, -100, 100);
      titleTh = 'เจรจาประนีประนอมสำเร็จ: ไถ่ถอนข้อกล่าวหาของ「' + ult.npcNameTh + '」ด้วยศิลาวิญญาณ!';
      storyTh = 'สำนักเรามอบศิลาวิญญาณ ' + cost + ' ก้อนแก่ทูตของ「' + ult.sectNameTh + '」เพื่อชดเชยความเสียหายและไถ่ตัว「' + ult.npcNameTh + '」อย่างเป็นทางการ หอวินัยของสำนักเดิมจึงยอมถอนหมายจับและยุติการตามล่า';
      consequenceTh = 'จ่าย ' + cost + ' ศิลาวิญญาณ · ' + ult.npcNameTh + ' พ้นข้อกล่าวหาโดยความสัมพันธ์ระหว่างสำนักไม่ตกต่ำ';
    } else if (act === 'EXTRADITE_RENEGADE' || act === 'EXTRADITE') {
      ult.status = 'EXTRADITED';
      ult.resolvedChoice = 'EXTRADITE_RENEGADE';
      ult.resolvedDay = W.day || 360;
      if (npc) {
        ro.pursuitStatus = 'EXTRADITED';
        npc.exiled = true;
        npc.extradited = true;
        if (g.SIM && g.SIM.retire) {
          g.SIM.retire(W, npc, 'ส่งตัวผู้ทรยศคืนสำนักเดิม');
        } else {
          if (npc.post && W.sect && W.sect.posts && W.sect.posts[npc.post] === npc.id) W.sect.posts[npc.post] = null;
          npc.post = null;
          if (g.AI && g.AI.freeBed) g.AI.freeBed(W, npc);
          const idx = W.npcs.indexOf(npc);
          if (idx >= 0) W.npcs.splice(idx, 1);
          if (W.byId) delete W.byId[npc.id];
          if (Array.isArray(W.gone)) W.gone.push(npc.id);
        }
      }
      attitudeDelta = 25;
      if (s) s.attitude = clamp((s.attitude || 0) + attitudeDelta, -100, 100);
      W.fame(-10);
      (W.npcs || []).forEach(n => {
        if (n && !n.dead && !n.exiled) {
          n.sat = clamp((n.sat || 65) - 12, 0, 100);
          if (n.h && n.h.state) n.h.state.mood = clamp((n.h.state.mood || 55) - 10, 0, 100);
        }
      });
      titleTh = 'ส่งตัวผู้ลี้ภัยคืนสำนักเดิม: ส่ง「' + ult.npcNameTh + '」กลับไปรับโทษที่「' + ult.sectNameTh + '」';
      storyTh = 'เพื่อหลีกเลี่ยงสงครามข้ามสำนัก เจ้าสำนักตัดสินใจคุมตัว「' + ult.npcNameTh + '」ส่งมอบให้แก่ทูตหอวินัยของ「' + ult.sectNameTh + '」แม้ความสัมพันธ์กับสำนักเดิมจะดีขึ้น (+25) แต่ศิษย์ทั้งสำนักต่างรู้สึกสะเทือนใจและสูญเสียขวัญกำลังใจอย่างหนัก!';
      consequenceTh = 'ความสัมพันธ์กับ ' + ult.sectNameTh + ' +25 · ชื่อเสียงคุณธรรมสำนัก -10 · ขวัญกำลังใจศิษย์ในสำนักลดลง -12';
    } else {
      return { ok: false, reason: 'invalid-choice' };
    }

    const chron = X.recordChronicle(W, {
      reportFormat: 'DISCIPLINE_EDICT',
      category: 'SUCCESSION',
      icon: act.includes('PROTECT') ? '🛡️' : act.includes('SETTLE') ? '💎' : '⛓️',
      macroRegion: (s && s.macroRegion) || 'CENTRAL_HEARTLAND',
      involvedSects: [ult.sectNameTh, W.sect.name],
      involvedFigures: [ult.npcNameTh, ult.disciplineElderNameTh],
      titleTh,
      storyTh,
      originCauseTh: 'สารคำขาดจากหอวินัยแห่ง「' + ult.sectNameTh + '」(นำโดย ' + ult.disciplineElderNameTh + ') เรียกร้องให้ส่งตัวผู้ลี้ภัย「' + ult.npcNameTh + '」',
      actorChainTh: ult.disciplineElderNameTh + ' (ยื่นคำขาด) ➔ เจ้าสำนัก「' + W.sect.name + '」(ตัดสินใจ: ' + ult.resolvedChoice + ') ➔ ' + ult.npcNameTh,
      systemImpactTh: 'การตัดสินใจต่อชะตาผู้ลี้ภัย ➔ ตราตรึงความจงรักภักดีและความทรงจำของศิษย์ ➔ แรงกระเพื่อมต่อไมตรีและหน่วยสังหารหอวินัยสำนักเดิม ➔ ขวัญกำลังใจศิษย์ทั้งสำนัก',
      consequenceTh,
      quiet: opts.quiet
    });

    return {
      ok: true,
      choice: ult.resolvedChoice,
      ultimatum: ult,
      npc,
      sect: s,
      attitudeDelta,
      chronicle: chron
    };
  };

  X.tickRenegadePursuits = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false };
    return X.tickForeignSectCognitionTiers(W, Object.assign({}, opts, { forcePursuitCheck: !!opts.force }));
  };

  X.launchVendettaReclamation = (W, renegadeNpcOrId, party, opts) => {
    opts = opts || {};
    if (!W || !W.world || !W.sect) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);

    const npc = typeof renegadeNpcOrId === 'object' && renegadeNpcOrId
      ? renegadeNpcOrId
      : (W.byId && W.byId[renegadeNpcOrId]) || (W.npcs || []).find(n => n && !n.dead && !n.exiled && n.renegadeOrigin && n.renegadeOrigin.pursuitStatus === 'PROTECTED');
    if (!npc || npc.dead || npc.exiled) return { ok: false, reason: 'renegade-npc-not-found' };

    const ro = npc.renegadeOrigin || (npc.h && npc.h.renegadeOrigin);
    if (!ro || !ro.sectId) return { ok: false, reason: 'no-renegade-origin' };

    const minStage = opts.minStage || 5;
    const curStage = (npc.cult && npc.cult.stage) || 1;
    if (curStage < minStage && !opts.force) {
      return { ok: false, reason: 'insufficient-stage', stage: curStage, requiredStage: minStage };
    }

    const targetSect = X.findSect(W, ro.sectId);
    if (!targetSect) return { ok: false, reason: 'origin-sect-not-found' };

    const strikeParty = Array.isArray(party) && party.length
      ? party.map(p => typeof p === 'string' ? W.byId[p] : p).filter(Boolean)
      : [npc].concat((W.npcs || []).filter(n => n && !n.dead && !n.exiled && n.id !== npc.id).sort((a, b) => CULT.power(b) - CULT.power(a)).slice(0, 3));
    if (!strikeParty.includes(npc)) strikeParty.unshift(npc);

    const partyPower = strikeParty.reduce((sum, m) => sum + CULT.power(m), 0) * (1 + ((ro.gratitude || 50) / 200));
    const enemyPower = Math.max(200, Math.round((targetSect.power || 1.2) * 280));
    const won = opts.forceLose ? false : (opts.forceWin !== false && (partyPower >= enemyPower * 0.65 || opts.force));

    if (!won) {
      return { ok: false, won: false, reason: 'reclamation-repelled', partyPower: Math.round(partyPower), enemyPower };
    }

    const usurperMaster = targetSect.figures && targetSect.figures.master;
    if (usurperMaster) {
      usurperMaster.dead = true;
      usurperMaster.diedDay = W.day || 360;
      usurperMaster.deathCauseTh = 'ถูกโค่นล้มในศึกทวงคืนบัลลังก์สำนักโดย「' + HC.fullName(npc) + '」';
    }

    // Install the renegade disciple as the rightful new Sect Master of their original sect!
    const newMasterFig = X.generateProceduralSectFigure(W, targetSect, 'master', {
      stage: Math.max(curStage, (targetSect.tierLevel || 2) + 3),
      ageYears: HC.ageYears ? HC.ageYears(npc) : 28,
      path: npc.cult ? npc.cult.path : targetSect.majorPath,
      sub: npc.cult ? npc.cult.sub : 'NONE'
    });
    if (newMasterFig && npc.h) {
      newMasterFig.h.name = Object.assign({}, npc.h.name);
      newMasterFig.h.personality = Object.assign({}, npc.h.personality);
      newMasterFig.h.values = Object.assign({}, npc.h.values);
      newMasterFig.fullNameTh = HC.fullName(npc);
      newMasterFig.titleAndNameTh = HC.fullName(npc) + ' 「เจ้าสำนักผู้ทวงคืนบัลลังก์」';
      newMasterFig.reclaimedFromPlayerNpcId = npc.id;
    }
    targetSect.figures.master = newMasterFig;
    targetSect.leaderNameTh = newMasterFig.titleAndNameTh;
    targetSect.eternalSwornAlly = true;
    targetSect.reclaimedByPlayerSect = true;
    targetSect.reclaimedMasterNpcId = npc.id;
    targetSect.reclaimedMasterNameTh = HC.fullName(npc);
    targetSect.treaty = 'ETERNAL_SWORN_ALLY';
    targetSect.attitude = 100;
    targetSect.isVassal = false;
    targetSect.bannerTh = '[ พันธมิตรร่วมสาบานนิรันดร์ ]';
    targetSect.annualTributeStones = Math.round(420 + (targetSect.tierLevel || 2) * 120);

    ro.pursuitStatus = 'RECLAIMED_THRONE';
    ro.reclaimedDay = W.day || 360;
    npc.renegadeOrigin = ro;
    if (npc.h) npc.h.renegadeOrigin = ro;
    npc.ascendedToForeignMaster = targetSect.id;
    npc.ascendedSectNameTh = targetSect.nameTh;

    // Register Eternal Sworn Ally bond in W.world.jianghu so Player Sect Master can summon them in Jianghu bonds too
    if (W.world) {
      if (!W.world.jianghu) W.world.jianghu = { bonds: [] };
      if (!Array.isArray(W.world.jianghu.bonds)) W.world.jianghu.bonds = [];
      const masterId = (W.sect && W.sect.masterId) || npc.id;
      W.world.jianghu.bonds.unshift({
        id: 'BOND_RECLAIMED_' + targetSect.id + '_' + (W.day || 360),
        kind: 'SWORN_ALLY',
        active: true,
        npcId: masterId,
        memberId: masterId,
        figureId: newMasterFig.id,
        figureNameTh: newMasterFig.titleAndNameTh,
        sectId: targetSect.id,
        sectNameTh: targetSect.nameTh,
        power: newMasterFig.power || 520,
        createdDay: W.day || 360
      });
    }

    // Honorably depart player's active W.npcs roster to rule their reclaimed sect (unless keepInPlayerSect is requested)
    if (!opts.keepInPlayerSect) {
      if (g.AI && g.AI.cancelAct) g.AI.cancelAct(W, npc);
      if (npc.post && W.sect && W.sect.posts) { W.sect.posts[npc.post] = null; npc.post = null; }
      if (g.AI && g.AI.freeBed) g.AI.freeBed(W, npc);
      npc.retiredToThrone = true;
      const nIdx = (W.npcs || []).indexOf(npc);
      if (nIdx >= 0) W.npcs.splice(nIdx, 1);
      if (Array.isArray(W.gone) && !W.gone.includes(npc.id)) W.gone.push(npc.id);
    }

    const wantTribute = targetSect.annualTributeStones || 0;
    const immediateTribute = (wantTribute > 0 && ECO)
      ? (ECO.earnFromPool
        ? ECO.earnFromPool(W, wantTribute, 'บรรณาการฉลองชัยศึกทวงคืนสำนักจาก「' + targetSect.nameTh + '」', { rivalSect: targetSect })
        : ((ECO.earn && ECO.earn(W, wantTribute, 'บรรณาการฉลองชัยศึกทวงคืนสำนักจาก「' + targetSect.nameTh + '」')) ? wantTribute : 0))
      : 0;
    W.fame(18);

    const titleTh = 'ศึกทวงคืนบัลลังก์สำเร็จ! สถาปนา「' + HC.fullName(npc) + '」ขึ้นครอง「' + targetSect.nameTh + '」เป็นพันธมิตรร่วมสาบานนิรันดร์!';
    const storyTh = 'หลังฝึกฝนบ่มเพาะตบะใน「' + W.sect.name + '」จนบรรลุขั้น ' + curStage + ' 「' + HC.fullName(npc) + '」ได้นำกองทัพยอดฝีมือของสำนักเราบุกกลับไปยัง「' + targetSect.nameTh + '」โค่นล้มเจ้าสำนักผู้ทรยศ「' + (usurperMaster ? usurperMaster.titleAndNameTh : 'ผู้ชิงบัลลังก์') + '」ลงได้สำเร็จ! เหล่าผู้อาวุโสและศิษย์ทั้งสำนักต่างคุกเข่าต้อนรับ「' + HC.fullName(npc) + '」ขึ้นดำรงตำแหน่งเจ้าสำนักคนใหม่ พร้อมประกาศผูกพันธสัญญาเป็น「สำนักพันธมิตรเอกถาวร (Eternal Sworn Ally)」ส่งบรรณาการให้สำนักเราทุกปีชั่วนิรันดร์!';
    const consequenceTh = HC.fullName(npc) + ' ขึ้นเป็นเจ้าสำนัก「' + targetSect.nameTh + '」· สถานะเป็นพันธมิตรร่วมสาบานนิรันดร์ (ท่าที 100) · รับบรรณาการ ' + immediateTribute + ' ศิลาวิญญาณ/ปี · ชื่อเสียงสำนัก +18';

    // Cross-System Hook: Record Soul-Forge weapon feats for strike party & shift Caravan Market index after major war
    if (g.SECT && g.SECT.SOUL_FORGE && g.SECT.SOUL_FORGE.recordWeaponFeat) {
      strikeParty.forEach(m => {
        if (m && m.equip && m.equip.WEAPON) {
          g.SECT.SOUL_FORGE.recordWeaponFeat(W, m, 'โค่นผู้ชิงบัลลังก์แห่ง「' + targetSect.nameTh + '」ในศึกทวงคืนสำนัก', 35);
        }
      });
    }
    if (g.SECT && g.SECT.CARAVAN_AUCTION && g.SECT.CARAVAN_AUCTION.updateMarketIndex) {
      g.SECT.CARAVAN_AUCTION.updateMarketIndex(W, { warDemandBoost: true });
    }

    const chron = X.recordChronicle(W, {
      reportFormat: 'WAR_PAVILION_RECORD',
      category: 'BATTLE',
      icon: '👑',
      macroRegion: targetSect.macroRegion || 'CENTRAL_HEARTLAND',
      involvedSects: [W.sect.name, targetSect.nameTh],
      involvedFigures: [HC.fullName(npc), usurperMaster && usurperMaster.titleAndNameTh].filter(Boolean),
      titleTh,
      storyTh,
      originCauseTh: 'หนี้แค้นชิงบัลลังก์ของ「' + HC.fullName(npc) + '」(ความซาบซึ้งต่อสำนักเรา ' + Math.round(ro.gratitude || 50) + ') เมื่อบ่มเพาะตบะถึงขั้น ' + curStage,
      actorChainTh: HC.fullName(npc) + ' + ทัพหน้า「' + W.sect.name + '」➔ โค่นล้ม ' + (usurperMaster ? usurperMaster.titleAndNameTh : 'เจ้าสำนักผู้ทรยศ') + ' ➔ ขึ้นครอง「' + targetSect.nameTh + '」',
      systemImpactTh: HC.fullName(npc) + ' ก้าวขึ้นครองตำแหน่งเจ้าสำนัก「' + targetSect.nameTh + '」· ผูกสัตย์สาบานเป็นพันธมิตรนิรันดร์ (ส่งบรรณาการ ' + immediateTribute + ' ศิลา/ปี) · ขยายเครือข่ายสายใยยุทธภพและสั่งสมบารมีศาสตราคู่กาย',
      combatBreakdownTh: 'กำลังทัพทวงคืน ' + Math.round(partyPower) + ' บดขยี้ค่ายของ ' + targetSect.nameTh + ' (' + enemyPower + ')',
      consequenceTh,
      quiet: opts.quiet
    });

    if (SECT && SECT.recordTimelineMilestone) {
      SECT.recordTimelineMilestone(W, {
        milestoneType: 'WAR_VICTORY',
        icon: '👑',
        titleTh,
        descTh: consequenceTh,
        involvedIds: [npc.id]
      });
    }

    return {
      ok: true,
      won: true,
      sect: targetSect,
      newMasterFigure: newMasterFig,
      renegadeNpc: npc,
      eternalSwornAlly: true,
      annualTributeStones: targetSect.annualTributeStones,
      chronicle: chron
    };
  };

  /* ---------- Pillar 5: Coalition Sect War & Grand Siege Reinforcement Beacon ---------- */
  X.launchCoalitionOffensive = (W, party, targetSectOrId, allySectIds, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);

    if (!targetSectOrId && !opts.autoPickTarget) {
      return { ok: false, reason: 'missing-target-sect' };
    }
    const targetSect = X.findSect(W, targetSectOrId);
    if (!targetSect) return { ok: false, reason: 'invalid-target-sect' };

    const allSects = W.world.allSects || [];
    let allies = [];
    if (Array.isArray(allySectIds) && allySectIds.length) {
      allies = allySectIds.map(id => X.findSect(W, id)).filter(s => s && s.id !== targetSect.id && ((s.attitude || 0) >= 60 || s.eternalSwornAlly || ['ALLIANCE', 'ALLIANCE_PACT', 'VASSAL_TREATY'].includes(s.treaty) || opts.forceAllies));
    } else {
      allies = allSects.filter(s => s && s.id !== targetSect.id && ((s.attitude || 0) >= 60 || s.eternalSwornAlly || ['ALLIANCE', 'ALLIANCE_PACT', 'VASSAL_TREATY'].includes(s.treaty))).slice(0, 2);
    }
    allies = allies.slice(0, 2);
    if (!allies.length && !opts.forceAllies) {
      return { ok: false, reason: 'no-eligible-allies' };
    }

    const coalitionLeaders = [];
    let coalitionBonusPower = 0;
    allies.forEach(aSect => {
      const marshal = (aSect.figures && (aSect.figures.warMarshal || aSect.figures.master)) || null;
      const mPower = marshal ? (marshal.power || 360) : 320;
      const added = Math.round(mPower * 1.25 + (aSect.power || 1.2) * 180);
      coalitionBonusPower += added;
      coalitionLeaders.push({
        sectId: aSect.id,
        sectNameTh: aSect.nameTh,
        marshalId: marshal ? marshal.id : null,
        marshalNameTh: marshal ? marshal.titleAndNameTh : aSect.leaderNameTh,
        powerContributed: added
      });
    });

    const siegeRes = X.marshalStrikeForce(W, party, targetSect, Object.assign({}, opts, {
      immediate: opts.immediate !== false,
      coalitionBonusPower,
      coalitionAllies: coalitionLeaders
    }));

    if (!siegeRes || !siegeRes.ok) {
      return Object.assign({}, siegeRes || { ok: false, reason: 'siege-rejected' }, {
        isCoalitionOffensive: false,
        coalitionAllies: coalitionLeaders,
        coalitionBonusPower: 0
      });
    }

    if (siegeRes.siege) {
      siegeRes.siege.isCoalitionOffensive = true;
      siegeRes.siege.coalitionAllies = coalitionLeaders;
      siegeRes.siege.coalitionBonusPower = coalitionBonusPower;
    }

    const isQueued = !!siegeRes.queued;
    const isWon = !isQueued && !!siegeRes.won;
    const allyNamesTh = coalitionLeaders.map(c => '「' + c.sectNameTh + '」(นำโดยแม่ทัพศึก ' + c.marshalNameTh + ')').join(' และ ');
    const chron = X.recordChronicle(W, {
      category: 'BATTLE',
      icon: '🚩',
      macroRegion: targetSect.macroRegion || 'CENTRAL_HEARTLAND',
      involvedSects: [W.sect.name].concat(coalitionLeaders.map(c => c.sectNameTh), [targetSect.nameTh]),
      involvedFigures: coalitionLeaders.map(c => c.marshalNameTh),
      titleTh: isQueued
        ? ('ระดมทัพพันธมิตร: 「' + W.sect.name + '」เคลื่อนพลมุ่งหน้าสู่ค่าย「' + targetSect.nameTh + '」')
        : ('ศึกพันธมิตรร่วมทัพ: 「' + W.sect.name + '」สนธิกำลัง' + (isWon ? 'ถล่ม' : 'ปะทะ') + 'ค่าย「' + targetSect.nameTh + '」!'),
      storyTh: isQueued
        ? ('สำนักเราส่งเทียบเชิญพันธมิตรไปยัง ' + (allyNamesTh || 'สำนักพันธมิตร') + ' จัดทัพสมทบกำลังรบ +' + coalitionBonusPower + ' ออกเดินทางมุ่งหน้าสู่ค่ายของ「' + targetSect.nameTh + '」')
        : ('สำนักเราส่งเทียบเชิญพันธมิตรไปยัง ' + (allyNamesTh || 'สำนักพันธมิตร') + ' ยกทัพใหญ่ข้ามพรมแดนมาสมทบกันเปิดศึกปิดล้อมค่ายของ「' + targetSect.nameTh + '」เสริมกำลังรบรวมอีก +' + coalitionBonusPower + ' จนสะท้านสะเทือนไปทั้งยุทธภพ!'),
      combatBreakdownTh: 'กำลังหนุนจากแม่ทัพศึกพันธมิตร (' + coalitionLeaders.length + ' สำนัก): +' + coalitionBonusPower + ' คะแนนรบ · ผลศึก: ' + (isQueued ? 'กำลังเดินทัพ (รอปะทะเมื่อถึงค่าย)' : (isWon ? 'คว้าชัยชนะทั้ง 3 ด่าน!' : 'ถอยตั้งหลัก/ไม่สำเร็จ')),
      consequenceTh: isQueued
        ? ('กองทัพพันธมิตรกำลังเดินทางสู่「' + targetSect.nameTh + '」')
        : (isWon ? ('พิชิต「' + targetSect.nameTh + '」สำเร็จด้วยกำลังทัพพันธมิตร!') : ('ทัพพันธมิตรถอยจากค่าย「' + targetSect.nameTh + '」')),
      quiet: opts.quiet
    });

    if (isWon && SECT && SECT.recordTimelineMilestone) {
      SECT.recordTimelineMilestone(W, {
        milestoneType: 'WAR_VICTORY',
        icon: '🚩',
        titleTh: 'ชัยชนะสงครามพันธมิตรร่วมทัพเหนือ「' + targetSect.nameTh + '」',
        descTh: 'ร่วมทัพกับ ' + coalitionLeaders.map(c => c.sectNameTh).join(', ') + ' พิชิตค่ายของ ' + targetSect.nameTh
      });
    }

    return Object.assign({}, siegeRes, {
      isCoalitionOffensive: true,
      coalitionAllies: coalitionLeaders,
      coalitionBonusPower,
      chronicle: chron
    });
  };

  // World-side opportunities: hostility and advanced cultivation permit events, never guarantee them.
  X.considerNaturalEndgameEvents = W => {
    if (!W?.world || !W.sect || W.world.lastNaturalEndgameDay === W.day) return;
    W.world.lastNaturalEndgameDay = W.day;
    const living=(W.npcs||[]).filter(n=>n&&!n.dead&&!n.exiled&&n.cult);
    const stage=Math.max(0,...living.map(n=>CULT.effectiveTechStage(n)));
    const options=[{id:'wait',score:1}];
    const old=W.world.activeEnemySiege;
    if(old?.status==='BESIEGING' && W.day-(old.day||0)>=20)return X.triggerSiegeReinforcementBeacon(W,{requestReinforcements:false});
    if(stage>=3 && (!old || old.status!=='BESIEGING' && W.day-(old.resolvedDay||old.day||0)>=90)) {
      for(const s of W.world.allSects||[])if(s&&!s.destroyed&&!s.isVassal&&(s.attitude||0)<=-60 && (s.power||0)*320 >= living.reduce((p,n)=>p+CULT.power(n),0)*0.65)
        options.push({id:'siege:'+s.id,score:0.01,run:()=>X.startEnemyGrandSiege(W,s.id)});
    }
    const crisis=W.world.worldCrisisState;
    if(stage>=6 && (!crisis?.activeArc || crisis.activeArc.completed && W.day-(crisis.activeArc.completedDay||0)>=180))
      options.push({id:'crisis',score:0.015,run:()=>g.SECT.WORLD_CRISIS.startWorldCrisis(W,null,{deferChapter1:true})});
    const picked=W.rng.weighted(options,o=>o.score);
    return picked?.run ? picked.run() : {ok:false,reason:'wait'};
  };

  X.startEnemyGrandSiege = (W, attackerSectOrId, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);
    const all = W.world.allSects || [];
    const attacker = (attackerSectOrId && X.findSect(W, attackerSectOrId))
      || all.slice().sort((a, b) => (a.attitude || 0) - (b.attitude || 0))[0];
    if (!attacker) return { ok: false, reason: 'no-attacker-sect' };

    const marshal = (attacker.figures && (attacker.figures.warMarshal || attacker.figures.master)) || null;
    const siege = {
      id: 'ENEMY_SIEGE_' + (W.day || 360),
      day: W.day || 360,
      attackerSectId: attacker.id,
      attackerSectNameTh: attacker.nameTh,
      commanderNameTh: marshal ? marshal.titleAndNameTh : attacker.leaderNameTh,
      enemyPower: opts.enemyPower || Math.round(520 + (attacker.power || 1.5) * 320),
      status: 'BESIEGING',
      beaconLit: false
    };
    W.world.activeEnemySiege = siege;
    return { ok: true, enemySiege: siege };
  };

  X.triggerSiegeReinforcementBeacon = (W, opts) => {
    opts = opts || {};
    if (!W || !W.world) return { ok: false, reason: 'invalid-world' };
    X.ensureWorldTopology(W);
    X.ensureJianghuFigures(W);

    if (!W.world.activeEnemySiege || W.world.activeEnemySiege.status !== 'BESIEGING') {
      if (!opts.autoSpawnSiege) {
        return { ok: false, reason: 'no-active-siege' };
      }
      X.startEnemyGrandSiege(W, opts.attackerSectId, opts);
    }
    const siege = W.world.activeEnemySiege;
    if (!siege || siege.status !== 'BESIEGING' || siege.beaconLit) return { ok: false, reason: 'no-active-siege' };

    const allSects = W.world.allSects || [];
    let helpers = opts.requestReinforcements === false ? [] : allSects.filter(s => s && s.id !== siege.attackerSectId && ((s.attitude || 0) >= 60 || s.eternalSwornAlly || ['ALLIANCE', 'ALLIANCE_PACT', 'VASSAL_TREATY'].includes(s.treaty)));
    if (!helpers.length && opts.forceReinforcement === true) {
      helpers = allSects.filter(s => s && s.id !== siege.attackerSectId).slice(0, 1);
    }
    helpers = helpers.slice(0, 2);

    const playerPower = (W.npcs || []).filter(n => n && !n.dead && !n.exiled).reduce((sum, n) => sum + CULT.power(n), 0);
    let reinforcementPower = 0;
    const reinforcementLeaders = [];
    helpers.forEach(hSect => {
      const marshal = (hSect.figures && (hSect.figures.warMarshal || hSect.figures.master)) || null;
      const rPow = Math.round((marshal ? marshal.power : 350) * 1.3 + (hSect.power || 1.2) * 200);
      reinforcementPower += rPow;
      reinforcementLeaders.push({
        sectId: hSect.id,
        sectNameTh: hSect.nameTh,
        marshalNameTh: marshal ? marshal.titleAndNameTh : hSect.leaderNameTh,
        power: rPow
      });
    });

    const totalDefense = Math.round(playerPower + reinforcementPower);
    const won = opts.forceLose ? false : (opts.forceWin === true ? true : (totalDefense >= siege.enemyPower * 0.65));

    siege.beaconLit = opts.requestReinforcements !== false;
    siege.status = won ? (reinforcementLeaders.length ? 'REPELLED_BY_COALITION' : 'REPELLED') : 'BREACHED';
    siege.reinforcements = reinforcementLeaders;
    siege.resolvedDay = W.day || 360;
    if (W.threat && W.threat.raid && won) {
      W.threat.raid = null;
    }

    const spoilsStones = won ? Math.min(360, Math.max(0, Math.floor(W.world.resourcePool?.stones || 0))) : 0;
    if (won) {
      if (ECO && ECO.earn) ECO.earn(W, spoilsStones, 'ยึดเสบียงศึกจากการตีขนาบทัพศัตรูที่มาปิดล้อม', {fromPool:true});
      W.fame(10);
    }

    const helperText = reinforcementLeaders.map(r => '「' + r.sectNameTh + '」(นำโดย ' + r.marshalNameTh + ')').join(' และ ');
    const titleTh = won ? 'สำนักต้านทัพปิดล้อม「' + siege.attackerSectNameTh + '」สำเร็จ' : 'ทัพ「' + siege.attackerSectNameTh + '」ฝ่าวงป้องกันสำนัก';
    const storyTh = 'กองทัพของ「' + siege.attackerSectNameTh + '」นำโดย ' + siege.commanderNameTh + ' เข้าปะทะแนวป้องกันสำนัก' + (reinforcementLeaders.length ? ' โดยมีทัพหนุนจาก ' + helperText : ' โดยสำนักรับศึกด้วยกำลังของตนเอง') + (won ? ' ฝ่ายป้องกันขับไล่ผู้รุกรานสำเร็จ' : ' ฝ่ายป้องกันไม่อาจหยุดการบุกได้');
    const consequenceTh = won ? 'ทำลายวงล้อมสำเร็จ · ยึดศิลาวิญญาณ +' + spoilsStones + ' ก้อน · ชื่อเสียงสำนัก +10' : 'แนวป้องกันถูกฝ่า · ไม่ได้รับรางวัลชัยชนะ';

    const chron = X.recordChronicle(W, {
      category: 'BATTLE',
      icon: '🔥',
      macroRegion: 'CENTRAL_HEARTLAND',
      involvedSects: [W.sect.name, siege.attackerSectNameTh].concat(reinforcementLeaders.map(r => r.sectNameTh)),
      involvedFigures: [siege.commanderNameTh].concat(reinforcementLeaders.map(r => r.marshalNameTh)),
      titleTh,
      storyTh,
      combatBreakdownTh: 'กำลังป้องกันสำนัก (' + Math.round(playerPower) + ') + กองหนุนพันธมิตร (+' + reinforcementPower + ') = ' + totalDefense + (won ? ' ต้านทัพปิดล้อมสำเร็จ (' : ' ไม่อาจต้านทัพปิดล้อม (') + siege.enemyPower + ')',
      consequenceTh,
      quiet: opts.quiet
    });

    return {
      ok: true,
      won,
      enemySiege: siege,
      reinforcements: reinforcementLeaders,
      reinforcementPower,
      spoilsStones,
      chronicle: chron
    };
  };

  g.EXPED = X;
  if (typeof module === 'object' && module.exports) module.exports = X;

  /* ---------- Patch JS2-v2.6.0 Category 13: Tiangu & Three-Empires World Lore, Empire Spheres & 60 Canonical Legends ---------- */
  const REGION_TO_EMPIRE_SPHERE = {
    NORTHERN_PEAKS: { id: 'BEIMING', nameTh: 'เขตอิทธิพลจักรวรรดิเป่ยหมิง (สกุลกู่ · แดนเหนือ)' },
    EASTERN_PLAINS: { id: 'DONGHUANG', nameTh: 'เขตอิทธิพลมหาอาณาจักรตงหวง (สกุลซือหม่า · แดนตะวันออก)' },
    SOUTHERN_WATERS: { id: 'DONGHUANG', nameTh: 'เขตอิทธิพลมหาอาณาจักรตงหวงและแดนน้ำทักษิณ' },
    WESTERN_DESERTS: { id: 'XIRONG', nameTh: 'เขตอิทธิพลจักรวรรดิซีหรง (สกุลทัวป๋า · แดนตะวันตก)' },
    CENTRAL_HIGHLANDS: { id: 'BUFFER_INDEPENDENT', nameTh: 'เขตรอยต่อยุทธภพอิสระและซากนครหลวงเทียนกู่' }
  };
  if (Array.isArray(X.CANONICAL_SECTS)) {
    X.CANONICAL_SECTS.forEach(s => {
      if (!s) return;
      const sph = REGION_TO_EMPIRE_SPHERE[s.macroRegion] || REGION_TO_EMPIRE_SPHERE.CENTRAL_HIGHLANDS;
      try {
        s.empireSphere = sph.id;
        s.empireSphereNameTh = sph.nameTh;
      } catch (_) {}
    });
  }
  X.WORLD_LORE = Object.freeze({
    VERSION: '2.6.0-tiangu-canon',
    DIEGETIC_STAGE_NAMING_LORE_TH: g.CULT && g.CULT.LOWER_WORLD_CEILING_LORE_TH,
    UPPER_WORLD_DESCENT_LAW: g.CULT && g.CULT.UPPER_WORLD_DESCENT_LAW,
    ERAS: Object.freeze([
      { id: 'ERA_1_ANCIENT_TIANGU', nameTh: 'ยุคที่ 1: มหาจักรวรรดิเทียนกู่และสงครามรุกรานข้ามมิติ' },
      { id: 'ERA_2_SHATTERED_GATE', nameTh: 'ยุคที่ 2: การระเบิดประตูมิติหลวงและการผนึกม่านกั้นภพ' },
      { id: 'ERA_3_THREE_EMPIRES', nameTh: 'ยุคที่ 3: ยุคสามมหาอาณาจักร (เป่ยหมิง · ตงหวง · ซีหรง) และ 19 สำนักยุทธภพ' },
      { id: 'ERA_4_CURRENT_CONVERGENCE', nameTh: 'ยุคที่ 4: รอยร้าวประตูมิติใต้สำนักและการตื่นขึ้นของมรดกเทียนกู่' }
    ]),
    EMPIRES: Object.freeze({
      TIANGU: { id: 'TIANGU', codeNum: 0, nameTh: 'มหาจักรวรรดิโบราณเทียนกู่', royalClanTh: 'ราชวงศ์กู่โบราณ' },
      BEIMING: { id: 'BEIMING', codeNum: 1, nameTh: 'จักรวรรดิเป่ยหมิง (แดนเหนือ)', royalClanTh: 'สกุลกู่ (#46 กู่เทียนเฉิน / #47 กู่ชิงเสวี่ย)' },
      DONGHUANG: { id: 'DONGHUANG', codeNum: 2, nameTh: 'มหาอาณาจักรตงหวง (แดนตะวันออก)', royalClanTh: 'สกุลซือหม่า (#52 มหาเสนาบดีซือหม่าชิง / #54 เอี๊ยนหลัว)' },
      XIRONG: { id: 'XIRONG', codeNum: 3, nameTh: 'จักรวรรดิซีหรง (แดนตะวันตก)', royalClanTh: 'สกุลทัวป๋า (#57 ทัวป๋าหงเหลียน)' }
    }),
    ERA5_SURVIVOR_LONGEVITY_RULES: Object.freeze({
      STASIS_SEAL: 'ผนึกน้ำแข็งนิรันดร์และค่ายกลหยุดเวลา (กู่เย่ #3, หลี่เจี้ยนซิน #6)',
      SOUL_VESSEL_RELIC: 'ฝากดวงจิตไว้ในหุ่นหยกขาวและศาสตราเทพ (กงซูจี #15, โอวหยางเหยียน #14)',
      THOUSAND_YEAR_COCOON: 'จำศีลผลัดเปลี่ยนเนื้อหนังในรังไหมบรรพกาล (ไป๋เฉ่า #13)',
      CRIPPLED_UPPER_WORLD_STRANDING: 'ผู้มาจากโลกเบื้องบนที่บาดเจ็บจนตบะร่วงหล่นต่ำกว่าเกณฑ์ม่านฟ้า จึงไม่ถูกม่านกั้นภพดีดกลับ (ขงหมิง #21, เฮ่อเหลียนม่อ #19)'
    }),
    SCHEMA_REMAPPINGS: Object.freeze({
      ASTRAL_NOMAD_STARSHIP_DAO: 'TIDE_VOYAGER',
      CELESTIAL_JURISPRUDENCE_DAO: 'STRATEGY_GOVERNANCE',
      REL_V250_ASTRAL_NOMAD_STARSHIP_DAO: 'REL_V230_TIDE_VOYAGER',
      CURRENCY_GOLD_TO_STONES: 'ศิลาวิญญาณ (Closed-Loop ECO.transferStones)'
    }),
    NOTABLE_FIGURES: Object.freeze({
      1: { id: 'FIG_01_GU_XUANYUAN', nameTh: 'จักรพรรดิองค์สุดท้าย กู่เสวียนหยวน (#1)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'ผู้สละราชบัลลังก์ระเบิดประตูมิติหลวงเพื่อผนึกม่านฟ้า' },
      6: { id: 'FIG_06_LI_JIANXIN', nameTh: 'หัวหน้าองครักษ์หลวง หลี่เจี้ยนซิน (#6)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'ผู้ถือกระบี่เหล็กนิลไร้คมยืนหยัดหน้าประตูเมืองเทียนกู่ 7 วัน 7 คืน' },
      8: { id: 'FIG_08_YE_QINGCANG', nameTh: 'ขุนพลตาเดียว เย่ชิงชาง (#8)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'ผู้เหนี่ยวธนูเหล็กไหลยิงนาวาฟ้าของทัพรุกรานร่วงหล่น' },
      13: { id: 'FIG_13_BAI_CAO', nameTh: 'หมอหลวง ไป๋เฉ่า (#13)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'ผู้รจนาตำราฝังเข็มเก้าดาราและเตาหลอมหมื่นโอสถ' },
      14: { id: 'FIG_14_OUYANG_YAN', nameTh: 'ปรมาจารย์ช่างหลอม โอวหยางเหยียน (#14)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'ผู้หลอมกระบี่อิงฟ้าพิฆาตมารและดาบฆ่ามังกรบัญชาหล้าจากเหล็กดาวตก' },
      15: { id: 'FIG_15_GONGSHU_JI', nameTh: 'เจ้ากรมกลไก กงซูจี (#15)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'ผู้สร้างหุ่นเชิดกายทิพย์และขนนกยูงทองคำกลไกสวรรค์' },
      16: { id: 'FIG_16_XINGCHENZI', nameTh: 'นักพรตดารา ซิงเฉินจื่อ (#16)', era: 'ERA_1_ANCIENT_TIANGU', roleTh: 'เจ้าหอพยากรณ์ดาราผู้ทิ้งป้ายหยกดาราสืบทอดถึงซิงอวิ๋น (#49)' },
      19: { id: 'FIG_19_HELIAN_MO', nameTh: 'แม่ทัพศัตรูตกค้าง เฮ่อเหลียนม่อ (#19)', era: 'ERA_2_SHATTERED_GATE', roleTh: 'แม่ทัพผู้รุกรานที่บาดเจ็บจนตบะพังทลายและถูกผนึกพร้อมเศษศาสตรามาร' },
      21: { id: 'FIG_21_KONG_MING', nameTh: 'ทูตตกสวรรค์ ขงหมิง (#21)', era: 'ERA_2_SHATTERED_GATE', roleTh: 'ผู้มาจากโลกเบื้องบนที่บาดเจ็บจนตบะสูญสลาย จึงไม่ถูกม่านกั้นภพดีดกลับและเร้นกายทิ้งมรดกไว้ในโลกเบื้องล่าง' },
      25: { id: 'FIG_25_FACELESS_GATEKEEPER', nameTh: 'ผู้เฝ้าประตูไร้หน้า (#25)', era: 'ERA_2_SHATTERED_GATE', roleTh: 'ผู้พิทักษ์ซากประตูมิติหลวงใต้ฐานสำนัก' },
      30: { id: 'FIG_30_MO_JI', nameTh: 'จักรพรรดิกลไก ม่อจี๋ (#30)', era: 'ERA_2_SHATTERED_GATE', roleTh: 'ผู้วางรากฐานปราการศิลาจักรกลและสุสานจักรพรรดิกลไกพันปี' },
      38: { id: 'FIG_38_HONG_QI', nameTh: 'ราชันย์พเนจรผู้ลี้ภัย หงชี (#38)', era: 'ERA_3_THREE_EMPIRES', roleTh: 'ผู้ถือพลองหยกเขียวมรกตปราบพยัคฆ์คุ้มครองคาราวานผู้ลี้ภัย' },
      40: { id: 'FIG_40_PU_JAO_SAMING', nameTh: 'ปู่เจ้าสมิงพราย (#40)', era: 'ERA_3_THREE_EMPIRES', roleTh: 'ปรมาจารย์ไสยเวทย์บรรพกาลแห่งบึงทมิฬทักษิณ' },
      41: { id: 'FIG_41_KENSHIN', nameTh: 'ปรมาจารย์ดาบไร้เงา เคนชิน (#41)', era: 'ERA_3_THREE_EMPIRES', roleTh: 'ผู้ก่อตั้งสายวิชาหมู่เกาะบูรพาผาเมฆานอกม่านหมอก' },
      46: { id: 'FIG_46_GU_TIANCHEN', nameTh: 'จักรพรรดิเป่ยหมิง กู่เทียนเฉิน (#46)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'ประมุขสกุลกู่แห่งแดนเหนือผู้หมายฟื้นฟูบัลลังก์เทียนกู่' },
      47: { id: 'FIG_47_GU_QINGXUE', nameTh: 'องค์หญิงน้ำแข็ง กู่ชิงเสวี่ย (#47)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'ทายาทสายเลือดเหมันต์แห่งราชวงศ์เป่ยหมิง' },
      49: { id: 'FIG_49_XING_YUN', nameTh: 'ผู้สืบทอดดารา ซิงอวิ๋น (#49)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'ทายาทผู้ถือป้ายหยกดาราของซิงเฉินจื่อ (#16)' },
      52: { id: 'FIG_52_SIMA_QING', nameTh: 'มหาเสนาบดี ซือหม่าชิง (#52)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'ผู้กุมอำนาจสูงสุดแห่งมหาอาณาจักรตงหวง' },
      53: { id: 'FIG_53_WAN_JINNIANG', nameTh: 'นายหญิงหอการค้า ว่านจินเหนียง (#53)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'ประมุขเครือข่ายการค้าหมื่นสมุทรแห่งตงหวง' },
      54: { id: 'FIG_54_YAN_LUO', nameTh: 'หัวหน้าสำนักตรวจการ เอี๊ยนหลัว (#54)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'ผู้ถือมีดสั้นเสี่ยวหลี่และพู่กันพิพากษาแห่งตงหวง' },
      57: { id: 'FIG_57_TUOBA_HONGLIAN', nameTh: 'แม่ทัพหญิงเพลิงโลหิต ทัวป๋าหงเหลียน (#57)', era: 'ERA_4_CURRENT_CONVERGENCE', roleTh: 'จอมทัพหน้าแห่งจักรวรรดิซีหรงแดนตะวันตก' }
    }),
    STORY_RIPPLE_CANON_SYNC: Object.freeze({
      'STORY-SYNC-01': 'ยายเมิ่ง (#24) แบ่งเศษผ้ารองถาดน้ำชาแช่เย็นจากเรือสำราญสวรรค์เป็น 2 ส่วน: แกนกลางเป็นภูษาชั้นในผนึกเหมันต์ที่กู่หลิงเฟย (#2) สวมจำศีล ส่วนเศษด้ายขอบนอกทอเป็นอาภรณ์ขนนกกระเรียนสวรรค์ในซากอุทยานหลวง และปราณหยกใสหมิงยวี่ที่กู่เทียนเฉิน (#46) ฝึกโดยไร้ผ้าคุ้มกายจึงค่อยๆ แช่แข็งหัวใจตนเอง',
      'STORY-SYNC-02': 'ซือหม่าชุน (#4) ดัดแปลงสมุดระเบียบคุมทะเบียนทาสเหมืองและอักขระแปะผนึกลังส่วยของสวรรค์เป็นระบบปกครองตงหวง และคุณชายสาม ซือหม่าชิง (#52) แสร้งเสเพลกว้านซื้อของเก่าชำรุดทั่วแผ่นดินเพราะรู้ความจริงว่ามีเพียงของขยะไร้ปราณเซียนเท่านั้นที่รอดม่านกั้นภพลงมาได้',
      'STORY-SYNC-03': 'เถ้าแก่เฉียน (#22) นำโครงลูกคิดเหล็กเบี้ยวที่เสมียนเหมืองสวรรค์โยนทิ้งมาใส่ลูกปัดทองคำคลังหลวง 99 เม็ดซ่อนไว้ในเจดีย์หินริมผา และเก็บลูกปัดแม่กุญแจเม็ดที่ 100 ไว้ที่โต๊ะคิดเงินโรงเตี๊ยมไร้ชื่อริมทาง (อีเวนต์ #10)',
      'STORY-SYNC-04': 'ซิงเฉินจื่อ (#16) ใช้แผ่นจานจำลองกลุ่มดาวของเล่นเด็กจากตระกูลโหรสวรรค์ที่เฟืองบิ่นสองซี่ส่องพบว่าม่านกั้นภพหักเหดวงดาวและมีเงามืดเบื้องบนชักใย จึงซ่อนจานสวรรค์ไว้นอกหอดูดาวก่อนเวลาหยุดนิ่ง (อีเวนต์ #29) และส่งต่อภารกิจแก่ซิงอวิ๋น (#49)',
      'STORY-SYNC-05': 'ตราพยัคฆ์ไท่จี๋ประกาศิตทัพของทัวป๋าเลี่ย (#5) หล่อเป็น 2 ซีกคู่กัน: ทัวป๋ากัง (#60) เฝ้าซีกพยัคฆ์ขวาบนผาหินแดงซีหรงเพื่อถ่วงดุลทัวป๋าเจิ้นเทียน (#56) ส่วนซีกไท่จี๋ซ้ายจมอยู่ในค่ายทะเลทรายโบราณ (เควสต์เบาะแส)',
      'STORY-SYNC-06': 'กำไลหยกมังกรหงส์คู่สวรรค์ถูกแกะสลักเป็น 2 วงคู่กันจากหยกหลวงเทียนกู่: วงมังกรเหมันต์อยู่กับองค์หญิงกู่ชิงเสวี่ย (#47) ในฐานะตราตั้งรัชทายาทเป่ยหมิง ส่วนวงหงส์มังกรคู่บำเพ็ญตกค้างอยู่ในตำหนักหยกคู่กลางซากอุทยานหลวง',
      'STORY-SYNC-07': 'พญาอสูรคลั่ง โซ่วหวง (#31) นำเศษคราบปลอกเล็บผุของสุนัขคุ้ยซากสายเลือดเทาเที่ยเจือจางที่ร่วงจากรอยแยกอเวจีมาตีเป็นกรงเล็บเทาเที่ย จนคืนจันทร์สีเลือดสัญชาตญาณตะกละในคราบอเวจีปลุกฝูงสัตว์เลี้ยงหันกลับมาฉีกเนื้อโซ่วหวงกินทั้งเป็น (อีเวนต์ #8)',
      'STORY-SYNC-08': 'แม่ทัพหญิง มู่หรงเสวี่ย (#7) เผาอายุขัยและแก่นโลหิตทั้งหมดเป็นบงกชโลหิตระเบิดสังหารร่างทรงที่อัญเชิญเศษเสี้ยวจิตหนึ่งในพันส่วนของผู้ตรวจการโลกเบื้องบนลงมาประทับกลางสนามรบ (อีเวนต์ #20)',
      'STORY-SYNC-09': 'เซียนกระบี่ขี้เมา จิ้วเจี้ยนเซียน (#39) แทงหนึ่งกระบี่เซียนเหินจากฟากฟ้าสะกิดม่านกั้นภพเป็นรูเข็มเหนือซากอุทยานหลวง และเห็นคนกวาดถนนชั้นต่ำบนโลกเบื้องบนสะบัดไม้กวาดปัดปราณกระบี่สูงสุดของเขาดับวูบเหมือนปัดขี้เถ้าไฟ (อีเวนต์ #35)',
      'STORY-SYNC-10': 'ทูตตกสวรรค์ ขงหมิง (#21) คืออดีตผู้เหินหาวที่ถูกส่งลงมาเป็นเบี้ยสงครามและถูกแรงระเบิดประตูมิติหลวงบดขยี้ตันเถียนจนตบะร่วงต่ำกว่าเกณฑ์ม่านฟ้า จึงติดค้างในโลกล่างถาวร ส่วนเสิ่นเทียนจุน (#28) ใช้เศษใบปลิวบทสวดคนรับใช้หน้าประตูวัดสวรรค์ทำพิธีจนถูกม่านฟ้าตบสวน (อีเวนต์ #25)',
      'STORY-SYNC-11': 'ศาสตรา REL_V230_* ของปรมาจารย์ทั้ง 5 (#17 ซูเหยียน, #28 เสิ่นเทียนจุน, #35 ไป๋อวี่, #40 ปู่เจ้าสมิงพราย, #41 เคนชิน) คือศาสตราต้นกำเนิดคู่ชีพปฐมครู ส่วน REC_REL_V230_* ที่สำนักหลอมขึ้นคือศาสตราจำลองภาชนะมรรคา และโซ่ตรวนอาญาสวรรค์เทียนกู่ทำงานโดยสกัดจุดตัดการเชื่อมต่อของร่างทรงในโลกล่าง',
      'STORY-SYNC-12': 'ซากอุทยานสวรรค์คือซากพระราชอุทยานหลวงเทียนกู่ที่จักรพรรดิกู่เสวียนหยวน (#1) สร้างจำลองสวรรค์และรวบรวมเศษวัตถุตกจากฟากฟ้า ส่วนเศษหยกโลกเบื้องบนในอีเวนต์ #7 คือเศษกรวดหางแร่ก้นเหมืองศิลาเซียนที่ทาสผู้เหินหาวสลักอักษรเลือดเตือนภัยทิ้งลงเหวมิติ'
    })
  });

  X.TAVERN_BALLAD_TEMPLATES = Object.freeze([
    {
      id: 'BALLAD_01_BEIMING_FROST',
      macroRegion: 'NORTHERN_PEAKS',
      titleTh: 'ข่าวลือพายุหิมะตำหนักน้ำแข็งเป่ยหมิง',
      storyTh: 'นักเดินทางจากแดนเหนือร่ำลือในวงสุราว่า พายุหิมะรอบตำหนักน้ำแข็งต้องห้ามแห่งเป่ยหมิงทวีความหนาวเหน็บผิดปกติ คล้ายผู้ครองบัลลังก์กำลังเร่งเสาะหาโอสถธาตุหยางล้ำค่ามารักษาโรคร้ายในสายเลือด',
      involvedSects: ['ราชสำนักเป่ยหมิง'],
      involvedFigures: ['กู่เทียนเฉิน (#46)', 'กู่ชิงเสวี่ย (#47)']
    },
    {
      id: 'BALLAD_02_DONGHUANG_CURIOS',
      macroRegion: 'EASTERN_PLAINS',
      titleTh: 'ข่าวลือคุณชายตงหวงกว้านซื้อถ้วยชามร้าวโบราณ',
      storyTh: 'พ่อค้าของเก่าจากเมืองตงหวงหัวเราะเล่าว่า ช่วงนี้มีคนของหอการค้าใหญ่เที่ยวเดินกว้านซื้อถ้วยชามร้าวและเศษพัดพังๆ ตามแผงแบกะดินด้วยราคาสูงลิ่ว ไม่มีใครเข้าใจว่าซื้อเศษของเก่าไปทำไม',
      involvedSects: ['หอการค้าตงหวง'],
      involvedFigures: ['ว่านจินเหนียง (#53)', 'ซือหม่าชิง (#52)']
    },
    {
      id: 'BALLAD_03_XIRONG_PHANTOM_SPEARS',
      macroRegion: 'WESTERN_BADLANDS',
      titleTh: 'ข่าวลือเสียงทวนปะทะกลางพายุทรายสีเลือด',
      storyTh: 'ทหารรับจ้างชายแดนตะวันตกโจษจันกันว่า ยามค่ำคืนที่มีพายุทรายสีเลือด มักได้ยินเสียงทวนเหล็กปะทะกันดังกึกก้องมาจากซากป้อมโบราณ ราวกับกองทัพเมื่อแสนปีก่อนยังไม่รู้ตัวว่าสงครามจบสิ้นแล้ว',
      involvedSects: ['กองทัพซีหรง'],
      involvedFigures: ['ทัวป๋าหงเหลียน (#57)', 'เฮ่อเหลียนม่อ (#19)']
    },
    {
      id: 'BALLAD_04_SOUTHERN_GHOST_JUNK',
      macroRegion: 'SOUTHERN_WATERS',
      titleTh: 'ข่าวลือสำเภาโบราณฝ่าทะเลหมอกทักษิณ',
      storyTh: 'ชาวประมงริมทะเลหมอกทักษิณเล่าขานด้วยความหวาดผวาว่า ในคืนไร้จันทร์จะมีเงาสำเภาโบราณขาดวิ่นแล่นฝ่าม่านหมอกเข้ามาเทียบท่า พร้อมสินค้านอกแผ่นดินที่ไม่เคยมีใครพบเห็นมาก่อน',
      involvedSects: ['สมาคมการค้าหุบเขาสองแคว'],
      involvedFigures: ['ปู่เจ้าสมิงพราย (#40)']
    },
    {
      id: 'BALLAD_05_VALLEY_STONE_HEARTBEAT',
      macroRegion: 'CENTRAL_HEARTLAND',
      titleTh: 'ข่าวลือเสียงหัวใจศิลาเต้นใต้ก้นเหวหุบเขาสองแคว',
      storyTh: 'พรานเฒ่าในหุบเขาสองแควกระซิบว่า บางคืนที่ได้แนบหูกับพื้นหินก้นเหว จะได้ยินเสียงหัวใจศิลาเต้นเป็นจังหวะทุ้มลึกอยู่ใต้ผืนดินที่ตั้งสำนักใหญ่ใจกลางหุบเขา',
      involvedSects: [],
      involvedFigures: ['ผู้เฝ้าประตูไร้หน้า (#25)']
    },
    {
      id: 'BALLAD_06_FALLING_ENVOY_CHESS',
      macroRegion: 'CENTRAL_HEARTLAND',
      titleTh: 'ข่าวลือนักพรตพเนจรวางหมากหินริมผาเมฆา',
      storyTh: 'เสี่ยวเอ้อร์โรงเตี๊ยมด่านหน้าเล่าว่า มีนักพรตชราในชุดผ้าป่านขาดวิ่นเคยวางเศษหยกสลักอักษรประหลาดจ่ายค่าสุรา ก่อนถอนหายใจแหงนมองม่านฟ้าเหมือนคนคิดถึงบ้านที่ไม่มีวันกลับไปได้',
      involvedSects: [],
      involvedFigures: ['ทูตตกสวรรค์ ขงหมิง (#21)']
    },
    {
      id: 'BALLAD_07_IRON_SWORD_MOUND',
      macroRegion: 'NORTHERN_PEAKS',
      titleTh: 'ข่าวลือเสียงกระบี่เหล็กนิลคร่ำครวญหน้าซากกำแพงหลวง',
      storyTh: 'คนตัดฟืนแถบเทือกเขาเหนือยืนยันว่า ยามสายลมเหมันต์พัดผ่านเนินกระบี่ร้าง จะได้ยินเสียงโลหะหนักอึ้งสั่นสะท้านตอบรับ ราวกับดวงวิญญาณองครักษ์โบราณยังคงยืนเฝ้าประตูเมืองที่พังทลายไปแล้ว',
      involvedSects: [],
      involvedFigures: ['หลี่เจี้ยนซิน (#6)']
    },
    {
      id: 'BALLAD_08_GOLDEN_PEACOCK_GEAR',
      macroRegion: 'WESTERN_BADLANDS',
      titleTh: 'ข่าวลือขนนกยูงทองคำในสุสานจักรพรรดิกลไก',
      storyTh: 'นักขุดสุสานที่รอดตายกลับมาเพ้อในโรงน้ำชาว่า ลึกเข้าไปในสุสานกลไกพันปีมีหุ่นหยกขาวที่ยังขยับนิ้วดีดลูกคิดและซ่อมแซมกระบอกกลไกขนนกยูงอยู่ลำพังในความมืด',
      involvedSects: [],
      involvedFigures: ['กงซูจี (#15)', 'ม่อจี๋ (#30)']
    },
    {
      id: 'BALLAD_09_THOUSAND_YEAR_COCOON',
      macroRegion: 'SOUTHERN_WATERS',
      titleTh: 'ข่าวลือกลิ่นหอมโอสถเก้าดารากลางบึงหมอกพิษ',
      storyTh: 'คนเก็บสมุนไพรร่ำลือว่า ทุกคืนวันเพ็ญจะมีผีเสื้อแสงดาวบินออกจากโพรงไม้โบราณกลางบึงทักษิณ พร้อมกลิ่นหอมโอสถที่เพียงสูดดมก็ช่วยให้บาดแผลเรื้อรังทุเลาลงอย่างน่าอัศจรรย์',
      involvedSects: [],
      involvedFigures: ['หมอหลวง ไป๋เฉ่า (#13)']
    },
    {
      id: 'BALLAD_10_YAN_LUO_SHADOW_DECREE',
      macroRegion: 'EASTERN_PLAINS',
      titleTh: 'ข่าวลือสำนักตรวจการตงหวงออกตามล่าเศษแผ่นหยกดำ',
      storyTh: 'คนเดินม้าต่างโจษจันกันทั่วโต๊ะสุราว่า มือปราบชุดดำของเอี๊ยนหลัวกำลังตั้งด่านตรวจค้นขบวนสินค้าอย่างเข้มงวด เพื่อตามหาเศษแผ่นหยกดำที่มีอักษรโบราณจากยุคเทียนกู่',
      involvedSects: ['สำนักตรวจการตงหวง'],
      involvedFigures: ['เอี๊ยนหลัว (#54)', 'ซิงอวิ๋น (#49)']
    }
  ]);

  X.recordTavernBalladRumor = (W, idxOrId) => {
    if (!W || !W.world) return null;
    const pool = X.TAVERN_BALLAD_TEMPLATES;
    const tpl = (typeof idxOrId === 'string' && pool.find(b => b.id === idxOrId))
      || pool[Math.abs(Number(idxOrId) || ((W.day || 1) + (W.world.chronicleSeq || 0))) % pool.length];
    if (!tpl) return null;
    return X.recordChronicle(W, {
      eventKey: 'ballad:' + tpl.id + ':' + (W.day || 0),
      category: 'LEGEND',
      reportFormat: 'TAVERN_BALLAD',
      isRumor: true,
      unverified: true,
      icon: '🍶',
      titleTh: tpl.titleTh,
      storyTh: tpl.storyTh,
      originCauseTh: 'นักเดินทางและคนเดินม้าเล่าขานต่อกันมาในโรงเตี๊ยมริมทาง',
      consequenceTh: 'เรื่องนี้ยังเป็นเพียงคำร่ำลือในวงสุรา รอสายสืบสำนักพิสูจน์ความจริง',
      macroRegion: tpl.macroRegion,
      involvedSects: tpl.involvedSects,
      involvedFigures: tpl.involvedFigures,
      quiet: true
    });
  };
  if (g.MAP) g.MAP.WORLD_LORE = X.WORLD_LORE;
/* === LIVING_JIANGHU_EPITHETS_EXPED_HOOK_V260 === */

  const _origHydrateFigEp = X.hydrateFigureToNpc;
  X.hydrateFigureToNpc = (W, figOrId, opts) => {
    const srcFig = (typeof figOrId === 'object' && figOrId) ? figOrId : (W && W.world && W.world.figuresById && W.world.figuresById[figOrId]);
    const res = _origHydrateFigEp(W, figOrId, opts);
    if (res && res.ok && res.npc && g.CULT && g.CULT.EPITHETS) {
      g.CULT.EPITHETS.onHydrateExternalFigure(W, res.npc, srcFig || res.npc);
    }
    return res;
  };

  const _origBuildFactSnapEp = X.buildFactSnapshot;
  X.buildFactSnapshot = (W, entry, actorSnapshots, fmtId) => {
    const snap = _origBuildFactSnapEp(W, entry, actorSnapshots, fmtId);
    if (snap && Array.isArray(snap.actorsAtEvent)) {
      snap.actorsAtEvent.forEach((act, idx) => {
        if (!act) return;
        const srcA = (actorSnapshots && actorSnapshots[idx]) || (W && W.byId && W.byId[act.id]) || null;
        if (srcA) {
          const epSnap = srcA.epithetSnapshot || (srcA.epithets ? {
            primaryId: srcA.epithets.primaryId,
            primaryTextTh: srcA.epithets.primaryTextTh,
            campusTextTh: srcA.epithets.campusTextTh,
            daoNameTh: srcA.epithets.daoNameTh,
            groupTitleTh: srcA.epithets.groupTitleTh,
            crownIds: (srcA.epithets.crownIds || []).slice(),
            posthumousTitleTh: srcA.epithets.posthumousTitleTh
          } : null);
          act.epithetAtEventTh = (srcA.epithetAtEventTh) ||
            (epSnap && (epSnap.primaryTextTh || epSnap.daoNameTh || epSnap.campusTextTh)) ||
            null;
          act.epithetSnapshot = epSnap;
        }
      });
    }
    return snap;
  };

  if (typeof X.awakenAncientDaoLegacy === 'function') {
    const _origAwakenDaoEp = X.awakenAncientDaoLegacy;
    X.awakenAncientDaoLegacy = function(W, npcOrId, legacyId, opts) {
      const res = _origAwakenDaoEp.apply(this, arguments);
      const npc = typeof npcOrId === 'object' ? npcOrId : (W && W.byId && W.byId[npcOrId]);
      if (res && res.ok && npc && g.CULT && g.CULT.EPITHETS) {
        g.CULT.EPITHETS.recordDeed(W, npc, 'ancient_dao_legacy_awakened', 1, {
          receiptId: 'dao_leg_' + npc.id + '_' + (legacyId || 'legacy'),
          descTh: 'ปลุกมรดกมรรคาโบราณที่สาบสูญสำเร็จ'
        });
      }
      return res;
    };
  }

})(typeof globalThis !== 'undefined' ? globalThis : this);


/* ============================================================================
 * JS2-v3.1.0 — LIVING LORE, 4 EPISTEMIC LAYERS, FALLEN DYNASTIES ARCHIVE,
 * 28 MULTI-PERSPECTIVE CANON FACTS & 20 MULTI-STAGE PLAYABLE STORY CHAINS
 * ============================================================================ */
(function initLivingLoreExpeditionEngine(g) {
  'use strict';
  const X = g.EXPED, HC = g.HC, U = g.U, JD = g.JD;
  const getCOG = () => g.COG, getCULT = () => g.CULT, getECO = () => g.ECO, getSECT = () => g.SECT, getAI = () => g.AI;
  if (!X || !HC || !U) return;
  const E = (n, p) => HC.eff(n, p), clamp = U.clamp;

  const EPISTEMIC_LAYERS = Object.freeze({
    PROVINCIAL_VEIL: Object.freeze({
      id: 'PROVINCIAL_VEIL',
      order: 1,
      nameTh: 'ชั้นที่ 1 · ม่านหมอกชนบทและคำบอกเล่าพื้นบ้าน',
      shortTh: 'คำบอกเล่าพื้นบ้าน',
      secretGate: false,
      descTh: 'เรื่องเล่าปากเปล่าในโรงเตี๊ยม เพลงคนแจวเรือ คติความเชื่อของชาวบ้าน และจารีตท้องถิ่นใน 54 เมืองและด่าน ซึ่งมักเจืออภินิหารหรืออคติของแต่ละท้องที่'
    }),
    IMPERIAL_CHESSBOARD: Object.freeze({
      id: 'IMPERIAL_CHESSBOARD',
      order: 2,
      nameTh: 'ชั้นที่ 2 · กระดานหมากเก้าแคว้น ราชวงศ์ที่ล่มสลาย และศึกตัวแทน 19 สำนัก',
      shortTh: 'กระดานหมากเก้าแคว้น',
      secretGate: false,
      descTh: 'สนธิสัญญาหยุนเหอ 820 ปีของซูฉิน (#37) การคานอำนาจของ 3 มหาจักรวรรดิ 5 แคว้นกลาง สภาเจ็ดวาณิช และร่องรอยของราชวงศ์ที่เพิ่งล่มสลายซึ่งยังหลงเหลืออยู่ในระบบภาษีและสายตระกูล'
    }),
    SHATTERED_SUBCONTINENT: Object.freeze({
      id: 'SHATTERED_SUBCONTINENT',
      order: 3,
      nameTh: 'ชั้นที่ 3 · ความลับอนุทวีปแตกสลาย ม่านกั้นภพเทียนกู่ และของตกค้างจากเบื้องบน',
      shortTh: 'ความลับม่านกั้นภพ',
      secretGate: true,
      descTh: 'ความจริงเรื่องการระเบิดประตูมิติหลวงของกู่เสวียนหยวน (#1) กฎเพดานตบะขั้น 9 ที่ม่านฟ้ากดทับ สัจธรรมว่าของวิเศษโบราณหลายชิ้นเป็นเพียงของใช้สามัญจากโลกเบื้องบน และแผ่นดินห้าภูมิภาคเป็นเพียงหลุมอุกกาบาตที่ถูกล้อมด้วยทะเลหมอกไร้ขอบเขต'
    }),
    ERASED_PREHISTORY: Object.freeze({
      id: 'ERASED_PREHISTORY',
      order: 4,
      nameTh: 'ชั้นที่ 4 · ยุคบรรพกาลก่อนเทียนกู่และปฐมบทผู้ก่อตั้งสำนักที่ถูกปิดบัง',
      shortTh: 'ปฐมประวัติที่ถูกลบ',
      secretGate: true,
      descTh: 'ยุคบรรพกาลสามสมัยที่ถูกราชสำนักเทียนกู่ลบออกจากพงศาวดาร หอจดหมายเหตุสี่มหาแดนลับ และชาติกำเนิดที่แท้จริงของปรมาจารย์ผู้ก่อตั้งสำนักรุ่นที่ 1 (#45) ผู้ทิ้งตราหินเทาไร้ลักษณ์ไว้เพื่อหลบเลี่ยงสายตาสวรรค์'
    })
  });

  const FALLEN_DYNASTIES_ARCHIVE = Object.freeze({
    DYN_TIANGU: Object.freeze({
      id: 'DYN_TIANGU',
      nameTh: 'มหาจักรวรรดิโบราณเทียนกู่',
      eraTh: 'ยุคที่ 1–2 · ก่อนการระเบิดประตูมิติหลวง (~1,000 ปีก่อน)',
      successorPolityIds: ['POL_BEIMING', 'POL_DONGHUANG', 'POL_XIRONG', 'POL_YUNHE'],
      anchorNodeIds: ['CITY_YH_OLD_DAREN_SQUARE', 'PASS_YH_YUGUAN_RUIN_POST', 'CITY_BM_HANYU_CAPITAL'],
      remnantSignTh: 'เหรียญสำริดตราประตูสวรรค์ ศิลาจารึกอักษรหลวงยุคกู่เสวียนหยวน (#1) และฐานค่ายกลสิบสองคบเพลิง',
      courtAccountTh: 'ราชสำนักเป่ยหมิงอ้างสิทธิ์สายเลือดสกุลกู่โดยตรง ส่วนตงหวงบันทึกว่าเทียนกู่ล่มสลายเพราะความอหังการของกษัตริย์องค์สุดท้าย',
      folkAccountTh: 'ชาวบ้านเล่าขานว่านครหลวงเทียนกู่ถูกทวยเทพลงทัณฑ์จนจมลงใต้หุบเขาและกลายเป็นซากอุทยานสวรรค์'
    }),
    DYN_QINGLAN: Object.freeze({
      id: 'DYN_QINGLAN',
      nameTh: 'ราชวงศ์ชิงหลานโบราณ (แคว้นสายน้ำคราม)',
      eraTh: 'ยุคก่อนปัจจุบัน · เพิ่งล่มสลายเมื่อ ~90 ปีก่อนและถูกผนวกเข้าตงหวง',
      successorPolityIds: ['POL_DONGHUANG'],
      anchorNodeIds: ['CITY_DH_QINGLAN_DICE_CITY', 'PASS_DH_BAILANG_RIVER_LOCK'],
      remnantSignTh: 'ตราประทับครั่งทองเหลืองรูปคลื่นคู่ของด่านภาษีเก่า และตั๋วแลกเงินใต้ดินที่โรงจำนำเก่ายังรับแลก',
      courtAccountTh: 'พงศาวดารตงหวงระบุว่าเจ้าแคว้นชิงหลานบริหารคลังล้มเหลวจนต้องขอสวามิภักดิ์ต่อราชธานีเก้าคลังสุริยัน',
      folkAccountTh: 'คนแจวเรือและนายหน้าเก่ากระซิบว่าคลังเสบียงใต้น้ำของชิงหลานยังไม่เคยถูกเปิด และตราภาษีเก่ายังใช้เบิกของในห้องลับได้'
    }),
    DYN_ZHENYANG: Object.freeze({
      id: 'DYN_ZHENYANG',
      nameTh: 'แคว้นปราการเจิ้นหยาง',
      eraTh: 'ยุคก่อนปัจจุบัน · ล่มสลายในศึกพรมแดนตะวันออก–กลางเมื่อ ~110 ปีก่อน',
      successorPolityIds: ['POL_DONGHUANG', 'POL_YUNHE'],
      anchorNodeIds: ['CITY_DH_ZHENYANG_RUIN_PREF', 'TOWN_YH_WUYUN_POST'],
      remnantSignTh: 'ป้อมศิลาครึ่งซีกและหมุดเหล็กบอกแนวเขตแดนที่ตอกซ้อนกับหลักศิลาหยุนเหอ',
      courtAccountTh: 'ตงหวงถือว่าเจิ้นหยางเป็นมณฑลหน้าด่านที่ถูกกบฏเผาทำลาย จึงตั้งด่านเก็บภาษีซ่อมป้อมทับที่เดิม',
      folkAccountTh: 'ทายาททหารยามเจิ้นหยางเล่าว่าแม่ทัพคนสุดท้ายเปิดประตูระบายพลเรือนหนีเข้าหยุนเหอก่อนเผาคลังแสงตนเอง'
    }),
    DYN_CANGLAN: Object.freeze({
      id: 'DYN_CANGLAN',
      nameTh: 'แคว้นหมอกชางหลาน',
      eraTh: 'ยุคกลางเจ็ดธงศึก · ล่มสลายเมื่อ ~240 ปีก่อนในหุบเขาหมอกเหนือ',
      successorPolityIds: ['POL_YOUMING', 'POL_BEIMING'],
      anchorNodeIds: ['CITY_YM_HUNDENG_CAPITAL', 'TOWN_YM_SHIBEI_RUBBING', 'PASS_YM_WUKUI_MIST_GATE'],
      remnantSignTh: 'ป้ายหยกครึ่งซีกสลักนามสกุลผู้อพยพ และเทคนิคลอกลายศิลาจารึกด้วยหมึกควันสน',
      courtAccountTh: 'ถูกบันทึกสั้นๆ ว่าเป็นแคว้นเล็กที่สลายตัวไปเองจากภัยหนาวและหมอกพิษ',
      folkAccountTh: 'ตระกูลที่อพยพลงใต้ยังเก็บป้ายหยกครึ่งซีกไว้เทียบหาญาติพี่น้องที่พลัดพรากในคืนเผาบัญชีเกณฑ์ทหาร'
    }),
    DYN_YANLING: Object.freeze({
      id: 'DYN_YANLING',
      nameTh: 'ราชวงศ์เหยียนหลิง (แคว้นสองแควโบราณ)',
      eraTh: 'ยุคสิบสองแคว้นล่มสลาย · ~420 ปีก่อน ก่อนกำเนิดสภาเจ็ดวาณิชหยุนเหอ',
      successorPolityIds: ['POL_YUNHE'],
      anchorNodeIds: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE', 'TOWN_YH_CUIZHU_TEA'],
      remnantSignTh: 'ขีดวัดระดับน้ำท่วมโบราณใต้ตอม่อสะพานศิลาสามแคว และสมุดบัญชีส่วยข้าวฤดูแล้ง',
      courtAccountTh: 'สภาเจ็ดวาณิชหยุนเหอบันทึกว่าเหยียนหลิงล่มสลายเพราะเก็บภาษีน้ำขูดรีดพ่อค้า',
      folkAccountTh: 'ชาวประมงเชื่อว่ากษัตริย์เหยียนหลิงทำผิดคำสัตย์ต่อพญามังกรน้ำ ทำให้แม่น้ำสองแควไหลย้อนกลับทุกเจ็ดปี'
    }),
    DYN_DAXIA_SEVEN_BANNERS: Object.freeze({
      id: 'DYN_DAXIA_SEVEN_BANNERS',
      nameTh: 'พันธมิตรเจ็ดธงศึกต้าเซี่ย',
      eraTh: 'ยุคกลียุคหลังประตูมิติแตก · ~750 ปีก่อน',
      successorPolityIds: ['POL_BEIMING', 'POL_XIRONG'],
      anchorNodeIds: ['PASS_BM_HANLONG_GATE', 'TOWN_BM_BAIMEI_OLD_FORT', 'PASS_BM_XUEFENG_WEST'],
      remnantSignTh: 'หัวทวนสำริดหักและแผนที่หนังแกะที่วาดโค้งน้ำโบราณก่อนแผ่นดินทรุด',
      courtAccountTh: 'เป่ยหมิงบันทึกว่าเป็นกองทัพขุนศึกนอกรีตที่ถูกปฐมกษัตริย์สกุลกู่ปราบปรามจนราบคาบ',
      folkAccountTh: 'พรานแดนเหนือเล่าว่าเป็นกองทัพผู้รอดชีวิตที่ตั้งค่ายสกัดอสูร裂缝มิติจนตัวตายหมดทั้งเจ็ดกองธง'
    }),
    DYN_HUANGSHA_OASIS: Object.freeze({
      id: 'DYN_HUANGSHA_OASIS',
      nameTh: 'สมาพันธ์โอเอซิสทรายทองหวงซา',
      eraTh: 'ยุคก่อนการรวมแผ่นดินซีหรง · ~310 ปีก่อน',
      successorPolityIds: ['POL_XIRONG', 'POL_CHIYAN'],
      anchorNodeIds: ['CITY_XR_SHAYU_OASIS', 'PASS_XR_HUANGSHA_FORT', 'TOWN_XR_XINYUE_WELL'],
      remnantSignTh: 'ช่องส่งน้ำใต้ดินโบราณ (Karez) และแท่นฝนหมึกหินทรายแดงสลักตราพยัคฆ์ครึ่งซีก',
      courtAccountTh: 'จักรวรรดิซีหรงบันทึกว่าชนเผ่าโอเอซิสยอมมอบบ่อน้ำทั้งเก้าแลกกับการคุ้มครองจากกองทัพทัวป๋า',
      folkAccountTh: 'คนนำทางทะเลทรายรู้ดีว่ายังมีท่อส่งน้ำใต้ดินและจุดพักคาราวานลับที่ไม่อยู่ในแผนที่ทหารซีหรง'
    }),
    DYN_NANZHU_LEAGUE: Object.freeze({
      id: 'DYN_NANZHU_LEAGUE',
      nameTh: 'สันนิบาตเดินเรือสมุทรทักษิณ',
      eraTh: 'ยุคสำรวจทะเลหมอก · ~180 ปีก่อน',
      successorPolityIds: ['POL_DONGHUANG', 'POL_GUJIAO'],
      anchorNodeIds: ['CITY_SO_NANZHU_PEARL_ISLE', 'CITY_SO_LONGWAN_SHIPYARD', 'PASS_SO_DENGTAI_LIGHTHOUSE'],
      remnantSignTh: 'สมุดปมเชือกหยั่งร่องน้ำสามตะเกียง และแผ่นไม้สักสลักชื่อเรือที่สูญหายในม่านหมอก',
      courtAccountTh: 'ตงหวงสั่งยุบสันนิบาตเดินเรือโดยอ้างว่าลักลอบค้าเกลือเถื่อนและสมคบโจรสลัดโขดหินดำ',
      folkAccountTh: 'ชาวเรือเกาะไข่มุกเล่าว่ากองเรือใหญ่แล่นเลยแนวประภาคารออกไปพบกำแพงหมอกไร้ก้นบึ้งก่อนจะเหลือเรือรอดกลับมาเพียงลำเดียว'
    })
  });

  const CANON_FACTS = Object.freeze([
    {
      id: 'FACT_01_SHUANGJIANG_BACKFLOW',
      storyId: 'STORY_01_SHUANGJIANG_FLOOD_LEDGER',
      titleTh: 'ปรากฏการณ์น้ำไหลย้อนและสมุดระดับน้ำซวงเจียง',
      layer: 'PROVINCIAL_VEIL',
      category: 'GEOGRAPHY',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE'],
      relatedPaths: ['TIDE_VOYAGER', 'STRATEGY_GOVERNANCE', 'MERCANTILE_DAO'],
      relatedFigures: [37, 53],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'ROUTE_SAFETY', legNodes: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE'], travelBonus: 0.14, descTh: 'ลดความล่าช้าและความเสี่ยงขบวนเรือข้ามสองแควหยุนเหอ–ด่านสะพานศิลาสามแคว' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ตำนานพญานาคราชทวงส่วยสองแคว',
          credibilityBase: 48,
          biasTh: 'เรื่องเล่าคนแจวเรือและโรงสุราท่าเทียบเรือซวงเจียง',
          summaryTh: 'ชาวเรือร่ำลือว่าทุกปลายฤดูใบไม้ร่วงปีที่เจ็ด พญามังกรใต้น้ำจะพลิกตัวทวงส่วยกษัตริย์เหยียนหลิง ทำให้กระแสน้ำสองแควไหลย้อนกลับและกลืนเรือสินค้าที่บรรทุกหนัก'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ประกาศเตือนภัยร่องน้ำสภาเจ็ดวาณิช',
          credibilityBase: 62,
          biasTh: 'ประกาศทางการของนายท่าเรือหยุนเหอเพื่อเก็บค่าธรรมเนียมนำร่อง',
          summaryTh: 'สภาเจ็ดวาณิชระบุว่ากระแสน้ำปั่นป่วนเกิดจากเรือต่างแคว้นทอดสมอขวางร่องน้ำ จึงต้องเรียกเก็บค่านำร่องพิเศษในช่วงน้ำหลาก'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บันทึกปราณวารีปะทะชีพจรปฐพี',
          credibilityBase: 65,
          biasTh: 'สมมติฐานของผู้ฝึกตนสายวารีและค่ายกล',
          summaryTh: 'ผู้ฝึกตนเชื่อว่าใต้จุดบรรจบแม่น้ำมีรอยรั่วของชีพจรปฐพีที่ดันมวลน้ำให้ตีกลับเป็นพักๆ เมื่อปราณหยินสะสมตัว'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'หลักฐานขีดวัดระดับน้ำแล้งและสมุดส่วยข้าวราชวงศ์เหยียนหลิง',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากการเทียบขีดหินใต้ตอม่อสะพานศิลาสามแควกับสมุดคลังข้าวโบราณ',
          summaryTh: 'รอยสิ่ววัดระดับน้ำใต้ตอม่อสะพานศิลาสามแควและสมุดส่วยข้าวโบราณพิสูจน์ว่า เมื่อปีใดหิมะแดนเหนือละลายช้าประจวบกับฝนหลงฤดูฝั่งตะวันออก สันดอนทรายใต้น้ำจะหนุนให้น้ำตีกลับเป็นเวลา 9 วัน สามารถคำนวณล่วงหน้าและปรับเส้นทางคาราวานหลบได้อย่างแม่นยำ'
        }
      }
    },
    {
      id: 'FACT_02_BAILU_DUAL_COMMENTARY',
      storyId: 'STORY_02_BAILU_DUAL_ANNOTATED_MANUAL',
      titleTh: 'อรรถาธิบายสองลายมือในคัมภีร์สำนักศึกษาไป๋ลู่',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'MARTIAL_SCHISM',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_BAILU_ACADEMY', 'CITY_YH_OLD_DAREN_SQUARE'],
      relatedPaths: ['XIAN', 'HEART_SOUL', 'SAGE_SUPPORT', 'LORE_ARCHIVIST'],
      relatedFigures: [21, 37],
      secretGate: false,
      defaultAccount: 'SECT_ORTHODOX',
      gameplayEffect: { kind: 'STUDY_SYNTHESIS', studySpeedBonus: 0.12, descTh: 'เพิ่มความเร็วและความปลอดภัยในการตีความคัมภีร์ด้วยอรรถาธิบายประสานสองสำนักคิด' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือคัมภีร์ต้องสาปของศิษย์ทรยศ',
          credibilityBase: 45,
          biasTh: 'คำเล่าลือในหมู่บัณฑิตฝึกหัดเมืองไป๋ลู่',
          summaryTh: 'ร่ำลือกันว่าผู้เขียนหมึกสีชาดในขอบคัมภีร์คือศิษย์เอกที่ธาตุไฟเข้าแทรกและจงใจเขียนเคล็ดวิชาลวงไว้สังหารผู้เรียนรุ่นหลัง'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ทะเบียนตำราต้องห้ามของหอตรวจการการศึกษา',
          credibilityBase: 60,
          biasTh: 'มุมมองขุนนางผู้ควบคุมสำนักศึกษา',
          summaryTh: 'หอทะเบียนตำราจัดให้ฉบับที่มีรอยแก้หมึกแดงเป็นฉบับคัดลอกผิดพลาดที่ควรเก็บเข้ากรุเพื่อรักษามาตรฐานการสอบ'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ข้อพิพาทสายเร่งรัดหมึกชาดกับสายมั่นคงหมึกดำ',
          credibilityBase: 68,
          biasTh: 'ความขัดแย้งระหว่างอาจารย์สายรุกและสายตั้งรับ',
          summaryTh: 'หมึกดำเน้นเดินปราณช้าแต่ปลอดภัย ส่วนหมึกชาดแนะให้บีบอัดปราณผ่านจุดชีพจรลัดซึ่งรุนแรงกว่าแต่เสี่ยงบาดเจ็บภายใน'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'บันทึกโต้ตอบของสองปรมาจารย์ร่วมสาบานแห่งไป๋ลู่',
          credibilityBase: 93,
          biasTh: 'พิสูจน์จากการเทียบลายมือต้นฉบับในหอสมุดไป๋ลู่และตราประทับคู่',
          summaryTh: 'ทั้งสองลายมือเขียนโดยปรมาจารย์คู่ร่วมสาบานคนเดียวกันในช่วงวัยหนุ่ม (หมึกชาด) และวัยชรา (หมึกดำ) เพื่อชี้แนะว่าผู้มีกายาแข็งแกร่งใช้ทางลัดหมึกชาดได้เมื่อมีหมึกดำคอยคุมจังหวะผ่อนลมหายใจ'
        }
      }
    },
    {
      id: 'FACT_03_QINGLAN_DOUBLE_TOLL_SEAL',
      storyId: 'STORY_03_QINGLAN_SECOND_TOLL_STAMP',
      titleTh: 'ตราประทับด่านภาษีซ้อนแห่งราชวงศ์ชิงหลาน',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'DYNASTY',
      polityId: 'POL_DONGHUANG',
      anchorNodeIds: ['CITY_DH_QINGLAN_DICE_CITY', 'CITY_DH_ZHENYANG_RUIN_PREF'],
      relatedPaths: ['MERCANTILE_DAO', 'FORTUNE_GAMBLER', 'STRATEGY_GOVERNANCE'],
      relatedFigures: [52, 53, 54],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'TRADE_TRUST_AND_CACHE', tradeBonus: 0.10, descTh: 'เข้าใจธรรมเนียมตั๋วแลกเงินเก่าชิงหลานและระเบียบศุลกากรตงหวง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือภาษีผีราชวงศ์ชิงหลาน',
          credibilityBase: 46,
          biasTh: 'เรื่องเล่าของคนคุมเกวียนและนักพนันเมืองชิงหลาน',
          summaryTh: 'พ่อค้าร่ำลือว่าหีบสินค้าใดที่มีตราคลื่นคู่ของราชวงศ์ชิงหลานที่ล่มสลายไปเมื่อเก้าสิบปีก่อนประทับซ้อนอยู่ จะถูกผีขุนนางเก่าตามทวงส่วยกลางทาง'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'หมายปราบปรามตราปลอมของสำนักตรวจการตงหวง',
          credibilityBase: 64,
          biasTh: 'ประกาศของมือปราบเอี๊ยนหลัว (#54)',
          summaryTh: 'สำนักตรวจการตงหวงประกาศว่าตราคลื่นคู่เป็นตราเถื่อนของกบฏหลงยุค ผู้ครอบครองหีบสินค้าต้องถูกยึดของกลางและสอบสวน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'รหัสลับเครือข่ายนายหน้าหอการค้าหมื่นสมุทร',
          credibilityBase: 67,
          biasTh: 'บันทึกของนายวาณิชย์สายการค้า',
          summaryTh: 'นายหน้าอาวุโสทราบว่าตระกูลคหบดีเก่าในเมืองชิงหลานและเจิ้นหยางยังใช้ตราครั่งทองเหลืองดั้งเดิมเป็นตั๋วรับประกันสินค้าระหว่างห้องใต้ดินเก่า'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'สมุดเทียบตราภาษีเปลี่ยนผ่านชิงหลาน–ตงหวง',
          credibilityBase: 92,
          biasTh: 'พิสูจน์จากการสอบทานสมุดบัญชีด่านเจิ้นหยางเก่ากับนายหน้าเมืองชิงหลาน',
          summaryTh: 'เมื่อตงหวงผนวกแคว้นชิงหลาน ว่านจินเหนียง (#53) ได้อนุญาตให้นายหน้าคลังเก่าประทับตราคลื่นคู่กำกับใต้ตราลูกคิดทองคำเพื่อรับรองสิทธิเบิกพัสดุคงค้างจากคลังใต้ดินโดยไม่ผิดกฎหมายศุลกากร'
        }
      }
    },
    {
      id: 'FACT_04_YUGUAN_REFUGEE_BOUNDARY',
      storyId: 'STORY_04_YUGUAN_TWO_VILLAGE_BOUNDARY',
      titleTh: 'หลักศิลาสองชื่อแห่งด่านหยกเก่าอวี้กวาน',
      layer: 'PROVINCIAL_VEIL',
      category: 'GEOGRAPHY',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['PASS_YH_YUGUAN_RUIN_POST', 'TOWN_YH_LIUWAN_FERRY'],
      relatedPaths: ['WANDERING_DAO', 'STRATEGY_GOVERNANCE', 'ARCHITECT_FORTIFIER'],
      relatedFigures: [38],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'SETTLEMENT_HARMONY', anchorNodeIds: ['PASS_YH_YUGUAN_RUIN_POST'], safetyBonus: 6, descTh: 'ประสานรอยร้าวสองหมู่บ้านรอบด่านหยกเก่าอวี้กวาน เพิ่มความปลอดภัยเส้นทาง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข้อพิพาทสันเขาแย่งน้ำสองตระกูล',
          credibilityBase: 50,
          biasTh: 'คำอ้างของชาวบ้านสองฝั่งสันเขาอวี้กวาน',
          summaryTh: 'หมู่บ้านฝั่งเหนือเรียกสันเขานี้ว่าเนินพักพลองเขียว ส่วนหมู่บ้านฝั่งใต้เรียกว่าผาแบ่งข้าว ต่างฝ่ายต่างอ้างว่าบรรพชนตนเป็นผู้ตั้งหลักศิลาก่อน'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'แผนที่รังวัดที่ดินของด่านภาษีอวี้กวาน',
          credibilityBase: 61,
          biasTh: 'บันทึกของเสมียนด่านเพื่อเก็บส่วยทั้งสองหมู่บ้าน',
          summaryTh: 'เสมียนด่านอ้างว่าหลักศิลาเดิมลบเลือนไปแล้ว พื้นที่ทั้งสองฝั่งจึงถือเป็นที่หลวงซึ่งต้องจ่ายค่าธรรมเนียมผ่านทางเพิ่ม'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บันทึกเส้นทางอพยพของราชันย์พเนจรหงชี (#38)',
          credibilityBase: 68,
          biasTh: 'ตำนานสายจอมยุทธ์พเนจร',
          summaryTh: 'เล่าขานว่าหงชี (#38) ใช้พลองหยกเขียวปักแบ่งเขตให้ขบวนผู้ลี้ภัยสองกลุ่มพักแรมคนละฟากเขาเพื่อไม่ให้แย่งฟืนและน้ำกัน'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'รอยสลักสองด้านบนฐานศิลาบอกทางม้าเร็วโบราณ',
          credibilityBase: 93,
          biasTh: 'พิสูจน์จากการขุดแต่งฐานหลักศิลาและเทียบสมุดสายตระกูลทั้งสองหมู่บ้าน',
          summaryTh: 'ฐานศิลาที่จมอยู่ใต้ดินครึ่งศอกสลักชื่อทั้งสองไว้คนละด้านโดยหงชี (#38) เพื่อให้สองตระกูลผลัดกันดูแลบ่อน้ำและคบเพลิงนำทางแก่คนเดินทางไกล'
        }
      }
    },
    {
      id: 'FACT_05_FORD_BEAST_MOLTING_CYCLE',
      storyId: 'STORY_05_BEAST_KEEPER_FORD_NOTEBOOK',
      titleTh: 'สมุดบันทึกคนเลี้ยงอสูรและวงจรลอกคราบริมแก่งน้ำตื้น',
      layer: 'PROVINCIAL_VEIL',
      category: 'ECOLOGY',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['TOWN_BM_BINGHE_FUR_POST', 'TOWN_GJ_YaoZhai_HUNT'],
      relatedPaths: ['BEAST_SOVEREIGN', 'SPIRIT_HUSBANDRY', 'PRIMORDIAL_SHIFTER'],
      relatedFigures: [31, 40],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'BEAST_ECOLOGY_INSIGHT', companionAffinityBonus: 0.12, descTh: 'เข้าใจวงจรลอกคราบและวางรังของสัตว์อสูรริมน้ำ ลดการปะทะโดยไม่จำเป็นและเก็บคราบสมุนไพรได้' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลืออสูรคลั่งอาละวาดปิดแก่งน้ำ',
          credibilityBase: 47,
          biasTh: 'ความตื่นตระหนกของพ่อค้าขนสัตว์และชาวบ้าน',
          summaryTh: 'ร่ำลือว่ามีอสูรกลายพันธุ์ดุร้ายดักซุ่มทำร้ายขบวนเดินทางตรงแก่งน้ำตื้น ต้องระดมมือปราบไปกวาดล้างให้สิ้นซาก'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ประกาศตั้งค่าหัวอสูรรบกวนเส้นทางเสบียง',
          credibilityBase: 60,
          biasTh: 'คำสั่งด่านทหารชายแดน',
          summaryTh: 'ด่านหน้าออกประกาศปิดแก่งน้ำชั่วคราวและตั้งรางวัลนำจับเขี้ยวอสูรเพื่อเปิดทางส่งเสบียงทหาร'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ตำราเก็บเกี่ยววัตถุดิบอสูรช่วงผลัดเกล็ด',
          credibilityBase: 66,
          biasTh: 'มุมมองของนักปรุงยาและผู้ล่าอสูร',
          summaryTh: 'ระบุว่าช่วงที่สัตว์อสูรริมน้ำรวมฝูงคือจังหวะที่เกล็ดอ่อนแอที่สุด เหมาะแก่การชิงเก็บแก่นอสูรและคราบเกล็ด'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'สมุดบันทึกสนามของคนเลี้ยงอสูรเฒ่า',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากการตรวจสมุดบันทึกหนังสัตว์และร่องรอยรังริมตลิ่ง',
          summaryTh: 'สัตว์อสูรเพียงขึ้นมาถูหินลอกคราบและเฝ้าไข่ริมแก่งน้ำตื้นเพียง 6 วันต่อฤดู หากเลี่ยงทางเดินริมตลิ่งหรือวางเกลือแร่ล่อไว้ห่างแก่ง จะสามารถเก็บคราบเกล็ดสมบูรณ์ได้โดยไม่เกิดการนองเลือด'
        }
      }
    },
    {
      id: 'FACT_06_STOREROOM_ANVIL_TALISMAN',
      storyId: 'STORY_06_STOREROOM_FLOORBOARD_SHRINE',
      titleTh: 'หิ้งบูชาช่างหลอมและตราเหล็กใต้พื้นห้องเก็บของเก่า',
      layer: 'PROVINCIAL_VEIL',
      category: 'CRAFT_LABOR',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['TOWN_YH_TIEKUANG_HOLLOW', 'CITY_CY_RONGLU_CAPITAL'],
      relatedPaths: ['CRAFT_CREATION', 'RECLAMATION_DAO', 'ARCHITECT_FORTIFIER'],
      relatedFigures: [14],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'GEAR_REPAIR_WARD', craftBonus: 0.10, descTh: 'ฟื้นฟูตำรับชุบขี้เถ้าถนอมเกราะและซ่อมบำรุงอุปกรณ์ป้องกันจากวัสดุสามัญ' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือยันต์อาถรรพ์ใต้พื้นไม้ห้องเก็บของ',
          credibilityBase: 44,
          biasTh: 'ความหวาดระแวงของศิษย์เวรทำความสะอาด',
          summaryTh: 'ศิษย์รับใช้ที่ไปรื้อแผ่นไม้ผุในห้องเก็บของเก่าพบทั่งเหล็กจิ๋วเปื้อนเขม่าและแผ่นไม้สลักชื่อแปลกๆ จึงลือกันว่าเป็นของทำคุณไสยที่คนรุ่นก่อนซ่อนไว้'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บัญชีพัสดุชำรุดรอหลอมทิ้ง',
          credibilityBase: 58,
          biasTh: 'มุมมองเสมียนคลังที่เน้นความเป็นระเบียบ',
          summaryTh: 'จัดให้เศษเหล็กและแผ่นไม้ใต้พื้นเป็นเพียงขยะจากการซ่อมอาคารรุ่นเก่าที่ควรนำไปหลอมรวมเป็นเหล็กแท่งธรรมดา'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ธรรมเนียมฝากคมทั่งของช่างฝึกหัดสายโอวหยางเหยียน (#14)',
          credibilityBase: 70,
          biasTh: 'จารีตโรงหลอมโบราณ',
          summaryTh: 'ช่างตีเหล็กยุคก่อนนิยมซ่อนทั่งจำลองและสูตรผสมขี้เถ้าชุบเกราะไว้ใต้พื้นโรงงาน เพื่อเป็นเครื่องรางคุ้มกันไฟเตาหลอมตีกลับ'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ตำรับชุบเกราะเหล็กผสมขี้เถ้าไม้สนของช่างรุ่นที่สี่',
          credibilityBase: 93,
          biasTh: 'พิสูจน์จากการถอดรหัสตราช่างบนทั่งจิ๋วและทดลองชุบแผ่นเกราะจริง',
          summaryTh: 'เป็นหิ้งรำลึกถึงหัวหน้าช่างหลอมสมัยเจ้าสำนักรุ่นที่ 4 ที่คิดค้นวิธีใช้ขี้เถ้าสมุนไพรและแร่เหล็กสามัญชุบผิวชุดเกราะให้ทนแรงกระแทกและซ่อมแซมง่ายในยามสำนักขาดแคลนศิลาวิญญาณ'
        }
      }
    },
    {
      id: 'FACT_07_GEN7_WOODEN_SWORD_AND_EMPTY_CHAIR',
      storyId: 'STORY_07_SEVENTH_GEN_EMPTY_CHAIR',
      titleTh: 'ปริศนาเก้าอี้ว่างและกระบี่ไม้ท้อข้างแท่นตราหินเทาไร้ลักษณ์',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'SECT_LINEAGE',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_OLD_DAREN_SQUARE', 'TOWN_YH_QINGXI_FOOT'],
      relatedPaths: ['XIAN', 'SWORD_DOMAIN', 'ANCESTRAL_RITUAL'],
      relatedFigures: [45],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'LINEAGE_COHESION', regaliaInsightBonus: 1, descTh: 'ประสานความเข้าใจมรดกเจ้าสำนักรุ่นที่ 7 ระหว่างกระบี่ไม้ท้อฝึกหัดกับตราหินเทาไร้ลักษณ์' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือกระบี่ไม้ท้อคือศาสตราเซียนที่ถูกสับเปลี่ยน',
          credibilityBase: 46,
          biasTh: 'คำซุบซิบของศิษย์ใหม่และชาวยุทธ์นอกสำนัก (อิงร่าง LORE_05 เดิม)',
          summaryTh: 'คนภายนอกร่ำลือว่าสมบัติประจำตำแหน่งเจ้าสำนักรุ่นที่ 7 คือกระบี่ไม้ท้อไร้คมที่แขวนอยู่ข้างเก้าอี้ว่างในโถงบรรพชน และสงสัยว่าเหตุใดเจ้าสำนักปัจจุบันจึงถือครองตราหินเทาไร้ลักษณ์แทน'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บันทึกสำรวจสำนักยุทธ์ของหอทะเบียนหยุนเหอ',
          credibilityBase: 59,
          biasTh: 'รายงานของเสมียนแคว้นหยุนเหอ',
          summaryTh: 'ระบุว่าสำนักเคยเกิดศึกชิงตำแหน่งในรุ่นที่ 6 จนศิษย์พี่ใหญ่หนีออกจากสำนักไปพร้อมเก้าอี้ประจำตำแหน่งที่ถูกปล่อยว่างไว้'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ธรรมเนียมคารวะผู้พิทักษ์ด่านและศาสตราไร้รูป',
          credibilityBase: 72,
          biasTh: 'คำสอนของผู้อาวุโสหอคัมภีร์',
          summaryTh: 'ยืนยันว่าตราประจำตำแหน่งที่แท้จริงตั้งแต่รุ่นที่ 1 คือ「ตราหินเทาไร้ลักษณ์」(REGALIA_ORIGIN_FORMLESS_STONE) ส่วนกระบี่ไม้ท้อและเก้าอี้ว่างเป็นอนุสรณ์ภายในของรุ่นที่ 6'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'บันทึกสั่งเสียของเจ้าสำนักรุ่นที่ 6 โม่ชางไห่',
          credibilityBase: 96,
          biasTh: 'พิสูจน์จากการเทียบจารึกป้ายบรรพชนรุ่นที่ 5–6 กับสมุดรายนามผู้สละชีพหน้าด่าน',
          summaryTh: 'ตราประจำตำแหน่งที่แท้จริงคือ「ตราหินเทาไร้ลักษณ์」ซึ่งจำแลงได้ 24 รูปลักษณ์ ส่วนกระบี่ไม้ท้อเป็นเพียงไม้ฝึกซ้อมวัยเยาว์ที่เจ้าสำนักรุ่นที่ 6 โม่ชางไห่ แขวนไว้คู่กับเก้าอี้ว่างของศิษย์พี่ร่วมสาบานผู้สละชีพต้านศึกหน้าหุบเขา เพื่อให้เจ้าสำนักรุ่นที่ 7 จดจำทั้งอำนาจแห่งตราหินและคุณธรรมแห่งผู้เสียสละ'
        }
      }
    },
    {
      id: 'FACT_08_TIANGU_MISSING_RIVER_BEND',
      storyId: 'STORY_08_MISSING_BEND_TRAIL_SKETCH',
      titleTh: 'ภาพร่างแผนที่รอยพับขาดของสมรภูมิกำแพงหลวงเทียนกู่',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'GEOGRAPHY',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['PASS_BM_HANLONG_GATE', 'CITY_BM_XINGYUN_CITADEL', 'TOWN_BM_BAIMEI_OLD_FORT'],
      relatedPaths: ['SWORD_DOMAIN', 'STAR_FATE', 'WANDERING_DAO'],
      relatedFigures: [6, 8, 16],
      secretGate: true,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'RUIN_TRAIL_PRECISION', expedSafetyBonus: 0.12, descTh: 'กำหนดพิกัดร่องรอยสมรภูมิเทียนกู่แม่นยำขึ้นและรับมือกรณีมีผู้สำรวจไปถึงก่อนได้อย่างสมบูรณ์' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'แผนที่ขุมทรัพย์รอยพับขาดจากโรงเตี๊ยมแดนเหนือ',
          credibilityBase: 45,
          biasTh: 'คำโฆษณาของนักขายแผนที่โบราณ',
          summaryTh: 'อ้างว่าหลังรอยพับที่ขาดหายไปของแผนที่หนังแกะคือคลังอาวุธลับของหลี่เจี้ยนซิน (#6) และเย่ชิงชาง (#8) ที่ยังไม่เคยมีผู้ใดค้นพบ'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'เขตหวงห้ามทางทหารของด่านประตูมังกรน้ำแข็ง',
          credibilityBase: 62,
          biasTh: 'คำสั่งกองทัพเป่ยหมิง',
          summaryTh: 'กองทัพเป่ยหมิงประกาศว่าแนวสันเขาหลังด่านหานหลงเป็นเพียงหน้าผาน้ำแข็งถล่มที่ไม่มีเส้นทางเดินทัพหรือโบราณสถานใดๆ'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บันทึกการเปลี่ยนร่องน้ำหลังแรงระเบิดประตูมิติหลวง',
          credibilityBase: 70,
          biasTh: 'แผนที่ดาราพยากรณ์ของสายซิงเฉินจื่อ (#16)',
          summaryTh: 'ชี้ว่าคุ้งน้ำในภาพร่างไม่ได้วาดผิด แต่แม่น้ำโบราณเปลี่ยนทิศทางไปสามสิบลี้หลังจากแผ่นดินทรุดตัวในวันระเบิดประตูมิติหลวง'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'พิกัดจริงของเนินธนูหักและหลักศิลาองครักษ์เทียนกู่',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการคำนวณมุมดาวซิงหยวนเทียบกับร่องน้ำแห้งหลังเมืองเก่ากระบี่เหมยขาว',
          summaryTh: 'รอยพับที่หายไปคือร่องน้ำแห้งที่เชื่อมระหว่างด่านหานหลงกับเมืองเก่าไป๋เหมย แม้สมบัติเอกอาจถูกผู้มีวาสนาหรือสำนักอื่นอัญเชิญไปแล้ว แต่หลักศิลาบันทึกกลยุทธ์ตั้งรับ 7 วัน 7 คืนของหลี่เจี้ยนซิน (#6) ยังคงสลักอยู่บนผนังผาให้ผู้มาเยือนศึกษามรรคายุทธ์ได้เสมอ'
        }
      }
    },
    {
      id: 'FACT_09_HAIMEN_NANZHU_SALT_CURRENT',
      storyId: 'STORY_09_ONE_SALT_LINE_TWO_PORTS',
      titleTh: 'สายเกลือหนึ่งเส้นและร่องน้ำมรสุมระหว่างสองท่าเรือ',
      layer: 'PROVINCIAL_VEIL',
      category: 'GEOGRAPHY',
      polityId: 'POL_DONGHUANG',
      anchorNodeIds: ['CITY_DH_HAIMEN_PORT', 'CITY_SO_NANZHU_PEARL_ISLE', 'CITY_SO_LONGWAN_SHIPYARD'],
      relatedPaths: ['TIDE_VOYAGER', 'MERCANTILE_DAO', 'CRAFT_CREATION'],
      relatedFigures: [53],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'SALT_PROVISION_BUFFER', provisionBonus: 0.12, descTh: 'สำรองเกลือและเสบียงก่อนฤดูมรสุมและเพิ่มความราบรื่นของเส้นทางเรือไห่เหมิน–หนานจู' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข้อกล่าวหากักตุนเกลือระหว่างไห่เหมินกับเกาะหนานจู',
          credibilityBase: 49,
          biasTh: 'ความบาดหมางของกรรมกรท่าเรือทั้งสองฝั่ง',
          summaryTh: 'ชาวท่าเรือไห่เหมินโทษว่าชาวเกาะไข่มุกหนานจูแอบกักตุนเกลือทะเลไว้โก่งราคาหน้ามรสุม ส่วนชาวเกาะหนานจูโทษว่ากองเรือตงหวงสั่งกักเรือเสบียง'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ระเบียบควบคุมโควตาเกลือหลวงตงหวง',
          credibilityBase: 63,
          biasTh: 'ประกาศขุนนางคลังท่าเรือไห่เหมิน',
          summaryTh: 'อ้างว่าภาวะเกลือขาดแคลนเกิดจากการลักลอบเดินเรือหนีภาษี จึงต้องเพิ่มด่านตรวจเรือประมงอิสระแถบอ่าวหลงวาน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บันทึกกระแสน้ำอุ่นปะทะลมมรสุมทักษิณ',
          credibilityBase: 68,
          biasTh: 'ปูมเดินเรือของสายนาวิกสมุทร',
          summaryTh: 'สังเกตว่าทุกสามปีจะมีกระแสน้ำวนพัดทรายมาปิดร่องน้ำตื้นหน้าอ่าวไห่เหมิน ทำให้เรือบรรทุกเกลือท้องแบนแล่นผ่านไม่ได้'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ตารางน้ำขึ้นน้ำลงและปูมเรือเกลืออู่ต่อเรือหลงวาน',
          credibilityBase: 93,
          biasTh: 'พิสูจน์จากการเทียบสมุดปูมเรือทั้งสองท่ากับระดับสันดอนปากอ่าว',
          summaryTh: 'ความตึงเครียดเกิดจากร่องน้ำตื้นปากอ่าวไห่เหมินตื้นเขินในช่วงลมมรสุมเปลี่ยนทิศ 12 วัน หากเปลี่ยนไปขนถ่ายผ่านท่าอู่ต่อเรือหลงวานและสำรองเกลือถนอมอาหารล่วงหน้า ทั้งสองท่าเรือจะค้าขายได้ต่อเนื่องโดยไม่ขาดแคลน'
        }
      }
    },
    {
      id: 'FACT_10_ROADSIDE_PHYSICIAN_STELE',
      storyId: 'STORY_10_DAMAGED_MEMORIAL_RESTORED_NAME',
      titleTh: 'นามที่เลือนหายบนศิลาอนุสรณ์ริมทางสุวรรณโพธิ์',
      layer: 'PROVINCIAL_VEIL',
      category: 'FOLK_CUSTOM',
      polityId: 'POL_SUVARNABODHI',
      anchorNodeIds: ['TOWN_SB_CIHANG_ALMS', 'CITY_SB_JINYA_SANGHA', 'TOWN_GJ_BAICAO_STILT'],
      relatedPaths: ['SAGE_SUPPORT', 'BUDDHA_DHARMA', 'PESTILENCE_REMEDY'],
      relatedFigures: [13],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'MEDICAL_MEMORIAL_BLESSING', healingBonus: 0.12, descTh: 'สืบทอดตำรับต้มยาสมุนไพรบรรเทาไข้ป่าและเชิดชูเกียรติหมอยาสามัญชน' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ศาลเซียนกระบี่นิรนามผู้ฟันภูผาเปิดทาง',
          credibilityBase: 48,
          biasTh: 'คำร่ำลือของนักเดินทางที่แวะจุดธูปริมทาง',
          summaryTh: 'ชาวบ้านเข้าใจว่ารอยบากบนศิลาอนุสรณ์ที่แตกหักคือรอยกระบี่ของจอมยุทธ์โบราณ จึงนิยมนำสุราและอาวุธมาเซ่นไหว้ขอพรให้ชนะศึก'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'หลักเขตแดนเก่าของสังฆารามสุวรรณโพธิ์',
          credibilityBase: 58,
          biasTh: 'บัญชีสำรวจสิ่งปลูกสร้างริมทางหลวง',
          summaryTh: 'บันทึกไว้สั้นๆ ว่าเป็นเพียงหลักหินบอกระยะทางที่ชำรุดจากยุคสงครามแคว้นกลาง'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ร่องรอยอักขระสายหมอหลวงไป๋เฉ่า (#13)',
          credibilityBase: 69,
          biasTh: 'ข้อสังเกตของหมอยาที่อ่านพบชื่อสมุนไพรท้ายแผ่นหิน',
          summaryTh: 'บรรทัดล่างสุดของศิลาที่จมอยู่ในโคลนมีอักษรย่อของสัดส่วนต้มยาแก้ไข้หมอกพิษ ไม่ใช่เคล็ดวิชากระบี่'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ทะเบียนโรงทานฉือหางและอนุสรณ์หมอยาเดินเท้า「เว่ยชิง」',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการลอกคราบตะไคร่บนศิลาเทียบกับสมุดมรณบัตรโรงทานฉือหาง',
          summaryTh: 'รอยบากบนหินไม่ใช่รอยกระบี่ แต่เป็นร่องวางคานหาบหม้อยาของหมอยาสามัญชนนาม「เว่ยชิง」และคนส่งสารที่แบกหม้อยาสมุนไพรฝ่าพายุฝนไปช่วยชาวบ้านสามหมู่บ้านจนสิ้นใจ การคืนนามที่แท้จริงให้ศิลาช่วยฟื้นฟูตำรับยาต้มป้องกันไข้หมอกให้หอโอสถ'
        }
      }
    },
    {
      id: 'FACT_11_FERRY_TRAVELER_TWICE_PAID_MEAL',
      storyId: 'STORY_11_MEAL_PAID_TWICE',
      titleTh: 'ธรรมเนียมฝากค่าข้าวคนเดินทางและมื้ออาหารที่ถูกจ่ายซ้ำ',
      layer: 'PROVINCIAL_VEIL',
      category: 'FOLK_CUSTOM',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['TOWN_YH_LIUWAN_FERRY', 'TOWN_YH_QINGXI_FOOT'],
      relatedPaths: ['CRAFT_CREATION', 'WANDERING_DAO', 'BOND_COMPANION'],
      relatedFigures: [38],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'COMMUNAL_MEAL_WARMTH', moodBonus: 6, descTh: 'เสริมสร้างน้ำใจไมตรีในโรงครัวสำนักและลดความโดดเดี่ยวของศิษย์ต่างถิ่น' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือสายลับติดสินบนพ่อครัวหรือเทวดาเตาไฟให้พร',
          credibilityBase: 45,
          biasTh: 'คำถกเถียงระหว่างเวรยามผู้ระแวงกับพ่อครัวผู้ภูมิใจ',
          summaryTh: 'เมื่อพบเบี้ยค่าอาหารวางซ้ำไว้ใต้หม้อแกงในโรงครัวถึงสองครั้ง ศิษย์เวรยามสงสัยว่าเป็นรหัสลับของสายสืบภายนอก ส่วนพ่อครัวคุยโวว่าฝีมือแกงร้อนของตนประทับใจยอดคนเร้นกาย'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บันทึกเงินเกินบัญชีเบิกจ่ายโรงครัว',
          credibilityBase: 56,
          biasTh: 'ระเบียบตรวจนับเบี้ยของหอคลัง',
          summaryTh: 'สันนิษฐานว่าเสมียนโรงครัวนับเบี้ยสวัสดิการรายสัปดาห์ซ้ำซ้อน จึงให้นำขึ้นบัญชีเงินสำรองเบ็ดเตล็ด'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'การตอบแทนน้ำใจเงียบของศิษย์ร่วมสำนัก',
          credibilityBase: 70,
          biasTh: 'ความเข้าใจของศิษย์ที่เคยร่วมโต๊ะอาหาร',
          summaryTh: 'เชื่อว่าเป็นศิษย์ที่เคยได้รับความช่วยเหลือเรื่องอาหารการกินในวันแรกเข้าสำนัก จึงนำเบี้ยมาวางคืนให้โรงครัวอย่างเงียบๆ'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ธรรมเนียม「ฝากชามอุ่นท่าข้ามฟากคุ้งหลิวเขียว」',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากพยานในโรงครัวและศิษย์ที่มีบ้านเกิดแถบท่าข้ามฟากคุ้งหลิวเขียว',
          summaryTh: 'ชาวท่าข้ามฟากคุ้งหลิวเขียวมีธรรมเนียมว่า เมื่อคนเดินทางได้รับน้ำใจจากสหายแปลกหน้าในยามขัดสน เมื่อตั้งตัวได้จะแอบวางค่าอาหารสองเท่าไว้ใต้หม้อแกงเพื่อเลี้ยงคนหลงทางคนถัดไปโดยไม่เอ่ยชื่อ'
        }
      }
    },
    {
      id: 'FACT_12_RED_RIDGE_TWIN_PASS_NAMES',
      storyId: 'STORY_12_WRONG_RIDGE_BEAST_REPORT',
      titleTh: 'ความสับสนของชื่อเรียก「สันเขาหินแดง」บนทางหลวงประจิม',
      layer: 'PROVINCIAL_VEIL',
      category: 'GEOGRAPHY',
      polityId: 'POL_XIRONG',
      anchorNodeIds: ['CITY_XR_CHIYAN_CAPITAL', 'PASS_CY_HEIYAN_ASH_PASS', 'PASS_XR_XUEYU_PENAL_GATE'],
      relatedPaths: ['WANDERING_DAO', 'BEAST_SOVEREIGN', 'STRATEGY_GOVERNANCE'],
      relatedFigures: [57],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'WEST_ROUTE_DISAMBIGUATION', legNodes: ['CITY_XR_CHIYAN_CAPITAL', 'PASS_CY_HEIYAN_ASH_PASS'], travelBonus: 0.13, descTh: 'แยกแยะพิกัดด่านผาหินแดงซีหรงกับด่านช่องเถ้าดำฉื่อเยี่ยน ป้องกันคณะเดินทางอ้อมผิดสันเขา' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวด่วนอสูรหินถล่มปิดทาง「สันเขาแดง」',
          credibilityBase: 46,
          biasTh: 'คำบอกเล่าอย่างตื่นตระหนกของคนนำสารคาราวาน',
          summaryTh: 'คนนำสารตะโกนแจ้งข่าวว่าฝูงอสูรและหินถล่มปิดทาง「สันเขาแดง」จนเดินทางไม่ได้ แต่คนท้องถิ่นเรียกทั้งผาหินแดงซีหรงและช่องเถ้าดำฉื่อเยี่ยนว่าสันเขาแดงเหมือนกัน'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ประกาศปิดด่านชั่วคราวของกองทัพหน้าซีหรง',
          credibilityBase: 60,
          biasTh: 'บันทึกทหารด่านที่ระบุแต่ชื่อมณฑลกว้างๆ',
          summaryTh: 'ระบุเพียงว่าเส้นทางรอยต่อซีหรง–ฉื่อเยี่ยนมีความเสี่ยงระดับสูงและแนะนำให้ขบวนสินค้าอ้อมลงใต้ผ่านโอเอซิสซาอวี่'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'วิธีสังเกตสีฝุ่นแร่บนล้อเกวียนคาราวาน',
          credibilityBase: 71,
          biasTh: 'เคล็ดวิชาแกะรอยของฝ่ายลาดตระเวนอสูร',
          summaryTh: 'ชี้ว่าดินแดนซีหรงเป็นทรายเหล็กสีชาด ส่วนด่านช่องเถ้าดำฉื่อเยี่ยนเป็นเขม่ากำมะถันสีเทาอมแดง สามารถดูจากคราบล้อเกวียนของผู้ส่งข่าวได้'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'แผนที่จำแนกสองสันเขาและจุดอสูรปะทุจริง',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากการตรวจคราบแร่กำมะถันของขบวนสินค้าและส่งหน่วยลาดตระเวนยืนยันพิกัด',
          summaryTh: 'จุดที่เกิดหินถล่มจริงคือไหล่เขาทิศเหนือของด่านช่องเถ้าดำเฮยเหยียน (PASS_CY_HEIYAN_ASH_PASS) ไม่ใช่ทางหลวงเข้าสู่นครปราการผาหินแดงซีหรง การยืนยันพิกัดช่วยให้แผนที่ยุทธภพระบุตำแหน่งแม่นยำและไม่ต้องอ้อมเสียเวลาหลายวัน'
        }
      }
    },
    {
      id: 'FACT_13_MERIDIAN_BELL_OMEN',
      storyId: 'STORY_13_BOTTLENECK_BELL_ECHO',
      titleTh: 'เสียงระฆังหลอนยามติดคอขวดและบันทึกธาตุไฟเข้าแทรก',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'BREAKTHROUGH',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['CITY_BM_HANYU_CAPITAL', 'CITY_BM_XUELIAN_SPRINGS'],
      relatedPaths: ['XIAN', 'HEART_SOUL', 'SONIC_RESONANCE', 'BUDDHA_DHARMA'],
      relatedFigures: [46, 47],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'BREAKTHROUGH_CALIBRATION', btStabilityBonus: 0.04, descTh: 'แยกแยะเสียงชีพจรตีกลับจากนิมิตทะลวงขั้น ลดความเสี่ยงธาตุไฟเข้าแทรกยามจิตมารสูง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ความเชื่อเรื่อง「ระฆังสวรรค์สามคราเรียกทะลวงขั้น」',
          credibilityBase: 47,
          biasTh: 'คำร่ำลือในหมู่ศิษย์ที่ติดคอขวดมานาน',
          summaryTh: 'ผู้ฝึกตนที่ติดคอขวดเล่าต่อกันว่า หากนั่งสมาธิยามดึกแล้วได้ยินเสียงระฆังกังวานในหูสามครั้ง แปลว่าประตูสวรรค์เปิดรับ ต้องรีบฝืนเดินปราณทะลวงขั้นทันที'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บันทึกอาการปราณเหมันต์สะท้อนของราชสำนักเป่ยหมิง',
          credibilityBase: 63,
          biasTh: 'รายงานหมอหลวงประจำนครหลวงปราการหยกเหมันต์',
          summaryTh: 'หมอหลวงเป่ยหมิงบันทึกว่าผู้ฝึกวิชาสายน้ำแข็งระดับสูงมักได้ยินเสียงกังวานคล้ายหยกกระทบกันเมื่อความดันปราณในจุดไป่ฮุ่ยพุ่งสูงเกินเกณฑ์'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บันทึกเตือนภัยของเจ้าสำนักรุ่นที่ 5 กู้เหยียนจือ',
          credibilityBase: 72,
          biasTh: 'สมุดบันทึกข้างแท่นจำศีลของบูรพาจารย์รุ่นที่ 5',
          summaryTh: 'กู้เหยียนจือเขียนเตือนไว้ก่อนมรณภาพว่า ในคืนพายุหิมะเขาหลงเชื่อเสียงระฆังในโสตประสาทว่าเป็นนิมิตตื่นรู้ จึงฝืนเร่งปราณจนธาตุไฟเข้าแทรก'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'หลักวินิจฉัย「เสียงสะท้อนชีพจรขมับก่อนจิตมารปะทุ」',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการเทียบสมุดบันทึกเจ้าสำนักรุ่นที่ 5 กับตำราแช่แข็งชีพจรน้ำพุหิมะอุ่นเสวี่ยเหลียน',
          summaryTh: 'เสียงระฆังสามคราในหูไม่ใช่ลางมงคลให้ฝืนทะลวงขั้น แต่เป็นอาการปราณอัดแน่นที่จุดขมับเมื่อค่าจิตมารหรือความเหนื่อยล้าสูงเกินไป ผู้รู้หลักนี้จะชะลอการฝืนทะลวงขั้นขณะจิตมารสูงและปรับลมหายใจให้มั่นคงก่อนลงมือจริง'
        }
      }
    },
    {
      id: 'FACT_14_CANGLAN_GRANARY_HALF_TALLY',
      storyId: 'STORY_14_HALF_JADE_CLAN_TALLY',
      titleTh: 'ป้ายหยกครึ่งซีกและบัญชีเผาคลังแสงแคว้นหมอกชางหลาน',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'DYNASTY',
      polityId: 'POL_YOUMING',
      anchorNodeIds: ['CITY_YM_HUNDENG_CAPITAL', 'TOWN_YM_SHIBEI_RUBBING', 'TOWN_YH_CUIZHU_TEA'],
      relatedPaths: ['ANCESTRAL_RITUAL', 'NETHER_GRAVE', 'BOND_COMPANION'],
      relatedFigures: [38],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'CLAN_KINSHIP_RECONCILIATION', trustBonus: 18, descTh: 'คลี่คลายความเข้าใจผิดข้ามสายตระกูลผู้อพยพแคว้นชางหลาน เสริมความสามัคคีในสำนัก' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'คำกล่าวหาบรรพชนสายใต้ว่าขโมยตราคลังเสบียงหนีทัพ',
          credibilityBase: 46,
          biasTh: 'ความขมขื่นของตระกูลสายเหนือที่ตกค้างในโยวหมิง',
          summaryTh: 'ทายาทสายเหนือเชื่อว่าในคืนที่แคว้นชางหลานแตก บรรพชนสายใต้ได้หักป้ายหยกครึ่งซีกและขโมยกุญแจคลังเสบียงหนีลงมาปลูกชาที่หยุนเหอ ทิ้งให้พี่น้องอดอยาก'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บันทึกการปราบกบฏคลังข้าวแห่งนครโคมวิญญาณโยวหมิง',
          credibilityBase: 58,
          biasTh: 'พงศาวดารฝ่ายผู้ชนะศึกยุคเจ็ดธง',
          summaryTh: 'บันทึกว่านายคลังแคว้นชางหลานวางเพลิงเผายุ้งฉางหลวงก่อนหลบหนี ทำให้กองทัพผู้พิชิตยึดได้เพียงเถ้าถ่าน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'รอยบากคู่บนป้ายหยกอพยพของศิษย์สองสายตระกูล',
          credibilityBase: 69,
          biasTh: 'การสังเกตรอยสลักด้านในของป้ายหยกประจำตระกูล',
          summaryTh: 'เมื่อนำป้ายหยกครึ่งซีกของสองสายตระกูลมาประกบกัน รอยบากด้านในกลับเป็นแผนผังห้องใต้ดินที่ไม่ใช่คลังข้าว แต่เป็นหอทะเบียนเกณฑ์ทหาร'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ศิลาจารึกสือเปยและบันทึกเผาบัญชีรายชื่อเยาวชนชางหลาน',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการประกบป้ายหยกสองซีกและเทียบแผ่นลอกลายศิลาตำบลสือเปย',
          summaryTh: 'สิ่งที่ถูกเผาในคืนแคว้นชางหลานแตกไม่ใช่คลังข้าว แต่คือสมุดทะเบียนรายชื่อเยาวชนทั้งเจ็ดตำบล บรรพชนสายเหนือและสายใต้แบ่งป้ายหยกคนละซีก โดยสายใต้พาเด็กๆ หนีลงใต้ ส่วนสายเหนือยอมอยู่เผาบัญชีเกณฑ์ทหารเพื่อไม่ให้กองทัพผู้รุกรานตามล่าลูกหลานได้'
        }
      }
    },
    {
      id: 'FACT_15_FROST_DEW_KILN_BANKING',
      storyId: 'STORY_15_NIGHT_DEW_KILN_SHIFT',
      titleTh: 'ธรรมเนียมกลบเถ้าเตาหลอมรับน้ำค้างกะดึกแห่งฉื่อเยี่ยน',
      layer: 'PROVINCIAL_VEIL',
      category: 'CRAFT_LABOR',
      polityId: 'POL_CHIYAN',
      anchorNodeIds: ['CITY_CY_RONGLU_CAPITAL', 'TOWN_CY_LIUHUANG_SULFUR'],
      relatedPaths: ['CRAFT_CREATION', 'RECLAMATION_DAO'],
      relatedFigures: [14],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'WORKSHOP_KILN_CUSTOM', craftSafetyBonus: 0.15, slagSalvageBonus: 1, descTh: 'ป้องกันไอพิษเตาหลอมตีกลับยามดึกและเก็บกู้เขม่าแร่บริสุทธิ์จากการควบแน่นน้ำค้าง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'เสียงบ่นเรื่องกฎกลั่นแกล้งศิษย์กะดึกให้เฝ้าชามน้ำเย็น',
          credibilityBase: 45,
          biasTh: 'ความเข้าใจของศิษย์โรงหลอมและหอโอสถรุ่นเยาว์',
          summaryTh: 'ศิษย์ฝึกหัดมักบ่นว่ากฎที่บังคับให้คนเข้าเวรกะสุดท้ายต้องกลบขี้เถ้าครึ่งปล่องและวางชามน้ำบ่อเย็นเฉียบไว้หน้าเตาเป็นเพียงการรับน้องที่ผู้อาวุโสคิดขึ้นเพื่อดูว่าศิษย์แอบหลับหรือไม่'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ข้อบังคับป้องกันอัคคีภัยสมาพันธ์ช่างฉื่อเยี่ยน',
          credibilityBase: 63,
          biasTh: 'ระเบียบความปลอดภัยของนครเตาหลอมอัคคี',
          summaryTh: 'ระบุเพียงว่าเป็นกฎลดความร้อนสะสมของเตาหลอมหลวงในช่วงเปลี่ยนกะเช้ามืด'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'เคล็ดเลี้ยงไฟหยินหยางของสายปรมาจารย์โอวหยางเหยียน (#14)',
          credibilityBase: 70,
          biasTh: 'คำอธิบายเชิงปราณธาตุไฟและน้ำ',
          summaryTh: 'อธิบายว่าการวางชามน้ำเย็นหน้าปล่องเถ้าช่วยดึงไอหยินยามรุ่งสางมาสะกดเปลวไฟคลั่งไม่ให้ปะทุทำลายตัวยาและเนื้อเหล็ก'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'กลไกควบแน่นไอกำมะถันและเก็บกู้ผงแร่บริสุทธิ์กะน้ำค้าง',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากการตรวจคราบผลึกในชามน้ำหน้าเตาหลอมและบันทึกช่างเหมืองหลิวหวง',
          summaryTh: 'เมื่ออุณหภูมิภายนอกลดลงยามใกล้รุ่ง ก๊าซพิษกำมะถันในปล่องเตาจะจมตัวไหลย้อนกลับเข้าสู่ห้องหลอม การกลบเถ้าครึ่งปล่องและวางชามน้ำเย็นจะดักจับไอพิษให้ควบแน่นตกผลึกอยู่ในชามน้ำ ทั้งช่วยป้องกันช่างกะเช้าสูดไอพิษและได้ผงแร่บริสุทธิ์กลับมาใช้ใหม่'
        }
      }
    },
    {
      id: 'FACT_16_TIGER_SEAL_CHIPPED_INKSTONE',
      storyId: 'STORY_16_EXILED_PRINCE_INKSTONE',
      titleTh: 'แท่นฝนหมึกตราพยัคฆ์บิ่นและบัญชีสำมะโนครัวชายแดนซีหรง',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'DYNASTY',
      polityId: 'POL_XIRONG',
      anchorNodeIds: ['CITY_XR_SHAYU_OASIS', 'PASS_XR_XUEYU_PENAL_GATE', 'CITY_XR_CHIYAN_CAPITAL'],
      relatedPaths: ['STRATEGY_GOVERNANCE', 'MERCANTILE_DAO', 'OATH_BINDER'],
      relatedFigures: [5, 56, 57, 60],
      secretGate: false,
      defaultAccount: 'COURT_CANON',
      gameplayEffect: { kind: 'COURT_SCHOLAR_PATRONAGE', diplomacyBonus: 8, descTh: 'ได้รับความไว้วางใจจากเครือข่ายขุนนางสายพิทักษ์ราษฎรและเพิ่มเสถียรภาพการทูตชายแดน' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือขุนนางตกอับลักลอบขายตราพยัคฆ์จำลอง',
          credibilityBase: 46,
          biasTh: 'คำซุบซิบในตลาดโอเอซิสซาอวี่',
          summaryTh: 'ร่ำลือว่าบัณฑิตตกอับที่พเนจรมาแถบชายแดนถูกปลดจากราชสำนักเพราะยักยอกเสบียงทัพ และพยายามนำแท่นฝนหมึกสลักลายพยัคฆ์บิ่นมาหลอกขายเป็นสมบัติยุคทัวป๋าเลี่ย (#5)'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'หมายถอดยศเสมียนด่านคุกโซ่โลหิตฐานขัดคำสั่งเกณฑ์พล',
          credibilityBase: 64,
          biasTh: 'ประกาศทางการของขุนศึกสายเหยี่ยวแห่งซีหรง',
          summaryTh: 'ระบุว่าขุนนางผู้นี้ถูกถอดยศและเนรเทศเพราะจงใจทำสมุดสำมะโนครัวชายแดนสูญหาย ทำให้การระดมพลล่าช้า'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ร่องรอยตราประทับสายทัวป๋ากัง (#60) ผู้ถ่วงดุลอำนาจ',
          credibilityBase: 71,
          biasTh: 'การวิเคราะห์ของเจ้าหอข่าวกรองสำนัก',
          summaryTh: 'สังเกตว่ารอยบิ่นบนแท่นฝนหมึกตรงกับตราประทับประจำตัวของผู้ตรวจการสายทัวป๋ากัง (#60) ที่คัดค้านการรีดไถเสบียงชาวบ้านโอเอซิส'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ต้นฉบับสำมะโนครัวจริงที่ซ่อนอยู่ในฐานแท่นฝนหมึกสองชั้น',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากการถอดสลักฐานแท่นฝนหมึกและตรวจสอบตัวเลขบ่อน้ำโอเอซิสซาอวี่',
          summaryTh: 'ภายในฐานแท่นฝนหมึกซ่อนบัญชีสำมะโนครัวฉบับจริงที่พิสูจน์ว่าผู้ตรวจการท่านนี้ปฏิเสธที่จะปลอมตัวเลขจำนวนประชากรโอเอซิสเพื่อป้องกันไม่ให้ชาวบ้านถูกเกณฑ์ส่วยน้ำเกินกำลังจนบ่อน้ำแห้งขอด'
        }
      }
    },
    {
      id: 'FACT_17_BITTER_WILLOW_MIASMA_WELL',
      storyId: 'STORY_17_BITTER_WILLOW_PLAGUE_WELL',
      titleTh: 'บ่อน้ำรากหลิวขมและบันทึกสกัดไข้หมอกพิษแดนทักษิณ',
      layer: 'PROVINCIAL_VEIL',
      category: 'ECOLOGY',
      polityId: 'POL_GUJIAO',
      anchorNodeIds: ['CITY_GJ_WANGU_TOTEM', 'TOWN_GJ_BAICAO_STILT', 'PASS_GJ_QIZHANG_MIASMA'],
      relatedPaths: ['VENOM_GU', 'PESTILENCE_REMEDY', 'SAGE_SUPPORT'],
      relatedFigures: [13, 40],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'MIASMA_WELL_PURIFICATION', clinicBonus: 0.14, descTh: 'นำหลักการกรองพิษด้วยรากหลิวขมมาใช้ในสถานรักษาและลดความระแวงระหว่างชาวกู่เจียวกับสุวรรณโพธิ์' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือบ่อน้ำต้องสาปหนอนกู่รากดำ',
          credibilityBase: 47,
          biasTh: 'ความหวาดกลัวของนักเดินทางที่เห็นรากไม้สีดำชอนไชปากบ่อน้ำ',
          summaryTh: 'ชาวบ้านและคนเดินทางเลี่ยงไม่กล้าตักน้ำจากบ่อหินเก่าที่มีรากหลิวสีคล้ำพันรอบปากบ่อ เพราะเชื่อว่าแม่มดกู่เจียววางพิษสาปให้น้ำมีรสฝาดขม'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'คำสั่งปิดบ่อน้ำชายแดนค่ายไผ่หมอกเจ็ดชั้น',
          credibilityBase: 59,
          biasTh: 'มาตรการกักกันโรคของด่านชายแดน',
          summaryTh: 'สั่งปักป้ายห้ามใช้น้ำจากบ่อที่มีรากหลิวชอนไชโดยสันนิษฐานว่าเป็นต้นตอของไข้ป่าฤดูฝน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บันทึกพฤกษาดูดซับพิษของสายหมู่บ้านไป๋เฉ่า',
          credibilityBase: 71,
          biasTh: 'ความรู้สมุนไพรของหมอยาแดนทักษิณ',
          summaryTh: 'ชี้ว่าต้นหลิวขมทักษิณจะแผ่รากลงสู่น้ำที่มีไอพิษหมอกสะสมเพื่อดูดซับโลหะหนักและพิษแมลงไว้ในเปลือกราก'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'บันทึกปลูกหลิวขมล้อมบ่อน้ำของศิษย์สายหมอหลวงไป๋เฉ่า (#13)',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการตรวจคุณภาพน้ำและเทียบแผ่นไม้ไผ่บันทึกโรคระบาดเมื่อห้าสิบปีก่อน',
          summaryTh: 'เมื่อครั้งเกิดไข้หมอกระบาดใหญ่ หมอยาจากหมู่บ้านไป๋เฉ่าและหมอผีกู่เจียวได้ร่วมมือกันปลูกต้นหลิวขมล้อมบ่อน้ำหลักเพื่อให้รากไม้กรองพิษจากตาน้ำใต้ดิน รสฝาดขมเล็กน้อยในน้ำคือตัวยาธรรมชาติที่ช่วยให้ชาวบ้านรอดพ้นจากโรคระบาด'
        }
      }
    },
    {
      id: 'FACT_18_THREE_LANTERN_FOG_UNDERTOW',
      storyId: 'STORY_18_FOG_LANTERN_FERRY_OATH',
      titleTh: 'คำสัตย์สามตะเกียงและร่องน้ำดูดริมขอบทะเลหมอกทักษิณ',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'FOLK_CUSTOM',
      polityId: null,
      anchorNodeIds: ['PASS_SO_DENGTAI_LIGHTHOUSE', 'CITY_SO_LONGWAN_SHIPYARD', 'TOWN_SO_OUYU_FISHER_ISLE'],
      relatedPaths: ['TIDE_VOYAGER', 'WANDERING_DAO', 'VOID_SPACE'],
      relatedFigures: [40],
      secretGate: true,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'SEA_FOG_NAVIGATION', legNodes: ['PASS_SO_DENGTAI_LIGHTHOUSE', 'CITY_SO_LONGWAN_SHIPYARD'], travelBonus: 0.14, descTh: 'เดินเรือเลียบขอบทะเลหมอกอย่างปลอดภัยด้วยวิธีหยั่งร่องน้ำสามตะเกียง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ตำนานโคมไฟวิญญาณสำเภาผีลากเรือลงก้นสมุทร',
          credibilityBase: 48,
          biasTh: 'ความเชื่อของชาวประมงเกาะโอวอวี๋',
          summaryTh: 'คนเรือสาบานว่าจะไม่ออกเรือหลังยามสามหากเห็นแสงไฟสีเขียวลอยเรี่ยน้ำ เพราะเชื่อว่าเป็นโคมนำทางของสำเภาผีที่จะลากเรือคนเป็นหายเข้าไปในทะเลหมอกไร้ขอบเขต'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ประกาศห้ามเดินเรือยามวิกาลของป้อมประภาคารปากน้ำ',
          credibilityBase: 61,
          biasTh: 'คำสั่งควบคุมการลักลอบขนสินค้าทางทะเล',
          summaryTh: 'อ้างว่าแสงไฟสีเขียวคือสัญญาณนัดหมายของโจรสลัดโขดหินหมอกเฮยเจียว จึงห้ามเรือประมงออกจากท่าหลังเที่ยงคืน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ปูมเชือกหยั่งน้ำของสันนิบาตเดินเรือสมุทรทักษิณ',
          credibilityBase: 72,
          biasTh: 'บันทึกของนายท้ายเรืออาวุโสอู่ต่อเรือหลงวาน',
          summaryTh: 'ระบุว่าแสงสีเขียวเกิดจากสาหร่ายเรืองแสงก้นร่องน้ำลึกที่ถูกกระแสน้ำดูดพัดขึ้นมาเมื่อม่านหมอกภายนอกบีบตัว'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ความจริงของแนวร่องน้ำดูดขอบม่านกั้นภพและเศษไม้สลักจากโพ้นทะเลหมอก',
          credibilityBase: 96,
          biasTh: 'พิสูจน์จากการหยั่งร่องน้ำสามตะเกียงและเก็บกู้แผ่นไม้เรือโบราณที่ซัดติดโขดหินประภาคาร',
          summaryTh: 'แสงสีเขียวคือสาหร่ายเรืองแสงที่ถูกกระแสน้ำวนริมขอบม่านกั้นภพพัดขึ้นมา การแขวนตะเกียงน้ำมันปลาสามดวงเรียงตามแนวดิ่งช่วยให้กะระยะห่างจากแนวร่องน้ำดูดได้แม่นยำ และเศษไม้เรือที่ลอยมาจากนอกม่านหมอกมีอักษรของจักรวรรดิภายนอกที่ยืนยันว่าแผ่นดินห้าภูมิภาคเป็นเพียงอนุทวีปที่ถูกผนึกไว้'
        }
      }
    },
    {
      id: 'FACT_19_MUTE_ARMORER_TWIN_TEMPER',
      storyId: 'STORY_19_SILENT_ANVIL_TEMPER_LINE',
      titleTh: 'ลายน้ำประสานทั่งไร้เสียงของสองตระกูลช่างหลอมคู่พิพาท',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'CRAFT_LABOR',
      polityId: 'POL_CHIYAN',
      anchorNodeIds: ['CITY_CY_RONGLU_CAPITAL', 'TOWN_YX_TAMAHAGANE_SAND', 'CITY_YX_WUYACASTLE'],
      relatedPaths: ['CRAFT_CREATION', 'SHADOW_SAMURAI', 'SWORD_DOMAIN'],
      relatedFigures: [14, 41],
      secretGate: false,
      defaultAccount: 'SECT_ORTHODOX',
      gameplayEffect: { kind: 'TWIN_FORGE_TEMPER_SYNERGY', weaponQualityBonus: 0.12, descTh: 'ผสานเทคนิคชุบแข็งอัคคีฉื่อเยี่ยนและตีทบทรายเหล็กดำหยุนเซียว เพิ่มความทนทานและพลังศาสตรา' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข้อกล่าวหาขโมยคัมภีร์ตีดาบข้ามแผ่นดิน',
          credibilityBase: 47,
          biasTh: 'คำท้าดวลระหว่างช่างตีเหล็กฉื่อเยี่ยนกับช่างดาบหยุนเซียว',
          summaryTh: 'ช่างหลอมแดนประจิมและช่างตีดาบผาเมฆาต่างกล่าวหาว่าอีกฝ่ายส่งสายลับมาขโมยเคล็ดวิชา「ลายน้ำประสานรอยร้าว」ของบรรพชนตนไปดัดแปลง'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ข้อบังคับห้ามส่งออกแร่เหล็กดำและกำมะถันเพลิง',
          credibilityBase: 60,
          biasTh: 'นโยบายผูกขาดยุทธภัณฑ์ของทั้งสองแคว้น',
          summaryTh: 'ทั้งสองแคว้นอ้างสิทธิ์ความเป็นต้นตำรับเพื่อสั่งห้ามค้าขายแลกเปลี่ยนแร่เหล็กข้ามภูมิภาค'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'รอยตอกกั่นดาบคู่ของสายโอวหยางเหยียน (#14) และเคนชิน (#41)',
          credibilityBase: 71,
          biasTh: 'การตรวจสอบกั่นศาสตราโบราณในคลังแสงสำนัก',
          summaryTh: 'พบว่าใต้กั่นดาบโบราณของทั้งสองสายมีรอยตอกรูปค้อนไขว้ไร้ลิ้นระฆังแบบเดียวกัน'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'บันทึกของช่างเกราะใบ้แห่งกรมศาสตราหลวงเทียนกู่',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการถอดกั่นศาสตราโบราณทั้งสองสายมาเทียบและหลอมประสานทรายเหล็กดำกับไฟกำมะถัน',
          summaryTh: 'ต้นตระกูลช่างทั้งสองแคว้นเคยเป็นศิษย์ร่วมเตาของช่างเกราะใบ้ผู้ช่วยงานโอวหยางเหยียน (#14) โดยศิษย์พี่นำเคล็ดไฟแรงไปตั้งรกรากที่ฉื่อเยี่ยน ส่วนศิษย์น้องนำเคล็ดตีทบเหล็กเย็นไปที่หาดทรายเหล็กดำหยุนเซียว เมื่อนำสองเคล็ดมาประสานกันจึงได้ลายน้ำประสานทั่งไร้เสียงที่สมบูรณ์แบบ'
        }
      }
    },
    {
      id: 'FACT_20_BROKEN_BRIDGE_EPITHET_DISPUTE',
      storyId: 'STORY_20_TWO_FACES_OF_ONE_EPITHET',
      titleTh: 'สมญานามเดียว สองตำนานที่ขัดแย้งแห่งช่องลมประจิมซีเฟิง',
      layer: 'PROVINCIAL_VEIL',
      category: 'EPITHET_LEGEND',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['PASS_YH_XIFENG_GORGE', 'CITY_YH_SHUANGJIANG'],
      relatedPaths: ['SWORD_DOMAIN', 'FOLKLORE_RUMOR', 'ARENA_GLORY'],
      relatedFigures: [6, 38],
      secretGate: false,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'EPITHET_CHRONICLE_VERIFICATION', fameBonus: 10, descTh: 'บันทึกทั้งนามเสียงที่ผู้คนร่ำลือและข้อเท็จจริงจากพยานในเหตุการณ์สะพานขาดช่องลมซีเฟิง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'เพลงโรงเตี๊ยมเหนือ:「จอมมารดาบเดียวสังหารสามสิบโจรหน้าสะพาน」',
          credibilityBase: 48,
          biasTh: 'การแต่งเติมให้ดุดันน่าเกรงขามของนักเล่านิทานแดนเหนือ',
          summaryTh: 'โรงเตี๊ยมสายเหนือขับขานว่าเจ้าของสมญานามสะบั้นสะพานซีเฟิงได้ลงมือสังหารโจรภูเขาสามสิบศพในดาบเดียวจนลำธารย้อมเป็นสีเลือด'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บันทึกคดีทำลายสะพานแขวนหลวงด่านช่องลมซีเฟิง',
          credibilityBase: 59,
          biasTh: 'สำนวนสอบสวนของด่านตรวจการที่มองแต่ความเสียหายของทรัพย์สิน',
          summaryTh: 'บันทึกว่าจอมยุทธ์พเนจรใช้กำลังภายในฟันเชือกสะพานแขวนขาดทำให้ทางส่งส่วยหยุดชะงักไปสามวัน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'เรื่องเล่าท่าข้ามฟากใต้:「ผู้ฟันเชือกสะพานเปิดทางหนีให้ชาวบ้านโดยไม่เปื้อนเลือด」',
          credibilityBase: 71,
          biasTh: 'คำบอกเล่าของลูกหลานชาวบ้านที่รอดชีวิตในวันเกิดเหตุ',
          summaryTh: 'ชาวบ้านฝั่งใต้ยืนยันว่าจอมยุทธ์ผู้นั้นไม่ได้ฆ่าใครเลยแม้แต่คนเดียว แต่ฟันเชือกสะพานแขวนหลังจากชาวบ้านข้ามพ้นหมดแล้ว เพื่อสกัดกองโจรไม่ให้ตามทัน'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'พงศาวดารสองด้านของสมญานาม「ดาบสะบั้นสะพานซีเฟิง」',
          credibilityBase: 95,
          biasTh: 'พิสูจน์จากการสอบทานพยานชาวบ้าน รอยดาบบนเสาหินสะพาน และคำให้การของอดีตหัวหน้าโจรที่กลับใจ',
          summaryTh: 'จอมยุทธ์ฟันเชือกสะพานขาดในดาบเดียวโดยไม่ปลิดชีพผู้ใดเพื่อรักษาศีลไม่สังหาร แต่หัวหน้าโจรที่พ่ายแพ้เกิดความอับอายที่ไม่กล้ากระโดดข้ามเหว จึงปั้นเรื่องโกหกว่าลูกน้องตนถูกยอดฝีมือลึกลับสังหารไปสามสิบคนเพื่อรักษาหน้า จนเกิดเป็นสองตำนานที่ขัดแย้งกัน'
        }
      }
    },
    {
      id: 'FACT_21_SU_QIN_820YR_YUNHE_TREATY',
      storyId: null,
      titleTh: 'สนธิสัญญาหยุนเหอ 820 ปี และกลไกถ่วงดุลเก้าแคว้นของซูฉิน (#37)',
      layer: 'IMPERIAL_CHESSBOARD',
      category: 'DYNASTY',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_SHUANGJIANG', 'CITY_YH_OLD_DAREN_SQUARE'],
      relatedPaths: ['STRATEGY_GOVERNANCE', 'MERCANTILE_DAO'],
      relatedFigures: [37, 46, 52, 57],
      secretGate: false,
      defaultAccount: 'COURT_CANON',
      gameplayEffect: { kind: 'DIPLOMACY_INSIGHT', diplomacyBonus: 5, descTh: 'เข้าใจกติกากันชนหยุนเหอและการทูตระหว่างสามมหาอำนาจ' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ตำนานลิ้นสาริกาหยุดสามกองทัพของมหาเสนาบดีซูฉิน (#37)',
          credibilityBase: 52,
          biasTh: 'นิทานโรงน้ำชานครสองแควหยุนเหอ',
          summaryTh: 'ชาวบ้านเล่าว่าซูฉิน (#37) ยืนพูดบนสะพานสองแควสามวันสามคืนจนกษัตริย์สามจักรวรรดิยอมวางอาวุธและยกหุบเขาหยุนเหอให้เป็นเขตปลอดทหาร'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'สนธิสัญญาเขตกันชนการค้าและห้ามเดินทัพหลวงผ่านหยุนเหอ',
          credibilityBase: 72,
          biasTh: 'เอกสารทางการของสภาเจ็ดวาณิชและสามมหาจักรวรรดิ',
          summaryTh: 'สามมหาจักรวรรดิ (เป่ยหมิง ตงหวง ซีหรง) ลงนามรับรองความเป็นกลางของแคว้นอิสระหยุนเหอ เพื่อใช้เป็นตลาดกลางแลกเปลี่ยนเสบียงและศิลาวิญญาณโดยห้ามส่งกองทัพหลวงล่วงล้ำ'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'กติกา 19 สำนักตัวแทนใต้เงาสนธิสัญญาหยุนเหอ',
          credibilityBase: 76,
          biasTh: 'บันทึกการเมืองยุทธภพของหอข่าวกรอง',
          summaryTh: 'เพราะสนธิสัญญาห้ามกองทัพหลวงรบกันโดยตรงในเขตกันชน ทั้งเก้าแคว้นจึงหันมาหนุนหลังสำนักยุทธ์ทั้ง 19 แห่งให้ทำศึกชิงแหล่งทรัพยากรและบารมีแทนราชสำนัก'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'เงื่อนไขลับใต้ศิลาสนธิสัญญาหยุนเหอเรื่องชีพจรปราณใต้หุบเขา',
          credibilityBase: 94,
          biasTh: 'พิสูจน์จากสำเนาสนธิสัญญาฉบับเต็มในหอจดหมายเหตุเมืองเก่าสิบสองคบเพลิง',
          summaryTh: 'สาเหตุแท้จริงที่ซูฉิน (#37) โน้มน้าวสามจักรวรรดิได้สำเร็จ คือการชี้ให้เห็นว่าหากเกิดสงครามใหญ่เหนือหุบเขาหยุนเหอ แรงสั่นสะเทือนจะทำให้ผนึกประตูมิติหลวงใต้ดินปริแตกและดึงทัณฑ์ม่านฟ้าลงมาทำลายทุกแคว้นพร้อมกัน'
        }
      }
    },
    {
      id: 'FACT_22_SIMA_QING_BROKEN_CURIO_HUNT',
      storyId: null,
      titleTh: 'ความลับการกว้านซื้อของเก่าชำรุดของคุณชายสามซือหม่าชิง (#52)',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'DYNASTY',
      polityId: 'POL_DONGHUANG',
      anchorNodeIds: ['CITY_DH_JIUKU_CAPITAL', 'CITY_DH_QINGLAN_DICE_CITY'],
      relatedPaths: ['MERCANTILE_DAO', 'LORE_ARCHIVIST', 'STRATEGY_GOVERNANCE'],
      relatedFigures: [4, 52, 53],
      secretGate: true,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'CURIO_APPRAISAL_INSIGHT', tradeBonus: 0.08, descTh: 'รู้เท่าทันมูลค่าของวัตถุโบราณไร้ปราณที่รอดพ้นม่านกั้นภพ (STORY-SYNC-02)' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือคุณชายเสเพลคลั่งสะสมถ้วยชามร้าว',
          credibilityBase: 50,
          biasTh: 'เพลงล้อเลียนในโรงเตี๊ยมตงหวง',
          summaryTh: 'ชาวเมืองหัวเราะเยาะว่าซือหม่าชิง (#52) และหอการค้าของว่านจินเหนียง (#53) ใช้เงินคลังไปกว้านซื้อถ้วยชามบิ่นและเศษพัดพังๆ ตามแผงของเก่าเพราะความเพี้ยน'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'โครงการรวบรวมโบราณวัตถุยุคก่อตั้งราชวงศ์ซือหม่า',
          credibilityBase: 64,
          biasTh: 'คำชี้แจงของกรมคลังตงหวง',
          summaryTh: 'อ้างว่าเป็นการรวบรวมเครื่องใช้โบราณเพื่อจัดแสดงในหอเกียรติยศราชธานีเก้าคลังสุริยัน'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'การแกะรอยอักขระผนึกลังส่วยของซือหม่าชุน (#4)',
          credibilityBase: 76,
          biasTh: 'บันทึกของปรมาจารย์ค่ายกลและอาลักษณ์',
          summaryTh: 'สังเกตว่าของเก่าที่ซือหม่าชิงกว้านซื้อล้วนมีรอยตราประทับอักขระแบบเดียวกับสมุดคุมทะเบียนทาสเหมืองของปฐมเสนาบดีซือหม่าชุน (#4)'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'กฎการคัดกรองของม่านกั้นภพ: มีเพียงขยะไร้ปราณเซียนที่รอดลงมาได้ (STORY-SYNC-02)',
          credibilityBase: 96,
          biasTh: 'พิสูจน์จากการตรวจเศษภาชนะไร้ปราณที่ทนทานต่อแรงบดขยี้ของม่านฟ้า',
          summaryTh: 'ซือหม่าชิง (#52) รู้ความลับจากบันทึกต้นตระกูลว่า ม่านกั้นภพจะบดขยี้ศาสตราที่มีปราณเซียนทุกชิ้นที่ร่วงลงมาจากโลกเบื้องบน มีเพียง「ของใช้สามัญที่ชำรุดและไร้ปราณ」เท่านั้นที่หลุดรอดลงมาได้โดยไม่ถูกทำลาย'
        }
      }
    },
    {
      id: 'FACT_23_MINGYU_FROST_ROBE_AND_HEART_FREEZE',
      storyId: null,
      titleTh: 'อาการหัวใจน้ำแข็งของกู่เทียนเฉิน (#46) และเศษผ้าปูโต๊ะน้ำชาสวรรค์ (STORY-SYNC-01)',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'MARTIAL_SCHISM',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['CITY_BM_HANYU_CAPITAL', 'CITY_BM_XUELIAN_SPRINGS'],
      relatedPaths: ['XIAN', 'ICE_FROST', 'CRAFT_CREATION'],
      relatedFigures: [2, 24, 46, 47],
      secretGate: true,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'FROST_MERIDIAN_GUARD', frostResistBonus: 0.10, descTh: 'เข้าใจผลข้างเคียงของปราณหยกใสหมิงยวี่และวิธีถนอมเส้นชีพจรหัวใจ' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ข่าวลือพายุหิมะวิปริตและการหาโอสถหยางรักษาจักรพรรดิเป่ยหมิง',
          credibilityBase: 50,
          biasTh: 'คำร่ำลือของพ่อค้าสมุนไพรแดนเหนือ',
          summaryTh: 'ร่ำลือว่าจักรพรรดิกู่เทียนเฉิน (#46) ประชวรด้วยโรคไอเย็นย้อนกลับเข้าสู่หัวใจ จึงส่งทูตออกกว้านซื้อสมุนไพรธาตุหยางทั่วแผ่นดิน'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ประกาศการเข้าฌานหลอมกายาหยกเหมันต์ขั้นสูงสุด',
          credibilityBase: 62,
          biasTh: 'แถลงการณ์ราชสำนักเป่ยหมิง',
          summaryTh: 'ราชสำนักประกาศว่าไอเย็นรอบตำหนักหลวงเกิดจากการที่องค์จักรพรรดิบรรลุเคล็ดปราณหยกใสหมิงยวี่ขั้นที่เก้า'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ปริศนาอาภรณ์ขนนกกระเรียนสวรรค์ที่ขาดหายไปครึ่งผืน',
          credibilityBase: 75,
          biasTh: 'บันทึกของยอดช่างทอและผู้ฝึกตนสายเหมันต์',
          summaryTh: 'ระบุว่าเคล็ดปราณหมิงยวี่ของกู่หลิงเฟย (#2) ต้องฝึกควบคู่กับภูษาผนึกเหมันต์ที่ยายเมิ่ง (#24) ทอไว้ มิฉะนั้นปราณเย็นจะแช่แข็งชีพจรหัวใจผู้ฝึก'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ความจริงของผ้ารองถาดน้ำชาแช่เย็นจากเรือสำราญโลกเบื้องบน (STORY-SYNC-01)',
          credibilityBase: 97,
          biasTh: 'พิสูจน์จากบันทึกยายเมิ่ง (#24) และเส้นใยอาภรณ์ในซากอุทยานหลวง',
          summaryTh: 'ภูษาวิเศษที่กู่หลิงเฟย (#2) สวมจำศีลแท้จริงคือเศษผ้ารองถาดน้ำชาแช่เย็นจากเรือสำราญสวรรค์ที่ยายเมิ่ง (#24) นำมาตัดเย็บ ส่วนกู่เทียนเฉิน (#46) ฝึกวิชาหมิงยวี่โดยไม่มีผ้าชั้นในคุ้มกาย หัวใจของเขาจึงค่อยๆ ถูกแช่แข็งทีละน้อย'
        }
      }
    },
    {
      id: 'FACT_24_XINGCHENZI_TOY_ASTROLABE_GEAR',
      storyId: null,
      titleTh: 'จานจำลองกลุ่มดาวเฟืองบิ่นสองซี่ของซิงเฉินจื่อ (#16) และการหักเหของม่านฟ้า (STORY-SYNC-04)',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'MARTIAL_SCHISM',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['CITY_BM_XINGYUN_CITADEL'],
      relatedPaths: ['STAR_FATE', 'ARRAY_TALISMAN', 'CHRONO_FATE'],
      relatedFigures: [16, 49],
      secretGate: true,
      defaultAccount: 'SECT_ORTHODOX',
      gameplayEffect: { kind: 'ASTRAL_REFRACTION_CALIBRATION', divinationBonus: 0.12, descTh: 'ชดเชยค่าความคลาดเคลื่อนของแสงดาวที่หักเหผ่านม่านกั้นภพ' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ตำนานจานดาราสวรรค์ทำนายชะตาหมื่นปี',
          credibilityBase: 48,
          biasTh: 'คำเล่าลือในเมืองดาราพยากรณ์ซิงหยวน',
          summaryTh: 'เชื่อว่านักพรตดาราซิงเฉินจื่อ (#16) ได้รับพระราชทานจานหมุนดวงดาวจากเทพแห่งโชคชะตาและซ่อนไว้ในหอดูดาวที่เวลาหยุดนิ่ง'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ปฏิทินดาราหลวงแห่งหอพยากรณ์เป่ยหมิง',
          credibilityBase: 64,
          biasTh: 'บันทึกโหรหลวง',
          summaryTh: 'โหรหลวงใช้ตารางดาวของซิงเฉินจื่อในการคำนวณฤกษ์ยามศึก แต่พบว่าทุกๆ ร้อยปีตำแหน่งดาวเหนือจะคลาดเคลื่อนไปสององศาโดยไม่ทราบสาเหตุ'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ภารกิจลับที่ซิงเฉินจื่อ (#16) มอบให้ซิงอวิ๋น (#49)',
          credibilityBase: 76,
          biasTh: 'บันทึกสายวิถีดาราชะตา',
          summaryTh: 'ซิงเฉินจื่อค้นพบว่าท้องฟ้าที่คนโลกล่างมองเห็นเป็นภาพลวงที่ถูกม่านกั้นภพหักเห จึงฝากป้ายหยกดาราให้ซิงอวิ๋น (#49) สืบหาความจริง'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ลูกข่างจำลองกลุ่มดาวของเล่นเด็กจากตระกูลโหรโลกเบื้องบน (STORY-SYNC-04)',
          credibilityBase: 97,
          biasTh: 'พิสูจน์จากรอยเฟืองบิ่นสองซี่และการคำนวณมุมหักเหของม่านฟ้า',
          summaryTh: 'จานสวรรค์ของซิงเฉินจื่อ (#16) แท้จริงคือของเล่นจำลองกลุ่มดาวสำหรับเด็กในตระกูลโหรสวรรค์ที่เฟืองบิ่นไปสองซี่แล้วถูกโยนทิ้งลงมา แต่เพียงของเล่นชิ้นนั้นก็ทำให้ซิงเฉินจื่อคำนวณพบว่าม่านฟ้ากำลังบิดเบือนแสงดาวและมีเงามืดเบื้องบนคอยเฝ้ามองโลกล่างอยู่'
        }
      }
    },
    {
      id: 'FACT_25_KONG_MING_SHATTERED_DANTIAN_STRANDING',
      storyId: null,
      titleTh: 'กฎแรงดีดม่านฟ้าและสาเหตุที่ทูตตกสวรรค์ขงหมิง (#21) ติดค้างในโลกล่าง (STORY-SYNC-10)',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'SECT_LINEAGE',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['PASS_YH_XIFENG_GORGE', 'CITY_YH_BAILU_ACADEMY'],
      relatedPaths: ['VOID_SPACE', 'HEART_SOUL', 'DIVINE_SUMMONER'],
      relatedFigures: [19, 21, 28, 39],
      secretGate: true,
      defaultAccount: 'FOLK_ORAL',
      gameplayEffect: { kind: 'SKY_CURTAIN_LAW_INSIGHT', tribulationResistBonus: 0.08, descTh: 'เข้าใจกฎแรงกดทับของม่านกั้นภพและการจำกัดตบะโลกล่าง' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'นิทานนักพรตขี้เมาผู้วางหมากหินริมผาเมฆา',
          credibilityBase: 47,
          biasTh: 'คำบอกเล่าของเสี่ยวเอ้อร์โรงเตี๊ยมด่านหน้า (BALLAD_06)',
          summaryTh: 'เล่าว่ามีนักพรตชราชุดผ้าป่านขาดวิ่นชอบเอาเศษหยกสลักอักษรประหลาดมาจ่ายค่าสุราแล้วแหงนมองฟ้าถอนหายใจเหมือนคนกลับบ้านไม่ได้'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'บันทึกผู้ลี้ภัยปริศนายุคประตูมิติหลวงระเบิด',
          credibilityBase: 60,
          biasTh: 'แฟ้มลับสำนักตรวจการ',
          summaryTh: 'สันนิษฐานว่าเป็นเพียงยอดฝีมือโบราณที่บาดเจ็บจากการระเบิดที่เทียนกู่และหลบซ่อนตัวตามแนวเขาหยุนเหอ'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'บทเรียนม่านฟ้าตบสวนของเสิ่นเทียนจุน (#28) และหนึ่งกระบี่ของจิ้วเจี้ยนเซียน (#39)',
          credibilityBase: 76,
          biasTh: 'บันทึกเตือนภัยของสายอัญเชิญเทวะและวิถีกระบี่',
          summaryTh: 'ระบุว่าม่านกั้นภพจะดีดหรือบดขยี้ผู้ที่มีตบะเกินเพดานขั้น 9 ทันที ดังที่เสิ่นเทียนจุน (#28) เคยถูกม่านฟ้าตบสวนเมื่อทำพิธีเรียกทวยเทพ'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ตันเถียนที่แหลกสลายของเบี้ยสงครามจากโลกเบื้องบน (STORY-SYNC-10)',
          credibilityBase: 97,
          biasTh: 'พิสูจน์จากบันทึกหมากล้อมของขงหมิง (#21) และผนึกของเฮ่อเหลียนม่อ (#19)',
          summaryTh: 'ขงหมิง (#21) และแม่ทัพศัตรูเฮ่อเหลียนม่อ (#19) คือผู้มาจากโลกเบื้องบนที่ถูกแรงระเบิดประตูมิติหลวงบดขยี้ตันเถียนจนตบะร่วงหล่นต่ำกว่าเกณฑ์ขั้น 9 ม่านกั้นภพจึงมองว่าพวกเขาเป็นเพียงสิ่งมีชีวิตโลกล่างและไม่ดีดกลับขึ้นไป ทำให้ต้องติดค้างอยู่ในโลกเบื้องล่างชั่วนิรันดร์'
        }
      }
    },
    {
      id: 'FACT_26_SUBCONTINENT_CRATER_BEYOND_FOG_SEA',
      storyId: null,
      titleTh: 'สัจธรรมอนุทวีปหลุมอุกกาบาต 1,000 × 1,000 ลี้ และมหาอาณาจักรพ้นทะเลหมอก (LORE_06B)',
      layer: 'SHATTERED_SUBCONTINENT',
      category: 'GEOGRAPHY',
      polityId: null,
      anchorNodeIds: ['PASS_SO_DENGTAI_LIGHTHOUSE', 'PASS_SO_HEIJIAO_CORSAIR_REEF', 'PASS_BM_XUEFENG_WEST'],
      relatedPaths: ['TIDE_VOYAGER', 'WANDERING_DAO', 'STAR_FATE'],
      relatedFigures: [1, 16, 21],
      secretGate: true,
      defaultAccount: 'SECT_ORTHODOX',
      gameplayEffect: { kind: 'CONTINENTAL_HORIZON_AWARENESS', explorationBonus: 0.10, descTh: 'ตระหนักถึงขอบเขตที่แท้จริงของแผนที่ห้าภูมิภาคและม่านหมอกรอบอนุทวีป' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ความเชื่อว่าแผ่นดินเก้าแคว้นคือโลกมนุษย์ทั้งหมด',
          credibilityBase: 50,
          biasTh: 'โลกทัศน์สามัญของชาวบ้านและจอมยุทธ์ทั่วไป',
          summaryTh: 'ผู้คนทั่วไปเชื่อว่าแผ่นดินห้าภูมิภาคกว้างพันลี้คูณพันลี้คือใต้หล้าทั้งหมด ส่วนนอกทะเลหมอกและเทือกเขาน้ำแข็งคือสุดขอบโลกที่ไร้สิ่งมีชีวิต'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'แผนที่ยุทธศาสตร์เก้าแคว้นฉบับราชสำนัก',
          credibilityBase: 65,
          biasTh: 'แผนที่ทางการของสามมหาจักรวรรดิ',
          summaryTh: 'กำหนดให้แนวทะเลหมอกทักษิณและทุ่งน้ำแข็งเหนือเป็นเขตสิ้นสุดพระราชอาณาเขตและห้ามจัดตั้งกองเรือสำรวจออกนอกม่านหมอก'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ข้อสังเกตเรื่องแนวภูเขาวงแหวนรอบแผ่นดินห้าภูมิภาค',
          credibilityBase: 76,
          biasTh: 'การสำรวจภูมิลักษณ์ของนักพรตดาราและนักเดินเรือ',
          summaryTh: 'สังเกตว่าเทือกเขาเหนือ ผาเมฆาตะวันออก ทะเลทรายตะวันตก และโขดหินทะเลใต้ ล้วนโค้งเข้าหากันเป็นรูปขอบหลุมวงกลมขนาดมหึมาโดยมีหุบเขาหยุนเหอเป็นจุดศูนย์กลาง'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'อนุทวีปหลุมระเบิดเทียนกู่ที่ถูกตัดขาดจากแผ่นดินใหญ่ภายนอก (LORE_06B)',
          credibilityBase: 98,
          biasTh: 'พิสูจน์จากการประกอบแผนที่ธรณีสัณฐานห้าภูมิภาคเข้ากับบันทึกม่านกั้นภพ',
          summaryTh: 'แผ่นดิน 1,000 × 1,000 ลี้ทั้งหมดเป็นเพียง「หลุมระเบิดของประตูมิติหลวงเทียนกู่」ที่ถูกโดมม่านกั้นภพครอบไว้เหมือนกะลา ทะเลหมอกที่ล้อมรอบคือขอบม่านผนึก และพ้นม่านหมอกออกไปภายนอกยังมีแผ่นดินใหญ่และมหาอาณาจักรอื่นของโลกเบื้องล่างตั้งอยู่'
        }
      }
    },
    {
      id: 'FACT_27_ANTEDILUVIAN_THREE_SOVEREIGN_EPOCHS',
      storyId: null,
      titleTh: 'สามยุคบรรพกาลก่อนเทียนกู่ที่ถูกกรมพิธีการลบออกจากประวัติศาสตร์ (LORE_06A)',
      layer: 'ERASED_PREHISTORY',
      category: 'SECT_LINEAGE',
      polityId: null,
      anchorNodeIds: ['TOWN_YM_SHIBEI_RUBBING', 'TOWN_BM_BAIMEI_OLD_FORT', 'CITY_GJ_WANGU_TOTEM'],
      relatedPaths: ['LORE_ARCHIVIST', 'PRIMORDIAL_SHIFTER', 'STAR_FATE'],
      relatedFigures: [1, 15, 25],
      secretGate: true,
      defaultAccount: 'SECT_ORTHODOX',
      gameplayEffect: { kind: 'ANTEDILUVIAN_SANCTUM_INSIGHT', sanctumBonus: 0.12, descTh: 'เข้าใจต้นกำเนิดของสี่มหาแดนลับและคัมภีร์บรรพกาลก่อนยุคเทียนกู่' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ตำนานว่าเทียนกู่คืออาณาจักรแรกของมนุษยชาติ',
          credibilityBase: 48,
          biasTh: 'ประวัติศาสตร์ฉบับท่องจำในสำนักศึกษา',
          summaryTh: 'ตำราเรียนทุกแคว้นสอนตรงกันว่าก่อนการสถาปนามหาจักรวรรดิเทียนกู่ แผ่นดินนี้เป็นเพียงป่ารกร้างที่ไร้ซึ่งอารยธรรมและวิถีบำเพ็ญ'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'พงศาวดารปฐมกษัตริย์เทียนกู่ผู้ประทานอักษรและไฟปราณ',
          credibilityBase: 64,
          biasTh: 'โฆษณาชวนเชื่อของราชวงศ์กู่โบราณ',
          summaryTh: 'เชิดชูว่าราชวงศ์เทียนกู่เป็นผู้คิดค้นมหาวิถีทั้งปวงและสร้างมหาแดนลับทั้งสี่ไว้เป็นคลังหลวง'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ร่องรอยอักขระก่อนยุคเทียนกู่ในหอจดหมายเหตุสี่มหาแดนลับ',
          credibilityBase: 78,
          biasTh: 'การค้นพบของคณะสำรวจมหาแดนลับโบราณ (SANCTUM_SOV_01..04)',
          summaryTh: 'ชั้นหินใต้ฐานมหาแดนลับทั้งสี่มีอายุเก่าแก่กว่ายุคเทียนกู่นับหมื่นปี และใช้อักขระดาวหลอม-โลหิตอสูรที่ไม่ตรงกับอักษรหลวงเทียนกู่'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'สามยุคบรรพกาลที่ถูกลบ: ยุคเตาหลอมดารา ยุคพันธสัญญาอสูรบรรพกาล และยุคพฤกษาวิญญาณ (LORE_06A)',
          credibilityBase: 98,
          biasTh: 'พิสูจน์จากศิลาชั้นลึกสุดของสี่มหาแดนลับและบันทึกที่รอดจากการเผาตำราของกรมพิธีการเทียนกู่',
          summaryTh: 'ก่อนยุคเทียนกู่เคยมีอารยธรรมรุ่งเรืองถึง 3 ยุค ได้แก่ ยุคเตาหลอมดาราบรรพกาล ยุคพันธสัญญาราชันอสูร และยุคพฤกษาวิญญาณโลกา ซึ่งผู้ก่อตั้งเทียนกู่ได้สั่งเผาทำลายบันทึกทั้งหมดเพื่อผูกขาดความชอบธรรมว่าตนเป็นจุดเริ่มต้นของมรรคา'
        }
      }
    },
    {
      id: 'FACT_28_NAMELESS_FOUNDER_UPPER_WORLD_VIGIL',
      storyId: null,
      titleTh: 'ชาติกำเนิดที่แท้จริงของปรมาจารย์ผู้ก่อตั้งรุ่นที่ 1 (#45) และเหตุผลของตราหินเทาไร้ลักษณ์',
      layer: 'ERASED_PREHISTORY',
      category: 'SECT_LINEAGE',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_OLD_DAREN_SQUARE', 'PASS_YH_YUGUAN_RUIN_POST'],
      relatedPaths: ['XIAN', 'VOID_SPACE', 'HEART_SOUL'],
      relatedFigures: [21, 25, 45],
      secretGate: true,
      defaultAccount: 'SECT_ORTHODOX',
      gameplayEffect: { kind: 'FOUNDER_ORIGIN_AWAKENING', regaliaInsightBonus: 2, descTh: 'ปลุกเสียงสะท้อนต้นกำเนิดของตราหินเทาไร้ลักษณ์โดยคงความลับไม่ให้รั่วไหลสู่สาธารณะ' },
      accounts: {
        FOLK_ORAL: {
          id: 'FOLK_ORAL',
          labelTh: 'ตำนานผู้เฒ่านิรนามผู้เร้นกายในหุบเขาเมฆาเร้น',
          credibilityBase: 55,
          biasTh: 'บันทึกเปิดเผยบนป้ายบรรพชนรุ่นที่ 1 (PATRIARCH_GEN_1)',
          summaryTh: 'บันทึกสาธารณะของสำนักระบุเพียงว่า ปรมาจารย์ผู้ก่อตั้งรุ่นที่ 1 เป็นผู้เฒ่าพเนจรนิรนามที่เข้ามาปลูกกระท่อมดูแลสัตว์วิญญาณและทิ้งตราหินเทาไร้ลักษณ์ไว้ก่อนเดินหายเข้าทะเลหมอก'
        },
        COURT_CANON: {
          id: 'COURT_CANON',
          labelTh: 'ทะเบียนสำนักขนาดเล็กไร้สังกัดในหุบเขาสองแคว',
          credibilityBase: 60,
          biasTh: 'บันทึกของสภาเจ็ดวาณิชหยุนเหอ',
          summaryTh: 'มองว่าสำนักของเราเป็นเพียงสำนักท้องถิ่นที่สืบทอดกันมาเจ็ดรุ่นโดยไม่ได้ข้องเกี่ยวกับราชสำนักหรือศึกประตูมิติโบราณ'
        },
        SECT_ORTHODOX: {
          id: 'SECT_ORTHODOX',
          labelTh: 'ความเชื่อมโยงระหว่างค่ายกลฐานสำนักกับซากประตูมิติหลวงใต้ก้นเหว',
          credibilityBase: 78,
          biasTh: 'ข้อสังเกตของเจ้าสำนักรุ่นที่ 6–7 เมื่อตราหินเทาไร้ลักษณ์ตื่นรู้',
          summaryTh: 'ค่ายกลแปดยอดเขาของสำนักถูกวางทับจุดศูนย์ถ่วงของซากประตูมิติหลวงใต้ก้นเหวอย่างจงใจ เพื่อใช้ปราณธรรมชาติของสัตว์วิญญาณและผู้ฝึกตนหลากหลายวิถีช่วยกลบเกลื่อนรอยรั่วมิติ'
        },
        VERIFIED_CHRONICLE: {
          id: 'VERIFIED_CHRONICLE',
          labelTh: 'ผู้เฝ้ายามนิรนาม (#45) ผู้หลอมตราหินไร้ลักษณ์เพื่อซ่อนผู้สืบทอดจากสายตาสวรรค์ (LORE_05B)',
          credibilityBase: 99,
          biasTh: 'ความลับสูงสุดที่เปิดเผยเฉพาะเมื่อตราหินเทาไร้ลักษณ์และบันทึกบรรพชนครบสมบูรณ์',
          summaryTh: 'ปรมาจารย์ผู้ก่อตั้งรุ่นที่ 1 (#45) คืออดีตผู้ตรวจการค่ายกลจากโลกเบื้องบนที่เลือกสละนามและผนึกตบะตนเองไว้ใต้หุบเขาเพื่อเฝ้ารอยร้าวประตูมิติหลวง เขาจงใจหลอม「ตราหินเทาไร้ลักษณ์」ให้ดูเหมือนก้อนหินสามัญไร้ปราณเซียนและไม่ผูกมัดกับวิถีใดวิถีหนึ่ง เพื่อไม่ให้ม่านกั้นภพและสายตาจากโลกเบื้องบนตรวจจับและลงทัณฑ์เจ้าสำนักรุ่นที่ 2 ถึงรุ่นที่ 7 ได้'
        }
      }
    }
  ]);

  const FACT_BY_ID = Object.freeze(Object.fromEntries(CANON_FACTS.map(f => [f.id, f])));

  // 20 Multi-Stage Playable Living Lore Story Chains (12 Adopted & Refined from Codex + 8 Original Gemini Chains)
  const STORY_CHAINS = Object.freeze([
    {
      id: 'STORY_01_SHUANGJIANG_FLOOD_LEDGER',
      titleTh: 'สมุดระดับน้ำท่วมและตำนานน้ำไหลย้อนแห่งซวงเจียง',
      group: 'CODEX_ADOPTED',
      category: 'GEOGRAPHY_ROUTE',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_01_SHUANGJIANG_BACKFLOW',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE'],
      summaryTh: 'เปรียบเทียบเพลงโรงเตี๊ยมเรื่องพญานาคราชทำให้น้ำสองแควไหลย้อน กับรอยสิ่ววัดระดับน้ำแล้งใต้สะพานศิลาสามแควและสมุดส่วยข้าวโบราณ',
       stages: [
        {
          idx: 0,
          id: 'SPARK_BACKFLOW_RUMOR',
          titleTh: 'ได้ยินคำร่ำลือเรื่องน้ำสองแควไหลย้อนกลืนเรือสินค้า',
          locationId: 'CITY_YH_SHUANGJIANG',
          accountId: 'FOLK_ORAL',
          descTh: 'คนแจวเรือที่นครสองแควหยุนเหอเล่าขานเรื่องกระแสน้ำไหลย้อนทุกปลายฤดูใบไม้ร่วง จนขบวนคาราวานลังเลที่จะข้ามน้ำ'
        },
        {
          idx: 1,
          id: 'CHECK_BRIDGE_CHISEL_AND_LEDGER',
          titleTh: 'สำรวจรอยสิ่ววัดระดับน้ำใต้ตอม่อสะพานศิลาสามแควและสมุดส่วยข้าว',
          locationId: 'PASS_YH_SANJIANG_BRIDGE',
          accountId: 'SECT_ORTHODOX',
          descTh: 'ตรวจสอบขีดหินโบราณยุคเหยียนหลิงใต้ตอม่อสะพานศิลาสามแควเทียบกับบันทึกปีที่หิมะเหนือละลายช้า'
        },
        {
          idx: 2,
          id: 'RESOLVE_HYDRO_CHRONICLE',
          titleTh: 'สรุปวัฏจักรสันดอนหนุนน้ำและวางแนวทางเดินเรือของสำนัก',
          locationId: 'CITY_YH_SHUANGJIANG',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เลือกแนวทางนำความรู้เรื่องช่วงน้ำหนุน 9 วันไปใช้ปรับตารางคาราวานหรือบันทึกเข้าหอคัมภีร์'
        }
      ],
      resolutions: [
        {
          id: 'CAUTIOUS_CONVOY_TIMETABLE',
          labelTh: 'ปรับตารางคาราวานและเรือข้ามฟากหลบช่วงน้ำหนุน 9 วัน',
          match: n => E(n, 'personality.caution') >= 55 || ['quartermaster', 'mission', 'treasury'].includes(n.post),
          consequenceTh: 'ฝ่ายยุทธปัจจัยกำหนดตารางเดินเรือหลบช่วงสันดอนหนุนน้ำ ลดเวลาเดินทางและความเสี่ยงบนเส้นทางซวงเจียง–สะพานศิลาสามแควถาวร',
          effect: { routeBonusLeg: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE'], routeMultiplier: 0.86, citySafetyDelta: 4 }
        },
        {
          id: 'SCHOLAR_HYDRO_ARCHIVE',
          labelTh: 'เรียบเรียง「พงศาวดารอุทกวิทยาสองแคว」ขึ้นทะเบียนหอคัมภีร์',
          match: n => E(n, 'values.knowledgeCraft') >= 55 || ['scripture', 'master', 'deputy'].includes(n.post),
          consequenceTh: 'บันทึกหลักฐานขีดวัดระดับน้ำยุคเหยียนหลิงเข้าหอจดหมายเหตุสำนัก เพิ่มความเข้าใจคัมภีร์และบารมีทางวิชาการ',
          effect: { routeBonusLeg: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE'], routeMultiplier: 0.90, sectFameDelta: 6, skillPractice: 'SCRIPTURE' }
        },
        {
          id: 'FERRYMAN_MARKER_REPAIR',
          labelTh: 'ตอกหมุดเตือนระดับน้ำร่วมกับสมาคมคนแจวเรือซวงเจียง',
          match: () => true,
          consequenceTh: 'ซ่อมแซมหลักวัดระดับน้ำริมตลิ่งร่วมกับชาวเรือซวงเจียง เพิ่มความรุ่งเรืองและความปลอดภัยของท่าเรือ',
          effect: { routeBonusLeg: ['CITY_YH_SHUANGJIANG', 'PASS_YH_SANJIANG_BRIDGE'], routeMultiplier: 0.88, cityProsperityDelta: 5, citySafetyDelta: 3 }
        }
      ]
    },
    {
      id: 'STORY_02_BAILU_DUAL_ANNOTATED_MANUAL',
      titleTh: 'คัมภีร์สองลายมือแห่งสำนักศึกษาไป๋ลู่',
      group: 'CODEX_ADOPTED',
      category: 'MARTIAL_SCHISM',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_02_BAILU_DUAL_COMMENTARY',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_BAILU_ACADEMY', 'CITY_YH_OLD_DAREN_SQUARE'],
      summaryTh: 'คัมภีร์ฝึกปราณเล่มเดียวกันมีรอยจดหมายเหตุริมกระดาษสองสี (หมึกชาดเร่งรัดปราณ กับ หมึกดำประคองชีพจร) ที่โต้เถียงกันเองทุกบท',
      stages: [
        {
          idx: 0,
          id: 'SPARK_MARGIN_DISPUTE',
          titleTh: 'พบรอยอรรถาธิบายหมึกชาดและหมึกดำโต้เถียงกันในคัมภีร์',
          locationId: 'CITY_YH_BAILU_ACADEMY',
          accountId: 'SECT_ORTHODOX',
          descTh: 'ศิษย์ที่อ่านคัมภีร์จากสายสำนักศึกษาไป๋ลู่พบคำสอนสองแนวทางที่ขัดแย้งกันในหน้าเดียว'
        },
        {
          idx: 1,
          id: 'COMPARE_HANDWRITING_AND_BREATH',
          titleTh: 'เทียบน้ำหนักพู่กันและทดลองเดินปราณตามจังหวะทั้งสอง',
          locationId: 'CITY_YH_OLD_DAREN_SQUARE',
          accountId: 'COURT_CANON',
          descTh: 'ตรวจสอบต้นฉบับในหอสมุดไป๋ลู่พบว่าหางอักษรทั้งสองสีมาจากข้อมือคนเดียวกันในต่างช่วงวัย'
        },
        {
          idx: 2,
          id: 'SYNTHESIZE_DUAL_ANNOTATION',
          titleTh: 'ตัดสินใจแนวทางถ่ายทอดคัมภีร์สองลายมือในสำนัก',
          locationId: 'CITY_YH_BAILU_ACADEMY',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เลือกวิธีใช้ประโยชน์จากอรรถาธิบายหมึกชาดและหมึกดำตามจริตของผู้เรียน'
        }
      ],
      resolutions: [
        {
          id: 'HARMONIZED_COMMENTARY_EDITION',
          labelTh: 'จัดทำฉบับประสาน「รุกด้วยหมึกชาด คุมด้วยหมึกดำ」ไว้ในหอคัมภีร์',
          match: n => E(n, 'aptitudes.comprehension') >= 55 || ['scripture', 'master', 'deputy'].includes(n.post),
          consequenceTh: 'หอคัมภีร์สำนักได้อรรถาธิบายประสานสองวัย ช่วยให้ศิษย์ศึกษาวิชาได้รวดเร็วและปลอดภัยขึ้น',
          effect: { customId: 'CUSTOM_BAILU_HARMONIZED_STUDY', studySpeedMult: 1.08, skillPractice: 'SCRIPTURE', sectFameDelta: 5 }
        },
        {
          id: 'CRIMSON_INK_BREAKTHROUGH_DRILL',
          labelTh: 'ฝึกฝนเคล็ดบีบอัดปราณหมึกชาดเพื่อเร่งความชำนาญกระบวนท่า',
          match: n => E(n, 'personality.ambition') >= 60 || E(n, 'personality.courage') >= 60,
          consequenceTh: 'ศิษย์สายรุกนำเคล็ดหมึกชาดมาใช้ฝึกซ้อมเร่งความก้าวหน้าตบะและทักษะการรบ',
          effect: { customId: 'CUSTOM_BAILU_CRIMSON_DRILL', cultGain: 28, skillPractice: 'SWORD' }
        },
        {
          id: 'BLACK_INK_FOUNDATION_ORTHODOXY',
          labelTh: 'ยึดแนวทางหมึกดำเป็นมาตรฐานสอนศิษย์ใหม่เพื่อป้องกันลมปราณตีกลับ',
          match: () => true,
          consequenceTh: 'วางรากฐานการเดินปราณตามแนวหมึกดำ ลดความตึงเครียดและจิตมารของศิษย์ในสำนัก',
          effect: { customId: 'CUSTOM_BAILU_BLACK_FOUNDATION', heartDemonDelta: -10, skillPractice: 'SCRIPTURE' }
        }
      ]
    },
    {
      id: 'STORY_03_QINGLAN_SECOND_TOLL_STAMP',
      titleTh: 'ตราประทับด่านภาษีซ้อนแห่งราชวงศ์ชิงหลานที่ล่มสลาย',
      group: 'CODEX_ADOPTED',
      category: 'DYNASTY_TRADE',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_03_QINGLAN_DOUBLE_TOLL_SEAL',
      polityId: 'POL_DONGHUANG',
      anchorNodeIds: ['CITY_DH_QINGLAN_DICE_CITY', 'CITY_DH_ZHENYANG_RUIN_PREF'],
      summaryTh: 'หีบสินค้าจากแดนตะวันออกมีตราครั่งทองเหลืองรูปคลื่นคู่ของราชวงศ์ชิงหลานที่ล่มสลายไปเมื่อเก้าสิบปีก่อนประทับซ้อนอยู่ใต้ตราลูกคิดทองคำตงหวง',
      stages: [
        {
          idx: 0,
          id: 'SPARK_DOUBLE_SEAL_CRATE',
          titleTh: 'ตรวจพบตราครั่งรูปคลื่นคู่โบราณประทับซ้อนบนหีบสินค้า',
          locationId: 'CITY_DH_QINGLAN_DICE_CITY',
          accountId: 'FOLK_ORAL',
          descTh: 'คนคุมคาราวานพบตราภาษีสองยุคซ้อนกันบนลังพัสดุจากเมืองสายน้ำครามชิงหลาน'
        },
        {
          idx: 1,
          id: 'INQUIRE_ZHENYANG_CUSTOMS_BROKER',
          titleTh: 'สอบทานสมุดเทียบตราภาษีเก่าที่เมืองป้อมเจิ้นหยางเก่า',
          locationId: 'CITY_DH_ZHENYANG_RUIN_PREF',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่านายหน้าตระกูลเก่าใช้ตราชิงหลานเป็นตั๋วรับรองสิทธิ์เบิกพัสดุคงค้างในคลังใต้ดินยุคเปลี่ยนผ่าน'
        },
        {
          idx: 2,
          id: 'SETTLE_QINGLAN_TALLY',
          titleTh: 'จัดการสิทธิ์เบิกพัสดุคลังเก่าและรายงานศุลกากรตงหวง',
          locationId: 'CITY_DH_QINGLAN_DICE_CITY',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เลือกวิธีดำเนินการกับตั๋วตราคลื่นคู่ระหว่างการเบิกพัสดุคงค้างหรือการสร้างไมตรีทางการทูต'
        }
      ],
      resolutions: [
        {
          id: 'REDEEM_QINGLAN_CELLAR_SHIPMENT',
          labelTh: 'ใช้ตั๋วตราคลื่นคู่เบิกพัสดุและศิลาวิญญาณคงค้างจากนายหน้าชิงหลาน',
          match: n => E(n, 'values.wealthResource') >= 52 || ['treasury', 'marketmaster', 'quartermaster'].includes(n.post),
          consequenceTh: 'เบิกศิลาวิญญาณและวัตถุดิบที่เก็บรักษาไว้ในคลังใต้ดินเมืองชิงหลานเข้าสู่คลังสำนักอย่างถูกต้องตามธรรมเนียมนายหน้า',
          effect: { closedLoopStonesFromPool: 120, cityProsperityDelta: 4 }
        },
        {
          id: 'REPORT_CUSTOMS_RECONCILIATION',
          labelTh: 'ส่งมอบสำเนาสมุดเทียบตราให้ด่านศุลกากรตงหวงเพื่อปลดข้อหาค้าของเถื่อน',
          match: n => E(n, 'personality.integrity') >= 58 || ['envoy', 'discipline', 'master'].includes(n.post),
          consequenceTh: 'ด่านตรวจการตงหวงยกเลิกหมายอายัดขบวนสินค้าของพ่อค้าชิงหลาน เพิ่มความเชื่อถือทางการทูตและความปลอดภัยของเมือง',
          effect: { citySafetyDelta: 6, cityProsperityDelta: 3, sectFameDelta: 6 }
        },
        {
          id: 'ARCHIVE_FALLEN_REALM_SEAL',
          labelTh: 'เก็บรักษาแม่พิมพ์ตราคลื่นคู่ไว้ในหอจดหมายเหตุราชวงศ์ที่ล่มสลาย',
          match: () => true,
          consequenceTh: 'บันทึกประวัติการเปลี่ยนผ่านแคว้นชิงหลาน–ตงหวงไว้เป็นตำราการค้าและประวัติศาสตร์ของสำนัก',
          effect: { sectFameDelta: 5, skillPractice: 'SCRIPTURE' }
        }
      ]
    },
    {
      id: 'STORY_04_YUGUAN_TWO_VILLAGE_BOUNDARY',
      titleTh: 'หลักศิลาสองชื่อแห่งด่านหยกเก่าอวี้กวาน',
      group: 'CODEX_ADOPTED',
      category: 'GEOGRAPHY_COMMUNITY',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_04_YUGUAN_REFUGEE_BOUNDARY',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['PASS_YH_YUGUAN_RUIN_POST', 'TOWN_YH_LIUWAN_FERRY'],
      summaryTh: 'สองหมู่บ้านผู้ลี้ภัยเก่าเรียกสันเขาเดียวกันคนละชื่อตามบันทึกต้นตระกูลยุคหงชี (#38) ขณะที่เสมียนด่านอ้างแผนที่ภาษีใหม่เข้ายึดบ่อน้ำ',
      stages: [
        {
          idx: 0,
          id: 'SPARK_RIDGE_NAME_QUARREL',
          titleTh: 'พบข้อพิพาทเรียกชื่อสันเขาและสิทธิ์ดูแลบ่อน้ำที่ด่านหยกเก่าอวี้กวาน',
          locationId: 'PASS_YH_YUGUAN_RUIN_POST',
          accountId: 'FOLK_ORAL',
          descTh: 'ชาวบ้านสองฝั่งเขาโต้เถียงกันเรื่องชื่อดั้งเดิมของสันเขาและสิทธิ์การใช้น้ำซับริมทาง'
        },
        {
          idx: 1,
          id: 'EXCAVATE_COURIER_MILESTONE_BASE',
          titleTh: 'ขุดแต่งฐานหลักศิลาม้าเร็วและเทียบสมุดอพยพที่ท่าข้ามฟากคุ้งหลิวเขียว',
          locationId: 'TOWN_YH_LIUWAN_FERRY',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบฐานหินยุคหงชี (#38) ที่สลักชื่อทั้งสองหมู่บ้านไว้คนละด้านของหลักศิลาเดียวกัน'
        },
        {
          idx: 2,
          id: 'RESTORE_DUAL_BOUNDARY_MARKER',
          titleTh: 'ไกล่เกลี่ยข้อพิพาทและตั้งหลักศิลาสองชื่อขึ้นใหม่',
          locationId: 'PASS_YH_YUGUAN_RUIN_POST',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'ตัดสินใจวิธีจัดการหลักศิลาและระเบียบดูแลบ่อน้ำริมด่านอวี้กวาน'
        }
      ],
      resolutions: [
        {
          id: 'ERECT_TWIN_NAME_STELE',
          labelTh: 'ยกหลักศิลาสองชื่อขึ้นตั้งใหม่และให้สองหมู่บ้านผลัดเวรดูแลบ่อน้ำตามคำสัตย์หงชี (#38)',
          match: n => E(n, 'personality.empathy') >= 50 || E(n, 'personality.integrity') >= 55,
          consequenceTh: 'สองหมู่บ้านยุติความบาดหมางและร่วมกันดูแลบ่อน้ำและคบเพลิงนำทางที่ด่านอวี้กวาน',
          effect: { citySafetyDelta: 7, cityProsperityDelta: 4, sectFameDelta: 6 }
        },
        {
          id: 'REGISTER_YUNHE_COURIER_WAYSTATION',
          labelTh: 'ขึ้นทะเบียนหลักศิลาเป็นสถานีพักม้าเร็วร่วมกับสภาหยุนเหอ',
          match: n => ['envoy', 'mission', 'quartermaster'].includes(n.post) || E(n, 'aptitudes.socialCommerce') >= 55,
          consequenceTh: 'ด่านอวี้กวานและท่าข้ามฟากคุ้งหลิวเขียวกลายเป็นจุดพักคาราวานที่ปลอดภัยและรวดเร็วขึ้น',
          effect: { routeBonusLeg: ['PASS_YH_YUGUAN_RUIN_POST', 'CITY_YH_OLD_DAREN_SQUARE'], routeMultiplier: 0.88, cityProsperityDelta: 5 }
        },
        {
          id: 'RUBBING_FOR_SECT_STELE_HALL',
          labelTh: 'คัดลอกลายสลักพลองหยกของหงชี (#38) กลับมาศึกษาที่หอคัมภีร์',
          match: () => true,
          consequenceTh: 'ได้ภาพลอกลายจารึกโบราณของราชันย์พเนจรหงชี (#38) กลับมาเพิ่มพูนความรู้ในสำนัก',
          effect: { citySafetyDelta: 4, skillPractice: 'STAFF' }
        }
      ]
    },
    {
      id: 'STORY_05_BEAST_KEEPER_FORD_NOTEBOOK',
      titleTh: 'สมุดบันทึกคนเลี้ยงอสูรริมแก่งน้ำตื้น',
      group: 'CODEX_ADOPTED',
      category: 'ECOLOGY_BEAST',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_05_FORD_BEAST_MOLTING_CYCLE',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['TOWN_BM_BINGHE_FUR_POST', 'TOWN_GJ_YaoZhai_HUNT'],
      summaryTh: 'สมุดบันทึกหนังสัตว์ของคนเลี้ยงอสูรเฒ่าอธิบายพฤติกรรมรวมฝูงลอกคราบริมแก่งน้ำตื้น ซึ่งสวนทางกับข่าวลือเรื่องอสูรคลั่ง',
      stages: [
        {
          idx: 0,
          id: 'SPARK_FORD_BEAST_SCARE',
          titleTh: 'รับทราบข่าวลืออสูรริมน้ำรวมฝูงขวางแก่งน้ำตื้น',
          locationId: 'TOWN_BM_BINGHE_FUR_POST',
          accountId: 'FOLK_ORAL',
          descTh: 'พรานและคนเดินทางร่ำลือว่ามีฝูงอสูรดุร้ายยึดแก่งน้ำตื้นจนไม่มีใครกล้าข้าม'
        },
        {
          idx: 1,
          id: 'READ_KEEPER_FIELD_NOTES',
          titleTh: 'ค้นพบสมุดบันทึกคนเลี้ยงอสูรและตรวจร่องรอยคราบเกล็ดริมตลิ่ง',
          locationId: 'TOWN_GJ_YaoZhai_HUNT',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่าฝูงอสูรเพียงขึ้นมาถูหินลอกคราบตามฤดูกาลและจะดุร้ายเฉพาะเมื่อมีคนเหยียบรังริมน้ำ'
        },
        {
          idx: 2,
          id: 'CHOOSE_FORD_ECOLOGY_POLICY',
          titleTh: 'ตัดสินใจแนวทางปฏิบัติต่อฝูงอสูรช่วงลอกคราบริมแก่ง',
          locationId: 'TOWN_BM_BINGHE_FUR_POST',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เลือกแนวทางจัดการแก่งน้ำตื้นตามหน้าที่และปณิธานของศิษย์ผู้รับผิดชอบ'
        }
      ],
      resolutions: [
        {
          id: 'KEEPER_CONSERVATION_SALT_MARK',
          labelTh: 'ปักหลักหินเกลือแร่ล่อฝูงอสูรให้อยู่ห่างทางข้ามและอนุรักษ์รัง',
          match: n => ['beastmaster', 'healer'].includes(n.post) || E(n, 'personality.empathy') >= 58 || ['BEAST_SOVEREIGN', 'SPIRIT_HUSBANDRY'].includes(n.cult?.path),
          consequenceTh: 'ฝูงอสูรย้ายไปลอกคราบที่คุ้งน้ำสงบหลังหลักเกลือแร่ ทางข้ามปลอดภัยและสัตว์คู่หูในสำนักมีความผูกพันเพิ่มขึ้น',
          effect: { customId: 'CUSTOM_KEEPER_FORD_SANCTUARY', citySafetyDelta: 6, petBondBonus: 8 }
        },
        {
          id: 'ALCHEMIST_MOLTED_SCALE_HARVEST',
          labelTh: 'จัดเวรเก็บคราบเกล็ดที่ลอกทิ้งริมหินมาปรุงโอสถโดยไม่รบกวนฝูงอสูร',
          match: n => ['alchemy', 'herbal'].includes(n.post) || E(n, 'interests.alchemy') >= 55,
          consequenceTh: 'หอโอสถได้คราบเกล็ดอสูรที่สมบูรณ์มาใช้เป็นวัตถุดิบโดยไม่ต้องเสี่ยงปะทะกับฝูงอสูร',
          effect: { customId: 'CUSTOM_MOLTED_SCALE_HARVEST', skillPractice: 'ALCHEMY', cityProsperityDelta: 4 }
        },
        {
          id: 'CAUTIOUS_FORD_DETOUR_POSTS',
          labelTh: 'ปักป้ายเตือนช่วงเวลาลอกคราบ 6 วันให้คาราวานใช้ทางเลี่ยงเนินสูง',
          match: () => true,
          consequenceTh: 'คนเดินทางและคาราวานเลี่ยงตลิ่งในช่วง 6 วันลอกคราบ ลดการสูญเสียบนเส้นทางแดนเหนือและแดนทักษิณ',
          effect: { citySafetyDelta: 5, skillPractice: 'BEAST_TAMING' }
        }
      ]
    },
    {
      id: 'STORY_06_STOREROOM_FLOORBOARD_SHRINE',
      titleTh: 'หิ้งบูชาช่างหลอมใต้พื้นไม้ห้องเก็บของเก่า',
      group: 'CODEX_ADOPTED',
      category: 'CRAFT_TRADITION',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_06_STOREROOM_ANVIL_TALISMAN',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['TOWN_YH_TIEKUANG_HOLLOW', 'CITY_CY_RONGLU_CAPITAL'],
      summaryTh: 'ใต้แผ่นไม้พื้นห้องเก็บของเก่าในสำนักมีทั่งเหล็กจิ๋วและป้ายชื่อช่างหลอมซ่อนอยู่ เมื่อเทียบกับตราเหล็กที่ตำบลเตาเหล็กซากสำริดจึงพบตำรับชุบขี้เถ้าถนอมเกราะ',
      stages: [
        {
          idx: 0,
          id: 'SPARK_FLOORBOARD_DISCOVERY',
          titleTh: 'พบทั่งเหล็กจิ๋วและแผ่นไม้สลักตราช่างใต้พื้นห้องเก็บของเก่า',
          locationId: 'TOWN_YH_TIEKUANG_HOLLOW',
          accountId: 'FOLK_ORAL',
          descTh: 'ระหว่างจัดระเบียบห้องเก็บของในสำนัก ศิษย์พบหิ้งเหล็กขนาดเล็กซ่อนอยู่ใต้คานไม้พร้อมห่อขี้เถ้าสน'
        },
        {
          idx: 1,
          id: 'TRACE_MAKER_MARK_AT_TIEKUANG',
          titleTh: 'นำตราช่างไปเทียบกับสมุดตระกูลช่างที่ตำบลเตาเหล็กซากสำริด',
          locationId: 'TOWN_YH_TIEKUANG_HOLLOW',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่าเป็นตราของหัวหน้าช่างหลอมสมัยเจ้าสำนักรุ่นที่ 4 ผู้คิดค้นวิธีชุบผิวชุดเกราะด้วยขี้เถ้าสมุนไพร'
        },
        {
          idx: 2,
          id: 'RESTORE_ASH_TEMPER_METHOD',
          titleTh: 'ฟื้นฟูตำรับชุบขี้เถ้าถนอมเกราะและบูรณะหิ้งรำลึกช่างหลอม',
          locationId: 'CITY_CY_RONGLU_CAPITAL',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'นำวิธีชุบขี้เถ้าถนอมเกราะกลับมาใช้ในโรงหลอมสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'ADOPT_ASH_WARD_ARMOR_MAINTENANCE',
          labelTh: 'บรรจุ「ตำรับชุบขี้เถ้าสนถนอมเกราะ」เป็นขั้นตอนมาตรฐานของโรงหลอมสำนัก',
          match: n => ['forge', 'arraymaster', 'quartermaster'].includes(n.post) || E(n, 'aptitudes.crafting') >= 52,
          consequenceTh: 'โรงหลอมสำนักนำวิธีชุบขี้เถ้าสนมาเคลือบชุดเกราะพื้นฐาน ช่วยเพิ่มความทนทานและพลังป้องกันให้ศิษย์ทั้งสำนัก',
          effect: { customId: 'CUSTOM_STOREROOM_ASH_TEMPER', skillPractice: 'FORGING', cityProsperityDelta: 4 }
        },
        {
          id: 'SHRINE_HONOR_ARTISAN_LINEAGE',
          labelTh: 'ตั้งหิ้งรำลึกบูรพาจารย์ช่างหลอมไว้ข้างเตาหลอมหลักเพื่อสร้างขวัญกำลังใจฝ่ายผลิต',
          match: () => true,
          consequenceTh: 'ศิษย์สายช่างรู้สึกได้รับเกียรติและสืบทอดความประณีตในการดูแลรักษาอุปกรณ์ของสำนัก',
          effect: { customId: 'CUSTOM_ARTISAN_SHRINE_HONOR', sectFameDelta: 5, skillPractice: 'FORGING' }
        }
      ]
    },
    {
      id: 'STORY_07_SEVENTH_GEN_EMPTY_CHAIR',
      titleTh: 'เก้าอี้ว่างและกระบี่ไม้ท้อในโถงบรรพชนรุ่นที่เจ็ด',
      group: 'CODEX_ADOPTED',
      category: 'SECT_LINEAGE',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_07_GEN7_WOODEN_SWORD_AND_EMPTY_CHAIR',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['CITY_YH_OLD_DAREN_SQUARE', 'TOWN_YH_QINGXI_FOOT'],
      summaryTh: 'คลี่คลายข่าวลือเรื่องกระบี่ไม้ท้อและเก้าอี้ว่างในโถงบรรพชน โดยเชื่อมโยงบันทึกเจ้าสำนักรุ่นที่ 5–6 เข้ากับตราหินเทาไร้ลักษณ์ของเจ้าสำนักรุ่นที่ 7',
      stages: [
        {
          idx: 0,
          id: 'SPARK_EMPTY_CHAIR_RUMOR',
          titleTh: 'ศิษย์รุ่นใหม่ตั้งคำถามเรื่องเก้าอี้ว่างและกระบี่ไม้ท้อข้างแท่นบรรพชน',
          locationId: 'TOWN_YH_QINGXI_FOOT',
          accountId: 'FOLK_ORAL',
          descTh: 'เกิดคำร่ำลือในหมู่ศิษย์ว่าเหตุใดข้างแท่นป้ายบรรพชนรุ่นที่ 6 จึงมีเก้าอี้ว่างและกระบี่ไม้ท้อไร้คมแขวนอยู่'
        },
        {
          idx: 1,
          id: 'INSPECT_GEN5_GEN6_ARCHIVE_NOTES',
          titleTh: 'ค้นคว้าสมุดบันทึกของเจ้าสำนักรุ่นที่ 5 กู้เหยียนจือ และรุ่นที่ 6 โม่ชางไห่',
          locationId: 'CITY_YH_OLD_DAREN_SQUARE',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบบันทึกว่าตราประจำตำแหน่งแท้จริงคือตราหินเทาไร้ลักษณ์ ส่วนเก้าอี้ว่างและกระบี่ไม้ท้อเป็นอนุสรณ์ถึงศิษย์พี่ผู้สละชีพเฝ้าด่านหน้า'
        },
        {
          idx: 2,
          id: 'AFFIRM_GEN7_STEWARDSHIP_RITE',
          titleTh: 'ประกอบพิธีรำลึกผู้พิทักษ์ด่านและยืนยันธรรมเนียมผู้สืบทอดรุ่นที่ 7',
          locationId: 'CITY_YH_OLD_DAREN_SQUARE',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เจ้าสำนักและผู้อาวุโสประกาศความหมายที่แท้จริงของเก้าอี้ว่างและตราหินเทาไร้ลักษณ์ต่อศิษย์ทั้งสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'REGALIA_DAO_INSIGHT_RESONANCE',
          labelTh: 'อัญเชิญตราหินเทาไร้ลักษณ์ขึ้นรับกระแสปณิธานบูรพาจารย์ทั้ง 6 รุ่น',
          match: (n, W) => W && W.sect && (n.id === W.sect.masterId || n.post === 'disciples'),
          consequenceTh: 'ตราหินเทาไร้ลักษณ์สั่นพ้องกับปณิธานบูรพาจารย์รุ่นที่ 1–6 เพิ่มแต้มตื่นรู้ DAO_INSIGHT และเสียงสะท้อนต้นกำเนิดของสำนัก',
          effect: { regaliaVector: 'DAO_INSIGHT', regaliaAmount: 1, originEchoesDelta: 2, sectFameDelta: 8 }
        },
        {
          id: 'GUARDIAN_CHAIR_MEMORIAL_ETCHING',
          labelTh: 'สลักนามศิษย์พี่ผู้พิทักษ์ด่านไว้ที่พนักเก้าอี้ว่างและใช้กระบี่ไม้ท้อสอนวิชาพื้นฐานแก่ศิษย์ใหม่',
          match: () => true,
          consequenceTh: 'ศิษย์ทั้งสำนักเข้าใจรากเหง้าความเสียสละของรุ่นที่ 6 เพิ่มความภักดีและขวัญกำลังใจในการปกป้องสำนัก',
          effect: { originEchoesDelta: 1, sectFameDelta: 6, skillPractice: 'SWORD' }
        }
      ]
    },
    {
      id: 'STORY_08_MISSING_BEND_TRAIL_SKETCH',
      titleTh: 'ภาพร่างแผนที่รอยพับขาดของสมรภูมิเทียนกู่',
      group: 'CODEX_ADOPTED',
      category: 'GEOGRAPHY_RUIN',
      layer: 'SHATTERED_SUBCONTINENT',
      factId: 'FACT_08_TIANGU_MISSING_RIVER_BEND',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['PASS_BM_HANLONG_GATE', 'CITY_BM_XINGYUN_CITADEL', 'TOWN_BM_BAIMEI_OLD_FORT'],
      summaryTh: 'ภาพร่างถ่านไม้แสดงจุดสังเกตสองแห่งของสมรภูมิเทียนกู่แต่ตรงกลางขาดหายไปตามรอยพับ ต้องคำนวณร่องน้ำโบราณที่เปลี่ยนทิศหลังประตูมิติระเบิด',
      stages: [
        {
          idx: 0,
          id: 'SPARK_CREASED_CHARCOAL_MAP',
          titleTh: 'ได้ภาพร่างแผนที่ถ่านไม้ที่รอยพับตรงคุ้งน้ำขาดหายไป',
          locationId: 'PASS_BM_HANLONG_GATE',
          accountId: 'FOLK_ORAL',
          descTh: 'พบแผ่นหนังแกะวาดแนวปราการของหลี่เจี้ยนซิน (#6) และเนินธนูของเย่ชิงชาง (#8) แต่ส่วนเชื่อมตรงกลางฉีกขาด'
        },
        {
          idx: 1,
          id: 'CALCULATE_OLD_RIVERBED_AT_XINGYUN',
          titleTh: 'เทียบแผนที่ดาวเมืองซิงหยวนเพื่อหาแนวร่องน้ำแห้งก่อนแผ่นดินทรุด',
          locationId: 'CITY_BM_XINGYUN_CITADEL',
          accountId: 'SECT_ORTHODOX',
          descTh: 'คำนวณพบว่าแม่น้ำโบราณเบี่ยงทิศไปทางเมืองเก่ากระบี่เหมยขาวหลังจากแรงระเบิดประตูมิติหลวง'
        },
        {
          idx: 2,
          id: 'SURVEY_BAIMEI_BATTLE_RIDGE',
          titleTh: 'ลงพื้นที่สำรวจร่องน้ำแห้งหลังเมืองเก่ากระบี่เหมยขาว',
          locationId: 'TOWN_BM_BAIMEI_OLD_FORT',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'ตรวจสอบหลักศิลาสมรภูมิเทียนกู่และบันทึกผลลัพธ์ตามสภาพจริงของโบราณสถาน'
        }
      ],
      resolutions: [
        {
          id: 'INSCRIBE_LI_JIANXIN_DEFENSE_FORMATION',
          labelTh: 'ลอกลายจารึกค่ายกลตั้งรับ 7 วัน 7 คืนของหลี่เจี้ยนซิน (#6) บนผาหิน',
          match: n => E(n, 'values.martialPeak') >= 55 || ['martial', 'commander', 'vanguard'].includes(n.post),
          consequenceTh: 'แม้ศาสตราเอกในตำนานจะมีผู้ถือครองตามกฎหนึ่งเดียวในโลกแล้ว แต่คณะสำรวจได้จารึกกระบวนท่าตั้งรับหน้าประตูเมืองเทียนกู่กลับมาเสริมทักษะการรบของสำนักอย่างสมบูรณ์',
          effect: { routeBonusLeg: ['PASS_BM_HANLONG_GATE', 'TOWN_BM_BAIMEI_OLD_FORT'], routeMultiplier: 0.88, skillPractice: 'SWORD', sectFameDelta: 8 }
        },
        {
          id: 'RECOVER_METEOR_ARROW_SLAG',
          labelTh: 'เก็บกู้เศษหัวธนูเหล็กไหลของทัพเย่ชิงชาง (#8) จากชั้นดินร่องน้ำแห้ง',
          match: () => true,
          consequenceTh: 'เก็บกู้เศษโลหะสมรภูมิโบราณและบันทึกพิกัดร่องน้ำเทียนกู่ลงในแผนที่สำนักอย่างแม่นยำ',
          effect: { closedLoopStonesFromPool: 90, skillPractice: 'FORGING', citySafetyDelta: 4 }
        }
      ]
    },
    {
      id: 'STORY_09_ONE_SALT_LINE_TWO_PORTS',
      titleTh: 'สายเกลือหนึ่งเส้น สองท่าเรือพิพาท',
      group: 'CODEX_ADOPTED',
      category: 'GEOGRAPHY_TRADE',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_09_HAIMEN_NANZHU_SALT_CURRENT',
      polityId: 'POL_DONGHUANG',
      anchorNodeIds: ['CITY_DH_HAIMEN_PORT', 'CITY_SO_NANZHU_PEARL_ISLE', 'CITY_SO_LONGWAN_SHIPYARD'],
      summaryTh: 'ท่าเรือไห่เหมินและเกาะไข่มุกหนานจูต่างกล่าวหาอีกฝ่ายว่ากักตุนเกลือทะเล แต่บันทึกน้ำขึ้นน้ำลงของอู่ต่อเรือหลงวานชี้ว่าเกิดจากสันดอนทรายหนุนช่วงมรสุมเปลี่ยนทิศ',
      stages: [
        {
          idx: 0,
          id: 'SPARK_SALT_SHORTAGE_BLAME',
          titleTh: 'รับรู้ข้อพิพาทเรื่องเกลือขาดแคลนระหว่างท่าเรือไห่เหมินกับเกาะหนานจู',
          locationId: 'CITY_DH_HAIMEN_PORT',
          accountId: 'FOLK_ORAL',
          descTh: 'พ่อค้าเกลือสองท่าเรือต่างโทษกันไปมาจนราคาเสบียงริมฝั่งผันผวน'
        },
        {
          idx: 1,
          id: 'CHECK_LONGWAN_TIDE_AND_DRAFT_LOGS',
          titleTh: 'ตรวจสอบสมุดกินน้ำลึกของเรือบรรทุกเกลือที่อู่ต่อเรืออ่าวหลงวาน',
          locationId: 'CITY_SO_LONGWAN_SHIPYARD',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่าเรือเกลือท้องแบนติดสันดอนปากอ่าวไห่เหมินเฉพาะช่วงมรสุมเปลี่ยนทิศ 12 วัน'
        },
        {
          idx: 2,
          id: 'ESTABLISH_MONSOON_SALT_RELAY',
          titleTh: 'วางระบบขนถ่ายเกลือผ่านอ่าวหลงวานและสำรองเสบียงก่อนมรสุม',
          locationId: 'CITY_SO_NANZHU_PEARL_ISLE',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'คลี่คลายความเข้าใจผิดของสองท่าเรือและปรับแผนเสบียงของสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'QUARTERMASTER_PRE_MONSOON_STOCK',
          labelTh: 'จัดซื้อและสำรองเกลือถนอมเสบียงเข้าโรงครัวสำนักก่อนช่วงมรสุมเปลี่ยนทิศ',
          match: n => ['provision', 'quartermaster', 'treasury'].includes(n.post) || E(n, 'personality.caution') >= 55,
          consequenceTh: 'ฝ่ายเสบียงสำรองเกลือและอาหารแห้งล่วงหน้า พร้อมเปิดทางขนถ่ายผ่านอ่าวหลงวาน ทำให้ทั้งสองท่าเรือรุ่งเรืองขึ้น',
          effect: { routeBonusLeg: ['CITY_DH_HAIMEN_PORT', 'CITY_SO_LONGWAN_SHIPYARD'], routeMultiplier: 0.87, cityProsperityDelta: 6, mealGrant: 6 }
        },
        {
          id: 'ARBITRATE_TWO_PORT_FERRY_PACT',
          labelTh: 'เป็นคนกลางจัดตารางเรือลำเลียงน้ำตื้นระหว่างไห่เหมิน–หลงวาน–หนานจู',
          match: () => true,
          consequenceTh: 'นายท่าทั้งสองฝั่งยอมรับตารางเดินเรือตามร่องน้ำมรสุม ลดความตึงเครียดชายฝั่งทักษิณ–บูรพา',
          effect: { routeBonusLeg: ['CITY_SO_LONGWAN_SHIPYARD', 'CITY_SO_NANZHU_PEARL_ISLE'], routeMultiplier: 0.88, citySafetyDelta: 5, cityProsperityDelta: 5 }
        }
      ]
    },
    {
      id: 'STORY_10_DAMAGED_MEMORIAL_RESTORED_NAME',
      titleTh: 'ชื่อที่เลือนหายบนศิลาอนุสรณ์ริมทาง',
      group: 'CODEX_ADOPTED',
      category: 'FOLK_MEMORIAL',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_10_ROADSIDE_PHYSICIAN_STELE',
      polityId: 'POL_SUVARNABODHI',
      anchorNodeIds: ['TOWN_SB_CIHANG_ALMS', 'CITY_SB_JINYA_SANGHA', 'TOWN_GJ_BAICAO_STILT'],
      summaryTh: 'ศิลาอนุสรณ์แตกหักริมทางถูกชาวบ้านเข้าใจผิดว่าเป็นหลุมศพเซียนกระบี่ แต่เมื่อลอกตะไคร่และค้นทะเบียนโรงทานฉือหางกลับพบว่าเป็นอนุสรณ์ของหมอยาเดินเท้าผู้สละชีพ',
      stages: [
        {
          idx: 0,
          id: 'SPARK_MISATTRIBUTED_SWORD_SHRINE',
          titleTh: 'พบศิลาอนุสรณ์ริมทางที่ถูกเซ่นไหว้ในฐานะศาลเซียนกระบี่นิรนาม',
          locationId: 'TOWN_SB_CIHANG_ALMS',
          accountId: 'FOLK_ORAL',
          descTh: 'นักเดินทางพากันวางจอกสุราหน้าหินแตกที่มีรอยบากลึกโดยเชื่อว่าเป็นรอยกระบี่โบราณ'
        },
        {
          idx: 1,
          id: 'RUB_MOSS_GROOVES_AND_CHECK_ALMS_ROLL',
          titleTh: 'ลอกคราบตะไคร่อ่านอักษรย่อสมุนไพรและค้นสมุดโรงทานฉือหาง',
          locationId: 'CITY_SB_JINYA_SANGHA',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบชื่อหมอยาสามัญชน「เว่ยชิง」และสูตรยาต้มแก้ไข้หมอกที่สลักอยู่โคนแผ่นหิน'
        },
        {
          idx: 2,
          id: 'RESTORE_PHYSICIAN_MEMORIAL_NAME',
          titleTh: 'สลักชื่อหมอยาเว่ยชิงคืนสู่ศิลาและฟื้นฟูตำรับยาต้มริมทาง',
          locationId: 'TOWN_SB_CIHANG_ALMS',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'คืนเกียรติยศที่แท้จริงให้ผู้วายชนม์และนำความรู้ทางการแพทย์กลับมาใช้'
        }
      ],
      resolutions: [
        {
          id: 'HEALER_ADOPT_WEIQING_DECOCTION',
          labelTh: 'บูรณะป้ายชื่อหมอยาเว่ยชิงและนำตำรับน้ำต้มสมุนไพรไปใช้ในสถานรักษาสำนัก',
          match: n => ['healer', 'alchemy', 'herbal'].includes(n.post) || E(n, 'personality.empathy') >= 55,
          consequenceTh: 'หอโอสถและสถานรักษาได้แนวทางต้มยาสมุนไพรพื้นฐานช่วยฟื้นฟูอาการบาดเจ็บและความเหนื่อยล้าของศิษย์',
          effect: { customId: 'CUSTOM_WEIQING_HERBAL_BROTH', skillPractice: 'MEDICINE', citySafetyDelta: 5, sectFameDelta: 6 }
        },
        {
          id: 'WAYSIDE_HERB_TEA_PAVILION',
          labelTh: 'ตั้งซุ้มหม้อน้ำชาสมุนไพรข้างศิลาอนุสรณ์เพื่อดูแลคนเดินทางตามเจตนารมณ์เดิม',
          match: () => true,
          consequenceTh: 'คนเดินทางแถบโรงทานฉือหางและหมู่บ้านไป๋เฉ่าได้รับน้ำชาสมุนไพรคุ้มกันไข้ป่า สร้างชื่อเสียงด้านเมตตาธรรมแก่สำนัก',
          effect: { cityProsperityDelta: 5, citySafetyDelta: 4, sectFameDelta: 7 }
        }
      ]
    },
    {
      id: 'STORY_11_MEAL_PAID_TWICE',
      titleTh: 'มื้ออาหารที่ถูกจ่ายซ้ำในโรงครัวสำนัก',
      group: 'CODEX_ADOPTED',
      category: 'SLICE_OF_LIFE',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_11_FERRY_TRAVELER_TWICE_PAID_MEAL',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['TOWN_YH_LIUWAN_FERRY', 'TOWN_YH_QINGXI_FOOT'],
      summaryTh: 'เรื่องราวชีวิตประจำวันในโรงครัวสำนัก เมื่อมีผู้วางเบี้ยค่าอาหารซ้ำไว้ใต้หม้อแกงสองครั้ง จนเกิดความเข้าใจผิดระหว่างเวรยามผู้ระแวงกับพ่อครัวผู้ภูมิใจ ก่อนจะพบว่าเป็นธรรมเนียมฝากชามอุ่นของศิษย์จากท่าข้ามฟาก',
      stages: [
        {
          idx: 0,
          id: 'SPARK_EXTRA_TALLY_UNDER_POT',
          titleTh: 'พบเบี้ยค่าอาหารวางซ้ำไว้ใต้หม้อแกงในโรงครัวสำนักเป็นครั้งที่สอง',
          locationId: 'TOWN_YH_QINGXI_FOOT',
          accountId: 'FOLK_ORAL',
          descTh: 'พ่อครัวและเวรยามในโรงครัวถกเถียงกันว่าใครเป็นคนแอบวางเบี้ยค่าอาหารเกินไว้ใต้หม้อแกง'
        },
        {
          idx: 1,
          id: 'WITNESS_DAWN_KITCHEN_EXCHANGE',
          titleTh: 'สังเกตเห็นศิษย์ต่างถิ่นแอบวางเบี้ยไว้ข้างเตาไฟยามเช้ามืด',
          locationId: 'TOWN_YH_LIUWAN_FERRY',
          accountId: 'SECT_ORTHODOX',
          descTh: 'ศิษย์ที่เข้าครัวแต่เช้าพบว่าผู้วางเบี้ยคือศิษย์น้องจากท่าข้ามฟากคุ้งหลิวเขียวที่เคยได้รับน้ำใจจากศิษย์พี่ในวันแรกเข้าสำนัก'
        },
        {
          idx: 2,
          id: 'KEEP_WARM_BOWL_CUSTOM',
          titleTh: 'เข้าใจธรรมเนียม「ฝากชามอุ่นท่าข้ามฟาก」และส่งต่อน้ำใจในโรงครัว',
          locationId: 'TOWN_YH_LIUWAN_FERRY',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'ผู้ที่อยู่ในเหตุการณ์เลือกวิธีรักษาธรรมเนียมน้ำใจเล็กๆ นี้ไว้ในโรงครัวสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'KITCHEN_WARM_BOWL_HOOK',
          labelTh: 'แขวนป้ายไม้「ชามอุ่นฝากสหาย」ไว้หน้าเตาแกงเพื่อให้ศิษย์แบ่งปันมื้ออาหารแก่ผู้กลับจากเดินทางไกล',
          match: n => ['provision', 'steward'].includes(n.post) || E(n, 'personality.empathy') >= 50,
          consequenceTh: 'โรงครัวสำนักมีธรรมเนียมเก็บแกงอุ่นไว้ให้ศิษย์ที่เพิ่งกลับจากการเดินทางไกล ช่วยเพิ่มอารมณ์ดีและลดความโดดเดี่ยว',
          effect: { customId: 'CUSTOM_FERRY_WARM_BOWL', moodDelta: 8, lonelinessDelta: -10, mealGrant: 3 }
        },
        {
          id: 'QUIET_GRATITUDE_BOND',
          labelTh: 'เก็บเรื่องนี้ไว้เป็นความลับที่รู้กันเฉพาะพยานในโรงครัวเพื่อไม่ให้ผู้ฝากเบี้ยเคอะเขิน',
          match: () => true,
          consequenceTh: 'พยานในโรงครัวยิ้มรับธรรมเนียมเงียบๆ นี้และกระชับความสัมพันธ์ฉันพี่น้องร่วมสำนักให้แน่นแฟ้นขึ้น',
          effect: { moodDelta: 6, lonelinessDelta: -8 }
        }
      ]
    },
    {
      id: 'STORY_12_WRONG_RIDGE_BEAST_REPORT',
      titleTh: 'รายงานอสูรปิดทางผิดสันเขา',
      group: 'CODEX_ADOPTED',
      category: 'GEOGRAPHY_RECON',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_12_RED_RIDGE_TWIN_PASS_NAMES',
      polityId: 'POL_XIRONG',
      anchorNodeIds: ['CITY_XR_CHIYAN_CAPITAL', 'PASS_CY_HEIYAN_ASH_PASS', 'PASS_XR_XUEYU_PENAL_GATE'],
      summaryTh: 'รายงานด่วนแจ้งว่าฝูงอสูรและหินถล่มปิดทาง「สันเขาแดง」ซึ่งเป็นชื่อเรียกซ้ำกันของสองเส้นทางบนพรมแดนประจิม ต้องตรวจคราบแร่กำมะถันเพื่อระบุสันเขาที่แท้จริง',
      stages: [
        {
          idx: 0,
          id: 'SPARK_AMBIGUOUS_RED_RIDGE_ALERT',
          titleTh: 'รับแจ้งข่าวด่วนเรื่องหินถล่มและอสูรปิดทาง「สันเขาแดง」โดยไม่ระบุพิกัดชัดเจน',
          locationId: 'PASS_XR_XUEYU_PENAL_GATE',
          accountId: 'FOLK_ORAL',
          descTh: 'ข่าวลือระบุเพียงชื่อเล่นท้องถิ่นว่าสันเขาแดงถูกปิด ทำให้ไม่แน่ชัดว่าเป็นทางไปซีหรงหรือฉื่อเยี่ยน'
        },
        {
          idx: 1,
          id: 'INSPECT_CARAVAN_SULFUR_DUST',
          titleTh: 'ตรวจคราบเขม่ากำมะถันบนล้อเกวียนและสอบทานเส้นทางที่ด่านช่องเถ้าดำ',
          locationId: 'PASS_CY_HEIYAN_ASH_PASS',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบคราบกำมะถันจากหมู่บ้านหลิวหวงบนเกวียนผู้ส่งข่าว ยืนยันว่าเหตุเกิดที่ด่านช่องเถ้าดำเฮยเหยียน'
        },
        {
          idx: 2,
          id: 'UPDATE_ATLAS_RIDGE_WARNING',
          titleTh: 'ปรับปรุงพิกัดเตือนภัยบนแผนที่ยุทธภพและเปิดทางเลี่ยงที่ถูกต้อง',
          locationId: 'CITY_XR_CHIYAN_CAPITAL',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'บันทึกความแตกต่างของสองสันเขาลงในแผนที่เดินทัพและเคลียร์เส้นทางที่ถูกเข้าใจผิด'
        }
      ],
      resolutions: [
        {
          id: 'CLEAR_HEIYAN_ROCKSLIDE_PASS',
          labelTh: 'ส่งหน่วยลาดตระเวนไปเคลียร์หินถล่มที่ด่านช่องเถ้าดำเฮยเหยียนและปักป้ายแยกชื่อสองสันเขา',
          match: n => ['wildwarden', 'vanguard', 'commander', 'mission'].includes(n.post) || E(n, 'personality.courage') >= 55,
          consequenceTh: 'เปิดทางด่านช่องเถ้าดำเฮยเหยียนและแก้ไขความสับสนบนแผนที่ประจิม ทำให้การเดินทางทั้งสายซีหรงและฉื่อเยี่ยนรวดเร็วขึ้น',
          effect: { routeBonusLeg: ['CITY_CY_RONGLU_CAPITAL', 'PASS_CY_HEIYAN_ASH_PASS'], routeMultiplier: 0.86, citySafetyDelta: 6 }
        },
        {
          id: 'VERIFY_XIRONG_HIGHWAY_OPEN',
          labelTh: 'ยืนยันในสมุดแผนที่สำนักว่าทางหลวงสู่นครปราการผาหินแดงซีหรงยังคงเปิดโล่งปลอดภัย',
          match: () => true,
          consequenceTh: 'ขบวนเดินทางสายตะวันตกไม่ต้องเสียเวลาอ้อมทะเลทรายโดยใช่เหตุ และแผนที่สำนักระบุพิกัดสันเขาอย่างแม่นยำ',
          effect: { routeBonusLeg: ['PASS_XR_XUEYU_PENAL_GATE', 'CITY_XR_CHIYAN_CAPITAL'], routeMultiplier: 0.88, citySafetyDelta: 4 }
        }
      ]
    },
    {
      id: 'STORY_13_BOTTLENECK_BELL_ECHO',
      titleTh: 'เสียงระฆังหลอนยามติดคอขวดและบันทึกธาตุไฟเข้าแทรก',
      group: 'GEMINI_ORIGINAL',
      category: 'BREAKTHROUGH_LORE',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_13_MERIDIAN_BELL_OMEN',
      polityId: 'POL_BEIMING',
      anchorNodeIds: ['CITY_BM_HANYU_CAPITAL', 'CITY_BM_XUELIAN_SPRINGS'],
      summaryTh: 'ศิษย์ที่ติดคอขวดร่ำลือว่าเสียงระฆังกังวานสามครั้งในหูยามดึกคือลางมงคลให้ฝืนทะลวงขั้นทันที แต่เมื่อเทียบสมุดบันทึกเจ้าสำนักรุ่นที่ 5 กับตำราแพทย์น้ำพุหิมะอุ่นเสวี่ยเหลียนจึงพบว่าเป็นสัญญาณเตือนชีพจรขมับตีกลับก่อนจิตมารปะทุ',
      stages: [
        {
          idx: 0,
          id: 'SPARK_MIDNIGHT_BELL_SUPERSTITION',
          titleTh: 'ศิษย์ที่ติดคอขวดเล่าขานเรื่องเสียงระฆังสวรรค์สามคราเรียกทะลวงขั้น',
          locationId: 'CITY_BM_HANYU_CAPITAL',
          accountId: 'FOLK_ORAL',
          descTh: 'ความเชื่อเรื่องเสียงระฆังในหูยามดึกแพร่สะพัดในหมู่ผู้ฝึกตนที่ใจร้อนอยากทะลวงคอขวด'
        },
        {
          idx: 1,
          id: 'CROSSCHECK_GEN5_DIARY_AND_XUELIAN_NOTES',
          titleTh: 'เทียบสมุดบันทึกธาตุไฟเข้าแทรกของเจ้าสำนักรุ่นที่ 5 กับตำราแพทย์เมืองน้ำพุหิมะอุ่น',
          locationId: 'CITY_BM_XUELIAN_SPRINGS',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่าเสียงระฆังสามคราคืออาการปราณอัดแน่นที่จุดขมับเมื่อจิตมารสะสมเกินเกณฑ์'
        },
        {
          idx: 2,
          id: 'CODIFY_BOTTLENECK_PULSE_DIAGNOSIS',
          titleTh: 'บัญญัติหลักตรวจชีพจรขมับก่อนปิดด่านทะลวงขั้นในสำนัก',
          locationId: 'CITY_BM_XUELIAN_SPRINGS',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เผยแพร่ความจริงเรื่องเสียงสะท้อนชีพจรเพื่อให้ศิษย์ประเมินโอกาสทะลวงขั้นตามความเป็นจริง'
        }
      ],
      resolutions: [
        {
          id: 'TEACH_MERIDIAN_BELL_CAUTION',
          labelTh: 'บรรจุ「หลักฟังเสียงชีพจรขมับสามครา」ในหอคัมภีร์เพื่อระงับการฝืนทะลวงขั้นยามจิตมารสูง',
          match: n => ['scripture', 'healer', 'master', 'deputy'].includes(n.post) || E(n, 'personality.rationality') >= 55,
          consequenceTh: 'ศิษย์ในสำนักแยกแยะอาการชีพจรตีกลับออกจากนิมิตลวงได้แม่นยำขึ้น ลดความสูญเสียจากการฝืนทะลวงขั้นและลดจิตมารสะสม',
          effect: { customId: 'CUSTOM_MERIDIAN_BELL_DIAGNOSIS', heartDemonDelta: -12, skillPractice: 'MEDICINE', sectFameDelta: 6 }
        },
        {
          id: 'XUELIAN_WARM_SPRING_BREATHING',
          labelTh: 'นำเคล็ดผ่อนลมหายใจน้ำพุอุ่นเสวี่ยเหลียนมาใช้คลายความดันปราณก่อนเข้าด่าน',
          match: () => true,
          consequenceTh: 'ผู้ฝึกตนที่ติดคอขวดรู้จักผ่อนปราณคลายจุดขมับก่อนเข้าด่านทะลวงขั้น เพิ่มความมั่นคงทางอารมณ์',
          effect: { customId: 'CUSTOM_WARM_SPRING_BREATH', heartDemonDelta: -8, cultGain: 20 }
        }
      ]
    },
    {
      id: 'STORY_14_HALF_JADE_CLAN_TALLY',
      titleTh: 'ป้ายหยกครึ่งซีกของตระกูลพลัดถิ่นแคว้นชางหลาน',
      group: 'GEMINI_ORIGINAL',
      category: 'KINSHIP_CLAN',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_14_CANGLAN_GRANARY_HALF_TALLY',
      polityId: 'POL_YOUMING',
      anchorNodeIds: ['CITY_YM_HUNDENG_CAPITAL', 'TOWN_YM_SHIBEI_RUBBING', 'TOWN_YH_CUIZHU_TEA'],
      summaryTh: 'ศิษย์และชาวบ้านสองสายตระกูลที่อพยพจากแคว้นหมอกชางหลานถือป้ายหยกครึ่งซีกที่ประกบกันได้พอดี แต่ต่างฝ่ายต่างจำประวัติศาสตร์คนละด้านเรื่องการเผาคลังในคืนเมืองแตก',
      stages: [
        {
          idx: 0,
          id: 'SPARK_MATCHING_JADE_HALVES',
          titleTh: 'พบป้ายหยกครึ่งซีกสองชิ้นที่มีรอยหักตรงกันแต่เล่าเรื่องคืนเมืองแตกต่างกัน',
          locationId: 'TOWN_YH_CUIZHU_TEA',
          accountId: 'FOLK_ORAL',
          descTh: 'สายตระกูลฝั่งใต้และสายตระกูลฝั่งเหนือต่างเข้าใจว่าอีกฝ่ายทอดทิ้งตระกูลในคืนที่แคว้นชางหลานล่มสลาย'
        },
        {
          idx: 1,
          id: 'COMPARE_SHIBEI_RUBBING_AND_NOTCHES',
          titleTh: 'นำป้ายหยกสองซีกมาประกบและเทียบกับแผ่นลอกลายศิลาที่ตำบลสือเปย',
          locationId: 'TOWN_YM_SHIBEI_RUBBING',
          accountId: 'SECT_ORTHODOX',
          descTh: 'รอยสลักด้านในป้ายหยกเมื่อประกบกันชี้ไปยังหอทะเบียนเกณฑ์ทหารของแคว้นชางหลาน ไม่ใช่คลังข้าว'
        },
        {
          idx: 2,
          id: 'RECONCILE_TWO_BRANCH_ANCESTORS',
          titleTh: 'เปิดเผยความเสียสละของบรรพชนทั้งสองสายที่เผาบัญชีเกณฑ์ทหารช่วยลูกหลาน',
          locationId: 'CITY_YM_HUNDENG_CAPITAL',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'ประสานรอยร้าวสองสายตระกูลและบันทึกเกียรติคุณลงในทำเนียบเครือญาติสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'SWORN_CLAN_REUNION_RITE',
          labelTh: 'จัดพิธีเชื่อมป้ายหยกสองสายตระกูลในโถงบรรพชนและฟื้นฟูไมตรีพี่น้องร่วมรากเหง้า',
          match: n => E(n, 'values.familyClan') >= 52 || E(n, 'personality.loyalty') >= 55,
          consequenceTh: 'ทายาททั้งสองสายตระกูลคลายความแค้นนับร้อยปีและจับมือเป็นพี่น้องร่วมสาบาน เพิ่มความไว้วางใจและความอบอุ่นในสำนัก',
          effect: { customId: 'CUSTOM_CANGLAN_JADE_REUNION', moodDelta: 10, lonelinessDelta: -12, sectFameDelta: 6 }
        },
        {
          id: 'SHIBEI_GENEALOGY_ARCHIVE',
          labelTh: 'ฝากสำเนาแผ่นลอกลายสายตระกูลชางหลานไว้ที่ตำบลศิลาจารึกสือเปยและหอทะเบียนสำนัก',
          match: () => true,
          consequenceTh: 'หอทะเบียนสำนักและตำบลสือเปยมีบันทึกสายตระกูลผู้อพยพที่ถูกต้อง ช่วยให้ผู้พลัดถิ่นสืบหารากเหง้าของตนได้',
          effect: { cityProsperityDelta: 4, citySafetyDelta: 4, sectFameDelta: 5 }
        }
      ]
    },
    {
      id: 'STORY_15_NIGHT_DEW_KILN_SHIFT',
      titleTh: 'ธรรมเนียมเฝ้าเตาไฟกะน้ำค้างแข็ง',
      group: 'GEMINI_ORIGINAL',
      category: 'CRAFT_LABOR',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_15_FROST_DEW_KILN_BANKING',
      polityId: 'POL_CHIYAN',
      anchorNodeIds: ['CITY_CY_RONGLU_CAPITAL', 'TOWN_CY_LIUHUANG_SULFUR'],
      summaryTh: 'ศิษย์โรงหลอมและหอโอสถรุ่นใหม่มองว่าธรรมเนียมกลบเถ้าครึ่งปล่องและวางชามน้ำบ่อเย็นหน้าเตากะดึกเป็นภาระไร้สาระ จนกระทั่งได้เทียบกับภูมิปัญญาเตาหลอมกำมะถันแห่งฉื่อเยี่ยน',
      stages: [
        {
          idx: 0,
          id: 'SPARK_NIGHT_SHIFT_GRUMBLING',
          titleTh: 'ศิษย์เวรเตาหลอมกะดึกตั้งข้อกังขาเรื่องกฎวางชามน้ำเย็นและกลบเถ้าครึ่งปล่อง',
          locationId: 'TOWN_CY_LIUHUANG_SULFUR',
          accountId: 'FOLK_ORAL',
          descTh: 'ศิษย์ฝึกหัดคิดจะยกเลิกธรรมเนียมวางชามน้ำหน้าเตาเพราะคิดว่าเป็นเพียงกฎรับน้องโบราณ'
        },
        {
          idx: 1,
          id: 'OBSERVE_DAWN_SULFUR_CONDENSATION',
          titleTh: 'ตรวจพบผลึกเขม่าแร่และไอกำมะถันที่ควบแน่นอยู่ในชามน้ำยามน้ำค้างลง',
          locationId: 'CITY_CY_RONGLU_CAPITAL',
          accountId: 'SECT_ORTHODOX',
          descTh: 'ช่างอาวุโสแห่งนครเตาหลอมอัคคีฉื่อเยี่ยนชี้ให้เห็นว่าชามน้ำเย็นช่วยดักก๊าซพิษไม่ให้ไหลย้อนเข้าปอดช่างกะเช้า'
        },
        {
          idx: 2,
          id: 'STANDARDIZE_FROST_DEW_SALVAGE',
          titleTh: 'ยกระดับธรรมเนียมกลบเถ้ารับน้ำค้างเป็นเคล็ดความปลอดภัยและเก็บกู้ผงแร่ของสำนัก',
          locationId: 'CITY_CY_RONGLU_CAPITAL',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'ศิษย์สายช่างเข้าใจเหตุผลที่แท้จริงและนำผงแร่ควบแน่นในชามน้ำกลับมาใช้ประโยชน์'
        }
      ],
      resolutions: [
        {
          id: 'KILN_DEW_MINERAL_RECLAMATION',
          labelTh: 'เก็บกู้ผงแร่และเขม่าสมุนไพรที่ควบแน่นในชามน้ำค้างมาใช้เป็นวัตถุดิบเสริมของโรงหลอมและหอโอสถ',
          match: n => ['forge', 'alchemy'].includes(n.post) || E(n, 'values.knowledgeCraft') >= 52,
          consequenceTh: 'โรงงานสำนักทั้งปลอดภัยจากไอพิษตีกลับและได้ผงแร่ควบแน่นกลับมาใช้ประโยชน์ในระบบเศรษฐกิจหมุนเวียน',
          effect: { customId: 'CUSTOM_FROST_DEW_KILN_SALVAGE', skillPractice: 'FORGING', cityProsperityDelta: 5 }
        },
        {
          id: 'SAFE_MORNING_SHIFT_PROTOCOL',
          labelTh: 'กำหนดให้การตรวจชามน้ำหน้าเตาเป็นสัญญาณเปิดงานที่ปลอดภัยของช่างกะเช้าทุกคน',
          match: () => true,
          consequenceTh: 'ลดความเหนื่อยล้าและอุบัติเหตุจากไอความร้อนในโรงหลอมและหอโอสถอย่างยั่งยืน',
          effect: { customId: 'CUSTOM_SAFE_KILN_SHIFT', skillPractice: 'ALCHEMY', moodDelta: 5 }
        }
      ]
    },
    {
      id: 'STORY_16_EXILED_PRINCE_INKSTONE',
      titleTh: 'แท่นฝนหมึกตราพยัคฆ์บิ่นของขุนนางตกอับ',
      group: 'GEMINI_ORIGINAL',
      category: 'COURT_AMBITION',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_16_TIGER_SEAL_CHIPPED_INKSTONE',
      polityId: 'POL_XIRONG',
      anchorNodeIds: ['CITY_XR_SHAYU_OASIS', 'PASS_XR_XUEYU_PENAL_GATE', 'CITY_XR_CHIYAN_CAPITAL'],
      summaryTh: 'บัณฑิตขุนนางตกอับจากแดนประจิมพกแท่นฝนหมึกหินทรายแดงที่มีรอยตราพยัคฆ์บิ่น ถูกทางการกล่าวหาว่าทำบัญชีทหารหาย แต่ภายในฐานแท่นฝนหมึกกลับซ่อนสำมะโนครัวจริงที่ปกป้องชาวบ้านโอเอซิส',
      stages: [
        {
          idx: 0,
          id: 'SPARK_DISGRACED_SCHOLAR_RUMOR',
          titleTh: 'พบขุนนางตกอับพร้อมแท่นฝนหมึกตราพยัคฆ์บิ่นที่เมืองการค้าโอเอซิสซาอวี่',
          locationId: 'CITY_XR_SHAYU_OASIS',
          accountId: 'COURT_CANON',
          descTh: 'มีเสียงลือว่าขุนนางผู้นี้ถูกถอดยศจากด่านคุกโซ่โลหิตเพราะทุจริตและทำบัญชีเกณฑ์พลสูญหาย'
        },
        {
          idx: 1,
          id: 'UNLOCK_DOUBLE_BOTTOM_INKSTONE',
          titleTh: 'พบรอยสลักสายทัวป๋ากัง (#60) และช่องลับใต้แท่นฝนหมึกหินทรายแดง',
          locationId: 'PASS_XR_XUEYU_PENAL_GATE',
          accountId: 'SECT_ORTHODOX',
          descTh: 'เปิดฐานแท่นฝนหมึกพบสำมะโนครัวบ่อน้ำฉบับจริงที่ขุนนางผู้นี้ซ่อนไว้เพื่อไม่ให้ชาวโอเอซิสถูกขูดรีดส่วยน้ำเกินจริง'
        },
        {
          idx: 2,
          id: 'DECIDE_CENSUS_LEDGER_FATE',
          titleTh: 'ตัดสินใจแนวทางจัดการสำมะโนครัวโอเอซิสและชะตาของขุนนางผู้ซื่อสัตย์',
          locationId: 'CITY_XR_CHIYAN_CAPITAL',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เลือกแนวทางระหว่างการคุ้มครองปราชญ์ผู้ซื่อตรงหรือการส่งหลักฐานให้ผู้ตรวจการราชสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'SHELTER_SCHOLAR_TREATISE_IN_SECT',
          labelTh: 'เชิญบัณฑิตมาเป็นที่ปรึกษาตำราปกครองในหอคัมภีร์และเก็บรักษาสำมะโนครัวคุ้มครองชาวโอเอซิส',
          match: n => E(n, 'personality.integrity') >= 55 || E(n, 'values.knowledgeCraft') >= 55 || ['scripture', 'master', 'deputy'].includes(n.post),
          consequenceTh: 'สำนักได้ตำราบริหารยุทธปัจจัยชายแดนและสร้างสายสัมพันธ์อันดีกับชาวเมืองโอเอซิสซาอวี่',
          effect: { customId: 'CUSTOM_OASIS_CENSUS_WISDOM', cityProsperityDelta: 6, citySafetyDelta: 5, sectFameDelta: 7, skillPractice: 'SCRIPTURE' }
        },
        {
          id: 'DELIVER_PROOF_TO_XIRONG_CENSOR',
          labelTh: 'ส่งสำเนาหลักฐานให้ผู้ตรวจการสายทัวป๋ากัง (#60) เพื่อคืนยศแก่ขุนนางผู้ซื่อสัตย์ในราชสำนักซีหรง',
          match: () => true,
          consequenceTh: 'ขุนนางผู้ซื่อตรงได้รับการคืนเกียรติในราชสำนักซีหรง ช่วยเพิ่มเสถียรภาพและไมตรีทางการทูตต่อสำนัก',
          effect: { citySafetyDelta: 7, closedLoopStonesFromPool: 100, sectFameDelta: 6 }
        }
      ]
    },
    {
      id: 'STORY_17_BITTER_WILLOW_PLAGUE_WELL',
      titleTh: 'บ่อน้ำหลิวขมและบันทึกโรคระบาดฤดูฝน',
      group: 'GEMINI_ORIGINAL',
      category: 'EPIDEMIC_RECOVERY',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_17_BITTER_WILLOW_MIASMA_WELL',
      polityId: 'POL_GUJIAO',
      anchorNodeIds: ['CITY_GJ_WANGU_TOTEM', 'TOWN_GJ_BAICAO_STILT', 'PASS_GJ_QIZHANG_MIASMA'],
      summaryTh: 'ชาวบ้านและคนเดินทางหวาดกลัวบ่อน้ำที่มีรากหลิวสีดำชอนไชโดยคิดว่าเป็นคำสาปหนอนกู่ แต่บันทึกไม้ไผ่ของหมู่บ้านหมอสมุนไพรไป๋เฉ่าพิสูจน์ว่าเป็นการปลูกหลิวขมเพื่อกรองพิษไข้หมอก',
      stages: [
        {
          idx: 0,
          id: 'SPARK_CURSED_WELL_PANIC',
          titleTh: 'พบความตื่นตระหนกเรื่องบ่อน้ำรากหลิวขมถูกกล่าวหาว่าเป็นบ่อพิษกู่เจียว',
          locationId: 'PASS_GJ_QIZHANG_MIASMA',
          accountId: 'FOLK_ORAL',
          descTh: 'ขบวนเดินทางไม่กล้าดื่มน้ำจากบ่อหินริมทางและกล่าวโทษชาวกู่เจียวว่าวางยาพิษในตาน้ำ'
        },
        {
          idx: 1,
          id: 'TEST_WILLOW_BARK_AT_BAICAO_STILT',
          titleTh: 'ตรวจฤทธิ์เปลือกรากหลิวขมและค้นบันทึกโรคระบาดที่หมู่บ้านหมอสมุนไพรไป๋เฉ่า',
          locationId: 'TOWN_GJ_BAICAO_STILT',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่าเปลือกรากหลิวขมมีฤทธิ์ดูดซับพิษหมอกและสกัดเชื้อไข้ป่าในน้ำใต้ดิน'
        },
        {
          idx: 2,
          id: 'PROPAGATE_BITTER_WILLOW_FILTRATION',
          titleTh: 'ประกาศความจริงเรื่องบ่อน้ำกรองพิษและนำกิ่งหลิวขมมาปลูกริมร่องน้ำสถานรักษา',
          locationId: 'CITY_GJ_WANGU_TOTEM',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'คลี่คลายความหวาดระแวงที่ด่านหมอกเจ็ดชั้นและยกระดับการป้องกันโรคในสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'PLANT_BITTER_WILLOW_AT_SECT_SPRING',
          labelTh: 'นำกิ่งพันธุ์หลิวขมทักษิณมาปลูกรอบร่องน้ำหอโอสถและสถานรักษาของสำนัก',
          match: n => ['healer', 'herbal', 'alchemy'].includes(n.post) || E(n, 'personality.empathy') >= 52,
          consequenceTh: 'น้ำในสถานรักษาสำนักมีฤทธิ์ต้านพิษหมอกอ่อนๆ ช่วยให้ผู้บาดเจ็บและผู้ติดพิษฟื้นตัวเร็วขึ้น',
          effect: { customId: 'CUSTOM_BITTER_WILLOW_SPRING', skillPractice: 'MEDICINE', citySafetyDelta: 5, sectFameDelta: 6 }
        },
        {
          id: 'CLEAN_AND_MARK_MIASMA_WELLS',
          labelTh: 'ทำความสะอาดปากบ่อและติดป้ายอธิบายคุณประโยชน์ของรากหลิวขมตลอดแนวทางกู่เจียว–สุวรรณโพธิ์',
          match: () => true,
          consequenceTh: 'คนเดินทางและชาวบ้านทั้งสองแคว้นกลับมาใช้น้ำบ่อได้อย่างมั่นใจ ลดความตึงเครียดบริเวณชายแดนทักษิณ',
          effect: { routeBonusLeg: ['PASS_GJ_QIZHANG_MIASMA', 'TOWN_GJ_BAICAO_STILT'], routeMultiplier: 0.88, citySafetyDelta: 6, cityProsperityDelta: 4 }
        }
      ]
    },
    {
      id: 'STORY_18_FOG_LANTERN_FERRY_OATH',
      titleTh: 'ตะเกียงน้ำมันปลาและคำสัตย์คนแจวเรือข้ามหมอก',
      group: 'GEMINI_ORIGINAL',
      category: 'VESSEL_FERRY_LORE',
      layer: 'SHATTERED_SUBCONTINENT',
      factId: 'FACT_18_THREE_LANTERN_FOG_UNDERTOW',
      polityId: null,
      anchorNodeIds: ['PASS_SO_DENGTAI_LIGHTHOUSE', 'CITY_SO_LONGWAN_SHIPYARD', 'TOWN_SO_OUYU_FISHER_ISLE'],
      summaryTh: 'ชาวประมงเกาะโอวอวี๋ไม่กล้าออกเรือเมื่อเห็นแสงสีเขียวลอยเรี่ยน้ำเพราะกลัวสำเภาผี แต่ปูมเชือกหยั่งน้ำของอู่ต่อเรือหลงวานชี้ว่าเป็นสาหร่ายเรืองแสงจากร่องน้ำดูดริมขอบม่านกั้นภพ',
      stages: [
        {
          idx: 0,
          id: 'SPARK_GREEN_FOG_LIGHT_TABOO',
          titleTh: 'รับรู้ข้อห้ามออกเรือยามเห็นแสงไฟสีเขียวลอยเรี่ยน้ำที่เกาะประมงโอวอวี๋',
          locationId: 'TOWN_SO_OUYU_FISHER_ISLE',
          accountId: 'FOLK_ORAL',
          descTh: 'คนเรือเล่าขานเรื่องโคมไฟสำเภาผีที่ลากเรือหายเข้าไปในทะเลหมอกทักษิณ'
        },
        {
          idx: 1,
          id: 'STUDY_THREE_LANTERN_KNOT_LOG',
          titleTh: 'ค้นคว้าสมุดปมเชือกหยั่งร่องน้ำสามตะเกียงที่อู่ต่อเรืออ่าวหลงวาน',
          locationId: 'CITY_SO_LONGWAN_SHIPYARD',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบวิธีแขวนตะเกียงน้ำมันปลาสามดวงเพื่อวัดความลึกและหลบแนวร่องน้ำดูดที่พัดสาหร่ายเรืองแสงขึ้นมา'
        },
        {
          idx: 2,
          id: 'SOUND_OUTER_FOG_RECOVER_DRIFTWOOD',
          titleTh: 'ทดลองหยั่งร่องน้ำหน้าป้อมประภาคารและเก็บกู้แผ่นไม้เรือจากโพ้นทะเลหมอก',
          locationId: 'PASS_SO_DENGTAI_LIGHTHOUSE',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'ยืนยันความปลอดภัยของวิธีเดินเรือสามตะเกียงและพบร่องรอยอักษรจากแผ่นดินใหญ่นอกม่านหมอก'
        }
      ],
      resolutions: [
        {
          id: 'ADOPT_THREE_LANTERN_FERRY_CODE',
          labelTh: 'ถ่ายทอด「วิธีหยั่งร่องน้ำสามตะเกียง」ให้กองเรือข้ามฟากและคณะสำรวจทางน้ำของสำนัก',
          match: n => ['mission', 'quartermaster', 'wildwarden'].includes(n.post) || ['TIDE_VOYAGER', 'WANDERING_DAO'].includes(n.cult?.path),
          consequenceTh: 'การเดินเรือแถบปากน้ำมังกรหลับและอ่าวหลงวานปลอดภัยจากกระแสน้ำดูดริมทะเลหมอกและเดินทางได้รวดเร็วขึ้น',
          effect: { routeBonusLeg: ['PASS_SO_DENGTAI_LIGHTHOUSE', 'CITY_SO_LONGWAN_SHIPYARD'], routeMultiplier: 0.85, citySafetyDelta: 6, cityProsperityDelta: 4 }
        },
        {
          id: 'DECODE_BEYOND_FOG_DRIFTWOOD',
          labelTh: 'นำแผ่นไม้สักสลักอักษรจากโพ้นทะเลหมอกกลับมาเก็บรักษาในหอจดหมายเหตุความลับม่านกั้นภพ',
          match: () => true,
          consequenceTh: 'หอคัมภีร์ได้หลักฐานชิ้นสำคัญที่ยืนยันว่าพ้นทะเลหมอกทักษิณออกไปยังมีอาณาจักรอื่นตั้งอยู่',
          effect: { customId: 'CUSTOM_OUTER_FOG_DRIFTWOOD_PROOF', sectFameDelta: 8, skillPractice: 'SCRIPTURE' }
        }
      ]
    },
    {
      id: 'STORY_19_SILENT_ANVIL_TEMPER_LINE',
      titleTh: 'ลายน้ำประสานรอยร้าวของตระกูลช่างไร้เสียง',
      group: 'GEMINI_ORIGINAL',
      category: 'RELIC_MAKER_LINEAGE',
      layer: 'IMPERIAL_CHESSBOARD',
      factId: 'FACT_19_MUTE_ARMORER_TWIN_TEMPER',
      polityId: 'POL_CHIYAN',
      anchorNodeIds: ['CITY_CY_RONGLU_CAPITAL', 'TOWN_YX_TAMAHAGANE_SAND', 'CITY_YX_WUYACASTLE'],
      summaryTh: 'ช่างหลอมอัคคีฉื่อเยี่ยนและช่างตีดาบทรายเหล็กดำหยุนเซียวต่างกล่าวหาว่าอีกฝ่ายขโมยเคล็ด「ลายน้ำประสานรอยร้าว」แต่เมื่อถอดกั่นศาสตราโบราณมาเทียบกลับพบตราค้อนไขว้ของช่างเกราะใบ้คนเดียวกัน',
      stages: [
        {
          idx: 0,
          id: 'SPARK_RIVAL_SMITH_ACCUSATION',
          titleTh: 'รับรู้ข้อพิพาทเรื่องผู้คิดค้นลายน้ำประสานรอยร้าวระหว่างช่างฉื่อเยี่ยนกับช่างหยุนเซียว',
          locationId: 'CITY_CY_RONGLU_CAPITAL',
          accountId: 'FOLK_ORAL',
          descTh: 'ช่างหลอมสองภูมิภาคโต้เถียงกันเรื่องสิทธิ์ความเป็นเจ้าของเคล็ดวิชาซ่อมรอยร้าวศาสตราโบราณ'
        },
        {
          idx: 1,
          id: 'INSPECT_TANG_MARKS_AT_TAMAHAGANE',
          titleTh: 'ตรวจสอบรอยตอกรูปค้อนไขว้ไร้ลิ้นระฆังใต้กั่นดาบโบราณที่หมู่บ้านหาดทรายเหล็กดำ',
          locationId: 'TOWN_YX_TAMAHAGANE_SAND',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบว่าต้นตระกูลช่างทั้งสองฝั่งเคยเป็นศิษย์พี่ศิษย์น้องร่วมเตาของช่างเกราะใบ้แห่งยุคเทียนกู่'
        },
        {
          idx: 2,
          id: 'REUNITE_FIRE_AND_WAVE_TEMPER',
          titleTh: 'ผสานเคล็ดชุบไฟแรงฉื่อเยี่ยนเข้ากับเคล็ดตีทบเหล็กเย็นหยุนเซียวในโรงหลอมสำนัก',
          locationId: 'CITY_YX_WUYACASTLE',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'คืนความสมบูรณ์ให้เคล็ดลายน้ำประสานทั่งไร้เสียงและยุติความบาดหมางของสองสายช่าง'
        }
      ],
      resolutions: [
        {
          id: 'MASTER_SILENT_ANVIL_SUTURE',
          labelTh: 'บรรจุ「เคล็ดประสานทั่งไร้เสียงสองสายช่าง」ในโรงหลอมสำนักเพื่อยกระดับการบำรุงรักษาศาสตรา',
          match: n => ['forge', 'arraymaster'].includes(n.post) || E(n, 'aptitudes.crafting') >= 55,
          consequenceTh: 'ช่างหลอมของสำนักเชี่ยวชาญการประสานรอยร้าวและดูแลรักษาศาสตราทั้งสายหนักและสายคมเฉียบ',
          effect: { customId: 'CUSTOM_SILENT_ANVIL_SUTURE', skillPractice: 'FORGING', cityProsperityDelta: 6, sectFameDelta: 7 }
        },
        {
          id: 'BROKER_IRON_SULFUR_CRAFT_EXCHANGE',
          labelTh: 'ประสานการแลกเปลี่ยนทรายเหล็กดำหยุนเซียวกับถ่านกำมะถันฉื่อเยี่ยนผ่านตลาดกลาง',
          match: () => true,
          consequenceTh: 'เปิดช่องทางแลกเปลี่ยนวัตถุดิบตีเหล็กระหว่างสองภูมิภาคและสร้างรายได้หมุนเวียนแก่สำนัก',
          effect: { closedLoopStonesFromPool: 110, cityProsperityDelta: 5 }
        }
      ]
    },
    {
      id: 'STORY_20_TWO_FACES_OF_ONE_EPITHET',
      titleTh: 'สมญานามเดียว สองตำนานที่ขัดแย้ง',
      group: 'GEMINI_ORIGINAL',
      category: 'EPITHET_DISPUTE',
      layer: 'PROVINCIAL_VEIL',
      factId: 'FACT_20_BROKEN_BRIDGE_EPITHET_DISPUTE',
      polityId: 'POL_YUNHE',
      anchorNodeIds: ['PASS_YH_XIFENG_GORGE', 'CITY_YH_SHUANGJIANG'],
      summaryTh: 'สมญานาม「ดาบสะบั้นสะพานซีเฟิง」ถูกขับขานในโรงเตี๊ยมเหนือว่าเป็นจอมมารผู้สังหารโจรสามสิบศพ แต่ชาวบ้านฝั่งใต้ยืนยันว่าเป็นจอมยุทธ์ผู้ฟันเชือกสะพานช่วยชาวบ้านหนีโดยไม่ฆ่าผู้ใดเลย',
      stages: [
        {
          idx: 0,
          id: 'SPARK_CONTRADICTORY_BALLADS',
          titleTh: 'ได้ยินเพลงโรงเตี๊ยมสองสำนวนที่เล่าวีรกรรมของสมญานามเดียวกันตรงข้ามกันอย่างสิ้นเชิง',
          locationId: 'CITY_YH_SHUANGJIANG',
          accountId: 'FOLK_ORAL',
          descTh: 'สำนวนเหนือเล่าว่าเป็นจอมยุทธ์อำมหิตผู้ฆ่าล้างสามสิบศพ ส่วนสำนวนใต้เล่าว่าเป็นผู้ถือศีลไม่สังหาร'
        },
        {
          idx: 1,
          id: 'EXAMINE_XIFENG_BRIDGE_PILLAR_AND_WITNESS',
          titleTh: 'ตรวจรอยดาบบนเสาหินด่านช่องลมประจิมซีเฟิงและสอบถามพยานที่อยู่ในเหตุการณ์',
          locationId: 'PASS_YH_XIFENG_GORGE',
          accountId: 'SECT_ORTHODOX',
          descTh: 'พบรอยดาบตัดเชือกสะพานเพียงรอยเดียว และได้พบอดีตโจรภูเขาที่สารภาพว่าหัวหน้าตนกุเรื่องสามสิบศพขึ้นเพื่อกลบเกลื่อนความขลาด'
        },
        {
          idx: 2,
          id: 'RECORD_DUAL_FACET_EPITHET_CHRONICLE',
          titleTh: 'บันทึกทั้งนามเสียงที่น่าเกรงขามและคุณธรรมที่แท้จริงลงในทำเนียบสมญานามยุทธภพ',
          locationId: 'CITY_YH_SHUANGJIANG',
          accountId: 'VERIFIED_CHRONICLE',
          descTh: 'เลือกวิธีบันทึกประวัติสมญานามในหอจดหมายเหตุสำนัก'
        }
      ],
      resolutions: [
        {
          id: 'CHRONICLE_TRUTH_AND_DETERRENCE',
          labelTh: 'บันทึกความจริงทั้งสองด้านไว้ในทำเนียบสมญานาม:「นามข่มขวัญโจร คุณธรรมคุ้มครองชาวบ้าน」',
          match: n => ['scripture', 'spymaster', 'envoy'].includes(n.post) || E(n, 'aptitudes.comprehension') >= 52,
          consequenceTh: 'ทำเนียบสมญานามของสำนักบันทึกทั้งที่มาของข่าวลือและข้อเท็จจริงจากพยาน ช่วยเพิ่มความน่าเชื่อถือของพงศาวดารสำนัก',
          effect: { customId: 'CUSTOM_DUAL_EPITHET_VERIFICATION', sectFameDelta: 8, citySafetyDelta: 5, skillPractice: 'SCRIPTURE' }
        },
        {
          id: 'BALLAD_CORRECTION_AT_SHUANGJIANG',
          labelTh: 'ถ่ายทอดบทเพลงฉบับจริงให้วณิพกนครสองแควหยุนเหอขับขานเชิดชูคุณธรรมไม่สังหาร',
          match: () => true,
          consequenceTh: 'เรื่องราวจอมยุทธ์ตัดสะพานโดยไม่เปื้อนเลือดกลายเป็นบทเพลงสอนใจในนครสองแควหยุนเหอ',
          effect: { sectFameDelta: 7, moodDelta: 6, cityProsperityDelta: 4 }
        }
      ]
    }
  ]);

  const STORY_BY_ID = Object.freeze(Object.fromEntries(STORY_CHAINS.map(s => [s.id, s])));

  // Ordinary Slice-of-Life & Lore-Driven Emergent Event Templates
  const EMERGENT_LORE_EVENTS = Object.freeze([
    {
      id: 'EMERGENT_01_FERRY_TIDE_DEBATE',
      kind: 'SLICE_AND_LORE',
      factId: 'FACT_01_SHUANGJIANG_BACKFLOW',
      storyId: 'STORY_01_SHUANGJIANG_FLOOD_LEDGER',
      nodeId: 'CITY_YH_SHUANGJIANG',
      titleTh: 'คนแจวเรือซวงเจียงถกเถียงเรื่องขีดระดับน้ำใต้ตอม่อสะพานเก่า',
      storyTh: 'ริมท่าเทียบเรือนครสองแควหยุนเหอ คนแจวเรือเฒ่ากับเสมียนท่าเรือชี้ให้ศิษย์ที่เดินทางผ่านมาดูรอยสิ่วโบราณใต้ตอม่อหินซึ่งโผล่พ้นน้ำขึ้นมาในยามน้ำลด พร้อมถกเถียงกันว่าปีนี้กระแสน้ำหนุนจะมาเร็วกว่ากำหนดหรือไม่',
      originCauseTh: 'ระดับน้ำสองแควลดต่ำลงจนเผยให้เห็นขีดวัดระดับน้ำยุคเหยียนหลิง',
      consequenceTh: 'ผู้ที่อยู่ในเหตุการณ์ได้รับรู้ข้อมูลเรื่องระดับน้ำสองแควจากสถานที่จริง'
    },
    {
      id: 'EMERGENT_02_SCRIPTURE_MARGIN_NOTE',
      kind: 'SLICE_AND_LORE',
      factId: 'FACT_02_BAILU_DUAL_COMMENTARY',
      storyId: 'STORY_02_BAILU_DUAL_ANNOTATED_MANUAL',
      nodeId: 'CITY_YH_BAILU_ACADEMY',
      titleTh: 'ศิษย์หอคัมภีร์พบหมายเหตุสองสีในสำเนาตำราจากไป๋ลู่',
      storyTh: 'ระหว่างคัดลอกคัมภีร์ที่ชำรุดในหอคัมภีร์ ศิษย์พบกระดาษคั่นหน้าจากเมืองบัณฑิตกวางขาวไป๋ลู่ที่มีรอยพู่กันหมึกชาดและหมึกดำเขียนโต้ตอบกันเรื่องวิธีโคจรลมปราณผ่านจุดชีพจรลัด',
      originCauseTh: 'การตรวจชำระและคัดลอกคัมภีร์ประจำสัปดาห์ในหอคัมภีร์',
      consequenceTh: 'จุดประกายการถกเถียงและเปรียบเทียบแนวทางฝึกฝนระหว่างสายรุกและสายมั่นคง'
    },
    {
      id: 'EMERGENT_03_QINGLAN_WAX_STAMP_PARCEL',
      kind: 'SLICE_AND_LORE',
      factId: 'FACT_03_QINGLAN_DOUBLE_TOLL_SEAL',
      storyId: 'STORY_03_QINGLAN_SECOND_TOLL_STAMP',
      nodeId: 'CITY_DH_QINGLAN_DICE_CITY',
      titleTh: 'หีบพัสดุจากแดนบูรพามีตราครั่งคลื่นคู่ของราชวงศ์ชิงหลานติดมาด้วย',
      storyTh: 'ขณะตรวจรับหีบสมุนไพรแห้งและใบชาจากขบวนค้าขายตะวันออก ผู้ดูแลคลังสังเกตเห็นตราครั่งทองเหลืองรูปคลื่นคู่ของแคว้นชิงหลานที่ล่มสลายไปเมื่อเก้าสิบปีก่อนประทับซ้อนอยู่ใต้ตราด่านภาษีตงหวง',
      originCauseTh: 'การหมุนเวียนสินค้าระหว่างคลังเก่าริมแม่น้ำชิงหลานกับตลาดหยุนเหอ',
      consequenceTh: 'เปิดเบาะแสเรื่องเครือข่ายตั๋วแลกเงินและคลังพัสดุยุคเปลี่ยนผ่านแคว้นชิงหลาน'
    },
    {
      id: 'EMERGENT_04_KITCHEN_TWICE_PAID_SOUP',
      kind: 'SLICE_OF_LIFE',
      factId: 'FACT_11_FERRY_TRAVELER_TWICE_PAID_MEAL',
      storyId: 'STORY_11_MEAL_PAID_TWICE',
      nodeId: 'TOWN_YH_LIUWAN_FERRY',
      titleTh: 'เบี้ยค่าอาหารปริศนาวางซ้ำใต้หม้อแกงร้อนในโรงครัวสำนัก',
      storyTh: 'หลังมื้อค่ำในโรงครัวสำนัก พ่อครัวพบเบี้ยค่าอาหารถูกวางซ้อนไว้ใต้ถาดหม้อแกงเป็นครั้งที่สองของสัปดาห์ ศิษย์ที่นั่งร่วมโต๊ะต่างอมยิ้มและคาดเดากันไปต่างๆ นานาว่าเป็นฝีมือของผู้ใด',
      originCauseTh: 'ศิษย์จากลุ่มน้ำหยุนเหอปฏิบัติตามธรรมเนียมฝากชามอุ่นตอบแทนน้ำใจสหายอย่างเงียบๆ',
      consequenceTh: 'บรรยากาศในโรงครัวอบอุ่นขึ้นและพยานในโรงครัวได้เรียนรู้ธรรมเนียมคนเดินทางริมท่าข้ามฟาก'
    },
    {
      id: 'EMERGENT_05_NIGHT_KILN_WATER_BOWL',
      kind: 'SLICE_OF_LIFE',
      factId: 'FACT_15_FROST_DEW_KILN_BANKING',
      storyId: 'STORY_15_NIGHT_DEW_KILN_SHIFT',
      nodeId: 'CITY_CY_RONGLU_CAPITAL',
      titleTh: 'คราบผลึกแร่ในชามน้ำบ่อหน้าเตาหลอมกะน้ำค้างแข็ง',
      storyTh: 'ยามเช้ามืดที่น้ำค้างลงจัด ศิษย์เวรโรงหลอมที่เข้ามาเปิดเตาพบว่าในชามน้ำเย็นที่วางทิ้งไว้หน้าปล่องเถ้าเมื่อคืนมีคราบผงแร่ละเอียดลอยจับอยู่เต็มผิวน้ำ ส่วนอากาศในห้องหลอมกลับปลอดโปร่งไร้กลิ่นกำมะถันฉุน',
      originCauseTh: 'อุณหภูมิรุ่งสางลดต่ำทำให้ไอกำมะถันและผงแร่ควบแน่นลงในชามน้ำเย็นหน้าเตา',
      consequenceTh: 'ศิษย์สายช่างเริ่มเข้าใจเหตุผลที่แท้จริงของธรรมเนียมกลบเถ้ารับน้ำค้าง'
    },
    {
      id: 'EMERGENT_06_ANCESTRAL_WOODEN_SWORD_DUSTING',
      kind: 'SLICE_AND_LORE',
      factId: 'FACT_07_GEN7_WOODEN_SWORD_AND_EMPTY_CHAIR',
      storyId: 'STORY_07_SEVENTH_GEN_EMPTY_CHAIR',
      nodeId: 'CITY_YH_OLD_DAREN_SQUARE',
      titleTh: 'ศิษย์เวรทำความสะอาดโถงบรรพชนพบรอยสลักใต้ด้ามกระบี่ไม้ท้อข้างเก้าอี้ว่าง',
      storyTh: 'ขณะปัดฝุ่นโถงป้ายวิญญาณบูรพาจารย์รุ่นที่ 1–6 ศิษย์เวรสังเกตเห็นว่าใต้ด้ามกระบี่ไม้ท้อไร้คมที่แขวนอยู่ข้างเก้าอี้ว่างมีอักษรย่อของเจ้าสำนักรุ่นที่ 6 โม่ชางไห่ สลักคำว่า「ระลึกถึงศิษย์พี่ผู้เฝ้าประตูเขา」คู่กับบันทึกกล่าวถึงตราหินเทาไร้ลักษณ์',
      originCauseTh: 'การดูแลทำความสะอาดและสักการะป้ายบรรพชนประจำเดือน',
      consequenceTh: 'ช่วยไขข้อข้องใจของศิษย์รุ่นใหม่เรื่องความแตกต่างระหว่างกระบี่ไม้ท้อที่ระลึกกับตราหินเทาไร้ลักษณ์ประจำตำแหน่งเจ้าสำนักรุ่นที่ 7'
    },
    {
      id: 'EMERGENT_07_BOTTLENECK_MIDNIGHT_CHIME',
      kind: 'SLICE_AND_LORE',
      factId: 'FACT_13_MERIDIAN_BELL_OMEN',
      storyId: 'STORY_13_BOTTLENECK_BELL_ECHO',
      nodeId: 'CITY_BM_XUELIAN_SPRINGS',
      titleTh: 'การสนทนาเรื่องเสียงระฆังในหูยามติดคอขวดที่ลานฝึกสมาธิ',
      storyTh: 'หลังเสร็จสิ้นการนั่งสมาธิรอบค่ำ ศิษย์ที่กำลังติดคอขวดเล่าให้สหายฟังว่าตนได้ยินเสียงกังวานคล้ายระฆังสามครั้งในโสตประสาท ผู้อาวุโสที่เดินผ่านมาได้ยินจึงเตือนให้นึกถึงบันทึกของเจ้าสำนักรุ่นที่ 5 กู้เหยียนจือ',
      originCauseTh: 'ความดันปราณสะสมที่จุดขมับของผู้ฝึกตนที่ติดคอขวด',
      consequenceTh: 'เกิดการแลกเปลี่ยนความรู้เรื่องการแยกแยะสัญญาณเตือนชีพจรตีกลับออกจากนิมิตทะลวงขั้น'
    },
    {
      id: 'EMERGENT_08_EPITHET_TAVERN_VERSIONS',
      kind: 'SLICE_AND_LORE',
      factId: 'FACT_20_BROKEN_BRIDGE_EPITHET_DISPUTE',
      storyId: 'STORY_20_TWO_FACES_OF_ONE_EPITHET',
      nodeId: 'PASS_YH_XIFENG_GORGE',
      titleTh: 'ผู้มาเยือนสองคนเล่าตำนาน「ดาบสะบั้นสะพานซีเฟิง」ไม่ตรงกัน',
      storyTh: 'ที่ศาลาพักร้อนหน้าสำนัก คนเดินม้าจากแดนเหนือและพ่อค้าใบชาจากแดนใต้ต่างเล่าที่มาของสมญานามดาบสะบั้นสะพานซีเฟิงไปคนละขั้ว คนหนึ่งว่าฆ่าโจรสามสิบศพ อีกคนว่าฟันเชือกสะพานช่วยชาวบ้านโดยไม่ฆ่าใครเลย',
      originCauseTh: 'การแพร่กระจายของข่าวลือและเพลงโรงเตี๊ยมจากสองภูมิภาคที่มาบรรจบกันที่หยุนเหอ',
      consequenceTh: 'ศิษย์ที่ได้ยินบันทึกทั้งสองกระแสไว้รอการพิสูจน์ที่ด่านช่องลมประจิมซีเฟิง'
    }
  ]);

  X.LIVING_LORE = Object.freeze({
    VERSION: '3.1.0-living-lore',
    EPISTEMIC_LAYERS,
    FALLEN_DYNASTIES_ARCHIVE,
    CANON_FACTS,
    FACT_BY_ID,
    STORY_CHAINS,
    STORY_BY_ID,
    EMERGENT_LORE_EVENTS
  });

  // Ensure world & sect Living Lore runtime state
  X.initLivingLore = W => {
    if (!W || !W.world) return null;
    if (!W.world.livingLore || typeof W.world.livingLore !== 'object') {
      W.world.livingLore = {
        version: '3.1.0-living-lore',
        facts: {},
        stories: {},
        routeModifiers: {},
        adoptedCustoms: {},
        epithetDisputes: {},
        recentEvents: [],
        eventSeq: 0,
        lastTickDay: -1,
        lastEmergentDay: -3
      };
    }
    const ll = W.world.livingLore;
    if (!ll.facts || typeof ll.facts !== 'object') ll.facts = {};
    if (!ll.stories || typeof ll.stories !== 'object') ll.stories = {};
    if (!ll.routeModifiers || typeof ll.routeModifiers !== 'object') ll.routeModifiers = {};
    if (!ll.adoptedCustoms || typeof ll.adoptedCustoms !== 'object') ll.adoptedCustoms = {};
    if (!ll.epithetDisputes || typeof ll.epithetDisputes !== 'object') ll.epithetDisputes = {};
    if (!Array.isArray(ll.recentEvents)) ll.recentEvents = [];

    if (W.sect) {
      if (!Array.isArray(W.sect.loreArchive)) W.sect.loreArchive = [];
    }

    // Ensure all 28 Canon Facts have a state record in ll.facts
    for (const f of CANON_FACTS) {
      if (!ll.facts[f.id]) {
        ll.facts[f.id] = {
          factId: f.id,
          discovered: false,
          firstDiscoveredDay: null,
          firstDiscovererId: null,
          knownAccounts: [],
          evidenceLineages: [],
          status: 'undiscovered',
          archivedInSect: false,
          lastUpdatedDay: W.day || 0
        };
      }
    }

    // Ensure all 20 Story Chains have a state record in ll.stories
    for (const s of STORY_CHAINS) {
      if (!ll.stories[s.id]) {
        ll.stories[s.id] = {
          storyId: s.id,
          factId: s.factId,
          stageIdx: 0,
          status: 'dormant', // 'dormant' | 'active' | 'contested' | 'resolved'
          sparkedDay: null,
          resolvedDay: null,
          resolutionId: null,
          resolutionLabelTh: null,
          resolutionConsequenceTh: null,
          leadNpcIds: [],
          witnessIds: [],
          evidenceLineages: [],
          history: []
        };
      }
    }

    // Seed initial lore for existing NPCs if not yet seeded
    if (Array.isArray(W.npcs)) {
      for (const n of W.npcs) {
        if (n && !n.dead && (!n.ext || !n.ext.lore)) {
          X.seedNpcInitialLore(W, n);
        }
      }
    }
    return ll;
  };

  // Seed an NPC with 2-3 organic hometown / polity / path beliefs at creation or recruitment
  X.seedNpcInitialLore = (W, npc) => {
    if (!W || !npc || npc.dead || !getCOG() || !getCOG().learnLoreFact) return;
    getCOG().ensureLoreState(npc);
    const homeId = npc.ext && npc.ext.world && npc.ext.world.hometownNodeId;
    const polityId = npc.ext && npc.ext.world && npc.ext.world.birthPolityId;
    const pathId = npc.cult && npc.cult.path;

    // 1. Find a non-secret fact anchored at or near the NPC's hometown or polity
    const homeFacts = CANON_FACTS.filter(f => !f.secretGate && (
      (homeId && Array.isArray(f.anchorNodeIds) && f.anchorNodeIds.includes(homeId)) ||
      (polityId && f.polityId === polityId)
    ));
    if (homeFacts.length) {
      const idx = Math.abs((npc.h && npc.h.genome) || 1) % homeFacts.length;
      const f = homeFacts[idx];
      const acc = (polityId === f.polityId && E(npc, 'personality.discipline') >= 62) ? 'COURT_CANON' : 'FOLK_ORAL';
      getCOG().learnLoreFact(W, npc, f.id, {
        accountId: acc,
        originEventId: 'hometown:' + (homeId || polityId || 'yunhe') + ':' + f.id + ':' + acc,
        sourceKind: 'hometown',
        storyId: f.storyId
      });
    }

    // 2. Seed sect generational lore (FACT_07) or Yunhe treaty lore (FACT_21) for sect members
    if (npc.id === (W.sect && W.sect.masterId) || (npc.rank || 0) >= 3) {
      getCOG().learnLoreFact(W, npc, 'FACT_07_GEN7_WOODEN_SWORD_AND_EMPTY_CHAIR', {
        accountId: 'SECT_ORTHODOX',
        originEventId: 'sect:ancestral_hall:FACT_07:SECT_ORTHODOX',
        sourceKind: 'ancestral_plaque',
        storyId: 'STORY_07_SEVENTH_GEN_EMPTY_CHAIR'
      });
      getCOG().learnLoreFact(W, npc, 'FACT_21_SU_QIN_820YR_YUNHE_TREATY', {
        accountId: 'SECT_ORTHODOX',
        originEventId: 'sect:archive:FACT_21:SECT_ORTHODOX',
        sourceKind: 'library_stele'
      });
    } else {
      // Junior disciples start with the folk/campus rumor about the wooden sword & empty chair or a path-linked fact
      const pathFacts = CANON_FACTS.filter(f => !f.secretGate && pathId && Array.isArray(f.relatedPaths) && f.relatedPaths.includes(pathId));
      const f2 = pathFacts[0] || FACT_BY_ID.FACT_07_GEN7_WOODEN_SWORD_AND_EMPTY_CHAIR;
      if (f2) {
        getCOG().learnLoreFact(W, npc, f2.id, {
          accountId: 'FOLK_ORAL',
          originEventId: 'campus:rumor:' + f2.id + ':FOLK_ORAL',
          sourceKind: 'conversation',
          storyId: f2.storyId
        });
      }
    }
  };

  function routeLegKey(a, b) {
    return a < b ? (a + '::' + b) : (b + '::' + a);
  }

  function applyStoryResolutionEffects(W, npc, storyDef, storyState, branch) {
    if (!W || !storyDef || !branch) return;
    const ll = X.initLivingLore(W);
    const eff = branch.effect || {};
    const state = W.world && W.world.continent;

    if (Array.isArray(eff.routeBonusLeg) && eff.routeBonusLeg.length === 2) {
      const k = routeLegKey(eff.routeBonusLeg[0], eff.routeBonusLeg[1]);
      ll.routeModifiers[k] = {
        legKey: k,
        from: eff.routeBonusLeg[0],
        to: eff.routeBonusLeg[1],
        multiplier: clamp(Number(eff.routeMultiplier) || 0.88, 0.72, 1.25),
        storyId: storyDef.id,
        labelTh: branch.labelTh,
        sinceDay: W.day || 0
      };
    }

    if (state && state.cities) {
      for (const nodeId of (storyDef.anchorNodeIds || [])) {
        const cStats = state.cities[nodeId];
        if (!cStats) continue;
        if (eff.citySafetyDelta) cStats.safety = clamp(cStats.safety + eff.citySafetyDelta, 20, 98);
        if (eff.cityProsperityDelta) cStats.prosperity = clamp(cStats.prosperity + eff.cityProsperityDelta, 20, 98);
      }
    }

    if (eff.customId) {
      ll.adoptedCustoms[eff.customId] = {
        id: eff.customId,
        storyId: storyDef.id,
        labelTh: branch.labelTh,
        consequenceTh: branch.consequenceTh,
        adoptedByNpcId: npc ? npc.id : null,
        adoptedDay: W.day || 0
      };
      if (npc && getCOG() && getCOG().ensureLoreState) {
        const nLore = getCOG().ensureLoreState(npc);
        if (nLore && !nLore.adoptedCustoms.includes(eff.customId)) {
          nLore.adoptedCustoms.push(eff.customId);
        }
      }
    }

    if (eff.closedLoopStonesFromPool && getECO() && typeof getECO().ReceiveExternalStones === 'function') {
      const poolAvail = (W.world && W.world.resourcePool && W.world.resourcePool.stones) || 0;
      const amt = Math.min(poolAvail, Math.max(0, Math.round(eff.closedLoopStonesFromPool)));
      if (amt > 0) {
        getECO().ReceiveExternalStones(W, amt, 'living_lore:' + storyDef.id);
      }
    }

    if (eff.mealGrant && W.sect && W.sect.stock) {
      W.sect.stock.meal = (W.sect.stock.meal || 0) + Math.max(1, Math.round(eff.mealGrant));
    }

    if (eff.sectFameDelta && W.sect) {
      W.sect.fame = Math.max(0, (W.sect.fame || 0) + eff.sectFameDelta);
    }

    if (eff.originEchoesDelta && W.sect) {
      W.sect.originEchoes = (W.sect.originEchoes || 0) + eff.originEchoesDelta;
    }

    if (eff.regaliaVector && getSECT() && getSECT().PATRIARCH_REGALIA && getSECT().PATRIARCH_REGALIA.advanceAwakening) {
      const master = (W.byId && W.sect && W.byId[W.sect.masterId]) || npc;
      getSECT().PATRIARCH_REGALIA.advanceAwakening(W, master, eff.regaliaVector, eff.regaliaAmount || 1);
    }

    if (npc && !npc.dead) {
      if (eff.skillPractice && HC.practice) {
        HC.practice(npc, eff.skillPractice, 0.45, 1.15);
      }
      if (eff.cultGain && npc.cult && getCULT() && getCULT().gain) {
        getCULT().gain(npc, eff.cultGain, W, 'living_lore_insight');
      }
      if (eff.heartDemonDelta && npc.h && npc.h.state) {
        npc.h.state.heartDemon = clamp((npc.h.state.heartDemon || 0) + eff.heartDemonDelta, 0, 100);
      }
      if (eff.moodDelta || eff.lonelinessDelta) {
        HC.feel(npc, { mood: eff.moodDelta || 0, loneliness: eff.lonelinessDelta || 0 });
      }
      if (eff.petBondBonus && Array.isArray(npc.pets)) {
        npc.pets.forEach(p => {
          if (p) p.bond = clamp((p.bond || 50) + eff.petBondBonus, 0, 100);
        });
      }
    }
  }

  // Advance or resolve a multi-stage Living Lore story chain through real NPC action
  X.advanceLivingLoreStory = (W, npc, storyId, opts) => {
    opts = opts || {};
    if (!W || !W.world || !storyId) return { ok: false, reason: 'invalid-args' };
    const ll = X.initLivingLore(W);
    const storyDef = STORY_BY_ID[storyId];
    if (!storyDef) return { ok: false, reason: 'unknown-story' };
    const st = ll.stories[storyId];
    if (!st) return { ok: false, reason: 'missing-story-state' };
    if (st.status === 'resolved' && !opts.allowReplay) {
      return { ok: false, reason: 'already-resolved', story: st };
    }

    const actor = npc || (W.byId && W.sect && W.byId[W.sect.masterId]) || (W.npcs && W.npcs[0]);
    if (!actor || actor.dead) return { ok: false, reason: 'no-living-actor' };

    const curIdx = st.status === 'dormant' ? 0 : clamp((st.stageIdx || 0) + 1, 0, storyDef.stages.length - 1);
    const stageDef = storyDef.stages[curIdx] || storyDef.stages[storyDef.stages.length - 1];
    const locNode = (stageDef && stageDef.locationId && X.SETTLEMENTS && X.SETTLEMENTS[stageDef.locationId])
      || (storyDef.anchorNodeIds && storyDef.anchorNodeIds[0] && X.SETTLEMENTS && X.SETTLEMENTS[storyDef.anchorNodeIds[0]])
      || null;
    const locSnap = locNode ? { nodeId: locNode.id, nameTh: locNode.nameTh, x: locNode.x, y: locNode.y, macroRegion: locNode.macroRegion } : null;

    const originEventId = opts.originEventId || ('story:' + storyId + ':stage:' + curIdx + ':day:' + (W.day || 0) + ':' + (locNode ? locNode.id : 'sect'));
    if (!st.evidenceLineages.includes(originEventId)) {
      st.evidenceLineages.push(originEventId);
    }
    if (!st.leadNpcIds.includes(actor.id)) st.leadNpcIds.push(actor.id);
    const witnessIds = Array.isArray(opts.witnessIds) && opts.witnessIds.length ? opts.witnessIds : [actor.id];
    for (const wid of witnessIds) {
      if (wid && !st.witnessIds.includes(wid) && st.witnessIds.length < 12) st.witnessIds.push(wid);
    }

    st.stageIdx = curIdx;
    if (st.sparkedDay == null) st.sparkedDay = W.day || 0;

    // Teach the linked lore fact at this stage's epistemic account to all witnesses
    const learnAccount = (curIdx >= storyDef.stages.length - 1)
      ? 'VERIFIED_CHRONICLE'
      : (stageDef && stageDef.accountId) || 'FOLK_ORAL';
    const isPhysical = curIdx >= 1 || ['city_ledger', 'library_stele', 'item_inscription', 'ancestral_plaque', 'expedition_witness'].includes(opts.sourceKind);

    for (const wid of witnessIds) {
      const wNpc = W.byId && W.byId[wid];
      if (wNpc && !wNpc.dead && getCOG() && getCOG().learnLoreFact) {
        getCOG().learnLoreFact(W, wNpc, storyDef.factId, {
          accountId: learnAccount,
          originEventId,
          sourceKind: opts.sourceKind || (curIdx === 0 ? 'city_visit' : curIdx === 1 ? 'city_ledger' : 'expedition_witness'),
          storyId: storyDef.id,
          physicalProof: isPhysical
        });
      }
    }

    if (curIdx < storyDef.stages.length - 1) {
      st.status = curIdx === 0 ? 'active' : 'contested';
      const histText = HC.fullName(actor) + ' ' + stageDef.titleTh + (locNode ? (' ณ ' + locNode.nameTh) : '');
      st.history.push({ day: W.day || 0, t: W.t || 0, stageIdx: curIdx, actorId: actor.id, locationId: locNode ? locNode.id : null, textTh: histText });
      if (st.history.length > 10) st.history.shift();

      if (getAI() && getAI().mem) {
        getAI().mem(W, actor, stageDef.titleTh + ' (' + storyDef.titleTh + ')', 0.65);
      }

      if (X.recordChronicle && !opts.silentChronicle) {
        X.recordChronicle(W, {
          eventKey: 'living_lore:' + storyId + ':s' + curIdx + ':' + (W.day || 0),
          category: 'LEGEND',
          reportFormat: curIdx === 0 ? 'TAVERN_BALLAD' : 'TRAVELOGUE_CHRONICLE',
          isRumor: curIdx === 0,
          unverified: curIdx < 2,
          epistemicStatus: curIdx === 0 ? 'RUMOR' : 'CONTESTED',
          icon: curIdx === 0 ? '📜' : '🔍',
          titleTh: '【เบาะแสตำนานมีชีวิต】' + storyDef.titleTh + ' · ' + stageDef.titleTh,
          storyTh: HC.fullName(actor) + ' ' + stageDef.descTh,
          originCauseTh: 'การสืบค้นและเปรียบเทียบคำบอกเล่าในโลกยุทธภพ (' + storyDef.titleTh + ')',
          consequenceTh: curIdx === 0 ? 'ยังเป็นคำบอกเล่าขั้นต้น รอการสอบทานหลักฐานสายที่สอง' : 'พบหลักฐานสองกระแสที่ต้องตัดสินใจสรุปผล',
          macroRegion: (locNode && locNode.macroRegion) || 'CENTRAL_HEARTLAND',
          location: locSnap,
          actorIds: witnessIds,
          storyThreadId: 'lore:' + storyDef.id,
          quiet: true
        });
      }

      return { ok: true, resolved: false, stageIdx: curIdx, status: st.status, story: st };
    }

    // Final stage (Stage 2): select personality/role-matched resolution branch!
    const branches = storyDef.resolutions || [];
    const chosenBranch = (opts.resolutionId && branches.find(b => b.id === opts.resolutionId))
      || branches.find(b => typeof b.match === 'function' && b.match(actor, W))
      || branches[branches.length - 1];

    st.status = 'resolved';
    st.resolvedDay = W.day || 0;
    st.resolutionId = chosenBranch ? chosenBranch.id : 'DEFAULT_RESOLUTION';
    st.resolutionLabelTh = chosenBranch ? chosenBranch.labelTh : 'สรุปบันทึกเข้าหอคัมภีร์';
    st.resolutionConsequenceTh = chosenBranch ? chosenBranch.consequenceTh : 'บันทึกความจริงลงในพงศาวดารสำนัก';

    const resHistText = HC.fullName(actor) + ' คลี่คลาย「' + storyDef.titleTh + '」: ' + st.resolutionLabelTh;
    st.history.push({ day: W.day || 0, t: W.t || 0, stageIdx: curIdx, actorId: actor.id, locationId: locNode ? locNode.id : null, textTh: resHistText, resolved: true });
    if (st.history.length > 10) st.history.shift();

    // Remove from activeLeads of witnesses once resolved
    for (const wid of st.witnessIds) {
      const wNpc = W.byId && W.byId[wid];
      const wLore = wNpc && getCOG() && getCOG().peekLoreState ? getCOG().peekLoreState(wNpc) : null;
      if (wLore && Array.isArray(wLore.activeLeads)) {
        wLore.activeLeads = wLore.activeLeads.filter(id => id !== storyId);
      }
    }

    applyStoryResolutionEffects(W, actor, storyDef, st, chosenBranch);

    // Compile the verified fact to the Sect Lore Archive
    X.compileLoreToSectArchive(W, actor, storyDef.factId, { storyId: storyDef.id, quiet: true });

    if (getAI() && getAI().mem) {
      getAI().mem(W, actor, 'พิสูจน์ความจริงเรื่อง「' + storyDef.titleTh + '」และตัดสินใจ: ' + st.resolutionLabelTh, 0.85);
    }

    if (X.recordChronicle && !opts.silentChronicle) {
      X.recordChronicle(W, {
        eventKey: 'living_lore:' + storyId + ':resolved:' + (W.day || 0),
        category: 'LEGEND',
        reportFormat: 'SECT_STELE_INSCRIPTION',
        isRumor: false,
        unverified: false,
        epistemicStatus: 'VERIFIED',
        milestone: true,
        icon: '🏛️',
        titleTh: '【คลี่คลายตำนานมีชีวิต】' + storyDef.titleTh + ' — ' + st.resolutionLabelTh,
        storyTh: HC.fullName(actor) + ' สอบทานหลักฐานจนพิสูจน์ความจริงของ「' + storyDef.titleTh + '」และดำเนินการ: ' + st.resolutionLabelTh,
        originCauseTh: storyDef.summaryTh,
        consequenceTh: st.resolutionConsequenceTh,
        macroRegion: (locNode && locNode.macroRegion) || 'CENTRAL_HEARTLAND',
        location: locSnap,
        actorIds: witnessIds,
        storyThreadId: 'lore:' + storyDef.id,
        quiet: false
      });
    }

    return {
      ok: true,
      resolved: true,
      stageIdx: curIdx,
      status: st.status,
      resolutionId: st.resolutionId,
      resolutionLabelTh: st.resolutionLabelTh,
      consequenceTh: st.resolutionConsequenceTh,
      story: st
    };
  };

  // Compile a verified lore fact into the Sect Archive (`W.sect.loreArchive`)
  X.compileLoreToSectArchive = (W, npc, factId, opts) => {
    opts = opts || {};
    if (!W || !W.sect || !factId) return { ok: false, reason: 'invalid-args' };
    const ll = X.initLivingLore(W);
    const factDef = FACT_BY_ID[factId];
    if (!factDef) return { ok: false, reason: 'unknown-fact' };

    if (!Array.isArray(W.sect.loreArchive)) W.sect.loreArchive = [];
    const already = W.sect.loreArchive.includes(factId);
    if (!already) {
      W.sect.loreArchive.push(factId);
    }
    if (ll.facts[factId]) {
      ll.facts[factId].discovered = true;
      ll.facts[factId].archivedInSect = true;
      ll.facts[factId].status = 'verified';
      if (!ll.facts[factId].knownAccounts.includes('VERIFIED_CHRONICLE')) {
        ll.facts[factId].knownAccounts.push('VERIFIED_CHRONICLE');
      }
    }

    // Share with key sect officers (Scripture Elder, Spymaster, Sect Master)
    const officers = [
      getSECT() && getSECT().holder ? getSECT().holder(W, 'scripture') : null,
      getSECT() && getSECT().holder ? getSECT().holder(W, 'spymaster') : null,
      W.byId && W.sect.masterId ? W.byId[W.sect.masterId] : null
    ].filter(Boolean);

    const originEventId = 'archive_compile:' + factId + ':' + (npc ? npc.id : 'sect');
    officers.forEach(off => {
      if (!off.dead && getCOG() && getCOG().learnLoreFact) {
        getCOG().learnLoreFact(W, off, factId, {
          accountId: 'VERIFIED_CHRONICLE',
          originEventId,
          sourceKind: 'library_stele',
          fromId: npc ? npc.id : null,
          fromNameTh: npc ? HC.fullName(npc) : 'หอคัมภีร์',
          physicalProof: true
        });
      }
    });

    if (npc && !npc.dead && HC.practice) {
      HC.practice(npc, 'SCRIPTURE', 0.30, 1.1);
    }
    return { ok: true, factId, newlyArchived: !already };
  };

  // Triggered whenever an NPC party arrives at a settlement on a city_visit
  X.onCityVisitLore = (W, ex, members) => {
    if (!W || !ex || !Array.isArray(members) || !members.length) return null;
    const ll = X.initLivingLore(W);
    const cityId = ex.targetNodeId || ex.region;
    const city = X.SETTLEMENTS && X.SETTLEMENTS[cityId];
    if (!city) return null;

    const leader = members[0];
    const witnessIds = members.map(m => m.id);

    // 1. Check if any story chain is anchored at this city and not yet resolved
    const anchoredStories = STORY_CHAINS.filter(s => Array.isArray(s.anchorNodeIds) && s.anchorNodeIds.includes(city.id));
    for (const sDef of anchoredStories) {
      const st = ll.stories[sDef.id];
      if (!st || st.status === 'resolved') continue;
      // Check if any member has this story as an active lead or if it's dormant
      const hasLead = members.some(m => {
        const ml = getCOG() && getCOG().peekLoreState ? getCOG().peekLoreState(m) : null;
        return ml && Array.isArray(ml.activeLeads) && ml.activeLeads.includes(sDef.id);
      });
      if (hasLead || st.status === 'dormant' || st.status === 'active') {
        return X.advanceLivingLoreStory(W, leader, sDef.id, {
          witnessIds,
          sourceKind: st.status === 'dormant' ? 'city_visit' : 'city_ledger',
          originEventId: 'city_visit:' + city.id + ':' + sDef.id + ':stage:' + (st.stageIdx || 0)
        });
      }
    }

    // 2. Otherwise, learn a local lore fact anchored at this settlement or polity
    const localFacts = CANON_FACTS.filter(f =>
      (Array.isArray(f.anchorNodeIds) && f.anchorNodeIds.includes(city.id)) ||
      (city.polityId && f.polityId === city.polityId && !f.secretGate)
    );
    if (localFacts.length) {
      const f = localFacts[((W.day || 0) + city.order) % localFacts.length];
      const isAcademyOrCapital = city.specialty === 'academy' || city.tier >= 4;
      const acc = isAcademyOrCapital ? 'COURT_CANON' : 'FOLK_ORAL';
      const originEventId = 'visit_stele:' + city.id + ':' + f.id + ':' + acc;
      for (const m of members) {
        if (getCOG() && getCOG().learnLoreFact) {
          getCOG().learnLoreFact(W, m, f.id, {
            accountId: acc,
            originEventId,
            sourceKind: isAcademyOrCapital ? 'city_ledger' : 'city_visit',
            storyId: f.storyId,
            physicalProof: isAcademyOrCapital
          });
        }
      }
      return { ok: true, learnedFactId: f.id, accountId: acc, cityId: city.id };
    }
    return null;
  };

  // Daily/Periodic Living Lore Simulation Tick (emergent slice-of-life & lore events from world activity)
  X.tickLivingLore = W => {
    if (!W || !W.world || !W.sect) return;
    const ll = X.initLivingLore(W);
    const day = W.day || 0;
    if (day <= ll.lastTickDay) return;
    ll.lastTickDay = day;

    const livingNpcs = (W.npcs || []).filter(n => n && !n.dead && !n.exiled);
    if (!livingNpcs.length) return;

    // 1. Check for natural emergent lore / slice-of-life spark every 4 days based on real sect/world activity
    if (day >= (ll.lastEmergentDay || 0) + 4) {
      const candidateTemplates = EMERGENT_LORE_EVENTS.filter(ev => {
        const st = ev.storyId ? ll.stories[ev.storyId] : null;
        return !st || st.status !== 'resolved';
      });
      if (candidateTemplates.length) {
        const tpl = candidateTemplates[(day + (ll.eventSeq || 0)) % candidateTemplates.length];
        // Pick real witnesses currently doing matching activities or residing in sect
        const homeNpcs = livingNpcs.filter(n => !n.away);
        const witnesses = (homeNpcs.length ? homeNpcs : livingNpcs).slice(0, 2);
        const lead = witnesses[0];
        if (lead) {
          ll.lastEmergentDay = day;
          ll.eventSeq = (ll.eventSeq || 0) + 1;
          const originEventId = 'emergent:' + tpl.id + ':day:' + day;
          for (const wNpc of witnesses) {
            if (getCOG() && getCOG().learnLoreFact) {
              getCOG().learnLoreFact(W, wNpc, tpl.factId, {
                accountId: 'FOLK_ORAL',
                originEventId,
                sourceKind: tpl.kind === 'SLICE_OF_LIFE' ? 'workshop_practice' : 'visitor_rumor',
                storyId: tpl.storyId
              });
            }
          }
          if (tpl.storyId && ll.stories[tpl.storyId] && ll.stories[tpl.storyId].status === 'dormant') {
            X.advanceLivingLoreStory(W, lead, tpl.storyId, {
              witnessIds: witnesses.map(x => x.id),
              originEventId,
              sourceKind: 'visitor_rumor',
              silentChronicle: true
            });
          }
          const locNode = tpl.nodeId && X.SETTLEMENTS ? X.SETTLEMENTS[tpl.nodeId] : null;
          const locSnap = locNode ? { nodeId: locNode.id, nameTh: locNode.nameTh, x: locNode.x, y: locNode.y, macroRegion: locNode.macroRegion } : null;
          const evRec = {
            id: 'll_ev_' + ll.eventSeq,
            day,
            templateId: tpl.id,
            factId: tpl.factId,
            storyId: tpl.storyId,
            titleTh: tpl.titleTh,
            storyTh: tpl.storyTh,
            witnessIds: witnesses.map(x => x.id),
            location: locSnap
          };
          ll.recentEvents.push(evRec);
          if (ll.recentEvents.length > 18) ll.recentEvents.shift();

          if (X.recordChronicle) {
            X.recordChronicle(W, {
              eventKey: 'living_lore_emergent:' + tpl.id + ':' + day,
              category: tpl.kind === 'SLICE_OF_LIFE' ? 'LIFE' : 'LEGEND',
              reportFormat: tpl.kind === 'SLICE_OF_LIFE' ? 'TEAHOUSE_GOSSIP' : 'TAVERN_BALLAD',
              isRumor: tpl.kind !== 'SLICE_OF_LIFE',
              unverified: true,
              icon: tpl.kind === 'SLICE_OF_LIFE' ? '🍵' : '📜',
              titleTh: tpl.titleTh,
              storyTh: tpl.storyTh,
              originCauseTh: tpl.originCauseTh,
              consequenceTh: tpl.consequenceTh,
              macroRegion: (locNode && locNode.macroRegion) || 'CENTRAL_HEARTLAND',
              location: locSnap,
              actorIds: witnesses.map(x => x.id),
              storyThreadId: tpl.storyId ? ('lore:' + tpl.storyId) : ('fact:' + tpl.factId),
              quiet: true
            });
          }
        }
      }
    }

    // 2. Unlock Layer 3 / Layer 4 deep truths organically when sufficient Layer 2 / Sanctum / Regalia milestones exist
    const reg = W.sect.patriarchRegalia;
    const master = W.byId && W.sect.masterId ? W.byId[W.sect.masterId] : null;
    if (master && !master.dead && reg && (reg.awakeningStage >= 2 || (W.sect.originEchoes || 0) >= 2)) {
      const f28 = ll.facts.FACT_28_NAMELESS_FOUNDER_UPPER_WORLD_VIGIL;
      if (f28 && !f28.discovered) {
        getCOG().learnLoreFact(W, master, 'FACT_28_NAMELESS_FOUNDER_UPPER_WORLD_VIGIL', {
          accountId: reg.awakeningStage >= 3 ? 'VERIFIED_CHRONICLE' : 'SECT_ORTHODOX',
          originEventId: 'regalia_resonance:stage:' + reg.awakeningStage,
          sourceKind: 'ancestral_plaque',
          physicalProof: reg.awakeningStage >= 3
        });
      }
    }
  };

  // Pure Read-Only Views for UI (0 RNG, 0 State Mutation!)
  X.getLivingLorePlayerView = (W, opts) => {
    opts = opts || {};
    const ll = W && W.world && W.world.livingLore;
    const archiveIds = (W && W.sect && Array.isArray(W.sect.loreArchive)) ? W.sect.loreArchive : [];

    const layers = Object.values(EPISTEMIC_LAYERS).map(layer => {
      const layerFacts = CANON_FACTS.filter(f => f.layer === layer.id).map(f => {
        const wf = ll && ll.facts && ll.facts[f.id];
        const discovered = !!(opts.debugRevealAll || (wf && wf.discovered) || archiveIds.includes(f.id));
        const veiled = !!(f.secretGate && !discovered);
        const status = wf ? wf.status : 'undiscovered';
        const knownAccIds = (wf && Array.isArray(wf.knownAccounts) && wf.knownAccounts.length)
          ? wf.knownAccounts
          : (discovered ? [f.defaultAccount || 'FOLK_ORAL'] : []);
        const visibleAccounts = veiled
          ? []
          : knownAccIds.map(aid => f.accounts[aid]).filter(Boolean);
        return {
          id: f.id,
          titleTh: veiled ? '🔒 ความลับที่ยังไม่มีศิษย์ค้นพบ (' + layer.shortTh + ')' : f.titleTh,
          layer: f.layer,
          category: f.category,
          polityId: f.polityId,
          anchorNodeIds: veiled ? [] : (f.anchorNodeIds || []).slice(),
          discovered,
          veiled,
          status,
          archivedInSect: archiveIds.includes(f.id),
          knownAccounts: visibleAccounts,
          evidenceLineageCount: wf && Array.isArray(wf.evidenceLineages) ? wf.evidenceLineages.length : 0,
          storyId: f.storyId || null
        };
      });
      return {
        id: layer.id,
        order: layer.order,
        nameTh: layer.nameTh,
        shortTh: layer.shortTh,
        descTh: layer.descTh,
        secretGate: layer.secretGate,
        discoveredCount: layerFacts.filter(f => f.discovered).length,
        totalCount: layerFacts.length,
        facts: layerFacts
      };
    });

    const stories = STORY_CHAINS.map(s => {
      const st = (ll && ll.stories && ll.stories[s.id]) || { stageIdx: 0, status: 'dormant', witnessIds: [], history: [] };
      const wf = ll && ll.facts && ll.facts[s.factId];
      const factDef = FACT_BY_ID[s.factId];
      const veiled = !!(factDef && factDef.secretGate && st.status === 'dormant' && !(wf && wf.discovered) && !opts.debugRevealAll);
      const curStage = s.stages[clamp(st.stageIdx || 0, 0, s.stages.length - 1)];
      const locNode = (curStage && curStage.locationId && X.SETTLEMENTS && X.SETTLEMENTS[curStage.locationId])
        || (s.anchorNodeIds && s.anchorNodeIds[0] && X.SETTLEMENTS && X.SETTLEMENTS[s.anchorNodeIds[0]])
        || null;
      return {
        id: s.id,
        titleTh: veiled ? '🔒 เรื่องราวเร้นลับที่รอผู้ค้นพบ' : s.titleTh,
        group: s.group,
        category: s.category,
        layer: s.layer,
        factId: s.factId,
        polityId: s.polityId,
        anchorNodeIds: veiled ? [] : s.anchorNodeIds.slice(),
        locationNode: veiled ? null : locNode,
        summaryTh: veiled ? 'ยังไม่มีศิษย์หรือสายข่าวในสำนักไปพบเบาะแสของเรื่องราวนี้' : s.summaryTh,
        status: st.status || 'dormant',
        stageIdx: st.stageIdx || 0,
        totalStages: s.stages.length,
        currentStageTitleTh: veiled ? 'รอการค้นพบ' : (curStage ? curStage.titleTh : ''),
        currentStageDescTh: veiled ? '' : (curStage ? curStage.descTh : ''),
        resolutionId: st.resolutionId || null,
        resolutionLabelTh: st.resolutionLabelTh || null,
        resolutionConsequenceTh: st.resolutionConsequenceTh || null,
        witnessNamesTh: (st.witnessIds || []).map(id => (W && W.byId && W.byId[id] && HC.fullName(W.byId[id])) || null).filter(Boolean),
        history: (st.history || []).slice(-4)
      };
    });

    return {
      version: '3.1.0-living-lore',
      layers,
      stories,
      fallenDynasties: Object.values(FALLEN_DYNASTIES_ARCHIVE),
      archivedCount: archiveIds.length,
      activeStoriesCount: stories.filter(s => s.status === 'active' || s.status === 'contested').length,
      resolvedStoriesCount: stories.filter(s => s.status === 'resolved').length,
      adoptedCustoms: ll ? Object.values(ll.adoptedCustoms || {}) : [],
      routeModifiers: ll ? Object.values(ll.routeModifiers || {}) : [],
      recentEvents: ll ? (ll.recentEvents || []).slice(-6).reverse() : []
    };
  };

  // Pure Read-Only Settlement Lore View for Atlas Popup & City Details (0 RNG, 0 State Mutation)
  X.getSettlementLoreView = (W, nodeId) => {
    if (!nodeId) return null;
    const ll = W && W.world && W.world.livingLore;
    const archiveIds = (W && W.sect && Array.isArray(W.sect.loreArchive)) ? W.sect.loreArchive : [];

    const fallen = Object.values(FALLEN_DYNASTIES_ARCHIVE).filter(d => Array.isArray(d.anchorNodeIds) && d.anchorNodeIds.includes(nodeId));
    const facts = CANON_FACTS.filter(f => Array.isArray(f.anchorNodeIds) && f.anchorNodeIds.includes(nodeId)).map(f => {
      const wf = ll && ll.facts && ll.facts[f.id];
      const discovered = !!((wf && wf.discovered) || archiveIds.includes(f.id));
      if (f.secretGate && !discovered) return null;
      const topAccId = (wf && wf.status === 'verified')
        ? 'VERIFIED_CHRONICLE'
        : ((wf && Array.isArray(wf.knownAccounts) && wf.knownAccounts[wf.knownAccounts.length - 1]) || f.defaultAccount || 'FOLK_ORAL');
      const acc = f.accounts[topAccId] || f.accounts.FOLK_ORAL;
      return {
        id: f.id,
        titleTh: f.titleTh,
        status: (wf && wf.status) || 'rumor',
        accountLabelTh: acc ? acc.labelTh : '',
        summaryTh: acc ? acc.summaryTh : ''
      };
    }).filter(Boolean);

    const stories = STORY_CHAINS.filter(s => Array.isArray(s.anchorNodeIds) && s.anchorNodeIds.includes(nodeId)).map(s => {
      const st = (ll && ll.stories && ll.stories[s.id]) || { status: 'dormant', stageIdx: 0 };
      const factDef = FACT_BY_ID[s.factId];
      const wf = ll && ll.facts && ll.facts[s.factId];
      if (factDef && factDef.secretGate && st.status === 'dormant' && !(wf && wf.discovered)) return null;
      return {
        id: s.id,
        titleTh: s.titleTh,
        status: st.status || 'dormant',
        stageIdx: st.stageIdx || 0,
        totalStages: s.stages.length,
        resolutionLabelTh: st.resolutionLabelTh || null
      };
    }).filter(Boolean);

    return { nodeId, fallenDynasties: fallen, facts, stories };
  };

  // Pure Read-Only Polity Lore View for UI.rPolities (0 RNG, 0 State Mutation)
  X.getPolityLoreView = (W, polityId) => {
    if (!polityId) return null;
    const ll = W && W.world && W.world.livingLore;
    const archiveIds = (W && W.sect && Array.isArray(W.sect.loreArchive)) ? W.sect.loreArchive : [];

    const fallen = Object.values(FALLEN_DYNASTIES_ARCHIVE).filter(d => Array.isArray(d.successorPolityIds) && d.successorPolityIds.includes(polityId));
    const facts = CANON_FACTS.filter(f => f.polityId === polityId).map(f => {
      const wf = ll && ll.facts && ll.facts[f.id];
      const discovered = !!((wf && wf.discovered) || archiveIds.includes(f.id));
      if (f.secretGate && !discovered) return null;
      const topAccId = (wf && wf.status === 'verified')
        ? 'VERIFIED_CHRONICLE'
        : ((wf && Array.isArray(wf.knownAccounts) && wf.knownAccounts[wf.knownAccounts.length - 1]) || f.defaultAccount || 'FOLK_ORAL');
      const acc = f.accounts[topAccId] || f.accounts.FOLK_ORAL;
      return {
        id: f.id,
        titleTh: f.titleTh,
        status: (wf && wf.status) || 'rumor',
        accountLabelTh: acc ? acc.labelTh : '',
        summaryTh: acc ? acc.summaryTh : ''
      };
    }).filter(Boolean);

    const stories = STORY_CHAINS.filter(s => s.polityId === polityId).map(s => {
      const st = (ll && ll.stories && ll.stories[s.id]) || { status: 'dormant', stageIdx: 0 };
      const factDef = FACT_BY_ID[s.factId];
      const wf = ll && ll.facts && ll.facts[s.factId];
      if (factDef && factDef.secretGate && st.status === 'dormant' && !(wf && wf.discovered)) return null;
      return {
        id: s.id,
        titleTh: s.titleTh,
        status: st.status || 'dormant',
        stageIdx: st.stageIdx || 0,
        totalStages: s.stages.length,
        resolutionLabelTh: st.resolutionLabelTh || null
      };
    }).filter(Boolean);

    return { polityId, fallenDynasties: fallen, facts, stories };
  };

  // Hook X.initContinent so every initialized continent also initializes Living Lore
  const _origInitContinentLore = X.initContinent;
  X.initContinent = W => {
    const res = _origInitContinentLore ? _origInitContinentLore(W) : undefined;
    X.initLivingLore(W);
    return res;
  };

  // Hook X.tickContinentalCourts to also tick Living Lore
  const _origTickCourtsLore = X.tickContinentalCourts;
  X.tickContinentalCourts = W => {
    const res = _origTickCourtsLore ? _origTickCourtsLore(W) : undefined;
    X.tickLivingLore(W);
    return res;
  };

  // Hook X.planContinentalRoute so verified route lore modifiers (STORY_01, STORY_04, STORY_08, STORY_09, STORY_12, STORY_17, STORY_18) causally affect route travel days
  const _origPlanRouteLore = X.planContinentalRoute;
  X.planContinentalRoute = (W, topo, target, fromId) => {
    const route = _origPlanRouteLore ? _origPlanRouteLore(W, topo, target, fromId) : null;
    if (!route || !Array.isArray(route.legs) || !route.legs.length) return route;
    const mods = W && W.world && W.world.livingLore && W.world.livingLore.routeModifiers;
    if (!mods || !Object.keys(mods).length) return route;
    let totalDays = 0;
    for (const leg of route.legs) {
      const k = routeLegKey(leg.from, leg.to);
      const m = mods[k];
      if (m && Number.isFinite(m.multiplier)) {
        leg.days = +(leg.days * m.multiplier).toFixed(4);
        leg.loreModifierStoryId = m.storyId;
      }
      totalDays += leg.days;
    }
    route.days = totalDays;
    return route;
  };

  // Hook X.cityVisitDrive so NPCs carrying active lore leads at reachable settlements gain extra curiosity motivation
  const _origCityVisitDriveLore = X.cityVisitDrive;
  X.cityVisitDrive = (W, npc) => {
    const base = _origCityVisitDriveLore ? _origCityVisitDriveLore(W, npc) : 0;
    if (!base || !npc) return base;
    const nLore = getCOG() && getCOG().peekLoreState ? getCOG().peekLoreState(npc) : null;
    if (nLore && Array.isArray(nLore.activeLeads) && nLore.activeLeads.length > 0) {
      const boost = Math.min(0.35, nLore.activeLeads.length * 0.12 * (E(npc, 'personality.curiosity') / 60));
      return clamp(base + boost, 0.1, 1.95);
    }
    return base;
  };


  /* ============================================================================
   * JS2 v3.4.0: 40 External World Random Events & Living Lore Cross-Links
   * (10 Categories · 100% Autonomous NPC Resolution · Zero-RNG Daily Spawn)
   * ============================================================================ */
  function detHash340(str) {
    let h = 2166136261 >>> 0;
    const s = String(str || '');
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  }

  const EXT_EVENT_CATEGORIES = Object.freeze({
    ANCIENT_WAR_RUINS: { id: 'ANCIENT_WAR_RUINS', nameTh: 'มรดกมหาสงครามโบราณและซากเทียนกู่', order: 1 },
    THREE_EMPIRES_POLITICS: { id: 'THREE_EMPIRES_POLITICS', nameTh: 'การเมืองและศึกตัวแทน 3 มหาอำนาจ', order: 2 },
    CELESTIAL_ANOMALIES: { id: 'CELESTIAL_ANOMALIES', nameTh: 'ปรากฏการณ์ฟ้าดินวิปริตและรอยแยกม่านภพ', order: 3 },
    WANDERING_JIANGHU_TRADE: { id: 'WANDERING_JIANGHU_TRADE', nameTh: 'ยุทธภพพเนจร การค้า ตลาดมืด และโรงเตี๊ยม', order: 4 },
    BEAST_ECOLOGY_KINGS: { id: 'BEAST_ECOLOGY_KINGS', nameTh: 'นิเวศวิทยาสัตว์อสูรและราชันอสูร', order: 5 },
    HIDDEN_DESTINY_LEGENDS: { id: 'HIDDEN_DESTINY_LEGENDS', nameTh: 'วาสนาลับและบุคคลในตำนานชุดแรก', order: 6 },
    ANCIENT_GENERALS_ENEMIES: { id: 'ANCIENT_GENERALS_ENEMIES', nameTh: 'ปฐมบรรพชน ขุนพลโบราณ และตัวแปรจากอาณาจักรศัตรู', order: 7 },
    HERMIT_ARTISAN_MASTERS: { id: 'HERMIT_ARTISAN_MASTERS', nameTh: 'ยอดปราชญ์สายอาชีพและปรมาจารย์เร้นกายยุคโบราณ', order: 8 },
    CHAOS_ERA_HEROES: { id: 'CHAOS_ERA_HEROES', nameTh: 'มหาราชาผู้โศกเศร้าและยอดคนแห่งยุคกลียุคหมื่นราชวงศ์', order: 9 },
    MODERN_EMPIRES_GATEKEEPER: { id: 'MODERN_EMPIRES_GATEKEEPER', nameTh: 'ตัวละครเอกยุคปัจจุบันของ 3 มหาอำนาจและปริศนาใต้สำนัก', order: 10 }
  });

  // Compact structured specification for all 40 events:
  // [no, id, cat, nameTh, figureTh, impact, days, prefPaths, rewardMatId, loreFactIdx, relicLinkId, storySync]
  const RAW_40_EVENTS = [
    [1, 'EXT_EVT_01_BLACK_CAVALRY', 'ANCIENT_WAR_RUINS', 'สุสานทหารม้าเกราะดำผุดกลางพายุทราย', 'แม่ทัพหานพัวจวิน (#11)', 'REGIONAL', 15, ['STRATEGY_GOVERNANCE', 'BUDDHA_DHARMA', 'ANCESTRAL_RITUAL', 'NETHER_GRAVE'], 'MAT_ORE_METEOR_IRON_5', 0, 'LEG_ACC_TAICHI_HEAVEN_SEAL', 'STORY-SYNC-05'],
    [2, 'EXT_EVT_02_CURSED_GOLD_VAULT', 'ANCIENT_WAR_RUINS', 'คลังทองคำต้องสาปของเสนาบดีฝ่ายขวาถล่ม', 'ราชันย์คลังมืด เหยียนกวง (#26)', 'REGIONAL', 14, ['MERCANTILE_DAO', 'FORTUNE_GAMBLER', 'BUDDHA_DHARMA'], 'MAT_ORE_QUICKSAND_SPIRIT_GOLD_4', 1, 'EQ_V320_TEMP_ABACUS_T6', null],
    [3, 'EXT_EVT_03_ENEMY_SKY_ARK', 'ANCIENT_WAR_RUINS', 'ซากสำเภาเวหาจากอาณาจักรศัตรูตกลงกลางหุบเขา', 'ขุนพลนาวาเวหาโบราณ', 'CONTINENTAL', 16, ['MECH_PUPPET', 'CRAFT_CREATION', 'TIDE_VOYAGER', 'ARRAY_TALISMAN'], 'MAT_FORM_SKY_LEVITATION_CORE_5', 2, 'EQ_V320_SHOES_T5', null],
    [4, 'EXT_EVT_04_BEIMING_PURGE', 'THREE_EMPIRES_POLITICS', 'พระราชโองการกวาดล้างมารแห่งเป่ยหมิง', 'ราชสำนักเป่ยหมิง (#46)', 'CONTINENTAL', 18, ['XIAN', 'BUDDHA_DHARMA', 'DEMON', 'STRATEGY_GOVERNANCE'], 'MAT_HERB_SNOW_LOTUS_5', 3, 'EQ_V320_SHOES_T7', 'STORY-SYNC-01'],
    [5, 'EXT_EVT_05_DONGHUANG_EMBARGO', 'THREE_EMPIRES_POLITICS', 'สงครามภาษีและการประมูลลับแห่งตงหวง', 'ตระกูลซือหม่า (#51/#52)', 'CONTINENTAL', 16, ['MERCANTILE_DAO', 'FORTUNE_GAMBLER', 'LORE_ARCHIVIST'], 'MAT_ORE_DIVINE_GOLD_6', 4, 'EQ_V320_SET_ARCH_BRUSH', 'STORY-SYNC-02'],
    [6, 'EXT_EVT_06_XIRONG_GAUNTLET', 'THREE_EMPIRES_POLITICS', 'เทียบเชิญประลองยุทธ์เลือดแห่งซีหรง', 'ตระกูลแม่ทัพทัวป๋า (#56/#60)', 'CONTINENTAL', 15, ['ARENA_GLORY', 'BODY', 'SHADOW_SAMURAI'], 'MAT_BP_TIGER_BLOOD_6', 5, 'EQ_V320_CURSED_SPEAR_T6', 'STORY-SYNC-05'],
    [7, 'EXT_EVT_07_WORLD_BARRIER_RIFT', 'CELESTIAL_ANOMALIES', 'รอยแยกม่านกั้นภพปริแตก — เศษเสี้ยวทัณฑ์สวรรค์', 'ผู้เหินหาวนิรนามโลกเบื้องบน', 'MYTHIC', 12, ['VOID_SPACE', 'ASTRO_DIVINATION', 'ARRAY_TALISMAN'], 'MAT_ORE_PRIMORDIAL_CRYSTAL_7', 6, 'EQ_V320_LORE_SWORD_T7', 'STORY-SYNC-12'],
    [8, 'EXT_EVT_08_BLOOD_MOON_DEMONS', 'CELESTIAL_ANOMALIES', 'คืนจันทร์สีเลือดและคลื่นจิตมารระบาด', 'คลื่นจิตมารยุคมืด', 'REGIONAL', 10, ['BUDDHA_DHARMA', 'HEART_SOUL', 'DEMON', 'OCCULT_MAGE'], 'MAT_FORM_BLOOD_FIEND_CRYSTAL_4', 7, 'EQ_V320_CURSED_RING_T4', 'STORY-SYNC-07'],
    [9, 'EXT_EVT_09_PRIMORDIAL_SPRING', 'CELESTIAL_ANOMALIES', 'น้ำพุวิญญาณบรรพกาลปะทุกลางรอยเลื่อนแผ่นดิน', 'ชีพจรมังกรโบราณ', 'REGIONAL', 14, ['DRAGON_VEIN_GEOMANCY', 'SPIRIT_HUSBANDRY', 'TIDE_VOYAGER'], 'MAT_HERB_DRAGON_GRASS_4', 8, 'EQ_V320_UPKEEP_STAFF_T5', null],
    [10, 'EXT_EVT_10_NAMELESS_INN_TEA', 'WANDERING_JIANGHU_TRADE', 'ชุมนุมโต๊ะน้ำชาที่โรงเตี๊ยมไร้ชื่อ — แผนที่คลังสมบัติทั้งเก้า', 'เถ้าแก่เฉียน (#22)', 'REGIONAL', 14, ['WANDERING_DAO', 'MERCANTILE_DAO', 'LORE_ARCHIVIST'], 'MAT_ORE_STAR_COPPER_3', 9, 'LEG_WPN_CAISHEN_GOLDEN_ABACUS', 'STORY-SYNC-03'],
    [11, 'EXT_EVT_11_GHOST_SHIP_MIST', 'WANDERING_JIANGHU_TRADE', 'เรือสำเภาผีของนายหญิงหลานอินเทียบท่าคืนหมอกทมิฬ', 'นายหญิงหลานอิน', 'REGIONAL', 12, ['TIDE_VOYAGER', 'FORTUNE_GAMBLER', 'NINPO_SHADOW'], 'MAT_WHIP_KARMIC_RED_SILK_5', 10, 'EQ_V320_SET_TWIN_ROBE', null],
    [12, 'EXT_EVT_12_REFUGEE_AMBUSH', 'WANDERING_JIANGHU_TRADE', 'ขบวนนักโทษประหารและผู้ลี้ภัยถูกโจรภูเขาซุ่มโจมตี', 'กองกำลังเร่ร่อนชายแดน', 'MINOR', 10, ['BODY', 'ARENA_GLORY', 'SAGE_SUPPORT', 'STRATEGY_GOVERNANCE'], 'MAT_ORE_COLD_STEEL_2', 11, 'EQ_V320_HEAVY_T2', null],
    [13, 'EXT_EVT_13_PHOENIX_EGG_VOLCANO', 'BEAST_ECOLOGY_KINGS', 'ไข่อมตะของราชันหงส์เพลิงกำลังจะฟักกลางปล่องภูเขาไฟ', 'ราชันหงส์เพลิงบรรพกาล', 'CONTINENTAL', 14, ['BEAST_SOVEREIGN', 'SPIRIT_HUSBANDRY', 'PRIMORDIAL_SHIFTER'], 'MAT_ZITHER_PHOENIX_HEARTWOOD_5', 12, 'EQ_V320_TAL_CHG_T6_PHOENIX', null],
    [14, 'EXT_EVT_14_BLOOD_WOLF_ALPHA', 'BEAST_ECOLOGY_KINGS', 'จ่าฝูงหมาป่าพันธะโลหิตบาดเจ็บหนีตายมาพึ่งเขตสำนัก', 'จ่าฝูงหมาป่าพันธะโลหิต', 'MINOR', 10, ['BEAST_SOVEREIGN', 'SAGE_SUPPORT', 'SPIRIT_HUSBANDRY'], 'MAT_BP_WOLF_FANG_1', 13, 'EQ_V320_CLAW_T1', null],
    [15, 'EXT_EVT_15_ANCIENT_TREE_SPIRIT', 'BEAST_ECOLOGY_KINGS', 'ภูตต้นไม้โบราณพันปีถูกหนอนปรสิตกลืนกินราก', 'ภูตพฤกษาพันปี', 'REGIONAL', 12, ['SPIRIT_HUSBANDRY', 'VENOM_GU', 'SAGE_SUPPORT'], 'MAT_HERB_JADE_LOTUS_2', 14, 'EQ_V320_ROBE_T2', null],
    [16, 'EXT_EVT_16_BLIND_ZITHER_SAGE', 'HIDDEN_DESTINY_LEGENDS', 'เสียงพิณไร้สายในคืนเดือนมืด — บททดสอบของคีตเซียนตาบอด', 'คีตเซียนตาบอด', 'REGIONAL', 12, ['SONIC_HARMONY', 'HEART_SOUL', 'LORE_ARCHIVIST'], 'MAT_FORM_SOUL_WOOD_PILLAR_4', 15, 'EQ_V320_GS_ZITHER_T4', null],
    [17, 'EXT_EVT_17_OLD_MAN_WOOD_SWORD', 'HIDDEN_DESTINY_LEGENDS', 'ชายชราพเนจรผู้ไร้ชื่อขอแลกกระบี่ไม้กับอาหารหนึ่งมื้อ', 'ยอดฝีมือเร้นกายนิรนาม', 'MINOR', 10, ['WANDERING_DAO', 'XIAN', 'SHADOW_SAMURAI'], 'MAT_HERB_DEW_GRASS_1', 16, 'EQ_V320_GS_SWORD_T3', null],
    [18, 'EXT_EVT_18_BETRAYED_GENERAL_PRISON', 'HIDDEN_DESTINY_LEGENDS', 'รอยแยกคุกมืดใต้ดิน — เสียงโซ่ตรวนของขุนพลผู้ถูกตราหน้าว่าทรยศ', 'ขุนพลผู้ถูกจองจำ', 'REGIONAL', 14, ['STRATEGY_GOVERNANCE', 'ANCESTRAL_RITUAL', 'KARMA_SAMSARA'], 'MAT_ORE_MITHRIL_JADE_4', 17, 'EQ_V320_SET_PATINA_ARMOR', null],
    [19, 'EXT_EVT_19_TUOBA_PHANTOM_SPEAR', 'ANCIENT_GENERALS_ENEMIES', 'เสียงทวนในพายุทรายสีเลือด — เงาร่างของแม่ทัพใหญ่ทัวป๋าเลี่ย', 'แม่ทัพใหญ่ทัวป๋าเลี่ย (#5)', 'CONTINENTAL', 15, ['ARENA_GLORY', 'BODY', 'STRATEGY_GOVERNANCE'], 'MAT_ORE_METEOR_IRON_5', 18, 'EQ_V320_GS_SPEAR_T3', 'STORY-SYNC-05'],
    [20, 'EXT_EVT_20_MURONG_BLOOD_LOTUS', 'ANCIENT_GENERALS_ENEMIES', 'ดอกบัวโลหิตนิรันดร์บานกลางบึงมรณะ — การตื่นขึ้นของมู่หรงเสวี่ย', 'แม่ทัพหญิงมู่หรงเสวี่ย (#7)', 'MYTHIC', 15, ['ANCESTRAL_RITUAL', 'DEMON', 'KARMA_SAMSARA'], 'MAT_HERB_BLOOD_GINSENG_3', 19, 'EQ_V320_CURSED_ROBE_T5', 'STORY-SYNC-08'],
    [21, 'EXT_EVT_21_TWIN_ASSASSINS', 'ANCIENT_GENERALS_ENEMIES', 'เงาคู่ในคืนไร้จันทร์ — บททดสอบของฝาแฝดมือสังหารหลวง', 'ฝาแฝดมือสังหารหลวง', 'REGIONAL', 12, ['NINPO_SHADOW', 'SHADOW_SAMURAI', 'VOID_SPACE'], 'MAT_BP_SCORPION_STING_4', 20, 'EQ_V320_GS_NEEDLE_T4', null],
    [22, 'EXT_EVT_22_STANDING_TITAN_LEIZHEN', 'ANCIENT_GENERALS_ENEMIES', 'ยักษ์ศิลาค้ำถ้ำลืมตาตื่น — บททดสอบหมัดเหล็กของจ้าวพยัคฆ์เหลยเจิ้น', 'จ้าวพยัคฆ์เหลยเจิ้น', 'CONTINENTAL', 14, ['BODY', 'GRAVITY_DAO', 'ARENA_GLORY'], 'MAT_BP_EARTH_CORE_4', 21, 'EQ_V320_FIST_T5', null],
    [23, 'EXT_EVT_23_STRANDED_ENEMY_GENERAL', 'ANCIENT_GENERALS_ENEMIES', 'ห้องจำศีลใต้หุบเขาไฟ — ขุนพลอาณาจักรศัตรูที่หนีกลับไม่ทัน', 'ขุนพลต่างภพจำศีล', 'CONTINENTAL', 14, ['STRATEGY_GOVERNANCE', 'LORE_ARCHIVIST', 'BODY'], 'MAT_FORM_EARTH_FLAME_CORE_4', 22, 'EQ_V320_CORE_CHG_T4_FLAME', null],
    [24, 'EXT_EVT_24_ICE_COFFIN_ENVOY', 'ANCIENT_GENERALS_ENEMIES', 'โลงหยกน้ำแข็งของทูตสาวจากอีกฟากฟ้า', 'ทูตหญิงต่างภพในโลงหยก', 'CONTINENTAL', 14, ['TIDE_VOYAGER', 'SAGE_SUPPORT', 'LORE_ARCHIVIST'], 'MAT_BP_BEAR_HEART_4', 23, 'EQ_V320_TEMP_FAN_T4', null],
    [25, 'EXT_EVT_25_FALLEN_UPPER_ENVOY', 'ANCIENT_GENERALS_ENEMIES', 'ทูตสวรรค์ปีกหักกลางหุบเขา — คำเตือนจากโลกเบื้องบน', 'ทูตตกสวรรค์ ขงหมิง (#21)', 'MYTHIC', 16, ['DIVINE_SUMMONER', 'DIVINE_POSSESSION', 'DIVINE_CHANNELER', 'LORE_ARCHIVIST'], 'MAT_TR_HEAVEN_EDICT_SILK', 24, 'EQ_V320_LORE_RING_T7', 'STORY-SYNC-10'],
    [26, 'EXT_EVT_26_MAD_APOTHECARY', 'HERMIT_ARTISAN_MASTERS', 'คนบ้าในบึงหมอกพิษ — โอสถหนึ่งเม็ดหรือพิษล้างบาง', 'ปรมาจารย์โอสถคลั่ง', 'REGIONAL', 12, ['VENOM_GU', 'SPIRIT_HUSBANDRY', 'CRAFT_CREATION'], 'MAT_HERB_VENOM_VINE_3', 25, 'EQ_V320_AUX_T2_ALCH', null],
    [27, 'EXT_EVT_27_MAGMA_BLACKSMITH', 'HERMIT_ARTISAN_MASTERS', 'วิญญาณช่างหลอมในหัวใจเปลวเพลิง — ตีเหล็กหนึ่งหมื่นค้อน', 'โอวหยางเหยียน (#14)', 'CONTINENTAL', 14, ['CRAFT_CREATION', 'BODY', 'ARENA_GLORY'], 'MAT_TR_WORLD_FORGE_SHARD', 26, 'EQ_V320_SET_PATINA_BLADE', 'STORY-SYNC-12'],
    [28, 'EXT_EVT_28_GONGSHU_PUPPET_VAULT', 'HERMIT_ARTISAN_MASTERS', 'ห้องนิรภัยหุ่นเชิดหยกขาว — ปริศนากลไกของกงซูจี', 'กงซูจี ปราชญ์กลไก', 'REGIONAL', 14, ['MECH_PUPPET', 'CRAFT_CREATION', 'ARRAY_TALISMAN'], 'MAT_FORM_EARTH_ARRAY_CORE_4', 27, 'EQ_V320_CORE_CHG_T4_LIGHT', null],
    [29, 'EXT_EVT_29_FROZEN_STAR_TOWER', 'HERMIT_ARTISAN_MASTERS', 'หอคอยดูดาวที่เวลาหยุดนิ่ง — คำพยากรณ์สุดท้ายของซิงเฉินจื่อ', 'ซิงเฉินจื่อ (#16)', 'MYTHIC', 15, ['ASTRO_DIVINATION', 'CHRONO_EPOCH', 'LORE_ARCHIVIST'], 'MAT_TR_ASTRAL_DEW', 23, 'LEG_WPN_HETU_LUOSHU_ASTROLABE', 'STORY-SYNC-04'],
    [30, 'EXT_EVT_30_SWEEPING_MONK', 'HERMIT_ARTISAN_MASTERS', 'หลวงจีนชรากวาดใบไม้กลางวัดร้าง — คมดาบที่ซ่อนในไม้กวาด', 'หลวงจีนชราวัดร้าง', 'REGIONAL', 12, ['BUDDHA_DHARMA', 'HEART_SOUL', 'WANDERING_DAO'], 'MAT_FORM_FAITH_INCENSE_PEARL_4', 12, 'EQ_V320_ROSARY_T5', null],
    [31, 'EXT_EVT_31_GRANNY_MENG_HUT', 'HERMIT_ARTISAN_MASTERS', 'กระท่อมปะชุนเสื้อผ้าริมบึง — เส้นไหมสวรรค์ของแม่เฒ่ายายเมิ่ง', 'แม่เฒ่ายายเมิ่ง (#24)', 'CONTINENTAL', 14, ['CRAFT_CREATION', 'SAGE_SUPPORT', 'TIDE_VOYAGER'], 'MAT_WHIP_KARMIC_RED_SILK_5', 22, 'LEG_ARM_CELESTIAL_CRANE_ROBE', 'STORY-SYNC-01'],
    [32, 'EXT_EVT_32_HUNDRED_DAY_EMPEROR', 'CHAOS_ERA_HEROES', 'บัลลังก์หินกลางทุ่งร้าง — เจตนารมณ์ของจักรพรรดิร้อยวัน หลินเทียน', 'จักรพรรดิร้อยวัน หลินเทียน', 'CONTINENTAL', 14, ['STRATEGY_GOVERNANCE', 'ANCESTRAL_RITUAL', 'INK_LITERATI'], 'MAT_BRUSH_DRAGON_WHISKER_JADE_5', 20, 'EQ_V320_GS_BRUSH_T6', null],
    [33, 'EXT_EVT_33_SEVEN_BANNER_WAGER', 'CHAOS_ERA_HEROES', 'ขุนพลขี้เมาผู้แบกธงขาดเจ็ดผืน — การเดิมพันครั้งที่แปดของเกาเซิ่ง', 'ขุนพลเกาเซิ่ง', 'REGIONAL', 12, ['FORTUNE_GAMBLER', 'ARENA_GLORY', 'STRATEGY_GOVERNANCE'], 'MAT_BP_HEAVEN_CORE_5', 13, 'EQ_V320_GS_ABACUS_T4', null],
    [34, 'EXT_EVT_34_GAMBLER_PRINCE_DICE', 'CHAOS_ERA_HEROES', 'บ่อนพนันชะตาขององค์ชายไร้บ้าน — ทอยเต๋าแลกสมบัติตำนาน', 'องค์ชายพเนจรนักเดิมพัน', 'REGIONAL', 12, ['FORTUNE_GAMBLER', 'MERCANTILE_DAO', 'WANDERING_DAO'], 'MAT_ORE_DIVINE_GOLD_6', 21, 'EQ_V320_SET_TWIN_RING', null],
    [35, 'EXT_EVT_35_DRUNKEN_SWORD_IMMORTAL', 'CHAOS_ERA_HEROES', 'น้ำเต้าสุราบนยอดไผ่ — ท้าดวลร่ำสุรากับเซียนกระบี่ขี้เมา', 'จิ้วเจี้ยนเซียน (#39)', 'MYTHIC', 14, ['XIAN', 'WANDERING_DAO', 'ARENA_GLORY'], 'MAT_HERB_IMMORTAL_PEACH_6', 6, 'EQ_V320_TEMP_SWORD_T4', 'STORY-SYNC-09'],
    [36, 'EXT_EVT_36_KENSHIN_CLOUD_CLIFF', 'CHAOS_ERA_HEROES', 'คมดาบไร้ปราณบนผาเมฆา — บททดสอบจิตว่างเปล่าของซามูไรเคนชิน', 'ซามูไรเคนชิน (#41)', 'CONTINENTAL', 14, ['SHADOW_SAMURAI', 'ARENA_GLORY', 'HEART_SOUL'], 'MAT_ORE_METEOR_IRON_5', 19, 'EQ_V320_TAL_CHG_T5_CHARGE', 'STORY-SYNC-11'],
    [37, 'EXT_EVT_37_CROWN_PRINCESS_MARKET', 'MODERN_EMPIRES_GATEKEEPER', 'เทพธิดาเก้าเหมันต์ปลอมตัวเดินตลาด — องค์หญิงรัชทายาทเป่ยหมิง', 'กู่ชิงเสวี่ย (#47)', 'CONTINENTAL', 14, ['XIAN', 'STRATEGY_GOVERNANCE', 'MERCANTILE_DAO'], 'MAT_HERB_SNOW_LOTUS_5', 22, 'LEG_ACC_DRAGON_PHOENIX_BANGLE', 'STORY-SYNC-06'],
    [38, 'EXT_EVT_38_XINGYUN_OBSERVATION', 'MODERN_EMPIRES_GATEKEEPER', 'นักพรตพเนจรดูดาวหน้าประตูสำนัก — เจ้าหอดูดาวซิงอวิ๋น', 'ซิงอวิ๋น (#49)', 'CONTINENTAL', 14, ['ASTRO_DIVINATION', 'LORE_ARCHIVIST', 'ARRAY_TALISMAN'], 'MAT_ORE_THUNDER_JADE_4', 23, 'EQ_V320_GS_ASTROLABE_T4', 'STORY-SYNC-04'],
    [39, 'EXT_EVT_39_CENSOR_WARRANT', 'MODERN_EMPIRES_GATEKEEPER', 'หมายจับตุลาการหน้าเหล็ก — เหยียนหลัวแห่งตงหวงตามล่าถึงพรมแดน', 'เหยียนหลัว ตุลาการตงหวง', 'CONTINENTAL', 14, ['STRATEGY_GOVERNANCE', 'KARMA_SAMSARA', 'ARENA_GLORY'], 'MAT_BP_TIGER_BONE_6', 15, 'EQ_V320_LORE_ARMOR_T7', 'STORY-SYNC-02'],
    [40, 'EXT_EVT_40_FACELESS_GATEKEEPER', 'MODERN_EMPIRES_GATEKEEPER', 'เสียงเรียกจากใต้ฐานประตูมิติ — การตื่นขึ้นของผู้เฝ้าประตูไร้หน้า', 'ผู้เฝ้าประตูไร้หน้าแห่งเทียนกู่', 'MYTHIC', 18, ['ANCESTRAL_RITUAL', 'LORE_ARCHIVIST', 'VOID_SPACE', 'ARRAY_TALISMAN'], 'MAT_TR_VOID_MATRIX_CORE', 27, 'EQ_V320_LORE_SWORD_T7', 'STORY-SYNC-12']
  ];

  const EXT_EVENT_CATALOG = Object.freeze(RAW_40_EVENTS.map(row => {
    const [no, id, category, nameTh, loreFigureTh, impact, durationDays, preferredPaths, rewardMatId, loreFactIdx, relicLinkId, storySync] = row;
    return Object.freeze({
      no, id, category,
      categoryNameTh: EXT_EVENT_CATEGORIES[category].nameTh,
      nameTh, loreFigureTh, impact, durationDays,
      preferredPaths: Object.freeze(preferredPaths.slice()),
      rewardMatId, loreFactIdx, relicLinkId, storySync,
      outcomes: Object.freeze([
        { key: 'HONORABLE', labelTh: 'เจรจา/คลี่คลายด้วยปัญญาและเกียรติ', repDelta: 24, cultExp: 85, matQty: 2, stones: 60 },
        { key: 'RIGHTEOUS', labelTh: 'ประกอบพิธีชำระ/ช่วยเหลือด้วยคุณธรรม', repDelta: 32, cultExp: 70, matQty: 1, stones: 35 },
        { key: 'AMBITIOUS', labelTh: 'ช่วงชิงผลประโยชน์และแก่นพลังต้องห้าม', repDelta: -12, cultExp: 110, matQty: 3, stones: 95, heartDemon: 6 },
        { key: 'PRAGMATIC', labelTh: 'สังเกตการณ์เก็บกวาดและถอยอย่างปลอดภัย', repDelta: 6, cultExp: 45, matQty: 1, stones: 25 }
      ])
    });
  }));

  const EXT_EVENT_BY_ID = Object.freeze(Object.fromEntries(EXT_EVENT_CATALOG.map(e => [e.id, e])));

  X.EXTERNAL_WORLD_EVENTS = {
    VERSION: '3.4.0-world-events',
    CATEGORIES: EXT_EVENT_CATEGORIES,
    CATALOG: EXT_EVENT_CATALOG,
    BY_ID: EXT_EVENT_BY_ID,

    ensureWorldState(W) {
      if (!W) return null;
      W.world = W.world || {};
      if (!W.world.externalWorldEvents || typeof W.world.externalWorldEvents !== 'object') {
        W.world.externalWorldEvents = { active: [], resolvedReceipts: {}, history: [], lastSpawnDay: -7 };
      }
      const st = W.world.externalWorldEvents;
      if (!Array.isArray(st.active)) st.active = [];
      if (!st.resolvedReceipts || typeof st.resolvedReceipts !== 'object') st.resolvedReceipts = {};
      if (!Array.isArray(st.history)) st.history = [];
      return st;
    },

    spawnDeterministicEvent(W, opts) {
      opts = opts || {};
      const st = X.EXTERNAL_WORLD_EVENTS.ensureWorldState(W);
      if (!st) return null;
      const day = W.day || 0;
      if (!opts.force && st.active.length >= 3) return null;
      if (!opts.force && day - (st.lastSpawnDay || -7) < 7) return null;

      let chosen = opts.eventId ? EXT_EVENT_BY_ID[opts.eventId] : null;
      if (!chosen) {
        const activeIds = new Set(st.active.map(a => a && a.id));
        const pool = EXT_EVENT_CATALOG.filter(ev => !activeIds.has(ev.id) && !(st.resolvedReceipts[ev.id] && (day - st.resolvedReceipts[ev.id].day) < 45));
        if (!pool.length) return null;
        const idx = detHash340((W.seed || 'seed') + ':ext_evt:' + day + ':' + st.history.length) % pool.length;
        chosen = pool[idx];
      }
      const instance = {
        uid: 'wevt_' + chosen.no + '_' + day,
        id: chosen.id,
        no: chosen.no,
        category: chosen.category,
        nameTh: chosen.nameTh,
        loreFigureTh: chosen.loreFigureTh,
        impact: chosen.impact,
        spawnedDay: day,
        expiresDay: day + chosen.durationDays,
        relicLinkId: chosen.relicLinkId || null,
        storySync: chosen.storySync || null
      };
      st.active.push(instance);
      st.lastSpawnDay = day;
      if (W.log && !opts.quiet) {
        W.log('world', '🌍 อีเวนต์โลกภายนอก [' + chosen.categoryNameTh + ']:「' + chosen.nameTh + '」(' + chosen.loreFigureTh + ')', []);
      }
      return instance;
    },

    chooseAutonomousOutcome(W, npc, ev) {
      if (!ev) return null;
      const E = g.HC && g.HC.eff;
      const mor = (npc && E) ? E(npc, 'values.morality') : 50;
      const amb = (npc && E) ? E(npc, 'personality.ambition') : 50;
      const caut = (npc && E) ? E(npc, 'personality.caution') : 50;
      const cour = (npc && E) ? E(npc, 'personality.courage') : 50;
      const path = npc && npc.cult && npc.cult.path;
      const doctrine = (W && W.sect && W.sect.doctrine) || 'BALANCED';
      const isPref = path && ev.preferredPaths.includes(path);
      // STORY-SYNC-10 guard on Event 25: DIVINE_* only (exclude mortal GOD path)
      const isDarkOrAmb = (amb >= 68 && mor < 48) || ['DEMON', 'VOID_HERETIC_PACT', 'NETHER_GRAVE', 'OCCULT_MAGE'].includes(path) || doctrine === 'RUTHLESS';
      if (ev.no === 25 && ['DIVINE_SUMMONER', 'DIVINE_POSSESSION', 'DIVINE_CHANNELER'].includes(path)) {
        return ev.outcomes[2]; // AMBITIOUS divine mandate strike
      }
      if (isPref && (cour >= 55 || mor >= 55)) return ev.outcomes[0]; // HONORABLE
      if (mor >= 65 || doctrine === 'RIGHTEOUS' || ['BUDDHA_DHARMA', 'SAGE_SUPPORT', 'ANCESTRAL_RITUAL', 'SPIRIT_HUSBANDRY'].includes(path)) return ev.outcomes[1]; // RIGHTEOUS
      if (isDarkOrAmb) return ev.outcomes[2]; // AMBITIOUS
      if (caut >= 62) return ev.outcomes[3]; // PRAGMATIC
      return isPref ? ev.outcomes[0] : ev.outcomes[3];
    },

    resolveEventAutonomously(W, npc, eventOrId, opts) {
      opts = opts || {};
      const st = X.EXTERNAL_WORLD_EVENTS.ensureWorldState(W);
      if (!st || !npc || npc.dead) return { ok: false, reason: 'invalid-actor' };
      const evId = typeof eventOrId === 'string' ? eventOrId : (eventOrId && eventOrId.id);
      const ev = EXT_EVENT_BY_ID[evId];
      if (!ev) return { ok: false, reason: 'unknown-event' };
      const day = W.day || 0;
      const prev = st.resolvedReceipts[ev.id];
      if (!opts.force && prev && (day - prev.day) < 45) {
        return { ok: false, reason: 'already-resolved-recently' };
      }

      const outcome = X.EXTERNAL_WORLD_EVENTS.chooseAutonomousOutcome(W, npc, ev);
      // Closed-loop transfer from canonical W.world.resourcePool.stones (never conjure stones)
      let stonesPaid = outcome.stones || 0;
      if (W.sect && stonesPaid > 0) {
        const pool = W.world && W.world.resourcePool;
        if (pool && Number.isFinite(pool.stones)) {
          stonesPaid = Math.min(stonesPaid, Math.max(0, Math.floor(pool.stones)));
          pool.stones -= stonesPaid;
        } else {
          stonesPaid = 0;
        }
        if (stonesPaid > 0) W.sect.stones = (W.sect.stones || 0) + stonesPaid;
      }
      if (W.sect && outcome.repDelta) {
        W.sect.rep = Math.max(0, (W.sect.rep || 0) + outcome.repDelta);
      }
      if (npc.cult && g.CULT && g.CULT.gain && outcome.cultExp > 0) {
        g.CULT.gain(npc, outcome.cultExp, W, 'external_world_event');
      }
      if (outcome.heartDemon && npc.h && npc.h.state) {
        npc.h.state.heartDemon = Math.min(100, (npc.h.state.heartDemon || 0) + outcome.heartDemon);
      }
      let matAwarded = null;
      if (ev.rewardMatId && g.ECO && g.ECO.matById && g.ECO.matById[ev.rewardMatId] && g.ECO.add) {
        g.ECO.add(W, ev.rewardMatId, outcome.matQty || 1);
        matAwarded = ev.rewardMatId;
      }
      // Cross-link to canonical v3.1.0 Living Lore facts[id] (plus legacy discoveredFacts index)
      let loreFactId = null;
      if (X.LIVING_LORE && Array.isArray(X.LIVING_LORE.CANON_FACTS) && X.LIVING_LORE.CANON_FACTS.length) {
        const cf = X.LIVING_LORE.CANON_FACTS[ev.loreFactIdx % X.LIVING_LORE.CANON_FACTS.length];
        if (cf && cf.id) {
          if (typeof X.LIVING_LORE.ensureWorldState === 'function') X.LIVING_LORE.ensureWorldState(W);
          W.world.livingLore = W.world.livingLore || {};
          W.world.livingLore.facts = W.world.livingLore.facts || {};
          const wf = W.world.livingLore.facts[cf.id] || (W.world.livingLore.facts[cf.id] = { id: cf.id, discovered: false, archivedInSect: false, status: 'undiscovered', knownAccounts: [] });
          wf.discovered = true;
          if (wf.status === 'undiscovered') wf.status = 'rumored';
          if (!Array.isArray(wf.knownAccounts)) wf.knownAccounts = [];
          if (!wf.knownAccounts.includes('WORLD_EVENT')) wf.knownAccounts.push('WORLD_EVENT');
          wf.lastSourceEventId = ev.id;
          wf.lastActorId = npc.id;
          wf.discoveredDay = wf.discoveredDay != null ? wf.discoveredDay : day;
          W.world.livingLore.discoveredFacts = W.world.livingLore.discoveredFacts || {};
          W.world.livingLore.discoveredFacts[cf.id] = { day, sourceEventId: ev.id, actorId: npc.id };
          loreFactId = cf.id;
        }
      }

      st.active = st.active.filter(a => a && a.id !== ev.id);
      const actorName = (npc.h && npc.h.name) ? ((npc.h.name.surname || '') + (npc.h.name.given || '')) : npc.id;
      const entry = {
        id: ev.id,
        no: ev.no,
        nameTh: ev.nameTh,
        category: ev.category,
        day,
        actorId: npc.id,
        actorNameTh: actorName,
        outcomeKey: outcome.key,
        outcomeLabelTh: outcome.labelTh,
        stonesPaid,
        matAwarded,
        loreFactId,
        relicLinkId: ev.relicLinkId || null
      };
      st.resolvedReceipts[ev.id] = { day, outcomeKey: outcome.key, actorId: npc.id };
      st.history.push(entry);
      if (st.history.length > 60) st.history.shift();
      if (W.log && !opts.quiet) {
        W.log('chronicle', '🌍 ' + actorName + ' คลี่คลายอีเวนต์「' + ev.nameTh + '」(' + outcome.labelTh + ')', [npc.id]);
      }
      return { ok: true, entry };
    },

    tickDaily(W) {
      const st = X.EXTERNAL_WORLD_EVENTS.ensureWorldState(W);
      if (!st) return null;
      const day = W.day || 0;
      st.active = st.active.filter(a => a && day <= (a.expiresDay || day));
      X.EXTERNAL_WORLD_EVENTS.spawnDeterministicEvent(W, { quiet: false });
      if (st.active.length > 0 && Array.isArray(W.npcs)) {
        const targetEvt = st.active.find(a => a && (day - (a.spawnedDay || 0)) >= 3);
        if (targetEvt) {
          const evDef = EXT_EVENT_BY_ID[targetEvt.id];
          const busyActs = new Set(['fight', 'breakthrough', 'seclusion', 'sleep', 'heal']);
          const candidates = W.npcs.filter(n => n && !n.dead && !n.foe && !n.away && !n.exiled && n.cult && (n.cult.stage || 1) >= 2 && (!n.act || !busyActs.has(n.act.id)) && (!n.h || !n.h.state || (n.h.state.energy || 100) >= 25));
          if (candidates.length > 0) {
            const scored = candidates.map(n => {
              const prefBonus = (evDef && evDef.preferredPaths.includes(n.cult.path)) ? 100 : 0;
              const repeatPenalty = (st.lastActorId && st.lastActorId === n.id) ? -60 : 0;
              const stageBonus = Math.min(30, (n.cult.stage || 1) * 4);
              const tie = detHash340((W.seed || 'seed') + ':' + targetEvt.id + ':' + day + ':' + n.id) % 19;
              return { n, score: prefBonus + repeatPenalty + stageBonus + tie };
            }).sort((a, b) => b.score - a.score);
            const chosenNpc = scored[0].n;
            const res = X.EXTERNAL_WORLD_EVENTS.resolveEventAutonomously(W, chosenNpc, targetEvt.id, { quiet: false });
            if (res && res.ok) {
              st.lastActorId = chosenNpc.id;
              if (chosenNpc.h && chosenNpc.h.state) {
                chosenNpc.h.state.energy = Math.max(10, (chosenNpc.h.state.energy || 60) - 18);
                chosenNpc.h.state.satiety = Math.max(10, (chosenNpc.h.state.satiety || 60) - 10);
              }
            }
          }
        }
      }
      return st;
    },

    peekSummary(W) {
      const st = W && W.world && W.world.externalWorldEvents;
      if (!st) return { activeCount: 0, resolvedCount: 0, activeNamesTh: [], recentTh: '' };
      const activeNamesTh = (st.active || []).map(a => a.nameTh);
      const last = (st.history && st.history.length) ? st.history[st.history.length - 1] : null;
      return {
        activeCount: activeNamesTh.length,
        resolvedCount: Object.keys(st.resolvedReceipts || {}).length,
        activeNamesTh,
        recentTh: last ? (last.actorNameTh + ': ' + last.nameTh + ' (' + last.outcomeLabelTh + ')') : ''
      };
    }
  };

})(typeof globalThis !== 'undefined' ? globalThis : this);
