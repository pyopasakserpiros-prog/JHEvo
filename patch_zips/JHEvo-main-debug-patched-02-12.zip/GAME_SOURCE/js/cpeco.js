/* cpeco.js — เศรษฐกิจแต้มคุณูปการ (v1.10.2)
 * แนวคิด: สำนัก "เสก" แต้มคุณูปการ (คป.) ขึ้นมาจ่ายค่าตอบแทน แต่แต้มจะมีค่าก็ต่อเมื่อมีของที่คนอยากได้ให้ใช้แลก
 *  ที่มาของแต้ม (เสก): เบี้ยหวัดรายเดือน · ค่าแรงงานประจำ · เก็บสมุนไพรหุบเขา · ปรุงโอสถพื้นฐานให้สำนัก · บริจาคของจากการเดินทาง/สำรวจ/วิชา/ตำรับที่พบ
 *  ที่ไปของแต้ม (เผา): ซื้อของร้านค้าสำนัก (โอสถ/อุปกรณ์) · เรียนวิชาขั้นสูงจากหอคัมภีร์ · ค่าธรรมเนียมขอสิทธิ์ศึกษาตำรับ · ขอคำชี้แนะ · ฝึกปราณเข้มข้น
 *  ของที่มีในร้านมาจากการบริจาค/ผลผลิตของสำนักเท่านั้น → ทุกคนมีเหตุผลทำงานเพื่อแต้ม
 *  กลไกเสถียรภาพ: ราคา/ค่ารับบริจาคปรับตามความขาดแคลนของแต่ละสิ่ง + ดัชนีราคาแต้มปรับตามปริมาณแต้มจริงต่อหัว */
(function (g) {
  'use strict';
  const U = g.U, HC = g.HC, CULT = g.CULT, ECO = g.ECO, SECT = g.SECT, AI = g.AI, X = g.EXPED, JD = g.JD, SK = g.SK, ST = g.STATS;
  const clamp = U.clamp, E = (n, p) => HC.eff(n, p), A = AI.ACTS;
  const CPE = {};
  const BASIC_IDS = JD.CP.BASIC.map(r => 'P:' + r.id);

  CPE.S = W => {
    const S = W.sect;
    if (S.cp && S.cp._ready && Array.isArray(S.cp.freeLib)) return S.cp;
    if (!S.cp) S.cp = { minted: 0, burned: 0, circulation: 0, retired: 0, arbitrageBlocked: 0, price: 1, markup: 1, welfare: 0.5, log: [], dayMint: 0, dayBurn: 0, welfareGiven: 0, donated: 0, sales: 0, techSales: 0, studyFees: 0, studyServices: 0, trainingFees: 0, trainingServices: 0, recipeFees: 0, recipeAuthorizations: 0, freeLib: S.library ? S.library.filter(id => { const t = CULT.tech(id); return t && t.tier <= 1 && !t.overhaulPack; }) : [], hist: [] };
    if (S.cp.circulation == null) S.cp.circulation = 0;
    if (S.cp.retired == null) S.cp.retired = 0;
    if (S.cp.arbitrageBlocked == null) S.cp.arbitrageBlocked = 0;
    if (S.cp.studyFees == null) S.cp.studyFees = 0;
    if (S.cp.studyServices == null) S.cp.studyServices = 0;
    if (S.cp.trainingFees == null) S.cp.trainingFees = 0;
    if (S.cp.trainingServices == null) S.cp.trainingServices = 0;
    if (S.cp.recipeFees == null) S.cp.recipeFees = 0;
    if (S.cp.recipeAuthorizations == null) S.cp.recipeAuthorizations = 0;
    if (!Array.isArray(S.cp.hist)) S.cp.hist = [];
    if (!Array.isArray(S.cp.log)) S.cp.log = [];
    ['minted', 'burned', 'circulation', 'retired', 'arbitrageBlocked', 'dayMint', 'dayBurn', 'welfareGiven', 'donated', 'sales', 'techSales', 'recipeFees', 'recipeAuthorizations'].forEach(k => { if (!Number.isFinite(S.cp[k])) S.cp[k] = 0; });
    if (!Number.isFinite(S.cp.price)) S.cp.price = 1;
    if (!Number.isFinite(S.cp.markup)) S.cp.markup = 1;
    if (Array.isArray(S.cp.freeLib) && S.cp.freeLib.length) S.cp._ready = true;
    return S.cp;
  };
  CPE.init = W => { CPE.S(W); W.npcs.forEach(n => { if (n.cp == null) n.cp = 40; }); };
  const note = (W, text) => { const c = CPE.S(W); c.log.push({ t: W.t, text }); if (c.log.length > 40) c.log.shift(); };
  CPE.mint = (W, n, amt, why, quiet) => {
    if (n && n.peakId && g.SECT && g.SECT.PEAKS && g.SECT.PEAKS.getUnitPeakBonuses) {
      const pkb = g.SECT.PEAKS.getUnitPeakBonuses(W, n);
      if (pkb && pkb.active && pkb.cpGainBonus > 0) amt *= (1 + pkb.cpGainBonus);
    }
    amt = Math.round(amt * 10) / 10; if (!(amt > 0)) return 0; const c = CPE.S(W); n.cp = (n.cp || 0) + amt; c.minted += amt; c.dayMint += amt; n.cpEarned = (n.cpEarned || 0) + amt; if (!quiet && amt >= 30) note(W, n.h.name.given + ' ได้ ' + Math.round(amt) + ' คป. (' + why + ')'); return amt; };
  CPE.spend = (W, n, amt, why) => { if (!Number.isFinite(amt) || amt < 0 || !Number.isFinite(n.cp || 0) || (n.cp || 0) < amt) return false; const c = CPE.S(W); n.cp -= amt; c.burned += amt; c.dayBurn += amt; if (amt >= 40) note(W, n.h.name.given + ' ใช้ ' + Math.round(amt) + ' คป. ' + why); return true; };
  CPE.retireNpc = (W, n, reason) => {
    if (!n || !(n.cp > 0)) return 0;
    const c = CPE.S(W);
    const amt = Math.round(n.cp * 10) / 10;
    c.retired = (c.retired || 0) + amt;
    n.cp = 0;
    if (amt >= 20) {
      note(W, (n.h && n.h.name && n.h.name.given || 'สมาชิก') + ' สิ้นสภาพ ปลดเกษียณแต้มคุณูปการ ' + amt + ' คป. (' + (reason || 'ออกจากสำนัก') + ')');
    }
    return amt;
  };

  /* ----- ความขาดแคลน/ราคา ----- */
  CPE.target = (W, id) => {
    const S = W.sect, w = (S.want && S.want[id]) || 0; let b = 4; const m = ECO.matById[id];
    if (m) b = m.tier <= 1 ? 16 : m.tier === 2 ? 9 : m.tier === 3 ? 5 : 3;
    if (BASIC_IDS.includes(id)) b = 12;
    else if (id.startsWith('P:BT_')) b = 1;
    else if (ECO.isPill(id)) { const info = ECO.pillInfo(id); b = !info ? 3 : info.tier <= 1 ? 8 : info.tier === 2 ? 5 : info.tier === 3 ? 3 : info.tier === 4 ? 2 : 1; }
    return Math.max(b, w);
  };
  CPE.scarcity = (W, id) => clamp((CPE.target(W, id) + 2) / (ECO.count(W, id) + 2), 0.5, 2.5);
  CPE.reward = (W, id, n, stockBefore) => {
    const tgt = CPE.target(W, id), stock = stockBefore == null ? ECO.count(W, id) : stockBefore;
    const sc = clamp((tgt + 2) / (stock + 2), 0.05, 2.5);
    return ECO.base(id) * 0.22 * sc * (n == null ? 1 : n);
  };
  const recipeByOutput = (() => { const m = {}; Object.keys(ECO.recipeById).forEach(k => { const r = ECO.recipeById[k]; if (r.outItemId) m[r.outItemId] = r; }); return m; })();
  CPE.priceOf = (W, id) => {
    const c = CPE.S(W); let base = ECO.base(id);
    const r = id.startsWith('P:') ? ECO.recipeById[id.slice(2)] : recipeByOutput[id];
    if (r) base = Math.max(base, ECO.inputCost(W, r) * 0.45 / (r.yield || 1));
    const raw = Math.round(base * 0.9 * c.price * c.markup * clamp(Math.pow(CPE.scarcity(W, id), 0.5), 0.8, 1.6));
    const minNoArb = Math.ceil(CPE.reward(W, id, 1) * 1.3) + 2;
    return Math.max(2, minNoArb, raw);
  };
  CPE.gearPrice = (W, it) => { const c = CPE.S(W); const maxD = it.maxDur == null ? 100 : it.maxDur, curD = it.dur == null ? maxD : it.dur; const condK = clamp(curD / 100, 0.25, 1) * clamp(0.7 + 0.3 * (maxD / 100), 0.5, 1); const baseVal = Math.max(it.value || 0, Math.round(20 * Math.pow(1.9, (it.tier || 1) - 1))); return Math.max(5, Math.round(baseVal * 0.9 * (it.q || 1) * condK * c.price * c.markup)); };
  CPE.techFree = (W, t, n) => !t || CPE.S(W).freeLib.includes(t.id) || !!(n && n.studyWaivers && n.studyWaivers[t.id]);
  CPE.techPrice = (W, t, n) => CPE.techFree(W, t, n) ? 0 : Math.round(28 * Math.pow(t.tier, 2.1) * CPE.S(W).price);
  CPE.techReward = (W, id) => { const t = CULT.tech(id); return t ? 28 * Math.pow(t.tier, 2.1) * 0.55 : 0; };
  CPE.donorValue = (W, out) => {
    const a = { total: 0, parts: [] };
    Object.keys(out.mats || {}).forEach(k => { const before = out.stockBefore && out.stockBefore[k]; const v = CPE.reward(W, k, out.mats[k], before); a.total += v; });
    Object.keys(out.pills || {}).forEach(k => { const before = out.stockBefore && out.stockBefore[k]; a.total += CPE.reward(W, k, out.pills[k], before); });
    (out.gear || []).forEach(gr => { a.total += CPE.gearPrice(W, gr) * 0.5; });
    (out.techs || []).forEach(id => { if (out.techsAccepted || !W.sect.library.includes(id)) a.total += CPE.techReward(W, id); });
    Object.keys(out.organs || {}).forEach(k => {
      const o = g.CONTENT && g.CONTENT.organById && g.CONTENT.organById[k];
      a.total += (o ? 12 * (o.tier || 1) : 15) * (out.organs[k] || 0);
    });
    if (out.stones > 0) a.total += out.stones * 0.2;
    return a.total;
  };
  const oHandover = X.handover;
  X.handover = (W, ex, alive, out) => {
    const accepted = oHandover(W, ex, alive, out) || out.donation || out;
    let total = 0; try { total = CPE.donorValue(W, accepted); } catch (e) { total = 0; }
    if (total > 0 && alive.length) {
      const wts = alive.map((m, i) => (i === 0 ? 1.3 : 1) * (0.7 + E(m, 'personality.loyalty') / 160)), ws = wts.reduce((s, x) => s + x, 0), c = CPE.S(W);
      alive.forEach((m, i) => { CPE.mint(W, m, total * wts[i] / ws, 'บริจาคของจากการเดินทาง', true); });
      c.donated += total; if (total >= 40) { note(W, 'คณะ ' + alive.map(m => m.h.name.given).join('、') + ' บริจาคของ รวม ' + Math.round(total) + ' คป.'); W.log('finance', 'คณะเดินทางบริจาคของเข้าคลังสำนัก ได้แต้มคุณูปการรวม ' + Math.round(total), alive.map(m => m.id)); }
    }
    return accepted;
  };

  /* ----- ค่าแรง: แปลงจากคุณงาม (merit) ที่ได้จากงานประจำ ----- */
  const WAGE_ACTS = { farm: 1, mine: 1, cook: 1, duty: 1, guard: 1, heal: 1, brew: 1, forge: 1, pray: 0.5, errand: 0.5 };
  Object.keys(WAGE_ACTS).forEach(id => {
    const a = A[id]; if (!a || !a.done) return; const od = a.done;
    a.done = function (n, W, ctx) {
      const m0 = n.merit || 0; const r = od.apply(this, arguments); const dm = (n.merit || 0) - m0;
      const got = id === 'farm' || id === 'mine' ? (ctx && ctx.got || 0) * 0.9 : 0;
      const pMod = CPE.S(W).price > 1.2 ? 1 / Math.pow(CPE.S(W).price, 0.5) : 1;
      CPE.mint(W, n, (Math.max(0, dm) * 1.3 + got * 0.3) * WAGE_ACTS[id] * pMod, 'ค่าแรง', true);
      return r;
    };
  });
  /* ----- สั่งเก็บสมุนไพรหุบเขา ----- */
  A.forage = {
    nameTh: 'เก็บสมุนไพรหุบเขา', icon: '🌿', color: '#6fbf73',
    can: (n, W) => n.h.state.energy > 35 && n.h.state.satiety > 30 && !(n.inj && n.inj.length) && !!W.map.byId.grove,
    score(n, W, S) {
      const sc = (CPE.scarcity(W, 'MAT_HERB_DEW_GRASS_1') + CPE.scarcity(W, 'MAT_HERB_CINDER_LEAF_1') + CPE.scarcity(W, 'MAT_HERB_JADE_LOTUS_2')) / 3;
      const rate = 6 * sc * (0.8 + (n.h.skills.herbalism || 0) / 120);
      S.add('เก็บสมุนไพรแลกคุณูปการ ≈' + Math.round(rate) + '/ชม. (ของ' + (sc > 1.3 ? 'ขาด' : sc < 0.8 ? 'ล้น' : 'พอดี') + ')', clamp(rate / 14, 0, 0.9) * (0.55 + CPE.drive(n) * 0.9));
      interestTerm(n, 'herbs', S, 0.5); S.add('ชอบท่องธรรมชาติ', (E(n, 'interests.exploring') - 50) / 220);
      if (n.rank >= 3) S.add('ผู้ใหญ่ไม่ต้องเก็บเอง', -0.5 - (n.rank - 3) * 0.3); if (n.rank === 0) S.add('งานของศิษย์ใหม่', 0.2 * AI.dutyWeight(n));
      if (n.h.state.energy < 50) S.add('เหนื่อย', -0.3); if (W.weather && ['storm', 'rain', 'snow'].includes(W.weather.kind)) S.add('อากาศไม่เป็นใจ', -0.5);
    },
    where: (W, n) => { const s = AI.freeStation(W, n, 'explore', 'grove'); return s ? { st: s } : null; },
    dur: n => 150 + Math.round(E(n, 'personality.discipline') * 0.5),
    start(n, W, ctx) { ctx.items = {}; ctx.cpValue = 0; return true; },
    tick(n, W, ctx) {
      n.h.state.energy = Math.max(0, n.h.state.energy - 0.06); n.h.state.rest -= 0.03; (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(n, 'herbalism', 1 / 55, 1);
      if (W.t % 60 === 0) {
        const sk = n.h.skills.herbalism || 0, cnt = Math.max(1, Math.round((1.4 + sk / 55) * (0.7 + W.rng.next() * 0.6) * (W.season === 3 ? 0.6 : W.season === 0 ? 1.2 : 1)));
        for (let i = 0; i < cnt; i++) { const r = W.rng.next(); const tier = r < 0.02 + sk / 1500 ? 3 : r < 0.18 + sk / 400 ? 2 : 1; const pool = ECO.herbPool ? ECO.herbPool(tier) : null; const id = pool ? W.rng.pick(pool) : null; if (id) { ctx.cpValue += CPE.reward(W, id, 1); ECO.add(W, id, 1); ctx.items[id] = (ctx.items[id] || 0) + 1; } }
        HC.trainBody(n, 'endurance', 0.6); if (W.rng.chance(0.004 * (1 - E(n, 'intellect.perceptiveness') / 180))) AI.injure(W, n, 1, 'ถูกสัตว์ป่าทำร้ายในหุบเขา');
      }
      AI.vf(n, { sectDuty: 0.03, freedom: 0.02 }); if (n.h.state.energy < 12) return 'done';
    },
    done(n, W, ctx) { const v = ctx.cpValue || 0, c = Object.values(ctx.items || {}).reduce((s, x) => s + x, 0); n.merit += 0.3 + c * 0.03; CPE.mint(W, n, v, 'เก็บสมุนไพร ' + c + ' ต้น', true); CPE.S(W).donated += v; }
  };
  const HERB_POOL = { 1: ['MAT_HERB_DEW_GRASS_1', 'MAT_HERB_CINDER_LEAF_1'], 2: ['MAT_HERB_JADE_LOTUS_2', 'MAT_HERB_MIST_ORCHID_2'], 3: ['MAT_HERB_BLOOD_GINSENG_3', 'MAT_HERB_VENOM_VINE_3', 'MAT_HERB_MERIDIAN_FLOWER_3'] };
  ECO.herbPool = t => HERB_POOL[t] || HERB_POOL[1];
  CPE.drive = n => clamp((E(n, 'values.wealthResource') * 0.45 + E(n, 'personality.ambition') * 0.3 + E(n, 'personality.discipline') * 0.25) / 100, 0.1, 1);
  function interestTerm(n, id, S, w) { const v = (E(n, 'interests.' + id) - 50) / 100 * w; S.add('สนใจ' + id, v); }

  /* ----- หลอมโอสถพื้นฐานให้สำนัก (ทุกคนทำได้ สำนักออกวัตถุดิบ) ----- */
  function getBasicMask(W) {
    if (!W || !W.sect) return 0;
    const seq = W._stockSeq || 0, pop = W.npcs ? W.npcs.length : 0;
    if (W._pbSeq === seq && W._pbPop === pop && W._pbMask !== undefined) return W._pbMask;
    const basics = JD.CP.BASIC;
    let mask = 0;
    for (let i = 0; i < basics.length; i++) {
      const r = basics[i];
      if (!ECO.inputsOk(W, r)) continue;
      const key = 'P:' + r.id;
      if (ECO.count(W, key) >= CPE.target(W, key) * 1.6) continue;
      mask |= (1 << i);
    }
    W._pbSeq = seq; W._pbPop = pop; W._pbMask = mask;
    return mask;
  }
  function pickBasic(W, n) {
    if (W && n._pbTick === W.t && n._pbSeq === W._stockSeq) return n._pbVal;
    const mask = getBasicMask(W);
    if (mask === 0) {
      if (W) { n._pbTick = W.t; n._pbSeq = W._stockSeq; }
      return (n._pbVal = null);
    }
    let best = null, bs = -1e9; const sk = n.h.skills.ALCHEMY || 0;
    const basics = JD.CP.BASIC;
    const nSeed = (n.n || 1) * 31 + ((W && W.day) || 0) * 17;
    for (let i = 0; i < basics.length; i++) {
      if ((mask & (1 << i)) === 0) continue;
      const r = basics[i];
      if (r.tier > 1 && sk + 25 < r.minMastery) continue;
      const key = 'P:' + r.id, have = ECO.count(W, key), tgt = CPE.target(W, key);
      const detTie = (((nSeed + i * 29) & 0x7fffffff) % 100) / 1000;
      const s = (tgt - have) / tgt + detTie - r.tier * 0.05;
      if (s > bs) { bs = s; best = { r, short: s }; }
    }
    if (W) { n._pbTick = W.t; n._pbSeq = W._stockSeq; }
    return (n._pbVal = best);
  }
  A.brewBasic = {
    nameTh: 'หลอมโอสถพื้นฐานให้สำนัก', icon: '🧪', color: '#8fd3c8',
    can: (n, W) => n.h.state.energy > 30 && n.h.state.satiety > 25 && !!pickBasic(W, n) && !(n.inj && n.inj.some(i => i.sev >= 2)),
    score(n, W, S) {
      const p = pickBasic(W, n); if (!p) return; const key = 'P:' + p.r.id, sc = CPE.scarcity(W, key);
      S.add('สำนักขาด' + ECO.name(key) + ' (คุณูปการ×' + sc.toFixed(1) + ')', clamp((sc - 0.7) * 0.6, 0, 0.9) * (0.6 + CPE.drive(n) * 0.7));
      interestTerm(n, 'alchemy', S, 0.8); S.add('ฝีมือปรุงโอสถ', (n.h.skills.ALCHEMY || 0) / 250); S.add('หน้าที่ต่อสำนัก', 0.2 * AI.dutyWeight(n));
      if (n.rank >= 4) S.add('ผู้ใหญ่ไม่ลงมือเอง', -0.35);
    },
    where(W, n) { const p = pickBasic(W, n); if (!p) return null; const s = AI.freeStation(W, n, 'cauldron', 'alchemy'); return s ? { st: s, rid: p.r.id } : null; },
    dur: (n) => Math.round(65 * (1 - 0.3 * (n.h.skills.ALCHEMY || 0) / 100)),
    start(n, W, ctx) { const r = ECO.recipeById[ctx.rid]; return !!r && ECO.reserveInputs(W, r, ctx, n); },
    tick(n, W) { n.h.state.energy = Math.max(0, n.h.state.energy - 0.04); n.h.state.rest -= 0.02; if (W.t % 45 === 0) HC.trainBody(n, 'dexterity', 0.5); AI.vf(n, { knowledgeCraft: 0.04, sectDuty: 0.03 }); },
    done(n, W, ctx) {
      const r = ECO.recipeById[ctx.rid]; if (!r) return;
      const key = r.outItemId || 'P:' + r.id, before = ECO.count(W, key), res = ECO.finishCraft(W, n, r, ctx); if (res.rejected) return;
      if (res.ok && res.key) { const sc = clamp((CPE.target(W, res.key) + 2) / (before + 2), 0.7, 2); const v = ECO.base(res.key) * res.n * 0.25 * res.q * sc; CPE.mint(W, n, v, 'หลอม ' + res.text, true); CPE.S(W).donated += v; n.merit += 0.8; W.sect.produced = (W.sect.produced || 0) + 1; if (W.rng.chance(0.06)) W.log('craft', n.h.name.given + ' หลอมโอสถพื้นฐานให้สำนัก: ' + res.text, [n.id]); }
      else { HC.feel(n, { mood: -3 }); }
    }
  };

  /* ----- บริจาคของที่สมาชิกเก็บไว้เอง (วัตถุดิบ / คัมภีร์วิชา / ม้วนตำรับ) ----- */
  const personalMats = n => { const m = n && n.inv && n.inv.mats; if (!m) return []; const out = []; for (const k in m) { if (m[k] > 0 && !ECO.REPAIR_STONES[k]) out.push(k); } return out; };
  const personalTechs = (n, W) => { const a = n && n.inv && n.inv.techs; if (!a || !a.length) return []; return Array.from(new Set(a)).filter(id => !!CULT.tech(id) && (!W || !W.sect.library.includes(id))); };
  const personalRecipes = n => { const a = n && n.inv && n.inv.recipes; if (!a || !a.length) return []; return Array.from(new Set(a)).filter(id => !!ECO.recipeById[id]); };
  const personalSurplusGear = (n, W) => {
    if (!n || !n.inv || !Array.isArray(n.inv.gear) || !n.inv.gear.length) return [];
    return n.inv.gear.filter(eq => {
      if (!eq || !eq.slot || eq.retired || (eq.procedural && eq.dur != null && eq.dur <= 0 && (eq.maxDur || 100) <= 20)) return false;
      if (g.MARTIAL && g.MARTIAL.classifyGearForNpc) {
        const cls = g.MARTIAL.classifyGearForNpc(W, n, eq, 0);
        return cls.category === 'surplus' || cls.category === 'gift-worthy';
      }
      return true;
    });
  };
  CPE.evaluatePersonalBagGear = (W, n) => {
    if (!n || n.dead || !n.inv || !Array.isArray(n.inv.gear) || !n.inv.gear.length) return { equipped: 0, retired: 0, surplusCount: 0 };
    let equipped = 0, retired = 0;
    for (let i = n.inv.gear.length - 1; i >= 0; i--) {
      const eq = n.inv.gear[i];
      if (!eq || !eq.slot) { n.inv.gear.splice(i, 1); continue; }
      if (eq.retired || (eq.procedural && eq.dur != null && eq.dur <= 0 && (eq.maxDur || 100) <= 20)) {
        if (ECO && ECO.retireGear) ECO.retireGear(W, n, eq);
        else n.inv.gear.splice(i, 1);
        retired++;
        continue;
      }
      if (n.cult && g.MARTIAL && g.MARTIAL.classifyGearForNpc) {
        const cls = g.MARTIAL.classifyGearForNpc(W, n, eq, 0);
        if (cls.category === 'useful-now' && SECT && SECT.EDITOR && SECT.EDITOR.equipPersonalGear) {
          const res = SECT.EDITOR.equipPersonalGear(W, n.id, eq.uid || eq.id);
          if (res && res.ok) equipped++;
        }
      }
    }
    const surplus = personalSurplusGear(n, W);
    return { equipped, retired, surplusCount: surplus.length, surplus };
  };
  const personalDonateFrac = n => clamp(0.38 + E(n, 'personality.integrity') / 260 + E(n, 'personality.loyalty') / 360 - E(n, 'values.wealthResource') / 520, 0.25, 0.92);
  const personalOrgansList = n => Object.keys((n && n.inv && n.inv.organs) || {}).filter(k => n.inv.organs[k] > 0);
  const hasDonatableMats = n => { const m = n && n.inv && n.inv.mats; if (!m) return false; let f = -1; for (const k in m) { const q = m[k]; if (q > 0 && !ECO.REPAIR_STONES[k]) { if (q > 1) return true; if (f < 0) f = personalDonateFrac(n); if (f >= 0.68) return true; } } return false; };
  A.donate = {
    nameTh: 'นำของส่วนตัวบริจาค', icon: '🎁', color: '#c6a4f5',
    can: (n, W) => n.h.state.energy > 15 && n.h.state.satiety > 15 && (hasDonatableMats(n) || personalOrgansList(n).length > 0 || personalTechs(n, W).length > 0 || personalRecipes(n).length > 0 || personalSurplusGear(n, W).length > 0),
    score(n, W, S) {
      const ids = personalMats(n), orgIds = personalOrgansList(n), techs = personalTechs(n, W), recipes = personalRecipes(n), gears = personalSurplusGear(n, W);
      if (!ids.length && !orgIds.length && !techs.length && !recipes.length && !gears.length) return;
      let value = 0, shortage = 0;
      ids.forEach(k => { const q = n.inv.mats[k] || 0, sc = CPE.scarcity(W, k); value += CPE.reward(W, k, q); shortage += Math.max(0, sc - 0.7); });
      techs.forEach(id => { value += CPE.techReward(W, id); });
      recipes.forEach(id => { if (!W.sect.knownRecipes.includes(id)) value += g.CONTENT && g.CONTENT.recipeReward ? g.CONTENT.recipeReward(W, id) : 12 * (ECO.recipeById[id].tier || 1); });
      orgIds.forEach(oid => { const o = g.CONTENT && g.CONTENT.organById && g.CONTENT.organById[oid]; value += (o ? 12 * (o.tier || 1) : 15) * (n.inv.organs[oid] || 0); });
      gears.forEach(eq => { value += Math.floor(CPE.gearPrice(W, eq) * 0.55); });
      S.add('อยากได้แต้มไว้แลกของ', clamp((150 - (n.cp || 0)) / 150, -0.2, 0.8) * 0.65);
      S.add('ซื่อสัตย์และภักดี', (E(n, 'personality.integrity') - 45) / 180 + (E(n, 'personality.loyalty') - 45) / 220);
      S.add('สำนักกำลังขาดวัตถุดิบ', ids.length ? clamp(shortage / ids.length, 0, 1) * 0.55 : 0);
      if (gears.length) S.add('บริจาคอุปกรณ์ส่วนเกินเข้าคลังแสง (' + gears.length + ' ชิ้น)', Math.min(0.85, 0.35 + gears.length * 0.2));
      S.add('มูลค่าของที่ถือ', clamp(value / 90, 0, 0.55));
      S.add('หวงทรัพย์ส่วนตัว', -(E(n, 'values.wealthResource') - 50) / 190);
      if (n.act && n.act.id === 'donate') S.add('กำลังจัดการของอยู่', -0.8);
    },
    where: (W, n) => {
      const hasScroll = personalTechs(n, W).length > 0 || personalRecipes(n).length > 0;
      const st = (hasScroll ? AI.freeStation(W, n, 'read', 'scripture') : null) || AI.freeStation(W, n, 'browse', 'market') || AI.freeStation(W, n, 'desk', 'treasury');
      return st ? { st } : null;
    },
    dur: n => 25 + Math.round((100 - E(n, 'personality.integrity')) * 0.15),
    done(n, W) {
      CPE.evaluatePersonalBagGear(W, n);
      const ids = personalMats(n), orgIds = personalOrgansList(n), techs = personalTechs(n, W), recipes = personalRecipes(n), gears = personalSurplusGear(n, W);
      if (!ids.length && !orgIds.length && !techs.length && !recipes.length && !gears.length) return;
      const loyalty = E(n, 'personality.loyalty'), frac = personalDonateFrac(n);
      let total = 0, units = 0, scrolls = 0, formulas = 0, formulaCp = 0, gearCount = 0, gearCp = 0; const accepted = {};
      ids.forEach(k => {
        const held = n.inv.mats[k] || 0;
        const give = held <= 1 ? (frac >= 0.68 ? held : 0) : Math.min(held - 1, Math.max(1, Math.floor(held * frac)));
        if (give <= 0) return;
        const spawnedHeld = (n.inv.spawnedMats && n.inv.spawnedMats[k]) || 0;
        const spawnedUsed = Math.min(give, spawnedHeld);
        const rewardable = Math.max(0, give - spawnedUsed);
        const before = ECO.count(W, k), v = rewardable > 0 ? CPE.reward(W, k, rewardable, before) : 0;
        ECO.add(W, k, give); n.inv.mats[k] -= give; if (n.inv.mats[k] <= 0) delete n.inv.mats[k];
        if (spawnedUsed > 0 && n.inv.spawnedMats) {
          n.inv.spawnedMats[k] -= spawnedUsed;
          if (n.inv.spawnedMats[k] <= 0) delete n.inv.spawnedMats[k];
        }
        accepted[k] = give; total += v; units += give;
      });
      techs.forEach(id => {
        const t = CULT.tech(id);
        if (!t) return;
        const isSpawned = Array.isArray(n.inv.spawnedTechs) && n.inv.spawnedTechs.includes(id);
        if (isSpawned) n.inv.spawnedTechs.splice(n.inv.spawnedTechs.indexOf(id), 1);
        if (!W.sect.library.includes(id)) { W.sect.library.push(id); if (g.COG && g.COG.recordHallAddition) g.COG.recordHallAddition(W, 'library', id, n.id); if (!isSpawned) total += CPE.techReward(W, id); scrolls++; }
        n.inv.techs = (n.inv.techs || []).filter(x => x !== id);
      });
      recipes.forEach(id => {
        if (g.CONTENT && g.CONTENT.donateRecipe) {
          const isSpawned = Array.isArray(n.inv.spawnedRecipes) && n.inv.spawnedRecipes.includes(id);
          if (isSpawned) n.inv.spawnedRecipes.splice(n.inv.spawnedRecipes.indexOf(id), 1);
          const beforeCp = n.cp || 0, beforeMint = CPE.S(W).minted;
          const res = g.CONTENT.donateRecipe(W, n, id, { quiet: true });
          if (res && res.ok) {
            if (isSpawned && res.reward > 0) {
              n.cp = beforeCp;
              CPE.S(W).minted = beforeMint;
              CPE.S(W).donated = Math.max(0, CPE.S(W).donated - res.reward);
              res.reward = 0;
            }
            formulas++; formulaCp += res.reward || 0;
          }
        }
      });
      gears.forEach(eq => {
        const cls = (g.MARTIAL && g.MARTIAL.classifyGearForNpc) ? g.MARTIAL.classifyGearForNpc(W, n, eq, 0) : null;
        if (cls && cls.category === 'gift-worthy' && cls.targetNpcId && g.COG && typeof g.COG.giveGearGift === 'function') {
          const targetNpc = W.byId && W.byId[cls.targetNpcId];
          if (targetNpc && !targetNpc.dead && !targetNpc.away) {
            const giftRes = g.COG.giveGearGift(W, n, targetNpc, eq);
            if (giftRes && giftRes.ok) {
              gearCount++;
              return;
            }
          }
        }
        if (SECT && SECT.EDITOR && SECT.EDITOR.donatePersonalGear) {
          const gRes = SECT.EDITOR.donatePersonalGear(W, n.id, eq.uid || eq.id);
          if (gRes && gRes.ok) {
            gearCount++;
            gearCp += gRes.reward || 0;
          }
        }
      });
      let organCount = 0, organCp = 0;
      orgIds.forEach(oid => {
        const qty = (n.inv && n.inv.organs && n.inv.organs[oid]) || 0;
        if (qty > 0 && g.CONTENT && g.CONTENT.donateOrgan) {
          const res = g.CONTENT.donateOrgan(W, n, oid, qty);
          if (res && res.ok) { organCount += qty; organCp += res.reward || 0; }
        }
      });
      if (!units && !organCount && !scrolls && !formulas && !gearCount) { HC.feel(n, { mood: -0.2 }); return; }
      if (g.SECT && g.SECT.notifyStockChanged) g.SECT.notifyStockChanged(W);
      if (total > 0) { CPE.mint(W, n, total, 'บริจาควัตถุดิบส่วนตัว', true); CPE.S(W).donated += total; }
      const grandTotal = total + formulaCp + gearCp;
      const detail = Object.keys(accepted).slice(0, 3).map(k => ECO.name(k) + ' ×' + accepted[k]).join('、');
      const parts = []; if (units) parts.push('วัตถุดิบ ' + detail + (Object.keys(accepted).length > 3 ? ' และอื่น ๆ' : '')); if (scrolls) parts.push('คัมภีร์ ' + scrolls + ' เล่ม'); if (formulas) parts.push('ม้วนตำรับ ' + formulas + ' ม้วน'); if (gearCount) parts.push('ศาสตรา ' + gearCount + ' ชิ้น');
      note(W, n.h.name.given + ' บริจาค' + parts.join(' + ') + ' ได้ ' + Math.round(grandTotal) + ' คป.');
      W.log('finance', n.h.name.given + ' นำของส่วนตัวกลับเข้าคลัง/หอคัมภีร์ แลก ' + Math.round(grandTotal) + ' คป.', [n.id]);
      HC.feel(n, { mood: 1 + loyalty / 100 }); AI.mem(W, n, 'บริจาคของส่วนตัวเข้าคลังสำนัก', 0.25);
    }
  };

  /* ----- ร้านค้าสำนัก ----- */
  const pathCrystalPrice = (W, key) => Math.max(25, Math.round(((ECO.price && ECO.price(W, key)) || 120) * 0.45));
  CPE.shopItems = W => {
    const S = W.sect, out = [];
    Object.keys(S.stock).forEach(k => {
      if (ECO.isPill(k) && S.stock[k] > 0) out.push({ kind: 'pill', key: k, n: S.stock[k], price: CPE.priceOf(W, k) });
      else if (k.startsWith('CRYSTAL_PATH_') && S.stock[k] > 0) out.push({ kind: 'path_crystal', key: k, n: S.stock[k], price: pathCrystalPrice(W, k) });
    });
    S.gear.forEach(gr => {
      if (!gr || gr.broken || gr.retired || (gr.procedural && (gr.dur || 0) <= 0)) return;
      out.push({ kind: 'gear', gear: gr, price: CPE.gearPrice(W, gr) });
    });
    return out;
  };
  const effOf = k => { const i = ECO.pillInfo(k); return i ? i.effect : {}; };
  CPE.pickPurchase = (W, n) => {
    const cp = n.cp || 0, c = n.cult; if (cp < 4) return null;
    const hm0 = n._nd ? n._nd.hpMax : CULT.hpMax(n);
    const sSeq = (W._pillSeq || 0) * 4096 + ((W.sect && W.sect.crystalsVer) || 0), hpBand = n.h.state.hp >= hm0 * 0.73 ? 8 : ((n.h.state.hp * 0.5) | 0), injLen = n.inj ? n.inj.length : 0;
    if (W.t > 0 && n._pickCache && (n._pickCache.t === W.t || (W.t > n._pickCache.t && W.t - n._pickCache.t < 180 && n._pickCache.sSeq === sSeq && n._pickCache.ver === n._ver)) && n._pickCache.path === (c && c.path) && n._pickCache.stage === (c && c.stage) && (W.t === n._pickCache.t ? n._pickCache.cp === cp : (Math.abs(cp - n._pickCache.cp) < 3 && (cp | 0) === (n._pickCache.cp | 0))) && n._pickCache.hpBand === hpBand && n._pickCache.gearLen === W.sect.gear.length && n._pickCache.injLen === injLen) return n._pickCache.val;
    let best = null, bs = 0;
    const have = k => (n.inv.pills && n.inv.pills[k]) || 0;
    const consider = (it, s, why) => { if (it.price == null) it.price = it.kind === 'path_crystal' ? pathCrystalPrice(W, it.key) : CPE.priceOf(W, it.key); if (it.price > cp * 0.9) return; s -= it.price / Math.max(40, cp) * 0.4; if (s > bs) { bs = s; best = Object.assign({ why, s }, it); } };
    const hpRatio = n.h.state.hp / Math.max(1, hm0), th0 = c ? CULT.threshold(n) : 0, eqSt0 = c ? (n._nd ? n._nd.eqStage : CULT.equivalentStage(n)) : 0;
    if (W._pillStockKeysSeq !== (W._pillSeq || 0) || !W._pillStockKeys) {
      const pks = [];
      for (const k in W.sect.stock) {
        if (W.sect.stock[k] > 0 && (k.charCodeAt(0) === 80 || ECO.isPill(k))) pks.push(k);
      }
      W._pillStockKeys = pks;
      W._pillStockKeysSeq = W._pillSeq || 0;
    }
    const abstainingPills = !!(CULT.isAbstainingFromPills && CULT.isAbstainingFromPills(n));
    const mappedBtKey = (c && g.BN && g.BN.resolveBreakthroughPillKey) ? g.BN.resolveBreakthroughPillKey(c) : (c ? ("P:BT_" + c.path + "_" + c.stage) : "");
    const pillKeys = abstainingPills ? [] : W._pillStockKeys;
    for (let pki = 0; pki < pillKeys.length; pki++) {
      const k = pillKeys[pki];
      if (W.sect.stock[k] <= 0) continue; const e = effOf(k), it = { kind: 'pill', key: k, price: null };
      const info = ECO.pillInfo(k);
      if (e.taboo && (!c || c.path !== 'DEMON') && E(n, 'personality.integrity') > 35) continue;
      if (BASIC_IDS.includes(k)) { const isZeroQi = !!(CULT.isZeroQiSamurai && CULT.isZeroQiSamurai(n)); const need = (e.healHealth && have(k) < 2 ? 0.7 : 0) + (e.healInjury && n.inj && n.inj.length ? 1.2 : 0) + (!isZeroQi && e.qiRestore && c && have(k) < 1 && n.rank >= 1 ? 0.35 : 0) + (e.clearHeartDemon && n.h.state.heartDemon > 25 ? 0.7 : 0) + (e.clearToxic && c && c.toxic > 20 ? 0.7 : 0) + (e.energyRestore && n.h.state.energy < 40 ? 0.4 : 0); if (need > 0 && have(k) < 3) consider(it, need * (1 - (E(n, 'personality.caution') < 30 ? 0.3 : 0)), 'สำรองไว้ใช้'); continue; }
      if (!info || (e.compatiblePath && (!c || e.compatiblePath !== c.path))) continue;
      if (e.healHealth && hpRatio < 0.72 && have(k) < 1) consider(it, 0.65 + (1 - hpRatio) * 1.5, 'โอสถรักษาระดับสูง');
      if (e.healInjury && n.inj && n.inj.length && have(k) < 1) consider(it, 1.1 + Math.min(0.8, n.inj.length * 0.2), 'รักษาบาดแผลหนัก');
      if (e.clearToxic && c && (c.toxic || 0) > 25 && have(k) < 1) consider(it, 0.8 + c.toxic / 100, 'ถอนพิษสะสม');
      if (e.clearHeartDemon && n.h.state.heartDemon > 32 && have(k) < 1) consider(it, 0.7 + n.h.state.heartDemon / 120, 'ระงับจิตมาร');
      if (e.insight && c && have(k) < 1 && (c.learning || E(n, 'personality.curiosity') > 65)) consider(it, 0.65 + E(n, 'personality.curiosity') / 250, 'เพิ่มความเข้าใจคัมภีร์');
      if (!c) continue;
      if (e.btFor) {
        if (((e.btFor.path === c.path && e.btFor.stage === c.stage) || k === mappedBtKey) && have(k) < 1 && (c.bn || c.prog >= th0 * 0.75)) consider(it, c.bn ? 3.5 : 2.6, 'โอสถทะลวงขั้น');
        continue;
      }
      if (e.breakthroughBonus && !e.btFor && have(k) < 1 && (c.bn || c.prog >= th0 * 0.75) && info.tier <= eqSt0 + 1) {
        consider(it, c.bn ? 2.8 : 2.0, 'โอสถหนุนทะลวงด่าน');
        continue;
      }
      if (e.cbBuff) {
        const combatInt = E(n, 'interests.combat') || 50;
        const courage = E(n, 'personality.courage') || 50;
        if (have(k) < 1 && (n.rank >= 1 || combatInt > 45 || courage > 55)) {
          consider(it, 0.45 + (combatInt / 180), 'ยาเตรียมศึก');
        }
        continue;
      }
      if (e.cultivationProgress && info.tier <= eqSt0 + 1 && c.prog < th0 * 0.85 && (c.toxic || 0) < (c.path === 'DEMON' ? 50 : 35)) consider(it, 0.5 + e.cultivationProgress / 160 + (E(n, 'personality.ambition') - 50) / 250, 'เร่งตบะ');
    }
    // Mortals (or stage<=1 uncommitted disciples) may purchase CRYSTAL_PATH_* matching their aptitude
    if (!c && W.sect && W.sect.stock) {
      const mRows = CULT.majorPathScores ? CULT.majorPathScores(n) : [];
      const topScore = mRows[0] ? mRows[0].score : 50;
      for (const k in W.sect.stock) {
        if (!k.startsWith('CRYSTAL_PATH_') || W.sect.stock[k] <= 0) continue;
        const pKey = k.replace(/^CRYSTAL_PATH_/, '');
        if (!CULT.PATHS[pKey]) continue;
        const row = mRows.find(r => r.path === pKey);
        const fitScore = row ? row.score : 45;
        if (fitScore >= topScore - 10) {
          consider({ kind: 'path_crystal', key: k, price: null }, 1.25 + Math.max(0, (fitScore - 40) / 80), 'ผลึกเบิกเนตรมหาวิถี');
        }
      }
    }
    const savingForTech = n.cognition?.goal?.id === "scripture" && n.cognition.goal.targetId ? CULT.tech(n.cognition.goal.targetId) : null;
    const reserveTechCp = savingForTech ? CPE.techPrice(W, savingForTech) : 0;
    if (c && (!savingForTech || cp > reserveTechCp * 1.15)) {
      const profWpn = (g.MARTIAL && g.MARTIAL.PROFILES && g.MARTIAL.PROFILES[c.sub] && g.MARTIAL.PROFILES[c.sub][3]) || [];
      const curWpn = n.equip && n.equip.WEAPON;
      const curIsFallback = !!(curWpn && g.MARTIAL && !profWpn.includes(g.MARTIAL.gearType(curWpn)));
      const inHysteresis = n._lastGearSwapAt != null && (W.t - n._lastGearSwapAt) < (curIsFallback ? 180 : 1440);
      const multReq = inHysteresis ? 1.38 : 1.2, flatReq = inHysteresis ? 16 : 8;
      const effSt = CULT.effectiveTechStage ? CULT.effectiveTechStage(n) : c.stage;
      if (W.sect.gear.length > 0) ["WEAPON", "ARMOR", "ACCESSORY"].forEach(slot => {
        let cs = null;
        W.sect.gear.forEach(gr => {
          if (!gr || gr.broken || gr.retired || (gr.procedural && (gr.dur || 0) <= 0)) return;
          if (gr.slot !== slot || (gr.minStage || 1) > effSt || (g.MARTIAL && g.MARTIAL.gearUsable && !g.MARTIAL.gearUsable(n, gr))) return;
          const price = CPE.gearPrice(W, gr);
          if (price > cp * 0.9) return;
          if (cs === null) { const cur = n.equip && n.equip[slot]; cs = cur ? g.MARTIAL.gearSuitability(n, cur, 0).score : 0; }
          const fit = g.MARTIAL.gearSuitability(n, gr, 0), gs = fit.score;
          const isGoalTarget = n.cognition?.goal?.id === "gear_upgrade" && n.cognition.goal.targetId === (gr.uid || gr.id);
          if (gs > cs * multReq + flatReq || (isGoalTarget && gs > cs + 6)) {
            const goalBonus = isGoalTarget ? 0.65 : 0;
            consider({ kind: "gear", gear: gr, price }, 0.6 + goalBonus + Math.min(1.2, (gs - cs) / Math.max(40, cs)) * 0.5, fit.reasons.join(" · "));
          }
        });
      });
    }
    if (c && c.track && CULT.checkTrackGates && (CULT.trackReady(n) || c.track.prog >= CULT.trackThreshold(n) * 0.65)) {
      const tg = CULT.checkTrackGates(W, n);
      if (tg.skillOk !== false && !tg.resourceOk && tg.missingStones && tg.missingStones.deficit > 0 && W.sect && (W.sect.stones || 0) >= 10 && cp >= 8) {
        const kScope = (g.COG && g.COG.knowledgeScope) ? g.COG.knowledgeScope(W, n) : null;
        const maxGrantCap = (!kScope || kScope.canSeeFullTreasury) ? Math.floor(W.sect.stones * 0.25) : Math.min(80, Math.floor(W.sect.stones * 0.20));
        const grantStones = Math.min(tg.missingStones.deficit, maxGrantCap, Math.floor(cp * 2.5));
        if (grantStones >= 5) {
          const grantPrice = Math.max(4, Math.ceil(grantStones / 2.5));
          consider({ kind: 'stone_grant', key: 'STONE_GRANT', nameTh: 'เบิกศิลาวิญญาณ ×' + grantStones, stones: grantStones, price: grantPrice }, 2.75, 'สะสมศิลาวิญญาณเพื่อทะลวงสายเฉพาะทาง');
        }
      }
    }
    if (W.t > 0) n._pickCache = { t: W.t, sSeq, ver: n._ver, path: c && c.path, stage: c && c.stage, cp, hpBand, gearLen: W.sect.gear.length, injLen, val: best };
    return best;
  };
  CPE.buy = (W, n, p) => {
    if (p && p.kind === 'path_crystal' && p.key && p.key.startsWith('CRYSTAL_PATH_') && Number.isFinite(p.price) && p.price > 0) {
      const pKey = p.key.replace(/^CRYSTAL_PATH_/, '');
      const quote = pathCrystalPrice(W, p.key);
      if (!CULT.PATHS[pKey] || p.price !== quote || !ECO.take(W, p.key, 1)) return false;
      if (!CPE.spend(W, n, quote, 'แลก' + ECO.name(p.key))) { ECO.add(W, p.key, 1); return false; }
      const bRes = (CULT.MORTAL_INITIATION && CULT.MORTAL_INITIATION.bestowPathCrystal)
        ? CULT.MORTAL_INITIATION.bestowPathCrystal(W, n, pKey, { free: true, fromShop: true })
        : { ok: false };
      if (!bRes || !bRes.ok) {
        CPE.mint(W, n, quote, 'คืนแต้มผลึกมรรคาไม่เข้าเกณฑ์');
        ECO.add(W, p.key, 1);
        return false;
      }
      CPE.S(W).sales++;
      W.log('shop', '[ซื้อสินค้า] ' + n.h.name.given + ' แลกคุณูปการ ' + quote + ' คป. ใช้「' + ECO.name(p.key) + '」', [n.id], { txKind: 'purchase', itemId: p.key, qty: 1, recipientId: n.id });
      return true;
    }
    if (p && p.kind === 'stone_grant' && Number.isFinite(p.price) && p.price > 0 && Number.isFinite(p.stones) && p.stones > 0) {
      if (!W || !W.sect || !n || !n.cult || !n.cult.track || !CULT.checkTrackGates) return false;
      const tg = CULT.checkTrackGates(W, n);
      const deficit = (!tg.resourceOk && tg.missingStones && tg.missingStones.deficit > 0) ? tg.missingStones.deficit : 0;
      const maxGrant = Math.min(deficit || 0, Math.floor((W.sect.stones || 0) * 0.25), Math.floor((n.cp || 0) * 2.5));
      const reqStones = Math.floor(p.stones);
      if (reqStones < 5 || reqStones > maxGrant) return false;
      const expectedPrice = Math.max(4, Math.ceil(reqStones / 2.5));
      if (p.price !== expectedPrice || (W.sect.stones || 0) < reqStones) return false;
      if (!CPE.spend(W, n, expectedPrice, 'แลกศิลาวิญญาณทะลวงสายเฉพาะทาง')) return false;
      if (ECO.transferStones) {
        ECO.transferStones(W, { from: 'sect', to: 'npc:' + n.id, amount: reqStones, why: 'แลกศิลาวิญญาณทะลวงสายเฉพาะทาง' });
      } else {
        ECO.pay(W, reqStones, 'แลกศิลาวิญญาณทะลวงสายเฉพาะทาง', { internalTransfer: true });
        n.inv.stones = (n.inv.stones || 0) + reqStones;
        n.personalStones = n.inv.stones;
      }
      n.inv.earmarkedTrackStones = (n.inv.earmarkedTrackStones || 0) + reqStones;
      return true;
    }
    if (!p || !Number.isFinite(p.price) || p.price <= 0 || !['pill','gear'].includes(p.kind)) return false;
    const c = CPE.S(W);
    if (p.kind === 'pill') {
      const quote = CPE.priceOf(W, p.key);
      if (p.price !== quote || !ECO.isPill(p.key) || !ECO.pillInfo(p.key)) return false;
      const quality = ECO.pillQuality(W, p.key);
      if (!ECO.take(W, p.key, 1)) return false;
      if (!CPE.spend(W, n, p.price, 'ซื้อ' + ECO.name(p.key))) { ECO.add(W, p.key, 1, quality); return false; }
      ECO.addPersonalPill(n, p.key, quality);
      if (!BASIC_IDS.includes(p.key)) {
        W.log('shop', '[ซื้อสินค้า] ' + n.h.name.given + ' แลกคุณูปการ ' + p.price + ' คป. ซื้อ「' + ECO.name(p.key) + '」×1 จากร้านสำนัก', [n.id], { txKind: 'purchase', itemId: p.key, qty: 1, recipientId: n.id });
      }
    } else {
      if (!p.gear || !n || !n.cult) return false;
      const i = W.sect.gear.findIndex(x => x === p.gear || (p.gear.uid && x && x.uid === p.gear.uid)); if (i < 0) return false;
      const boughtGear = W.sect.gear[i];
      if (!boughtGear || boughtGear.broken || boughtGear.retired || (boughtGear.procedural && (boughtGear.dur || 0) <= 0)) return false;
      const effSt = n.cult ? (CULT.effectiveTechStage ? CULT.effectiveTechStage(n) : n.cult.stage) : 0;
      if (!['WEAPON', 'ARMOR', 'ACCESSORY'].includes(boughtGear && boughtGear.slot) || (boughtGear.minStage || 1) > effSt + 1) return false;
      const quote = CPE.gearPrice(W, boughtGear);
      if (p.price !== quote) return false;
      if (!CPE.spend(W, n, quote, 'ซื้อ' + boughtGear.nameTh)) return false;
      W.sect.gear.splice(i, 1);
      boughtGear.boughtFromSectShop = true;
      boughtGear.lastBuyerId = n.id;
      boughtGear.boughtAtDay = W.day;
      const oldHp = n.h && n.h.state ? n.h.state.hp : null, oldQi = n.h && n.h.state ? n.h.state.qi : null;
      const cur = n.equip[boughtGear.slot];
      if (cur) {
        n.inv = n.inv || {};
        n.inv.gear = n.inv.gear || [];
        n.inv.gear.push(cur);
      }
      n.equip[boughtGear.slot] = boughtGear; n._lastGearSwapAt = W.t; ST.dirty(n);
      if (g.COG && g.COG.reconcileLoadout) g.COG.reconcileLoadout(W, n);
      else if (g.MARTIAL && g.MARTIAL.reconcilePassives) g.MARTIAL.reconcilePassives(n);
      if (g.MARTIAL && g.MARTIAL.syncResourceCaps) g.MARTIAL.syncResourceCaps(n, oldHp, oldQi);
      if (g.SECT && g.SECT.notifyStockChanged) g.SECT.notifyStockChanged(W, boughtGear.id);
      W.log('gear', '[ซื้อสินค้า] ' + n.h.name.given + ' แลกคุณูปการ ' + p.price + ' คป. ซื้อ「' + boughtGear.nameTh + '」จากร้านสำนัก', [n.id], { txKind: 'purchase', itemId: boughtGear.id, itemUid: boughtGear.uid, qty: 1, recipientId: n.id });
    }
    c.sales++; HC.feel(n, { mood: 1.5 }); AI.mem(W, n, 'ซื้อ' + (p.kind === 'gear' ? p.gear.nameTh : ECO.name(p.key)) + 'ด้วยแต้มคุณูปการ', 0.25); return true;
  };
  A.shop = {
    nameTh: 'ร้านค้าสำนัก', icon: '🛒', color: '#e0b84a',
    can: (n, W) => (n.cp || 0) >= 4 && !!CPE.pickPurchase(W, n),
    score(n, W, S) { const p = CPE.pickPurchase(W, n); if (!p) return S.add('ไม่มีของที่อยากได้', -3); S.add('อยากได้ ' + (p.kind === 'gear' ? p.gear.nameTh : p.nameTh || ECO.name(p.key)) + ' (' + p.price + ' คป. · ' + p.why + ')', 0.55 + p.s * 0.35 + (E(n, 'values.wealthResource') - 50) / 300); },
    where: (W, n) => { const s = AI.freeStation(W, n, 'browse', 'market'); return s ? { st: s } : null; },
    dur: () => 25,
    done(n, W) { CPE.buy(W, n, CPE.pickPurchase(W, n)); }
  };
  AI.wantedPill = (W, n) => { const p = CPE.pickPurchase(W, n); return p && p.kind === 'pill' ? { key: p.key, price: p.price, name: ECO.name(p.key) } : null; };

  /* ----- บริการชี้แนะจากหอคัมภีร์: ใช้แต้มเป็นค่าครูและเผาออกจากระบบ ----- */
  CPE.guidanceTeacher = (W, n) => {
    const eligible = t => !!(t && t !== n && !t.dead && !t.away && !t.exiled && !(t.jail && t.jail > W.t) && (!t.act || (t.act.id !== 'sleep' && t.act.id !== 'fight')) && !(g.COMBAT && g.COMBAT.isUnitInActiveFight && g.COMBAT.isUnitInActiveFight(W, t)) && !(t.guidanceUntil > W.t) && (t.rank > n.rank || (t.cult && n.cult && (CULT.equivalentStage ? CULT.equivalentStage(t) > CULT.equivalentStage(n) : t.cult.stage > n.cult.stage))));
    const head = SECT.holder(W, 'scripture'); if (eligible(head)) return head;
    const master = W.byId[W.sect.masterId]; if (eligible(master)) return master;
    return W.npcs.find(eligible) || null;
  };
  CPE.guidanceFee = (W, n) => {
    const learning = n && n.cult && n.cult.learning, t = learning && CULT.tech(learning.id);
    if (!t) return 0;
    return Math.max(1, Math.round((20 + 8 * Math.pow(t.tier || 1, 2)) * CPE.S(W).price));
  };
  A.guidedStudy = {
    nameTh: 'ขอคำชี้แนะจากอาจารย์', icon: '🧑‍🏫', color: '#b9a1f5',
    can(n, W) {
      if (!n.cult || !n.cult.learning || (n.insightT || 0) > 0) return false;
      const last = n.guidanceDay == null ? -999 : n.guidanceDay;
      return W.day - last >= 16 && !!CPE.guidanceTeacher(W, n) && (n.cp || 0) >= CPE.guidanceFee(W, n);
    },
    score(n, W, S) {
      const fee = CPE.guidanceFee(W, n), teacher = CPE.guidanceTeacher(W, n);
      S.add('วิชาที่เรียนยังไม่สำเร็จ', 0.65);
      S.add('ใฝ่รู้', (E(n, 'personality.curiosity') - 45) / 180);
      S.add('มีอาจารย์ที่เหมาะสม', teacher ? 0.25 + Math.min(0.25, (teacher.h.skills.SCRIPTURE || 0) / 300) : -1);
      S.add('เหลือแต้มพอจ่าย', clamp(((n.cp || 0) - fee) / Math.max(1, fee), 0, 3) * 0.22);
      S.add('หวงทรัพย์ไว้ซื้อของ', -(E(n, 'values.wealthResource') - 50) / 280);
    },
    where: (W, n) => { const st = AI.freeStation(W, n, 'read', 'scripture'); return st ? { st } : null; },
    dur: () => 30,
    start(n, W, ctx) {
      const teacher = CPE.guidanceTeacher(W, n), fee = CPE.guidanceFee(W, n);
      if (!teacher || !n.cult || !n.cult.learning || (n.insightT || 0) > 0 || W.day - (n.guidanceDay == null ? -999 : n.guidanceDay) < 16) return false;
      if (!CPE.spend(W, n, fee, 'ค่าชี้แนะจากหอคัมภีร์')) return false;
      const honorarium = Math.max(1, Math.floor(fee * 0.30));
      CPE.mint(W, teacher, honorarium, 'ค่าบูชาครูชี้แนะ ' + n.h.name.given, true);
      ctx.teacherId = teacher.id; ctx.fee = fee; ctx.honorarium = honorarium; teacher.guidanceUntil = W.t + 36;
      const tier = (CULT.tech(n.cult.learning.id) || {}).tier || 1;
      ctx.rate = clamp(0.0035 + tier * 0.00045 + (teacher.h.skills.SCRIPTURE || 0) / 30000 + E(teacher, 'intellect.comprehension') / 50000, 0.004, 0.009);
      n.guidanceDay = W.day; n.insightT = 360;
      const c = CPE.S(W); c.studyFees = (c.studyFees || 0) + fee; c.studyServices = (c.studyServices || 0) + 1;
      return true;
    },
    tick(n, W, ctx) {
      const learning = n.cult && n.cult.learning;
      if (!learning) return 'done';
      const ancMult = (CULT.isAncestralBlessingActive ? CULT.isAncestralBlessingActive(n, W ? W.t : null) : (n.ancestralBlessing && (!n.ancestralBlessing.until || n.ancestralBlessing.until >= W.t))) && n.ancestralBlessing.studySpeedMult ? n.ancestralBlessing.studySpeedMult : 1;
      const fbStudy = (g.FISHING && g.FISHING.activeFoodBuff) ? ((g.FISHING.activeFoodBuff(W, n) || {}).studyMult || 1) : ((n.foodBuff && (!W || !Number.isFinite(W.t) || W.t < n.foodBuff.until) && n.foodBuff.studyMult) || 1);
      learning.got = Math.min(learning.need, learning.got + learning.need * (ctx.rate || 0.005) * ancMult * fbStudy);
      (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(n, 'SCRIPTURE', 1 / 30, 1.1);
      const teacher = W.byId[ctx.teacherId]; if (teacher && !teacher.dead) { (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(teacher, 'SCRIPTURE', 1 / 60, 0.8); teacher.merit = (teacher.merit || 0) + 0.005; }
      n.h.state.energy = Math.max(10, n.h.state.energy - 0.012); n.h.state.rest = Math.max(10, n.h.state.rest - 0.006);
    },
    done(n, W, ctx) {
      const teacher = W.byId[ctx.teacherId];
      W.log('finance', n.h.name.given + ' จ่าย ' + Math.round(ctx.fee || 0) + ' คป. ขอคำชี้แนะจาก ' + (teacher ? teacher.h.name.given : 'หอคัมภีร์') + ' วิชาที่กำลังเรียนคืบหน้าและได้รับความกระจ่าง', [n.id].concat(teacher ? [teacher.id] : []));
      HC.feel(n, { mood: 1.2 });
    },
    inside: true
  };

  /* ----- บริการฝึกปราณเร่งด่วน: ใช้ทรัพยากร/ผู้ดูแลของสำนัก แลกกับความก้าวหน้าและเผาแต้ม ----- */
  CPE.trainingFee = (W, n) => n && n.cult ? Math.max(1, Math.round((18 + 7 * Math.pow(n.cult.stage || 1, 2)) * CPE.S(W).price)) : 0;
  A.paidTraining = {
    nameTh: 'ซื้อสิทธิ์ฝึกปราณเข้มข้น', icon: '✨', color: '#70c6f2',
    can(n, W) {
      if (!n.cult || n.dead || n.away || (n.inj && n.inj.some(i => i.sev >= 2)) || n.h.state.energy < 30 || n.h.state.satiety < 25) return false;
      if (n.cult.stage >= CULT.maxStage(n) || n.cult.prog >= CULT.threshold(n) * 0.88) return false;
      const last = n.paidTrainingDay == null ? -999 : n.paidTrainingDay;
      return W.day - last >= 14 && (n.cp || 0) >= CPE.trainingFee(W, n);
    },
    score(n, W, S) {
      const fee = CPE.trainingFee(W, n);
      S.add('อยากเร่งตบะ', 0.72 + (E(n, 'personality.ambition') - 50) / 170);
      S.add('ให้ความสำคัญกับวิถียุทธ์', (E(n, 'values.martialPeak') - 45) / 190);
      S.add('มีแต้มเหลือจ่าย', clamp(((n.cp || 0) - fee) / Math.max(1, fee), 0, 3) * 0.28);
      S.add('หวงแต้มไว้ซื้อของ', -(E(n, 'values.wealthResource') - 50) / 260);
      S.add('ฝึกปกติก็พอ', -Math.max(0, (n.cult.prog / Math.max(1, CULT.threshold(n))) - 0.65) * 0.8);
    },
    where(W, n) {
      if (CULT && CULT.resolvePathStations) {
        const res = CULT.resolvePathStations(W, n, 'paidTraining');
        if (res && res.st) return { st: res.st };
      }
      const st = AI.freeStation(W, n, 'meditate', 'meditation_hall') || AI.freeStation(W, n, 'dummy', 'training_ground') || AI.freeStation(W, n, 'read', 'scripture');
      return st ? { st } : null;
    },
    dur: () => 90,
    start(n, W, ctx) {
      if (!A.paidTraining.can(n, W)) return false;
      const fee = CPE.trainingFee(W, n), threshold = CULT.threshold(n);
      if (!CPE.spend(W, n, fee, 'ซื้อสิทธิ์ฝึกปราณเข้มข้น')) return false;
      ctx.fee = fee; ctx.gain = Math.max(2, threshold * 0.04); ctx.perTick = ctx.gain / 90; ctx.gained = 0;
      n.paidTrainingDay = W.day;
      const c = CPE.S(W); c.trainingFees = (c.trainingFees || 0) + fee; c.trainingServices = (c.trainingServices || 0) + 1;
      return true;
    },
    tick(n, W, ctx) {
      if (!n.cult) return 'done';
      const before = n.cult.prog; CULT.gain(n, ctx.perTick || 0.1); ctx.gained += Math.max(0, n.cult.prog - before);
      n.h.state.energy = Math.max(10, n.h.state.energy - 0.018); n.h.state.rest = Math.max(10, n.h.state.rest - 0.012);
      if (W.t % 15 === 0) {
        if (n.cult.path === 'BODY') (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(n, 'BODY_REFINING', 0.05, 1.1);
        else if (n.cult.path === 'DEMON') {
          (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(n, n.cult.sub === 'VENOM_GU_SOVEREIGN' ? 'POISON' : 'SOUL_DIVINE', 0.05, 1.15);
          if (n.h.state.heartDemon < 55) n.h.state.heartDemon = Math.min(55, (n.h.state.heartDemon || 0) + 0.15);
        } else if (n.cult.path === 'HEART_SOUL') {
          (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(n, 'SOUL_DIVINE', 0.05, 1.15);
          n.h.state.heartDemon = Math.max(0, (n.h.state.heartDemon || 0) - 0.35);
        } else (g.MARTIAL && g.MARTIAL.skillPractice ? g.MARTIAL.skillPractice : HC.practice)(n, 'SCRIPTURE', 0.05, 1.1);
      }
    },
    done(n, W, ctx) {
      W.log('finance', n.h.name.given + ' จ่าย ' + Math.round(ctx.fee || 0) + ' คป. ซื้อสิทธิ์ฝึกปราณเข้มข้น ตบะเพิ่ม ' + Math.round(ctx.gained || 0), [n.id]);
      HC.feel(n, { mood: 1.0 });
    }
  };

  /* ----- เรียนวิชา: วิชาพื้นฐานเรียนฟรี วิชาอื่นใช้แต้ม (เผาออกจากระบบ) ----- */
  AI.nextTechToStudy = (W, n) => {
    const c = n.cult; if (!c) return null;
    const cpBand = Math.floor((n.cp || 0) / 2), libLen = W.sect.library ? W.sect.library.length : 0, goalTgt = n.cognition?.goal?.id === 'scripture' ? (n.cognition.goal.targetId || '') : '';
    const ntc = n._nextTechCache;
    if (ntc && W.t >= ntc.t && W.t - ntc.t < 360 && ntc.cpBand === cpBand && ntc.st === c.stage && ntc.sub === c.sub && ntc.tl === c.techs.length && ntc.libLen === libLen && ntc.goalTgt === goalTgt && ntc.rank === n.rank && (!ntc.out || !c.techs.includes(ntc.out.id))) {
      return ntc.out;
    }
    const cap = Math.min(CULT.effectiveTechStage ? CULT.effectiveTechStage(n) : c.stage, SECT.canLearnTier(W, n));
    const libPool = (g.COG && g.COG.visibleLibraryFor) ? g.COG.visibleLibraryFor(W, n) : W.sect.library;
    let ids = CULT.learnable(n, libPool).map(id => CULT.tech(id)).filter(t => (t.reqTier || t.tier) <= cap);
    ids = ids.filter(t => CPE.techPrice(W, t) <= (n.cp || 0));
    let out = null;
    if (ids.length) {
      if (goalTgt) { const desired = ids.find(t => t.id === goalTgt); if (desired) out = desired; }
      if (!out) {
        ids.sort((a, b) => {
          const prefDiff = g.COG ? (g.COG.techPreference(n, b) - g.COG.techPreference(n, a)) : (b.power - a.power);
          const retDiff = (CULT && CULT.techRetentionScore) ? (CULT.techRetentionScore(n, b) - CULT.techRetentionScore(n, a)) * 0.25 : 0;
          return prefDiff + retDiff;
        });
        out = ids[0];
      }
    }
    n._nextTechCache = { t: W.t, cpBand, st: c.stage, sub: c.sub, tl: c.techs.length, libLen, goalTgt, rank: n.rank, out };
    return out;
  };
  const SA = A.study, oStart = SA.start;
  SA.start = function (n, W, ctx) {
    const c = n.cult;
    if (c && !c.learning) {
      const t = AI.nextTechToStudy(W, n);
      if (t) {
        if (g.MARTIAL) return g.MARTIAL.startStudy(W, n, t.id).ok;
        const price = CPE.techPrice(W, t);
        if (price > 0 && !CPE.spend(W, n, price, 'เรียนวิชา「' + t.nameTh + '」')) return false;
        if (price > 0) CPE.S(W).techSales += price;
        c.learning = { id: t.id, need: CULT.studyCost(t), got: 0 };
        return true;
      }
    }
    return oStart.apply(this, arguments);
  };

  /* ----- โอสถฟื้นฟู: ผลเพิ่มเติม + การใช้ + สวัสดิการ (รวมศูนย์ใน ECO.applyPill แล้ว) ----- */
  const isPillAllowed = (n, key) => {
    const info = ECO.pillInfo(key);
    if (!info) return false;
    const p = info.effect && info.effect.compatiblePath;
    return !p || (n.cult && n.cult.path === p);
  };
  const pickPill = (n, effectKey, fallbackList) => {
    if (!n.inv || !n.inv.pills) return null;
    if (fallbackList && Array.isArray(fallbackList)) {
      const basic = fallbackList.find(k => (n.inv.pills[k] || 0) > 0 && isPillAllowed(n, k));
      if (basic) return basic;
    }
    for (const k of Object.keys(n.inv.pills)) {
      if ((n.inv.pills[k] || 0) <= 0 || !isPillAllowed(n, k)) continue;
      const info = ECO.pillInfo(k);
      if (info && info.effect && info.effect[effectKey]) return k;
    }
    return null;
  };
  const consume = (W, n, key) => {
    if (!n.inv || !n.inv.pills || (n.inv.pills[key] || 0) <= 0) return null;
    const q = (n.inv.pillQuality && n.inv.pillQuality[key]) || 1;
    const res = ECO.applyQualityPill(W, n, key, q);
    if (res) {
      n.inv.pills[key]--;
      if (n.inv.pills[key] <= 0) {
        delete n.inv.pills[key];
        if (n.inv.pillQuality) delete n.inv.pillQuality[key];
      }
      if (n.inv.spawnedPills && n.inv.spawnedPills[key] > 0) {
        n.inv.spawnedPills[key]--;
        if (n.inv.spawnedPills[key] <= 0) delete n.inv.spawnedPills[key];
      }
      if ((W.t + (n.n || 0)) % 2 === 0) {
        W.log('train', n.h.name.given + ' ใช้โอสถ「' + ECO.name(key) + '」เพื่อรักษาฟื้นฟูร่างกาย', [n.id]);
      }
    }
    return res;
  };
  CPE.consumePersonalPill = consume;
  CPE.consumeCrafted = (W, n, p) => {
    const list = n.inv && n.inv.craftedPills, i = list && list.indexOf(p);
    if (i == null || i < 0 || p.intent !== 'keep' || !(p.qty > 0)) return null;
    const result = ECO.applyQualityPill(W, n, p.key, p.q);
    if (!result) return null;
    if (--p.qty <= 0) list.splice(i, 1);
    W.log('train', n.h.name.given + ' ใช้โอสถที่ตนปรุง「' + ECO.name(p.key) + '」เพื่อหนุนการบำเพ็ญ', [n.id]);
    return result;
  };
  function pickCrafted(n, effect) { return (n.inv && n.inv.craftedPills || []).find(p => p.intent === 'keep' && p.qty > 0 && ECO.pillInfo(p.key)?.effect[effect]); }
  CPE.autoUse = (W, n) => {
    if (n.dead || !n.inv || (n.act && n.act.id === 'fight')) return;
    if (CULT.isAbstainingFromPills && CULT.isAbstainingFromPills(n)) {
      if (Array.isArray(n.inv.gear) && n.inv.gear.length > 0) CPE.evaluatePersonalBagGear(W, n);
      return;
    }
    if (Array.isArray(n.inv.gear) && n.inv.gear.length > 0) CPE.evaluatePersonalBagGear(W, n);
    let hasPills = !!(n.inv.craftedPills && n.inv.craftedPills.length);
    if (!hasPills && n.inv.pills) { for (const _k in n.inv.pills) { hasPills = true; break; } }
    if (!hasPills) return;
    const s = n.h.state, R = JD.CP.RECOVERY, hm = CULT.hpMax(n);
    const owned = n.inj && n.inj.length && pickCrafted(n, 'healInjury') || s.hp < hm * 0.5 && pickCrafted(n, 'healHealth') || n.cult && n.cult.toxic > 40 && pickCrafted(n, 'clearToxic') || s.heartDemon > 45 && pickCrafted(n, 'clearHeartDemon') || s.energy < 18 && pickCrafted(n, 'energyRestore');
    if (owned) return CPE.consumeCrafted(W, n, owned);
    if (!n.inv.pills || !Object.keys(n.inv.pills).length) return;
    let k;
    if (n.inj && n.inj.length && (k = pickPill(n, 'healInjury', R.wound))) return consume(W, n, k);
    if (s.hp < hm * 0.5 && (k = pickPill(n, 'healHealth', R.hp))) return consume(W, n, k);
    if (s.heartDemon > (n.cult && n.cult.path === 'DEMON' ? 62 : 45) && (k = pickPill(n, 'clearHeartDemon', R.calm))) return consume(W, n, k);
    if (n.cult && n.cult.toxic > (n.cult.path === 'DEMON' ? 56 : 40) && (k = pickPill(n, 'clearToxic', R.detox))) return consume(W, n, k);
    if (s.energy < 18 && (k = pickPill(n, 'energyRestore', R.vigor))) return consume(W, n, k);
  };
  CPE.fightUse = (W, n, ctx) => {
    if (!n.inv || (ctx.pillAt || 0) > W.t || (CULT.isAbstainingFromPills && CULT.isAbstainingFromPills(n))) return false; const s = n.h.state, R = JD.CP.RECOVERY; let k;
    const isZeroQi = !!(CULT.isZeroQiSamurai && CULT.isZeroQiSamurai(n));
    const owned = s.hp < CULT.hpMax(n) * 0.38 && pickCrafted(n, 'healHealth') || n.cult && !isZeroQi && s.qi != null && s.qi < CULT.qiMax(n) * 0.2 && pickCrafted(n, 'qiRestore');
    if (owned && CPE.consumeCrafted(W, n, owned)) { ctx.pillAt = W.t + 6; n.fx = {t:W.t,text:'💊'}; return true; }
    if (!n.inv.pills) return false;
    if (n.sx && n.sx.some(x => x.k === 'poison') && (k = pickPill(n, 'clearPoison', null))) {
      ctx.pillAt = W.t + 6; if (consume(W, n, k)) { n.fx = { t: W.t, text: '💊' }; return true; }
    }
    if (s.hp < CULT.hpMax(n) * 0.38 && (k = pickPill(n, 'healHealth', R.hp))) { ctx.pillAt = W.t + 6; if (consume(W, n, k)) { n.fx = { t: W.t, text: '💊' }; return true; } }
    if (n.cult && !isZeroQi && s.qi != null && s.qi < CULT.qiMax(n) * 0.2 && (k = pickPill(n, 'qiRestore', R.qi))) { ctx.pillAt = W.t + 6; if (consume(W, n, k)) { n.fx = { t: W.t, text: '💊' }; return true; } }
    return false;
  };
  CPE.welfareOfficer = W => {
    const S = W.sect, available = n => !!n && !n.dead && !n.away && !n.exiled && !n.sealed && !n.sealedBt && !(n.jail > W.t);
    const elder = SECT.holder(W, 'treasury'), master = W.byId[S.masterId], deputy = W.byId[S.deputyId];
    const eligible = W.npcs.filter(n => available(n) && n.rank >= 1);
    const best = list => list.sort((a,b) => SECT.relevance('treasury', b) - SECT.relevance('treasury', a) || a.id.localeCompare(b.id))[0];
    let officer, role, acting = false;
    if (available(elder)) { officer = elder; role = 'treasury'; }
    else if (elder && (officer = best(eligible.filter(n => n.assist === 'treasury')))) { role = 'acting_treasury'; acting = true; }
    else if (available(master)) { officer = master; role = 'master'; }
    else if (available(deputy)) { officer = deputy; role = 'acting_master'; acting = true; }
    else if ((officer = best(eligible.filter(n => n.assist === 'treasury')) || best(eligible))) { role = 'acting_treasury'; acting = true; }
    else { role = 'unavailable'; acting = false; }
    const id = officer ? officer.id : null, previous = S.welfareAuthority;
    if (!previous || previous.id !== id || previous.role !== role) {
      S.welfareAuthority = { id, role, acting, since: W.day };
      if (officer) W.log('appoint', officer.h.name.given + (acting ? ' รับหน้าที่รักษาการดูแลการแจกจ่ายโอสถ' : ' รับผิดชอบการแจกจ่ายโอสถ'), [id]);
      else if (previous && previous.id) W.log('appoint', 'ไม่มีผู้มีสิทธิ์ดูแลการแจกจ่ายโอสถชั่วคราว', []);
    }
    return officer || null;
  };
  CPE.welfareDaily = W => {
    if (g.SECT && g.SECT.ensureDirectives) g.SECT.ensureDirectives(W);
    const S = W.sect, c = CPE.S(W), tr = CPE.welfareOfficer(W), R = JD.CP.RECOVERY;
    if (!tr) return;
    const mer = S.policy.meritocracy / 100;
    const trIntegrity = E(tr, 'personality.integrity');
    const trEmpathy = E(tr, 'personality.empathy');
    const gen = clamp((trEmpathy * 0.45 + E(tr, 'social.hospitality') * 0.2 + (100 - E(tr, 'values.wealthResource')) * 0.2 + S.policy.generosity * 0.15) / 100, 0.05, 0.95);
    c.welfare = Math.round(gen * 100) / 100;
    c.markup = Math.round(clamp(0.85 + (E(tr, 'values.wealthResource') - 50) / 150 + (50 - S.policy.generosity) / 300, 0.75, 1.4) * 100) / 100;

    const rd = S.reserveDirectives && S.reserveDirectives.medicine;
    const reserveFor = k => (rd && rd[k] != null ? rd[k] : (gen < 0.4 ? 3 : 1));

    let given = 0;
    const recipients = [];
    const passedOver = [];

    const give = (n, list, needScore, relScore) => {
      const k = list.find(x => BASIC_IDS.includes(x) && ECO.count(W, x) > reserveFor(x));
      if (!k) return false;
      n.inv.pills = n.inv.pills || {};
      if (n.inv.pills[k] >= 2) return false;
      const quality = ECO.pillQuality(W, k); ECO.take(W, k, 1);
      ECO.addPersonalPill(n, k, quality);
      given++;
      recipients.push({ id: n.id, name: n.h.name.given, item: k, needScore: Math.round(needScore), biasScore: Math.round(relScore) });
      return true;
    };

    const candidates = W.npcs.filter(n => !n.dead && !n.away && !n.exiled && !(CULT.isAbstainingFromPills && CULT.isAbstainingFromPills(n)));
    const evaluated = candidates.map(n => {
      const s = n.h.state, hm = CULT.hpMax(n), needs = [];
      let needScore = 0;
      if (n.inj && n.inj.length) {
        needs.push(R.wound);
        needScore += n.inj.reduce((acc, i) => acc + (i.sev || 1) * 22, 15);
      }
      if (s.hp < hm * 0.7) {
        needs.push(R.hp);
        needScore += Math.max(0, (1 - s.hp / hm)) * 50;
      }
      if (s.heartDemon > 35) {
        needs.push(R.calm);
        needScore += Math.max(0, s.heartDemon - 30) * 1.0;
      }
      if (n.cult && n.cult.toxic > 30) {
        needs.push(R.detox);
        needScore += Math.max(0, n.cult.toxic - 25) * 1.0;
      }
      if (s.energy < 25) {
        needs.push(R.vigor);
        needScore += Math.max(0, 30 - s.energy) * 0.4;
      }
      if (!needs.length) return null;
      const meritBonus = n.rank * 4 + Math.min(20, (n.merit || 0) * 0.15);
      const flatBonus = (g.COG && g.COG.flatteryBonus) ? g.COG.flatteryBonus(tr, n) : 0;
      const relScore = SECT.relationScore(tr, n) + flatBonus * 1.4;
      const effectiveMerit = clamp(mer * (0.55 + trIntegrity / 220), 0.05, 0.95);
      const decisionScore = (needScore + meritBonus) * effectiveMerit + (relScore * 1.2) * (1 - effectiveMerit);
      return { n, needs, needScore, relScore, decisionScore, meritBonus };
    });

    const needy = evaluated.filter(Boolean);
    needy.sort((a, b) => b.decisionScore - a.decisionScore);

    needy.forEach(item => {
      const { n, needs, needScore, relScore } = item;
      const p = clamp(0.15 + gen * 0.75 + (relScore / 250) * (1 - mer) - (n.rank === 0 ? 0.08 * (1 - gen) : 0), 0.05, 0.98);
      let received = false;
      if (W.rng.next() < p) {
        received = needs.some(l => give(n, l, needScore, relScore));
      }
      if (!received && needScore > 25) {
        passedOver.push(item);
      }
    });

    if (W.day % 30 === 15 && gen > 0.45) {
      W.npcs.forEach(n => {
        if (!n.dead && !n.away && n.cult && n.rank >= 1 && ECO.count(W, 'P:BASIC_HP') > W.npcs.length * 0.5 + reserveFor('P:BASIC_HP')) {
          give(n, R.hp, 10, SECT.relationScore(tr, n));
        }
      });
    }

    const biasedRecipients = recipients.filter(r => r.biasScore > 20 && r.needScore < 30);
    if (biasedRecipients.length > 0 && passedOver.length > 0 && mer < 0.55) {
      passedOver.forEach(p => {
        if (p.needScore >= 35 || p.n.merit > 20) {
          p.n.sat = Math.max(0, (p.n.sat || 60) - 3);
          HC.feel(p.n, { mood: -2 });
          const rel = SECT.rel(p.n, tr.id);
          rel.a = Math.max(-100, rel.a - 4);
          rel.t = Math.max(0, (rel.t ?? 40) - 6);
          HC.experience(p.n, 'punished_unfair', 0.4);
          if (g.COG && g.COG.remember) g.COG.remember(W, p.n, { kind: "unfair_allocation", subjectId: tr.id, severity: 0.6 });
          if (g.COG && g.COG.submitPetition) g.COG.submitPetition(W, p.n, "complaint", { accusedId: tr.id, reason: "ไม่ได้รับโอสถสวัสดิการทั้งที่บาดเจ็บ" });
          if (W.rng.chance(0.35)) {
            W.log('finance', p.n.h.name.given + ' มีอาการบาดเจ็บหนักแต่ไม่ได้รับโอสถสวัสดิการ ขณะที่คนสนิทของผู้ดูแลคลังได้รับแทน เกิดความไม่พอใจ', [p.n.id, tr.id]);
          }
        }
      });
    } else if (mer > 0.7 && passedOver.length === 0 && recipients.length > 0) {
      needy.forEach(item => {
        if (E(item.n, 'personality.integrity') > 60) {
          item.n.sat = Math.min(100, (item.n.sat || 60) + 0.5);
        }
      });
    }

    if (recipients.length || passedOver.length) {
      S.welfareHistory.unshift({
        day: W.day,
        treasurerId: tr.id,
        treasurerName: tr.h.name.given,
        acting: S.welfareAuthority.acting,
        authorityRole: S.welfareAuthority.role,
        meritocracy: Math.round(mer * 100),
        given,
        recipients,
        passedOverCount: passedOver.length
      });
      if (S.welfareHistory.length > 30) S.welfareHistory.pop();
      if (given > 0 && W.rng.chance(0.4)) {
        W.log('economy', 'หอคลังแจกจ่ายโอสถสวัสดิการพื้นฐานให้แก่สมาชิก ' + given + ' คน', recipients.slice(0, 3).map(r => r.id));
      }
    }

    if (given) {
      c.welfareGiven += given;
      if (given >= 3 || W.rng.chance(0.3)) {
        const biasDesc = mer < 0.4 ? ' (เอนเอียงตามความสนิท)' : mer > 0.75 ? ' (ยึดความจำเป็นและความชอบธรรม)' : '';
        W.log('finance', 'ผู้ดูแลคลัง ' + tr.h.name.given + ' แจกโอสถสวัสดิการ ' + given + ' เม็ด' + biasDesc + ' (นิสัย' + (gen > 0.65 ? 'ใจกว้าง' : gen < 0.35 ? 'หวงของ' : 'พอประมาณ') + ')', [tr.id]);
      }
    }
  };
  /* ----- รายวัน/รายเดือน ----- */
  CPE.daily = W => {
    const S = W.sect, c = CPE.S(W); if (S.library && !c.freeLib) c.freeLib = S.library.filter(id => { const t = CULT.tech(id); return t && t.tier <= 1 && !t.overhaulPack; });
    W.npcs.forEach(n => {
      if (n.cp == null) n.cp = 20;
      if (n.inv && n.inv.techs) {
        n.inv.techs = n.inv.techs.filter(id => {
          if (!CULT.tech(id)) return false;
          if (S.library.includes(id)) {
            if (!n.cult || !Array.isArray(n.cult.techs) || !n.cult.techs.includes(id)) {
              n.studyWaivers = n.studyWaivers || {};
              n.studyWaivers[id] = true;
            }
            return false;
          }
          return true;
        });
      }
      if (n.inv && n.inv.recipes) n.inv.recipes = n.inv.recipes.filter(id => !!ECO.recipeById[id]);
    });
    CPE.welfareDaily(W);
    if (g.SECT && g.SECT.distributeSectStock && W.day % 2 === 0) {
      g.SECT.distributeSectStock(W);
    }
    const al = W.npcs.filter(n => !n.dead && !n.exiled);
    const baseTgt = 175 + al.reduce((s, n) => s + n.rank * 16 + (n.cult ? n.cult.stage * 20 : 0), 0) / Math.max(1, al.length);
    const tgt = baseTgt * Math.pow(Math.max(0.6, c.price || 1), 0.65);
    const cap = tgt * 4, balances = al.map(n => clamp(n.cp || 0, 0, cap));
    const avg = balances.length ? balances.reduce((s, v) => s + v, 0) / balances.length : 0;
    const median = balances.length ? balances.slice().sort((a, b) => a - b)[balances.length >> 1] : 0;
    const refBal = 0.45 * avg + 0.55 * median;
    if (refBal > tgt * 1.25) c.price = Math.min(4, c.price * 1.004);
    else if (refBal < tgt * 0.78) c.price = Math.max(0.6, c.price / 1.0045);
    c.circulation = Math.round(al.reduce((s, n) => s + (n.cp || 0), 0) * 10) / 10;
    c.hist.push({ d: W.day, avg: Math.round(avg), median: Math.round(median), price: Math.round(c.price * 100) / 100, mint: Math.round(c.dayMint), burn: Math.round(c.dayBurn), circulation: c.circulation, retired: Math.round(c.retired || 0) }); if (c.hist.length > 60) c.hist.shift();
    c.dayMint = 0; c.dayBurn = 0;
  };
  const oPay = SECT.paySalaries;
  SECT.paySalaries = W => {
    const paid = oPay(W), pay = [0, 6, 12, 24, 42, 65, 90];
    const pMod = CPE.S(W).price > 1.2 ? 1 / Math.pow(CPE.S(W).price, 0.5) : 1;
    W.npcs.forEach(n => { if (n.dead || n.exiled) return; CPE.mint(W, n, (pay[n.rank] || 10) * (n.post ? 1.25 : 1) * (0.9 + W.sect.policy.generosity / 500) * pMod, 'เบี้ยหวัดคุณูปการ', true); });
    return paid;
  };
  function personalCraftChoice(W, n) {
    if (!n.inv || !n.cult || n.dead || n.away || n.h.state.energy < 20) return null;
    if ((n.inv.craftedPills || []).length >= 3) return null;
    const mats = n.inv.mats;
    if (!mats) return null;
    let matSum = 0;
    for (const mk in mats) { if (mats[mk] > 0) matSum += mats[mk]; }
    if (matSum <= 0) return null;
    const wt = W ? W.t : -1, nVer = n._ver || 0;
    if (wt > 0 && (n._pcTick === wt || (wt > n._pcTick && wt - n._pcTick < 45)) && n._pcVer === nVer && n._pcMatSum === matSum) return n._pcVal;
    n._pcTick = wt; n._pcVer = nVer; n._pcMatSum = matSum;
    const known = [...(n.inv.recipes || []), ...(n.recipes || [])];
    const canBasicBrew = (n.h.skills.ALCHEMY || 0) >= 10 || HC.eff(n, 'interests.herbs') >= 35 || n.post === 'alchemy' || (n.inj && n.inj.length > 0) || n.h.state.hp < CULT.hpMax(n) * 0.75;
    const basicIds = canBasicBrew ? ['BASIC_HP', 'BASIC_QI', 'BASIC_VIGOR', 'BASIC_WOUND', 'BASIC_DETOX', 'BASIC_CALM', ...((n.h.skills.ALCHEMY || 0) >= 30 ? ['BASIC_HP2', 'BASIC_QI2'] : [])] : [];
    const ids = Array.from(new Set([...known, ...basicIds]));
    if (!ids.length) return (n._pcVal = null);
    let best = null;
    for (const id of ids) {
      const r = ECO.recipeById[id]; if (!r || r.craft !== 'ALCHEMY' || r.outType !== 'PILL') continue;
      const quote = ECO.personalCraftQuote(W, n, r); if (!quote || !quote.owned.length) continue;
      const key = r.outItemId || 'P:' + r.id, info = ECO.pillInfo(key); if (!info) continue;
      const need = (n.h.state.hp < CULT.hpMax(n) * 0.75 && info.effect.healHealth) || ((n.inj && n.inj.length > 0) && info.effect.healInjury) || (n.cult.toxic > 25 && info.effect.clearToxic) || (n.h.state.heartDemon > 30 && info.effect.clearHeartDemon);
      const intent = need ? 'keep' : 'donate';
      const value = Math.min(CPE.reward(W, key, r.yield || 1), quote.cost + quote.ownValue * 1.2);
      if (!need && value <= quote.cost) continue;
      const score = need ? 2.0 : 0.8 + Math.min(0.9, (value - quote.cost) / 40);
      const preference = n.cognition?.goal?.id === 'craft' && n.cognition.goal.targetId === r.id?.toString() ? 0.6 : 0;
      if (!best || score + preference > best.score) best = { r, intent, score: score + preference };
    }
    return (n._pcVal = best);
  }
  A.personalBrew = {
    nameTh: 'ปรุงโอสถส่วนตัว', icon: '⚗️', color: '#8ad7ae',
    can: (n, W) => !!personalCraftChoice(W, n),
    score(n, W, S) { const c = personalCraftChoice(W,n); if (c) S.add('ผลิตโอสถจากวัตถุดิบส่วนตัว', c.score + (n.cult && n.cult.path === 'CRAFT_CREATION' ? 0.55 : 0)); },
    where(W,n) { const c = personalCraftChoice(W,n), st = c && AI.freeStation(W,n,'cauldron','alchemy'); return st ? { st, rid:c.r.id, intent:c.intent } : null; },
    start(n,W,ctx) { return !!ECO.personalCraftQuote(W,n,ECO.recipeById[ctx.rid]); },
    dur(n,W,ctx) { const r=ECO.recipeById[ctx.rid]; return r ? Math.round(ECO.craftHours(r,n.h.skills.ALCHEMY||0)*60) : 0; },
    tick(n, W) { n.h.state.energy=Math.max(0,n.h.state.energy-0.04); if (n.cult && (n.cult.path === 'CRAFT_CREATION' || (Array.isArray(n.cult.techs) && n.cult.techs.includes('PASS_CROSS_CRAFT_004')))) { const cMult = n.cult.path === 'CRAFT_CREATION' ? 1.35 : 0.65; CULT.gain(n, CULT.rate(n, cMult) / 60, W, 'craft_tick'); } },
    done(n,W,ctx) {
      const r = ECO.recipeById[ctx.rid];
      const out = ECO.personalCraft(W, n, r, ctx.intent);
      if (out && out.ok) {
        n.stats = n.stats || {};
        n.stats.crafted = (n.stats.crafted || 0) + 1;
        n.lastPersonalCraftFail = null;
        W.log('craft', n.h.name.given + ' ปรุงโอสถส่วนตัวสำเร็จ (คุณภาพ ' + Math.round(out.product.q * 100) + '%)', [n.id]);
      } else {
        const failReason = (out && out.reason) || 'missing-inputs-or-cp';
        n.lastPersonalCraftFail = { t: W.t, rid: ctx.rid, reason: failReason };
        if (AI && AI.mem) AI.mem(W, n, 'ปรุงโอสถส่วนตัวไม่สำเร็จ (' + failReason + ')', 0.3);
      }
    }
  };
  A.personalPillDonation = {
    nameTh:'บริจาคโอสถส่วนตัว',icon:'🎁',color:'#c6a4f5',
    can:n => !!(n.inv && (n.inv.craftedPills||[]).some(p=>p.intent==='donate')),
    score(n,W,S) { S.add('นำโอสถที่ผลิตไปบริจาค',1.8); },
    where(W,n) { const st=AI.freeStation(W,n,'browse','market') || AI.freeStation(W,n,'desk','treasury'); return st ? {st} : null; },
    dur:()=>20,
    done(n,W) { for (const p of [...(n.inv.craftedPills||[])]) if(p.intent==='donate') { const result=ECO.donatePersonalProduct(W,n,p.id); if(result.ok) W.log('finance',n.h.name.given+' บริจาคโอสถส่วนตัว ได้ '+Math.round(result.reward)+' คป.',[n.id]); } }
  };
  function neededPersonalPillEffect(n) {
    if (!n || !n.inv) return null;
    const hasCr = !!(n.inv.craftedPills && n.inv.craftedPills.length);
    let hasP = false;
    if (n.inv.pills) { for (const _k in n.inv.pills) { hasP = true; break; } }
    if (!hasCr && !hasP) return null;
    if (n.inj && n.inj.length > 0) {
      if ((n.inv.craftedPills || []).some(p => p.intent === 'keep' && p.qty > 0 && ECO.pillInfo(p.key)?.effect.healInjury) || pickPill(n, 'healInjury')) return 'healInjury';
    }
    if (n.h.state.hp < CULT.hpMax(n) * 0.8) {
      if ((n.inv.craftedPills || []).some(p => p.intent === 'keep' && p.qty > 0 && ECO.pillInfo(p.key)?.effect.healHealth) || pickPill(n, 'healHealth')) return 'healHealth';
    }
    if (n.cult && (n.cult.toxic || 0) >= 35) {
      if ((n.inv.craftedPills || []).some(p => p.intent === 'keep' && p.qty > 0 && ECO.pillInfo(p.key)?.effect.clearToxic) || pickPill(n, 'clearToxic')) return 'clearToxic';
    }
    if ((n.h.state.heartDemon || 0) >= 40 && (!n.cult || n.cult.path !== 'DEMON' || n.h.state.heartDemon >= 65)) {
      if ((n.inv.craftedPills || []).some(p => p.intent === 'keep' && p.qty > 0 && ECO.pillInfo(p.key)?.effect.clearHeartDemon) || pickPill(n, 'clearHeartDemon')) return 'clearHeartDemon';
    }
    return null;
  }
  A.personalPillUse = {
    nameTh:'ใช้โอสถส่วนตัว',icon:'💊',color:'#7fd1b9',
    can(n) {
      return !!neededPersonalPillEffect(n);
    },
    score(n,W,S) {
      const eff = neededPersonalPillEffect(n);
      if (eff === 'healInjury') S.add('รักษาอาการบาดเจ็บด้วยโอสถส่วนตัว', 2.45);
      else if (eff === 'clearToxic') S.add('ขับพิษโอสถสะสมด้วยโอสถส่วนตัว', 2.1);
      else if (eff === 'clearHeartDemon') S.add('ระงับจิตมารด้วยโอสถส่วนตัว', 2.15);
      else S.add('บาดเจ็บและมีโอสถส่วนตัว', 2.4);
    },
    where(W,n) { return {pos:{x:n.x,y:n.y}}; },dur:()=>1,
    done(n,W) {
      const eff = neededPersonalPillEffect(n) || 'healHealth';
      const list = n.inv.craftedPills || [], i = list.findIndex(p => p.intent === 'keep' && p.qty > 0 && ECO.pillInfo(p.key)?.effect[eff]);
      if (i >= 0) return CPE.consumeCrafted(W, n, list[i]);
      const k = pickPill(n, eff);
      if (k) consume(W, n, k);
    }
  };
  CPE.personalCraftChoice = personalCraftChoice;
  g.CPE = CPE;
  if (typeof module === 'object' && module.exports) module.exports = CPE;
})(typeof globalThis !== 'undefined' ? globalThis : this);
