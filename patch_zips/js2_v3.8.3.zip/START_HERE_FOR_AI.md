> **Latest Release: `JS2 v3.8.3`** — 11 Standalone Novel-Grade Lore Chronicles (~706 KB) bundled into `data_expansion.js` & `UI.rLore()` (`📚 คลังมหากาพย์ 11 บท`), verified 40-script lock & `JianghuSect_single.html` (19,842 KB). See `NEW_CHAT_HANDOFF_JS2_v3.8.3.md` & `PATCH_REPORTS/PATCH_REPORT_JS2_v3.8.3.md`.

> **Latest Release: ** — 11 Standalone Novel-Grade Lore Chronicles (~706 KB) bundled into  &  (), verified 40-script lock &  (19,842 KB). See  & .

# START HERE FOR AI — JianghuSect Evolution (JS2 v3.8.2)

## Current State
- **Active Version**: **JS2 v3.8.2 Living Rise & Fall (Phase 1 Living Sects + Phase 2 Living Polities)** (`SIM.PATCH_VERSION = '3.7.0a'`, `SIM.SAVE_SCHEMA_VERSION = '3.7.0aa-p0-audit-fixes'`).
- **Completed Series**: `v3.1.0` Living Lore → `v3.2.0` Equipment Expansion → `v3.3.0` Tactical Combat & Six-Path Mastery → `v3.4.0` External World Events → `v3.5.0a/b/c` Complete P0/P1/P2 Hardening → `v3.6.0a` Living Jianghu Sects → `v3.7.0a` Living Continental Polities.
- **Full Changelog**: See `CHANGELOG_JS2_V310_TO_V382.md` and `PATCH_REPORTS/`.

## Non-Negotiable Invariants (`AGENTS.md`)
1. **Never modify `AGENTS.md`** (`67,202` bytes) or **`GAME_SOURCE/js/human_core.js`** (`HC.FINGERPRINT === '155:2f9c9dd7'`).
2. **Exact 40 `<script>` tags** across `GAME_SOURCE/index.html`, `GAME_SOURCE/test/load.js`, and `GAME_SOURCE/JianghuSect_single.html`.
3. **100% Autonomous NPCs** — zero player command buttons.
4. **Always run** `core_lock.js`, `validate_data_schema.js`, `living_polities_v360b_suite.js`, `living_sects_v360a_suite.js`, `p2_polish_v350c_suite.js`, `p1_hardening_v350b_suite.js`, `p0_hardening_v350a_suite.js`, `world_events_v340_suite.js`, `tactical_sixpaths_v330_suite.js`, `equipment_v320_suite.js`, `build_single.js`, and `run_parallel_tests.js` (`187/187 PASS`) after changes.
