# Subsequent Patch Prompt (v2.0.7): Player UI Controls for Diplomacy & Sanctums, Full 50-Subpath Specialization Track Migration, and Cross-Sect Tournament Brackets

You are continuing development on **JianghuSect**. Before writing code, inspect the actual codebase, run the existing test suite (`node tools/run_parallel_tests.js`), and verify all claims against the live implementation in `GAME_SOURCE/`.

---

## 1. Context & Completed Baseline (v2.0.6 Integration Patch)

In the v2.0.6 Integration Reliability patch, the following systems were audited, repaired, and verified across 79 automated test suites:
- **NPC Bottleneck Resolution & Skill Training**: NPCs accurately detect specialization and major-path bottlenecks (e.g., `MOVEMENT 15/30`), select the missing skill during `practice`, `skillDrill`, and `pair` (`seek_teach`), explain when progress is genuinely impossible (when stations/teachers/resources are unavailable), and advance immediately upon meeting gates.
- **Diplomacy Lifecycle**: `CONTENT.signTreaty`, `CONTENT.exchangeWithAlly`, and `SECT.resolveRivalEnvoyChallenge` enforce cooldowns, reserve floors, rival attitude deltas on victory/defeat, and automatic defender selection.
- **Sanctum Bonus-Reward System**: `EXPLORE.resolveSanctum` preserves guaranteed per-floor refinement catalysts (`CAT_RESONANCE_JADE_4`, `CAT_ASTRAL_ESSENCE_5`, `CAT_PRIMORDIAL_FLAME_6`) and performs a single separate bonus-reward roll per expedition based on deepest floor cleared (`4%` at Floor 1, `8%` at Floor 2, `12%` at Floor 3, cap 1 per run) followed by a second weighted rarity roll (`RARE_MATERIAL` 48, `RECIPE_SCROLL` 26, `SUBPATH_CRYSTAL` 15, `UNCOMMON_MANUAL` 9.5, `APEX_LEGENDARY` 1.5 on Floor 3+) with strict uniqueness and anti-inflation guards.
- **Ancestral Legacy & Technique Catalog**: Unified `W.t` simulation clock expiry via `CULT.isAncestralBlessingActive`, removed study-speed double-counting from `CULT.studyCost`, enabled cross-path/cross-subpath eligibility for all 22 Legendary manuals once `CULT.effectiveTechStage(npc) >= reqTier`, stripped arbitrary weapon restrictions from 37 non-weapon techniques, and wired `M.weaponCompatibility(a, tech).accDelta` into real combat (`COMBAT.useSkill`).

---

## 2. Objectives for the Next Patch (v2.0.7)

### Area 1 — Interactive Player UI Controls for Diplomacy, Sanctum Dispatch, and Catalyst Refinement
While autonomous NPC/Master hooks and programmatic APIs exist for Diplomacy (`CONTENT.signTreaty`, `CONTENT.exchangeWithAlly`, `SECT.resolveRivalEnvoyChallenge`), Sanctums (`EXPLORE.departSanctum`), and Catalyst Refinement (`ECO.refineGearWithCatalyst`), the player-facing UI panels in `js/ui.js` are primarily read-only summaries.
1. **Diplomacy & World Politics UI (`UI.rWorld` / `UI.rPol` in `js/ui.js`)**:
   - Display each rival/neighboring sect's current attitude, active treaty (`CONTENT.TREATY_TH`), specialty materials, treaty/exchange cooldown status (`treatyCooldownUntil`, `exchangeCooldownUntil`), and active political event (`W.world.politics.activeEvent`).
   - Add interactive action buttons (`data-do="sign-treaty"`, `data-do="ally-exchange"`, `data-do="resolve-pol-event"`) allowing the player to direct the Sect Master / Mission Elder to sign treaties, dispatch an allied exchange caravan, or resolve an active political event when eligible, with clear disabled reasons when blocked by attitude, stones, or cooldown.
2. **Sanctum Expedition & Catalyst Refinement UI (`UI.rDisc` / `UI.rStock` in `js/ui.js`)**:
   - In the Discovery / Sanctums panel (`UI.rDisc`), display each Sanctum's 3 floor guardians, resonance sets, deepest floor cleared, bonus-reward drop statistics (`W.explore.sanctums.bonusDrops`, `bonusByTier`), and recent expedition logs (`W.explore.sanctums.history`), plus a button (`data-do="depart-sanctum"`) to dispatch an eligible party when no sanctum expedition is active.
   - In the Armory / Character Equipment UI, allow triggering `ECO.refineGearWithCatalyst` on eligible T4–T6 equipment when refinement catalysts are in stock.

### Area 2 — Optional Track Mode for the Remaining 27 Base Subpaths
Currently, 23 subpaths in `JD.EXPANSION.progressionMapping` have 9-realm independent tracks in `CULT.TRACKS`, while the 27 original subpaths remain major-stage-bound (`n.cult.track === null`, which is tested by `test/martial_retraining.js:13` upon initial retraining to `STAR_ARCHER`).
1. Design a non-breaking progression bridge so cultivators on the 27 original subpaths can either awaken an advanced specialization track at `effectiveTechStage >= 4` (or via a dedicated Sect Research / Subpath Manual milestone) without breaking `test/martial_retraining.js:13`, OR provide equivalent sub-realm milestone challenges so all 50 subpaths have rich mid-to-late-game skill/resource gate progression.
2. Ensure `CULT.inspectProgressionBottleneck`, `M.activeBottleneckSkills`, and `COG` handle any newly awakened tracks with the same station/teacher/resource feasibility checks.

### Area 3 — Cross-Sect Invited Martial Assembly & Envoy Duel Visuals
1. Extend `SECT.assembly` and `SECT.resolveRivalEnvoyChallenge` so allied sects (`MARTIAL_EXCHANGE`, `ALLIANCE`, `ALLIANCE_PACT`) can send guest prodigies to participate in bracket bouts, while rival sects (`RIVAL_FEUD`, `EMBARGO`) send challengers with full weapon-tactical and resonance-set profiles.
2. Surface detailed bout logs and envoy challenge breakdowns in the Sect Assembly UI panel.

---

## 3. Hard Engineering Constraints

1. **Do NOT modify `GAME_SOURCE/js/human_core.js`** (`HC.FINGERPRINT === '155:2f9c9dd7'`, SHA-256 `a0d393284fb4b136848e5b80e12f3edd2c4f9437c419c793c2a7e75d881c0542`).
2. **Preserve the 40-script architecture** in `GAME_SOURCE/index.html` and `GAME_SOURCE/test/load.js`.
3. **Preserve the 80-NPC mobile performance budget** (`avgMsPerTick < 3.0ms`, `maxSustainableTicksPerSec >= 300` in `test/browser_mobile_perf.js`).
4. **Always rebuild standalone HTML** via `node tools/build_single.js` and sync `JianghuSect_single.html` across `GAME_SOURCE/`, `JianghuSect_v2.0.6_AI_Continuation_Package/`, and the package root before running tests.
5. **Run all regression and new tests** via `node tools/run_parallel_tests.js` and `node test/run_all.js` and ensure 100% pass rate.
