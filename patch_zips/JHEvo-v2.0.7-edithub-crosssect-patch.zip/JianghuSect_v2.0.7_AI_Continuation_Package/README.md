# JianghuSect — Sect Evolution & Wuxia Life Simulation (v2.0.7 Patch)

## Overview
**JianghuSect** is a deep Wuxia sect simulation featuring autonomous NPC cognition, 5 major cultivation paths, 50 specializations (all 50 subpaths equipped with 9-realm specialization tracks), 630 martial techniques & mantras (with 22 universal Legendaries and 11 unique Legendary weapons), 12 elemental affinities, multi-floor Ancient Sanctums with guaranteed refinement catalysts and depth-scaled bonus rewards, inter-sect Diplomacy & Rival Envoys, Edit Hub Diplomacy & Sanctum Boss controls, and Cross-Sect Tournament Assemblies.

## Key Files & Structure
- `JianghuSect_single.html` — Playable standalone single-file HTML bundle (v2.0.7).
- `GAME_SOURCE/` — Complete modular source (`index.html`, `css/`, `data/`, `js/`, `tools/`, `test/`).
- `PATCH_IMPLEMENTATION_REPORT.md` — Implementation report for the v2.0.7 patch (Edit Hub Diplomacy & Sanctum controls, 50-Subpath Progression Bridge, Cross-Sect Assembly).
- `SUBSEQUENT_PATCH_PROMPT_V2_0_8_EN.md` — Active prompt for the next patch (v2.0.8): 3 new major paths (`MECH_PUPPET`, `KARMA_SAMSARA`, `BEAST_SOVEREIGN`), 18 expansion subpaths, Universal Spirit Beast Pet System, ~48 archetype techniques, and full content integration.
- `SUBSEQUENT_PATCH_PROMPT_V2_0_7_EN.md` — Retained prompt that drove v2.0.7.
- `START_HERE_FOR_AI.md` — Quick-start guide for AI continuation.

## Build & Test Commands
Run from `GAME_SOURCE`:
```bash
# Rebuild standalone HTML bundle
node tools/build_single.js

# Run the v2.0.7 Edit Hub, 50-subpath progression & cross-sect assembly validation suite
node test/edithub_crosssect_progression_suite.js

# Run all 80 test suites sequentially
node test/run_all.js

# Run all test suites in parallel (syntax + unit + integration + browser/mobile perf)
node tools/run_parallel_tests.js
```
