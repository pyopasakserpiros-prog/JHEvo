# Start Here for AI Continuation

1. **Read the prompts and reports in order**:
   - `SUBSEQUENT_PATCH_PROMPT_V2_0_8_EN.md` — **Active prompt for the next patch (v2.0.8)**: Adding 3 new major cultivation paths (`MECH_PUPPET`, `KARMA_SAMSARA`, `BEAST_SOVEREIGN`), 18 expansion subpaths, a Universal Spirit Beast Pet System (1 active pet for all paths, 2–3+ active pets & symbiotic co-op/fusion for `BEAST_SOVEREIGN`), ~48 archetype techniques, and full Edit Hub integration. Includes explicit mandate to research and innovate.
   - `PATCH_IMPLEMENTATION_REPORT.md` — Engineering report of verified features, architecture, and test verification for the v2.0.7 patch (Edit Hub Diplomacy & Sanctum controls, 50-Subpath Progression Bridge, Cross-Sect Tournament Assembly).
   - `SUBSEQUENT_PATCH_PROMPT_V2_0_7_EN.md` — Retained historical prompt that drove the v2.0.7 patch.
   - `NEXT_PATCH_PROMPT_EN.md`, `REVIEW_FOLLOWUP.md`, `MASTER_IMPLEMENTATION_PROMPT_EN.md` — Retained historical reference documents.
2. **Source & Build Location**:
   - Authoritative source code and tests live in `GAME_SOURCE/`.
   - Standalone playable bundle: `JianghuSect_single.html` (generated via `node tools/build_single.js` inside `GAME_SOURCE/`).
3. **Hard Invariants**:
   - Never modify `GAME_SOURCE/js/human_core.js` (`HC.FINGERPRINT === '155:2f9c9dd7'`).
   - Preserve the 40-script architecture in `GAME_SOURCE/index.html`.
   - Maintain the 80-NPC mobile performance budget (`avgMsPerTick < 3.0ms`).
   - Verify all tests pass via `node test/run_all.js` (80/80 suites passing) and `node tools/run_parallel_tests.js`.
