# JianghuSect — Verified v2.0.8 Release & v2.0.9 Handoff

- **Playable Standalone**: Open `GAME_SOURCE/JianghuSect_single.html` directly in any modern browser.
- **Complete Source, Data, Assets, Build Tools & 81 Regression Suites**: `GAME_SOURCE/`.
- **v2.0.8 Implementation Report (Thai & English)**: `PATCH_IMPLEMENTATION_REPORT.md`.
- **Next Patch Prompt (v2.0.9)**: `SUBSEQUENT_PATCH_PROMPT_V2_0_9_EN.md`.
- **AI Entry Point**: `START_HERE_FOR_AI.md`.

### v2.0.8 Highlights
- **9 Major Cultivation Paths & 78 Subpaths**: Added `MECH_PUPPET` (8 stages, 7 subpaths), `KARMA_SAMSARA` (8 stages, 7 subpaths), `BEAST_SOVEREIGN` (8 stages, 7 subpaths), and `SAGE_SUPPORT` (8 stages, 7 subpaths — dedicated Healing, Buff & Support path).
- **Full Stage Equivalence**: Updated `CULT.normalizedStage`, `CULT.equivalentStage`, `CULT.effectiveTechStage`, and `CULT.worldRank` across all 9 paths so equipment `minStage`, technique `reqTier`, and 9-realm specialization tracks work seamlessly across 4-stage, 5-stage, 8-stage, and 9-stage paths.
- **Self & Ally Healing + 8 Timed Buff Archetypes with Strict Expiration**: Implemented `CULT.castHealOrBuff`, `AI.ACTS.supportBless`, combat ally/self healing, and 8 timed buffs (`vitalRegen`, `fervorMight`, `aegisWard`, `swiftWind`, `qiConduit`, `clarityLotus`, `meridianUnblock`, `nirvanaGrace`) with `STATS.purgeExpired` and `earliestExpiry` cache invalidation so buffs never persist past their `until` timestamp.
- **Universal Spirit Beast Companion System**: Any cultivator can tame and field up to 1 active pet (`BEAST_SOVEREIGN` masters field up to 2–4 active pets), with live capture conservation, feeding, and Sovereign Awakening.
- **Expanded Arsenal**: 638 techniques (including 28 new innate subpath techniques, 44 path-specific techniques, and 12 cross-path `path: 'ANY'` weapon/element-bound techniques), 84 mantras, 364 items, 515 recipes, and 18 Equipment Resonance Sets covering all 78 subpaths.
- **Verification**: 81/81 regression test suites PASS (`node tools/run_parallel_tests.js`).
