# ACTIVE PATCH PROMPT — Patch v5.8.0 (Era 5 Phase 9: Forbidden Arts & Blood-Essence Overdrive Overhaul — ยกระดับวิชาประเภท `FORBIDDEN_ART` & `FORBIDDEN_TECHNIQUE` 37 วิชา)

## Target Identifiers
- **Patch Version**: `5.8.0` (`SIM.PATCH_VERSION = '5.8.0'`)
- **Save Schema Version**: `5.8.0-forbidden-arts-and-blood-sacrifice-overhaul` (`SIM.SAVE_SCHEMA_VERSION = '5.8.0-forbidden-arts-and-blood-sacrifice-overhaul'`)
- **Prerequisite Baseline**: `v5.7.0` (`133/133` suites passed)

## Scope & Engineering Requirements (1 Technique Category Overhaul per Patch: `FORBIDDEN_ART` & `FORBIDDEN_TECHNIQUE`)
Continuing our 1-category-per-patch overhaul series (after `MOVEMENT_TECHNIQUE` in `v5.4.0`, `MANTRA` in `v5.5.0`, `DEFENSIVE_TECHNIQUE` in `v5.6.0`, and `SUPPORT_TECHNIQUE` / `AUXILIARY_ART` in `v5.7.0`), overhaul all **37 `FORBIDDEN_ART` (35) & `FORBIDDEN_TECHNIQUE` (2) techniques** in `JD.TECH.techniques` (`CULT.FORBIDDEN_ARTS`):
1. **Six Distinct Forbidden Art Archetypes (`CULT.FORBIDDEN_ARTS.ARCHETYPES`) & 6 New Forbidden Manuals (T1–T6)**:
   - `BLOOD_ESSENCE_IGNITION` (`🩸 เผาโลหิตต้นกำเนิดระเบิดตบะ — 燃血秘术`): Ignites blood essence (`HP`) to surge combat attack (`+45%`) and temporary realm power, leaving temporary blood-deficiency weakness until healed by Support/Infirmary arts.
   - `LIFESPAN_HEAVEN_DEFIANCE` (`⏳ เผาผลาญอายุขัยฝืนชะตาสวรรค์ — 燃寿逆天功`): Burns a small fraction of longevity/vitality to force a breakthrough or unleash a devastating desperation strike (`+65%` power & guaranteed crit) when cornered.
   - `SOUL_DEVOURING_ABYSS` (`💀 กลืนกินวิญญาณสังเวยมาร — 噬魂魔典`): Harvests fallen enemies' soul essence in combat to permanently or temporarily boost Qi capacity and heal HP, at the cost of rising Heart Demon & Karma debt.
   - `MERIDIAN_REVERSE_BURST` (`⚡ ย้อนรอยเส้นชีพจรทะลวงขีดจำกัด — 逆脉狂暴`): Reverses Qi flow through the Eight Extraordinary Meridians (`+50%` speed & attack, ignores stun/control), risking minor meridian strain afterwards.
   - `CORPSE_PUPPET_NECROMANCY` (`🧟 เชิดหุ่นซากศพและกู่โลหิตต้องห้าม — 控尸血蛊`): Summons a temporary blood-gu / shadow-corpse phantom in combat and inflicts virulent decaying curses.
   - `VOID_TABOO_ANNIHILATION` (`🌑 มหาวิชาต้องห้ามดับสูญฟ้าดิน — 禁忌灭世诀`): Supreme high-tier taboo art that unleashes an apocalyptic void shockwave when HP is critical, turning the tide of any sect siege or boss battle.
2. **Three Forbidden Seal States (`n.forbiddenArtState.sealMode`)**:
   - `SEALED_DORMANT` (`🔒 ผนึกคัมภีร์ต้องห้าม — ปลอดภัยไร้ผลข้างเคียง`)
   - `CONTROLLED_UNSEAL` (`☯️ คลายผนึกครึ่งขั้น — พลังเพิ่มขึ้นโดยคุมจิตมารอยู่หมัด`)
   - `BLOOD_TABOO_UNLEASHED` (`🩸 ปลดผนึกโลหิตต้องห้ามเต็มพิกัด — อานุภาพสูงสุดในยามคับขัน`)
3. **Canvas Visuals, Diorama (`poseMode === 'forbidden'`) & Verification**:
   - Render crimson-black taboo seal chains, blood-flame halos, and void runes in `drawNpc` and `Render.diorama` (`pose === 'forbidden'`).
   - Add `GAME_SOURCE/test/v580_forbidden_arts_overhaul_suite.js` (`134/134 PASS`), validate schema (`0 Errors / 0 Warnings`), rebuild `GAME_SOURCE/JianghuSect_single.html`, write `PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_V5_8_0.md`, and package `JHEvo-main-v5.8.0.zip`.
