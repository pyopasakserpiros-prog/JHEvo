# ACTIVE PATCH PROMPT — Patch v5.5.0 (Era 5 Phase 6: Interactive Sect Territory Expansion, Dynamic Weather Calamities & Grand Formation Warfare)

## Target Identifiers
- **Patch Version**: `5.5.0` (`SIM.PATCH_VERSION = '5.5.0'`)
- **Save Schema Version**: `5.5.0-territory-weather-and-formation-warfare` (`SIM.SAVE_SCHEMA_VERSION = '5.5.0-territory-weather-and-formation-warfare'`)
- **Prerequisite Baseline**: `v5.4.0` (`130/130` suites passed)

## Scope & Engineering Requirements
1. **Dynamic Sect Weather & Celestial Calamity Effects**:
   - Expand weather states (`clear`, `rain`, `snow`, `spirit_aurora`, `thunder_tempest`, `blood_eclipse`) so they visually transform the Sect Map canvas and interact with elemental cultivation rates, array shields, and Qinggong flight costs.
2. **Interactive Grand Formation Warfare & Array Node Linked Beams**:
   - Render live geometric formation beams connecting active Peak Sanctuaries and Totem Pillars during raids or sect defense drills, with interactive formation stance switching (`OFFENSIVE_SWORD_NET`, `IMMORTAL_AEGIS_DOME`, `FIVE_ELEMENT_REGEN`).
3. **Verification & Packaging**:
   - Add `GAME_SOURCE/test/v550_territory_weather_and_formation_warfare_suite.js` (`131/131 PASS`), validate schema (`0 Errors / 0 Warnings`), rebuild `GAME_SOURCE/JianghuSect_single.html`, write `PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_V5_5_0.md`, and package `JHEvo-main-v5.5.0.zip`.
