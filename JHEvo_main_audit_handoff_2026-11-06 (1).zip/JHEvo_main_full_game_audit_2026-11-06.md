# JianghuSect Evolution — Full Game Audit (AUDIT ONLY)
**Branch:** `main` · **Pinned commit:** `29d02ba35f7f4f978ac66de23cc83de915232662` · **Audit date:** 6 พฤศจิกายน 2026
**Sources:** GitHub pinned `main` + `JHEvo-v3.1.0-checkpoint.zip` (blob SHA เปรียบเทียบ 5 ไฟล์หลักตรง) · **Policy:** ไม่แก้ Source/Save, ไม่ Commit/Deploy/Install
**Main at close:** `2153e96071babed34f8f6ef05658b6931bdcf353` (commit ใหม่ 1 รายการ เพิ่ม PDF 2 ไฟล์เท่านั้น; ไม่เปลี่ยน `GAME_SOURCE` ดังนั้นผลตรวจโค้ดจาก pinned SHA ยังคงใช้กับ HEAD นี้ได้)

> **Scope & caution:** รายงานนี้ตรวจ Source ทั้งโครงสร้างและประเด็นเสี่ยงอย่างเจาะจง พร้อมรัน regression suite 117 รายการและ independent probes; ไม่ใช่หลักฐานว่าได้พิสูจน์ทุก execution path ของ 249 tracked files. สถานะ PROBABLE/SUSPECTED/NOT VERIFIED ระบุชัดเจนเพื่อกันการสรุปเกินหลักฐาน.

## PART A — Executive Summary
- **รายการตรวจพบ:** 21 ประเด็น · CONFIRMED 16, PROBABLE 4, SUSPECTED 1.
- **ระดับความรุนแรง:** CRITICAL 0, HIGH 10, MEDIUM 8, LOW 0, INFO 3. ไม่มีการยืนยันความเสียหายของเซฟจริงหรือเกมค้างระดับ CRITICAL ในรอบนี้.
- **Regression runner:** 117/117 PASS; syntax 189/189 PASS; browser_mobile_perf PASS (80 NPC, 0.557 ms/tick). Independent probes ยืนยัน resource/accounting และ invalid state bugs ที่ suite เดิมไม่จับ.
- **ลำดับแก้ไข:** งบยอดเขา/โอสถ → คุก (state validation) → เงินรางวัล/เงินเดือน → UI duty/tournament cooldown → combat integration/Peak aura → long-run verification.

## PART B — Repository Architecture & System Inventory
- Pinned GitHub `main`: [commit](https://github.com/pyopasakserpiros-prog/JHEvo/commit/29d02ba35f7f4f978ac66de23cc83de915232662). Tree 249 tracked files; package includes `GAME_SOURCE/js` 29 JS, `data` 11 JS, `test` 139 JS, `tools` 10 JS. Browser game built on JavaScript IIFE/global modules, HTML/CSS, local assets. No root package.json in ZIP.
- Entry/dataflow: `index.html → main.js (RAF, speed controls) → SIM.tick → {AI, SECT, ECO, EXPED, COMBAT} → W world state → {UI.updateHud, UI.render, render.js}`; Save = `SIM.serialize/deserialize`. Monthly peak tick at `sim.js:705`; daily officer at `sect.js:6438`.

| System | Source | Producer → Consumer | Integration health |
|---|---|---|---|
| Boot/UI routing | `index.html, js/main.js, js/ui.js, js/render.js` | DOM event / RAF → SIM / UI / Render | RUNNING, Browser test PASS |
| Simulation clock and persistence | `js/sim.js` | main.js, Browser controls → SECT, AI, ECO, EXPED, world state | RUNNING, 117 regression pass |
| NPC cognition/AI | `js/ai.js, js/cognition.js, js/human_core.js` | SIM.tick → CULT, ECO, COMBAT, W.npcs | PARTIAL: Peak aura not authoritative |
| Combat/Tactics | `js/combat.js, js/skills.js, js/stats.js` | AI, SIM, EXPED → W.fights, injuries, rewards | PARTIAL: Vanguard modifier disconnected |
| Economy & transaction | `js/economy.js, js/external_market.js, js/cpeco.js` | UI, NPC AI, SECT, expeditions → W.sect.stones, W.sect.stock, n.inv | BROKEN invariants in peaks/payroll |
| Sect and 25 offices | `js/sect.js, js/cognition.js` | SECT.daily, UI action → world, economy, combat, guild | PARTIAL: write-only state fields |
| Peaks & sanctuaries | `js/sect.js [PEAKS], js/ui.js` | UI action, SIM.monthly → peak state, NPC, chronicle | BROKEN economy/eligibility/cooldowns |
| Dungeon & prisoners | `js/sect.js [dungeon], js/ui.js` | SECT.daily, warden, UI → W.sect.dungeon, world, NPC | BROKEN action validation |
| Expedition & world | `js/expedition.js, js/explore.js, js/world_map.js, js/wildlife.js, js/wild_resources.js` | SIM.daily/AI/mission UI → resources, NPC injuries, W.world | PARTIAL REVIEW, existing tests PASS |
| Research/Library | `js/knowledge.js, js/sim.js [researchTick], js/sect.js, js/ui.js` | daily tick, UI/NPC → W.sect.library, W.sect.research, CULT | PASS selected suite; full realistic NPC coverage pending |
| Data registries | `data/*.js, js/content.js` | index load order, content.ensure → economy, crafting, skills | PASS validator, browser smoke |
| Tests/build | `test/*.js, tools/*.js` | Node/Chromium → test/results, bundle | 117/117 PASS at SHA baseline |

## PART C — Bug Inventory (Evidence-based)
| ID | Severity | Status | Category | Finding |
|---|---|---|---|---|
| JHE-001 | HIGH | CONFIRMED | Economy / Resource Conservation | การจัดสรรงบยอดเขาไม่หักศิลาจากคลังกลาง |
| JHE-002 | HIGH | CONFIRMED | Economy / Resource Duplication | คลังยอดเขาจ่ายเกินยอดคงเหลือและบังคับเติมยอดหลังจ่าย |
| JHE-003 | MEDIUM | CONFIRMED | Economy / Pill Inventory | แจกโอสถให้ NPC โดยไม่หัก pillReserve |
| JHE-004 | HIGH | CONFIRMED | UI → Governance → Economy / Exploit | ปุ่มสั่งขุนนางซ้ำสร้างรายได้ Quartermaster ได้ไม่จำกัด |
| JHE-005 | MEDIUM | CONFIRMED | Economy / Rounding | เงินเดือนหักจากคลังไม่เท่ากับยอดเงินที่ NPC ได้รับ |
| JHE-006 | HIGH | CONFIRMED | Combat / Money Mint | รางวัล Tournament ปกติจ่ายเต็มแม้คลังหักได้เพียงบางส่วน |
| JHE-007 | HIGH | CONFIRMED | Gameplay / Reward Farming | ประลองยอดเขาซ้ำวันเดียว รับรางวัลได้หลายครั้ง |
| JHE-008 | HIGH | CONFIRMED | Gameplay / Progression Bypass | กดจัดประลองแล้วระบบสถาปนายอดเขาโดยข้ามเกณฑ์ |
| JHE-009 | MEDIUM | CONFIRMED | Gameplay / Missing Preconditions | พิธีแลกเปลี่ยนวิชาซ้ำได้ และยอมรับยอดเขาที่ยังไม่สถาปนา |
| JHE-010 | MEDIUM | CONFIRMED | Gameplay / State Invariant | เปิดค่ายกลปราณให้ยอดเขาที่ยังไม่ได้ก่อตั้งได้ |
| JHE-011 | HIGH | CONFIRMED | Code Zero / Gameplay Integration | โบนัสค่ายกลปราณแยกจากสถานะเปิดจริงและใช้ค่าคงที่ใน AI |
| JHE-012 | HIGH | CONFIRMED | Dungeon / State Validation / API Exploit | Prisoner Object อิสระถูกประมวลผลซ้ำหรือปลอมได้ |
| JHE-013 | HIGH | CONFIRMED | Dungeon / Invalid Transition | คำสั่งเชลยผิดประเภทลบเชลยแต่คืน ok=true |
| JHE-014 | MEDIUM | PROBABLE | Gameplay / Design Intent | ระบบคุกสร้างเชลยขึ้นเองในรอบวันโดยไม่มี Encounter |
| JHE-015 | HIGH | PROBABLE | Disconnected Code / Combat | ค่า Vanguard posture และ intercept bonus ไม่ถูกใช้ใน Combat |
| JHE-016 | MEDIUM | PROBABLE | Disconnected Code / Office Jurisdictions | สถานะขุนนางหลายค่ามีผู้เขียนแต่ไม่พบผู้บริโภค Gameplay |
| JHE-017 | MEDIUM | CONFIRMED | Economy / Balance / Growth | Arraymaster เพิ่ม defensePower ทบต้นเมื่อเรียก Duty ซ้ำ |
| JHE-018 | MEDIUM | PROBABLE | Economy / API Semantics | forceFull stipend สามารถจ่ายเงินโดยไม่มีงบกลาง |
| JHE-019 | INFO | SUSPECTED | Design Question / Gameplay Fidelity | ประลองยอดเขาตัดสินแชมป์ด้วย power sorting ไม่เกิดการต่อสู้จริง |
| JHE-020 | INFO | CONFIRMED | Code Quality / Save Purity | การ Serialize มีผลข้างเคียงกับ Cache ของ NPC |
| JHE-021 | INFO | CONFIRMED | Release Documentation / Test Audit | รายงาน QA ระบุ 188 ไฟล์ แต่ตรวจในแพ็กเกจปัจจุบันได้ 189 |

### Detailed Findings — ส่งให้ทีมแก้ไขได้ทันที

#### JHE-001 — การจัดสรรงบยอดเขาไม่หักศิลาจากคลังกลาง
**Classification:** Economy / Resource Conservation · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Sect / Peaks / Economy / UI / Monthly Tick
**Source & line links:** [GAME_SOURCE/js/sect.js:11367-11456](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11367-L11456); [GAME_SOURCE/js/ui.js:1173-1182](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L1173-L1182); [GAME_SOURCE/js/sim.js:701-706](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sim.js#L701-L706)
- **Execution path:** UI allocate-peak-resources หรือ SIM.monthly → PEAKS.tick → allocateCentralResourcesToPeaks → เพิ่ม treasuryStones และจ่ายสมาชิก โดยไม่ debit W.sect.stones
- **Root cause / Evidence:** คำนวณ pool อย่างน้อย 80 และเครดิตเข้ายอดเขาทันที ไม่มีการตรวจยอด/หักคลังส่วนกลาง
- **Gameplay impact:** สร้างศิลาและโอสถขึ้นมาโดยไม่มีต้นทาง; ส่งผลทุกเดือนและเมื่อกดปุ่มได้
- **Reproduction:** สร้างยอดเขาที่สถาปนาแล้ว 2 แห่ง ตั้ง W.sect.stones=0 แล้วเรียก allocateCentralResourcesToPeaks → ok=true, reported 80, centralAfter=0, personalDelta=378 (รวมทุนยอดเขาเดิม)
- **Fix proposal (do not apply in audit):** ยืนยันคลังกลางมีพอ; debit ต้นทางจริงก่อน credit ปลายทาง; ทำธุรกรรมแบบ atomic และ reconcile บัญชี
- **Regression test to add:** property: Δcentral + ΣΔpeak + ΣΔpersonal = 0 สำหรับการโอนศิลา; zero balance ต้อง fail; ทดสอบหลายยอดเขา/การปัดเศษ

#### JHE-002 — คลังยอดเขาจ่ายเกินยอดคงเหลือและบังคับเติมยอดหลังจ่าย
**Classification:** Economy / Resource Duplication · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Peaks / NPC inventory / Economy
**Source & line links:** [GAME_SOURCE/js/sect.js:11460-11516](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11460-L11516)
- **Execution path:** PEAKS.distributePeakResourcesToMembers → stonesPerMember=Math.max(12, …) → credit ทุกคน → pObj.treasuryStones=Math.max(20,… )
- **Root cause / Evidence:** ขั้นต่ำจ่ายต่อคนไม่ผูกกับยอดจริง; เงินที่หักคำนวณจาก stonesPerMember แทนยอดจ่ายจริงในนโยบายลำเอียง; บังคับยอดคงเหลือ ≥20
- **Gameplay impact:** เงินศิษย์เพิ่มทั้งที่ยอดเขามีเงิน 1; treasury จาก 1 กลายเป็น 20
- **Reproduction:** ตั้ง treasuryStones=1 ให้ยอดเขาที่มีสมาชิก 3; สั่งแจก → personalDelta +36, treasuryAfter=20
- **Fix proposal (do not apply in audit):** กำหนดงบสุทธิ max(0, treasury), คำนวณผลรวม actual grants, จำกัดจำนวน/อัตราให้พอ, ห้ามสร้าง floor treasury หลังจ่าย
- **Regression test to add:** property ΣpersonalGains ≤ treasuryBefore และ treasuryAfter = treasuryBefore − ΣpersonalGains (ยกเว้นรับเข้าอีกธุรกรรม)

#### JHE-003 — แจกโอสถให้ NPC โดยไม่หัก pillReserve
**Classification:** Economy / Pill Inventory · **Severity:** MEDIUM · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Peak Pill Reserve / NPC inventory / Economy
**Source & line links:** [GAME_SOURCE/js/sect.js:11493-11513](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11493-L11513); [GAME_SOURCE/js/economy.js:711-719](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/economy.js#L711-L719)
- **Execution path:** distributePeakResourcesToMembers → ECO.addPersonalPill(member,… ) → inventory เพิ่ม แต่ pObj.pillReserve ไม่ถูกลด
- **Root cause / Evidence:** ฟังก์ชันแจกยาไม่ได้ตรวจ reserve และไม่มีการลดยอด
- **Gameplay impact:** โอสถเกิดขึ้นจากความว่างเปล่าเมื่อแจกซ้ำ
- **Reproduction:** ตั้ง pillReserve=0; มีสมาชิก 2 คน; เรียกแจก → 2 เม็ดเพิ่มในถุง, reserve ยังคง 0
- **Fix proposal (do not apply in audit):** ตรวจและหัก inventory ยอดเขาตามจำนวนที่แจกสำเร็จ; ยืนยันชนิดโอสถ/จำนวนและ reconcile
- **Regression test to add:** test ห้ามแจกเมื่อ reserve=0; ΣreceivedPills + reserveAfter = reserveBefore

#### JHE-004 — ปุ่มสั่งขุนนางซ้ำสร้างรายได้ Quartermaster ได้ไม่จำกัด
**Classification:** UI → Governance → Economy / Exploit · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Sect Governance / Economy / UI
**Source & line links:** [GAME_SOURCE/js/ui.js:2077-2083](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L2077-L2083); [GAME_SOURCE/js/sect.js:5890-5907](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5890-L5907); [GAME_SOURCE/js/sect.js:6050-6063](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6050-L6063); [GAME_SOURCE/js/ui.js:3333-3333](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L3333-L3333)
- **Execution path:** UI data-do=run-officer-jurisdictions → runOfficerJurisdictions(ignoreAvailability:true) → Quartermaster → ECO.earn
- **Root cause / Evidence:** ไม่มี cooldown/idempotency ต่อวัน; UI explicitly bypass isOfficerAvailable และตัดสินใจทุกครั้งที่กด
- **Gameplay impact:** กดซ้ำในวันเดียวเพื่อเพิ่มเงินไม่มีต้นทุนคาราวาน
- **Reproduction:** แต่งตั้ง Quartermaster; เรียก UI action เทียบเท่า twice บน W.day=360 → stones 1000→1022→1044
- **Fix proposal (do not apply in audit):** แยก manual review จาก duty execution; ต่อวัน/รอบ duty ใช้ idempotency token และกำหนด provenance ของรายได้
- **Regression test to add:** กดปุ่ม 2–20 ครั้งในวันเดียว เงินต้องเพิ่มตามนโยบายได้ไม่เกินครั้งที่กำหนด; ตรวจ journal double-post

#### JHE-005 — เงินเดือนหักจากคลังไม่เท่ากับยอดเงินที่ NPC ได้รับ
**Classification:** Economy / Rounding · **Severity:** MEDIUM · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Payroll / NPC wallet / Finance Ledger
**Source & line links:** [GAME_SOURCE/js/sect.js:1007-1037](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L1007-L1037)
- **Execution path:** SECT.paySalaries → สำหรับแต่ละ NPC round(amt*k) → debits round(total*k)
- **Root cause / Evidence:** รวมเงินที่จ่ายรายคนกับการหักส่วนกลางปัดเศษคนละระดับ
- **Gameplay impact:** ศิลาหายหรือเพิ่มในระบบเมื่อคลังไม่พอ
- **Reproduction:** 47 NPC, stones=4 → หัก 4 แต่ผู้รับได้เงินรวม 1; ที่ stones=1 หัก 1 แต่จ่าย 0
- **Fix proposal (do not apply in audit):** คำนวณรายการ payout ก่อน; sum(payout) เป็น debit ที่แท้จริง; ใช้ residual allocation ที่รวมไม่เกินงบ
- **Regression test to add:** budget range 0..total: ΣactualPayouts === treasuryDebit; ยอดห้ามติดลบ; เงินรวมคงเดิม

#### JHE-006 — รางวัล Tournament ปกติจ่ายเต็มแม้คลังหักได้เพียงบางส่วน
**Classification:** Combat / Money Mint · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Combat / Tournament / Treasury
**Source & line links:** [GAME_SOURCE/js/combat.js:2740-2746](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/combat.js#L2740-L2746)
- **Execution path:** COMBAT.tournamentEnd → ECO.pay(min(prize, sect.stones)) → win.inv.stones += prize
- **Root cause / Evidence:** amount debit กับ credit ต่างกันเมื่อเงินคลังน้อย
- **Gameplay impact:** ผู้ชนะรับเงินที่ไม่ได้ถูกหักจากใคร
- **Reproduction:** สร้าง tournament T.prize=200, sect.stones=5 → winner wallet +200 (debit จำกัด 5)
- **Fix proposal (do not apply in audit):** บังคับเงินรางวัล funded/reserved ก่อนจัด; จ่ายจริงตามเงินที่หักหรือบันทึกหนี้ค้างจ่าย
- **Regression test to add:** กับ treasury=0/5/200: recipientGain == actualDebit; ทดสอบ mixed callbacks หลังจบ

#### JHE-007 — ประลองยอดเขาซ้ำวันเดียว รับรางวัลได้หลายครั้ง
**Classification:** Gameplay / Reward Farming · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Peak Tournament / Reward Economy / UI
**Source & line links:** [GAME_SOURCE/js/sect.js:11527-11648](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11527-L11648); [GAME_SOURCE/js/ui.js:1184-1193](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L1184-L1193)
- **Execution path:** UI hold-inter-peak-tournament → PEAKS.holdInterPeakTournament → reward champion/peak → history
- **Root cause / Evidence:** ไม่ตรวจ lastTournamentDay, ค่าใช้จ่าย, cooldown หรือการลงทะเบียนต่อรอบ
- **Gameplay impact:** กดซ้ำเพิ่ม stones/CP/ตบะ/โอสถและ prestige
- **Reproduction:** 2 calls ใน W.day=360 → ok=true ทั้งคู่, history เพิ่ม 2, winner เดิม; ไม่มีเงินคลังกลางลด
- **Fix proposal (do not apply in audit):** กำหนดรอบการแข่งขันไม่ซ้ำวัน/ฤดูกาล, บันทึก lastTournamentDay, จ่ายจากงบที่กันไว้
- **Regression test to add:** repeat action 2–10 ครั้งวันเดียวต้องมีเพียงหนึ่งการจ่าย; รอบใหม่หลัง cooldown จ่ายได้ครั้งเดียว

#### JHE-008 — กดจัดประลองแล้วระบบสถาปนายอดเขาโดยข้ามเกณฑ์
**Classification:** Gameplay / Progression Bypass · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Peak Founding / Tournament / UI
**Source & line links:** [GAME_SOURCE/js/sect.js:11531-11547](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11531-L11547); [GAME_SOURCE/js/ui.js:1184-1192](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L1184-L1192)
- **Execution path:** UI tournament autoFoundIfNeeded:true → scanAndFoundEligiblePeaks → หากไม่พอ for PEAK_IDS → foundPeak(allowDecree:true)
- **Root cause / Evidence:** การจัดประลองเรียกเส้นทาง decree founding โดยไม่ขอเงื่อนไข/ยืนยันเจ้าสำนัก
- **Gameplay impact:** ปลดล็อกยอดเขาที่ปกติต้องเข้าเกณฑ์; ข้าม progression
- **Reproduction:** โลก SIM.create เริ่มมียอดเขา 0; กด tournament action → foundedAfter=2, ยอดเขาละ 1 สมาชิก
- **Fix proposal (do not apply in audit):** ไม่ควร auto-found โดย force decree; ให้ปุ่มแจ้งว่าต้องก่อตั้งจริงก่อน; หากต้องใช้ decree ให้เป็นคำสั่งผู้เล่นแยกพร้อมต้นทุน
- **Regression test to add:** zero founded + tournament click: founded stays 0 และ action fail; >=2 founded: เริ่มได้

#### JHE-009 — พิธีแลกเปลี่ยนวิชาซ้ำได้ และยอมรับยอดเขาที่ยังไม่สถาปนา
**Classification:** Gameplay / Missing Preconditions · **Severity:** MEDIUM · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Peaks / Cultivation / Relations
**Source & line links:** [GAME_SOURCE/js/sect.js:11901-11919](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11901-L11919); [GAME_SOURCE/js/ui.js:1088-1097](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L1088-L1097)
- **Execution path:** holdJointPeakExchange → ตรวจมี pA/pB เท่านั้น → adjustRelation(+14), CULT.gain(+14) ทุกครั้ง
- **Root cause / Evidence:** ไม่เช็ก founded, cooldown, วัตถุดิบและจำนวนการเข้าร่วม
- **Gameplay impact:** เพิ่ม relation/cult ซ้ำได้; API รับยอดเขาที่ founded=false
- **Reproduction:** สอง calls วันเดียว relation 16→30→44; un-founded pair -24→-10 และ ok=true
- **Fix proposal (do not apply in audit):** ตรวจ pA.founded && pB.founded, ระยะเวลาพิธี/ต้นทุน, จำกัดครั้ง/วัน
- **Regression test to add:** unfounded pair reject; repeated same-day call reject; one valid exchange adjusts once

#### JHE-010 — เปิดค่ายกลปราณให้ยอดเขาที่ยังไม่ได้ก่อตั้งได้
**Classification:** Gameplay / State Invariant · **Severity:** MEDIUM · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Peaks / Array activation
**Source & line links:** [GAME_SOURCE/js/sect.js:11940-11948](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11940-L11948)
- **Execution path:** PEAKS.activatePeakArray → ensure peak → set arrayActive=true โดยไม่ตรวจ founded
- **Root cause / Evidence:** validation ตรวจแต่ p มีอยู่ ไม่ตรวจเงื่อนไขก่อตั้ง
- **Gameplay impact:** สร้าง state arrayActive=true แต่ founded=false
- **Reproduction:** เริ่มเกมและเรียก activatePeakArray(W, PEAK_AZURE_SWORD) → ok=true, founded=false, active=true
- **Fix proposal (do not apply in audit):** ต้อง founded=true ก่อน activation พร้อม cost และ availability rules
- **Regression test to add:** unfounded activation returns reason and does not mutate state; after founding then works

#### JHE-011 — โบนัสค่ายกลปราณแยกจากสถานะเปิดจริงและใช้ค่าคงที่ใน AI
**Classification:** Code Zero / Gameplay Integration · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** AI / Cultivation / Peak array / UI
**Source & line links:** [GAME_SOURCE/js/sect.js:11940-11955](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11940-L11955); [GAME_SOURCE/js/ai.js:545-552](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ai.js#L545-L552)
- **Execution path:** PEAKS.activatePeakArray sets arrayActive; cultivationBonusFor returns 0.14 based only on founded; AI cultivator done uses peakId ? 1.14 : 0.88
- **Root cause / Evidence:** arrayActive ไม่ได้เป็น guard; AI ไม่เรียก cultivationBonusFor และให้รางวัลโบนัสคงที่เล็กน้อยหลังทำกิจกรรมแทนคูณ rate จริง
- **Gameplay impact:** โบนัส UI ไม่สะท้อนค่ายกลเปิด/ปิด, ความต่างการบำเพ็ญของแต่ละยอดเขาไม่ถูกใช้
- **Reproduction:** ตั้ง founded peak arrayActive=false → cultivationBonusFor ยังคืน 0.14; grep runtime พบฟังก์ชันไม่มีผู้เรียกนอกจากนิยาม
- **Fix proposal (do not apply in audit):** สร้าง single authoritative getCultivationRateMultiplier(W,n) ที่ตรวจ founded && arrayActive และทำให้ base cultivation rate ใช้ค่าจริง
- **Regression test to add:** สอง NPC seeded เหมือนกัน เปิด/ปิด array; assert actual XP ratio ~1.14 ภายใต้กลไกที่กำหนด

#### JHE-012 — Prisoner Object อิสระถูกประมวลผลซ้ำหรือปลอมได้
**Classification:** Dungeon / State Validation / API Exploit · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Dungeon / Economy / Save-integrity
**Source & line links:** [GAME_SOURCE/js/sect.js:6741-6758](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6741-L6758); [GAME_SOURCE/js/sect.js:6759-6774](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6759-L6774)
- **Execution path:** executePrisonerAction → handleDungeonPrisoner → เมื่อ argument เป็น object ใช้ object ตรง ๆ โดยไม่ตรวจ membership/status
- **Root cause / Evidence:** bypass lookup ที่มีเงื่อนไข status IMPRISONED, ปล่อยให้ resolved/fake object ถูกดำเนินการ
- **Gameplay impact:** duplicate ransom และ forge ransom ได้ผ่าน API; อาจทำลาย stat
- **Reproduction:** เดิม 1000 → ไถ่เชลยครั้งแรก 1463 → ใช้ object เดิมไถ่ซ้ำ 1926; object ปลอม ransomStones=999999 → 1001047, captured=0
- **Fix proposal (do not apply in audit):** resolve by ID กับ canonical dungeon.prisoners เท่านั้น; validate status, immutable amount; guard transaction idempotency
- **Regression test to add:** after resolve, same id/object must fail; fabricated object must fail; captured = sum legitimate prisoner events

#### JHE-013 — คำสั่งเชลยผิดประเภทลบเชลยแต่คืน ok=true
**Classification:** Dungeon / Invalid Transition · **Severity:** HIGH · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Dungeon / Player UI / State Machine
**Source & line links:** [GAME_SOURCE/js/sect.js:6750-6764](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6750-L6764); [GAME_SOURCE/js/sect.js:6822-6843](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6822-L6843)
- **Execution path:** handleDungeonPrisoner → set RESOLVED + filter prisoners ก่อน switch act
- **Root cause / Evidence:** ไม่มี allowlist/validation action ก่อนเปลี่ยนสถานะ
- **Gameplay impact:** เชลยหายจากคุกและมี history ว่าง ทั้งที่ไม่ได้จัดการจริง
- **Reproduction:** executePrisonerAction(id, FAKE_ACTION) → ok=true; prisoner count=0; history.titleTh ว่าง
- **Fix proposal (do not apply in audit):** ตรวจ action allowlist ก่อน mutate; validate actor/target; transactional state transition
- **Regression test to add:** unknown action leaves prisoner unchanged; no history, no rewards and ok=false

#### JHE-014 — ระบบคุกสร้างเชลยขึ้นเองในรอบวันโดยไม่มี Encounter
**Classification:** Gameplay / Design Intent · **Severity:** MEDIUM · **Status:** PROBABLE · **Confidence:** กลาง · **Reproducible:** Static / limited test
**Scope:** Dungeon / Events / World / Economy
**Source & line links:** [GAME_SOURCE/js/sect.js:6846-6862](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6846-L6862); [GAME_SOURCE/js/sect.js:6434-6438](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L6434-L6438)
- **Execution path:** SECT.daily เมื่อ day%9=0 → SECT.tickDungeon; หากคุกว่างและ day%18=0 → capturePrisoner(W) แล้ว resolve วันเดียวกัน
- **Root cause / Evidence:** เงื่อนไขตามเวลาไม่ต้องมีผลศึก, ผู้จับกุม, ข้อมูลพ่ายแพ้หรือการส่งตัว
- **Gameplay impact:** เกิดเชลยและไถ่/คัมภีร์/ศิษย์แปรพักตร์ได้จากเวลา หากไม่ได้ตั้งใจให้เป็นเหตุการณ์โลก
- **Reproduction:** ตั้ง W.day=378, dungeon ว่าง; tickDungeon → captured 0→1, prisoners_after=0, action=INTERROGATE
- **Fix proposal (do not apply in audit):** ตัดสินใจว่าเป็น random narrative event หรือ combat prisoner; ถ้า combat ให้จับจาก encounter provenance เท่านั้น
- **Regression test to add:** day 378 with no battle: no capture; ถ้าเป็น random event ให้ record origin event + constraints
- **Qualification:** เจตนาการออกแบบยังไม่ยืนยัน; CONFIRMED เฉพาะพฤติกรรมที่ทดลอง

#### JHE-015 — ค่า Vanguard posture และ intercept bonus ไม่ถูกใช้ใน Combat
**Classification:** Disconnected Code / Combat · **Severity:** HIGH · **Status:** PROBABLE · **Confidence:** สูง · **Reproducible:** Static / limited test
**Scope:** Vanguard / Combat / Governance
**Source & line links:** [GAME_SOURCE/js/sect.js:5915-5922](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5915-L5922); [GAME_SOURCE/js/combat.js:830-934](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/combat.js#L830-L934)
- **Execution path:** Officer Vanguard → writes W.sect.vanguardInterceptBonus; combat resolveDefensiveInterception คำนวณแต่ role/weapon/bond/dist
- **Root cause / Evidence:** ไม่มี static reference ใน modular js combat/อื่น ๆ ที่นำ bonus ไปคำนวณ interception
- **Gameplay impact:** ผู้เล่นเห็นโบนัสคุ้มกัน แต่ผลการเข้าสกัดกั้นอาจไม่เปลี่ยนเลย
- **Reproduction:** rg ทุก js/data พบ vanguardInterceptBonus เฉพาะตำแหน่งเขียน/แสดงใน sect.js; ไม่พบการใช้ใน combat.js
- **Fix proposal (do not apply in audit):** เชื่อม combat resolver กับ modifier จาก sect, จำกัด scope ว่า unit ฝ่ายผู้เล่น; ความน่าจะเป็นต้องมี cap
- **Regression test to add:** same seeded encounter with bonus=0 vs 0.2, compare interception distribution/score (1000 trials)
- **Qualification:** ยังไม่ได้แสดง dynamic A/B combat; จึงไม่ฟันธงว่าไม่มีทางเรียกแบบ dynamic

#### JHE-016 — สถานะขุนนางหลายค่ามีผู้เขียนแต่ไม่พบผู้บริโภค Gameplay
**Classification:** Disconnected Code / Office Jurisdictions · **Severity:** MEDIUM · **Status:** PROBABLE · **Confidence:** สูง · **Reproducible:** Static / limited test
**Scope:** Governance / Diplomacy / Threat / Dungeon / Combat
**Source & line links:** [GAME_SOURCE/js/sect.js:5803-5810](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5803-L5810); [GAME_SOURCE/js/sect.js:5820-5824](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5820-L5824); [GAME_SOURCE/js/sect.js:5831-5837](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5831-L5837); [GAME_SOURCE/js/sect.js:5866-5883](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5866-L5883); [GAME_SOURCE/js/sect.js:5910-5915](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5910-L5915)
- **Execution path:** envoy / spymaster / warden / arraymaster / commander → writes diplomacyBonus / earlyWarningBonus / dungeonSecurity / arrayIntegrity / combatPosture
- **Root cause / Evidence:** rg ใน modular runtime พบ property ใช้เฉพาะ assign/log/show; ไม่พบ downstream read ที่เปลี่ยนกฎ threat, prison escape, combat, diplomacy transactions
- **Gameplay impact:** โบนัสและนโยบายหลายตำแหน่งเสี่ยงกลายเป็นข้อความบรรยายเท่านั้น; *arraymaster* ยังมีผลจริงที่ node garrison อีกส่วนหนึ่ง
- **Reproduction:** สั่ง Officer duties แล้ว inspect writes; scan JS refs ต่อ field ไม่พบ consumer ใน systems ที่เกี่ยวข้อง
- **Fix proposal (do not apply in audit):** นิยาม contract ผู้เขียน→ผู้ใช้สำหรับแต่ละ field; ผูกกับ threat detection, jail, combat, diplomacy action และจัด A/B effect tests
- **Regression test to add:** A/B scenario ระหว่าง 0/สูงสุดของแต่ละ stat ต้องวัด outcome ที่ต่างกัน; เช็กทุกรายการผ่าน tick จริง
- **Qualification:** ไม่อ้างว่าทั้งตำแหน่ง dead: actions อื่นบางส่วนใน branch เดียวกันมี gameplay impact

#### JHE-017 — Arraymaster เพิ่ม defensePower ทบต้นเมื่อเรียก Duty ซ้ำ
**Classification:** Economy / Balance / Growth · **Severity:** MEDIUM · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** World resourceNodes / Combat defense / Officer AI
**Source & line links:** [GAME_SOURCE/js/sect.js:5865-5884](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L5865-L5884); [GAME_SOURCE/js/ui.js:2077-2083](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L2077-L2083)
- **Execution path:** runOfficerJurisdictionSingle(arraymaster) → ทุก player-owned resource node garrison.defensePower = round(defensePower*1.06)
- **Root cause / Evidence:** ไม่มี cap, cooldown หรือ origin stat เดิม; manual UI duty เรียกซ้ำในวันเดียวได้
- **Gameplay impact:** defense power โตทบต้นจนไร้สมดุลและอาจ overflow หากสั่งมากพอ
- **Reproduction:** กำหนด defensePower=100, สั่ง duty 8 ครั้งใน W.day=360 → 100,106,112,119,126,134,142,151,160
- **Fix proposal (do not apply in audit):** เปลี่ยนเป็น modifier ต่อรอบจาก baseDefense, cap และ idempotency; ไม่แก้ base บ่อย ๆ
- **Regression test to add:** 100 repeated duty calls ≤ allowable max; same day only one effect; clamp no overflow

#### JHE-018 — forceFull stipend สามารถจ่ายเงินโดยไม่มีงบกลาง
**Classification:** Economy / API Semantics · **Severity:** MEDIUM · **Status:** PROBABLE · **Confidence:** กลาง · **Reproducible:** Static / limited test
**Scope:** Stipends / Budget / API consumers
**Source & line links:** [GAME_SOURCE/js/sect.js:1050-1085](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L1050-L1085); [GAME_SOURCE/js/ui.js:1151-1161](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/ui.js#L1151-L1161)
- **Execution path:** SECT.payOfficeStipends(W,{forceFull:true}) credits recipients full, clamps sect.stones=max(0,stones-total)
- **Root cause / Evidence:** forceFull overrides affordability check; free option also suppresses debit (intended editor/test may differ)
- **Gameplay impact:** API เรียกจากระบบอื่นอาจสร้างเงินเมื่อไม่มีงบ แม้ UI ปกติใช้ opts={} ไม่ใช่ forceFull
- **Reproduction:** แต่งตั้ง mission officer, stones=0, call forceFull:true → officer +22, sect still 0
- **Fix proposal (do not apply in audit):** แยก debug grant/override ออกจาก production API หรือ guard budget; internal trusted bypass ต้องระบุชัด
- **Regression test to add:** with forceFull=true and no money, production refuses or explicitly test-only; UI normal does not mint
- **Qualification:** ยืนยันผล API; ยังไม่พบ UI ที่ส่ง forceFull:true จึงไม่จัดเป็น player-accessible confirmed

#### JHE-019 — ประลองยอดเขาตัดสินแชมป์ด้วย power sorting ไม่เกิดการต่อสู้จริง
**Classification:** Design Question / Gameplay Fidelity · **Severity:** INFO · **Status:** SUSPECTED · **Confidence:** กลาง · **Reproducible:** Static / limited test
**Scope:** Tournament / Combat Design
**Source & line links:** [GAME_SOURCE/js/sect.js:11544-11570](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11544-L11570); [GAME_SOURCE/js/sect.js:11570-11646](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sect.js#L11570-L11646)
- **Execution path:** holdInterPeakTournament → sort contenders by CULT.power × prestige → choose winner → credit rewards
- **Root cause / Evidence:** ไม่มี COMBAT fight invocation ในฟังก์ชันนี้; อาจเป็น instant-resolution ที่ตั้งใจ
- **Gameplay impact:** ผลแข่ง deterministic และไม่มีสกิล/ยุทธวิธี/บาดเจ็บในสนามตามจินตนาการผู้เล่น
- **Reproduction:** อ่าน Source Code: ผู้ชนะคือ top score โดยไม่ run Combat; Unit test แค่ ok/tournament
- **Fix proposal (do not apply in audit):** ถาม Game Design ว่าต้องการ quick simulation หรือ full combat; ถ้า full combat ให้เชื่อม COMBAT พร้อม costs/injuries
- **Regression test to add:** Design acceptance: กำหนดว่าการแข่งต้องมี combat record/skill usage หรือระบุว่าเป็น auto-simulated
- **Qualification:** ข้อสงสัยเชิงออกแบบ ไม่ใช่ Confirmed Bug

#### JHE-020 — การ Serialize มีผลข้างเคียงกับ Cache ของ NPC
**Classification:** Code Quality / Save Purity · **Severity:** INFO · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Save / Cultivation cache / Performance
**Source & line links:** [GAME_SOURCE/js/sim.js:731-735](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/sim.js#L731-L735); [GAME_SOURCE/js/cultivation.js:1995-2002](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/js/cultivation.js#L1995-L2002)
- **Execution path:** SIM.serialize(W) → ตั้ง W.npcs[i]._cultRateBase = null ก่อน stringify
- **Root cause / Evidence:** Save serializer mutate live world cache แทนใช้ replacer หรือ snap copy
- **Gameplay impact:** อาจเพิ่มงานคำนวณซ้ำหลัง Autosave และมีปัญหา state purity; ยังไม่พบ Gameplay ผิด
- **Reproduction:** อ่าน source; code mutates _cultRateBase โดยตรงก่อนสร้าง snap
- **Fix proposal (do not apply in audit):** ย้าย skip cache into serialization step โดยไม่แก้ W จริง; วัด cost หลัง autosave
- **Regression test to add:** deep compare live mutable fields ก่อน/หลัง save, perf snapshots 100 NPC
- **Qualification:** เป็นคุณภาพโค้ด; ไม่ได้พิสูจน์ความเสียหายของข้อมูล

#### JHE-021 — รายงาน QA ระบุ 188 ไฟล์ แต่ตรวจในแพ็กเกจปัจจุบันได้ 189
**Classification:** Release Documentation / Test Audit · **Severity:** INFO · **Status:** CONFIRMED · **Confidence:** สูงมาก · **Reproducible:** Yes in isolated probe
**Scope:** Release QA / Docs / Trust
**Source & line links:** [GAME_SOURCE/test/run_all.js:1-6](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/test/run_all.js#L1-L6); [GAME_SOURCE/tools/run_parallel_tests.js:70-103](https://github.com/pyopasakserpiros-prog/JHEvo/blob/29d02ba35f7f4f978ac66de23cc83de915232662/GAME_SOURCE/tools/run_parallel_tests.js#L70-L103)
- **Execution path:** release report claims syntax=188; actual tools/run_parallel_tests.js enumerates 189 JS under data/js/tools/test
- **Root cause / Evidence:** เอกสาร QA เป็น snapshot หรือจำนวนไฟล์เกิดการเปลี่ยนแปลงหลังรันรายงาน
- **Gameplay impact:** ทำให้ผู้รับรายงานเข้าใจ coverage ผิด (ไม่ได้ชี้ bug runtime)
- **Reproduction:** parallel runner fresh result: 117/117 pass, syntaxFiles=189
- **Fix proposal (do not apply in audit):** สร้าง release report จาก CI artifact ที่ผูก SHA และ timestamp เดียวกัน
- **Regression test to add:** QA pipeline assert count/suite list and embed commit SHA in report

## PART D — Dead Code, Code Zero & Disconnected Systems
**PROBABLE write-only gameplay fields (not all offices are dead):** `vanguardInterceptBonus`, `vanguardPosture`, `diplomacyBonus`, `earlyWarningBonus`, `dungeonSecurity`, `arrayIntegrity`, `combatPosture`. Static `rg` across `GAME_SOURCE/js` and `GAME_SOURCE/data` found setters/log statements and no consumer in the expected subsystem for these fields. Dynamic reflection paths not exhaustively proven absent. See JHE-015/016.
**CONFIRMED partial integration:** `PEAKS.cultivationBonusFor` accepts inactive arrays and AI uses literal `1.14/0.88` rather than this function. `arraymaster` does increase node `defensePower` so the *whole* office is not dead. Files in tests are excluded from real-runtime call graph claims.

## PART E — Logic & Gameplay Reasonableness
- Economy violates invariant: central allocation grants despite zero treasury, peak distribution can exceed budget, pill reserve is not debited; salary rounding loses stones. Combat tournament payout also mints money when prize is underfunded.
- Time/governance: manual UI force-executes officer duties without freshness guard; normal daily officer interval exists but is bypassed. Tournament/exchange can be repeated same day.
- Peak progression: tournament auto-founds peaks and activation works on un-founding; 14% aura independent from arrayActive, leaving player-facing UI causality misleading.
- Dungeon: canonical prisoner lookup can be bypassed with Object; unknown action resolves and removes prisoner; timed ghost prisoner event is a design question not a certain defect without design signoff.
- Combat fidelity: instant peak tournament selects winner by score (not a COMBAT bout). Whether this is intended fast simulation requires design confirmation.

## PART F — Cross-System Integration Map
```text
UI[data-do=allocate-peak-resources] → PEAKS.allocateCentralResourcesToPeaks → peak treasury ↑ → NPC wallet ↑
                                                           ↳ MISSING: central treasury debit / pill reserve debit
UI[data-do=run-officer-jurisdictions] → SECT.runOfficerJurisdictions(ignoreAvailability) → Quartermaster ECO.earn
                                                                                  ↳ MISSING: duty idempotency/cooldown
SECT.vanguard duty → W.sect.vanguardInterceptBonus → [NO identified read] → COMBAT.resolveDefensiveInterception
SECT.warden duty → dungeonSecurity → [NO identified read] → Prisoner lifecycle
SECT.PEAKS.activatePeakArray → arrayActive → [not checked] → AI cultivation (hardcoded 1.14)
SECT.handleDungeonPrisoner(Object) → stats/treasury ↑ → [MISSING: canonical membership check]
COMBAT.tournamentEnd → ECO.pay(min(prize, treasury)) → NPC wallet += full prize
```

## PART G — API & Dependency Audit
- No `package.json` in provided package; core runs as browser JavaScript and Node test scripts. Browser tests use `tools/cdp_playwright.js` Chromium CDP fallback when `playwright` package is absent (verified `playwright` unavailable, `/usr/bin/chromium` present).
- Context7 documentation query for Microsoft Playwright APIs was reviewed in this audit conversation; installed Playwright package version is **not available**, so do not claim a package-version-specific defect from those docs. The custom CDP driver must be evaluated against its own implementation, not presumed equivalent to Playwright in every API.
- Replit: connected account returned zero apps for JHEvo; no repository moved or new app created. Vercel: no linked deployment project found for this repo; no build/deploy action performed.

## PART H — Performance & Stability
- `test/browser_mobile_perf.js`: PASS, 360/412/1280px, 24 tabs, 0×–48× controls, 80-NPC stress. Reported 0.557 ms/tick for this environment.
- Independent Node 80-NPC 2,000-tick simulation: average 0.580 ms/tick; 100-tick batches ranged 0.295–1.038 ms/tick. HeapUsed 38.60 MB → 64.42 MB; this single run **cannot establish a memory leak**.
- Long-run >20k ticks, browser GC trend, x32 over hours on physical mobile, massive world expansion: **NOT VERIFIED**. Do not infer absence of degradation from current PASS.

## PART I — Test Results and Coverage Gaps
| Run | Result | Exact scope |
|---|---|---|
| `node tools/run_parallel_tests.js` | 117 / 117 PASS, 0 fail, 0 timeout (53.03s) | Node+browser suites+syntax; syntax 189 JS |
| `node test/browser_mobile_perf.js` | PASS, 0.557 ms/tick | Chrome CDP mobile/desktop + 80 NPC |
| Independent probes 1–3 | 19 isolated cases EXECUTED (including bootstrap) | Resources, peak, dungeon, salary, office, combat |
| Independent 80 NPC × 2,000 ticks | PASS no thrown exception | Perf sample; not long-run memory proof |
| Player save data | NOT RUN | No real user save touched |
**Important:** Existing test/v310 suite checks `activatePeakArray` and `cultivationBonusFor` separately but does not verify `arrayActive=false` prevents gameplay bonus; similarly the dungeon suite only tests known actions and not fake Object/replay/unknown Action. These coverage omissions explain how green tests and confirmed bugs coexist.

## PART J — Historical Regression (9 required targets)
| Historical target | Existing evidence | Status of regression risk | Add test |
|---|---|---|---|
| Episode 4/5 freeze | ไม่มี targeted episode-specific regression ที่ยืนยันจากชื่อ test | NOT VERIFIED | เพิ่ม scripted replay ep4/ep5 พร้อม watchdog และ save snapshots |
| AI flee/retreat anomalous | test/npc_command.js และ v300_tactical... PASS | PARTIAL | เพิ่ม scenario flee/should-not-flee/retreat loops 2k ticks |
| Donation/deposit loops | test/unified_donation_suite.js, phase3_stock_distribution_log.js PASS | PARTIAL | ตรวจ deposit/withdraw invariant และ repeated same action across save/load |
| Visitor confused with Disciple | visitors_clues_weapons_suite.js / merchant_guest_lifecycle.js อยู่ใน suite PASS | PARTIAL | assert visitor never enters W.npcs except explicit join path |
| Threat Radius blocks exploration | test/exploration_replay.js และ codex_combined_review.js PASS | PARTIAL | property reachable nodes after safe-zone and threat changes |
| Sanctuary enemy placement | test/diplomacy_sanctum_ancestral_suite.js PASS | PARTIAL | spawn coordinates vs sanctuary safe bounds tests |
| Research not starting | test/sect_library_suite.js PASS | PARTIAL | NPC auto-init when eligible, progress after 5 days & missing lead |
| Library exists but NPC not using it | test/sect_library_suite.js PASS | PARTIAL | instrument AI choose study→spend CP→learn technique→combat effect |
| Spawner lacks technique crystals | test/phase2_edit_hub_inventory.js PASS | VERIFIED TEST COVERAGE | T: crystal in UI editor and stock on actual browser |

## PART K — Risk Assessment
1. **P0 High risk:** Resource conservation (JHE-001/002/003, JHE-006), prisoner canonical status/integrity (JHE-012/013), UI-triggered repeat duty and tournament farm (JHE-004/007/008). These directly alter economy and progression.
2. **P1 Medium/High risk:** Peak aura/activation and officer combat integration (JHE-010/011/015/016); garrison exponential scaling (JHE-017); payroll rounding (JHE-005).
3. **P2 Quality/Design risk:** Dungeon time-spawn provenance (JHE-014), forced stipend API scope (JHE-018), simulated tournament fidelity (JHE-019), serialize purity (JHE-020), release documentation alignment (JHE-021).

## PART L — Recommended Development Roadmap
**Wave 1 / Lock critical invariants:** ป้องกัน prisoner identity spoof/replay/action-invalid; สร้าง transaction ledger ที่ debit=credit สำหรับ central→peak, peak→member, pill, prize, payroll; เขียน failing regression tests ก่อนแก้.
**Wave 2 / Player exploit gates:** เพิ่ม per-day/per-period idempotency ให้ UI duties, tournaments, exchanges; ห้าม tournament auto-found เมื่อไม่ผ่านเกณฑ์; validate founding/array state ก่อนเปิด.
**Wave 3 / System integration:** ผูก `vanguardInterceptBonus` กับ combat intercept และ peak array activation กับ actual cultivation rate; ให้ write-only office state มี consumer ที่วัดได้ หรือถอดคำโฆษณา/UI ที่ยังไม่จริง.
**Wave 4 / Determinism and long-run QA:** เพิ่ม property-based balance, scenario seeded A/B, >20k ticks/80–200 NPC, x32 soak, Episode4/5 replay; รายงาน CI ควรฝัง SHA ที่ตรวจและจำนวนไฟล์จริง.

### AUDIT ONLY / Provenance & Git Safety
- No repository edits, commits, pushes, merges, branch switches, dependency installations, deployments, or modifications of real save data.
- GitHub `main` HEAD at audit start: 29d02ba35f7f4f978ac66de23cc83de915232662; HEAD at audit close: 2153e96071babed34f8f6ef05658b6931bdcf353. GitHub compare confirmed the one new commit added only `JHEvo_v3.1.0_Development_Proposals_and_Roadmap.pdf` and `JHEvo_v3.1.0_Full_Game_Audit_Report.pdf`, and did not modify `GAME_SOURCE`, so all code findings remain applicable to the later HEAD. Uploaded ZIP has no `.git` directory; `git status` cannot describe a working tree for the ZIP. Git blob SHA equality was confirmed for 5 key files, not entire Git tree.
- Independent probes were written and run in `/tmp/jhevo_audit/`, outside source; test harness test-result artifacts were written only to the disposable extracted copy.
- All source links in this report are pinned to GitHub commit 29d02ba35f7f4f978ac66de23cc83de915232662.
