(function (root, factory) {
  "use strict";
  const value = factory(
    typeof module === "object" && module.exports
      ? require("./human-core.js")
      : root.CompanyCore,
  );
  if (typeof module === "object" && module.exports) module.exports = value;
  else root.CompanyData = value;
})(typeof globalThis !== "undefined" ? globalThis : this, function (H) {
  "use strict";
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const idPattern = /^[a-z][a-zA-Z0-9_-]{0,63}$/;
  const validId = (id) =>
    typeof id === "string" &&
    idPattern.test(id) &&
    !["constructor", "prototype"].includes(id);
  const deepFreeze = (o) => {
    Object.values(o).forEach((v) => {
      if (v && typeof v === "object") deepFreeze(v);
    });
    return Object.freeze(o);
  };

  // Multi-nationality demographic & name pools researched from authentic regional registries
  const NATIONALITIES = deepFreeze({
    TH: {
      id: "TH",
      nameTh: "ไทย",
      nameEn: "Thai",
      flag: "🇹🇭",
      codeTh: "TH · ไทย",
      hometowns: ["นนทบุรี", "สมุทรปราการ", "ปทุมธานี", "ชลบุรี", "เชียงใหม่", "ขอนแก่น", "นครราชสีมา", "ระยอง", "พระนครศรีอยุธยา", "ฉะเชิงเทรา"],
      educations: [
        "ปวส. เทคนิคอุตสาหกรรมและเมคคาทรอนิกส์",
        "ปริญญาตรี วิศวกรรมอุตสาหการและระบบการผลิต",
        "ปริญญาตรี บริหารธุรกิจและการจัดการซัพพลายเชน",
        "ปวส. ช่างกลโรงงานและควบคุมคุณภาพมาตรฐานสากล",
        "ปริญญาตรี บัญชีต้นทุนและการเงินธุรกิจอุตสาหกรรม"
      ],
      roleWeight: { sales: 0.72, admin: 0.78, engineer: 0.52, assembler: 0.58, inspector: 0.62, logistics: 0.64, coordinator: 0.72 }
    },
    JP: {
      id: "JP",
      nameTh: "ญี่ปุ่น",
      nameEn: "Japanese",
      flag: "🇯🇵",
      codeTh: "JP · ญี่ปุ่น",
      hometowns: ["โอซาก้า", "นาโกย่า", "โยโกฮาม่า", "ฟุกุโอกะ", "เกียวโต", "ฮามามัตสึ"],
      educations: [
        "สถาบันเทคโนโลยีแห่งโตเกียว (Monozukuri & Lean QC)",
        "ปริญญาตรี วิศวกรรมไมโครอิเล็กทรอนิกส์และยานยนต์ (Nagoya)",
        "ผู้เชี่ยวชาญมาตรฐาน Kaizen, 5S & IPC-A-610"
      ],
      roleWeight: { sales: 0.05, admin: 0.04, engineer: 0.18, assembler: 0.04, inspector: 0.14, logistics: 0.03, coordinator: 0.08 }
    },
    CN: {
      id: "CN",
      nameTh: "จีน",
      nameEn: "Chinese",
      flag: "🇨🇳",
      codeTh: "CN · จีน",
      hometowns: ["เซินเจิ้น", "ซูโจว", "กวางโจว", "เซี่ยงไฮ้", "ตงกวน", "หางโจว"],
      educations: [
        "วิศวกรรมฮาร์ดแวร์และซัพพลายเชนอุตสาหกรรม (Shenzhen)",
        "ปริญญาตรี วิศวกรรมระบบอัตโนมัติและพลังงานสะอาด",
        "การจัดการโลจิสติกส์และจัดซื้อชิ้นส่วนระดับโลก"
      ],
      roleWeight: { sales: 0.08, admin: 0.06, engineer: 0.14, assembler: 0.08, inspector: 0.08, logistics: 0.08, coordinator: 0.08 }
    },
    VN: {
      id: "VN",
      nameTh: "เวียดนาม",
      nameEn: "Vietnamese",
      flag: "🇻🇳",
      codeTh: "VN · เวียดนาม",
      hometowns: ["บั๊กนิญ", "ไฮฟอง", "ดานัง", "โฮจิมินห์", "ฮานอย", "บิ่ญเซือง"],
      educations: [
        "เทคนิคการประกอบ SMT และสายการผลิตความแม่นยำสูง (Bac Ninh)",
        "ปริญญาตรี วิศวกรรมไฟฟ้าและตรวจสอบคุณภาพผลิตภัณฑ์",
        "ประกาศนียบัตรวิชาชีพชั้นสูง ช่างเทคนิคอุตสาหกรรม"
      ],
      roleWeight: { sales: 0.04, admin: 0.04, engineer: 0.08, assembler: 0.14, inspector: 0.1, logistics: 0.1, coordinator: 0.04 }
    },
    MM: {
      id: "MM",
      nameTh: "เมียนมา",
      nameEn: "Myanmar",
      flag: "🇲🇲",
      codeTh: "MM · เมียนมา",
      hometowns: ["ย่างกุ้ง", "มัณฑะเลย์", "พะโค", "เมาะลำเลิง", "ตองยี"],
      educations: [
        "ใบรับรองช่างประกอบชิ้นส่วนอุตสาหกรรมและคลังสินค้า",
        "เทคนิคการประกอบละเอียดและการแพ็กกิ้งมาตรฐานส่งออก",
        "วิชาชีพช่างเทคนิคสายการผลิตและตรวจสอบเบื้องต้น"
      ],
      roleWeight: { sales: 0.02, admin: 0.02, engineer: 0.02, assembler: 0.14, inspector: 0.04, logistics: 0.13, coordinator: 0.03 }
    },
    EN: {
      id: "EN",
      nameTh: "สากล (ตะวันตก)",
      nameEn: "International",
      flag: "🇬🇧",
      codeTh: "EN · สากล",
      hometowns: ["ลอนดอน", "ซานโฮเซ", "ซิดนีย์", "แมนเชสเตอร์", "มิวนิก", "ซูริก"],
      educations: [
        "B.Eng. Embedded Systems & Industrial Automation",
        "B.Sc. Global Supply Chain & B2B Key Account Management",
        "M.Eng. Reliability Engineering & Six Sigma Black Belt"
      ],
      roleWeight: { sales: 0.09, admin: 0.06, engineer: 0.06, assembler: 0.02, inspector: 0.02, logistics: 0.02, coordinator: 0.05 }
    }
  });

  const NAME_POOLS = deepFreeze({
    TH: {
      maleFirst: [
        "ธนกฤต", "กิตติพงศ์", "ณัฐวุฒิ", "ศุภชัย", "ภูริพัฒน์", "ชยุต",
        "ภาคิน", "วรเมธ", "ธีรภัทร", "ปิยะพงษ์", "จิรายุ", "กัมปนาท",
        "อัครเดช", "พีรวิชญ์", "นรภัทร", "ศรัณย์", "พงศกร", "อนุชา",
        "ธนดล", "กฤตภาส", "ชานนท์", "ปรเมศวร์", "สิรภพ", "เจตนิพัทธ์"
      ],
      femaleFirst: [
        "กมลชนก", "พิมพ์ชนก", "ณัฐธิดา", "ศิริพร", "ชลธิชา", "กัญญาณัฐ",
        "ภัทรวดี", "วรัญญา", "อารยา", "สุภัสสรา", "นันท์นภัส", "ปภาวรินท์",
        "พิชญาภา", "รุ่งทิวา", "ธัญชนก", "อัญชลี", "ลลิตา", "มนัสนันท์",
        "ชนัญชิดา", "ปุณยนุช", "กานต์สินี", "แพรวพรรณ", "ญาดา", "เขมิกา"
      ],
      surnames: [
        "วงศ์สุวรรณ", "เจริญสุข", "ศรีสวัสดิ์", "เกียรติไพศาล", "รัตนโชติ",
        "พงษ์พานิช", "อัครเดชา", "วัฒนากุล", "โชติบริบูรณ์", "ตั้งเจริญ",
        "พิทักษ์สิน", "ธนากิจ", "ศิริวงศ์", "เลิศวิไล", "กิจเจริญ",
        "บุญญะริทธิ์", "สมบูรณ์ผล", "สุวรรณภูมิ", "จรัสแสง", "นิคมรัตน์",
        "วิริยะกิจ", "มหาดำรงค์", "เปี่ยมสุข", "สกุลไทย", "ทรัพย์ทวี"
      ],
      nicknamesMale: ["ภัทร", "ต้น", "กานต์", "ธีร์", "ภูมิ", "นนท์", "เจ", "อาร์ต", "แบงค์", "ก้อง", "เอิร์ธ", "ท็อป", "บอส", "พีท", "มาร์ค", "โอม", "คิว", "กาย"],
      nicknamesFemale: ["มิน", "น้ำ", "อิง", "ป่าน", "แพร", "ฟ้า", "เมย์", "โบว์", "พลอย", "มายด์", "เนย", "พิม", "เฟิร์น", "จูน", "เบลล์", "ออม", "ครีม", "กวาง"]
    },
    JP: {
      maleFirst: ["ฮารุโตะ (Haruto)", "เร็น (Ren)", "ทาคุมิ (Takumi)", "เคนจิ (Kenji)", "โซตะ (Sota)", "ไดกิ (Daiki)", "ยูโตะ (Yuto)", "นาโอกิ (Naoki)"],
      femaleFirst: ["ฮิมาริ (Himari)", "อาโออิ (Aoi)", "ยุย (Yui)", "ซากุระ (Sakura)", "มิโอะ (Mio)", "ริน (Rin)", "อายากะ (Ayaka)", "นานามิ (Nanami)"],
      surnames: ["ซาโต้ (Sato)", "ซูซูกิ (Suzuki)", "ทาคาฮาชิ (Takahashi)", "ทานากะ (Tanaka)", "วาตานาเบะ (Watanabe)", "อิโต้ (Ito)", "ยามามาโตะ (Yamamoto)", "โคบายาชิ (Kobayashi)"],
      nicknamesMale: ["เคน", "ทาคุ", "เร็น", "ฮารุ", "โซตะ", "ได"],
      nicknamesFemale: ["อาโออิ", "ยุย", "มิโอะ", "ริน", "ซากุระ", "นานะ"]
    },
    CN: {
      maleFirst: ["เหว่ย (Wei)", "ฮ่าวหราน (Haoran)", "จื้อหาว (Zihao)", "หมิงเจ๋อ (Mingze)", "เจี้ยนหัว (Jianhua)", "จวิ้นเจี๋ย (Junjie)", "อี้เฉิน (Yichen)", "ข่าย (Kai)"],
      femaleFirst: ["จื่อหาน (Zihan)", "อี้หนัว (Yinuo)", "ซินอี้ (Xinyi)", "เหม่ยหลิง (Meiling)", "เสี่ยวเหวิน (Xiaowen)", "เจียอี้ (Jiayi)", "หยูถง (Yutong)", "หลิน (Lin)"],
      surnames: ["หวัง (Wang)", "หลี่ (Li)", "จาง (Zhang)", "หลิว (Liu)", "เฉิน (Chen)", "หยาง (Yang)", "หวง (Huang)", "จ้าว (Zhao)"],
      nicknamesMale: ["เหว่ย", "ฮ่าว", "หมิง", "เจี้ยน", "ข่าย"],
      nicknamesFemale: ["หลิน", "เหม่ย", "ซิน", "เหวิน", "เจีย"]
    },
    VN: {
      maleFirst: ["มินห์ กวาน (Minh Quan)", "ฮว่าง นาม (Hoang Nam)", "ดึ๊ก อันห์ (Duc Anh)", "แทงห์ ตุง (Thanh Tung)", "กวาง ฮุย (Quang Huy)", "บ๋าว ลอง (Bao Long)"],
      femaleFirst: ["ถวิ ลินห์ (Thuy Linh)", "บิช หง็อก (Bich Ngoc)", "ไม อันห์ (Mai Anh)", "แทงห์ ห่า (Thanh Ha)", "ฟือง เถ่า (Phuong Thao)", "ลาน อันห์ (Lan Anh)"],
      surnames: ["เหงียน (Nguyen)", "เจิ่น (Tran)", "เล (Le)", "ฝ่าม (Pham)", "ฮหว่าง (Hoang)", "หวู (Vu)", "ดัง (Dang)", "บุ่ย (Bui)"],
      nicknamesMale: ["กวาน", "นาม", "ฮุย", "ตุง", "ลอง"],
      nicknamesFemale: ["ลินห์", "หง็อก", "ไม", "ห่า", "เถ่า"]
    },
    MM: {
      maleFirst: ["อ่อง จอ (Aung Kyaw)", "มิน ตัน (Min Thant)", "หม่อง ซอ (Maung Zaw)", "โก โก (Ko Ko)", "เท็ต แนง (Htet Naing)", "ซอ ลวิน (Zaw Lwin)"],
      femaleFirst: ["เม ตะซิน (May Thazin)", "ขิ่น ซู (Khin Su)", "เอ มิ (Aye Mi)", "นันท์ ซานดาร์ (Nand Sandar)", "ซู มยัต (Su Myat)", "พยู ซิน (Phyu Sin)"],
      surnames: ["สายช่างย่างกุ้ง", "สายเทคนิคมัณฑะเลย์", "สายงานพะโค", "สายอุตสาหกรรมเมียนมา"],
      nicknamesMale: ["อ่อง", "หม่อง", "ซอ", "เท็ต", "โก"],
      nicknamesFemale: ["เม", "ขิ่น", "เอ", "ซู", "พยู"]
    },
    EN: {
      maleFirst: ["อเล็กซานเดอร์ (Alexander)", "เจมส์ (James)", "โอลิเวอร์ (Oliver)", "ลูคัส (Lucas)", "แดเนียล (Daniel)", "มาร์คัส (Marcus)"],
      femaleFirst: ["ชาร์ล็อตต์ (Charlotte)", "เอมิลี่ (Emily)", "โซเฟีย (Sophia)", "คลาร่า (Clara)", "เอเลน่า (Elena)", "ฮันนาห์ (Hannah)"],
      surnames: ["สมิธ (Smith)", "จอห์นสัน (Johnson)", "มิลเลอร์ (Miller)", "แอนเดอร์สัน (Anderson)", "เทย์เลอร์ (Taylor)", "คลาร์ก (Clark)"],
      nicknamesMale: ["อเล็กซ์", "เจมส์", "ลุค", "แดน", "มาร์ค"],
      nicknamesFemale: ["เอมี่", "โซฟี", "คลาร่า", "เอเลน", "ฮันนาห์"]
    }
  });

  const STARTER_IDENTITIES = deepFreeze({
    "employee-1": { nationality: "TH", gender: "F", age: 27, firstName: "มินตรา", lastName: "วงศ์สุวรรณ", educationTh: "ปริญญาตรี บริหารธุรกิจและการตลาดอุตสาหกรรม B2B (ม.เกษตรฯ)", hometownTh: "นนทบุรี" },
    "employee-2": { nationality: "TH", gender: "M", age: 29, firstName: "ภัทรพล", lastName: "เจริญสุข", educationTh: "ปริญญาตรี การจัดการซัพพลายเชนและบัญชีต้นทุน", hometownTh: "สมุทรปราการ" },
    "employee-3": { nationality: "JP", gender: "F", age: 31, firstName: "นานามิ (Nanami)", lastName: "ทาคาฮาชิ (Takahashi)", educationTh: "วิศวกรรมระบบอุตสาหกรรมและนวัตกรรม (Osaka Institute of Tech)", hometownTh: "โอซาก้า" },
    "employee-4": { nationality: "TH", gender: "M", age: 24, firstName: "ต้นกล้า", lastName: "ศรีสวัสดิ์", educationTh: "ปวส. เทคนิคการผลิตและเมคคาทรอนิกส์โรงงาน", hometownTh: "ชลบุรี" },
    "employee-5": { nationality: "VN", gender: "F", age: 23, firstName: "ถวิ ลินห์ (Thuy Linh)", lastName: "เหงียน (Nguyen)", educationTh: "เทคนิคสายการผลิตอัตโนมัติและการประกอบความแม่นยำสูง (Bac Ninh)", hometownTh: "บั๊กนิญ" },
    "employee-6": { nationality: "TH", gender: "M", age: 30, firstName: "กานต์ชนก", lastName: "เกียรติไพศาล", educationTh: "ปริญญาตรี วิศวกรรมควบคุมคุณภาพ มาตรฐาน ISO 9001 & IQC", hometownTh: "ปทุมธานี" },
    "employee-7": { nationality: "MM", gender: "F", age: 25, firstName: "เม ตะซิน (May Thazin)", lastName: "สายเทคนิคย่างกุ้ง", educationTh: "วิชาชีพการจัดการคลังสินค้าและฟลีทขนส่งส่งออก", hometownTh: "ย่างกุ้ง" },
    "employee-8": { nationality: "CN", gender: "M", age: 34, firstName: "จื้อหาว (Zihao)", lastName: "เฉิน (Chen)", educationTh: "ปริญญาโท บริหารอุตสาหกรรมและกลยุทธ์องค์กร (Shenzhen Tech)", hometownTh: "เซินเจิ้น" }
  });

  // Real-World Corporate Organizational Divisions (ฝ่ายบริหารในออฟฟิศ vs ฝ่ายปฏิบัติการในโรงงาน)
  const CORPORATE_DIVISIONS = deepFreeze({
    executive: {
      id: "executive",
      nameTh: "คณะผู้บริหารและสำนักงานประธาน (CEO & Executive Office)",
      zoneId: "office",
      icon: "👑",
      roles: ["coordinator"],
      descriptionTh: "กำหนดเข็มทิศกลยุทธ์ประจำสัปดาห์ บริหารเงินทุน ชำระหนี้ ขยายอาคาร/ที่ดิน สรรหาบุคลากร และอนุมัติเลื่อนตำแหน่ง"
    },
    office: {
      id: "office",
      nameTh: "ฝ่ายบริหารและพาณิชย์ในออฟฟิศ (Corporate & Commercial Office)",
      zoneId: "office",
      icon: "🏢",
      roles: ["sales", "admin", "engineer"],
      descriptionTh: "เจรจาดีลธุรกิจกับบริษัทคู่ค้า B2B จัดซื้อวัตถุดิบต้นน้ำ บริหารบัญชี/ใบแจ้งหนี้ และวิจัยพัฒนาแบบแปลนสินค้าใหม่"
    },
    factory: {
      id: "factory",
      nameTh: "ฝ่ายปฏิบัติการโรงงานและโลจิสติกส์ (Factory & Supply Chain Operations)",
      zoneId: "factory",
      icon: "🏭",
      roles: ["assembler", "inspector", "logistics"],
      descriptionTh: "เดินเครื่องสายการผลิต ประกอบชิ้นงาน ตรวจสอบคุณภาพ QC/QA แพ็กสินค้าลงกล่อง และปล่อยรถบรรทุกจัดส่งลูกค้า"
    }
  });

  const ROLE_DEPARTMENTS = deepFreeze({
    coordinator: {
      roleId: "coordinator",
      divisionId: "executive",
      divisionNameTh: "ฝ่ายบริหารระดับสูงและทรัพยากรบุคคล (Executive & HR Office)",
      departmentTh: "สำนักประธานบริหารและพัฒนาองค์กร (CEO & Corporate HR)",
      zoneTh: "อาคารสำนักงานใหญ่ (Office HQ)",
      coreDutiesTh: "กำหนดกลยุทธ์บริษัท บริหารสภาพคล่อง ลงทุนก่อสร้างอาคาร คัดเลือกคนเข้าทำงาน และประเมินเลื่อนขั้น"
    },
    sales: {
      roleId: "sales",
      divisionId: "office",
      divisionNameTh: "ฝ่ายบริหารในออฟฟิศ (White-Collar Office)",
      departmentTh: "ฝ่ายขายและพัฒนาธุรกิจ B2B (Commercial & B2B Sales)",
      zoneTh: "อาคารสำนักงานใหญ่ (Office HQ)",
      coreDutiesTh: "ติดต่อบริษัทคู่ค้า เจรจาต่อรองราคาขาย เงื่อนไขมัดจำ และคัดเลือกคำสั่งซื้อที่ทำกำไรสูงสุด"
    },
    admin: {
      roleId: "admin",
      divisionId: "office",
      divisionNameTh: "ฝ่ายบริหารในออฟฟิศ (White-Collar Office)",
      departmentTh: "ฝ่ายจัดซื้อ ซัพพลายเชน และบัญชีการเงิน (Procurement & Finance)",
      zoneTh: "อาคารสำนักงานใหญ่ / คลังวัตถุดิบ",
      coreDutiesTh: "วางแผนสั่งซื้อวัตถุดิบจากซัพพลายเออร์ ออกใบ PO สร้างเครดิตการค้า และวางบิลเรียกเก็บเงินลูกค้า (Invoice)"
    },
    engineer: {
      roleId: "engineer",
      divisionId: "office",
      divisionNameTh: "ฝ่ายวิจัยและวิศวกรรม (R&D & Engineering)",
      departmentTh: "ฝ่ายวิจัยผลิตภัณฑ์และวิศวกรรมเครื่องกล (R&D & Maintenance Engineering)",
      zoneTh: "อาคารแล็บวิจัย (R&D Lab) & โรงงาน",
      coreDutiesTh: "วิจัยปลดล็อกสินค้าอุตสาหกรรมใหม่ ปรับปรุงกระบวนการผลิต และซ่อมบำรุงเครื่องจักรเชิงป้องกัน"
    },
    assembler: {
      roleId: "assembler",
      divisionId: "factory",
      divisionNameTh: "ฝ่ายปฏิบัติการในโรงงาน (Factory Floor Operations)",
      departmentTh: "ฝ่ายการผลิตและประกอบชิ้นงาน (Production & Assembly Line)",
      zoneTh: "อาคารโรงงานผลิต (Production Lines A/B/C)",
      coreDutiesTh: "เบิกวัตถุดิบตามสูตร BOM เดินเครื่องจักรประกอบชิ้นงาน และแก้ไขงานซ่อม (Rework)"
    },
    inspector: {
      roleId: "inspector",
      divisionId: "factory",
      divisionNameTh: "ฝ่ายปฏิบัติการในโรงงาน (Factory Floor Operations)",
      departmentTh: "ฝ่ายควบคุมและประกันคุณภาพ (Quality Control & Assurance - QC/QA)",
      zoneTh: "แท่นตรวจมาตรฐานโรงงาน (QC Station)",
      coreDutiesTh: "ตรวจสอบความสมบูรณ์ของชิ้นงาน คัดกรองของเสียก่อนส่งมอบ และรักษามาตรฐานชื่อเสียงบริษัท"
    },
    logistics: {
      roleId: "logistics",
      divisionId: "factory",
      divisionNameTh: "ฝ่ายปฏิบัติการในโรงงานและคลังสินค้า (Warehouse & Fleet Operations)",
      departmentTh: "ฝ่ายคลังพัสดุและโลจิสติกส์จัดส่ง (Warehouse & Outbound Logistics)",
      zoneTh: "อาคารคลังสินค้าและท่าปล่อยรถขนส่ง",
      coreDutiesTh: "ตรวจรับวัตถุดิบเข้าคลัง แพ็กสินค้าสำเร็จรูปลงหีบห่อ และจัดส่งขึ้นรถบรรทุกไปถึงบริษัทลูกค้า"
    }
  });

  const CAREER_LADDERS = deepFreeze({
    sales: [
      { level: 1, titleTh: "เจ้าหน้าที่ฝ่ายขาย B2B (Jr. B2B Sales)", badge: "Lv.1", division: "office", departmentTh: "ฝ่ายขายและพาณิชย์", dutyTh: "ติดต่อลูกค้าและทำใบเสนอราคา", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "เจ้าหน้าที่บริหารลูกค้าองค์กรอาวุโส (Sr. Key Account Sales)", badge: "Lv.2", division: "office", departmentTh: "ฝ่ายขายและพาณิชย์", dutyTh: "เจรจาต่อรองราคาขายและมัดจำกับคู่ค้ารายใหญ่", minTasks: 2, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.12 },
      { level: 3, titleTh: "ผู้จัดการฝ่ายขายและการพาณิชย์ (Commercial Sales Manager)", badge: "Lv.3", division: "office", departmentTh: "ฝ่ายขายและพาณิชย์", dutyTh: "คุมทีมขาย ประเมินเลื่อนขั้นในแผนก และปิดดีลระดับองค์กร", minTasks: 6, minSkill: 56, minTenureDays: 5, wageBonus: 7500, mentorPower: 0.24 },
      { level: 4, titleTh: "ผู้อำนวยการฝ่ายพาณิชย์ (Chief Commercial Officer - CCO)", badge: "Lv.4", division: "executive", departmentTh: "คณะผู้บริหารสายพาณิชย์", dutyTh: "กำหนดยุทธศาสตร์การตลาดและสัญญาระดับประเทศ", minTasks: 12, minSkill: 65, minTenureDays: 10, wageBonus: 14000, mentorPower: 0.36 }
    ],
    admin: [
      { level: 1, titleTh: "เจ้าหน้าที่จัดซื้อและบัญชี (Jr. Procurement & Accounting)", badge: "Lv.1", division: "office", departmentTh: "ฝ่ายจัดซื้อและบัญชีการเงิน", dutyTh: "ออกใบสั่งซื้อ PO และวางบิลลูกค้า", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "นักวางแผนซัพพลายเชนและบัญชีอาวุโส (Sr. Supply Chain & Finance)", badge: "Lv.2", division: "office", departmentTh: "ฝ่ายจัดซื้อและบัญชีการเงิน", dutyTh: "บริหารสต็อกวัตถุดิบและเจรจาเครดิตซัพพลายเออร์", minTasks: 2, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.12 },
      { level: 3, titleTh: "ผู้จัดการฝ่ายจัดซื้อและบัญชีการเงิน (Supply Chain & Finance Mgr)", badge: "Lv.3", division: "office", departmentTh: "ฝ่ายจัดซื้อและบัญชีการเงิน", dutyTh: "ควบคุมต้นทุนวัตถุดิบ กระแสเงินสด และประเมินทีม", minTasks: 6, minSkill: 56, minTenureDays: 5, wageBonus: 7000, mentorPower: 0.24 },
      { level: 4, titleTh: "ประธานเจ้าหน้าที่ฝ่ายการเงิน (Chief Financial Officer - CFO)", badge: "Lv.4", division: "executive", departmentTh: "คณะผู้บริหารสายการเงิน", dutyTh: "บริหารโครงสร้างเงินทุน งบดุล และความเสี่ยงทางการเงิน", minTasks: 12, minSkill: 65, minTenureDays: 10, wageBonus: 13000, mentorPower: 0.36 }
    ],
    engineer: [
      { level: 1, titleTh: "วิศวกรวิจัยและกระบวนการผลิต (R&D & Process Engineer)", badge: "Lv.1", division: "office", departmentTh: "ฝ่ายวิจัยและวิศวกรรม", dutyTh: "วิจัยผลิตภัณฑ์ใหม่และดูแลเครื่องจักร", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0.05 },
      { level: 2, titleTh: "วิศวกรระบบและเครื่องกลอาวุโส (Sr. Industrial Engineer)", badge: "Lv.2", division: "office", departmentTh: "ฝ่ายวิจัยและวิศวกรรม", dutyTh: "พัฒนาแบบแปลนขั้นสูงและซ่อมบำรุงเชิงป้องกัน", minTasks: 2, minSkill: 50, minTenureDays: 2, wageBonus: 4500, mentorPower: 0.16 },
      { level: 3, titleTh: "หัวหน้าวิศวกรบริหารโครงการ (Principal Chief Engineer)", badge: "Lv.3", division: "office", departmentTh: "ฝ่ายวิจัยและวิศวกรรม", dutyTh: "นำทีมวิจัย R&D และวางผังเทคโนโลยีโรงงาน", minTasks: 6, minSkill: 58, minTenureDays: 5, wageBonus: 9500, mentorPower: 0.28 },
      { level: 4, titleTh: "ประธานเจ้าหน้าที่ฝ่ายเทคโนโลยี (Chief Technology Officer - CTO)", badge: "Lv.4", division: "executive", departmentTh: "คณะผู้บริหารสายเทคโนโลยี", dutyTh: "ขับเคลื่อนนวัตกรรมและระบบอัตโนมัติทั้งนิคม", minTasks: 12, minSkill: 66, minTenureDays: 10, wageBonus: 16000, mentorPower: 0.4 }
    ],
    assembler: [
      { level: 1, titleTh: "พนักงานฝ่ายผลิตหน้าไลน์ (Production Line Operator)", badge: "Lv.1", division: "factory", departmentTh: "ฝ่ายการผลิตและประกอบ", dutyTh: "เดินเครื่องจักรและประกอบชิ้นงานตาม BOM", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "ช่างเทคนิคสายการผลิตอาวุโส (Sr. Line Technician)", badge: "Lv.2", division: "factory", departmentTh: "ฝ่ายการผลิตและประกอบ", dutyTh: "คุมเครื่องจักรความแม่นยำสูงและสอนงานช่างใหม่", minTasks: 3, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.14 },
      { level: 3, titleTh: "หัวหน้ากะสายการผลิต (Production Shift Foreman)", badge: "Lv.3", division: "factory", departmentTh: "ฝ่ายการผลิตและประกอบ", dutyTh: "ควบคุมโควตาการผลิตประจำกะและประเมินช่างในทีม", minTasks: 8, minSkill: 56, minTenureDays: 5, wageBonus: 7500, mentorPower: 0.26 },
      { level: 4, titleTh: "ผู้จัดการโรงงานฝ่ายผลิต (Plant Production Director)", badge: "Lv.4", division: "executive", departmentTh: "คณะผู้บริหารสายโรงงาน", dutyTh: "บริหารกำลังการผลิตทุกอาคารและมาตรฐานอุตสาหกรรม", minTasks: 15, minSkill: 64, minTenureDays: 10, wageBonus: 13500, mentorPower: 0.38 }
    ],
    inspector: [
      { level: 1, titleTh: "เจ้าหน้าที่ตรวจสอบคุณภาพ (QC Line Inspector)", badge: "Lv.1", division: "factory", departmentTh: "ฝ่ายควบคุมและประกันคุณภาพ", dutyTh: "ตรวจสอบคุณภาพชิ้นงานหน้าไลน์และคัดแยกของเสีย", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "ผู้ตรวจสอบมาตรฐานคุณภาพอาวุโส (Sr. QA Auditor)", badge: "Lv.2", division: "factory", departmentTh: "ฝ่ายควบคุมและประกันคุณภาพ", dutyTh: "ตรวจรับรองมาตรฐานสินค้าและตรวจวัตถุดิบ IQC", minTasks: 3, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.14 },
      { level: 3, titleTh: "หัวหน้าฝ่ายควบคุมคุณภาพ (QC/QA Supervisor)", badge: "Lv.3", division: "factory", departmentTh: "ฝ่ายควบคุมและประกันคุณภาพ", dutyTh: "กำกับดูแลมาตรฐาน Zero-Defect และประเมินทีม QC", minTasks: 8, minSkill: 56, minTenureDays: 5, wageBonus: 7500, mentorPower: 0.26 },
      { level: 4, titleTh: "ผู้อำนวยการฝ่ายประกันคุณภาพ (Quality Assurance Director)", badge: "Lv.4", division: "executive", departmentTh: "คณะผู้บริหารสายคุณภาพ", dutyTh: "รับรองมาตรฐานส่งออกระดับสากลของเครือบริษัท", minTasks: 15, minSkill: 64, minTenureDays: 10, wageBonus: 13500, mentorPower: 0.38 }
    ],
    logistics: [
      { level: 1, titleTh: "เจ้าหน้าที่คลังสินค้าและแพ็กกิ้ง (Warehouse & Packing Staff)", badge: "Lv.1", division: "factory", departmentTh: "ฝ่ายคลังสินค้าและโลจิสติกส์", dutyTh: "รับวัตถุดิบเข้าคลังและแพ็กสินค้าลงหีบห่อ", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0 },
      { level: 2, titleTh: "เจ้าหน้าที่ควบคุมสต็อกและจัดส่งอาวุโส (Sr. Dispatch Specialist)", badge: "Lv.2", division: "factory", departmentTh: "ฝ่ายคลังสินค้าและโลจิสติกส์", dutyTh: "บริหารคิวรถขนส่งขาออกและควบคุมคลังสินค้าสำเร็จรูป", minTasks: 3, minSkill: 48, minTenureDays: 2, wageBonus: 3500, mentorPower: 0.12 },
      { level: 3, titleTh: "ผู้จัดการคลังสินค้าและฟลีทขนส่ง (Warehouse & Fleet Manager)", badge: "Lv.3", division: "factory", departmentTh: "ฝ่ายคลังสินค้าและโลจิสติกส์", dutyTh: "บริหารขบวนรถบรรทุกส่งออกและประเมินทีมโลจิสติกส์", minTasks: 7, minSkill: 56, minTenureDays: 5, wageBonus: 7000, mentorPower: 0.24 },
      { level: 4, titleTh: "ผู้อำนวยการศูนย์กระจายสินค้าและโลจิสติกส์ (Logistics Director)", badge: "Lv.4", division: "executive", departmentTh: "คณะผู้บริหารสายโลจิสติกส์", dutyTh: "บริหารเครือข่ายซัพพลายเชนและศูนย์กระจายสินค้าทั่วประเทศ", minTasks: 14, minSkill: 64, minTenureDays: 10, wageBonus: 13000, mentorPower: 0.35 }
    ],
    coordinator: [
      { level: 1, titleTh: "เจ้าหน้าที่บริหารงานทั่วไปและบุคคล (HR & Admin Coordinator)", badge: "Lv.1", division: "executive", departmentTh: "สำนักบริหารและทรัพยากรบุคคล", dutyTh: "ประสานงานระหว่างออฟฟิศกับโรงงานและดูแลสวัสดิการ", minTasks: 0, minSkill: 0, minTenureDays: 0, wageBonus: 0, mentorPower: 0.08 },
      { level: 2, titleTh: "ผู้จัดการฝ่ายบุคคลและปฏิบัติการ (HR & Operations Manager)", badge: "Lv.2", division: "executive", departmentTh: "สำนักบริหารและทรัพยากรบุคคล", dutyTh: "สรรหาบุคลากร ประเมินความพึงพอใจ และบริหารงานบุคคล", minTasks: 2, minSkill: 50, minTenureDays: 2, wageBonus: 4500, mentorPower: 0.18 },
      { level: 3, titleTh: "ผู้อำนวยการฝ่ายปฏิบัติการ (Chief Operating Officer - COO)", badge: "Lv.3", division: "executive", departmentTh: "สำนักประธานบริหาร", dutyTh: "กำกับดูแลทุกแผนกและบริหารการขยายตัวของนิคม", minTasks: 6, minSkill: 58, minTenureDays: 5, wageBonus: 9500, mentorPower: 0.3 },
      { level: 4, titleTh: "ประธานเจ้าหน้าที่บริหาร (Chief Executive Officer - CEO)", badge: "Lv.4", division: "executive", departmentTh: "สำนักประธานบริหารสูงสุด", dutyTh: "ผู้นำสูงสุดขององค์กร กำหนดวิสัยทัศน์ การลงทุน และอนุมัติตำแหน่งบริหาร", minTasks: 12, minSkill: 66, minTenureDays: 10, wageBonus: 16000, mentorPower: 0.42 }
    ]
  });

  // Constructible Industrial Estate Expansion Plots (รองรับการก่อสร้างคลัง ไลน์การผลิต และอาคารใหม่ในอนาคต)
  const EXPANSION_PLOTS = deepFreeze({
    rawDepot: {
      id: "rawDepot",
      nameTh: "คลังวัตถุดิบต้นน้ำและท่าตรวจรับ IQC",
      shortNameTh: "คลังวัตถุดิบ (Raw Depot)",
      subtitleTh: "ไซโลเก็บวัตถุดิบ • ท่าเทียบรถซัพพลายเออร์ • ตรวจรับ IQC",
      icon: "🏗️",
      category: "logistics",
      cost: 1800000,
      minDay: 4,
      minStaff: 6,
      footprint: { x: 17, y: 15, width: 4, height: 5 },
      doorCell: { x: 19, y: 20 },
      benefitTh: "เพิ่มสถานีจัดซื้อ/รับของความจุสูง เร่งความเร็วออกใบ PO และรับวัตถุดิบ +20%",
      stations: [
        { id: "admin_depot", kind: "admin", x: 18, y: 17, ax: 18, ay: 18, capacity: 10 },
        { id: "receiving_depot", kind: "receiving", x: 20, y: 18, ax: 20, ay: 19, capacity: 10 }
      ]
    },
    prodLineB: {
      id: "prodLineB",
      nameTh: "อาคารสายการผลิตที่ 2 (Smart Line B)",
      shortNameTh: "ไลน์ผลิต 2 (Line B)",
      subtitleTh: "สายพานประกอบอัจฉริยะ • แท่นตรวจ QC ประจำไลน์ B",
      icon: "⚙️",
      category: "production",
      cost: 2400000,
      minDay: 5,
      minStaff: 9,
      footprint: { x: 34, y: 2, width: 5, height: 9 },
      doorCell: { x: 36, y: 11 },
      benefitTh: "เปิดสายการผลิตที่ 2 เพิ่มความจุช่างประกอบ +24 คน และผู้ตรวจ QC +10 คน เร่งความเร็วผลิต +15%",
      stations: [
        { id: "assembly_b1", kind: "assembly", x: 35, y: 4, ax: 35, ay: 5, capacity: 12 },
        { id: "assembly_b2", kind: "assembly", x: 37, y: 4, ax: 37, ay: 5, capacity: 12 },
        { id: "quality_b1", kind: "quality", x: 36, y: 8, ax: 36, ay: 9, capacity: 10 }
      ]
    },
    dispatchHub: {
      id: "dispatchHub",
      nameTh: "ศูนย์กระจายสินค้าและท่าปล่อยรถส่งออก",
      shortNameTh: "ศูนย์ส่งออก (Dispatch Hub)",
      subtitleTh: "สายพานแพ็กกิ้งอัตโนมัติ • ท่าปล่อยรถบรรทุกส่งออก B2B",
      icon: "🚛",
      category: "logistics",
      cost: 2000000,
      minDay: 6,
      minStaff: 10,
      footprint: { x: 33, y: 18, width: 6, height: 4 },
      doorCell: { x: 35, y: 22 },
      benefitTh: "เพิ่มสถานีแพ็กและท่าปล่อยรถความจุสูง เร่งความเร็วแพ็กและส่งออก +25% พร้อมเพิ่มฟลีทรถขนส่ง",
      stations: [
        { id: "packing_hub", kind: "packing", x: 34, y: 19, ax: 34, ay: 20, capacity: 18 },
        { id: "shipping_hub", kind: "shipping", x: 37, y: 19, ax: 37, ay: 20, capacity: 16 }
      ]
    },
    execAnnex: {
      id: "execAnnex",
      nameTh: "ศูนย์พาณิชย์และห้องเจรจาธุรกิจ B2B",
      shortNameTh: "ศูนย์การค้า B2B (Trade Center)",
      subtitleTh: "ห้องรับรองคู่ค้า • ทีมขายองค์กร • ฝ่ายการเงินและนักลงทุนสัมพันธ์",
      icon: "🏛️",
      category: "office",
      cost: 1600000,
      minDay: 5,
      minStaff: 8,
      footprint: { x: 10, y: 2, width: 3, height: 5 },
      doorCell: { x: 11, y: 7 },
      benefitTh: "เพิ่มสถานีฝ่ายขายและบัญชี B2B ความจุสูง เพิ่มอำนาจต่อรองราคาขายกับลูกค้า +6%",
      stations: [
        { id: "sales_annex", kind: "sales", x: 11, y: 4, ax: 11, ay: 5, capacity: 14 },
        { id: "admin_annex", kind: "admin", x: 12, y: 8, ax: 12, ay: 9, capacity: 14 }
      ]
    },
    maintWorkshop: {
      id: "maintWorkshop",
      nameTh: "โรงซ่อมบำรุงเครื่องกลและวิศวกรรม",
      shortNameTh: "โรงซ่อมบำรุง (Maintenance)",
      subtitleTh: "ศูนย์ซ่อมบำรุงเชิงป้องกัน • ห้องสอบเทียบเครื่องมือวัด",
      icon: "🛠️",
      category: "engineering",
      cost: 1500000,
      minDay: 6,
      minStaff: 8,
      footprint: { x: 17, y: 11, width: 4, height: 3 },
      doorCell: { x: 19, y: 14 },
      benefitTh: "ลดอัตราการสึกหรอของเครื่องจักรโรงงานลง 35% และเพิ่มสถานีวิศวกรรมซ่อมบำรุง",
      stations: [
        { id: "research_maint", kind: "research", x: 19, y: 12, ax: 19, ay: 13, capacity: 10 }
      ]
    },
    prodLineC: {
      id: "prodLineC",
      nameTh: "อาคารสายการผลิตอัตโนมัติที่ 3 (Mega Line C)",
      shortNameTh: "ไลน์ผลิต 3 (Mega Line C)",
      subtitleTh: "โรงงานระบบอัตโนมัติความจุสูง • รองรับพนักงานระดับ 200-500 คน",
      icon: "🤖",
      category: "production",
      cost: 3500000,
      minDay: 8,
      minStaff: 16,
      footprint: { x: 17, y: 2, width: 4, height: 8 },
      doorCell: { x: 19, y: 10 },
      benefitTh: "เปิดสายการผลิตขนาดใหญ่ เพิ่มความจุช่างประกอบ +60 คน และ QC +25 คน เร่งความเร็วผลิต +20%",
      stations: [
        { id: "assembly_c1", kind: "assembly", x: 18, y: 4, ax: 18, ay: 5, capacity: 30 },
        { id: "assembly_c2", kind: "assembly", x: 20, y: 4, ax: 20, ay: 5, capacity: 30 },
        { id: "quality_c1", kind: "quality", x: 19, y: 8, ax: 19, ay: 9, capacity: 25 }
      ]
    },
    solarPlant: {
      id: "solarPlant",
      nameTh: "สถานีพลังงานแสงอาทิตย์และหม้อแปลงนิคม",
      shortNameTh: "โซลาร์ฟาร์ม (Solar Grid)",
      subtitleTh: "ผลิตไฟฟ้าสะอาดใช้ในนิคม • ลดค่าโสหุ้ยรายวัน • เพิ่มคะแนน ESG",
      icon: "☀️",
      category: "utility",
      cost: 2200000,
      minDay: 7,
      minStaff: 10,
      footprint: { x: 9, y: 8, width: 3, height: 3 },
      doorCell: { x: 10, y: 11 },
      benefitTh: "ลดภาระค่าเช่าและสาธารณูปโภครายวันลง 20% และเพิ่มโบนัสชื่อเสียงบริษัทสีเขียว",
      stations: []
    },
    dormitory: {
      id: "dormitory",
      nameTh: "หอพักพนักงานและลานจอดรถนิคม",
      shortNameTh: "หอพัก/ลานจอดรถ (Dorm & Park)",
      subtitleTh: "ที่พักสวัสดิการพนักงาน • ลานจอดรถมอเตอร์ไซค์และรถยนต์ส่วนตัว",
      icon: "🏘️",
      category: "welfare",
      cost: 1400000,
      minDay: 5,
      minStaff: 8,
      footprint: { x: 5, y: 17, width: 6, height: 5 },
      doorCell: { x: 8, y: 22 },
      benefitTh: "เพิ่มความจุจุดพักผ่อนและโรงอาหารรองรับพนักงานระดับร้อยคน พร้อมฟื้นฟูกำลังใจรายวัน",
      stations: [
        { id: "lounge_dorm", kind: "lounge", x: 7, y: 19, ax: 7, ay: 20, capacity: 45 },
        { id: "meal_dorm", kind: "meal", x: 9, y: 19, ax: 9, ay: 20, capacity: 45 }
      ]
    }
  });

  // External World & Macro-Economic Simulation Blueprint (คู่ค้า B2B, ซัพพลายเออร์, คู่แข่ง, รัฐบาล, ตลาดหุ้น)
  const EXTERNAL_WORLD_DEFAULTS = deepFreeze({
    clients: [
      { id: "siam_tech", nameTh: "บมจ. สยามเทค โฮลดิ้งส์", sector: "tech", tierTh: "องค์กรมหาชน (SET100)", baseTrust: 55, pricePremium: 0.04, paymentDays: 1, preferredProducts: ["speaker", "lamp", "iotController", "smartMeter"] },
      { id: "asia_autoparts", nameTh: "บจก. เอเชีย ออโต้พาร์ท แอนด์ อีวี", sector: "automotive", tierTh: "ผู้ผลิตยานยนต์ OEM", baseTrust: 52, pricePremium: 0.06, paymentDays: 1, preferredProducts: ["autoSensor", "evController", "batteryPack"] },
      { id: "cp_health", nameTh: "บมจ. เจริญผล ฟู้ดแอนด์เฮลท์", sector: "food", tierTh: "เครือค้าปลีกและสุขภาพ", baseTrust: 56, pricePremium: 0.03, paymentDays: 0, preferredProducts: ["herbalDrink", "energyProtein", "functionalShot"] },
      { id: "green_power", nameTh: "บจก. กรีนพาวเวอร์ โซลูชั่นส์ เอเชีย", sector: "energy", tierTh: "พันธมิตรพลังงานสะอาด BOI", baseTrust: 50, pricePremium: 0.07, paymentDays: 1, preferredProducts: ["solarCharger", "homeInverter", "batteryPack"] },
      { id: "tokyo_elec", nameTh: "บจก. โตเกียว อิเล็กทรอนิกส์ (ประเทศไทย)", sector: "tech", tierTh: "คู่ค้าส่งออกญี่ปุ่น", baseTrust: 60, pricePremium: 0.08, paymentDays: 1, preferredProducts: ["iotController", "autoSensor", "smartMeter", "lamp"] },
      { id: "metro_retail", nameTh: "บมจ. นครหลวง ดิสทริบิวชั่น", sector: "general", tierTh: "ศูนย์ค้าส่งทั่วประเทศ", baseTrust: 48, pricePremium: 0.02, paymentDays: 0, preferredProducts: ["speaker", "lamp", "herbalDrink", "solarCharger"] }
    ],
    suppliers: [
      { id: "shenzhen_semi", nameTh: "บจก. เซินเจิ้น เซมิคอนดักเตอร์ ซัพพลาย", originTh: "เซินเจิ้น / ท่าเรือแหลมฉบัง", specialtyTh: "แผงวงจร ชิป และเซนเซอร์", materials: ["pcb", "microchip", "led", "sensor", "heat_sink"], baseTrust: 50, creditTermsTh: "COD / Net 7" },
      { id: "siam_metal", nameTh: "บจก. สยามเมทัล แอนด์ ฮาร์เนส อินดัสทรี", originTh: "นิคมอมตะซิตี้ ชลบุรี", specialtyTh: "แผ่นโลหะ ตัวถัง และชุดสายไฟ", materials: ["casing", "driver", "metal_sheet", "wire_harness", "heat_sink"], baseTrust: 55, creditTermsTh: "Net 7" },
      { id: "thai_organic", nameTh: "สหกรณ์เกษตรอินทรีย์และสารสกัดไทย", originTh: "นครปฐม / เชียงใหม่", specialtyTh: "สารสกัดธรรมชาติและบรรจุภัณฑ์อาหาร", materials: ["raw_extract", "glass_bottle", "pack_carton"], baseTrust: 58, creditTermsTh: "COD / Net 7" },
      { id: "pacific_solar", nameTh: "บจก. แปซิฟิก โซลาร์ แอนด์ ลิเธียม เพาเวอร์", originTh: "นิคมอีสเทิร์นซีบอร์ด ระยอง", specialtyTh: "แผงโซลาร์เซลล์และแบตเตอรี่ลิเธียม", materials: ["solar_cell", "battery"], baseTrust: 48, creditTermsTh: "Net 14" }
    ],
    competitors: [
      { id: "titan_elec", nameTh: "บมจ. ไททัน อิเล็กทรอนิกส์", sector: "tech", sectorTh: "อิเล็กทรอนิกส์และสมาร์ตเทค", marketSharePct: 24.5, strength: 68, strategyTh: "เน้นกำลังการผลิตขนาดใหญ่และตัดราคา" },
      { id: "eastern_auto", nameTh: "บจก. อีสเทิร์น ออโต้เทค", sector: "automotive", sectorTh: "ชิ้นส่วนยานยนต์และ EV", marketSharePct: 21.0, strength: 64, strategyTh: "เน้นมาตรฐาน QC เข้มงวดและสัญญาระยะยาว" },
      { id: "siam_naturals", nameTh: "บมจ. สยามเนเชอรัล ฟู้ดส์", sector: "food", sectorTh: "อาหารและเครื่องดื่มสุขภาพ", marketSharePct: 19.5, strength: 58, strategyTh: "เน้นกระจายสินค้าไวและออกสินค้าใหม่ต่อเนื่อง" },
      { id: "solartech_asia", nameTh: "บจก. โซลาร์เทค เอเชีย", sector: "energy", sectorTh: "พลังงานสะอาดและโซลาร์", marketSharePct: 18.0, strength: 62, strategyTh: "เน้นนวัตกรรม R&D และสิทธิประโยชน์ BOI" },
      { id: "apex_ind", nameTh: "บมจ. เอเพ็กซ์ อินดัสเตรียล กรุ๊ป", sector: "multi", sectorTh: "กลุ่มอุตสาหกรรมครบวงจร", marketSharePct: 15.0, strength: 74, strategyTh: "เน้นดึงตัวช่างฝีมือและแย่งประมูลดีล B2B" }
    ],
    governmentPolicies: [
      { id: "boi_smart_industry", nameTh: "บัตรส่งเสริมการลงทุน BOI อุตสาหกรรมเป้าหมาย", summaryTh: "ลดภาระภาษีนิติบุคคลและหนุนการวิจัย R&D อุตสาหกรรมอัจฉริยะ (+แต้มวิจัยไวขึ้น)", corporateTaxPct: 10, demandMultiplier: 1.08, greenBonus: 0 },
      { id: "export_stimulus", nameTh: "มาตรการกระตุ้นการส่งออกและโลจิสติกส์ EEC", summaryTh: "บริษัทคู่ค้า B2B สั่งซื้อล็อตใหญ่ขึ้นและจ่ายชำระเงินเร็วขึ้น", corporateTaxPct: 15, demandMultiplier: 1.15, greenBonus: 0 },
      { id: "green_esg_subsidy", nameTh: "มาตรการสนับสนุนโรงงานสีเขียวและพลังงานสะอาด (ESG)", summaryTh: "อุดหนุนสินค้ากลุ่มพลังงานสะอาด/เกษตรอินทรีย์ และเพิ่มชื่อเสียงองค์กรรักษ์โลก", corporateTaxPct: 12, demandMultiplier: 1.1, greenBonus: 2 },
      { id: "labor_welfare_push", nameTh: "นโยบายยกระดับคุณภาพชีวิตและทักษะแรงงานอุตสาหกรรม", summaryTh: "ส่งเสริมการฝึกอบรมทักษะในศูนย์ฝึกและเพิ่มขวัญกำลังใจพนักงานเมื่อมีสวัสดิการ", corporateTaxPct: 15, demandMultiplier: 1.04, greenBonus: 0 },
      { id: "industrial_stability", nameTh: "นโยบายรักษาเสถียรภาพเศรษฐกิจและซัพพลายเชน", summaryTh: "ตรึงราคาวัตถุดิบต้นน้ำและส่งเสริมสินเชื่อดอกเบี้ยต่ำสำหรับโรงงาน", corporateTaxPct: 15, demandMultiplier: 1.05, greenBonus: 0 }
    ],
    stockIndices: [
      { id: "SET_IND", symbol: "SET-IND", nameTh: "ดัชนีอุตสาหกรรมรวม (Siam Industrial Index)", baseValue: 1420.0 },
      { id: "TECH", symbol: "SIAM-TECH", nameTh: "กลุ่มชิ้นส่วนอิเล็กทรอนิกส์และ IoT", baseValue: 860.0 },
      { id: "AUTO", symbol: "SIAM-AUTO", nameTh: "กลุ่มชิ้นส่วนยานยนต์และ EV", baseValue: 740.0 },
      { id: "FOOD", symbol: "SIAM-AGRO", nameTh: "กลุ่มเกษตรแปรรูปและอาหารสุขภาพ", baseValue: 690.0 },
      { id: "GREEN", symbol: "SIAM-ESG", nameTh: "กลุ่มพลังงานสะอาดและเทคโนโลยีสีเขียว", baseValue: 910.0 }
    ],
    ceoDirectives: [
      { id: "sales_blitz", nameTh: "ลุยยอดขายและขยายฐานคู่ค้า B2B (Commercial Blitz)", descTh: "เน้นเจรจาปิดดีล B2B ราคาดีและเร่งส่งมอบออเดอร์ลูกค้า" },
      { id: "cash_shield", nameTh: "รัดเข็มขัดรักษาสภาพคล่อง (Cash Runway Shield)", descTh: "สำรองกระแสเงินสด สั่งวัตถุดิบแบบ Just-in-Time และเร่งเก็บเงิน Invoice" },
      { id: "zero_defect", nameTh: "มาตรฐานช่างฝีมือไร้ของเสีย (Zero-Defect Quality)", descTh: "เน้นความประณีตในสายการผลิตและการตรวจ QC ลดอัตราของเสีย" },
      { id: "wellness_care", nameTh: "ดูแลบุคลากรและสร้างขวัญกำลังใจ (People & Retention)", descTh: "ป้องกันภาวะหมดไฟ สนับสนุนการพักผ่อนและรั้งตัวคนเก่ง" },
      { id: "rnd_sprint", nameTh: "เร่งเครื่องวิจัยและแตกไลน์อุตสาหกรรม (R&D Innovation Sprint)", descTh: "ทุ่มทรัพยากรวิจัยแบบแปลนสินค้าใหม่ที่มีอัตรากำไรสูง" },
      { id: "scale_expansion", nameTh: "ขยายอาณาจักรนิคมและกำลังการผลิต (Industrial Scale-Up)", descTh: "ลงทุนก่อสร้างอาคารใหม่ ขยายไลน์การผลิต และรับพนักงานเพิ่มรองรับออเดอร์ใหญ่" }
    ]
  });

  const MOTIVE_FACTOR_LABELS = deepFreeze({
    effort: "ความทุ่มเทและแรงกายที่ใช้",
    delay: "ความเร่งด่วนของงานที่ค้าง",
    skillFit: "ความถนัดตรงสายงาน",
    change: "ความท้าทายและการปรับเปลี่ยน",
    risk: "การบริหารความเสี่ยง",
    hunger: "การเติมพลังด้วยมื้ออาหาร",
    social: "การพูดคุยและเชื่อมสัมพันธ์กับทีม",
    voice: "การสะท้อนปัญหาและออกความเห็น",
    craft: "ความประณีตและการสร้างผลงานด้วยฝีมือ",
    duty: "ความรับผิดชอบต่อหน้าที่และออเดอร์",
    routine: "ความคุ้นเคยและระเบียบแบบแผน",
    help: "การช่วยเหลือเกื้อกูลเพื่อนร่วมทีม",
    novelty: "การคิดค้นและเรียนรู้สิ่งใหม่",
    energy: "การฟื้นฟูพลังงานร่างกาย",
    stress: "การผ่อนคลายความเครียดสะสม",
    health: "การดูแลสุขภาพร่างกาย",
    burnout: "การป้องกันภาวะหมดไฟ",
    focus: "สมาธิและความต่อเนื่องในการทำงาน",
    mood: "อารมณ์และขวัญกำลังใจ",
    achievement: "คุณค่าความสำเร็จในงาน",
    security: "คุณค่าความมั่นคงปลอดภัย",
    income: "คุณค่ารายได้และผลตอบแทน",
    autonomy: "คุณค่าความเป็นอิสระในการทำงาน",
    fairness: "คุณค่าความเป็นธรรมในองค์กร",
    belonging: "คุณค่าการเป็นส่วนหนึ่งของทีม",
    learning: "คุณค่าการเรียนรู้และพัฒนาตน",
    meaning: "คุณค่าความหมายของงานที่ทำ",
    workLifeBalance: "คุณค่าสมดุลชีวิตและการพักผ่อน",
    recognition: "คุณค่าการได้รับการยอมรับและเกียรติภูมิ",
    family: "คุณค่าการดูแลครอบครัว",
    comfort: "คุณค่าคุณภาพชีวิตและความเป็นอยู่",
    humility: "ความถ่อมตน",
    optimism: "การมองโลกในแง่บวก",
    care: "ความเอื้ออาทรต่อผู้อื่น",
    stewardship: "ความรับผิดชอบต่อส่วนรวม",
    influence: "การมีบทบาทกำหนดทิศทาง",
    tradition: "การเคารพธรรมเนียมปฏิบัติ",
    variety: "ความหลากหลายของประสบการณ์",
    craftsmanship: "คุณค่าของฝีมือและความประณีต",
    sociability: "นิสัยชอบเข้าสังคม",
    conscientiousness: "นิสัยรับผิดชอบและมีวินัย",
    agreeableness: "นิสัยให้ความร่วมมือ",
    openness: "นิสัยเปิดรับสิ่งใหม่",
    riskTaking: "นิสัยกล้าตัดสินใจเสี่ยง",
    stressReactivity: "ความไวต่อความกดดัน",
    assertiveness: "ความกล้าแสดงออก",
    patience: "ความอดทนและใจเย็น",
    integrity: "ความซื่อสัตย์สุจริต",
    adaptability: "ความยืดหยุ่นในการปรับตัว",
    ambition: "แรงผลักดันและความทะเยอทะยาน",
    prudence: "ความรอบคอบก่อนลงมือ"
  });

  function hashStr(str) {
    let h = 2166136261 >>> 0;
    const s = String(str || "");
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function pickDet(arr, seedStr) {
    if (!arr || !arr.length) return "";
    return arr[hashStr(seedStr) % arr.length];
  }

  function getCareerStep(roleId, level) {
    const ladder = CAREER_LADDERS[roleId] || CAREER_LADDERS.assembler;
    const lv = Math.max(1, Math.min(ladder.length, Number(level) || 1));
    return ladder[lv - 1] || ladder[0];
  }

  function getNextCareerStep(roleId, level) {
    const ladder = CAREER_LADDERS[roleId] || CAREER_LADDERS.assembler;
    const lv = Math.max(1, Number(level) || 1);
    return lv < ladder.length ? ladder[lv] : null;
  }

  function createIdentity(seed, personId, baseName, roleId = "assembler") {
    const pid = String(personId || "employee-1");
    const preset = STARTER_IDENTITIES[pid];
    if (preset) {
      const nat = NATIONALITIES[preset.nationality] || NATIONALITIES.TH;
      const genderSymbol = preset.gender === "F" ? "♀" : "♂";
      const genderTh = preset.gender === "F" ? "หญิง" : "ชาย";
      const nickname = baseName || pid;
      const fullName = `${preset.firstName} ${preset.lastName}`;
      return {
        nationality: nat.id,
        nationalityTh: nat.nameTh,
        flag: nat.flag,
        codeTh: nat.codeTh,
        gender: preset.gender,
        genderTh,
        genderSymbol,
        age: preset.age,
        firstName: preset.firstName,
        lastName: preset.lastName,
        nickname,
        fullName,
        displayName: `${fullName} (${nickname})`,
        educationTh: preset.educationTh,
        hometownTh: preset.hometownTh
      };
    }

    const key = `${seed}:${pid}:${roleId}`;
    const h1 = hashStr(key + ":nat");
    const natOrder = ["TH", "JP", "CN", "VN", "MM", "EN"];
    let acc = 0;
    const roll = (h1 % 1000) / 1000;
    let chosenNatId = "TH";
    for (const nid of natOrder) {
      const w = (NATIONALITIES[nid].roleWeight && NATIONALITIES[nid].roleWeight[roleId]) || 0.05;
      acc += w;
      if (roll <= acc) {
        chosenNatId = nid;
        break;
      }
    }
    const nat = NATIONALITIES[chosenNatId] || NATIONALITIES.TH;
    const pool = NAME_POOLS[chosenNatId] || NAME_POOLS.TH;
    const gender = hashStr(key + ":gender") % 2 === 0 ? "M" : "F";
    const genderTh = gender === "F" ? "หญิง" : "ชาย";
    const genderSymbol = gender === "F" ? "♀" : "♂";
    const baseAgeMin = roleId === "engineer" || roleId === "coordinator" ? 25 : 21;
    const age = baseAgeMin + (hashStr(key + ":age") % 19);
    const firstName = pickDet(gender === "F" ? pool.femaleFirst : pool.maleFirst, key + ":first");
    const lastName = pickDet(pool.surnames, key + ":last");
    const nickname = baseName || pickDet(gender === "F" ? pool.nicknamesFemale : pool.nicknamesMale, key + ":nick");
    const fullName = `${firstName} ${lastName}`;
    return {
      nationality: nat.id,
      nationalityTh: nat.nameTh,
      flag: nat.flag,
      codeTh: nat.codeTh,
      gender,
      genderTh,
      genderSymbol,
      age,
      firstName,
      lastName,
      nickname,
      fullName,
      displayName: `${fullName} (${nickname})`,
      educationTh: pickDet(nat.educations, key + ":edu"),
      hometownTh: pickDet(nat.hometowns, key + ":home")
    };
  }

  function translateMotiveFactor(factor, extraLabels = {}) {
    const raw = String(factor || "").trim();
    if (!raw) return "ความเหมาะสมตามสถานการณ์";
    if (MOTIVE_FACTOR_LABELS[raw]) return MOTIVE_FACTOR_LABELS[raw];
    if (extraLabels && extraLabels[raw]) return extraLabels[raw];

    const parts = raw.split(":");
    const prefix = parts.length > 1 ? parts[0] : "";
    const key = parts.length > 1 ? parts.slice(1).join(":") : raw;

    if (MOTIVE_FACTOR_LABELS[key]) return MOTIVE_FACTOR_LABELS[key];
    if (extraLabels && extraLabels[key]) {
      return prefix === "value" ? `คุณค่า${extraLabels[key]}` : extraLabels[key];
    }
    return "ดุลยพินิจตามความเหมาะสมของงาน";
  }

  const INDUSTRY_SKILL_TEMPLATES = deepFreeze({
    software: {
      id: "software",
      nameTh: "วิศวกรรมซอฟต์แวร์และระบบ",
      aptitudes: {
        analytical: 0.45,
        memory: 0.2,
        learningSpeed: 0.2,
        precision: 0.15,
      },
    },
    construction: {
      id: "construction",
      nameTh: "งานก่อสร้างและโครงสร้าง",
      aptitudes: {
        strength: 0.35,
        stamina: 0.3,
        spatial: 0.2,
        dexterity: 0.15,
      },
    },
    architecture: {
      id: "architecture",
      nameTh: "สถาปัตยกรรมและผังโครงสร้าง",
      aptitudes: {
        spatial: 0.4,
        creativity: 0.3,
        analytical: 0.2,
        precision: 0.1,
      },
    },
    driving: {
      id: "driving",
      nameTh: "การขับขี่และควบคุมยานพาหนะ",
      aptitudes: {
        spatial: 0.35,
        composure: 0.25,
        sensory: 0.2,
        dexterity: 0.2,
      },
    },
    design: {
      id: "design",
      nameTh: "การออกแบบและสุนทรียศาสตร์",
      aptitudes: {
        creativity: 0.45,
        sensory: 0.3,
        spatial: 0.15,
        emotionalInsight: 0.1,
      },
    },
    customerCare: {
      id: "customerCare",
      nameTh: "บริการและดูแลลูกค้า",
      aptitudes: {
        emotionalInsight: 0.4,
        communication: 0.35,
        composure: 0.25,
      },
    },
    aerospaceEngineering: {
      id: "aerospaceEngineering",
      nameTh: "วิศวกรรมอวกาศ",
      aptitudes: {
        analytical: 0.25,
        numerical: 0.2,
        spatial: 0.2,
        problemSensitivity: 0.15,
        precision: 0.2,
      },
    },
    missionControl: {
      id: "missionControl",
      nameTh: "ควบคุมภารกิจและระบบวิกฤต",
      aptitudes: {
        attention: 0.25,
        uncertaintyReasoning: 0.25,
        composure: 0.2,
        communication: 0.15,
        problemSensitivity: 0.15,
      },
    },
    automotiveEngineering: {
      id: "automotiveEngineering",
      nameTh: "ออกแบบระบบยานยนต์",
      aptitudes: {
        analytical: 0.3,
        spatial: 0.25,
        numerical: 0.2,
        creativity: 0.15,
        precision: 0.1,
      },
    },
    vehicleMaintenance: {
      id: "vehicleMaintenance",
      nameTh: "วิเคราะห์และซ่อมยานยนต์",
      aptitudes: {
        problemSensitivity: 0.25,
        dexterity: 0.25,
        hearing: 0.15,
        visualAcuity: 0.15,
        analytical: 0.2,
      },
    },
    financialAnalysis: {
      id: "financialAnalysis",
      nameTh: "วิเคราะห์การเงินและการลงทุน",
      aptitudes: {
        numerical: 0.35,
        uncertaintyReasoning: 0.3,
        analytical: 0.2,
        verbal: 0.15,
      },
    },
    riskManagement: {
      id: "riskManagement",
      nameTh: "บริหารความเสี่ยง",
      aptitudes: {
        uncertaintyReasoning: 0.35,
        problemSensitivity: 0.25,
        numerical: 0.2,
        composure: 0.2,
      },
    },
    animalHusbandry: {
      id: "animalHusbandry",
      nameTh: "ดูแลและสังเกตพฤติกรรมสัตว์",
      aptitudes: {
        attention: 0.2,
        emotionalInsight: 0.2,
        problemSensitivity: 0.2,
        dexterity: 0.15,
        sensory: 0.15,
        stamina: 0.1,
      },
    },
    veterinaryCare: {
      id: "veterinaryCare",
      nameTh: "ความรู้และหัตถการสัตวแพทย์",
      aptitudes: {
        analytical: 0.2,
        memory: 0.2,
        dexterity: 0.2,
        precision: 0.2,
        problemSensitivity: 0.2,
      },
    },
    foodPreparation: {
      id: "foodPreparation",
      nameTh: "ประกอบอาหารและควบคุมรสชาติ",
      aptitudes: {
        tasteSmell: 0.25,
        dexterity: 0.2,
        organization: 0.15,
        creativity: 0.15,
        colorDiscrimination: 0.1,
        coordination: 0.15,
      },
    },
    foodSafety: {
      id: "foodSafety",
      nameTh: "สุขอนามัยและความปลอดภัยอาหาร",
      aptitudes: {
        problemSensitivity: 0.25,
        precision: 0.25,
        attention: 0.2,
        memory: 0.15,
        sensory: 0.15,
      },
    },
    structuralEngineering: {
      id: "structuralEngineering",
      nameTh: "วิศวกรรมโครงสร้าง",
      aptitudes: {
        numerical: 0.25,
        spatial: 0.25,
        analytical: 0.3,
        problemSensitivity: 0.2,
      },
    },
    heavyEquipment: {
      id: "heavyEquipment",
      nameTh: "ควบคุมเครื่องจักรหนัก",
      aptitudes: {
        controlPrecision: 0.3,
        reactionSpeed: 0.2,
        spatial: 0.2,
        coordination: 0.15,
        attention: 0.15,
      },
    },
    fieldConstruction: {
      id: "fieldConstruction",
      nameTh: "งานก่อสร้างภาคสนาม",
      aptitudes: {
        strength: 0.2,
        stamina: 0.2,
        balance: 0.2,
        flexibility: 0.15,
        coordination: 0.15,
        spatial: 0.1,
      },
    },
    medicine: {
      id: "medicine",
      nameTh: "ความรู้และดูแลสุขภาพ",
      aptitudes: {
        analytical: 0.25,
        memory: 0.25,
        problemSensitivity: 0.2,
        emotionalInsight: 0.15,
        precision: 0.15,
      },
    },
    law: {
      id: "law",
      nameTh: "กฎหมายและการให้เหตุผล",
      aptitudes: {
        verbal: 0.35,
        analytical: 0.25,
        memory: 0.2,
        communication: 0.2,
      },
    },
    education: {
      id: "education",
      nameTh: "การสอนและอธิบาย",
      aptitudes: {
        verbal: 0.2,
        communication: 0.25,
        emotionalInsight: 0.25,
        speechClarity: 0.15,
        organization: 0.15,
      },
    },
    agriculture: {
      id: "agriculture",
      nameTh: "เพาะปลูกและดูแลระบบเกษตร",
      aptitudes: {
        problemSensitivity: 0.2,
        organization: 0.2,
        sensory: 0.2,
        stamina: 0.2,
        analytical: 0.2,
      },
    },
    creativeProduction: {
      id: "creativeProduction",
      nameTh: "ผลิตสื่อและศิลปะ",
      aptitudes: {
        creativity: 0.3,
        colorDiscrimination: 0.2,
        hearing: 0.15,
        communication: 0.2,
        sensory: 0.15,
      },
    },
    logisticsPlanning: {
      id: "logisticsPlanning",
      nameTh: "วางแผนโลจิสติกส์",
      aptitudes: {
        organization: 0.3,
        numerical: 0.2,
        spatial: 0.2,
        attention: 0.15,
        perceptualSpeed: 0.15,
      },
    },
    energyOperations: {
      id: "energyOperations",
      nameTh: "ปฏิบัติการพลังงานและระบบสาธารณูปโภค",
      aptitudes: {
        attention: 0.25,
        controlPrecision: 0.2,
        problemSensitivity: 0.2,
        composure: 0.2,
        reactionSpeed: 0.15,
      },
    },
  });

  // Headcount Quota Limits by Career Level & Organizational Hierarchy (Scales from 5 to 500 NPCs)
  const CAREER_QUOTAS = deepFreeze({
    // Lv.1: Operational Staff / Operators (Flexible baseline)
    1: { nameTh: "พนักงานปฏิบัติการระดับต้น (Junior/Staff)", quotaType: "unlimited" },
    // Lv.2: Senior Specialist / Technician (Max 45% of department, min 1 when deptSize >= 2)
    2: { nameTh: "เจ้าหน้าที่/ช่างเทคนิคอาวุโส (Senior/Specialist)", maxRatio: 0.45, minDeptSize: 2 },
    // Lv.3: Department Supervisor / Foreman / Manager (1 per dept, expands with Lv.2+ building or >=4 staff, scales 1 per 6 staff)
    3: { nameTh: "หัวหน้ากะ/ผู้จัดการแผนก (Supervisor/Manager)", baseSlots: 1, expandThreshold: 4, spanOfControl: 6 },
    // Lv.4: Executive Director / VP / C-Level (1 base, expands with >=10 staff & >=15M cash, scales 1 per 20 staff)
    4: { nameTh: "ผู้อำนวยการฝ่าย/ผู้บริหารระดับสูง (Director/Executive)", baseSlots: 1, expandThreshold: 10, spanOfControl: 20 },
  });

  // 5-Person Lean Startup Roster (สำหรับเริ่มตั้งบริษัทขนาดเล็ก 5 คน แล้วค่อยเติบโตสู่ระดับ 100-500 คน)
  const LEAN_STARTERS = deepFreeze([
    { name: "ธีร์", role: "coordinator", dailyWage: 35000 }, // CEO & ผู้ก่อตั้ง
    { name: "มิน", role: "sales", dailyWage: 38000 },        // ฝ่ายขาย B2B (ออฟฟิศ)
    { name: "ภัทร", role: "admin", dailyWage: 35000 },       // ฝ่ายจัดซื้อและบัญชี (ออฟฟิศ)
    { name: "ต้น", role: "assembler", dailyWage: 40000 },    // ช่างฝ่ายผลิต (โรงงาน)
    { name: "กานต์", role: "inspector", dailyWage: 36000 },  // ฝ่าย QC และช่วยงานคลัง (โรงงาน)
  ]);

  const defaults = {
    version: "1.1.0",
    skills: {
      sales: {
        id: "sales",
        nameTh: "การขายและเจรจาธุรกิจ B2B",
        aptitudes: {
          communication: 0.55,
          emotionalInsight: 0.25,
          organization: 0.1,
          composure: 0.1,
        },
      },
      admin: {
        id: "admin",
        nameTh: "จัดซื้อ บัญชี และซัพพลายเชน",
        aptitudes: { organization: 0.5, precision: 0.3, memory: 0.2 },
      },
      engineering: {
        id: "engineering",
        nameTh: "วิศวกรรม วิจัย และซ่อมบำรุง",
        aptitudes: {
          analytical: 0.4,
          creativity: 0.3,
          learningSpeed: 0.2,
          spatial: 0.1,
        },
      },
      assembly: {
        id: "assembly",
        nameTh: "การผลิตและประกอบชิ้นงาน",
        aptitudes: {
          dexterity: 0.45,
          precision: 0.25,
          stamina: 0.2,
          spatial: 0.1,
        },
      },
      quality: {
        id: "quality",
        nameTh: "ควบคุมและประกันคุณภาพ (QC/QA)",
        aptitudes: { precision: 0.5, analytical: 0.3, sensory: 0.2 },
      },
      logistics: {
        id: "logistics",
        nameTh: "คลังสินค้าและโลจิสติกส์ขนส่ง",
        aptitudes: {
          organization: 0.45,
          stamina: 0.25,
          strength: 0.15,
          spatial: 0.15,
        },
      },
      leadership: {
        id: "leadership",
        nameTh: "ภาวะผู้นำและบริหารองค์กร",
        aptitudes: {
          communication: 0.35,
          emotionalInsight: 0.35,
          organization: 0.15,
          composure: 0.15,
        },
      },
    },
    materials: {
      pcb: { id: "pcb", nameTh: "แผงวงจร", unitCost: 9000, leadMinutes: 1440 },
      casing: {
        id: "casing",
        nameTh: "ตัวถัง",
        unitCost: 5000,
        leadMinutes: 720,
      },
      driver: {
        id: "driver",
        nameTh: "ดอกลำโพง",
        unitCost: 6000,
        leadMinutes: 1440,
      },
      led: { id: "led", nameTh: "โมดูลแสง", unitCost: 7500, leadMinutes: 1440 },
      sensor: {
        id: "sensor",
        nameTh: "เซ็นเซอร์",
        unitCost: 6000,
        leadMinutes: 1440,
      },
      metal_sheet: { id: "metal_sheet", nameTh: "แผ่นโลหะขึ้นรูป", unitCost: 7000, leadMinutes: 1440 },
      wire_harness: { id: "wire_harness", nameTh: "ชุดสายไฟแรงดันต่ำ", unitCost: 4500, leadMinutes: 720 },
      microchip: { id: "microchip", nameTh: "ชิปไมโครโพรเซสเซอร์", unitCost: 8500, leadMinutes: 720 },
      raw_extract: { id: "raw_extract", nameTh: "สารสกัดสมุนไพร/ผลไม้ออร์แกนิก", unitCost: 3500, leadMinutes: 720 },
      glass_bottle: { id: "glass_bottle", nameTh: "ขวดแก้วสุญญากาศและฝาเกลียว", unitCost: 2500, leadMinutes: 720 },
      pack_carton: { id: "pack_carton", nameTh: "กล่องบรรจุภัณฑ์มาตรฐานอาหาร", unitCost: 2000, leadMinutes: 720 },
      solar_cell: { id: "solar_cell", nameTh: "แผงโซลาร์เซลล์ประสิทธิภาพสูง", unitCost: 8500, leadMinutes: 1440 },
      battery: { id: "battery", nameTh: "โมดูลแบตเตอรี่ลิเธียมความปลอดภัยสูง", unitCost: 9500, leadMinutes: 1440 },
      heat_sink: { id: "heat_sink", nameTh: "ครีบระบายความร้อนอะลูมิเนียม", unitCost: 4000, leadMinutes: 720 },
    },
    products: {
      speaker: {
        id: "speaker",
        nameTh: "ลำโพงบลูทูธ",
        bom: { pcb: 1, casing: 1, driver: 1 },
        assemblyMinutes: 40,
        qaMinutes: 12,
        packingMinutes: 6,
        priceMin: 75000,
        priceMax: 90000,
        researchRequired: 0,
        visualKey: "product.speaker",
        industry: "tech",
        industryNameTh: "เครื่องใช้ไฟฟ้าและเทคโนโลยี"
      },
      lamp: {
        id: "lamp",
        nameTh: "โคมไฟปรับแสง",
        bom: { pcb: 1, casing: 1, led: 2, sensor: 1 },
        assemblyMinutes: 55,
        qaMinutes: 15,
        packingMinutes: 8,
        priceMin: 120000,
        priceMax: 145000,
        researchRequired: 300,
        visualKey: "product.lamp",
        industry: "tech",
        industryNameTh: "เครื่องใช้ไฟฟ้าและเทคโนโลยี"
      },
      iotController: {
        id: "iotController",
        nameTh: "กล่องควบคุม IoT อุตสาหกรรม",
        bom: { pcb: 1, casing: 1, microchip: 1, sensor: 1 },
        assemblyMinutes: 45,
        qaMinutes: 15,
        packingMinutes: 8,
        priceMin: 110000,
        priceMax: 135000,
        researchRequired: 160,
        visualKey: "product.iotController",
        industry: "tech",
        industryNameTh: "เทคโนโลยีและระบบอัจฉริยะ"
      },
      smartMeter: {
        id: "smartMeter",
        nameTh: "มิเตอร์ไฟฟ้าอัจฉริยะ Smart Grid",
        bom: { pcb: 1, microchip: 1, sensor: 1, casing: 1, wire_harness: 1 },
        assemblyMinutes: 50,
        qaMinutes: 18,
        packingMinutes: 8,
        priceMin: 130000,
        priceMax: 160000,
        researchRequired: 200,
        visualKey: "product.smartMeter",
        industry: "tech",
        industryNameTh: "เทคโนโลยีและระบบอัจฉริยะ"
      },
      autoSensor: {
        id: "autoSensor",
        nameTh: "โมดูลเซนเซอร์ตรวจจับยานยนต์",
        bom: { pcb: 1, metal_sheet: 1, wire_harness: 1, sensor: 1 },
        assemblyMinutes: 50,
        qaMinutes: 20,
        packingMinutes: 8,
        priceMin: 135000,
        priceMax: 165000,
        researchRequired: 140,
        visualKey: "product.autoSensor",
        industry: "automotive",
        industryNameTh: "ยานยนต์และชิ้นส่วนกลไก"
      },
      evController: {
        id: "evController",
        nameTh: "ชุดควบคุมมอเตอร์ไฟฟ้า EV",
        bom: { pcb: 1, metal_sheet: 2, wire_harness: 2, casing: 1 },
        assemblyMinutes: 65,
        qaMinutes: 25,
        packingMinutes: 10,
        priceMin: 180000,
        priceMax: 220000,
        researchRequired: 240,
        visualKey: "product.evController",
        industry: "automotive",
        industryNameTh: "ยานยนต์และชิ้นส่วนกลไก"
      },
      batteryPack: {
        id: "batteryPack",
        nameTh: "แพ็กแบตเตอรี่โมดูลยานยนต์ EV",
        bom: { battery: 2, metal_sheet: 1, wire_harness: 2, heat_sink: 1 },
        assemblyMinutes: 70,
        qaMinutes: 25,
        packingMinutes: 12,
        priceMin: 210000,
        priceMax: 260000,
        researchRequired: 360,
        visualKey: "product.batteryPack",
        industry: "automotive",
        industryNameTh: "ยานยนต์และชิ้นส่วนกลไก"
      },
      herbalDrink: {
        id: "herbalDrink",
        nameTh: "เครื่องดื่มสมุนไพรอัดขวดสุญญากาศ",
        bom: { raw_extract: 2, glass_bottle: 2, pack_carton: 1 },
        assemblyMinutes: 25,
        qaMinutes: 18,
        packingMinutes: 12,
        priceMin: 95000,
        priceMax: 115000,
        researchRequired: 80,
        visualKey: "product.herbalDrink",
        industry: "food",
        industryNameTh: "อาหารแปรรูปและเครื่องดื่มสุขภาพ"
      },
      energyProtein: {
        id: "energyProtein",
        nameTh: "โปรตีนอัดแท่งเสริมพลังงาน",
        bom: { raw_extract: 3, pack_carton: 2 },
        assemblyMinutes: 30,
        qaMinutes: 15,
        packingMinutes: 10,
        priceMin: 110000,
        priceMax: 130000,
        researchRequired: 180,
        visualKey: "product.energyProtein",
        industry: "food",
        industryNameTh: "อาหารแปรรูปและเครื่องดื่มสุขภาพ"
      },
      functionalShot: {
        id: "functionalShot",
        nameTh: "เครื่องดื่มสกัดเข้มข้นบูสต์ภูมิคุ้มกัน",
        bom: { raw_extract: 3, glass_bottle: 2, pack_carton: 1 },
        assemblyMinutes: 28,
        qaMinutes: 20,
        packingMinutes: 10,
        priceMin: 125000,
        priceMax: 150000,
        researchRequired: 260,
        visualKey: "product.functionalShot",
        industry: "food",
        industryNameTh: "อาหารแปรรูปและเครื่องดื่มสุขภาพ"
      },
      solarCharger: {
        id: "solarCharger",
        nameTh: "เครื่องชาร์จโซลาร์พกพา",
        bom: { solar_cell: 1, battery: 1, casing: 1, pcb: 1 },
        assemblyMinutes: 45,
        qaMinutes: 18,
        packingMinutes: 8,
        priceMin: 160000,
        priceMax: 195000,
        researchRequired: 220,
        visualKey: "product.solarCharger",
        industry: "energy",
        industryNameTh: "พลังงานสะอาดและรักษ์โลก"
      },
      homeInverter: {
        id: "homeInverter",
        nameTh: "อินเวอร์เตอร์แปลงไฟโซลาร์รูฟท็อป",
        bom: { solar_cell: 1, pcb: 1, microchip: 1, heat_sink: 2, metal_sheet: 1 },
        assemblyMinutes: 60,
        qaMinutes: 22,
        packingMinutes: 10,
        priceMin: 195000,
        priceMax: 240000,
        researchRequired: 340,
        visualKey: "product.homeInverter",
        industry: "energy",
        industryNameTh: "พลังงานสะอาดและรักษ์โลก"
      },
    },
    roles: {
      sales: { nameTh: "ฝ่ายขาย B2B", skill: "sales", division: "office" },
      admin: { nameTh: "จัดซื้อและบัญชี", skill: "admin", division: "office" },
      engineer: { nameTh: "วิศวกร R&D", skill: "engineering", division: "office" },
      assembler: { nameTh: "ช่างฝ่ายผลิต", skill: "assembly", division: "factory" },
      inspector: { nameTh: "ตรวจคุณภาพ QC", skill: "quality", division: "factory" },
      logistics: { nameTh: "คลังและจัดส่ง", skill: "logistics", division: "factory" },
      coordinator: { nameTh: "ผู้บริหาร/CEO", skill: "leadership", division: "executive" },
    },
    taskKinds: {},
    starters: [
      { name: "มิน", role: "sales", dailyWage: 38000 },
      { name: "ภัทร", role: "admin", dailyWage: 35000 },
      { name: "น้ำ", role: "engineer", dailyWage: 42000 },
      { name: "ต้น", role: "assembler", dailyWage: 40000 },
      { name: "อิง", role: "assembler", dailyWage: 40000 },
      { name: "กานต์", role: "inspector", dailyWage: 36000 },
      { name: "ป่าน", role: "logistics", dailyWage: 36000 },
      { name: "ธีร์", role: "coordinator", dailyWage: 35000 },
    ],
    rules: {
      initialCash: 12000000,
      initialDebt: 6000000,
      rentDaily: 80000,
      interestDaily: 0.0002,
      minimumWage: 28000,
      creditLimit: 20000000,
      paydayInterval: 7,
      maxActiveOrders: 12,
      maxUnits: 160,
      scenarioDays: 90,
      winCash: 6000000,
      winReputation: 60,
      hireFee: 300000,
      maxPeople: 500,
    },
    initialStock: { pcb: 30, casing: 30, driver: 30, led: 0, sensor: 0, metal_sheet: 0, wire_harness: 0, microchip: 0, raw_extract: 0, glass_bottle: 0, pack_carton: 0, solar_cell: 0, battery: 0, heat_sink: 0 },
  };
  function registerSkill(c, spec) {
    if (!spec || !validId(spec.id) || c.skills[spec.id])
      throw new TypeError("invalid/duplicate skill id");
    H.createSkill(H.createProfile("validation", "person"), spec);
    if (typeof spec.nameTh !== "string" || !spec.nameTh)
      throw new TypeError("skill needs name");
    c.skills[spec.id] = clone(spec);
    return c;
  }
  function registerRole(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      c.roles[spec.id] ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !Object.hasOwn(c.skills, spec.skill)
    )
      throw new TypeError("invalid role specification");
    c.roles[spec.id] = { nameTh: spec.nameTh, skill: spec.skill };
    return c;
  }
  function registerMaterial(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      c.materials[spec.id] ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !Number.isSafeInteger(spec.unitCost) ||
      spec.unitCost < 1 ||
      spec.unitCost > 1e9 ||
      !Number.isSafeInteger(spec.leadMinutes) ||
      spec.leadMinutes < 5 ||
      spec.leadMinutes > 1440 * 30
    )
      throw new TypeError("invalid material specification");
    c.materials[spec.id] = clone(spec);
    if (!Object.hasOwn(c.initialStock, spec.id)) c.initialStock[spec.id] = 0;
    return c;
  }
  function registerProduct(c, spec) {
    if (
      !spec ||
      !validId(spec.id) ||
      c.products[spec.id] ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      !spec.bom ||
      typeof spec.bom !== "object" ||
      Array.isArray(spec.bom) ||
      !Object.keys(spec.bom).length
    )
      throw new TypeError("invalid product specification");
    for (const [m, n] of Object.entries(spec.bom))
      if (
        !Object.hasOwn(c.materials, m) ||
        !Number.isSafeInteger(n) ||
        n < 1 ||
        n > 1000
      )
        throw new TypeError("invalid BOM material: " + m);
    for (const k of [
      "assemblyMinutes",
      "qaMinutes",
      "packingMinutes",
      "priceMin",
      "priceMax",
    ])
      if (
        !Number.isSafeInteger(spec[k]) ||
        spec[k] < 1 ||
        spec[k] > (k.startsWith("price") ? 1e12 : 100000)
      )
        throw new TypeError("invalid product field: " + k);
    const bomCost = Object.entries(spec.bom).reduce(
      (sum, [id, n]) => sum + c.materials[id].unitCost * n,
      0,
    );
    if (!Number.isSafeInteger(bomCost) || Object.keys(spec.bom).length > 64)
      throw new TypeError("unsafe BOM cost");
    if (
      spec.priceMin > spec.priceMax ||
      !Number.isFinite(spec.researchRequired ?? 0) ||
      (spec.researchRequired ?? 0) < 0
    )
      throw new TypeError("invalid product price/research");
    c.products[spec.id] = {
      ...clone(spec),
      researchRequired: spec.researchRequired ?? 0,
      visualKey: spec.visualKey || "product." + spec.id,
    };
    return c;
  }
  function validateTaskKind(c, spec) {
    const allowedStations = new Set([
      "assembly",
      "quality",
      "packing",
      "shipping",
      "admin",
      "research",
      "sales",
      "manager",
    ]);
    if (
      !spec ||
      !validId(spec.id) ||
      typeof spec.nameTh !== "string" ||
      !spec.nameTh ||
      typeof spec.skill !== "string" ||
      !Object.hasOwn(c.skills, spec.skill) ||
      !allowedStations.has(spec.stationKind) ||
      !Number.isSafeInteger(spec.requiredMinutes) ||
      spec.requiredMinutes < 5 ||
      spec.requiredMinutes > 1440 ||
      spec.requiredMinutes % 5 !== 0
    )
      throw new TypeError("invalid task kind specification");
    if (spec.impacts !== undefined) {
      if (
        !spec.impacts ||
        typeof spec.impacts !== "object" ||
        Array.isArray(spec.impacts)
      )
        throw new TypeError("invalid task impacts");
      for (const [k, v] of Object.entries(spec.impacts))
        if (typeof v !== "number" || !Number.isFinite(v) || v < -2 || v > 2)
          throw new TypeError("invalid task impact " + k);
    }
    for (const [k, min, max] of [
      ["researchPoints", 0, 1000],
      ["reputationDelta", -10, 10],
      ["workload", 0, 2],
      ["hazard", 0, 1],
      ["complexity", 0, 1],
    ])
      if (
        spec[k] !== undefined &&
        (typeof spec[k] !== "number" ||
          !Number.isFinite(spec[k]) ||
          spec[k] < min ||
          spec[k] > max)
      )
        throw new TypeError("invalid task effect " + k);
    if (
      spec.revenue !== undefined &&
      (!Number.isSafeInteger(spec.revenue) ||
        spec.revenue < 0 ||
        spec.revenue > 1e9)
    )
      throw new TypeError("invalid task revenue");
    if (
      spec.domain !== undefined &&
      !["cognitive", "physical", "social", "creative", "balanced"].includes(
        spec.domain,
      )
    )
      throw new TypeError("invalid task domain");
  }
  function registerTaskKind(c, spec) {
    if (!c.taskKinds || typeof c.taskKinds !== "object") c.taskKinds = {};
    if (spec && Object.hasOwn(c.taskKinds, spec.id))
      throw new TypeError("duplicate task kind");
    validateTaskKind(c, spec);
    c.taskKinds[spec.id] = {
      ...clone(spec),
      researchPoints: spec.researchPoints ?? 0,
      reputationDelta: spec.reputationDelta ?? 0,
      revenue: spec.revenue ?? 0,
      domain: spec.domain || "balanced",
      workload: spec.workload ?? 1,
      hazard: spec.hazard ?? 0,
      complexity: spec.complexity ?? 0.5,
    };
    return c;
  }
  function validateCatalog(c) {
    const e = [];
    if (
      !c ||
      typeof c !== "object" ||
      !c.skills ||
      !c.materials ||
      !c.products ||
      !c.roles ||
      !c.rules ||
      !c.initialStock
    )
      return ["catalog missing top-level sections"];
    for (const [id, s] of Object.entries(c.skills)) {
      if (!validId(id) || id !== s?.id) e.push("invalid skill " + id);
      else
        try {
          H.createSkill(H.createProfile("validate", "p"), s);
        } catch (err) {
          e.push(err.message);
        }
    }
    for (const [id, m] of Object.entries(c.materials))
      if (
        !validId(id) ||
        id !== m?.id ||
        !Number.isSafeInteger(m.unitCost) ||
        m.unitCost < 1 ||
        m.unitCost > 1e9 ||
        !Number.isSafeInteger(m.leadMinutes) ||
        m.leadMinutes < 5
      )
        e.push("invalid material " + id);
    for (const [id, p] of Object.entries(c.products)) {
      if (
        !validId(id) ||
        id !== p?.id ||
        typeof p.bom !== "object" ||
        Array.isArray(p.bom) ||
        !p.bom ||
        !Object.keys(p.bom).length
      ) {
        e.push("invalid product " + id);
        continue;
      }
      for (const [mat, n] of Object.entries(p.bom))
        if (
          !Object.hasOwn(c.materials, mat) ||
          !Number.isSafeInteger(n) ||
          n < 1
        )
          e.push("invalid BOM " + id);
      for (const k of [
        "assemblyMinutes",
        "qaMinutes",
        "packingMinutes",
        "priceMin",
        "priceMax",
      ])
        if (
          !Number.isSafeInteger(p[k]) ||
          p[k] < 1 ||
          p[k] > (k.startsWith("price") ? 1e12 : 100000)
        )
          e.push("invalid " + id + "." + k);
      const bomCost = Object.entries(p.bom).reduce(
        (sum, [id, n]) => sum + (c.materials[id]?.unitCost || 0) * n,
        0,
      );
      if (!Number.isSafeInteger(bomCost) || Object.keys(p.bom).length > 64)
        e.push("unsafe BOM economics " + id);
      if (
        p.priceMin > p.priceMax ||
        !Number.isFinite(p.researchRequired) ||
        p.researchRequired < 0
      )
        e.push("invalid product economics " + id);
    }
    for (const [id, n] of Object.entries(c.initialStock))
      if (!Object.hasOwn(c.materials, id) || !Number.isSafeInteger(n) || n < 0)
        e.push("invalid stock " + id);
    for (const [id, r] of Object.entries(c.roles))
      if (
        !validId(id) ||
        ["constructor", "prototype"].includes(id) ||
        !r ||
        !Object.hasOwn(c.skills, r.skill)
      )
        e.push("invalid role " + id);
    if (c.taskKinds !== undefined) {
      if (
        !c.taskKinds ||
        typeof c.taskKinds !== "object" ||
        Array.isArray(c.taskKinds)
      )
        e.push("invalid taskKinds");
      else
        for (const [id, t] of Object.entries(c.taskKinds)) {
          try {
            if (id !== t.id) throw new TypeError("mismatched task id");
            validateTaskKind(c, t);
          } catch (_) {
            e.push("invalid taskKind " + id);
          }
        }
    }
    if (c.lifeGoals !== undefined) {
      try {
        H.deriveAspirations(
          H.createProfile("validate", "p"),
          H.STATE_DEFAULTS,
          { goalSpecs: c.lifeGoals },
        );
      } catch (_) {
        e.push("invalid life goals");
      }
    }
    for (const [k, v] of Object.entries(c.rules))
      if (typeof v !== "number" || !Number.isFinite(v) || v < 0)
        e.push("invalid rule " + k);
    for (const skill of [
      "sales",
      "admin",
      "engineering",
      "assembly",
      "quality",
      "logistics",
      "leadership",
    ])
      if (!Object.hasOwn(c.skills, skill))
        e.push("required skill " + skill + " missing");
    if (
      !Array.isArray(c.starters) ||
      !c.starters.length ||
      c.starters.length > 600
    )
      e.push("invalid starters");
    else
      for (const s of c.starters)
        if (
          !s ||
          typeof s.name !== "string" ||
          !Object.hasOwn(c.roles, s.role) ||
          !Number.isSafeInteger(s.dailyWage) ||
          s.dailyWage < c.rules.minimumWage
        )
          e.push("invalid starter");
    for (const [k, min, max] of [
      ["initialCash", 0, 1e12],
      ["initialDebt", 0, 1e12],
      ["rentDaily", 0, 1e9],
      ["minimumWage", 1, 1e7],
      ["creditLimit", 0, 1e12],
      ["paydayInterval", 1, 30],
      ["maxActiveOrders", 1, 200],
      ["maxUnits", 1, 4000],
      ["scenarioDays", 1, 365],
      ["winCash", 0, 1e12],
      ["winReputation", 0, 100],
      ["hireFee", 0, 1e9],
      ["maxPeople", 1, 600],
    ])
      if (
        !Number.isSafeInteger(c.rules[k]) ||
        c.rules[k] < min ||
        c.rules[k] > max
      )
        e.push("invalid rule " + k);
    if (
      typeof c.rules.interestDaily !== "number" ||
      !Number.isFinite(c.rules.interestDaily) ||
      c.rules.interestDaily < 0 ||
      c.rules.interestDaily > 0.1
    )
      e.push("invalid interest rate");
    return e;
  }
  return Object.freeze({
    VERSION: "1.2.0",
    NATIONALITIES,
    NAME_POOLS,
    STARTER_IDENTITIES,
    CORPORATE_DIVISIONS,
    ROLE_DEPARTMENTS,
    CAREER_QUOTAS,
    CAREER_LADDERS,
    EXPANSION_PLOTS,
    EXTERNAL_WORLD_DEFAULTS,
    LEAN_STARTERS,
    MOTIVE_FACTOR_LABELS,
    INDUSTRY_SKILL_TEMPLATES,
    getCareerStep,
    getNextCareerStep,
    createIdentity,
    translateMotiveFactor,
    createCatalog: () => clone(defaults),
    validateCatalog,
    registerSkill,
    registerRole,
    registerMaterial,
    registerProduct,
    registerTaskKind,
  });
});
