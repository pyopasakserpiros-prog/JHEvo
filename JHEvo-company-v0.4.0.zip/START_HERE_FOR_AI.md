# เริ่มที่นี่ — Company Simulation (v0.4.0)

งานปัจจุบัน: เกมบริษัทมุมมองภายนอก (`Siam Enterprise: Autonomous Multi-Industry Company Simulation`) ผู้เล่นสังเกตการณ์ NPC และ CEO ดำเนินกิจการและตัดสินใจเอง ดูสถานะล่าสุดที่ `project_status_and_ai_onboarding.md` และกฎที่ `AGENTS.md` ก่อนทำแพตช์

เปิดเล่น `COMPANY_SOURCE/CompanyFoundation_single.html` (หรือ `COMPANY_SOURCE/Company_single.html`) หรือรัน local server จาก `COMPANY_SOURCE` แล้วเปิด `index.html` ไฟล์ HTML เดี่ยวฝัง CSS/JS สำหรับใช้ออฟไลน์ 100%

## อ่านตามงาน

1. `AGENTS.md` — ขอบเขตผู้เล่น ล็อกแกนมนุษย์ บัญชี และเซฟ
2. `project_status_and_ai_onboarding.md` — สิ่งที่ทำได้จริงใน v0.4.0 ข้อจำกัด และผลตรวจล่าสุด (112/112 tests)
3. `.agents/skills/company-evolution-dev/SKILL.md` และ `.agents/skills/company-for-every-patch/SKILL.md` (รวมถึง `SKILL.md` ที่รากโปรเจกต์) — พิมพ์เขียวสถาปัตยกรรมและรายการตรวจสอบบังคับทุกครั้งที่อัปเดตแพตช์
4. `COMPANY_SOURCE/README.md` — วิธีเปิด สร้างไฟล์เล่น และเครื่องมือทดสอบ
5. `docs/company/PATCH_IMPLEMENTATION_REPORT_COMPANY_V0_3_0.md` — รายงานการอัปเดตแพตช์ v0.4.0 (ระบบโควตาตำแหน่งตามพีระมิด, เครื่องยนต์ประเมินเลื่อนขั้นโดยหัวหน้างานด้วย Human Core & ความสัมพันธ์, ปรับทิศทางบริษัทสู่ Multi-Industry, และสินค้า 4 หมวดอุตสาหกรรม)
6. `docs/company/PRESENTATION_API.md`, `HUMAN_CORE_MODEL.md`, `MANUFACTURING_SUPPLY_CHAIN_AND_INVENTORY_SPEC.md`, และ `HIERARCHICAL_WORKFORCE_AND_PROMOTION_SYSTEM.md`
