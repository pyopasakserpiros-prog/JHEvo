# JianghuSect 2 v2.3.0 — รวมรายงานตรวจบัคแปดหมวด (แยกไฟล์ทั้งหมด)

**อัปเดต 8 พฤศจิกายน 2026 | ใช้ซอร์ส v2.3.0 เดียวกันโดยไม่แก้ไฟล์เกม**

## หมวด 1 — บัคทั้งเกม (รายงานก่อนหน้า)
- `QA_FREEZE_AUDIT_V230.docx` / `.md` / `.json`: บัคและตรรกะโดยรวม 13 ประเด็น
- `AUDIT_REPRO_RED_TESTS.js`, `AUDIT_REPRO_BASELINE.txt`, `REGRESSION_*.json/.txt`, `SCHEMA_VALIDATION_LOG.txt`

## หมวด 2 — อุปกรณ์และเมต้า (รายงานก่อนหน้า แยกจากวิถี)
- `QA_GEAR_BALANCE_AUDIT_V230.docx` / `.md` / `.json`: ตรวจอุปกรณ์ 12 ประเด็น บัค + design review
- `GEAR_PATCH_IMPLEMENTATION_GUIDE.md`: คำสั่งสำหรับ AI แก้หมวดอุปกรณ์
- `GEAR_BALANCE_REPRO_TESTS.js`, `GEAR_BALANCE_REPRO_RESULTS.json`, `GEAR_BALANCE_REPRO_RUN_LOG.txt`

## หมวด 3 — วิถีหลักและสายย่อย (รายงานเพิ่มใหม่)
- `QA_DAO_PATH_SUBPATH_AUDIT_V230.docx` / `.md` / `.json`: 43 วิถี, 286 สายย่อย, 5 กลุ่มบัคยืนยัน + 1 review + 1 info
- `DAO_PATCH_IMPLEMENTATION_GUIDE.md`: คำสั่งลำดับงานให้ AI เขียนโค้ดแก้ DAO-IDs
- `DAO_PATH_SUBPATH_REPRO_TESTS.js`, `DAO_PATH_SUBPATH_REPRO_RESULTS.json`, `DAO_PATH_SUBPATH_REPRO_RUN_LOG.txt`: 8 cases (6 reproduced, 1 control, 1 review)
- `DAO_PATH_SUBPATH_BASELINE_MATRIX.json`: ค่าสเตตัสไร้อุปกรณ์/คัมภีร์/วิชา 286 สายสำหรับทบทวน (ไม่ใช่ power tier list)

## ความสำคัญและข้อควรระวัง
1. DAO-001 P0: 15 สายย่อยทะลวงไม่ได้จาก skill ID ผิด 144 จุดใน 9 realms, 128 จุดมีผลต่อการทะลวงระดับ 2–9
2. DAO-002 P1: เมื่อเปลี่ยนวิถี ระบบยังสวมมนตราขั้น 7 ต่างวิถีในขั้น 1 ได้ผ่านกฎ UI (bug ยืนยันจาก source functions)
3. DAO-003 P1: 38 preference refs ใน 35 สายย่อยไม่มี affinity canonical; DAO-004 P1: 3 วิถีหลักอ่านค่าความชอบผิดชื่อ; DAO-005 P2: lifeMult stale หลังทะลวงสำเร็จ
4. DAO-006 REVIEW: สายที่สเตตัสแรงอาจเป็นเมต้าเกมปลายทางที่ตั้งใจไว้ ควรเทียบการต่อสู้จริงก่อนเนิร์ฟ; DAO-007 INFO ไม่ใช่ bug
5. รายงานอุปกรณ์และรายงานวิถีเป็นคนละไฟล์ ไม่เขียนทับกัน และบัคที่เกี่ยวกับอุปกรณ์ใช้ prefix `EQ-`, วิถีใช้ `DAO-`.
6. ZIP นี้เป็น **รายงานและหลักฐานเท่านั้น** ไม่รวม source เกม; ใช้ source ZIP ที่ผู้ใช้อัปโหลดแยกต่างหาก. Repro runner ต้องเข้าถึง `test/load.js` ของโค้ดเกม (กำหนด `GAME_SOURCE_ROOT`).

## หมวด 4 — ระบบสำนักส่วนที่เหลือ (ไม่ตรวจเศรษฐกิจซ้ำ)
- `QA_SECT_SYSTEMS_AUDIT_V230.docx` / `.md` / `.json`: 27 เคส negative-path ในหมวดการเมือง/ศาล/ตำแหน่ง/สืบทอด/แลกเปลี่ยน/จารกรรม/โทเท็ม/ยอดเขา/ค่ายกล/ค่าหัว/automation; 1 ข้อเป็น REVIEW ไม่ใช่ confirmed bug
- `SECT_PATCH_IMPLEMENTATION_GUIDE.md`: ลำดับแก้สำหรับ AI พร้อม acceptance tests และ save migration
- `SECT_DEEP_REPRO_TESTS.js`, `SECT_DEEP_REPRO_RESULTS.json`, `SECT_DEEP_REPRO_RUN_LOG.txt`: ชุด Node negative-path 27 กรณี พร้อมผลรันจริง
- `SECT_REGRESSION_BASELINE_LOG.txt`: ชุดทดสอบสำนักเดิม 5 ชุด ผ่านทั้งหมดเมื่อรันแยก
- **ความสำคัญ:** S17 รับค่าหัวทันทีได้ แต่การรีเฟรชซ้ำวันเดิมตรวจได้เฉพาะ API; S15 ยังไม่พิสูจน์ปั๊ม Tier; S16 FREE TOTEM เป็น design REVIEW.
- 3 หมวดก่อนหน้าถูกเก็บไว้ใน ZIP เดิมครบและไม่แก้ไฟล์รายงานเดิม

## อัปเดต: ตรวจผลกระทบลูกโซ่ก่อนปล่อย (8 พ.ย. 2026)

**ไม่ได้สร้างรายงานใหม่**: เพิ่มภาคผนวกและข้อมูล JSON ในรายงาน 4 หมวดเดิม; ปรับคู่มือแก้ไขเดิมด้วย โดยไม่เปลี่ยนไฟล์เกม.

- บัคทั่วไป: `JHS-014` P2 (W.byId ผีสำหรับสมาชิกที่ออก) — รวม 14 ประเด็น.
- อุปกรณ์: `EQ-013` P1 (อาวุธผู้สืบทอดหายถาวรเมื่อรับจิตศาสตรา), `EQ-014` P2 (ฝัง elder soul ถูกข้าม) — รวม 14 ประเด็น.
- วิถี/สายย่อย: ไม่มีรหัสใหม่; เพิ่มหลักฐาน `DAO-001/002` บัคค้างหลังโหลด.
- สำนัก: `SECT-28` P1 (ศิษย์สืบทอดตายแล้ว ID ค้าง) — รวม 28 ประเด็น; เพิ่มพยาน guard roster, splinter, exchange, bounty, relic, totem.

ไฟล์ `CASCADE_*_REPRO_TESTS.js` และ `CASCADE_*_REPRO_RESULTS.json` เป็น **สคริปต์/หลักฐานทดสอบ** ไม่ใช่รายงานใหม่. ใช้ `GAME_SOURCE_ROOT=/path/to/GAME_SOURCE node CASCADE_<...>_REPRO_TESTS.js`; `OUTPUT_JSON=/path/result.json` เลือกที่เขียนผลได้. หลักฐาน 20 chain cases ทั้งหมดใช้ Node loader + source เดิม; ข้อใหม่ยืนยัน runtime แต่ยังไม่ใช่การรับรอง browser playthrough ครบทุก UI.

> Release readiness ยังไม่ผ่าน: แก้ P0/P1, จัดการเซฟ legacy และรัน regression/standalone/browser/perf ก่อนแจกผู้เล่น. เลิกนับเป็น bug เฉพาะเพราะ meta สูงโดยไม่มี proof.

## หมวด 5 — ระบบต่อสู้ วิชา สถานะ และ AI (รอบตรวจใหม่ก่อนปล่อย)

- `QA_COMBAT_SKILLS_STATUS_AUDIT_V230.docx` / `.md` / `.json`: 11 ประเด็น P0–P3 รวม 1 ประเด็นฮีลที่ต้องยืนยัน design ก่อน nerf.
- `COMBAT_PATCH_IMPLEMENTATION_GUIDE.md`: ลำดับแก้ไขแบบต้นทางและ acceptance tests สำหรับ Coding AI.
- `COMBAT_DEEP_REPRO_TESTS.js`, `COMBAT_DEEP_REPRO_RESULTS.json`, `COMBAT_DEEP_REPRO_RUN_LOG.txt`: 17 เคส (14 พบอาการ, 2 control, 1 inconclusive), errors 0.
- `COMBAT_REGRESSION_BASELINE_LOG.txt`: regression ระบบต่อสู้/วิชา/วิถี 10 ชุดผ่าน เมื่อแยกรันจาก source เดิม.
- **Release blocker ใหม่:** COMBAT-01 P0 ตายจาก combat แล้ว AI.kill ไม่ทำความสะอาดและเซฟผิดถาวร; COMBAT-02–06 aura/formation/siege ติดผลผิดฝ่าย; COMBAT-07 shieldBp ไม่ลด.
- อัปเดตท้ายรายงานเดิม 4 หมวด (Word + Markdown + JSON) เป็นการเชื่อมผลกระทบ ไม่เพิ่มรายงานภาพรวมใหม่ และไม่เพิ่ม ID ซ้ำ.
- **ควรตรวจถัดไป:** เซฟ/โหลด + migration + วงจรเวลา tick/day/month; ต่อด้วย UI route + world event/exploration.
- **ข้อจำกัด:** Node-runtime probes ไม่ใช่ browser E2E, ไม่มีการแก้ source และยังไม่รัน regression ทุกรายการ.


## หมวด 6 — สำรวจโลก แดนลับ คณะเดินทาง วาสนาฟ้าดิน (8 พ.ย. 2026)

- `QA_WORLD_EXPLORATION_EXPEDITIONS_AUDIT_V230.docx` / `.md` / `.json`: **14 ประเด็น** แยก P0 1, P1 5, P2 5, REVIEW 3 (REVIEW ไม่ถือว่าเป็นบัคยืนยัน).
- `WORLD_EXPLORATION_PATCH_IMPLEMENTATION_GUIDE.md`: ลำดับแก้แบบต้นทางสำหรับ AI เขียนโค้ด พร้อม negative-path acceptance tests.
- `WORLD_EXPLORATION_REPRO_TESTS.js` / `_RESULTS.json` / `_RUN_LOG.txt`: 30 cases (รวม controls และ review) ผลคาดเกิดซ้ำ 30/30, test script errors 0. ใช้ `GAME_SOURCE_ROOT=/path/to/GAME_SOURCE node WORLD_EXPLORATION_REPRO_TESTS.js`.
- `WORLD_EXPLORATION_REGRESSION_LOG.txt`: regression เดิม 6 suites exit 0. `WORLD_EXPLORATION_BROWSER_E2E_BLOCKED.json`: Playwright เปิดหน้า localhost ไม่ได้จาก `ERR_BLOCKED_BY_ADMINISTRATOR` — จึง **ยังไม่ได้ทดสอบ UI E2E ด้วยการคลิก**; UI route ยืนยันจาก source.
- **Release blocker:** WORLD-01 micro-location จ่ายของ/CP/merit ไม่จำกัดในเวลาเกมเดียวกัน; WORLD-04 NPC ทำ gather + world anomaly ซ้อนจน resolve สองงาน; WORLD-02/05/06 คนคุก/เนรเทศ/เดินทางยังถูกเลือกเป็นคณะ; WORLD-03 NPC ซ้ำใน party.
- **ความสัมพันธ์ข้ามหมวด:** สำนัก/บทลงโทษ/ค่ายพัก, สถานะต่อสู้-ความตาย, การฝึกฝน และผลลัพธ์เซฟ. ไม่ตรวจเศรษฐกิจหรือเซฟซ้ำหมวดที่อีกแชทกำลังตรวจ.
- **หมวดที่ควรตรวจถัดไป:** ระบบ NPC อิสระ ความต้องการ บุคลิก ความสัมพันธ์ อาจารย์–ศิษย์ และการเลือกกิจกรรม.

**การส่งมอบเป็นรายงานอย่างเดียว:** ไม่แก้ source ของเกม และไม่ได้สร้าง ZIP เกมฉบับใหม่ในชุดนี้.

## หมวด 7 — อาจารย์–ศิษย์ สายสืบทอด และตำแหน่งทำเนียบสำนัก (8 พ.ย. 2026)

- `QA_MENTORSHIP_OFFICES_AUDIT_V230.docx` / `.md` / `.json`: **14 root causes ใหม่** (P0=1, P1=10, P2=3), **3 design-review**, และยืนยันซ้ำ `SECT-03` จากหมวดสำนักโดยไม่เปิด ID ใหม่.
- `MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js`, `_RESULTS.json`, `_RUN_LOG.txt`: 33 cases — finding patterns reproduced 21, controls pass 9, design reviews 3, test script errors 0. **21 เคสไม่ใช่ 21 บัคอิสระ**.
- `MENTORSHIP_OFFICES_REGRESSION_LOG.txt`: regression สายสืบทอด/ตำแหน่ง/cognition เดิม 9 suites exit=0.
- `MENTORSHIP_OFFICES_PATCH_IMPLEMENTATION_GUIDE.md`: ลำดับแก้แบบ canonical eligibility, atomic retire, formal lineage/AI teach separation, office delegation revocation, safeguard dying wish.
- **P0 release blocker:** ชี้แนะศิษย์ซ้ำ 12 ครั้งภายในเวลาเกมเดียวกัน → cult progress +124, teacher merit +24; UI source path มีให้กด.
- **ผลกระทบลูกโซ่:** AI teach จบกิจกรรมแล้วบังคับเปลี่ยนสายอาจารย์; การออกจากสำนักยังสอน/ให้โบนัสทะลวง; การปลดตำแหน่งไม่ถอนสิทธิ์ผู้รักษาการ; SIM.addNpc→retire บางสถานะ crash หลังลบชื่อออกจาก roster แต่ยังไม่คืนทรัพย์สิน.
- **ขอบเขต:** แยก UI path กับ internal API / crafted state; ไม่ยืนยันว่าได้ทำ browser click-through E2E สำเร็จ; ไม่มีการตรวจ AI NPC ทั้งระบบ/เศรษฐกิจ/เซฟเกมซ้ำกับอีกแชท.
- **คำแนะนำถัดไป:** ตรวจ UI end-to-end + การยืนยันสิทธิ์คำสั่งผู้เล่น และ runtime ระยะยาวหลังแก้ release blockers.

**การส่งมอบเป็นรายงานอย่างเดียว:** ไม่แก้ source ของเกม และไม่ได้สร้าง ZIP เกมฉบับใหม่ในชุดนี้.


## หมวด 8 — วิชา คัมภีร์ กระบวนท่า และวิชาที่ใช้กับอาวุธ/อุปกรณ์ (8 พ.ย. 2026)

- `QA_TECHNIQUES_WEAPONS_AUDIT_V230.docx` / `.md` / `.json`: รายงานเฉพาะหมวด **TECH-01–10** แยกต่างหากจากหมวดต่อสู้/วิถี/อุปกรณ์เดิม; บัค/ความไม่สอดคล้อง 7, review สมดุล/เจตนา 2, content backlog 1.
- `TECHNIQUE_PATCH_IMPLEMENTATION_GUIDE.md`: ลำดับแก้ต้นเหตุและ acceptance tests สำหรับ Coding AI, ไม่เนิร์ฟวิชาที่ M สูงเพียงอย่างเดียว.
- `TECHNIQUE_REPRO_INSTRUCTIONS.md`: คำสั่งรันและขอบเขตความหมายของชุดทดสอบ; สคริปต์ `TECHNIQUE_{CATALOG_SCAN,CROSS_SCAN,COVERAGE_AUDIT,RUNTIME_PROBES}.js` ใช้ `GAME_SOURCE_ROOT=/path/to/GAME_SOURCE`.
- `TECHNIQUE_INDIVIDUAL_CATALOG_QA.csv`: static audit ของ **1,824 วิชา/คัมภีร์**; `TECHNIQUE_EACH_MOVE_QA.csv`: profile/screening **2,603** รายการ (ไม่ใช่ E2E หรือ combat encounter simulation).
- `TECHNIQUE_PATH_COVERAGE.csv`, `TECHNIQUE_SUBPATH_COVERAGE.csv`, `TECHNIQUE_SUBPATH_GAP_ACTIONS.csv`, `TECHNIQUE_WEAPON_COVERAGE.csv`: ตารางครบ **43 วิถี 286 สายย่อย และ 16 อาวุธ** พร้อมช่องว่างวิชา/บทบาทและการจัดลำดับพัฒนา.
- `TECHNIQUE_RUNTIME_PROBE_RESULTS.json`, `TECHNIQUE_RUNTIME_PROBE_PORTABLE_LOG.txt`, `TECHNIQUE_COVERAGE_AUDIT.json`, `TECHNIQUE_CATALOG_SCAN.json`, `TECHNIQUE_CROSS_SCAN_SUMMARY.json`, `TECHNIQUE_EQUIPMENT_TYPE_MISMATCHES.json`, `TECHNIQUE_EQUIPMENT_GRANT_CANDIDATES.json`, `TECHNIQUE_RELATED_REGRESSION_LOG.txt`: ผลตรวจประกอบ/ข้อมูลสำหรับ AI.
- **พบสำคัญ:** TECH-01 อาวุธ 24 + เกราะ 12 ชิ้นชนิดผิด, TECH-02 อุปกรณ์ให้ท่าขั้นสูงก่อนเงื่อนไข, TECH-04 4 วิชาปลดท่าสองไม่ได้; TECH-03 ตัวกรองโบนัสธาตุใน `skillModifiers` ต้องยืนยัน semantics ก่อนเปลี่ยน schema.
- **ข้อเสนอแยกจากบัค:** วิถีหลักต่ำกว่าค่าเฉลี่ย 31/43; สายย่อยต่ำกว่าเฉลี่ย 202/286; `JADE_IMMORTAL_BODY` มีวิชาเฉพาะ 1; อาวุธ 6 ประเภทใหม่ไม่มีท่าที่ตั้ง `requiresWeapon` โดยตรงแม้มีท่าที่ associated; เพิ่มสถานะใหม่เป็นข้อเสนอหลังปิด P0/P1 เท่านั้น.
- **Release Gate ยังไม่ผ่าน:** ปิดบัคต้นทางและทดสอบการใช้งานจริงตามชุดทดสอบ/สิทธิ์/สถานะโลกก่อนเปิดให้ผู้เล่น. แฟ้มทั้งหมดเป็นรายงาน ไม่แก้ไฟล์เกม.
