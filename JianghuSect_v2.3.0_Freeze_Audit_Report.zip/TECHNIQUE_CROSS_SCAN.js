const fs=require('fs'), G=require(require('path').join(process.env.GAME_SOURCE_ROOT || require('path').join(__dirname, 'GAME_SOURCE'), 'test', 'load'));const {JD,SK,CULT,MARTIAL:M,ECO}=G;
const ts=[...(JD.TECH.techniques||[]),...(JD.TECH.mantras||[])];
const moveRows=[],techRows=[],errors=[];
for(const t of ts){
 let profiles=[], ex='';try{profiles=SK.allMoves(t)}catch(e){ex=e.stack||e.message;}
 if(ex)errors.push({id:t.id,err:ex});
 const reqs={reqPath:t.reqPath,reqSubpath:t.reqSubpath,reqElement:t.reqElement,requiresWeapon:t.requiresWeapon,compatiblePaths:t.compatiblePaths,compatibleSubs:t.compatibleSubs};
 const trow={id:t.id,nameTh:t.nameTh,path:t.path,sub:t.sub,cat:t.cat,tier:t.tier,grade:t.grade,legendary:!!t.legendary,innate:!!t.innateOnly,isSectHeritage:!!t.isSectHeritage,passive:!!t.passive,stages:Array.isArray(t.stages)?t.stages.length:0,moveDefs:Array.isArray(t.moveDefs)?t.moveDefs.length:0,profiles:profiles.length,reqs,arch:t.combatArch,desc:t.descTh||t.description||null};techRows.push(trow);
 for(const p of profiles){moveRows.push({techId:t.id,id:p.moveId||p.id,nameTh:p.nameTh,tier:t.tier,path:t.path,cat:t.cat,arch:p.arch,M:p.M,hits:p.hits,cd:p.cd,wind:p.wind,costPct:p.costPct,stageReq:p.stageReq,reqMastery:p.reqMastery,reqCultStage:p.reqCultStage,aoe:p.aoe,team:p.team,shield:p.shield,heal:p.heal,steal:p.steal,qiRestorePct:p.qiRestorePct,element:p.element,grantBuff:p.grantBuff,ctrl:p.ctrl,rider:p.rider,shieldValid:p.shield<=1,healValid:p.heal<=1,range:p.range,composable:p.composable,aiRole:p.aiRole});}
}
const out={techRows,moveRows,errors};fs.writeFileSync(require('path').join(__dirname, 'TECHNIQUE_CROSS_SCAN.json'),JSON.stringify(out,null,2));
const by=(arr,k)=>arr.reduce((o,x)=>(o[String(x[k])]=(o[String(x[k])]||0)+1,o),{});
const anomalies={unknownStatus:[],nonfinite:[],noMove:[],invalidRange:[],highPower:[],tooCheap:[],positiveQi:[],unknownArch:[]};
for(const p of moveRows){for(const [field,v]of Object.entries({M:p.M,cd:p.cd,wind:p.wind,hits:p.hits,costPct:p.costPct}))if(!Number.isFinite(v))anomalies.nonfinite.push({id:p.id,field,v});for(const field of ['grantBuff','ctrl','rider'])if(typeof p[field]==='string'&&!SK.STATUS[p[field]])anomalies.unknownStatus.push({id:p.id,field,status:p[field]});if(p.M*p.hits>15)anomalies.highPower.push({id:p.id,M:p.M,hits:p.hits,value:p.M*p.hits});if(p.M>0&&p.costPct===0)anomalies.tooCheap.push({id:p.id});if((p.heal||0)>1||(p.shield||0)>1)anomalies.positiveQi.push({id:p.id,heal:p.heal,shield:p.shield});if(!SK.ARCH[p.arch])anomalies.unknownArch.push({id:p.id,arch:p.arch});}
for(const t of techRows)if(!t.passive&&t.profiles===0&&!/MANTRA/.test(t.cat||''))anomalies.noMove.push({id:t.id,cat:t.cat});
console.log(JSON.stringify({counts:{techRows:techRows.length,profiles:moveRows.length,errors:errors.length,reqPath:techRows.filter(x=>x.reqs.reqPath).length,reqSubpath:techRows.filter(x=>x.reqs.reqSubpath).length,reqElement:techRows.filter(x=>x.reqs.reqElement).length,requiresWeapon:techRows.filter(x=>x.reqs.requiresWeapon).length},anomalies:Object.fromEntries(Object.entries(anomalies).map(([k,v])=>[k,{count:v.length,sample:v.slice(0,18)}]))},null,2));
