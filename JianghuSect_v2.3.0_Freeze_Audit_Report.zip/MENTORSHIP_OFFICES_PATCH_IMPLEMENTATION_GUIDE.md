# คู่มือ Coding AI — แก้บัคสายอาจารย์–ศิษย์และทำเนียบสำนัก (v2.3.0)

> ให้อ่าน `AGENTS.md` ก่อนแก้ทุกครั้ง, รักษา Human Core fingerprint, ห้ามปรับสมดุลค่าเมต้าโดยไร้หลักฐาน, ห้ามเขียนโค้ด stub, ห้ามลดความหมายของ 25 ตำแหน่ง.

## อ่านหลักฐานก่อนแก้

- `QA_MENTORSHIP_OFFICES_AUDIT_V230.md/.json` สรุป 14 root causes; `MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js` ใช้ต้นฉบับจาก `GAME_SOURCE` เท่านั้น.
- ทั้ง 33 เคสเป็นหลักฐานปัจจุบันของช่องโหว่: finding จะต้อง **ไม่** ยืนยันพฤติกรรมผิดเดิมหลังแก้; control ต้องยังผ่าน; DR ต้องมี decision ก่อนแก้.
- `SECT-03` เรื่องแต่งตั้ง NPC ที่ถูกกักขังถูกบันทึกไว้ในรายงาน SECT แล้ว; อย่าสร้าง ticket ซ้ำ.

## แนวแก้แบบ transaction/contract เดียว (prioritized)

1. **Eligibility contract:** `isActiveSectMember`, `canMentorNow`, `canBeDisciple`, `canHoldOffice`, `canDelegateDomain`; ทุกจุดแก้ state ใช้ predicate กลาง รวม alive, W.npcs membership, jail/detention/away/sealed/exiled, location, preconditions. แยก historical relationships ออกจาก active action.
2. **Mentorship lesson ≠ formal bond:** `AI.pairEnd(type=teach)` ไม่ควรรับศิษย์อัตโนมัติ. `coachDisciple` ต้องตรวจ formal bond และใช้ cooldown/budget; ห้าม `force:true` บน path ผู้เล่น. พิธี reparent ต้องอัปเดต bond/family/rel/chronicle แบบ atomic.
3. **Qi inheritance:** `transmitQi` ตรวจ mentor alive และ disciple bond ตามกฎ; dyingWish และ preAscension เป็น event token ก่อน mark dead เพื่อรักษาการส่งต่อจิตวิญญาณที่ตั้งใจ; no multi-unrelated flood.
4. **Office resolver:** แปลง planned aliases เป็น canonical post code ในทุก public entrypoint (appoint, dismiss, holder, authority). validate post ก่อนแก้ n.post; invalid alias ต้องไม่ mutate state.
5. **Delegation:** office dismissal, retire, death, replace ต้องเรียก sync/revoke ด้วย transaction เดียว. `COG.hasAuthority` ยืนยัน original holder, live delegation, acting flag, scopes, active member; stale grants ต้อง reject.
6. **Retirement:** init `n.inv.crystals` / `n.inv.subManuals` ตั้งแต่ addNpc; MARTIAL.returnKnowledge defensive; stage return assets ก่อน W.npcs.splice หรือใช้ rollback; cleanup teacher and office references; verify no duplicate equipment/knowledge.
7. **Long-world regression:** จำลอง AI teach เดินต่อหลายเดือน, สลับ 2 อาจารย์, เนรเทศ/กักขัง/ตาย/รับศิษย์ใหม่, สืบทอดผู้นำ, กรณีไม่มีครู/คนเต็มเพดาน และ load mid-transition; assert deterministic archive.

## Acceptance gates

- P0 UI spam no free progress in same time window.
- AI teaching neither changes registered master nor bypasses maximum disciples.
- Retired/exiled/detained/away/dead mentors cannot coach or offer live tribulation guidance unless explicitly designed and validated.
- All removed official/acting delegated rights revoked; role, posts, post/n.post and authorities same canonical state.
- New NPC retirement error-free and atomic; all gear, manuals, crystals returned exactly once.
- DyingWish transmission still works before character marked dead; valid succession, old lineage records and existing 9 regression suites preserved.
- Manual browser testing of character profile, mentor button, office appointments and dismissal UI, save/load confirmation; no duplicate logs nor double spend.

## Commands

```bash
node MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js /path/to/GAME_SOURCE > result.json
# then run relevant nine baseline suites referenced in MENTORSHIP_OFFICES_REGRESSION_LOG.txt
# and the complete GAME_SOURCE/test/run_all.js before release
```

**ห้ามใช้เกณฑ์ “สคริปต์เดิมผ่าน” เป็นหลักฐานว่า bug หาย** เพราะ repro script นี้ตรวจว่าบัคเกิดได้ในซอร์สเดิม; ต้องเขียน revised assertions ที่ตรวจ expected protected outcome ให้ผ่าน แล้วเก็บ proof ทั้ง pre/post fix.
