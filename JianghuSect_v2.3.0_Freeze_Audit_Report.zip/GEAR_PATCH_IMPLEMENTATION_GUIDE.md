# คำสั่งให้ AI เขียนโค้ดแก้ไข — Equipment Freeze Patch v2.3.0

**เป้าหมาย:** ปิดช่องโกง/บัคอุปกรณ์โดยไม่เพิ่มฟีเจอร์ ไม่เนิร์ฟเมต้าอย่างไม่มีหลักฐาน และไม่เปลี่ยนโครงสร้างใหญ่โดยไม่จำเป็น

## สิ่งที่ต้องอ่านตามลำดับ
1. `QA_FREEZE_AUDIT_V230.md` (Audit เดิม, เป็นการตรวจทั้งเกม)
2. `QA_GEAR_BALANCE_AUDIT_V230.md` (Audit อุปกรณ์รอบใหม่)
3. `QA_GEAR_BALANCE_AUDIT_V230.json` (machine-readable tasks)
4. `GEAR_BALANCE_REPRO_TESTS.js`, `.json`, `.txt` (หลักฐาน/สคริปต์ทดสอบ)

## Task queue
A. P0 EQ-001 — แก้ socketRune ให้ transactional & idempotent: ตรวจ owner/resources/slots, socket replacement ไม่ append modifiers ทับ, validate และ migrate old saves; runtime enforce ceiling. เป้าหมาย: 100 clicks ไม่โตไม่จำกัด

B. P0 EQ-009 — รวม quality clamp ไว้จุดเดียว; clamp `newQ` ก่อนคำนวณ ratio; ไม่มี growth เมื่อ `newQ<=oldQ`; ไม่คูณ `st`/`combatMult` ซ้ำจน drift; preserve legitimate max quality; migration for existing over-scaled equipment

C. P1 EQ-002 — initialXp UI ต้องไม่ 320 แบบกดได้ซ้ำฟรี; สร้างของจากอากาศเฉพาะกรณี design explicitly; ค่าจิต/level/cost/progression เป็น authoritative และ replay-safe

D. P1 EQ-003/EQ-011 — โบนัสอุปกรณ์พังต้อง inactive ใน paired/equipment rating; cache invalidation หลัง wear/repair; NEUTRAL pairing จัดให้เป็น rule ชัดเจน

E. P1 EQ-005/EQ-010 — helper เดียวสำหรับ path/stage/usable/equip/granted skills; test progression boundaries และ incompatible path

F. P1 review EQ-004 — Legendary wildcard ดูเจตนา: ถ้าไม่ใช่ universal ให้ whitelist/family/type restriction แทน blanket `legendary=>true`; ถ้า deliberate universal ห้ามลบทิ้งโดยไม่เพิ่มทางเลือกเมต้า

G. P2 EQ-006 — gear identity/ownership validation, ไม่ mutate orphan object

H. REVIEW EQ-007/EQ-012 — ห้ามสั่งเนิร์ฟอัตโนมัติ: stone repair ลด maxDur และ 3-legendaries +45.3% *raw stat contribution* เป็น design choice; ต้องวัด DPS/EHP/endgame cost ก่อน

## ต้องส่งกลับเมื่อแก้
- Patch/diff ทุกไฟล์ที่แก้ พร้อมอธิบายเหตุผลแต่ละ EQ-ID
- Unit/regression tests สำหรับเคสเดิม **หลังแก้** ให้ assert expected healthy behavior ไม่ใช่ assert ว่ายังโกงได้
- ผลรัน baseline ชุดเก่า + ชุดใหม่, QA manual checklist, save migration test
- รายการที่ไม่ได้แก้ พร้อมเหตุผล (เช่น ตั้งใจให้ Legendary เป็นเมต้าระดับสูง)

## คำสั่งรันหลักฐาน
แตกไฟล์ original release ให้มีโฟลเดอร์ `GAME_SOURCE/` ตามจริง จากนั้น:

```bash
JHS_GAME_ROOT=/absolute/path/to/GAME_SOURCE node GEAR_BALANCE_REPRO_TESTS.js
```

บันทึกผลจาก `GEAR_BALANCE_REPRO_RESULTS.json` กับ log; สคริปต์นี้เป็น **red-test** แสดง behavior เดิม ไม่ใช่ green-test ตรวจหลังแก้ (คาดว่าบางเคสจะไม่ผ่านเมื่อแก้ถูกต้อง).


## อัปเดตก่อนเปิดเกม: ระบบมรดกอุปกรณ์ + chain regression (8 พ.ย. 2026)

- **EQ-013 [P1]** ก่อนทำ UI polishing ให้แก้ `SOUL_FORGE.inheritSentientWeaponOnDeath` ไม่ให้ทับ `heir.equip.WEAPON` โดยทำอาวุธเดิมหายเมื่อ `heir.inv.gear` ไม่มี; atomic ownership / UID exactly-once ก่อน-หลัง save.
- **EQ-014 [P2]** ตรวจเจตนามรดกวิญญาณผู้อาวุโสแล้วเลือกการเรียก `imbueElderSoulIntoWeapon` ก่อนย้าย reference หรืออธิบาย design ให้ชัด.
- **EQ-001/EQ-002** เพิ่ม tests หลัง reload และ Sect Tier/rating เพราะรอบใหม่พิสูจน์ว่า rune×15 คง modifier 15 ครั้ง และจิตศาสตรา stage5 ส่งผล rating/Tier score จริง.
- **โยง SECT-28** ผู้สืบทอดตายแล้ว successorId ค้าง; ให้ integration test death+inherit+succession ในโลกเดียว ไม่ดูแต่ gear inventory.
