'use strict';
const fs=require('fs');const G=require(require('path').join(process.env.GAME_SOURCE_ROOT || require('path').join(__dirname, 'GAME_SOURCE'), 'test', 'load')); const P=(__dirname + require('path').sep);const {JD,SK,MARTIAL:M,ECO}=G;
const T=[...(JD.TECH.techniques||[]),...(JD.TECH.mantras||[])];const paths=JD.CULT.paths; const allPaths=Object.keys(paths),subEntries=[];
for(const [pid,p] of Object.entries(paths))for(const sub of p.subPaths||[])subEntries.push({path:pid,pathTh:p.shortTh||p.nameTh,sub:sub.id,subTh:sub.nameTh});
const combatCats=new Set(['COMBAT_TECHNIQUE','FORBIDDEN_ART','SUPPORT_TECHNIQUE','DEFENSIVE_TECHNIQUE','MOVEMENT_TECHNIQUE','FORBIDDEN_TECHNIQUE','LIGHTNESS_ART','AUXILIARY_ART','LIGHTNESS_GRAND_DAO','DEFENSIVE_GRAND_DAO','SUPPORT_GRAND_DAO','FORBIDDEN_GRAND_DAO']);
const innate=t=>!!t.innateOnly||!!t.isInnate||!!t.innateSubpath||String(t.cat).startsWith('INNATE_');
const isPassive=t=>!!t.passive||String(t.cat).startsWith('PASSIVE')||!!t.passiveFamily;
const moves=t=>SK.allMoves(t);
const roles=(mm)=>[...new Set(mm.map(m=>{
 const a=m.arch;
 if(['guard','shield','counter','evade'].includes(a))return 'DEFENSE';
 if(['heal','support','buff','cleanse','summon'].includes(a))return 'SUPPORT';
 if(['control','bind','seal','suppress','taunt','stun'].includes(a))return 'CONTROL';
 if(['blink','charge','dash','retreat','movement','mobility'].includes(a))return 'MOBILITY';
 return 'OFFENSE';}))];
const matchesSub=(t,s)=>t.path===s.path&&(t.sub===s.sub || t.innateSubpath===s.sub || (Array.isArray(t.reqSubpath)?t.reqSubpath.includes(s.sub):t.reqSubpath===s.sub));
const nativePath=t=>allPaths.includes(t.path);
const pRows=[];
for(const pid of allPaths){const pt=T.filter(t=>t.path===pid),act=pt.filter(t=>moves(t).length>0),m=act.flatMap(moves);const rolesSet=roles(m);
 pRows.push({path:pid,nameTh:paths[pid].shortTh||paths[pid].nameTh,subpaths:(paths[pid].subPaths||[]).length,techniques:pt.length,active:act.length,passive:pt.filter(isPassive).length,innate:pt.filter(innate).length,moves:m.length,exclusiveSub:pt.filter(t=>t.sub||t.reqSubpath||t.innateSubpath).length,missingRoles:['OFFENSE','DEFENSE','SUPPORT','CONTROL','MOBILITY'].filter(r=>!rolesSet.includes(r)),roles:rolesSet});
}
const sRows=[];
for(const s of subEntries){const st=T.filter(t=>matchesSub(t,s));const act=st.filter(t=>moves(t).length>0);const m=act.flatMap(moves),r=roles(m);sRows.push({...s,exclusiveTech:st.length,exclusiveActive:act.length,exclusivePassive:st.length-act.length,innate:st.filter(innate).length,nonInnate:st.filter(t=>!innate(t)).length,moves:m.length,roles:r,missingRoles:['OFFENSE','DEFENSE','SUPPORT','CONTROL','MOBILITY'].filter(role=>!r.includes(role)),techIds:st.map(t=>t.id)});}
const wTypes=['SWORD','BLADE','SPEAR','FIST','BOW','STAFF','FOCUS','ZITHER','BRUSH','WHIP','ROSARY','CLAW','NEEDLE','FAN','ASTROLABE','ABACUS'];
const items=[...Object.values(ECO.itemById||{})]; const uniqI=new Map(items.filter(it=>it.id).map(it=>[it.id,it]));
const wRows=[];
for(const w of wTypes){const tw=T.filter(t=>(t.weaponTypes||[]).includes(w));const rw=tw.filter(t=>t.requiresWeapon);const ws=[...uniqI.values()].filter(it=>it.slot==='WEAPON'&&(it.gearType===w||(M.gearType&&M.gearType(it)===w)));const gSkills=new Set();let mods=0;for(const it of ws){for(const id of it.grantedSkills||[])gSkills.add(id);mods+=(it.skillModifiers||[]).length}
 const p=tw.flatMap(moves);wRows.push({weapon:w,nameTh:JD.MARTIAL.types[w],associatedTech:tw.length,requiredTech:rw.length,associatedMoves:p.length,weaponItems:ws.length,itemsWithGrants:ws.filter(it=>it.grantedSkills&&it.grantedSkills.length).length,grantSkillCount:gSkills.size,itemsWithModifiers:ws.filter(it=>it.skillModifiers&&it.skillModifiers.length).length,roles:roles(p),missingRoles:['OFFENSE','DEFENSE','SUPPORT','CONTROL','MOBILITY'].filter(r=>!roles(p).includes(r))});}
const by=(rows,k)=>rows.reduce((a,x)=>(a[x[k]]=(a[x[k]]||0)+1,a),{});
const mdian=a=>{a=a.slice().sort((x,y)=>x-y);return a.length?(a[Math.floor((a.length-1)/2)]+a[Math.floor(a.length/2)])/2:0};
const summary={pathCount:pRows.length,subCount:sRows.length,weaponCount:wRows.length,meanPath:(pRows.reduce((s,p)=>s+p.techniques,0)/pRows.length),medianPath:mdian(pRows.map(p=>p.techniques)),meanSubExclusive:(sRows.reduce((s,x)=>s+x.exclusiveTech,0)/sRows.length),medianSubExclusive:mdian(sRows.map(s=>s.exclusiveTech)),subNonInnateZero:sRows.filter(x=>!x.nonInnate).length,subActiveZero:sRows.filter(x=>!x.exclusiveActive).length,byTechs:by(sRows,'exclusiveTech'),pathUnderMean:pRows.filter(x=>x.techniques<pRows.reduce((v,p)=>v+p.techniques,0)/pRows.length).length,weaponMin:wRows.reduce((a,x)=>x.associatedTech<a.associatedTech?x:a,wRows[0]),weaponMax:wRows.reduce((a,x)=>x.associatedTech>a.associatedTech?x:a,wRows[0])};
const result={summary,paths:pRows,subpaths:sRows,weapons:wRows};
fs.writeFileSync(P+'TECHNIQUE_COVERAGE_AUDIT.json',JSON.stringify(result,null,2));
const tocsv=(filename,arr,cols)=>fs.writeFileSync(P+filename, '\ufeff'+cols.join(',')+'\n'+arr.map(o=>cols.map(k=>'"'+String(Array.isArray(o[k])?o[k].join('|'):(o[k]??'')).replace(/"/g,'""')+'"').join(',')).join('\n')+'\n');
tocsv('TECHNIQUE_PATH_COVERAGE.csv',pRows,['path','nameTh','subpaths','techniques','active','passive','innate','moves','exclusiveSub','roles','missingRoles']);
tocsv('TECHNIQUE_SUBPATH_COVERAGE.csv',sRows,['path','pathTh','sub','subTh','exclusiveTech','exclusiveActive','exclusivePassive','innate','nonInnate','moves','roles','missingRoles','techIds']);
tocsv('TECHNIQUE_WEAPON_COVERAGE.csv',wRows,['weapon','nameTh','associatedTech','requiredTech','associatedMoves','weaponItems','itemsWithGrants','grantSkillCount','itemsWithModifiers','roles','missingRoles']);
console.log(JSON.stringify({summary,leastPaths:[...pRows].sort((a,b)=>a.techniques-b.techniques).slice(0,14),leastWeapons:[...wRows].sort((a,b)=>a.associatedTech-b.associatedTech)},null,2));
