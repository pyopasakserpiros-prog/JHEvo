# JianghuSect 2 v2.3.0 — Freeze / Stability Code & Logic Audit

> **วันที่ตรวจ:** 8 พฤศจิกายน 2026  
> **ขอบเขต:** ไฟล์ ZIP v2.3.0 ที่แนบมาเท่านั้น (ไม่แก้ source)  
> **เป้าหมาย:** bug fixing / logic / missing integration / exploit ก่อนหยุดพัฒนาฟีเจอร์

## Executive decision

**ยังไม่แนะนำประกาศเป็นแพตช์สมบูรณ์ / content-freeze certified** แม้ Schema Validation และ standalone bundle ผ่าน เพราะมีช่องโหว่เศรษฐกิจที่สร้างทรัพยากรได้ฟรี ความคลาดเคลื่อนของเซฟเกม และระบบที่ประกาศแต่ไม่มีทางเชื่อมเข้าการเล่นจริง.

**จำนวนข้อค้นพบ 13 ข้อ:** P0 = 2, P1 = 6, P2 = 4, P3 = 1. แยกบันทึก QA performance เพิ่ม 1 ประเด็นที่ยังไม่ใช่หลักฐานยืนยันว่าบัคเกม.

## ผลการตรวจที่รันจริง

| Gate | ผล | หลักฐาน/ความหมาย |
|---|---|---|
| ZIP CRC | ผ่าน | ไฟล์ ZIP ไม่มีไฟล์เสีย |
| Core Lock | ผ่าน | human_core.js SHA-256 ตรงตาม invariant |
| Data Schema | ผ่าน | **0 Errors / 0 Warnings** |
| Full parallel regression | **138/139 ผ่าน** | v410 performance fail 4.768 ms/tick เมื่อทดสอบ 4 workers พร้อมกัน |
| v410 isolation | ผ่าน 121 assertions | 2.127 ms/tick เมื่อตรวจเดี่ยว; แสดงความไวต่อ CPU contention |
| JS syntax sweep | ผ่าน | node --check จำนวน 213 ไฟล์ |
| Standalone build parity | ผ่าน | สร้างไฟล์ใหม่ได้ SHA-256 เดิมทุกไบต์; standalone suite ผ่าน |
| Independent red probes | **14/14 FAIL ตามที่คาด** | ชี้บัค/ช่องเชื่อมขาดที่ suite เก่ายังไม่ตรวจ |

> ผล regression แสดงว่าชุดเทสต์เดิมครอบคลุมเส้นทางที่ทดสอบ แต่ **ไม่รับประกันว่าเกมไร้บัคเชิงตรรกะ**; failure ด้าน perf เกิดเฉพาะรันคู่ขนานในสภาพแวดล้อมนี้ จึงไม่จัดเป็นบัคเกมแน่นอน.

## ตารางจัดลำดับงานแก้

| รหัส | ลำดับ | อาการสรุป | หลักฐาน |
|---|---|---|---|
| JHS-001 | P0 | ใช้ไอเทมสิ้นเปลืองได้โดยไม่มีของในคลัง | ยืนยันด้วยการรันจริง |
| JHS-002 | P0 | ปรุงโอสถขาดสมุนไพรได้ และผลิตหลายร้อยชิ้นโดยจ่ายเพียงครั้งเดียว | ยืนยันด้วยการรันจริง |
| JHS-003 | P1 | ไอเทมหลายชาร์จถูกอ้างสิทธิ์ซ้ำโดยหลายตัวละคร | ยืนยันด้วยการรันจริง |
| JHS-004 | P1 | การเซฟตัด state ต่อสู้และพิธีกรรมที่มีผลจริงออก | ยืนยันด้วยการรันจริง |
| JHS-005 | P1 | ตัวตรวจเวอร์ชันเซฟยอมรับเซฟรุ่นใหม่/เวอร์ชันผิดรูปแบบ | ยืนยันด้วยการรันจริง |
| JHS-006 | P1 | ระบบ Effect ตอบว่าใช้งานสำเร็จทั้งที่ fallback ผิดคุณสมบัติ | ยืนยันด้วยการรันจริงสำหรับตัวอย่าง และยืนยันเชิงโครงสร้างสำหรับขอบเขต |
| JHS-007 | P1 | Duet Resonance API ยังไม่มีสายเรียกจากเกมจริง | ยืนยันจากการค้นหาจุดเรียกใน source; ยังไม่ยืนยัน UI ทุกเส้นทางด้วย manual playthrough |
| JHS-008 | P1 | วิชาประสานสายเฉพาะ 5 แบบเป็นเพียงข้อมูลไม่ถูกเลือกใช้งาน | ยืนยันจาก catalog references |
| JHS-009 | P2 | Duet ตรวจคูลดาวน์ฝ่ายร่าย แต่ไม่ตรวจฝ่ายคู่ | ยืนยันด้วยการรันจริง |
| JHS-010 | P2 | Enhanced charged skill entrypoint ไม่มีผู้เรียกจากระบบเล่น | ยืนยันจากการค้นหาการเรียกแบบ static |
| JHS-011 | P2 | Boss anatomy/part-break API ไม่ถูกเชื่อมกับดาเมจการต่อสู้ | ยืนยันจากการค้นหาการเรียกแบบ static |
| JHS-012 | P2 | ไอเทมโอสถของเซฟหนึ่งปนเข้า catalog ของเกมใหม่ | ยืนยันด้วยการรันจริง |
| JHS-013 | P3 | README ภายในแพ็กเกจระบุเวอร์ชันผิดจาก runtime | ตรวจเทียบไฟล์โดยตรง |

## รายงานรายข้อและคำสั่งแก้สำหรับ AI

### JHS-001 [P0] ใช้ไอเทมสิ้นเปลืองได้โดยไม่มีของในคลัง

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/economy.js:2534-2537`, `GAME_SOURCE/js/economy.js:2550-2566`, `GAME_SOURCE/js/economy.js:2373-2385`

**Actual / Evidence:** กรณีไอเทมใช้ครั้งเดียว เมื่อ ECO.count(W,itemId)=0 โค้ดข้าม ECO.take แล้วเดินหน้ารับผลสำเร็จ (ok:true) แม้ opts.free=false; ทดลอง ITEM190_PILL_001 ไม่มีในคลังแต่ใช้ได้จริง; กับดักที่ arm ไว้ก็เรียกใช้โดยไม่มี stock check.

**Impact:** สร้างผลของยา/ไอเทมฟรี ทำลายเศรษฐกิจและเงื่อนไขการต่อสู้; trap ที่ไม่มีของจริงยังทำงาน

**Fix direction:** ทำธุรกรรม reserve/consume แบบ atomic ก่อน apply effect; ถ้าไม่ free ต้องตรวจ stock/ownership และหักสำเร็จจึงใช้ได้; ห้ามหักสิ่งที่ไม่มี; trap ต้องยืนยัน stock ตั้งแต่ arm หรือ trigger และไม่ mark triggered เมื่อ use ไม่ผ่าน

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-001; ECO.useConsumableItem(W,n,"ITEM190_PILL_001",{free:false}) ขณะ stock=0 คืน ok:true

**Acceptance tests:** stock=0 ต้องคืน ok:false; HP/buff/effects/phase queue ไม่เปลี่ยน; เมื่อ stock≥1 ลดตรงจำนวน; opts.free:true ใช้เฉพาะทางที่อนุญาต

### JHS-002 [P0] ปรุงโอสถขาดสมุนไพรได้ และผลิตหลายร้อยชิ้นโดยจ่ายเพียงครั้งเดียว

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/economy.js:2428-2468`

**Actual / Evidence:** brewMultiPhaseSpecialtyPill เช็กเงิน แต่เมื่อสมุนไพรน้อยกว่า herbCost กลับไม่ reject; qty=Math.max(1,opts.qty||1) แต่ stoneCost/herbCost ไม่คูณจำนวน. ทดสอบ herb=0, stones=1000, qty=500: ได้โอสถ 500 ชิ้น ใช้หินปราณ 25 และสมุนไพร 0.

**Impact:** ทำลายต้นทุนการปรุงและระบบตลาด; bulk arbitrage รุนแรง

**Fix direction:** validate qty เป็นจำนวนเต็มบวกและมีเพดาน; คูณต้นทุนต่อหน่วยหรือกำหนดสูตร batch ที่ชัดเจน; reject หากสมุนไพร/เงินไม่พอ; ตรวจทั้งสองทรัพยากรก่อนหักแบบ atomic; ห้ามผลิตก่อนหัก

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-002a/JHS-002b

**Acceptance tests:** ขาดวัตถุดิบใดต้องไม่สร้างยา; qty=N ต้นทุน N× ต่อหน่วย (หรือสูตร batch ที่ประกาศ); ห้ามทรัพยากรติดลบ

### JHS-003 [P1] ไอเทมหลายชาร์จถูกอ้างสิทธิ์ซ้ำโดยหลายตัวละคร

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/economy.js:2546-2562`

**Actual / Evidence:** talismanCharges เก็บแยก npc.ext แต่คลังยังถือสินค้าจนใช้ชาร์จสุดท้าย; มี ITEM_V234_TAL_001 เพียงหนึ่งชิ้น (3 charges) ตัวละครสองคนเริ่มใช้ได้ทั้งคู่และต่างมี 2 charges คงเหลือ รวมเกินจำนวนที่เป็นเจ้าของจริง.

**Impact:** ทำซ้ำทรัพยากร/ขยายจำนวนชาร์จโดยไม่มีต้นทุน; ขายหรือโยกสินค้าได้ระหว่างชาร์จ

**Fix direction:** โอน ownership หรือจอง item-instance/charge pool เมื่อเริ่มใช้; ห้าม NPC คนอื่น claim ชิ้นเดียวกัน; เมื่อใช้หมดให้คืน/ลบ reservation อย่างปลอดภัย และ persist ผ่าน save/load

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-003

**Acceptance tests:** ไอเทม 1 ชิ้นมีจำนวนชาร์จรวมจำกัด; ระหว่างการใช้งาน ขาย/โอนไม่ทำให้สร้างชาร์จใหม่

### JHS-004 [P1] การเซฟตัด state ต่อสู้และพิธีกรรมที่มีผลจริงออก

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/sim.js:785-829`, `GAME_SOURCE/js/sim.js:896-903`, `GAME_SOURCE/js/cultivation.js:9152-9156`, `GAME_SOURCE/js/combat.js:5538-5576`, `GAME_SOURCE/js/combat.js:958-976`, `GAME_SOURCE/js/cognition.js:808-809`

**Actual / Evidence:** replacer ปฏิเสธ key ขึ้นต้น _ เกือบทั้งหมด; ค่า _divineStrain=90, _duetCdUntil, _ccImmuneUntil, _ccDrStacks, _boneArmorHp, _shadowClones, _poiseGauge, _lastGearSwapAt และค่าเก็บเศษเวลางานอื่นๆ กลายเป็น undefined หลังโหลด. ทดสอบ state 10 ฟิลด์หายทั้ง 10.

**Impact:** เซฟ/โหลดรีเซ็ต cooldown/ความเสี่ยง/เกราะ/CC diminishing returns/ฮิสเทอรีสลับอุปกรณ์; มีโอกาส exploit และผลลัพธ์ไม่ deterministic

**Fix direction:** จัดชั้น authoritative persistent state เทียบกับ transient cache จริง; ย้าย authoritative ไปชื่อไม่ขึ้น _ หรือ explicit allowlist/serialize envelope; มี migration สำหรับเซฟ v2.3.0 เดิม; ตรวจ round-trip active fight, divine strain, buff, gear hysteresis, partial cultivation progress

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-004; 10-field expanded repro อยู่ใน independent_repros ในการตรวจ

**Acceptance tests:** หลัง save/load ค่า cooldown/guard/progress เดิมเท่ากันและ decrement ต่ออย่างถูกต้อง; transient cache ไม่ serialize

### JHS-005 [P1] ตัวตรวจเวอร์ชันเซฟยอมรับเซฟรุ่นใหม่/เวอร์ชันผิดรูปแบบ

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/sim.js:7-11`, `GAME_SOURCE/js/sim.js:830-870`

**Actual / Evidence:** PATCH_VERSION ของเกมคือ 2.3.0 แต่ SUPPORTED_PATCHES มี 3.1.1–5.8.0; SUPPORTED_SAVE_SCHEMAS มีรายการ 3.x–5.8.0 จึงรับเซฟ 5.8.0 แล้ว serialize กลับเป็น 2.3.0 โดยไม่มี migration ที่ยืนยัน; patchVersion="invalid-version" ผ่าน เพราะ parseFloat เป็น NaN; schemaVersion="0.0.0-unknown" ก็ผ่าน; runtime v="9.0.0" ผ่าน ทั้งที่ SIM.VERSION=1.10.11.

**Impact:** ยอมรับข้อมูลที่เกมปัจจุบันไม่รู้จักและเปลี่ยนเวอร์ชันกำกับเงียบ ๆ; เสี่ยงโหลดผิด shape/สูญเสีย semantics

**Fix direction:** ใช้ semver parser แยก numeric parts และ reject invalid; รองรับเฉพาะ schema ที่พิสูจน์ migration/round-trip ได้; ห้าม whitelist future schema โดยไม่มี migration; แยกรุ่น engine/patch/schema ชัดเจน

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-005a/JHS-005b

**Acceptance tests:** reject future/malformed และ import ไม่แก้โลกเดิม; accepted version แต่ละรายการมี migration+tests ชัดเจน

### JHS-006 [P1] ระบบ Effect ตอบว่าใช้งานสำเร็จทั้งที่ fallback ผิดคุณสมบัติ

**ความมั่นใจ:** ยืนยันด้วยการรันจริงสำหรับตัวอย่าง และยืนยันเชิงโครงสร้างสำหรับขอบเขต

**จุดที่พบ:** `GAME_SOURCE/js/economy.js:1904-2050`, `GAME_SOURCE/js/economy.js:2051-2275`, `GAME_SOURCE/js/economy.js:2277-2300`, `GAME_SOURCE/js/economy.js:2585-2592`, `GAME_SOURCE/js/combat.js:5531`

**Actual / Evidence:** ALL_RUNTIME_EFFECT_IDS มี 143 IDs แต่ switch executeItemEffectById มี dedicated cases เพียง 46; 99 IDs ไหลเข้า default ทิ้ง params แล้วให้ buff fervorMight แทนและคืน ok:true. ตัวอย่าง EFX_CARGO_PRESERVATION ให้ combat buff ไม่ใช่เก็บรักษาเสบียง. verifyItemEffectRuntimeCoverage เพียงเทียบชื่อกับรายการ ไม่ทดสอบผลลัพธ์จริง. บาง ID อาจมี handler ในระบบอื่น จึงห้ามเหมาว่าทุก effect ไม่ทำงานทั่วเกม.

**Impact:** ไอเทม/โอสถที่ผ่าน executor นี้ให้ผลผิดชื่อ, ผู้เล่นเห็น success ผิดจริง, QA 100% coverage ที่ไม่สะท้อนพฤติกรรม

**Fix direction:** สร้าง dispatch map ตาม context/use-case แยก ITEM, PASSIVE_GEAR, COMBAT, CULTIVATION, EXPLORE; unhandled ต้องคืน ok:false พร้อม reason/log ไม่ให้ generic buff; เพิ่มผลเฉพาะ semantics และ contract tests ของ 143 IDs ตาม acquisition/use path

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-006; ECO.executeItemEffectById("EFX_CARGO_PRESERVATION") คืน ok:true และ STATS.has("fervorMight") เป็น true

**Acceptance tests:** ทุก Effect ที่ประกาศต้องมี test แสดง state delta ที่คาดหวังและผลด้านลบ/ข้อจำกัด; unknown ID ไม่ผ่านเงียบ

### JHS-007 [P1] Duet Resonance API ยังไม่มีสายเรียกจากเกมจริง

**ความมั่นใจ:** ยืนยันจากการค้นหาจุดเรียกใน source; ยังไม่ยืนยัน UI ทุกเส้นทางด้วย manual playthrough

**จุดที่พบ:** `GAME_SOURCE/js/combat.js:5536-5581`, `GAME_SOURCE/test/v340_combat_depth_and_duet_synergies_suite.js:104-132`

**Actual / Evidence:** COMBAT.tryExecuteDuetSkill ถูกนิยามใน combat.js แต่ไม่พบการเรียกใช้งานจาก GAME_SOURCE/js/*.js; การเรียกทั้งหมดที่พบอยู่ใน suite ที่ส่งคู่ทดสอบตรง ๆ. ดังนั้นมี API+test green โดยไม่ปรากฏ integration จาก battle AI/action selection.

**Impact:** ผู้เล่นอาจไม่เห็นระบบประสานวิชาคู่ทำงานเลยแม้มีระบบอยู่ใน data และ test

**Fix direction:** ต่อเข้าจังหวะ combat tick/action selection ตามเงื่อนไข bond/range/energy/qi และ cooldown; เลือกท่า/พันธะอย่างมีความหมาย; เพิ่ม integration test จาก SIM.tick/COMBAT.tickFight โดยไม่เรียก tryExecuteDuetSkill ตรง

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-007 (static orphan check)

**Acceptance tests:** สร้างการต่อสู้คู่ที่เข้าเงื่อนไขแล้ว Duet activation เกิดจาก gameplay path, บันทึกเหตุการณ์และ consume cost; ไม่เกิดในกรณีไม่เข้าเงื่อนไข

### JHS-008 [P1] วิชาประสานสายเฉพาะ 5 แบบเป็นเพียงข้อมูลไม่ถูกเลือกใช้งาน

**ความมั่นใจ:** ยืนยันจาก catalog references

**จุดที่พบ:** `GAME_SOURCE/js/combat.js:5537-5546`, `GAME_SOURCE/js/combat.js:5561-5569`, `GAME_SOURCE/test/v230_grand_dao_deep_parity_and_universal_arsenal_suite.js:145-146`

**Actual / Evidence:** CATALOG มี 8 ท่า แต่ tryExecuteDuetSkill เลือกได้เพียง 3 ท่าจาก companion/mentor/destiny; 5 ท่า BUSHIDO_SHINOBI, PANTHEON, OCCULT_GRAVE, ASTRAL_CHRONO, DRAGON_TIDE มีเพียงรายการประกาศ ไม่มี runtime reference เพื่อเลือกจริง. suite v230 ตรวจแค่ Object.keys(...).length>=8.

**Impact:** บิลด์สายเฉพาะมีท่าแสดงในข้อมูล แต่ไม่ได้โบนัส/เอฟเฟกต์ที่สัญญาไว้

**Fix direction:** เพิ่ม selector สำหรับเงื่อนไข path groups ของทั้งสองฝ่ายและบอนด์, ระบุ precedence เมื่อเข้าได้หลายหมวด; ทดสอบทุก catalog ID ถูกเลือกได้จริงผ่านการเล่น

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-008 (static catalog-only check)

**Acceptance tests:** มี fixture สำหรับท่าทั้ง 8 ชนิด และใน runtime แต่ละท่ามีทางเกิดตามกติกา

### JHS-009 [P2] Duet ตรวจคูลดาวน์ฝ่ายร่าย แต่ไม่ตรวจฝ่ายคู่

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/combat.js:5548-5556`, `GAME_SOURCE/js/combat.js:5575-5576`

**Actual / Evidence:** เมื่อร่ายสำเร็จตั้ง _duetCdUntil ทั้ง caster และ partner แต่ตรวจเพียง caster. ทดสอบให้ partner ยังติด cooldown แล้วรีเซ็ตเฉพาะ caster: เรียกซ้ำยัง ok:true.

**Impact:** cooldown ของฝ่ายคู่ไม่ถูกบังคับเมื่อสลับบทบาท/เปลี่ยนคู่ สร้างการร่ายถี่เกินออกแบบ

**Fix direction:** ตรวจทั้งสองคนก่อนทำความเสียหาย; บังคับ cost/cooldown สอดคล้องกับการใช้จริง; ร่วมกับแก้ JHS-004 เพื่อ persist cooldown

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-009

**Acceptance tests:** คู่ใดก็ตามที่ยังติด cooldown จะคืน cooldown-active ไม่สร้าง damage/shield

### JHS-010 [P2] Enhanced charged skill entrypoint ไม่มีผู้เรียกจากระบบเล่น

**ความมั่นใจ:** ยืนยันจากการค้นหาการเรียกแบบ static

**จุดที่พบ:** `GAME_SOURCE/js/combat.js:5583-5610`, `GAME_SOURCE/test/v340_combat_depth_and_duet_synergies_suite.js:173-184`

**Actual / Evidence:** startChargedSkill ตั้ง isChargedSkill, poiseShield และ release multiplier แต่ไม่พบ COMBAT.startChargedSkill(...) ใน GAME_SOURCE/js; มีเฉพาะเทสต์โดยตรง. เกมยังมี generic channeling อื่นอยู่ จึงต้องตรวจว่า enhanced entrypoint จำเป็น/ถูกใช้ทางอ้อมหรือไม่.

**Impact:** คุณสมบัติเสริม charge/poise/release อาจไม่เกิดจาก AI หรือสกิลในเกมจริง

**Fix direction:** หากเป็นฟีเจอร์ที่ต้องใช้ ให้ต่อจาก skill/action resolver และทดสอบ channeling ระยะจริง, interrupt, charged release, save/load; หากไม่ใช่ฟีเจอร์ใช้งานจริง ให้ลบ/ซ่อนความคาดหวังใน UI และเอกสาร

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-010 (static orphan check)

**Acceptance tests:** เล่นจนเกิด charged enhanced skill ได้ โดยไม่เรียก API ผ่าน test โดยตรง

### JHS-011 [P2] Boss anatomy/part-break API ไม่ถูกเชื่อมกับดาเมจการต่อสู้

**ความมั่นใจ:** ยืนยันจากการค้นหาการเรียกแบบ static

**จุดที่พบ:** `GAME_SOURCE/js/combat.js:5612-5682`, `GAME_SOURCE/test/v340_combat_depth_and_duet_synergies_suite.js:191-208`

**Actual / Evidence:** ANATOMY_BREAKER.damageBossPart มีระบบลด HP ชิ้นส่วนและดรอป แต่ไม่พบ runtime caller ใน GAME_SOURCE/js; เทสต์เรียก damageBossPart โดยตรง.

**Impact:** ผู้เล่นสู้บอสจริงแล้วไม่ปรากฏการทำลายชิ้นส่วน/หยุดสกิล/ดรอปเฉพาะจุดตามที่คาด

**Fix direction:** ต่อเข้าระบบ hit targeting หรืออนุญาตเป้าชิ้นส่วนใน encounter แบบชัดเจน, จำกัดดรอป 1 ครั้งต่อชิ้น, คืนค่าชิ้นส่วนหลัง save/load; ทดสอบผ่านการโจมตีจริง

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-011 (static orphan check)

**Acceptance tests:** พบการ invoke จาก combat damage path และ integration test ผ่านการโจมตีจริง

### JHS-012 [P2] ไอเทมโอสถของเซฟหนึ่งปนเข้า catalog ของเกมใหม่

**ความมั่นใจ:** ยืนยันด้วยการรันจริง

**จุดที่พบ:** `GAME_SOURCE/js/sim.js:912-918`, `GAME_SOURCE/js/economy.js:1899-1902`, `GAME_SOURCE/js/economy.js:2415-2419`

**Actual / Evidence:** deserialize เอา sect.customPills ไปเขียน ECO.itemById/ECO.v235ItemById ซึ่งเป็น registry ระดับ global; หลังโหลดเซฟที่มี AUDIT_PILL_LEAK_2026 แล้วสร้างโลกใหม่ที่ไม่มี pill ใน sect ใหม่ ECO.getItem(id) ก็ยังคืน pill เก่า.

**Impact:** ข้ามโลก/ข้ามเซฟมีการปนข้อมูล; เมื่อบวก JHS-001 จะใช้ effect ของไอเทมจากอีกเซฟได้แม้ไม่มีในคลัง

**Fix direction:** แยก custom definitions เป็น per-world registry; ECO.getItem ควรอิง W เมื่อเป็น dynamic item; clear scoped definitions ใน newGame/load หรือสร้าง sandbox import ก่อน commit; จัดการ conflict กับ canonical ID

**How to reproduce:** AUDIT_REPRO_RED_TESTS.js → JHS-012

**Acceptance tests:** สร้างโลกใหม่ไม่มี item definition ของเซฟก่อน; สามารถโหลดโลกเก่ากลับได้ครบโดยไม่ปนเปื้อน

### JHS-013 [P3] README ภายในแพ็กเกจระบุเวอร์ชันผิดจาก runtime

**ความมั่นใจ:** ตรวจเทียบไฟล์โดยตรง

**จุดที่พบ:** `GAME_SOURCE/README.md:1-15`, `GAME_SOURCE/js/sim.js:7-11`, `ACTIVE_PATCH_PROMPT_JIANGHUSECT2_V2_3_0.md:1-12`

**Actual / Evidence:** README ของ GAME_SOURCE เขียน package release/patch 3.1.1 และ save marker 3.1.0 แต่ runtime จริงประกาศ PATCH_VERSION 2.3.0, SAVE_SCHEMA_VERSION 2.3.0-grand-dao-deep-parity-release.

**Impact:** AI ที่รับงานอาจแก้ผิด branch, เขียน migration หรือ QA gate ผิดเวอร์ชัน

**Fix direction:** แก้ README เป็น 2.3.0, ติดป้าย historical docs/archive, ระบุ source of truth และ freeze branch

**How to reproduce:** เทียบข้อเท็จจริงด้วย diff ของ README และ SIM constants

**Acceptance tests:** README/index/version card/test manifest สอดคล้อง 2.3.0 และไม่มี current release ขัดกัน

## ประเด็น QA ที่แยกออกจากบัคเกม

**QA-PERF-01 — Test contention:** `node tools/run_parallel_tests.js` ด้วย `TEST_WORKERS=4` ให้ 138/139 ผ่าน; `v410` ล้มที่ 4.768 ms/tick เกิน threshold 3.5. เมื่อนำ suite เดียวกันมารันเดี่ยวผ่านครบ 121 assertions โดยใช้ 2.127 ms/tick. **ยังไม่มีหลักฐานว่า code path นี้ช้าเกินบนเครื่องเป้าหมายจริง**; แนะนำให้รัน performance solo และบันทึก CPU/VM environment; แยก functional assertions ออกจาก hard perf threshold.

## ขอบเขตและการอ่านผล

- **Confirmed runtime:** มี Node.js reproduction จริง ผ่าน state/return value ตามที่ระบุ; โปรดรันทดสอบใหม่หลังแก้.
- **Confirmed static integration gap:** จากการค้นทุกไฟล์ `GAME_SOURCE/js/*.js` ไม่พบ caller ไปยัง exported API; dynamic invocation / reflection อาจเกิดได้ตามโค้ดภายนอกหรือส่วนเพิ่มเติมที่ไม่ได้แนบมา จึงควรให้ AI เช็กก่อนตัดสินลบโค้ด.
- **Item effects 99/143:** หมายถึง `executeItemEffectById` ไม่มี `case` เฉพาะและจะใช้ fallback *ในเส้นทางนี้*; ไม่ได้ยืนยันว่า 99 รายการไม่มี logic ใน subsystem อื่น.
- **Replit:** ตรวจหาแอปชื่อ JianghuSect ในบัญชีที่เชื่อมต่อแล้วไม่พบ; การตรวจทั้งหมดจึงอ้างอิง ZIP ที่แนบมา ไม่ใช่ repository live.
- ไม่ได้ทดสอบ gameplay manual ทุกทางเลือกบนอุปกรณ์จริง; อุปกรณ์ที่รองรับ browser/Chromium มีอยู่และ test browser ที่รวมไว้รันผ่านใน baseline.

## ขั้นตอนให้ AI ที่เขียนโค้ดแก้ตามลำดับ

1. **ห้ามแก้ `GAME_SOURCE/js/human_core.js`** และห้ามเพิ่มฟีเจอร์/ทำ refactor ใหญ่ที่ไม่จำเป็น; ทำ snapshot/branch ใหม่เพื่อย้อนกลับได้.
2. แก้ P0 (`JHS-001`, `JHS-002`) ก่อนเพื่อหยุดการสร้าง resource ฟรี; ใช้ atomic check/reserve/commit และเพิ่ม zero-stock, qty, concurrency tests.
3. แก้ P1 (`JHS-003`–`JHS-008`): สิทธิ์ talisman charge, authoritative save state, version guards, effect semantics และ duet wiring; จัด migration เฉพาะจำเป็น.
4. แก้ P2 (`JHS-009`–`JHS-012`) แบบ targeted ตาม acceptance; จัด feature integration tests ที่เรียกจาก `SIM.tick`/combat update ไม่ใช่ direct API อย่างเดียว.
5. แก้ README `JHS-013` และทดสอบความถูกต้องหลังแก้แต่ละชุด; ไม่แตะ content/data ไม่เกี่ยวข้อง.
6. Gate ก่อนปล่อย: `node tools/validate_data_schema.js` ต้อง 0/0; `node test/run_all.js` 100%; `node test/standalone.js`; build single-file parity; รัน `AUDIT_REPRO_RED_TESTS.js` เป้าหมาย **GREEN 14/14**; browser QA และ 80-NPC perf แบบเดี่ยว.

## Prompt สำหรับส่งต่อ AI เขียนโค้ด (คัดลอกทั้งส่วนนี้)

```text
กรุณาแก้เฉพาะบัคของ JianghuSect 2 v2.3.0 จากไฟล์ QA_FREEZE_AUDIT_V230.md และ AUDIT_REPRO_RED_TESTS.js โดยเรียง P0 → P1 → P2 → P3. ห้ามเพิ่มฟีเจอร์ใหม่ที่ไม่จำเป็น, ห้ามแก้ GAME_SOURCE/js/human_core.js (SHA-256 lock), ห้ามเปลี่ยน behavior ที่พิสูจน์ว่าถูกอยู่แล้ว. ก่อนแก้แต่ละข้อ ให้ยืนยัน reproduction และ expected/actual ตามตำแหน่งไฟล์ที่ระบุ; สำหรับ static orphan ให้ตรวจ caller ทั้งหมดรวม dynamic hooks ก่อนต่อระบบ. หลังแก้ต้องส่งรายการไฟล์ที่เปลี่ยน, root cause, test ใหม่, วิธีอัปเกรดเซฟถ้ามี, สถานะ RED→GREEN 14/14, และผล schema/regression/browser/standalone ไม่แอบข้าม test failure หรืออ้าง 100% หากยังไม่ผ่าน. ยึด authoritative state และให้ใช้ resource/check/commit แบบ atomic เท่านั้น.
```

## ไฟล์แนบในชุดรายงาน

- `QA_FREEZE_AUDIT_V230.md` — รายงานฉบับอ่านโดย AI (ไฟล์นี้)
- `QA_FREEZE_AUDIT_V230.docx` — รายงานไทยสำหรับอ่านและส่งต่อ
- `QA_FREEZE_AUDIT_V230.json` — ข้อค้นพบแบบ structured
- `AUDIT_REPRO_RED_TESTS.js` — เทสต์ที่ควร FAIL ในบิลด์เดิมและ GREEN หลังแก้
- `AUDIT_REPRO_BASELINE.txt` — ผลการรัน red probes 14/14
- `REGRESSION_PARALLEL_RESULT.json` / `REGRESSION_PARALLEL_LOG.txt` — หลักฐานผล suite รวม
- `REGRESSION_V410_ISOLATED_LOG.txt` — ผล v410 เมื่อรันเดี่ยว
- `SCHEMA_VALIDATION_LOG.txt` / `BUILD_SINGLE_LOG.txt` — หลักฐาน build & schema

---
หมายเหตุ: รายงานนี้เป็นการตรวจ snapshot ของไฟล์แนบ; **ไม่มีการแก้ซอร์สเกมของลูกพี่** และไม่อ้างว่าเข้าถึง repo/เซฟจริงของผู้เล่น.


## ภาคผนวกอัปเดต — ตรวจผลกระทบลูกโซ่ก่อนปล่อยจริง (8 พ.ย. 2026)

> เพิ่มในรายงานเดิม ไม่ใช่รายงานใหม่; ผลตรวจรอบแรก 13 ข้อ + **JHS-014 อีก 1 ข้อ (รวม 14: P0=2/P1=6/P2=5/P3=1)**. การตรวจเศรษฐกิจเชิงลึกแยกให้ AI อีกแชทดูอยู่ จึงไม่มีการจัดอันดับราคา/เงินในส่วนนี้.

### JHS-014 [P2] NPC ที่ออกจากสำนักค้างใน W.byId จนกว่าเซฟ/โหลด

- **โค้ด:** `js/sim.js:472-488`, `js/sect.js:8565-8622`
- **หลักฐาน runtime:** C14 ลบสมาชิกออกจาก `W.npcs`, ใส่ `W.gone` แต่ `W.byId[id]` ยังมีค่า. C15 เรียก `SOUL_FORGE.awakenWeaponSpirit(W, id, id)` ต่อได้ `ok:true` และสร้างอาวุธให้คนที่ออกจากสำนักแล้ว; หลัง save/load หา ID นั้นไม่เจอ. **ยังไม่ยืนยันเส้นทาง UI ผู้เล่น**
- **ผลลูกโซ่:** ออกจากสำนัก → index รายชื่อสองชุดขัดกัน → API ภายในทำธุรกรรมกับคนที่ไม่ใช่สมาชิก → เซฟ/โหลดทำให้ผลเรียกต่างจากก่อนโหลด.
- **แก้ไข:** sync `W.byId` พร้อม `W.npcs` ใน retire, เก็บ history ใน `historicalPeople`, API ตรวจ active membership และสถานะทุกครั้ง; อย่าใช้การลบ history เพื่อแก้ index.
- **Acceptance:** ก่อนและหลัง load การเรียกด้วย ID คนเก่าคืนปฏิเสธ ไม่สร้างไอเทม/บันทึกผลสำเร็จ; ชื่อในสุสานและบันทึกประวัติยังคงอยู่.

### การเชื่อมต่อที่ต้องทดสอบร่วมหลังแก้

| ลำดับเหตุการณ์ | ผลที่พิสูจน์ / จุดเฝ้าระวัง | รายงานที่เป็นเจ้าของบัค |
|---|---|---|
| NPC ตาย → จิตศาสตราสืบทอด → inventory → save/load | อาวุธเดิมทายาทสูญหายถาวร (`C10`) | `EQ-013` รายงานอุปกรณ์ |
| สำนักแตก → member roster/guard roster → daily → save/load | สมาชิกกบฏยังนับเป็นกำลังเดิม (`C03`,`C12`) | `SECT-06` รายงานสำนัก |
| รีเทรนวิถี → คัมภีร์เดิม → STATS → save/load | คัมภีร์ข้ามวิถียังอยู่หลังโหลด (`C19`) | `DAO-002` รายงานวิถี |
| เซฟ/โหลด ↔ ความสามารถของ AI และอุปกรณ์ | สถานะคูลดาวน์/พลังบางส่วนต้อง round-trip โดยไม่ฟื้นโกง | `JHS-004`,`EQ-001`,`EQ-013` |

**Release gate:** ปิด P0/P1 ที่ผู้เล่นเข้าถึงได้ก่อนแจกเกม; สำหรับ API-only ไม่อ้างว่าโกงผ่าน UI จนกว่าจะตรวจ caller; ทุกระบบที่มีผลข้ามหมวดต้องเพิ่ม tests `before action → action → daily tick → serialize/deserialize → invariant` และห้ามแก้ซอร์สในรอบ audit นี้.

## การตรวจข้ามระบบเพิ่มเติม — COMBAT v2.3.0 (8 พ.ย. 2026)

**ผลต่อระบบรวม/เซฟจากการต่อสู้:** พบ COMBAT-01 ระดับ P0: C.slay ตั้ง dead=true ก่อนเรียก AI.kill จึงข้ามล้างตำแหน่ง, death log, W.deaths และ event การตายตามปกติ; CB-16 ยืนยันว่า state ผิดคงอยู่หลัง SIM.serialize/deserialize. ดู QA_COMBAT_SKILLS_STATUS_AUDIT_V230. ถือเป็น cross-domain blocker เพิ่ม ไม่แก้จำนวน issue เดิมและไม่อ้างว่าเกมถูกแก้แล้ว.
