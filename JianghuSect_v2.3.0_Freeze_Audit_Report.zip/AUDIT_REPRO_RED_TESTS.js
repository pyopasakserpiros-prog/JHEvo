'use strict';
/*
 * JianghuSect2 v2.3.0 independent regression probes — read-only against game source.
 * Place this file next to the GAME_SOURCE directory and run:
 *   node AUDIT_REPRO_RED_TESTS.js
 * Expected on the supplied unpatched ZIP: RED findings (assertions fail).
 * After fixes, all probes should become GREEN, and the original suites still pass.
 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const G = require(path.join(__dirname, 'GAME_SOURCE/test/load.js'));
const { SIM, ECO, COMBAT, STATS } = G;
const log = [];
function probe(id, description, fn) {
  try { fn(); log.push({ id, result: 'GREEN', description }); console.log('GREEN', id, description); }
  catch (e) { log.push({ id, result: 'RED', description, evidence: e.message }); console.log('RED', id, description, '=>', e.message); }
}
function world(seed) { return SIM.create('audit_' + seed); }
function emptyStock(W, id) { while (ECO.count(W,id)>0) ECO.take(W,id,1); }

probe('JHS-001','UseConsumable must reject zero stock unless opts.free',()=>{
  const W=world('free_consumable'),n=W.npcs[0],id='ITEM190_PILL_001';
  emptyStock(W,id); assert.equal(ECO.count(W,id),0);
  const before=ECO.count(W,id),r=ECO.useConsumableItem(W,n,id,{free:false});
  assert.strictEqual(r.ok,false,`item ${id} stock ${before}, but use returned ok=true`);
});
probe('JHS-002a','Multi-phase pill brew must reject absent herbs',()=>{
  const W=world('herb_less'),n=W.npcs[0],id='ITEM_V234_PILL_001';
  emptyStock(W,'herb');assert.equal(ECO.count(W,'herb'),0);
  const r=ECO.brewMultiPhaseSpecialtyPill(W,n,id,{herbCost:2,stoneCost:25,qty:1});
  assert.strictEqual(r.ok,false,'brewing succeeded with zero of two required herbs');
});
probe('JHS-002b','Multi-phase pill cost must scale with qty',()=>{
  const W=world('qty_undercharge'),n=W.npcs[0],id='ITEM_V234_PILL_001';
  const before=W.sect.stones;
  const r=ECO.brewMultiPhaseSpecialtyPill(W,n,id,{herbCost:2,stoneCost:25,qty:500});
  assert(!(r.ok && r.qtyBrewed===500 && before-W.sect.stones===25),'500 pills created for only 25 stones and no herbs');
});
probe('JHS-003','One stored 3-charge talisman cannot spawn two independent 2-charge allocations',()=>{
  const W=world('talisman_double_claim'),a=W.npcs[0],b=W.npcs[1],id='ITEM_V234_TAL_001';
  emptyStock(W,id);ECO.add(W,id,1);
  const first=ECO.useConsumableItem(W,a,id);
  const second=ECO.useConsumableItem(W,b,id);
  assert(!(first.ok && second.ok && (a.ext.talismanCharges[id]||0)>=2 && (b.ext.talismanCharges[id]||0)>=2),'single 3-charge talisman allocated to two NPCs with 4 charges remaining');
});
probe('JHS-004','Combat and ritual state must survive save/load',()=>{
  const W=world('underscore_save'),n=W.npcs[0];
  const fields={_divineStrain:90,_duetCdUntil:W.t+16,_ccImmuneUntil:W.t+24,_boneArmorHp:7,_lastGearSwapAt:W.t,_ccDrStacks:2};
  Object.assign(n,fields);const L=SIM.deserialize(SIM.serialize(W)).byId[n.id];
  for(const [key,val] of Object.entries(fields)) assert.strictEqual(L[key],val,`${key}: ${val} became ${String(L[key])}`);
});
probe('JHS-005a','Future 5.8.0 schema cannot silently down-convert to 2.3.0',()=>{
  const s=JSON.parse(SIM.serialize(world('future_version')));
  s.schemaVersion='5.8.0-forbidden-arts-passive-awakening-and-blood-altar';s.patchVersion='5.8.0';
  assert.throws(()=>SIM.deserialize(JSON.stringify(s)));
});
probe('JHS-005b','Invalid patchVersion string must be rejected',()=>{
  const s=JSON.parse(SIM.serialize(world('invalid_version')));s.patchVersion='invalid-version';
  assert.throws(()=>SIM.deserialize(JSON.stringify(s)));
});
probe('JHS-006','Unknown-for-this-executor item effect must not masquerade as success with generic fervor buff',()=>{
  const W=world('effect_fallback'),n=W.npcs[0];
  assert.equal(STATS.has(n,'fervorMight',W.t),false);
  const result=ECO.executeItemEffectById(W,n,'EFX_CARGO_PRESERVATION');
  assert(!(result.ok && STATS.has(n,'fervorMight',W.t)),'cargo preservation returned ok and only applied generic combat fervor buff');
});
probe('JHS-007','Duet cast must be invoked somewhere in the shipping runtime, not just tests',()=>{
  const dir=path.join(__dirname,'GAME_SOURCE/js');
  const sources=fs.readdirSync(dir).filter(f=>f.endsWith('.js')).map(f=>fs.readFileSync(path.join(dir,f),'utf8'));
  const runtimeCalls=sources.flatMap(s=>[...s.matchAll(/\b(?:C|COMBAT|g\.COMBAT)\.tryExecuteDuetSkill\s*\(/g)]);
  assert(runtimeCalls.length>0,'no runtime invocation of tryExecuteDuetSkill detected');
});
probe('JHS-008','Special path duet IDs must be used outside their catalog declaration',()=>{
  const dir=path.join(__dirname,'GAME_SOURCE/js');
  const source=fs.readdirSync(dir).filter(f=>f.endsWith('.js')).map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n');
  const ids=['DUET_BUSHIDO_SHINOBI_ECLIPSE','DUET_PANTHEON_TWIN_AVATAR','DUET_OCCULT_GRAVE_REQUIEM','DUET_ASTRAL_CHRONO_CONVERGENCE','DUET_DRAGON_TIDE_HARMONY'];
  for(const id of ids) { const count=source.split(id).length-1;assert(count>=3,`${id} appears only in catalog key + id value, count=${count}`); }
});
probe('JHS-009','Both duet participants must obey cooldown',()=>{
  const W=world('partner_cd'),a=W.npcs[0],b=W.npcs[1];
  a.x=51;a.y=50;b.x=52;b.y=50;
  a.companionId=b.id;b.companionId=a.id;
  const t={id:'FOE_PROBE',foe:true,name:'dummy',tier:3,hp:100000,hpMax:100000,x:53,y:50};
  W.foes.push(t);W.foeById[t.id]=t;
  const f=COMBAT.startFight(W,[a.id,b.id],[t.id],'spar',{serious:false});
  assert(COMBAT.tryExecuteDuetSkill(W,f,a,b,t).ok);
  a._duetCdUntil=0;
  assert(b._duetCdUntil>W.t);
  const second=COMBAT.tryExecuteDuetSkill(W,f,a,b,t);
  assert.strictEqual(second.ok,false,'partner cooling down, but second cast executed');
});
probe('JHS-010','Charged skill entrypoint must be wired into shipping runtime',()=>{
  const dir=path.join(__dirname,'GAME_SOURCE/js');
  const s=fs.readdirSync(dir).filter(f=>f.endsWith('.js')).map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n');
  assert(/\b(?:C|COMBAT|g\.COMBAT)\.startChargedSkill\s*\(/.test(s),'no runtime caller of startChargedSkill; existing generic channeling is a separate mechanic');
});
probe('JHS-011','Boss anatomy breaking must be called by fight engine',()=>{
  const dir=path.join(__dirname,'GAME_SOURCE/js');
  const s=fs.readdirSync(dir).filter(f=>f.endsWith('.js')).map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n');
  assert(/\b(?:ANATOMY_BREAKER|COMBAT\.ANATOMY_BREAKER|C\.ANATOMY_BREAKER)\.damageBossPart\s*\(/.test(s),'no runtime invocation of damageBossPart found');
});
probe('JHS-012','Custom pill registrations from imported saves must not leak to unrelated new games',()=>{
  const W=world('global_pill'),id='AUDIT_PILL_LEAK_2026';const raw=JSON.parse(SIM.serialize(W));
  raw.sect.customPills={...(raw.sect.customPills||{}),[id]:{id,nameTh:'audit',tier:1,kind:'PILL',effects:[]}};
  assert(SIM.deserialize(JSON.stringify(raw)).sect.customPills[id]);
  const fresh=world('unrelated_new_game');
  const leaked=!!ECO.getItem(id)&&!(fresh.sect.customPills||{})[id];
  delete ECO.itemById[id]; if(ECO.v235ItemById) delete ECO.v235ItemById[id];
  assert(!leaked,'fresh game sees pill definition from a different saved world');
});
const reds=log.filter(x=>x.result==='RED');
console.log(`\nRED ${reds.length}/${log.length}, GREEN ${log.length-reds.length}/${log.length}`);
console.log('All RED cases are expected against the original unpatched file. Re-run after code fixes.');
