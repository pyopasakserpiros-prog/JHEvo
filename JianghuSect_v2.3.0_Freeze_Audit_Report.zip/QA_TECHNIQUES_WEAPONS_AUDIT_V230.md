# JianghuSect 2 v2.3.0 — ตรวจวิชา วิถี/สายย่อย และวิชาสำหรับอาวุธ–อุปกรณ์
> **หมวดที่ 8 แยกจากหมวดการต่อสู้และหมวดอุปกรณ์เดิม** · 8 พฤศจิกายน 2026 · **Read-only: ไม่แก้ซอร์สเกม**

## 1. ข้อมูลฐานและผลสรุป
- ZIP เกม SHA-256: `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`; ใช้ต้นฉบับ v2.3.0 ที่ผู้ใช้อัปโหลด ไม่ใช่โค้ดเวอร์ชันอื่นจากเอกสาร AGENTS.md ที่มีข้อมูลเก่าใหม่ปะปน
- อ่าน `AGENTS.md`, `.agents/skills/combat-design`, `game-data-integrity`, `progression-design`, `qa-test-matrix`, onboarding และโค้ดจากชุดไฟล์นี้ก่อนตรวจ
- ตรวจทะเบียน **1,702 เทคนิค/วิชา + 122 คัมภีร์ = 1,824 records**, ตรวจ profile ที่รันได้ **2,603 กระบวนท่า/โปรไฟล์** (จำนวนที่ประกาศ `moveDefs` แยกอาจน้อยกว่า), **43 วิถี**, **286 สายย่อย**, **16 ประเภทอาวุธ** และสถานะที่ใช้อยู่ใน `SK.STATUS` 109 ชื่อ
- กลุ่มตรวจพบ **7 ประเด็นบัค/ความไม่สอดคล้องเชิงพฤติกรรม** (TECH-01–07), **2 กลุ่มทบทวนสมดุล/เจตนา** (TECH-08–09) และ **1 กลุ่มข้อเสนอเนื้อหา** (TECH-10).
- ทดสอบด้วย runtime Node **14 เคส** (บางเคสเป็น schema/design scan ที่ไม่ใช่บัค), ชุด regression เดิมที่เกี่ยวข้อง **6 ชุดผ่านทั้งหมด** เมื่อรันเดี่ยว. ไม่มีการอ้างว่า test 2,603 move แบบเล่นจริงครบ.

**การตัดสิน Release Gate:** ยังไม่ผ่าน เพราะ TECH-01 / TECH-02 / TECH-04 และ TECH-03 (หลังยืนยันความหมาย schema) ส่งผลต่อเงื่อนไขหรือพลังวิชาที่ผู้เล่นใช้จริง และยังมี P0/P1 ในรายงานก่อนหน้าที่ต้องปิด

## 2. Bug Register: สิ่งที่พิสูจน์และสิ่งที่เป็นเพียงข้อเสนอ
| ID | ระดับ | ประเด็น |
|---|---|---|
| TECH-01 | P1 | อาวุธและเกราะจำแนกประเภทผิดจากชนิดที่กำหนดไว้ |
| TECH-02 | P1 | สวมอุปกรณ์แล้วใช้ท่าที่สูงกว่าขั้นบ่มเพาะและความชำนาญ |
| TECH-03 | P1 / DESIGN-CONFIRM | โบนัสธาตุ/ประเภทจาก skillModifiers ทำงานกว้างเกินข้อมูล |
| TECH-04 | P1 | กระบวนท่าขั้นสอง 4 วิชาปลดล็อกไม่ได้ |
| TECH-05 | P2 | UI บอกเลือกท่าได้แม้อาวุธบังคับไม่พร้อม |
| TECH-06 | P2 | แคชรายการวิชาไม่อัปเดตเมื่อ modifier เปลี่ยนบนอุปกรณ์ UID เดิม |
| TECH-07 | P2 / INTERNAL | เปลี่ยนวิชากลางอาร์เรย์จำนวนเท่าเดิมแล้ว SK.list ค้าง |
| TECH-08 | REVIEW | อุปกรณ์ประจำวิถีอาจยอมมอบวิชาข้ามวิถี |
| TECH-09 | BALANCE-REVIEW | วิชาดาเมจสูงและวิชาไร้ต้นทุน: ห้ามจัดว่าโกงจาก M ดิบ |
| TECH-10 | CONTENT-PLAN | ความหนาแน่นวิถี/สายย่อย/อาวุธไม่เท่ากัน |

### TECH-01 — อาวุธและเกราะจำแนกประเภทผิดจากชนิดที่กำหนดไว้ [P1]
- **หลักฐาน:** PT-GEAR-TYPE-REAL; 24 WEAPON + 12 ARMOR; ECO.mintGear(EQ_V234_WPN_053) ให้ SWORD ทั้งที่ weaponType=BOW
- **จุดโค้ด/ข้อมูล:** js/martial.js:639,1358; js/economy.js:372–387; data itemById EQ_V234_WPN_017–118 / ARM_002 เป็นต้น
- **ต้นเหตุ:** gearType ของอุปกรณ์บางรุ่นไม่ถูกคัดลอกจาก weaponType/armorType/subType แต่เดาประเภทจาก nameTh ซึ่งประกอบชื่อไอเทมหลายหมวด
- **ผลกระทบลูกโซ่:** การผลิต/รับดรอป → อาวุธกลายเป็นประเภทอื่น → requiredWeapon ของวิชาและระยะโจมตีผิด → AI จัดอาวุธผิด → DPS/ผลศึก/การบาดเจ็บ/การตาย/รางวัลผิด
- **แนวแก้ต้นทาง:** กำหนดชนิด canonical จากข้อมูล item ที่มีชนิดชัดเจนก่อน fallback classify(nameTh); ตรวจ mint/procedural/dropped gear และ UI แล้วอัปเดต cache
- **เกณฑ์ผ่าน:** mint เทียบรายการ 36 ชิ้นทุกชิ้นต้องรักษาชนิดที่ declare และวิชา BOW/ARMOR ตามประเภทจริงใช้ได้

### TECH-02 — สวมอุปกรณ์แล้วใช้ท่าที่สูงกว่าขั้นบ่มเพาะและความชำนาญ [P1]
- **หลักฐาน:** PT-EQUIP-GRANT-EARLY; stage1 equips EQ_V234_WPN_025 → TECH_V234_XIAN_ACT_03_M1/M2 require cultivation3; SK.canSelectMove=true
- **จุดโค้ด/ข้อมูล:** js/martial.js:1271–1290,1343–1354; js/skills.js:606–619
- **ต้นเหตุ:** grantedSkills ผ่าน gate ที่ระดับไอเทมเท่านั้น; SK.list ใช้ SK.allMoves(t).slice(0,2) ข้าม unlockedMoves+reqCultStage/reqMastery
- **ผลกระทบลูกโซ่:** คราฟต์/แลกอาวุธ → ได้วิชาขั้นสูงทั้งที่ยังไม่ฝึก → กำจัดบอส/ผ่านหอ/ชิงทรัพยากรก่อนระดับ → เศรษฐกิจและความก้าวหน้าถูกเร่ง → เซฟเก็บสถานะ
- **แนวแก้ต้นทาง:** กำหนดกติกา Equipment Grant ระบุ override ที่ตั้งใจ (tier cap explicit) และ default ให้ใช้ SK.unlockedMoves รวม reqCultStage/reqMastery; ตรวจ item minStage จากข้อมูลจริง
- **เกณฑ์ผ่าน:** stage1 ไม่เลือกหรือใช้ move ที่ reqCultStage3; ตัวละครถึงขั้น/ความชำนาญตามกฎแล้วใช้ได้; อุปกรณ์ไม่ให้เรียนวิชาถาวร

### TECH-03 — โบนัสธาตุ/ประเภทจาก skillModifiers ทำงานกว้างเกินข้อมูล [P1 / DESIGN-CONFIRM]
- **หลักฐาน:** PT-ELEMENT-MOD, PT-SCHEMA-MOD-MATCH; EQ_V234_WPN_001 FIRE +14% ให้ WATER_ICE (M=1.25→1.43), 277 mod มี element แต่ 0 ใช้ matchElement
- **จุดโค้ด/ข้อมูล:** js/martial.js:1306–1339; ECO.itemById.*.skillModifiers
- **ต้นเหตุ:** ตัวกรองอ่าน matchElement/matchArch/matchTechId แต่ข้อมูลจริงบันทึก element (277) / weaponType (120) แทน
- **ผลกระทบลูกโซ่:** อาวุธเฉพาะธาตุ → บัฟทุกท่ารวมธาตุตรงข้าม → คอมโบ/ดาเมจ/สถานะ/ยิงหลายครั้งแรงเกิน → build meta บิด → AI เลือกผิด
- **แนวแก้ต้นทาง:** ยืนยันก่อนว่า element/weaponType เป็น metadata หรือเงื่อนไขที่ตั้งใจ; หากเป็น gate ให้ normalize schema หรือแก้ producer/consumer และทำ test ตรง/ไม่ตรงธาตุ
- **เกณฑ์ผ่าน:** วิชา FIRE เทียบ WATER_ICE ได้โบนัสเฉพาะตาม design; เปลี่ยนอุปกรณ์แล้ว stats/skill ทันทีไม่ค้าง

### TECH-04 — กระบวนท่าขั้นสอง 4 วิชาปลดล็อกไม่ได้ [P1]
- **หลักฐาน:** PT-UNREACH-MP_STAFF_WALL / MP_SPEAR_LINE / MP_BLADE_SHADOW / MP_FOCUS_SEAL; mastery=99999 ยังได้ stage1
- **จุดโค้ด/ข้อมูล:** js/skills.js:501–515,528–539; technique definitions 4 IDs
- **ต้นเหตุ:** moveDefs.stageReq=2 แต่ t.stages ไม่มี, unlockedStage() คืน 1
- **ผลกระทบลูกโซ่:** ฝึกวิชา/ใช้ทรัพยากร → ท่าที่สองล็อกถาวร → ผู้เล่นลงทุนสูญเปล่า → AI/บิลด์สำนักไม่ครบ
- **แนวแก้ต้นทาง:** เพิ่ม stages ระดับ2 ที่สอดคล้องความชำนาญ/ขั้น หรือแก้ gate ตาม design; ห้ามปลดฟรีแบบไม่ตรวจ
- **เกณฑ์ผ่าน:** mastery และ cultivation ถึง requirement จึงปลดท่า2 ได้; ต่ำกว่า requirement ยังไม่ได้

### TECH-05 — UI บอกเลือกท่าได้แม้อาวุธบังคับไม่พร้อม [P2]
- **หลักฐาน:** PT-SELECT-REQUIRED; MP_BOW_IRON_DRAW_T1 canSelectMove=true มือเปล่า แต่ weaponCanUse=false, skillEfficiency=0
- **จุดโค้ด/ข้อมูล:** js/skills.js:545–556; js/martial.js:385–395,651–659; js/combat.js:1844–1845,1938
- **ต้นเหตุ:** canSelectMove ตรวจ ownership/ความชำนาญ ไม่ตรวจ compatibility ที่การต่อสู้ปฏิเสธ
- **ผลกระทบลูกโซ่:** ผู้เล่นเห็นปุ่มกดได้ → ตั้งท่าที่ออกไม่ได้ → AI หลีกเลี่ยง/ทำท่าพื้นฐาน → เข้าใจผิดว่าเกมไม่ตอบสนอง
- **แนวแก้ต้นทาง:** ปรับ UI/selection ให้เรียก gate สถานะเดียวกับ combat, พร้อมข้อความอาวุธจำเป็น
- **เกณฑ์ผ่าน:** ไม่อนุญาต select move ที่ requiresWeapon แต่ไม่ตรง; สวมถูกและไม่พังแล้วเลือกได้

### TECH-06 — แคชรายการวิชาไม่อัปเดตเมื่อ modifier เปลี่ยนบนอุปกรณ์ UID เดิม [P2]
- **หลักฐาน:** PT-CACHE-SKILL-MOD; เปลี่ยน multPct จาก .10→1.50 แต่ SK.list ยังแสดง M=1.38; invalidate แล้ว M=3.13
- **จุดโค้ด/ข้อมูล:** js/skills.js:585–593,632; js/martial.js:1306–1339
- **ต้นเหตุ:** _skListCache.eqKey ใช้ UID/ID ไม่ใช้ version ของ skillModifiers/runes/quality
- **ผลกระทบลูกโซ่:** ตีรูน/ปรับอุปกรณ์ → UI ดาเมจและรายการท่าค้าง → AI/เซฟใช้อัตราเก่าจน invalidate → ผู้เล่นเห็นผลไม่แน่นอน
- **แนวแก้ต้นทาง:** เพิ่ม equipmentSkillsVersion และ invalidate ทุกครั้งที่เปลี่ยน modifier, enchant, durability, grant, UID; อย่า stringify ทั้ง object ทุก tick
- **เกณฑ์ผ่าน:** อัปเกรดบน UID เดิมให้ผลใหม่ใน SK.list ทันทีและตรงการคำนวณรอบถัดไป

### TECH-07 — เปลี่ยนวิชากลางอาร์เรย์จำนวนเท่าเดิมแล้ว SK.list ค้าง [P2 / INTERNAL]
- **หลักฐาน:** PT-CACHE-MIDDLE; techs[1] เปลี่ยนจาก ART190_XIAN_002→004 แต่ SK.list ไม่เปลี่ยนจน invalidate
- **จุดโค้ด/ข้อมูล:** js/skills.js:585–593,632
- **ต้นเหตุ:** cache key เทียบเพียง tl,t0,tL ไม่เก็บ revision/digest รายชื่อ
- **ผลกระทบลูกโซ่:** ระบบสอน/ถอนวิชา/เปลี่ยนช่อง → รายชื่อท่าปัจจุบันผิด → AI เลือกไม่ตรง → ผู้เล่นเข้าใจว่าเรียนใหม่ไม่ติด
- **แนวแก้ต้นทาง:** ให้ mutation เส้นทางเดียวเพิ่ม techLoadoutVersion และ invalidate ใน teach/unlearn/retrain/equip/deserialize
- **เกณฑ์ผ่าน:** เปลี่ยนสมาชิกกลางแล้วรายการท่าอัปเดต; save/load คง revision ถูกต้อง

### TECH-08 — อุปกรณ์ประจำวิถีอาจยอมมอบวิชาข้ามวิถี [REVIEW]
- **หลักฐาน:** PT-GRANT-CROSSPATH; EQ_V234_WPN_002 path BODY แต่ reqPath=null, XIAN ได้ TECH_V234_BODY_ACT_01
- **จุดโค้ด/ข้อมูล:** data EQ_V234_WPN_002; js/martial.js:1279–1288
- **ต้นเหตุ:** schema มี path สำหรับ flavor/bonus และ reqPath สำหรับ gate; บางรายการ reqPath=null ตามจริง
- **ผลกระทบลูกโซ่:** ผู้เล่นข้ามสายด้วยอุปกรณ์ → เกิด build ใหม่ที่อาจตั้งใจ แต่ถ้าเป็นข้อจำกัดจะลบเอกลักษณ์วิถี
- **แนวแก้ต้นทาง:** ยืนยัน design cross-path ของ gear grants ก่อนใส่ gate โดยอัตโนมัติ
- **เกณฑ์ผ่าน:** เกมและ UI บอกชัดว่าสวมข้ามวิถีได้หรือไม่; ทดสอบ both cases

### TECH-09 — วิชาดาเมจสูงและวิชาไร้ต้นทุน: ห้ามจัดว่าโกงจาก M ดิบ [BALANCE-REVIEW]
- **หลักฐาน:** 34 profiles มี M×hits>15; 2 profiles M×hits>4 costPct=0; วิชาต้องห้ามมี CD สูง/ต้นทุนอื่น; SHADOW_SAMURAI เป็นวิถีไร้ปราณ
- **จุดโค้ด/ข้อมูล:** SK.moveProfile, SK.qiCost, COMBAT.chooseSkill and strike; TECHNIQUE_EACH_MOVE_QA.csv
- **ต้นเหตุ:** เครื่องคัดเบื้องต้นใช้ M×hits ไม่รวมนโยบาย Qi, HP cost, windup, range, proc, enemy defense, role and encounter progression
- **ผลกระทบลูกโซ่:** เนิร์ฟ M ผิด → วิถีไร้ปราณเสียเอกลักษณ์; ไม่ตรวจ proc ถูก → บิลด์ combo หลุด balance
- **แนวแก้ต้นทาง:** จำลอง duel/pve/pvp เทียบ stage + gear parity + RNG seeds + burst/sustain + Qi/HP cost + roles before nerf
- **เกณฑ์ผ่าน:** มี DPS/EHP/useful utility distribution ตาม tier/build และ meta อธิบายได้

### TECH-10 — ความหนาแน่นวิถี/สายย่อย/อาวุธไม่เท่ากัน [CONTENT-PLAN]
- **หลักฐาน:** 43 paths mean 39.91 median19; 31 ต่ำกว่า mean; 286 subpaths mean5.16 median4; 202 ต่ำกว่า mean, 114 ต่ำกว่า median; JADE_IMMORTAL_BODY มี 1; ABACUS 56 associated; 6 new weapon classes have 0 requiresWeapon
- **จุดโค้ด/ข้อมูล:** JD.CULT.paths, JD.TECH.techniques, JD.MARTIAL.types, generated coverage tables
- **ต้นเหตุ:** กลุ่มวิถีใหม่ถูกเติมแบบ broad parity แต่ยังไม่เท่า depth วิถีเก่า; ชุดใหม่เน้นการแสดงบทบาทผ่าน innate/composable
- **ผลกระทบลูกโซ่:** ตัวเลือกที่มีน้อย → ผู้เล่นเกิดบิลด์ซ้ำ/ต้องพึ่งวิชาสากล → ศาสตราบางชนิดรู้สึกไร้เอกลักษณ์ แม้มี innate จริง
- **แนวแก้ต้นทาง:** หลังปิด release bugs ให้ทยอยเพิ่มความหลากหลายตาม role, ไม่เติมจำนวนเพียงเพื่อดันค่าเฉลี่ย; ใช้ตาราง 43/286/16 และแยก native vs universal
- **เกณฑ์ผ่าน:** แต่ละ sub ที่อ่อนมีทางเลือก offensive + defensive/utility ที่ได้จาก source จริง, AI ใช้, ค่าร่าย/การได้มาสมเหตุสมผล

## 3. ตารางความหนาแน่นแยก 43 วิถีหลัก
- ค่าเฉลี่ยวิชาประจำวิถี (ไม่รวม path ANY) = **39.91**, ค่ามัธยฐาน = **19**, วิถีต่ำกว่าค่าเฉลี่ย = **31 วิถี**. **ห้ามแปลว่า 31 วิถีต้องเติม 20 วิชาทันที** เพราะรุ่นเนื้อหาและกลไกต่างกัน
- การนับเป็น `tech.path` ตามทะเบียนหลัก; ไม่บวกเทคนิค ANY, วิชาสากล หรือที่ยืมข้ามสายเป็นวิชาประจำทุกวิถี เพื่อป้องกันการปกปิดช่องว่าง
| รหัสวิถี | ชื่อวิถี | สายย่อย | วิชาประจำ | ใช้งาน/มีท่า | profiles |
|---|---|---|---|---|---|
| XIAN | วิถีเซียน | 16 | 198 | 136 | 227 |
| BODY | วิถีกายา | 16 | 183 | 130 | 212 |
| GOD | วิถีเทพ | 13 | 158 | 116 | 184 |
| DEMON | วิถีมารอสูร | 10 | 95 | 72 | 137 |
| HEART_SOUL | วิถีจิต·เซน | 10 | 106 | 80 | 151 |
| MECH_PUPPET | วิถีกลจักร | 10 | 55 | 42 | 89 |
| KARMA_SAMSARA | วิถีกรรมวัฏ | 10 | 58 | 46 | 94 |
| BEAST_SOVEREIGN | วิถีราชันย์อสูร | 10 | 55 | 43 | 88 |
| SAGE_SUPPORT | วิถีปราชญ์หนุนนำ | 10 | 55 | 42 | 98 |
| CRAFT_CREATION | วิถีรังสรรค์ | 12 | 69 | 48 | 99 |
| ARRAY_TALISMAN | ค่ายกลยันต์ | 7 | 55 | 37 | 75 |
| STRATEGY_GOVERNANCE | พิชัยอภิบาล | 8 | 55 | 37 | 72 |
| ASTRO_DIVINATION | โหราดวงดาว | 6 | 18 | 14 | 34 |
| BUDDHA_DHARMA | พุทธธรรม | 6 | 19 | 15 | 35 |
| VOID_SPACE | สุญญตามิติ | 6 | 18 | 14 | 34 |
| SONIC_HARMONY | คีตายุทธ | 6 | 18 | 14 | 34 |
| VENOM_GU | พิษหนอนกู่ | 6 | 19 | 15 | 35 |
| PRIMORDIAL_SHIFTER | แปลงกายบรรพกาล | 6 | 19 | 15 | 35 |
| CELESTIAL_WEATHER | เทวอากาศ | 6 | 19 | 15 | 35 |
| WANDERING_DAO | จาริกพิภพ | 6 | 18 | 14 | 34 |
| MERCANTILE_DAO | พาณิชย์มรรคา | 6 | 19 | 15 | 35 |
| DRAGON_VEIN_GEOMANCY | มังกรธรณี | 6 | 19 | 15 | 35 |
| GRAVITY_DAO | แรงโน้มถ่วง | 6 | 19 | 15 | 35 |
| CHRONO_EPOCH | กาลเวลา | 6 | 19 | 15 | 35 |
| INK_LITERATI | อักษรปราชญ์ | 6 | 18 | 14 | 34 |
| SOUL_PUPPETRY | เชิดเงาวิญญาณ | 6 | 19 | 15 | 35 |
| PRIMORDIAL_CHAOS | โกลาหลต้นกำเนิด | 6 | 18 | 14 | 34 |
| SHADOW_SAMURAI | ซามูไรไร้เงา | 4 | 18 | 14 | 28 |
| NINPO_SHADOW | นินจาเร้นเงา | 4 | 19 | 15 | 29 |
| NINPO_ELEMENTAL | นินจาคาถาธาตุ | 4 | 19 | 15 | 29 |
| DIVINE_SUMMONER | อัญเชิญเทวะ | 4 | 19 | 15 | 29 |
| DIVINE_POSSESSION | เทวะสถิตร่าง | 4 | 18 | 14 | 28 |
| DIVINE_CHANNELER | ยืมพลังเทวะ | 4 | 18 | 14 | 28 |
| VOID_HERETIC_PACT | สัญญานอกมิติ | 4 | 18 | 14 | 28 |
| OCCULT_MAGE | จอมขมังเวท | 4 | 18 | 14 | 28 |
| DEVOURING_FLESH | กลืนหลอมสรีระ | 4 | 19 | 15 | 29 |
| NETHER_GRAVE | สุสานยมโลก | 4 | 18 | 14 | 28 |
| ANCESTRAL_RITUAL | พิธีบรรพชน | 4 | 18 | 14 | 28 |
| TIDE_VOYAGER | นาวิกสมุทร | 4 | 19 | 15 | 29 |
| LORE_ARCHIVIST | อาลักษณ์หอคัมภีร์ | 4 | 19 | 15 | 29 |
| FORTUNE_GAMBLER | เดิมพันชะตา | 4 | 19 | 15 | 29 |
| SPIRIT_HUSBANDRY | เกษตรวิญญาณ | 4 | 18 | 14 | 28 |
| ARENA_GLORY | เกียรติยุทธ์ประลอง | 4 | 18 | 14 | 28 |

## 4. ตาราง 286 สายย่อย: เกณฑ์จัดลำดับเติมวิชา
- วิชาเฉพาะสายที่เชื่อมด้วย `sub / innateSubpath / reqSubpath` เฉลี่ย **5.16** มัธยฐาน **4**; สายที่ต่ำกว่า mean = **202**, ต่ำกว่า median = **114**
- มี **1 สาย** ที่มีเฉพาะ innate 1 วิชา (`BODY / JADE_IMMORTAL_BODY`), **55 สาย** ที่มี 2 รายการ. ถือเป็นโอกาสเติมความหลากหลาย ไม่ได้แปลว่าใช้สกิลอื่นไม่ได้: วิชา cross-path/shared/universal ยังมีอยู่
- แผนงานระยะถัดไปหลังปิดบัค: สาย 1 รายการตั้งเป้าเพิ่ม 2–3 บทบาท, สาย 2 รายการเพิ่ม 1–2 บทบาทที่แตกต่าง; ยึด median 4 เป็น checkpoint ไม่ใช่กฎแข็งหรือเป้ารวมทุกวิถี

### สายย่อยที่มีวิชาเฉพาะสายเพียง 1–2 รายการ (รายชื่อเต็ม)
| วิถี | สายย่อย | ชื่อ | จำนวน | ไม่ใช่ innate | profiles |
|---|---|---|---|---|---|
| XIAN | YIN_YANG_HARMONY | สายหยินหยางหมุนเวียนไร้ลักษณ์ | 2 | 1 | 5 |
| BODY | JADE_IMMORTAL_BODY | สายกายาหยกพิสุทธิ์หมื่นพิษไม่กล้ำกราย | 1 | 0 | 2 |
| GOD | MEDICINE_BODHI_GOD | สายเทพโอสถโพธิญาณ | 2 | 1 | 3 |
| KARMA_SAMSARA | LOTUS_MERCY_PURIFIER | สายปทุมโปรดสัตว์ชำระบาป | 2 | 1 | 3 |
| KARMA_SAMSARA | BODHI_VOW_GUARDIAN | สายมหาปณิธานโพธิสัตว์คุ้มภพ | 2 | 1 | 3 |
| BEAST_SOVEREIGN | SYMBIOTIC_BEAST_WARRIOR | สายนักรบผสานร่างอสูรคลั่ง | 2 | 1 | 3 |
| BEAST_SOVEREIGN | COLOSSUS_SHIELD_TAMER | สายปราการอสูรยักษ์พิทักษ์สำนัก | 2 | 1 | 3 |
| BEAST_SOVEREIGN | CELESTIAL_ASTRAL_FAIRY_TAMER | สายพันธะสัตว์เทพดาราและภูตพฤกษา | 2 | 1 | 3 |
| SAGE_SUPPORT | QIMEN_TALISMAN_PATRON | สายปรมาจารย์ยันต์ฉีเหมินคุ้มทัพ | 2 | 1 | 4 |
| SAGE_SUPPORT | WAR_BANNER_CHORISTER | สายขุนพลธงศึกปลุกขวัญสวรรค์ | 2 | 1 | 4 |
| SAGE_SUPPORT | WOOD_SPIRIT_SYMBIONT | สายทูตพฤกษาวิญญาณค้ำชูโลก | 2 | 1 | 4 |
| ASTRO_DIVINATION | METEOR_OMEN_CALLER | สายอัญเชิญดาวตกพิพากษา | 2 | 1 | 5 |
| ASTRO_DIVINATION | QIMEN_EIGHT_GATES_DIVINER | สายฉีเหมินแปดประตูพยากรณ์ | 2 | 1 | 5 |
| ASTRO_DIVINATION | BIG_DIPPER_LONGEVITY_SAGE | สายกระบวยดาราต่อชะตา | 2 | 1 | 5 |
| BUDDHA_DHARMA | THOUSAND_PALM_BODHISATTVA | สายโพธิสัตว์พันกรการุญ | 2 | 1 | 5 |
| BUDDHA_DHARMA | RELIC_PAGODA_KEEPER | สายผู้พิทักษ์เจดีย์พระธาตุ | 2 | 1 | 5 |
| BUDDHA_DHARMA | KARMA_FIRE_ASCETIC | สายธุดงค์เพลิงกัลป์เผาวิบาก | 2 | 1 | 5 |
| VOID_SPACE | SINGULARITY_COLLAPSE_MAGE | สายยุบตัวจุดอนันต์สุญตา | 2 | 1 | 5 |
| VOID_SPACE | PHASE_MIRAGE_ASSASSIN | สายเร้นเงาเหลื่อมมิติ | 2 | 1 | 5 |
| VOID_SPACE | SPATIAL_BARRIER_WARDEN | สายกำแพงกระจกมิติสะท้อน | 2 | 1 | 5 |
| SONIC_HARMONY | RESONANT_BELL_EXORCIST | สายกระดิ่งกังวานสลายมาร | 2 | 1 | 5 |
| SONIC_HARMONY | SILENT_WAVE_ASSASSIN | สายคลื่นเสียงไร้รูปสังหารเงียบ | 2 | 1 | 5 |
| SONIC_HARMONY | CELESTIAL_CHOIR_CONDUCTOR | สายวาทยกรสวรรค์ประสานคีตา | 2 | 1 | 5 |
| VENOM_GU | CORROSIVE_MIASMA_WEAVER | สายทอหมอกพิษกัดกร่อนเกราะ | 2 | 1 | 5 |
| VENOM_GU | SCORPION_CLAW_EXECUTIONER | สายกรงเล็บแมงป่องพิษบรรพกาล | 2 | 1 | 5 |
| VENOM_GU | IMMORTAL_NECTAR_TOXIN_SAGE | สายพิษสลับอมฤตช่วยชีวิต | 2 | 1 | 5 |
| PRIMORDIAL_SHIFTER | BLACK_TORTOISE_SHELL_COLOSSUS | สายกระดองเต่าดำสะท้อนศาสตรา | 2 | 1 | 5 |
| PRIMORDIAL_SHIFTER | FIEND_APE_TITAN_MORPH | สายแปลงร่างวานรยักษ์ถล่มขุนเขา | 2 | 1 | 5 |
| PRIMORDIAL_SHIFTER | NINE_TAIL_MIRAGE_SHIFTER | สายจำแลงจิ้งจอกเก้าหางพันหน้า | 2 | 1 | 5 |
| CELESTIAL_WEATHER | TYPHOON_GALE_SOVEREIGN | สายจ้าวพายุไต้ฝุ่นกวาดสมรภูมิ | 2 | 1 | 5 |
| CELESTIAL_WEATHER | MIRAGE_FOG_SHROUDER | สายม่านหมอกลวงตาปิดกั้นสัมผัส | 2 | 1 | 5 |
| CELESTIAL_WEATHER | SOLAR_ZENITH_INVOKER | สายอัญเชิญแสงสุริยันกลางหาว | 2 | 1 | 5 |
| WANDERING_DAO | WILDERNESS_BEAST_TRACKER | สายพรานแกะรอยอสูรแดนเถื่อน | 2 | 1 | 5 |
| WANDERING_DAO | CLOUD_STEP_HERMIT | สายฤๅษีเหยียบเมฆาเร้นกาย | 2 | 1 | 5 |
| WANDERING_DAO | REALM_MAPPER_CHRONICLER | สายนักเขียนแผนที่หมื่นพิภพ | 2 | 1 | 5 |
| MERCANTILE_DAO | TREASURE_APPRAISER_SAGE | สายปราชญ์ประเมินศาสตราและของวิเศษ | 2 | 1 | 5 |
| MERCANTILE_DAO | DEBT_FORECLOSURE_ENFORCER | สายทวงหนี้วิบากและยึดครองพลัง | 2 | 1 | 5 |
| MERCANTILE_DAO | EQUITY_SHIELD_CHANCELLOR | สายเสนาบดีคลังสมดุลทองคำ | 2 | 1 | 5 |
| DRAGON_VEIN_GEOMANCY | EARTH_DRAGON_AWAKENER | สายปลุกชีพมังกรดินสะเทือนภพ | 2 | 1 | 5 |
| DRAGON_VEIN_GEOMANCY | JADE_FAULT_CRUSHER | สายรอยเลื่อนหยกทลายปราการ | 2 | 1 | 5 |
| DRAGON_VEIN_GEOMANCY | SANCTUARY_PEAK_CUSTODIAN | สายผู้พิทักษ์ยอดเขาศักดิ์สิทธิ์ | 2 | 1 | 5 |
| GRAVITY_DAO | SINGULARITY_WELL_CONTROLLER | สายหลุมแรงโน้มถ่วงสะกดทัพ | 2 | 1 | 5 |
| GRAVITY_DAO | METEOR_WEIGHT_STRIKER | สายหมัดศิลาเพิ่มมวลพริบตา | 2 | 1 | 5 |
| GRAVITY_DAO | TIDAL_LOCK_ARBITER | สายแรงดึงดูดพันธนาการคู่ศึก | 2 | 1 | 5 |
| CHRONO_EPOCH | ACCELERATED_BLADE_FLASH | สายประกายดาบเร่งเวลาพริบตา | 2 | 1 | 5 |
| CHRONO_EPOCH | STASIS_SEAL_WARDEN | สายผนึกหยุดนิ่งชั่วนิรันดร์ | 2 | 1 | 5 |
| CHRONO_EPOCH | PAST_FUTURE_MIRROR_SAGE | สายกระจกส่องอดีตและอนาคต | 2 | 1 | 5 |
| INK_LITERATI | CLASSICS_LAW_ARBITER | สายปราชญ์บัญญัติกฎมณเฑียรบาล | 2 | 1 | 5 |
| INK_LITERATI | VERMILION_CRITIQUE_CENSOR | สายพู่กันชาดวิพากษ์สลายวิชา | 2 | 1 | 5 |
| INK_LITERATI | HISTORIANS_DESTINY_QUILL | สายอาลักษณ์จารึกพงศาวดารฟ้า | 2 | 1 | 5 |
| SOUL_PUPPETRY | CORPSE_FLAME_MARIONETTE | สายหุ่นเชิดเพลิงอสูรบรรพกาล | 2 | 1 | 5 |
| SOUL_PUPPETRY | MIRROR_SHADOW_TWIN | สายเงาแฝดกระจกสะท้อนสังหาร | 2 | 1 | 5 |
| SOUL_PUPPETRY | FATE_STRING_CONDUCTOR | สายบรรเลงด้ายชะตาควบคุมองคาพยพ | 2 | 1 | 5 |
| PRIMORDIAL_CHAOS | ENTROPY_FLAME_SOVEREIGN | สายเพลิงโกลาหลเผาผลาญกฎเกณฑ์ | 2 | 1 | 5 |
| PRIMORDIAL_CHAOS | GENESIS_LOTUS_CREATOR | สายบัวกำเนิดภพเนรมิตปราณ | 2 | 1 | 5 |
| PRIMORDIAL_CHAOS | ABYSSAL_CHAOS_HALBERD | สายทวนโกลาหลผ่าแยกฟ้าดิน | 2 | 1 | 5 |

**ทะเบียนครบทั้ง 286 สาย พร้อมจำนวน, บทบาท, gap และ tech IDs** อยู่ที่ `TECHNIQUE_SUBPATH_GAP_ACTIONS.csv`; ยึดไฟล์นี้เป็น input สั่ง AI สร้างเนื้อหาต่อ ต้องตรวจแหล่งเรียนและ usability จริงก่อนเพิ่ม

## 5. อาวุธ 16 ประเภท และอุปกรณ์ 3 ช่อง
- จำนวน associatedTech นับวิชาที่ประกาศ `weaponTypes` (วิชาหนึ่งอาจอยู่หลายประเภท) ไม่เท่ากับจำนวนวิชาที่จำเป็นต้องใช้อาวุธนั้น และไม่รับรองว่าใช้ได้โดยทุกวิถี
| ศาสตรา | วิชาที่เกี่ยว | บังคับใช้ | ไอเทม | วิชาแถมจากไอเทม | ขาด archetype ตรง |
|---|---|---|---|---|---|
| SWORD | 284 | 8 | 42 | 15 |  |
| BLADE | 248 | 14 | 43 | 14 |  |
| SPEAR | 294 | 17 | 50 | 17 |  |
| FIST | 277 | 0 | 32 | 7 |  |
| BOW | 264 | 18 | 28 | 0 |  |
| STAFF | 443 | 15 | 43 | 13 |  |
| FOCUS | 471 | 11 | 61 | 21 |  |
| ZITHER | 215 | 13 | 48 | 17 |  |
| BRUSH | 335 | 8 | 47 | 16 |  |
| WHIP | 229 | 10 | 45 | 14 |  |
| ROSARY | 108 | 0 | 17 | 8 | DEFENSE, SUPPORT, CONTROL, MOBILITY |
| CLAW | 90 | 0 | 18 | 10 | DEFENSE, SUPPORT, CONTROL, MOBILITY |
| NEEDLE | 111 | 0 | 19 | 8 | DEFENSE, SUPPORT, CONTROL, MOBILITY |
| FAN | 161 | 0 | 17 | 8 | DEFENSE, SUPPORT, CONTROL, MOBILITY |
| ASTROLABE | 138 | 0 | 20 | 10 | DEFENSE, SUPPORT, CONTROL, MOBILITY |
| ABACUS | 56 | 0 | 16 | 8 | DEFENSE, SUPPORT, CONTROL, MOBILITY |

- **6 ประเภทอาวุธใหม่ ROSARY, CLAW, NEEDLE, FAN, ASTROLABE, ABACUS มี requiresWeapon = 0 ทั้งหมด**: รูปแบบความถนัดมีแต่ขาดวิชาที่ผูกกับอาวุธนั้นแบบมีข้อกำหนดตรง ๆ. ถือเป็นช่องว่างเอกลักษณ์ ไม่ใช่บัคหรือข้อบังคับต้องทำก่อนปล่อย
- ชั้นเกราะ ARMOR `HEAVY/LIGHT/ROBE` และเครื่องประดับ `RING/NECKLACE/BRACELET/CHARM` ตรวจผลข้ามกับ gearType, grantSkill, skillModifiers; ตาราง mismatch 36 รายการแนบทั้ง JSON

## 6. ข้อเสนอเติมวิชาอย่างมีเอกลักษณ์ (ไม่ใช่บัค)
**ลำดับหลังปิด P0/P1 เท่านั้น**; อย่าเพิ่มจำนวนอย่างเดียว และห้ามเอา keyword ใหม่ไปแย่งหน้าที่ 109 สถานะเดิม
| วิถี/กลุ่ม | บทบาทที่ควรเติม | อาวุธ/อุปกรณ์ |
|---|---|---|
| BODY / JADE_IMMORTAL_BODY | โล่หยกกักแรง • ป้องกันตัดดาเมจได้ครั้งเดียวต่อช่วง, counter แตกเกราะเมื่อผ่านเงื่อนไข, หมัดพุ่งที่แลกความถึกกับระยะ | FIST / HEAVY / CLAW |
| ASTRO_DIVINATION / CHRONO_EPOCH | ชี้ดวงดาวและอ่านจังหวะก่อนสังหาร; วางตำแหน่งคุ้มกัน+จำกัดรีไวน์ด้วย Temporal Debt | ASTROLABE / BRUSH |
| MERCANTILE_DAO / FORTUNE_GAMBLER | ลูกคิดรบคุมจังหวะ Qi ที่ใช้จริง, risk/reward จากเดิมพันที่มีต้นทุนล่วงหน้าและไม่เสกเงิน | ABACUS / CHARM |
| SONIC_HARMONY / INK_LITERATI | วงคีตะคุ้มกันหมู่ที่ต้องอยู่ฝ่ายเดียวกัน, อักษรผนึกที่ใช้ LoS/จุดคุม, การประสานที่มีเว้นจังหวะ | ZITHER / BRUSH / FAN |
| VENOM_GU / NINPO_SHADOW | โจมตีจุดชีพจรแบบ status buildup (ไม่ stun-lock), ปิดแผล/ดูดพิษแบบมี counter | NEEDLE / CLAW |
| BUDDHA_DHARMA / DIVINE_CHANNELER | สายลูกประคำคุมโล่ช่วยเพื่อนแบบมี ICD และเสีย Qi, ชำระ curse เฉพาะจังหวะ | ROSARY / STAFF |
| DRAGON_VEIN_GEOMANCY / VOID_SPACE | อ่านตำแหน่งค่ายกลกับท่าถอย, anchor พื้นที่กัน displacement แต่เสียโอกาสโจมตี | ASTROLABE / FAN |
| BEAST_SOVEREIGN / SPIRIT_HUSBANDRY / SOUL_PUPPETRY | ท่าร่วมสัตว์/หุ่นเชิดที่ตรวจ faction+participant; break tether แล้วคืน ownership ถูกต้อง | CLAW / WHIP / FOCUS |

## 7. คีย์เวิร์ดและสถานะใหม่ที่เสนอ (ยังไม่มีในเกม)
- ตรวจชื่อ ID ที่เสนอเทียบ `SK.STATUS` ของ ZIP นี้แล้วเป็นชื่อใหม่; **ต้องสร้างสัญญา producer → trigger/condition → effect/sink → AI → UI → save → tests ให้ครบ** ห้ามใส่ status ID ลง data อย่างเดียว
- **`temporalDebt` · หนี้กาลเวลา** (CHRONO_EPOCH / ASTROLABE): หลังย้อนเวลาได้ประโยชน์ 1 ครั้ง ใส่หนี้ 1–2 ชั้น; ร่ายครั้งถัดไปช้าลงหรือใช้ Qi เพิ่มตามชั้น **ข้อจำกัด:** รีเซ็ตหลังชำระต้นทุน; ไม่ซ้อนเกิน 2; ไม่เรียกรีไวน์ซ้อน; ระบุใน UI
- **`meridianPressure` · แรงกดจุดชีพจร** (NEEDLE / BODY / VENOM_GU): โจมตีเข็มสะสมแรงกด 2 ชั้นเพื่อลดอัตราฟื้น Qi ชั่วคราวโดยไม่ซ้ำ stun **ข้อจำกัด:** มีภูมิคุ้มกันบอส, purge ได้, ไม่ซ้อน QI_BLOCK จนปลดวิชาไม่ได้ถาวร
- **`sightlinePinned` · กดดันแนวยิง** (BOW / SNIPE): ธนูยิงคุมแนวทำให้เป้าหมายออกจากที่กำบังแล้วเสีย accuracy ชั่วคราว แทน stun/root **ข้อจำกัด:** ใช้ LoS จริง, cap per target, AI เลี่ยงด้วยตำแหน่ง; ห้ามข้ามกำแพง
- **`rhythmDebt` · ค้างจังหวะคีตะ** (ZITHER / ROSARY / SONIC_HARMONY): ใช้วิชาในจังหวะไม่สัมพันธ์กับเครื่องหมายจังหวะแล้วเสียโบนัสครั้งต่อไป; เล่นเป็นลำดับได้ combo **ข้อจำกัด:** คุม rhythm chain ไม่บังคับผู้เล่น spam, duration สั้น, เสียง/ภาพ/UI บอกสถานะ
- **`ledgerBalance` · ดุลบัญชีกรรม** (ABACUS / MERCANTILE_DAO / KARMA_SAMSARA): บันทึก Qi ที่ใช้กับโจมตีเป็นดุล ใช้ครั้งเดียวเพื่อกันดาเมจหรือปล่อยโจมตีตอบโต้ **ข้อจำกัด:** ไม่มีการสร้าง Qi/ทรัพยากรจริง; จำกัดยอดตาม Qi ที่จ่ายจริงและ softcap; ไม่ทบกับ loot
- **`fanWindAngle` · มุมลมแปรผัน** (FAN / CELESTIAL_WEATHER): โจมตีพัดเปลี่ยนทิศบังคับตำแหน่งเป้าหมายเล็กน้อย และสร้างช่องให้ท่าต่อเนื่องโดนเป็นแนว **ข้อจำกัด:** ใช้ pathfinding/ขอบสนาม/immune boss; จำกัด chain และไม่กระเด็นนอกแผนที่
- **`clawGrip` · เขี้ยวเกาะแน่น** (CLAW / PRIMORDIAL_SHIFTER / BEAST_SOVEREIGN): ตีประชิดติดเครื่องหมายเกาะครั้งเดียวทำให้ท่ากรงเล็บถัดไปได้โบนัสต่อเป้าหมายเดิม **ข้อจำกัด:** ไม่ล็อก NPC ตลอดศึก; สลับเป้าแล้วหาย; ตรวจ guard/ward และ durability
- **`rosaryVow` · สัตย์ป้องกันธรรม** (ROSARY / BUDDHA_DHARMA): คำสัตย์ช่วยเพื่อนหนึ่งคนด้วยโล่เล็กเมื่อเลือดต่ำ แต่ผู้ร่ายต้องเสีย Qi จริง **ข้อจำกัด:** ICD ต่อผู้รับ+ศึก, ตรวจฝ่าย/participant เหมือน combat fix, ห้ามฮีลผิดฝ่าย
- **`inkOrderSeal` · ราชโองการหมึก** (BRUSH / INK_LITERATI): ประทับตราคำสั่งบนเป้าหมาย; วิชาเขียนอักษรถัดไปเปลี่ยนชนิดเอฟเฟกต์หรือคุมพื้นที่ **ข้อจำกัด:** ใช้ mark key ใหม่ไม่ซ้ำ starSeal/daoMark, cap 2, save/load ทวนสอบ
- **`stanceFracture` · แตกร้าวท่วงท่า** (BLADE / SPEAR / HEAVY): การเจาะเกราะหนักลดโบนัส stance ชั่วคราวโดยไม่ถอดอุปกรณ์หรือเขียนทับ loadout **ข้อจำกัด:** ต้านทานได้, ไม่ลบสถานะถาวร, จำกัด 1 proc ต่อวงจรคูลดาวน์
- **`astralCalibration` · ปรับแกนดารา** (ASTROLABE / ASTRO_DIVINATION / DRAGON_VEIN_GEOMANCY): ผู้ร่ายอ่านตำแหน่งเป้าหมายล่วงหน้า 1 รอบ ช่วยคุมระยะและการโต้กลับแต่เสียเวลาร่าย **ข้อจำกัด:** ขอบเขต LoS จริงและการเคลื่อนที่, ไม่เพิ่ม accuracy ไร้เพดาน
- **`summonInterdict` · ผนึกประตูอัญเชิญ** (FOCUS / ROSARY / DIVINE_SUMMONER / NETHER_GRAVE): กั้นการเกิด summon ใหม่ระยะสั้น ไม่ลบ summon ที่มีอยู่และไม่ยุ่งกับ registry NPC จริง **ข้อจำกัด:** มี counterspell/ระดับบอส immune บางส่วน; ห้ามทำลายข้อมูลสัตว์เลี้ยง/มรดก

## 8. สมดุลและผลกระทบลูกโซ่ (Release Gate)
1. อาวุธ/เกราะ TYPE ผิด → วิชาระยะ/การใช้ท่าผิด → AI เลือก target+ตำแหน่งผิด → ดาเมจผิด → บาดเจ็บ/สังหารผิด → เศรษฐกิจ/ตำแหน่ง/เซฟได้รับผล (เชื่อม TECH-01 กับ COMBAT-01 และ EQ ที่พบก่อนหน้า)
2. Item Grant ข้ามขั้น → ท่าแข็งแรงก่อนเวลา → ผ่านหอ/แดนลับ/บอสที่ปกติไม่ผ่าน → ได้ทรัพยากร/คัมภีร์เร็ว → ตัวละครและสำนักยิ่งนำ → ความต่างยิ่งโต (TECH-02)
3. Modifier ไม่จำกัดธาตุ → วิชาทั่วไปและวิชาข้ามสายรับโบนัสไฟ/น้ำแข็งโดยไม่ได้แลกต้นทุน → meta ดัน DPS สูงจนทำลายบทบาทธาตุ/คุมพื้นที่ (TECH-03)
4. คุมสถานะฝ่าย: ก่อนสร้างวิชาช่วยเหลือหรือสถานะใหม่ ต้องปิด COMBAT-02–06 ที่บัฟผิดฝ่ายก่อน ไม่เช่นนั้นวิชาใหม่ขยายบัคเดิม
5. ทุกการแก้ skill cache/gear grant ต้องตรวจกลางศึก, สลับอาวุธ, ของพัง, ตาย/สืบทอด, ย้ายสำนัก, เซฟ/โหลด, การเล่นหลายวัน และ RNG deterministic

## 9. Test Plan และข้อจำกัด
- Runtime tests: `TECHNIQUE_RUNTIME_PROBES.js` 14 cases; ผล `TECHNIQUE_RUNTIME_PROBE_RESULTS.json`; พฤติกรรมที่ถูก flag รวม schema/design ไม่ได้หมายถึง 14 distinct bugs
- Full catalog: `TECHNIQUE_INDIVIDUAL_CATALOG_QA.csv` 1,824 records และ `TECHNIQUE_EACH_MOVE_QA.csv` 2,603 move profiles; มิใช่การยืนยัน gameplay ดาเมจจริงทีละท่า
- Coverage: `TECHNIQUE_PATH_COVERAGE.csv` 43 วิถี, `TECHNIQUE_SUBPATH_GAP_ACTIONS.csv` 286 สาย, `TECHNIQUE_WEAPON_COVERAGE.csv` 16 ประเภท
- Type mismatch: `TECHNIQUE_EQUIPMENT_TYPE_MISMATCHES.json` 36 items. Stage grant pre-screen: `TECHNIQUE_EQUIPMENT_GRANT_CANDIDATES.json` 189 รายการที่ต้องประเมินตามเงื่อนไขไอเทมและหอ/สูตร; 1 ตัวอย่างรันจริงยืนยันได้
- Regression เดิมที่รันซ้ำเดี่ยว: v230_grand_dao, v234_massive_content, unified_weapon, technique_overhaul, v212_weapon_build, v300_tactical ทั้ง **6 ผ่าน**; บันทึก `TECHNIQUE_RELATED_REGRESSION_LOG.txt`
- **ยังไม่ได้ทำ** browser click/gesture E2E บน Chromium ครบทุกท่า, battle-monte-carlo 1000 seed, 43-path all-vs-all balancing, เกณฑ์ retention จากผู้เล่นจริง หรือพิสูจน์สมดุล PvP ระยะยาว. ห้ามอ้างว่าพิสูจน์แล้วว่า 34 ท่าที่ M×hits>15 โกงจริง
- เครื่องมือที่ใช้: Node runtime ปัจจุบัน+ Python CSV, ไม่มีการเชื่อม Replit app ในบัญชีที่พบ; แก้ไขแค่เอกสารรายงานภายใน ZIP ไม่แตะ source

## 10. สิ่งที่ต้องทำต่อสำหรับ Coding AI
1. ปิด TECH-01 และ TECH-02 ก่อน ต่อด้วย TECH-04; ทำ regression weapons, gear grants, stage unlock, AI selection, sim/save.
2. ยืนยัน spec ของ element/weaponType ใน skillModifiers เพื่อปิด TECH-03 อย่างปลอดภัย; ทดสอบไวมากกับ item ที่เกี่ยวข้อง 277 mods และ cross-element.
3. ปรับ canSelect / cache / loadout authority ที่ TECH-05–07 ตามต้นทางเดียวกัน ไม่ patch UI อย่างเดียว.
4. หลังปิด P0/P1 รายงานเดิม ให้ใช้ทะเบียน 43/286/16 เสนอแพตช์เพิ่มวิชาเล็ก ๆ ทีละชุดพร้อม source การได้มาจริง และ DPS/utility before-after; สถานะใหม่เป็น proposal ไม่ต้องเร่งลง release build.
