# คำสั่งสำหรับ AI เขียนโค้ด — DAO / CULTIVATION / SUBPATH Freeze Patch v2.3.0

## เป้าหมาย
แก้บัควิถีหลักและสายย่อยจาก `QA_DAO_PATH_SUBPATH_AUDIT_V230.md` โดยไม่เพิ่มฟีเจอร์, ไม่ลบคอนเทนต์ 43 วิถี / 286 สาย, และไม่เนิร์ฟเมต้าเกินจำเป็น. ไฟล์รายงานอุปกรณ์ `QA_GEAR_BALANCE_AUDIT_V230.*` อยู่แยกหมวดใน ZIP เดียวกัน.

## งานตามลำดับ
**A. P0 / DAO-001:** Canonicalize skillGate IDs ในข้อมูล realm ครบ 15 สาย. ห้ามเปลี่ยน HERBALISM เป็น HERBALISM ตัวใหญ่ต่อ; ใช้ `herbalism` และ `cooking` ที่ skillRead รองรับ. `FISHING` ไม่มี canonical skill ต้องเลือกทางแก้ที่ฝึกได้จริงและเชื่อมระบบประมง; `CRAFTING`, `LEADERSHIP` ให้เลือก mapping ที่สอดคล้อง design. Validate data at startup + regression testing all 9 realms. Preserve track ordinal/progress/history on save migration.

**B. P1 / DAO-002:** สร้าง `canActivateMantra(n,id)` canonical validator ตรวจ unlocked + path + tier + restrictions. เชื่อม UI switch/list, auto select, load reconciliation, stats read. อนุญาตประวัติ unlockedMantras จากวิถีเก่า แต่ห้าม activate ก่อนเงื่อนไขครบ. ทดสอบ DEMON tier7→XIAN tier1 และมั่นใจว่าไม่มี bonus จากแมนตราที่ผิด.

**C. P1 / DAO-003:** แก้ 38 invalid `SUBPREF.aff` references. นิยาม schema alias for HC affinities vs MARTIAL skill scores ให้ชัด; ทุกคะแนนตอบสนองต่อ trait ปลายทางจริง. ทดสอบ CI และ seeded path selection distribution.

**D. P1 / DAO-004:** แก้ `values.wealth` → `wealthResource` ใน MERCANTILE_DAO/FORTUNE_GAMBLER; `values.dutyHonor` → canonical `sectDuty`/`honorLegacy` หรือ weighted mix สำหรับ ANCESTRAL_RITUAL. Assert monotonic response to trait changes where intended.

**E. P2 / DAO-005:** Invalidate or track-key `M.lifeMult` after `CULT.trackBreakthrough`. Test real eligible track level-up with guaranteed RNG only for deterministic QA; normal action still uses chance; keep `M.progression` and `M.lifeMult` coherent.

**F. REVIEW / DAO-006:** Do not nerf outlier paths solely from no-gear vs NONE stats. Close equipment exploit audit first, then run matched tier/gear/mantra/skill build comparisons on DPS, EHP, qi sustain, rare-item acquisition and counters.

## หลักฐานสำหรับเช็กก่อนและหลัง
- `DAO_PATH_SUBPATH_REPRO_TESTS.js`: `GAME_SOURCE_ROOT=/path/to/release node DAO_PATH_SUBPATH_REPRO_TESTS.js dao_results.json`
- `DAO_PATH_SUBPATH_REPRO_RESULTS.json`: current observed failing behavior; 8 cases, 6 reproduced, one control, one review.
- `QA_DAO_PATH_SUBPATH_AUDIT_V230.json`: field details and all 15 affected IDs, all 38 invalid affinities.
- `DAO_PATH_SUBPATH_BASELINE_MATRIX.json`: review-only matrix 286 paths (no gear/no active mantra/tech).

## Definition of Done
- Add **green regression** asserts new correct behavior, not just re-run red reproduction script and count reproduced bugs.
- No invalid gate IDs / preference aliases / value paths; no cross-path tier7 mantra after retrain; live cache updates after track success.
- All original tests and schema checks still pass, save/load old migration integrity, release notes list DAO-IDs fixed.
- If meta is deliberately strong, note design rationale and leave REVIEW unmodified until combat benchmarks are available.


## อัปเดต chain gate วิถี/สายย่อย (8 พ.ย. 2026)

- **DAO-002/C19:** คัมภีร์ข้ามวิถี stage7 ถูกกลับมาสวมที่ stage1 หลัง retrain; MATK 105→127 และยังอยู่หลัง save/load; ต้อง validate ใน UI + CULT/STATS + sanitize import โดยไม่ลบ learned manuscripts.
- **DAO-001/C20:** 15 สายย่อยติด gate จาก skill key ผิด; ตัวอย่าง HERBALISM/COOKING ยังค้างหลัง load แม้ skill/resource พร้อม; ต้องแก้ key ต้นทางและทดสอบทะลวงหลัง migrate.
