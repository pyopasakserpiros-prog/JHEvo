#!/usr/bin/env node
'use strict';
// Read-only reproduction against the ORIGINAL unpacked v2.3.0 source; no patches.
const path=require('path');
const loadPath=process.env.JHS_GAME_ROOT ? path.join(process.env.JHS_GAME_ROOT,'test/load') : '../audit_v230/GAME_SOURCE/test/load';
const g=require(loadPath);
const {JD,ECO,SIM,SECT,STATS,MARTIAL,VC}=g;
const W=SIM.create('equipment-freeze-audit-230');
const npc=W.npcs[0];
const tests=[];
function check(id,exec){try{const details=exec();tests.push({id,observed:true,details});console.log('OBSERVED '+id+': '+JSON.stringify(details));}catch(err){tests.push({id,observed:false,error:String(err&&err.stack||err)});console.log('NOT_REPRODUCED '+id+': '+String(err));}}
function assert(v,msg){if(!v)throw new Error(msg);}
const gearDefs=JD.ITEMS.items.filter(it=>['WEAPON','ARMOR','ACCESSORY'].includes(it.slot));
const defsBySlot={}; for(const slot of ['WEAPON','ARMOR','ACCESSORY'])defsBySlot[slot]=gearDefs.filter(it=>it.slot===slot);
const snapshot=(gear)=>Object.assign({},gear,{st:gear.st&&Object.assign({},gear.st)});
check('EQ-001_socket_unlimited_multiplicative',()=>{
 const gear=ECO.rollProceduralGear(W,{slot:'WEAPON',gearType:'SWORD',tier:3,seed:'socket-test'});npc.equip={WEAPON:gear,ARMOR:null,ACCESSORY:null};
 const original={id:'TEST_MOVE',arch:'SWORD',element:'FIRE',M:1,pen:0,critAdd:0};
 const balances=[];
 for(let i=0;i<20;i++){
  const res=ECO.socketElementalRunes(W,npc,gear,['FIRE','WATER_ICE']);assert(res.ok,'socket failed '+i);
  if([0,1,4,9,19].includes(i)){const move=MARTIAL.applyEquipmentSkillModifiers(npc,original);balances.push({sockets:i+1,modifierEntries:gear.skillModifiers.length,mult:move.M,pen:move.pen,crit:move.critAdd});}
 }
 assert(balances[4].mult>20,'no runaway multiplicative skill stat');return {balances,materialCost:0,gearUid:gear.uid};
});
check('EQ-002_free_max_spirit',()=>{
 npc.equip={WEAPON:null,ARMOR:null,ACCESSORY:null};const beforeStock=JSON.stringify(W.sect.stock),beforeGear=(W.sect.gear||[]).length;
 const first=SECT.SOUL_FORGE.awakenWeaponSpirit(W,npc,npc,{initialXp:320});const firstStage=first.weaponSpirit.stage,firstXP=first.weaponSpirit.spiritXp;
 const second=SECT.SOUL_FORGE.awakenWeaponSpirit(W,npc,npc,{initialXp:320});const stage=second.weaponSpirit.stage,afterXP=second.weaponSpirit.spiritXp;
 assert(first.ok&&second.ok&&stage===5,'spirit did not reach top stage');assert(JSON.stringify(W.sect.stock)===beforeStock,'stock changed');
 return {weaponId:npc.equip.WEAPON.id,createdFromEmptySlot:true,firstStage,firstXP,secondStage:stage,secondXP:afterXP,spiritMult:second.weaponSpirit.multBonus,gearCombatMult:npc.equip.WEAPON.combatMult,sectStockUnchanged:true,sectGearCountDelta:(W.sect.gear||[]).length-beforeGear};
});
check('EQ-003_neutral_pair_and_broken_bonus',()=>{
 const w=ECO.mintGear(W,defsBySlot.WEAPON.find(x=>!x.legendary && (!x.element||x.element==='NEUTRAL')) || defsBySlot.WEAPON[0],1);
 const x=ECO.mintGear(W,defsBySlot.ACCESSORY.find(x=>!x.legendary && (!x.element||x.element==='NEUTRAL')) || defsBySlot.ACCESSORY[0],1);
 w.element='NEUTRAL';x.element='NEUTRAL';w.minStage=1;x.minStage=1;
 npc.equip={WEAPON:w,ARMOR:null,ACCESSORY:x};const whileHealthy=ECO.evaluatePairedItems(npc),whileHealthyUsable=[MARTIAL.gearUsable(npc,w),MARTIAL.gearUsable(npc,x)];
 w.broken=true;w.dur=0;const whileBroken=ECO.evaluatePairedItems(npc);assert(whileHealthy.active&&whileBroken.active&&!MARTIAL.gearUsable(npc,w),'paired bonus not given with broken');
 return {pairId:w.id+' + '+x.id,whileHealthy,whileHealthyUsable,whileBroken,brokenWeaponUsable:MARTIAL.gearUsable(npc,w)};
});
check('EQ-004_legendary_wildcard_resonance',()=>{
 const rs=MARTIAL.RESONANCE_SETS.find(rs=>rs.path!=='ANY' && rs.path!==npc.cult.path && rs.slots && rs.slots.WEAPON && rs.slots.ARMOR);
 assert(rs,'no incompatible set');const wl=VC.LEGENDARY_WEAPON_BY_ID;
 const wd=Object.values(wl).find(x=>x.slot==='WEAPON');const ad=Object.values(wl).find(x=>x.slot==='ARMOR');assert(wd&&ad,'missing legendary slots');
 const w=VC.mintLegendaryEquipment(W,wd.id),a=VC.mintLegendaryEquipment(W,ad.id);w.minStage=1;a.minStage=1;
 npc.equip={WEAPON:w,ARMOR:a,ACCESSORY:null};
 const matches=[MARTIAL.itemMatchesResonanceSet(npc,w,rs),MARTIAL.itemMatchesResonanceSet(npc,a,rs)];
 const evalSet=MARTIAL.evaluateResonanceSet(npc);
 assert(matches[0]&&matches[1]&&evalSet.active,'legendary wildcard not triggering');
 return {npcPath:npc.cult.path,setId:rs.id,setPath:rs.path,weaponType:w.gearType,armorType:a.gearType,setAllowedWeaponTypes:rs.slots.WEAPON,setAllowedArmorTypes:rs.slots.ARMOR,matchDespiteIncompatibility:matches,actualSelectedSetId:evalSet.setId,selectedSetPath:evalSet.set&&evalSet.set.path,pieces:evalSet.pieces,bonuses:evalSet.p};
});
check('EQ-005_incompatible_path_gear_usable',()=>{
 const foreign=gearDefs.find(x=>x.compatiblePath && ![].concat(x.compatiblePath).includes('ANY') && ![].concat(x.compatiblePath).includes(npc.cult.path) && x.slot==='WEAPON');assert(foreign,'no foreign gear'); const prevStage=npc.cult.stage; npc.cult.stage=Math.max(npc.cult.stage,foreign.minStage||1); const item=ECO.mintGear(W,foreign,1);item.compatiblePath=foreign.compatiblePath;
 const usable=MARTIAL.gearUsable(npc,item);npc.inv=npc.inv||{};npc.inv.gear=[item];
 const res=SECT.EDITOR.equipPersonalGear(W,npc.id,item.uid);
 assert(usable && !res.ok,'no boundary contradiction');npc.cult.stage=prevStage;return {npcPath:npc.cult.path,gearId:item.id,gearPaths:item.compatiblePath,gearUsable:usable,manualEquip:res,syntheticSetup:'Raised npc stage only to meet gear minStage; source item is canonical'};
});
check('EQ-006_refine_no_owner_integrity',()=>{
 const gear=ECO.rollProceduralGear(W,{slot:'WEAPON',tier:4,gearType:'BLADE'});const orphan=snapshot(gear);const cat='CAT_PRIMORDIAL_FLAME_6';W.sect.catalysts={[cat]:2};
 const res=ECO.refineGearWithCatalyst(W,orphan,cat,null);
 assert(res.ok && W.sect.catalysts[cat]===1 && orphan.q>gear.q,'unowned gear not refinable');return {unownedGearUid:orphan.uid,originalQuality:gear.q,newQuality:orphan.q,catalystsRemain:W.sect.catalysts[cat]};
});
check('EQ-007_cheap_low_tier_stone_repairs_high_tier',()=>{
 const w=ECO.rollProceduralGear(W,{slot:'WEAPON',tier:4,gearType:'SWORD'});w.tier=7;w.minStage=1;w.dur=10;W.sect.gear.push(w);ECO.add(W,'ITEM_REPAIR_STONE_1',1);
 const res=ECO.repairGear(W,w,'ITEM_REPAIR_STONE_1');assert(res.ok,'low-tier repair not allowed');
 return {gearTier:w.tier,stoneTier:1,repairOk:res.ok,newMaxDur:w.maxDur,remainingStone:ECO.count(W,'ITEM_REPAIR_STONE_1')};
});

check('EQ-009_refinement_quality_ceiling_runaway',()=>{
 const d=gearDefs.find(x=>x.slot==='WEAPON' && (x.tier||0)>=4 && !x.legendary); assert(d,'no regular high-tier weapon');
 const item=ECO.mintGear(W,d,1.5);const cat='CAT_PRIMORDIAL_FLAME_6';W.sect.gear.push(item);W.sect.catalysts={[cat]:25};
 const run=[];for(let i=1;i<=15;i++){
  const r=ECO.refineGearWithCatalyst(W,item.uid,cat,null);assert(r.ok,'refine failed at '+i+': '+r.reason);
  if([1,2,5,10,15].includes(i))run.push({refinements:i,q:item.q,quality:item.quality,atk:item.st&&item.st.atk,combatMult:item.combatMult,catalystsLeft:W.sect.catalysts[cat]});
 }
 assert(run[0].q===run[4].q && run[4].atk > run[0].atk*1.8,'q ceiling did not permit stat drift');return {gearId:item.id,qualityHardLimit:1.75,catalystDeclaredMax:1.85,run};
});
check('EQ-010_min_stage_validator_inconsistent',()=>{
 const d=gearDefs.find(x=>x.slot==='WEAPON' && (x.minStage||1)>=4 && !x.legendary);assert(d,'gear with minStage>=4 absent');
 const it=ECO.mintGear(W,d,1);const prevStage=npc.cult.stage; npc.cult.stage=(it.minStage||4)-1;
 const usable=MARTIAL.gearUsable(npc,it);npc.inv=npc.inv||{};npc.inv.gear=[it];const res=SECT.EDITOR.equipPersonalGear(W,npc.id,it.uid);npc.cult.stage=prevStage;
 assert(usable&&!res.ok,'stage discrepancy not found');return {gearId:it.id,minStage:it.minStage,testNpcStage:(it.minStage||4)-1,combatUsable:usable,manualEquipOk:res.ok,manualEquipReason:res.reason,syntheticSetup:'NPC stage set to item minStage-1'};
});

check('EQ-011_broken_spirit_weapon_rating_still_buffed',()=>{
 const w=ECO.rollProceduralGear(W,{slot:'WEAPON',tier:4,gearType:'SWORD'});w.broken=true;w.dur=0;
 npc.equip={WEAPON:w,ARMOR:null,ACCESSORY:null};assert(!MARTIAL.gearUsable(npc,w),'weapon is not broken under usability');
 const fixedV={atk:100,matk:100,crit:10,critDmg:150,cast:100,pen:10,acc:100,def:90,mdef:90,hp:1000,eva:50};
 const base=STATS.rating(npc,fixedV);w.weaponSpirit={stage:5,multBonus:0.32};const withSpirit=STATS.rating(npc,fixedV);
 assert(withSpirit>base*1.31,'broken spirit rating unchanged');return {gearId:w.id,broken:true,gearUsable:MARTIAL.gearUsable(npc,w),ratingWithoutSpirit:+base.toFixed(2),ratingWithSpirit:+withSpirit.toFixed(2),ratio:+(withSpirit/base).toFixed(4),note:'Fixed V supplied to rating to isolate weapon spirit multiplier'};
});
check('EQ-012_legendary_double_set_bonus',()=>{
 const by=VC.LEGENDARY_WEAPON_BY_ID; const wdef=Object.values(by).find(x=>x.slot==='WEAPON');
 const adef=Object.values(by).find(x=>x.slot==='ARMOR'); const xdef=Object.values(by).find(x=>x.slot==='ACCESSORY');
 assert(wdef&&adef&&xdef,'missing legendary three slots');
 const w=VC.mintLegendaryEquipment(W,wdef.id),a=VC.mintLegendaryEquipment(W,adef.id),x=VC.mintLegendaryEquipment(W,xdef.id);
 w.minStage=1;a.minStage=1;x.minStage=1;npc.equip={WEAPON:w,ARMOR:a,ACCESSORY:x};
 const res=MARTIAL.evaluateResonanceSet(npc),leg=MARTIAL.evaluateLegendaryRelicResonance(npc);
 assert(res.active&&leg.active,'dual sets not active');return {gearIds:[w.id,a.id,x.id],normalSet:{id:res.setId,pieces:res.pieces,p:res.p},legendarySet:{pieces:leg.pieces,p:leg.p,f:leg.f,qiCostMult:leg.qiCostMult,procChanceMult:leg.procChanceMult},combinedAtkPct:+(100*((res.p.atk||0)+(leg.p.atk||0))).toFixed(1),note:'Additive raw % contributions only, not actual post-cap final damage; stacking may be intentional'};
});
check('EQ-008_default_quality_and_stat_score_catalog',()=>{
 const records=gearDefs.map(it=>{let mint;try{mint=ECO.mintGear(W,it,it.q||1);}catch(e){return null;}const st=STATS.gearStats(mint);const score=STATS.gearScore(mint);return {id:it.id,nameTh:it.nameTh,slot:it.slot,tier:it.tier||1,legendary:!!it.legendary,q:mint.q,score,st};}).filter(Boolean);
 const groups={};for(const rec of records){const key=rec.slot+'_T'+rec.tier; (groups[key]||(groups[key]=[])).push(rec);}
 const stats=Object.fromEntries(Object.entries(groups).map(([key,v])=>{const sorted=v.map(x=>x.score).sort((a,b)=>a-b);return [key,{count:v.length,median:sorted[Math.floor(sorted.length/2)],max:sorted[sorted.length-1],min:sorted[0]}];}));
 const top=records.slice().sort((a,b)=>b.score-a.score).slice(0,22).map(({st,...r})=>r);
 return {counts:{allCatalogItems:JD.ITEMS.items.length,gear:gearDefs.length,legendary:gearDefs.filter(x=>x.legendary).length},stats,top};
});
require('fs').writeFileSync('/mnt/data/JianghuSect_v2.3.0_Freeze_Audit/GEAR_BALANCE_REPRO_RESULTS.json',JSON.stringify({timestamp:'2026-11-08',version:SIM.PATCH_VERSION,tests},null,2));
console.log('OBSERVED_CASES',tests.filter(t=>t.observed).length,'/',tests.length);
