# วิธีตรวจซ้ำ: วิชา วิถี/สายย่อย อาวุธ–อุปกรณ์ (v2.3.0)

## ฐานเดียวกัน
- ใช้เกมต้นฉบับ `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip` เท่านั้น (SHA256 `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`).
- แตกเกม ZIP แล้วหาตำแหน่งโฟลเดอร์ **`GAME_SOURCE`** ที่ภายในมี `test/load.js` และ `js/skills.js`. ไม่ต้องคัดลอกหรือแก้ไฟล์เกม.
- ต้องมี Node.js และตั้งค่าตัวแปร `GAME_SOURCE_ROOT` ให้ชี้ไปยังตำแหน่งนั้น

## คำสั่ง
```bash
export GAME_SOURCE_ROOT=/absolute/path/to/GAME_SOURCE
node TECHNIQUE_RUNTIME_PROBES.js     # 14 probes: reproduce runtime anomalies + review scans
node TECHNIQUE_COVERAGE_AUDIT.js     # สรุป 43 วิถี 286 สายย่อย และ 16 อาวุธ + CSV
node TECHNIQUE_CATALOG_SCAN.js       # ตรวจ schema 1,824 วิชาและคัมภีร์
node TECHNIQUE_CROSS_SCAN.js         # สร้าง 2,603 move profiles สำหรับคัดกรองเบื้องต้น
```

สคริปต์จะเขียนผลลัพธ์ `.json`/`.csv` ในโฟลเดอร์เดียวกับสคริปต์ ไม่แตะไฟล์ source เกม ไม่เปลี่ยน save ของผู้เล่น (ใช้ world test ที่สร้างใหม่ใน process). แฟ้ม `TECHNIQUE_*_RESULTS.json` และ `.csv` ใน ZIP เป็น snapshot จาก v2.3.0. `TECHNIQUE_CROSS_SCAN.js` สร้าง JSON ฉบับเต็มที่มีขนาดใหญ่ จึงแนบเฉพาะตาราง CSV ที่อ่านง่ายกว่า.

## การอ่านผลที่ถูกต้อง
- จำนวน **14 probes** ไม่เท่ากับ 14 บัค. ตาราง `TECH-01…TECH-07` แยกข้อผิดพลาด; `TECH-08/09` เป็นเรื่องยืนยัน design/สมดุล และ `TECH-10` เป็นข้อเสนอเพิ่มเนื้อหาเท่านั้น.
- `TECHNIQUE_INDIVIDUAL_CATALOG_QA.csv` คือ **static audit** ของ 1,824 records ไม่ใช่เล่นทดสอบทุกวิชาแยกกัน.
- `TECHNIQUE_EACH_MOVE_QA.csv` คือ **runtime profile/screening** จำนวน 2,603 ไม่ใช่ผลตีมอนสเตอร์ครบทุกท่า.
- `TECHNIQUE_SUBPATH_GAP_ACTIONS.csv` ครอบคลุมทุก 286 สาย; คำว่า ‘ต่ำกว่าค่าเฉลี่ย’ ไม่ได้แปลว่าต้องสร้างให้เท่าค่าเฉลี่ยทันที หรือเป็นบัค.
- สถานะและ keywords ใหม่ในรายงานเป็น **ข้อเสนอออกแบบ** ไม่ใช่ existing game data; ต้องเพิ่ม engine, counters, UI, AI, save, test หากตัดสินใจสร้างจริง.

## Acceptance หลังแก้
1. ชนิดอาวุธ/เกราะทุกชิ้นต้องตรงกับชนิด canonical ทั้ง mint และ loot (อย่างน้อย 36 ตัวที่ตรวจเจอ).
2. ของสวมใส่ขั้น 1 ต้องไม่อนุญาตให้เลือกท่าที่มี `reqCultStage=3` เว้นมี override design ที่ระบุชัด.
3. โบนัส `element`/`weaponType` ต้องมี semantics ตรงตาม design (มีกรณีตรง/ผิด element).
4. 4 วิชาที่มี `stageReq=2` ต้องปลดล็อกเมื่อถึงเงื่อนไข และห้ามปลดล็อกก่อน.
5. UI และ combat ใช้ eligibility เดียวกัน; อุปกรณ์เปลี่ยน modifier บน UID เดิมแล้วรายการท่าไม่ค้าง.
6. หลังแก้รัน regression เดิมและ browser end-to-end เพิ่ม ไม่ใช่เพียงให้ 14 probes ไม่รายงานผิด.
