'use strict';
/** Deterministic release-blocker probes for original v2.3.0.  Intentional RED tests: reproduced means invariant is violated. */
const path=require('path');
const srcRoot=process.env.GAME_SOURCE_ROOT || path.join(__dirname, 'GAME_SOURCE');
const G=require(path.join(srcRoot,'test','load.js'));
const {SIM, COMBAT:C, CULT, STATS:ST}=G;
const fs=require('fs');
const rows=[];
function caseRun(id,title,fn){ try{const r=fn(); rows.push({id,title,reproduced:!!r.reproduced,observed:r.observed,note:r.note||'',error:null});console.log(id, r.reproduced?'REPRO':'NO_REPRO',JSON.stringify(r.observed));}catch(e){rows.push({id,title,reproduced:false,observed:null,error:e.stack});console.log(id,'ERROR',e.message);}}
let seq=1;
function ctx(){
 const W=SIM.create('battle-release-audit-'+seq++);const [a,d,s]=W.npcs;
 for(const n of [a,d,s]){
 n.x=14; n.y=14;n.away=false;n.dead=false;n.fled=false;n.yield=false;
 n.h.state.hp=C.hpMax(n); n.h.state.qi=CULT.qiMax(n);
 n.supportState=null;n.defensiveArtState=null;n.mantraState=null;n.forbiddenArtState=null;n.passiveResonanceState=null;
 n.pets=[];n.equip={}; n.sx=[];n.buffs=[];n._cs=null;
 }
 W._hasActiveDefSupportAura=false; W.sect.formationWarfare={activeStance:null}; W.sect.elementalBarrier={active:false,barrierHp:0};
 const f={id:8000+seq,kind:'duel',serious:false,A:[a.id],B:[d.id,s.id],t0:W.t,log:[]};
 return {W,a,d,s,f};
}
function support(W,s,arch){s.cult.path='SAGE_SUPPORT';s.cult.stage=5; return CULT.SUPPORT_ARTS.setSupportPosture(W,s,null,arch);}
caseRun('CB-01','Enemy support buffs attacker on opposite team',()=>{
 const {W,a,d,s,f}=ctx(); const sp=support(W,s,'QIMEN_BATTLE_BANNER');
 const before=s.supportState.totalCommandBuffs;
 C.applyDamage(W,f,a,d,25,'test opposition');
 const increased=s.supportState.totalCommandBuffs-before;
 return {reproduced:increased===1,observed:{supportSide:C.sideOf(f,s.id),attackerSide:C.sideOf(f,a.id),increased,damageBonus:sp.effAtkBonusPct}};
});
caseRun('CB-02','Enemy support heals opposing combatant',()=>{
 const {W,a,d,s,f}=ctx();const sp=support(W,s,'ACUPOINT_MERIDIAN_THERAPY');
 a.h.state.hp=Math.round(C.hpMax(a)*.45); const before=C.hp(a);
 C.applyDamage(W,f,d,a,25,'test healing opposition');
 const after=C.hp(a);const healed=s.supportState.totalAlliesHealed;
 return {reproduced:healed>0 && C.isHostile(f,a.id,s.id),observed:{supportSide:C.sideOf(f,s.id),targetSide:C.sideOf(f,a.id),hpBefore:before,hpAfter:after,healEvent:healed,healPct:sp.effHealPct}};
});
caseRun('CB-03','Nonparticipant support changes external combat damage',()=>{
 const {W,a,d,s,f}=ctx();f.B=[d.id];
 support(W,s,'QIMEN_BATTLE_BANNER');C.applyDamage(W,f,a,d,25,'test third party');
 const buffed=s.supportState.totalCommandBuffs;
 return {reproduced:buffed>0 && !C.sideOf(f,s.id),observed:{supportInFight:C.sideOf(f,s.id),changedAttacks:buffed,insideRadius:true}};
});
caseRun('CB-04','Enemy defender guardian intercepts for opposite side',()=>{
 const {W,a,d,s,f}=ctx();s.cult.path='SAGE_SUPPORT';s.cult.stage=5;
 const gr=CULT.DEFENSIVE_ARTS.setDefensivePosture(W,s,null,'CELESTIAL_AEGIS_DOME');
 a.h.state.hp=Math.round(C.hpMax(a)*.85);const startS=C.hp(s);
 C.applyDamage(W,f,d,a,45,'test guardian opposing team');
 const proc=s.lastDefensiveArtProc;
 return {reproduced:!!proc&&proc.kind==='ALLY_AEGIS_INTERCEPT' && C.isHostile(f,s.id,a.id),observed:{guardianSide:C.sideOf(f,s.id),targetSide:C.sideOf(f,a.id),allowed:gr.allyInterceptActive,proc:proc||null,guardHpBefore:startS,guardHpAfter:C.hp(s)}};
});
caseRun('CB-05','Sect sword formation buffs opponent NPC damage',()=>{
 const {W,a,d,s,f}=ctx();f.B=[d.id]; W.sect.formationWarfare.activeStance='SWORD_NET_SLAUGHTER';
 let hit=0;const original=C.applyDamage;C.applyDamage=(ww,ff,aa,dd,v)=>{hit=v;return false;};
 try{C.applyDamage=original; // Use actual call and compare hp after with baseline fixed damage.
   a.h.state.hp=Math.max(40,Math.round(C.hpMax(a)*.65));const before=C.hp(a);
   C.applyDamage(W,f,d,a,30,'opponent strikes player');const delta=before-C.hp(a);
   return {reproduced:delta>=36 && C.isHostile(f,d.id,a.id),observed:{attackerSide:C.sideOf(f,d.id),sectPlayerSide:C.sideOf(f,a.id),dealt:delta,raw:30,activeStance:W.sect.formationWarfare.activeStance}};
 }finally{C.applyDamage=original;}
});
caseRun('CB-06','Sect siege barrier protects hostile NPC raider',()=>{
 const {W,a,d,s,f}=ctx();f.kind='raid';f.B=[d.id];W.sect.elementalBarrier={active:true,barrierHp:1000,absorbRatio:.35};
 const before=C.hp(d);C.applyDamage(W,f,a,d,100,'siege hit on raider');
 return {reproduced:W.sect.elementalBarrier.barrierHp<1000,observed:{defenderSide:C.sideOf(f,a.id),raiderSide:C.sideOf(f,d.id),barrierBefore:1000,barrierAfter:W.sect.elementalBarrier.barrierHp,enemyHpLost:before-C.hp(d)}};
});
caseRun('CB-07','Layered DOT stacks removed instead of decaying',()=>{
 const {W,a,d,f}=ctx();ST.addStatus(d,'poison',2,{per:.004,stacks:3,stackDecayMode:'LAYERED',src:a.id},W.t);
 const before=d.sx.map(x=>({k:x.k,stacks:x.stacks,until:x.until}));W.t+=2;C.statusTick(W,f,d);
 return {reproduced:!d.sx.some(x=>x.k==='poison'),observed:{before,after:d.sx,expected:'stack=2, renewed until'},note:'ST.purgeExpired runs before C.statusTick expiration branch'};
});
caseRun('CB-08','MECH_PUPPET path defense never drains mech integrity',()=>{
 const {W,a,d,s,f}=ctx();d.cult.path='MECH_PUPPET';d.cult.stage=3; const mech=CULT.ensureMechState(d); mech.integrity=100; mech.charge=0;mech.mode='BASTION';
 // Make a an attacker foe to avoid normal effects and reactive passive paths.
 const foe={id:'foe_mech_audit',foe:true,name:'audit demon',tier:3,hp:2000,hpMax:2000,x:d.x+1,y:d.y,skills:[]};W.foeById[foe.id]=foe;f.A=[foe.id];f.B=[d.id];
 const first=mech.integrity;
 const res=C.strike(W,f,foe,d,{M:.30,type:'p',forced:true,noCrit:true,noCounter:true,noReflect:true,noProc:true});
 return {reproduced:res.hit && mech.integrity===first,observed:{hit:res.hit,firstIntegrity:first,finalIntegrity:mech.integrity,mode:mech.mode,hasPathEntry:!!CULT.PATHS.MECH_PUPPET,damage:res.dmg}};
});
caseRun('CB-09','Support healing triggers on every hit with no spend or ICD',()=>{
 const {W,a,d,s,f}=ctx();f.B=[d.id];const sup=support(W,s,'ACUPOINT_MERIDIAN_THERAPY');
 d.h.state.hp=Math.round(C.hpMax(d)*.4);
 const qiBefore=s.h.state.qi;
 for(let i=0;i<8;i++) C.applyDamage(W,f,a,d,1,'eight micro hits same tick');
 return {reproduced:s.supportState.totalAlliesHealed>=Math.round(C.hpMax(d)*sup.effHealPct)*8 && s.h.state.qi===qiBefore,observed:{heals:s.supportState.totalAlliesHealed,healPct:sup.effHealPct,qiSpent:qiBefore-s.h.state.qi,hitCount:8,gameTimeElapsed:0,targetHp:C.hp(d)}};
});
caseRun('CB-10','chooseSkill throws for null target instead of support-only action',()=>{
 const {W,a,s,f}=ctx();let err=null;try{C.chooseSkill(W,f,a,null,{cds:{}})}catch(e){err=e.message;}
 return {reproduced:!!err&&/before initialization/i.test(err),observed:{error:err},note:'API-level guard; normal C.attack usually has a target'};
});
caseRun('CB-11','Combat spawns hit target via direct useSkill even with insufficient Qi',()=>{
 const {W,a,d,f}=ctx();f.B=[d.id]; const moves=G.SK.list(a).filter(p=>p && p.M>0 && G.SK.qiCost(a,p)>0 && (!G.MARTIAL||G.MARTIAL.skillEfficiency(a,p)>0));
 if(!moves.length)return {reproduced:false,observed:{note:'no castable move found'}};
 const p=moves[0],cost=G.SK.qiCost(a,p);a.h.state.qi=0;const before=C.hp(d);
 C.useSkill(W,f,a,d,p,{cds:{}});
 return {reproduced:a.h.state.qi===0 && !!a.castFx,observed:{skill:p.id,cost,qiAfter:a.h.state.qi,castFx:!!a.castFx,hpBefore:before,hpAfter:C.hp(d)},note:'Only direct API; chooseSkill rejects insufficient Qi. Do not classify player exploit.'};
});
caseRun('CB-12','Battle uses world-level sect protection without faction eligibility',()=>{
 const {W,a,d,s,f}=ctx();f.B=[d.id];W.sect.formationWarfare.activeStance='IMMORTAL_AEGIS_DOME';
 d.h.state.hp=Math.round(C.hpMax(d)*.75);const before=C.hp(d);C.applyDamage(W,f,a,d,100,'hostile protected');
 return {reproduced:before-C.hp(d)<=80,observed:{enemySide:C.sideOf(f,d.id),defendersSide:C.sideOf(f,a.id),damage:before-C.hp(d),raw:100,stance:W.sect.formationWarfare.activeStance}};
});
caseRun('CB-13','Combat death bypasses AI.kill bookkeeping and office cleanup',()=>{
 const {W,a,d,f}=ctx();f.B=[d.id];f.serious=true;d.h.state.hp=8;
 d.post='martial';W.sect.posts.martial=d.id;const beforeDeaths=W.deaths||0;
 const result=C.applyDamage(W,f,a,d,900,'fatal damage');
 return {reproduced:result===true && d.dead && d.post==='martial' && W.sect.posts.martial===d.id && (W.deaths||0)===beforeDeaths && !d.deathWhy,
 observed:{damageKilled:result,dead:d.dead,officerPost:d.post,sectOfficerId:W.sect.posts.martial,deathWhy:d.deathWhy||null,deathsBefore:beforeDeaths,deathsAfter:W.deaths||0,deathLogCount:(W.logs||[]).filter(x=>x.type==='death').length},note:'C.slay sets victim.dead=true before AI.kill; AI.kill returns early on n.dead'};
});
caseRun('CB-14','Legacy shieldBp is never debited by applyDamage',()=>{
 const {W,a,d,f}=ctx();f.B=[d.id];d.shieldBp=100;
 const hp0=C.hp(d);for(let i=0;i<4;i++)C.applyDamage(W,f,a,d,50,'shield test');
 return {reproduced:d.shieldBp===100 && hp0===C.hp(d),observed:{initialShield:100,remainingShield:d.shieldBp,hitCount:4,rawDamageTotal:200,hpLost:hp0-C.hp(d)},note:'shieldOf returns an object copy for shieldBp instead of a writable ref'};
});
caseRun('CB-15','DIRECT AI.kill correctly cleans offices (control)',()=>{
 const {W,d}=ctx();d.post='martial';W.sect.posts.martial=d.id;
 const beforeDeaths=W.deaths||0;G.AI.kill(W,d,'QA control');
 return {reproduced:false,observed:{dead:d.dead,post:d.post,officerSlot:W.sect.posts.martial||null,deathWhy:d.deathWhy,deathsDelta:(W.deaths||0)-beforeDeaths},note:'Expected control: shows state machine works when AI.kill called first'};
});
caseRun('CB-16','Combat-death stale office persists after save/load',()=>{
 const {W,a,d,f}=ctx();f.B=[d.id];f.serious=true;d.h.state.hp=5;d.post='martial';W.sect.posts.martial=d.id;
 C.applyDamage(W,f,a,d,900,'fatal then save');
 const W2=SIM.deserialize(SIM.serialize(W));const d2=W2.byId[d.id];
 return {reproduced:!!(d2 && d2.dead && d2.post==='martial' && W2.sect.posts.martial===d2.id && !(W2.deaths>0)),
 observed:{dead:d2&&d2.dead,post:d2&&d2.post,postRef:W2.sect.posts.martial,deathWhy:d2&&d2.deathWhy||null,deaths:W2.deaths||0}};
});
caseRun('CB-17','Siege barrier only protects player NPC and not foe (scope control)',()=>{
 const {W,a,d,f}=ctx();f.kind='raid';const foe={id:'foe_barrier_scope',name:'mob',foe:true,tier:2,hp:200,hpMax:200};W.foeById[foe.id]=foe;f.B=[foe.id];W.sect.elementalBarrier={active:true,barrierHp:1000,absorbRatio:.35};
 C.applyDamage(W,f,a,foe,50,'barrier scope');
 return {reproduced:false,observed:{barrierHp:W.sect.elementalBarrier.barrierHp,foeHp:foe.hp},note:'Control: normal foe-type raider does not consume barrier. CB-06 specific to hostile NPC combatants.'};
});
const result={source:'JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip',total:rows.length,reproduced:rows.filter(r=>r.reproduced).length,errors:rows.filter(r=>r.error).length,rows};
const out=process.env.OUTPUT_JSON||'COMBAT_DEEP_REPRO_RESULTS.json';fs.writeFileSync(out,JSON.stringify(result,null,2));console.log('TOTAL',result.total,'REPRO',result.reproduced,'ERRORS',result.errors);
