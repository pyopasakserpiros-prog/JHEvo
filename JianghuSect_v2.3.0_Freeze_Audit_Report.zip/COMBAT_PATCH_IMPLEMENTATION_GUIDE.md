# COMBAT v2.3.0 — ข้อกำหนดแก้ไขสำหรับ Coding AI (ไม่ใช่สั่งทำฟีเจอร์ใหม่)
> อ่าน `QA_COMBAT_SKILLS_STATUS_AUDIT_V230.md` และ `COMBAT_DEEP_REPRO_RESULTS.json` ก่อนแก้; อ้างอิง `COMBAT-xx` ใน commit/PR; อย่าเปลี่ยน source เวอร์ชันเริ่มต้นจนกว่าจะทำ baseline regression.

## ลำดับลงมือที่แนะนำ
**A. P0, แก้ transaction ตายต้นทาง** — COMBAT-01. `C.slay` ห้ามตั้ง `dead=true` ก่อน `AI.kill` ที่ guard; ต้อง transaction once + source-of-truth เดียว. เปิด regression death battle / normal / master / officer / summon / foe / save-load, ห้ามเพิ่ม count ตายสองครั้ง. รายงาน JHS/SECT/GEAR ต้องยืนยันร่วมกัน.

**B. แก้ faction eligibility / participant shared helper** — COMBAT-02/03/04/05/06. ใช้ `C.isAlly(f,...)` และ ownership W.sect/raid side ที่ถูกต้อง, ไม่เช็กแค่ `!foe`. Cover attack buff, heal, intercept, stance, elemental barrier. ห้ามพัง support/guardian ฝ่ายเดียวกัน.

**C. persistent resource & branch** — COMBAT-07 shieldBp ที่ไม่ลด; COMBAT-09 MECH_PUPPET unreachable; COMBAT-10 layered poison expiration; COMBAT-11 null target safe. เพิ่ม save/load mid-shield, mid-mech, mid-DOT.

**D. balance gate** — COMBAT-08 heal 8 ครั้งใน tick เดียวไม่เสีย Qi. ต้องให้ดีไซน์เลือกระหว่าง per-hit, per-tick budget, ICD; ห้ามกำหนดตัวเลขเนิร์ฟตามความรู้สึก. Benchmark DPS/EHP/cost บิลด์ support ก่อน/หลัง.

## Test-first acceptance
- **COMBAT-01**: ฆ่า NPC ตำแหน่ง martial 1 ครั้งแล้วต้องมี deathDay/deathWhy, W.deaths+1, post null ทั้ง NPC และ W.sect.posts, log ความตาย 1 ครั้ง, ผลสืบทอดถูกต้อง, เซฟโหลดแล้วคงสถานะ; เรียกซ้ำไม่เพิ่ม death count
- **COMBAT-02**: ฝ่าย B ไม่บัฟหรือฮีล A; ฝ่าย A ยังช่วย A ได้ตามระยะ; ทั้ง NPC vs NPC, NPC vs foe และ raid
- **COMBAT-03**: side=null ให้บัฟ/ฮีลไม่ได้ ขณะสมาชิกทีมเดียวกันในสนามได้ตามปกติ
- **COMBAT-04**: ศัตรูและผู้ไม่ร่วมศึกไม่ได้คุ้มกัน; ฝ่ายเดียวกันยัง intercept ได้โดยลดทรัพยากรตามเงื่อนไข
- **COMBAT-05**: ค่ายกลผู้เล่นไม่บัฟ/ป้องกัน NPC ฝ่ายตรงข้าม; NPC ฝ่ายผู้เล่นได้โบนัส; ถ้ารบกลางกลางต้องไม่ติดอัตโนมัติ
- **COMBAT-06**: NPC ผู้บุกไม่ได้ใช้กำแพง; ฝ่ายผู้ป้องกันใช้ได้; hostile foe, NPC-neutral, NPC-owned raiders มี regression
- **COMBAT-07**: 4 hits ×50 กับ shieldBp=100: โล่หมดตามกฎ, HP สูญเสียหลังโล่หมด; เซฟ/โหลดระหว่างฮิตไม่คืนโล่
- **COMBAT-08**: ทดสอบ 1-hit vs 8-hit ภายใน tick เดียว, heal ไม่ scale แปลกกับจำนวน hits; build สนับสนุนยังมีประโยชน์ ไม่ nerf แบบเหวี่ยง
- **COMBAT-09**: MECH_PUPPET BASTION ถูกตีแล้ว integrity ลดและ charge อัปเดต; generic paths ยังคงลดดาเมจตามเดิม
- **COMBAT-10**: poison layered 3→2→1→0 ข้ามหลาย tick และเซฟ/โหลดระหว่างเสื่อมชั้น; duration ปกติหมดแล้วหาย
- **COMBAT-11**: null target ไม่ throw, เลือกสกิล self/team หรือคืน null แบบปลอดภัยตามกฎ

## วิธีรัน
```bash
GAME_SOURCE_ROOT=/path/to/GAME_SOURCE node COMBAT_DEEP_REPRO_TESTS.js
```
`REPRO` คือ fail ของ invariant ในโค้ดเดิม. หลังแก้ violation 14 เคสควรไม่เกิด แต่ `CB-11` ยังคงเป็น inconclusive; เปลี่ยน assertion ให้เป็น positive invariants และแยก control ก่อนรวมใน CI. Re-run 10 baseline suites (`COMBAT_REGRESSION_BASELINE_LOG.txt`) รวม UI smoke และ long-run world tick ก่อนปล่อย.
