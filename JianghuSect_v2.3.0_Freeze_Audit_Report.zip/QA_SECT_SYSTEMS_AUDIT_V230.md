# รายงานตรวจระบบสำนักส่วนที่เหลือ — JianghuSect 2 v2.3.0
> **หมวดใหม่แยกจากเศรษฐกิจ / อุปกรณ์ / วิถีและสายย่อย** | ตรวจ 8 พฤศจิกายน 2026 | ต้นฉบับไม่ถูกแก้ไข

**SHA-256 ต้นฉบับ ZIP:** `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`

## 1) สรุปผู้บริหาร

ตรวจ **27 negative-path cases** กับระบบสำนักจริง: **27 เคสแสดงปัญหาหรือข้อทบทวนตามสมมติฐาน** (26 ประเด็นโค้ด/การเชื่อมต่อที่ต้องแก้หรือยืนยัน + 1 เรื่องสมดุลที่ให้เจ้าของเกมตัดสิน); ไม่ได้หมายความว่าเทสต์เดิม 27 ชุดล้มเหลว — สิ่งเหล่านี้เป็นชุดทดสอบใหม่ที่เขียนให้จงใจจับพฤติกรรมผิด.

จำนวนตามลำดับความสำคัญ: **P1: 18**, **P2: 7**, **P3: 1**, **REVIEW: 1**. ไม่มี P0 เพราะส่วนใหญ่เป็นข้อผิดพลาดร้ายแรงแต่ยังไม่พิสูจน์ว่าทำลายเซฟหรือเปิดช่องแบบไร้เพดานให้ผู้เล่นโดยตรงใน UI.

**ผลเทสต์เดิม (control):** 5 suites ที่ครอบคลุม politics, sect daily, officer/peaks, creative systems, architecture **ผ่านทุกชุด** เมื่อตรวจแยก. เทสต์ใหม่ค้นพบข้อผิดพลาดที่เทสต์ปกติยังไม่ตรวจ เช่น invalid input, duplicate actions, no-op integration, lifecycle วันหมดอายุ.

**ขอบเขต:** ตรวจสมาชิก/ตำแหน่ง/สืบทอด, ศาลวินัย, ก๊กการเมือง/กบฏ, สภา, แลกเปลี่ยนศิษย์/จารกรรม, โทเท็มและสายเลือด, บูรพาจารย์, ค่ายกล, ค่าหัว, ระบบช่วยบริหารและยอดเขา. แยกออกจากการตรวจ *ราคา รายได้ ต้นทุน และสมดุลเศรษฐกิจมหภาค* ของอีกแชท; เรื่องค่าหัวที่แตะรางวัลถูกรายงานเพราะปัญหา **ภารกิจ/เงื่อนไขการจบงาน** เป็นแกนหลัก.

### ประเด็นที่ควรจัดการก่อนเข้าสู่แพตช์ Freeze

1. **SECT-17/26:** ค่าหัวให้รางวัลโดยไม่ต้องทำภารกิจจริง และบอร์ดหมดหลัง 4 งานโดยไม่มีรอบสร้างใหม่. การรีเฟรชผ่าน API ในวันเดียวทำงานได้ แต่ **ยังไม่มีหลักฐานว่าผู้เล่นกดรีเฟรช API ผ่าน UI**.
2. **SECT-05/06/07/13:** ดวลตราแพ้ไม่ได้ตามปกติ (`|| true`), กบฏแยกตัวแต่ยังอยู่ในสำนักเดิม, ปราบแล้วผู้ถูกขังยังทำงาน และการกด resolve สร้างวิกฤตใหม่เอง.
3. **SECT-01/02/21:** ศาลตัดสินผิดคดี/ใช้คำพิพากษา invalid/การคุมขังไม่บังคับใช้กับ NPC.
4. **SECT-08/09/10/11:** แลกเปลี่ยนศิษย์ซ้ำวันเดียว ID ชน, ไม่มีกลับเมื่อ stayAway, จารกรรมฟรีสำเร็จเสมอและไม่มีตรวจเจ้าหน้าที่/ชนิดภารกิจ.
5. **SECT-22/23:** UI เปิด automation แต่ไม่พบการเรียกจาก Tick จริง; PEAKS.dailyTick ที่จะส่งสำรวจอัตโนมัติไม่ได้ถูกเรียกใน SIM (ยังมี PEAKS.tick สำหรับงานเดิม).
6. **SECT-16 (REVIEW):** สามารถเปิด 4 โทเท็มฟรีจาก UI ภายในวันเดียว รับโบนัสถาวรแรงมาก **อย่าเนิร์ฟโดยอัตโนมัติ** ต้องถามว่าเป็น design หรือไม่.

## 2) สรุปผลตามหมวด

| ระบบ | จำนวนเคส | ระดับ |
|---|---:|---|
| หอวินัย | 3 | P1 |
| ตำแหน่ง | 1 | P1 |
| สืบทอด | 1 | P1 |
| กบฏ/การเมือง | 5 | P1, P2 |
| ศิษย์แลกเปลี่ยน | 2 | P1 |
| จารกรรม | 2 | P1 |
| การเมืองภายใน | 1 | P1 |
| กบฏ/ข้อมูล | 1 | P3 |
| โทเท็ม/สายเลือด | 1 | P2 |
| โทเท็ม/สมดุล | 1 | REVIEW |
| กิจกรรม/ค่าหัว | 4 | P1, P2 |
| สภา | 1 | P2 |
| ศาลบรรพชน | 1 | P2 |
| ค่ายกล/อาณาเขต | 1 | P2 |
| ระบบอัตโนมัติ | 1 | P1 |
| ยอดเขา/การสำรวจ | 1 | P2 |

## 3) รายละเอียดสำหรับ AI เขียนโค้ด: 27 ประเด็น

ทุกข้อมี **ตำแหน่งโค้ด สาเหตุ ผลกระทบ หลักฐานที่รันจริง วิธีแก้ และเกณฑ์รับงาน**. “REPRO” หมายถึงพฤติกรรมเดิมที่ไม่ตรงกับ invariant ใน script; บางข้อเป็น API-only และไม่ควรเหมารวมว่าโกงผ่าน UI ได้.

### SECT-01 [P1] ศาลตัดสินคดีผิดคนเมื่อระบุรหัสคดีไม่ถูกต้อง
- **กลุ่ม/การเข้าถึง:** หอวินัย · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13345–13358; js/ui.js:1835–1839`
- **รากสาเหตุ:** ค้นหา caseId ไม่พบแล้ว fallback ไปคดีแรก จากนั้นลบและลงโทษคนในคดีนั้น
- **ผลกระทบ:** การคลิกจากสถานะ UI ล้าสมัย/รหัสเซฟเก่าอาจพิพากษาคนผิดโดยไม่แจ้ง
- **ผลรันทดสอบ:** `{"adjudicated":"CASE_1","before":["CASE_1","CASE_2"],"ok":true,"remaining":["CASE_2"]}`
- **แนวแก้:** หากส่ง caseId ที่ไม่ว่าง ต้องพบคดีตรงกันเท่านั้น มิฉะนั้น {ok:false,reason:"case-not-found"}; แยก action “เลือกคดีแรก” ที่ UI explicit
- **Accept:** ส่ง CASE_NONEXISTENT แล้วคดีเดิมทั้ง 2 คงอยู่ ไม่มีใครโดนลงโทษ
- **Repro case:** `S01`

### SECT-02 [P1] สั่งจำคุก 7 วัน แต่ NPC ยังมีสิทธิ์รับตำแหน่ง/ทำงาน
- **กลุ่ม/การเข้าถึง:** หอวินัย · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13369–13385, 684–685, 774–788`
- **รากสาเหตุ:** ศาลเขียน detainedUntilDay แต่ isOfficerAvailable/eligible และระบบงานอ่าน jail/punished อีกชุดหนึ่ง
- **ผลกระทบ:** บทลงโทษจำคุกไม่มีผลต่อการทำงานจริงและกฎหมายสำนักไม่สมเหตุสมผล
- **ผลรันทดสอบ:** `{"available":true,"day":360,"eligible":true,"until":367}`
- **แนวแก้:** รวม canonical isNpcDetained(W,n) และเชื่อมทุก eligibility/AI/office/expedition; migration กับ jail/punished เดิม
- **Accept:** ก่อนหมดวันที่กำหนดต้องไม่ทำงาน/รับตำแหน่ง; หลังพ้นวันกลับได้
- **Repro case:** `S02`

### SECT-03 [P1] API แต่งตั้งคนตายได้และทำสถานะตำแหน่งไม่สอดคล้อง
- **กลุ่ม/การเข้าถึง:** ตำแหน่ง · API (UI auto filter dead) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:774–808, 789–844; js/ui.js:1620–1640`
- **รากสาเหตุ:** SECT.appoint ไม่เรียก eligible และไม่ตรวจ dead/exiled/away เอง แม้ eligible ตอบ false
- **ผลกระทบ:** คืน true แล้วแก้ n.post เป็น martial ให้คนตาย ขณะที่ W.sect.posts อาจถูกระบบอื่นเคลียร์
- **ผลรันทดสอบ:** `{"appointed":true,"dead":true,"eligible":false,"postInSect":null}`
- **แนวแก้:** ตรวจ candidate validity ภายใน appoint เสมอและใช้ canonical eligibility; แยก force/editor explicit พร้อมเหตุผล
- **Accept:** ผู้สมัครตาย/ถูกขัง/ออกสำนัก แต่งตั้งไม่สำเร็จและไม่ mutate สถานะ
- **Repro case:** `S03`

### SECT-04 [P1] ย้ายผู้สืบทอดไปตำแหน่งอื่นแล้วยังค้าง successorId
- **กลุ่ม/การเข้าถึง:** สืบทอด · API+UI indirect · `runtime-reproduced`
- **โค้ด:** `js/sect.js:789–830, 844–854, 858–969`
- **รากสาเหตุ:** เมื่อ n.post เดิมเป็น disciples การแต่งตั้ง post ใหม่ล้าง posts.disciples แต่ไม่ได้ล้าง successorId
- **ผลกระทบ:** สองระบบรายงานคนละตำแหน่งและอาจเข้าสู่วิกฤตสืบทอดผิดคน
- **ผลรันทดสอบ:** `{"after":"n937698","before":"n937698","disciples":null,"martial":"n937698","post":"martial"}`
- **แนวแก้:** สร้าง updateSuccessorOfficeState บนทุกทางตั้ง/ย้าย/ปลดและ validate เมื่อโหลด
- **Accept:** successorId และ posts.disciples ต้องสอดคล้องหรือใช้สถานะ designate แยกชัดเจน
- **Repro case:** `S04`

### SECT-05 [P1] ดวลตราเจ้าสำนักชนะตลอดแม้กบฏแข็งแกร่งกว่า 26 เท่า
- **กลุ่ม/การเข้าถึง:** กบฏ/การเมือง · API (UI มีปุ่มเจรจาเป็นหลัก) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13858–13877`
- **รากสาเหตุ:** เงื่อนไข masterPow*1.15>=rebelPow || true บังคับ true เสมอ เว้น forceRebelWin
- **ผลกระทบ:** ความเสี่ยงดวลไม่มีจริง ทำให้การกบฏไม่สมเหตุสมผล
- **ผลรันทดสอบ:** `{"duelWinner":"MASTER","masterPower":316.46455788675144,"masterWon":true,"rebelPower":8266.180862038145}`
- **แนวแก้:** ตัด ||true; สุ่มผล/ใช้ combat resolver + บันทึกผลเมื่อกบฏชนะและระบบสืบทอด
- **Accept:** ทดลอง masterPower≈316 vs rebelPower≈8266 ให้ฝ่ายกบฏชนะได้โดยไม่ใช้ force flag
- **Repro case:** `S05`

### SECT-06 [P1] กบฏแยกสำนักแต่ผู้ติดตามยังเป็นสมาชิกสำนักเดิม
- **กลุ่ม/การเข้าถึง:** กบฏ/การเมือง · API (แผนเรื่อง) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13880–13896`
- **รากสาเหตุ:** สร้าง splinterSect.memberIds แต่ไม่ถอน NPC จาก W.npcs/W.byId และไม่ mark exiled/defector
- **ผลกระทบ:** สมาชิกอยู่พร้อมกันสองสำนัก นับประชากร/งาน/อำนาจซ้ำกับฝ่ายกบฏ
- **ผลรันทดสอบ:** `{"rebels":["n635818","n929261","n4_218"],"stillActiveAtHome":["n635818","n929261","n4_218"],"worldSectCount":1}`
- **แนวแก้:** กำหนด canonical ownership transition; ใช้ transfer/exile/leave แล้วถอนหน้าที่และ update peaks/posts/queue
- **Accept:** ทุก rebelId ไม่ปรากฏเป็นศิษย์ active ของสำนักเดิมหลัง SPLINTER
- **Repro case:** `S06`

### SECT-07 [P1] ปราบกบฏแล้วจับหัวหน้าขัง แต่ตัวจริงยังเดินทำงานได้
- **กลุ่ม/การเข้าถึง:** กบฏ/การเมือง · API (แผนเรื่อง) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13837–13858; js/sect.js:6867–6903`
- **รากสาเหตุ:** capturePrisoner สร้าง prisoner record ใหม่ แต่ไม่ย้าย/กัก/ถอน ringleaderId ต้นฉบับ
- **ผลกระทบ:** หัวหน้ากบฏมีทั้งสถานะ “ถูกขัง” และศิษย์ active ในสำนัก
- **ผลรันทดสอบ:** `{"away":false,"dead":false,"exiled":false,"jailed":0,"leaderId":"n668592","leaderRank":1,"prisoner":"ฝูหว่านชิง"}`
- **แนวแก้:** เชื่อม prisoner.sourceNpcId หรือ custodyRef กับ NPC จริง; ตั้ง detained/removed และคืนสถานะเมื่อปล่อย
- **Accept:** SUPPRESS แล้วหัวหน้ากบฏหยุดงานและถูกกักตัวจริง ไม่ปรากฏ 2 ตัวตน
- **Repro case:** `S07`

### SECT-08 [P1] ส่งศิษย์แลกเปลี่ยนซ้ำวันเดียว ได้รางวัลซ้ำและรหัสชนกัน
- **กลุ่ม/การเข้าถึง:** ศิษย์แลกเปลี่ยน · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14090–14146; js/ui.js:1915–1919`
- **รากสาเหตุ:** dispatchExchangeDisciple ไม่เช็ก active exchange/cooldown และใช้ id=EXCH_day_npcId
- **ผลกระทบ:** เพิ่ม exp/วิชาซ้ำได้ในช่วงวันเดียว; record IDs ซ้ำชน save/index/tooltip
- **ผลรันทดสอบ:** `{"firstOk":true,"records":["EXCH_360_n223062","EXCH_360_n223062"],"sameId":true,"secondOk":true}`
- **แนวแก้:** กำหนด active exchange check + cooldown + sequence ID; จ่ายรางวัลเมื่อกลับจริง
- **Accept:** ส่งคนเดิมในวันเดียว/ระหว่างรอคืนถูกปฏิเสธ; ID ทุก record unique
- **Repro case:** `S08`

### SECT-09 [P1] ศิษย์แลกเปลี่ยนแบบ stayAway ไม่มีวงจรกลับสำนัก
- **กลุ่ม/การเข้าถึง:** ศิษย์แลกเปลี่ยน · API (UI default stayAway=false) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14126–14139, 14074–14089`
- **รากสาเหตุ:** ตั้ง npc.away=true + returnDay แต่ไม่มี exchange daily tick/processor ที่คืน away=false และเปลี่ยนสถานะ
- **ผลกระทบ:** ตัวละครหายจากการทำงานตลอดแม้เลยกำหนดกลับ
- **ผลรันทดสอบ:** `{"away":true,"day":365,"hasExchangeTick":false,"returnDay":362,"status":"AWAY_STUDYING"}`
- **แนวแก้:** เพิ่ม tickExchangeDisciples(W) ใน daily clock; reconcile save โหลด และคืน/ยกเลิกเมื่อศิษย์เสียชีวิต
- **Accept:** W.day>returnDay แล้ว away=false และ status=COMPLETED/FAILED
- **Repro case:** `S09`

### SECT-10 [P1] จารกรรมสำเร็จ 100% และเพิ่ม earlyWarningBonus ไม่มีขีดจำกัด
- **กลุ่ม/การเข้าถึง:** จารกรรม · API (ไม่พบปุ่มตรง) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14168–14212`
- **รากสาเหตุ:** runEspionageOperation ตั้ง success:true และเพิ่ม +0.20 ทุกครั้งโดยไม่เช็กเสี่ยง/คูลดาวน์/cap
- **ผลกระทบ:** ทำซ้ำ 8 ครั้งเพิ่ม warning 0→1.6 และยังไม่มีความเสี่ยงใด ๆ
- **ผลรันทดสอบ:** `{"after":1.6,"before":0,"missions":8,"successes":8}`
- **แนวแก้:** ตรวจ spy/target/mission; ใช้ RNG seeded, cooldown, resource cost, upper bound, modifier duration หรือ stack rule
- **Accept:** ซ้ำ 8 ครั้งไม่สามารถโตไม่จำกัด/สำเร็จทุกครั้ง และแสดงเหตุผล fail
- **Repro case:** `S10`

### SECT-11 [P1] คนตายและชนิดภารกิจจารกรรมปลอมยังทำสำเร็จ
- **กลุ่ม/การเข้าถึง:** จารกรรม · API (ไม่พบปุ่มตรง) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14168–14212`
- **รากสาเหตุ:** รับ spy จาก W.byId แต่ไม่ตรวจ dead/exiled/away; missionType ที่ไม่รู้จักก็เข้า success:true
- **ผลกระทบ:** ตัวละครที่ปฏิบัติการไม่ได้สร้างรายงานสำเร็จและเพิ่ม warning
- **ผลรันทดสอบ:** `{"dead":true,"mission":"INVALID_MISSION","resultOk":true,"success":true,"warning":0.2}`
- **แนวแก้:** strict membership+availability check และ allowlist missionType; validate target sect ID
- **Accept:** spy.dead=true หรือ INVALID_MISSION คืน ok:false และไม่เปลี่ยน state
- **Repro case:** `S11`

### SECT-12 [P1] ญัตติทางการเมืองใบเดียวถูกตัดสินซ้ำและส่งผลซ้ำ
- **กลุ่ม/การเข้าถึง:** การเมืองภายใน · API/internal AI · `runtime-reproduced`
- **โค้ด:** `js/sect.js:6310–6465`
- **รากสาเหตุ:** resolvePoliticalNomination รับ object nomination โดยตรงโดยไม่ตรวจว่าอยู่ใน pending หรือ status===PENDING
- **ผลกระทบ:** สามารถใช้ข้อมูลญัตติเดิมแต่งตั้งใหม่และเพิ่ม undercurrent/history ซ้ำ
- **ผลรันทดสอบ:** `{"firstOk":true,"firstU":0,"history":2,"secondOk":true,"secondU":12,"status":"RESOLVED"}`
- **แนวแก้:** resolve ด้วย id จาก pending เท่านั้น; ตรวจสถานะก่อน mutate; optimistic state guard
- **Accept:** resolve ครั้งที่สองคืน ok:false และ counters/history ไม่เปลี่ยน
- **Repro case:** `S12`

### SECT-13 [P1] กดแก้วิกฤตกบฏทั้งที่ไม่มีวิกฤต ระบบกลับสร้างวิกฤตใหม่เอง
- **กลุ่ม/การเข้าถึง:** กบฏ/การเมือง · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13813–13822; js/ui.js:1910–1914, 4131–4131`
- **รากสาเหตุ:** resolveFactionSchism เรียก triggerFactionSchismCrisis โดยอัตโนมัติเมื่อไม่มี ACTIVE crisis
- **ผลกระทบ:** ปุ่มเจรจาใน UI สามารถสร้างกบฏจากความว่างเปล่าแล้ว “แก้” ทันที
- **ผลรันทดสอบ:** `{"before":false,"created":true,"mode":"NEGOTIATE","ok":true}`
- **แนวแก้:** คืน no-active-schism และซ่อน/disable action จนมีวิกฤตจริง; แยก debug spawn API
- **Accept:** เกมเริ่มต้นไม่มีวิกฤต กด resolve แล้วไม่สร้าง crisis/ไม่หักศิลา
- **Repro case:** `S13`

### SECT-14 [P3] รหัสสำนักกบฏนำกลับมาใช้ซ้ำหลังลบข้อมูลรายการ
- **กลุ่ม/การเข้าถึง:** กบฏ/ข้อมูล · API/edge only · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13880–13892`
- **รากสาเหตุ:** ใช้ splinterSects.length+1 แทน monotonic sequence
- **ผลกระทบ:** ถ้ามีการลบ records/กรองเซฟ อาจชน ID กับประวัติ/พันธมิตรเดิม
- **ผลรันทดสอบ:** `{"first":"SPLINTER_SECT_1","second":"SPLINTER_SECT_1"}`
- **แนวแก้:** ใช้ world.splinterSeq เพิ่มต่อเนื่อง และ migrate ID เดิมเฉพาะกรณีชน
- **Accept:** ลบ entry เก่าแล้วก่อกบฏใหม่ ID ต้องไม่ซ้ำ
- **Repro case:** `S14` · ทดสอบสภาวะ edge ไม่ยืนยันว่าผู้เล่นสร้างเหตุการณ์นี้ผ่าน UI ปกติ

### SECT-15 [P2] สระไขกระดูกปลุกสายเลือดคนเดิมได้เรื่อย ๆ และนับจำนวนผิด
- **กลุ่ม/การเข้าถึง:** โทเท็ม/สายเลือด · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:12615–12649; js/ui.js:1989–1999`
- **รากสาเหตุ:** cleanseMarrowPool เปิด awakenBloodline ทุกครั้ง ไม่มี cooldown/วัสดุ; awakenedCount++ แม้คนเดิมมีสายเลือดแล้ว
- **ผลกระทบ:** คลังตัวเลข “ปลุกแล้ว” เพิ่ม 12 จากผู้มีสายเลือดจริงคนเดียว; ฝึก body เพิ่มได้ซ้ำเล็กน้อยโดยไม่ลงทุน
- **ผลรันทดสอบ:** `{"afterScore":123,"afterTier":"SMALL","beforeScore":122,"beforeTier":"SMALL","bloodlineCount":12,"uniqueAwakened":1}`
- **แนวแก้:** เพิ่ม first-awakening guard, cooldown, cost; count derived from unique awakened NPCs
- **Accept:** ชำระซ้ำจะไม่เพิ่ม awakenedCount; ตัวนับเท่าจำนวนคนจริง; ทดสอบออก/เข้า
- **Repro case:** `S15`

### SECT-16 [REVIEW] สถาปนาโทเท็มครบ 4 ต้นฟรีทันที ให้โบนัสถาวรทุกคน
- **กลุ่ม/การเข้าถึง:** โทเท็ม/สมดุล · UI+API · `design-review`
- **โค้ด:** `js/sect.js:12576–12613, 12662–12694; js/ui.js:1788–1796, 4091–4101; js/stats.js:570–575`
- **รากสาเหตุ:** กดสร้างอีก 3 ต้นเพื่อเปิดครบ 4 ไม่มีเงื่อนไขขั้น/ทรัพยากร/cooldown เลย
- **ผลกระทบ:** ทดสอบแจกโบนัสรวม HP+18%, MATK+22%, ATK+12%, DEF+23%, MDEF+15% พร้อม flat CRIT+5 เป็นต้น; อาจเป็น intended meta
- **ผลรันทดสอบ:** `{"after":["TOTEM_AZURE_DRAGON","TOTEM_WHITE_TIGER","TOTEM_VERMILION_PHOENIX","TOTEM_BLACK_TORTOISE"],"afterBonus":{"active":true,"f":{"cast":8,"crit":5,"critDmg":16,"pen":10},"labelTh":"พรคุ้มครองเสาโทเท็มสำนัก","p":{"atk":0.12,"def":0.22999999999999998,"hp":0.18,"matk":0.22,"mdef":0.15}},"beforeBonus":{"active":false},"day":360,"start":["TOTEM_AZURE_DRAGON"],"stonesAfter":1000,"stonesBefore":1000}`
- **แนวแก้:** ให้เจ้าของเกมยืนยันเจตนา; ถ้าต้องการปลดตามความก้าวหน้า ให้เกตตามระดับสำนัก/ยอดเขาและใส่ต้นทุน ไม่เนิร์ฟโบนัสก่อน benchmark
- **Accept:** ถ้าตั้งใจแจกฟรี ให้ระบุในคำอธิบายเกม; ถ้าไม่ ตั้งเงื่อนไข/เกตพร้อมเทสต์
- **Repro case:** `S16`

### SECT-17 [P1] กดรับค่าหัวได้โดยไม่ล่าหรือต่อสู้; API รีเฟรชแล้วรับซ้ำในวันเดิม
- **กลุ่ม/การเข้าถึง:** กิจกรรม/ค่าหัว · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14237–14308; js/ui.js:1920–1924`
- **รากสาเหตุ:** claimBountyHunt ให้ rewards/merit/fame และสร้างเชลยทันทีโดยไม่มี combat/missions/party check; refreshBounties ไม่เช็กเวลา
- **ผลกระทบ:** จาก UI รับรางวัล 4 งานแรกได้เลย; หากเรียก refresh API แล้วรับเพิ่มวันเดิมได้ (ยังไม่พบปุ่มรีเฟรชโดยตรง)
- **ผลรันทดสอบ:** `{"completedAfterFirst":1,"completedAfterSecond":2,"fameDelta":24,"firstOk":true,"firstPrisoner":true,"sameDay":360,"secondOk":true,"secondPrisoner":true}`
- **แนวแก้:** สร้าง state CONTRACT→HUNTING→RETURN→CLAIMED หรือ auto-resolve แบบมี risk/time/cost; refresh มีวันขั้นต่ำ
- **Accept:** กด claim งานยังไม่จบถูกปฏิเสธ; ไม่มีสังหาร/จับสำเร็จฟรี; refresh API วันเดิมไม่ได้
- **Repro case:** `S17`

### SECT-18 [P2] สภาผู้อาวุโสรับรหัสญัตติที่ไม่มีจริงแล้วทำญัตติอื่น
- **กลุ่ม/การเข้าถึง:** สภา · API (UI ส่งค่า valid) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:9395–9404`
- **รากสาเหตุ:** MOTION_DEFS[motionId] || EXPAND_PRODUCTION_QUOTAS กลบ invalid ID
- **ผลกระทบ:** สั่งเรื่องหนึ่งแต่ระบบออกมติการผลิตเงียบ ๆ และแก้ state ผิดเรื่อง
- **ผลรันทดสอบ:** `{"actualMotion":"EXPAND_PRODUCTION_QUOTAS","ok":true,"passed":true}`
- **แนวแก้:** ถ้า argument ไม่ว่างและไม่อยู่ใน catalog ให้ invalid-motion; default ได้เฉพาะกรณีไม่ส่ง id และ UX ระบุ
- **Accept:** BAD_MOTION_ID คืน ok:false ไม่เปิดญัตติหรือบันทึกผล
- **Repro case:** `S18` · ทดสอบสภาวะ edge ไม่ยืนยันว่าผู้เล่นสร้างเหตุการณ์นี้ผ่าน UI ปกติ

### SECT-19 [P2] ถวายของโบราณซ้ำ UID ได้และปั๊มแต้มธูปทุกครั้ง
- **กลุ่ม/การเข้าถึง:** ศาลบรรพชน · API only (ไม่พบปุ่มบูชา relic) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13647–13663`
- **รากสาเหตุ:** enshrineAncestralRelic push ทุกครั้ง ไม่ตรวจ UID หรือการถือครอง; ได้ incensePoints+25 ทุกครั้ง
- **ผลกระทบ:** ไอเทมเดียวถวายได้สองครั้ง ข้อมูลซ้ำและเพิ่มแต้มธูป 100→150 จากสองครั้ง
- **ผลรันทดสอบ:** `{"a":true,"b":true,"entries":["SAME_ONE","SAME_ONE"],"incenseAfter":150,"incenseBefore":100}`
- **แนวแก้:** บังคับ owner/holding check + unique UID + transfer item to pavilion vault + one-time reward
- **Accept:** ใช้ UID ซ้ำครั้งสองคืน duplicate-relic และ incense ไม่เพิ่ม
- **Repro case:** `S19` · ทดสอบสภาวะ edge ไม่ยืนยันว่าผู้เล่นสร้างเหตุการณ์นี้ผ่าน UI ปกติ

### SECT-20 [P2] ระบุรหัสเสาค่ายกลผิด แต่เปลี่ยนยามเสาต้นแรก
- **กลุ่ม/การเข้าถึง:** ค่ายกล/อาณาเขต · API+UI indirect · `runtime-reproduced`
- **โค้ด:** `js/sect.js:12916–12927; js/ui.js:1845–1852`
- **รากสาเหตุ:** assignAnchorGuard ใช้ find(id) || grid.anchors[0] แม้ id ไม่ว่างแต่ไม่พบ
- **ผลกระทบ:** คำสั่งรหัสผิดไปเปลี่ยน NPC ผู้คุ้มกันเสาอื่นแบบไม่แจ้ง
- **ผลรันทดสอบ:** `{"guardAfter":"n198764","guardBefore":null,"modifiedAnchor":"ANCHOR_NORTH_PEAK","ok":true,"requested":"NOT_FOUND"}`
- **แนวแก้:** ถ้ามี id ต้อง match เท่านั้น; fallback ต้นแรกได้เฉพาะ omit id โดยตั้งใจ
- **Accept:** NOT_FOUND คืน ok:false และ guardNpcId เสาแรกคงเดิม
- **Repro case:** `S20`

### SECT-21 [P1] ศาลรับคำพิพากษาไม่รู้จักแล้วแอบลงโทษแบบหักแต้ม
- **กลุ่ม/การเข้าถึง:** หอวินัย · API (UI ส่ง valid) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13354–13400`
- **รากสาเหตุ:** vKey ไม่อยู่ในสองกรณีพิเศษแล้วเข้า else MERIT_FINE_AND_PENANCE โดยเก็บ verdict เป็นค่า invalid
- **ผลกระทบ:** ส่ง INVALID_VERDICT หัก merit 100→75 และปิดคดีทันที
- **ผลรันทดสอบ:** `{"casesRemaining":0,"meritAfter":75,"ok":true,"verdict":"INVALID_VERDICT"}`
- **แนวแก้:** กำหนด validVerdicts ชัดเจน ตรวจค่าก่อนลบคดี/ปรับ NPC
- **Accept:** invalid verdict ไม่หัก merit ไม่ปิดคดี และคืน reason
- **Repro case:** `S21`

### SECT-22 [P1] สวิตช์ระบบช่วยบริหารอัตโนมัติเปิดอยู่ แต่ SIM ไม่เคยเรียกงานอัตโนมัติ
- **กลุ่ม/การเข้าถึง:** ระบบอัตโนมัติ · UI-visible / static wiring · `static-wiring`
- **โค้ด:** `js/sect.js:13434–13534; js/sim.js:740–760, 300–310; js/ui.js:1878–1884, 4104–4120`
- **รากสาเหตุ:** AUTOMATION.runDailyAutomation ถูกนิยามและทดสอบโดยเรียกตรง แต่ไม่มี production call-site ในไฟล์ js อื่น; sim แค่ ensure policy
- **ผลกระทบ:** ปุ่มเปิดเผยให้เข้าใจว่าจะแจกยา/ซ่อมเสา/จัดยอดเขา แต่ Tick เกมไม่ทำตาม
- **ผลรันทดสอบ:** `{"externalCallSites":[],"policyDefaultEnabled":true}`
- **แนวแก้:** เชื่อมครั้งเดียวต่อวันใน SIM.daily/approved clock ด้วย lastRunDay guard, เปิด on/off ทุก rule และทดสอบหลายวัน
- **Accept:** เปิด auto + สร้างเงื่อนไขแล้ว 1 วันเกิดผล; ปิดแล้วไม่เกิด; เรียกซ้ำวันเดียวไม่แจกของซ้ำ
- **Repro case:** `S22`

### SECT-23 [P2] ทัพสำรวจยอดเขาอัตโนมัติถูกเขียนไว้แต่ไม่เชื่อม Tick เกม
- **กลุ่ม/การเข้าถึง:** ยอดเขา/การสำรวจ · static wiring / UI manual works · `static-wiring`
- **โค้ด:** `js/sect.js:13214–13310, 12279–12307; js/sim.js:750–756`
- **รากสาเหตุ:** PEAKS.dailyTick เรียก launchPeakExpedition เมื่อคลังยอดเขาต่ำ แต่ SIM.monthly เรียกเพียง PEAKS.tick ที่ไม่เรียก auto expedition
- **ผลกระทบ:** ยอดเขารอส่งสำรวจอัตโนมัติอยู่ในโค้ดแต่ไม่มีการเรียกจากวงรอบปกติ
- **ผลรันทดสอบ:** `{"externalCallSites":[],"simCallsPeakTick":true}`
- **แนวแก้:** เลือก cadence ที่ตั้งใจ (daily/monthly), เชื่อมอย่างระวังไม่ทำ PEAKS.tick ซ้ำ และเคารพคูลดาวน์/เสบียง
- **Accept:** เมื่อยอดเขาที่ก่อตั้งมีเงื่อนไขพร้อมและคลังต่ำ จะออกสำรวจอัตโนมัติตามรอบ ไม่ถี่เกิน
- **Repro case:** `S23`

### SECT-24 [P2] วิธีแก้วิกฤตกบฏไม่รู้จัก กลายเป็นคำสั่งแยกสำนัก
- **กลุ่ม/การเข้าถึง:** กบฏ/การเมือง · API only (UI fixed valid) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:13816–13898`
- **รากสาเหตุ:** ทุกค่าที่ไม่เข้า NEGOTIATE/SUPPRESS/SEAL_DUEL ไหลผ่านถึง default SPLINTER
- **ผลกระทบ:** ส่ง NO_SUCH_DECISION แล้วสำนักแตกถาวรและเปลี่ยนประวัติ
- **ผลรันทดสอบ:** `{"crisisStatus":"RESOLVED_SPLINTERED","mode":"SPLINTER","ok":true,"splinterCount":1}`
- **แนวแก้:** ใช้ explicit case SPLINTER กับ allowlist, unknown return invalid-resolution ก่อน mutate
- **Accept:** unknown ไม่แก้ crisis หรือสร้าง splinterSect
- **Repro case:** `S24` · ทดสอบสภาวะ edge ไม่ยืนยันว่าผู้เล่นสร้างเหตุการณ์นี้ผ่าน UI ปกติ

### SECT-25 [P2] ส่งรหัสประกาศจับที่ไม่มีจริง แต่ไปรับรางวัลงานแรก
- **กลุ่ม/การเข้าถึง:** กิจกรรม/ค่าหัว · API (UI omitted ID intentionally) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14261–14267`
- **รากสาเหตุ:** ค้นหา bountyId ไม่พบแล้ว fallback ไปงาน OPEN แรกเสมอ ไม่แยก null ออกจาก invalid ID
- **ผลกระทบ:** คำสั่งติดตั้ง/บันทึกผิดหมายเลขอาจจ่ายรางวัลคนละงาน
- **ผลรันทดสอบ:** `{"actual":"BOUNTY_1_1","ok":true,"remainingOpen":3,"requested":"WRONG_BOUNTY"}`
- **แนวแก้:** allow null/undefined เพื่อเลือกแรกตาม UI เท่านั้น แต่ explicit invalid ต้อง reject
- **Accept:** WRONG_BOUNTY ไม่ลดจำนวนงาน OPEN; null ยังคงเลือกแรกได้
- **Repro case:** `S25`

### SECT-26 [P1] ค่าหัวมีแค่สี่งานแล้วบอร์ดหมดถาวร ไม่รีสต็อกตามวัน
- **กลุ่ม/การเข้าถึง:** กิจกรรม/ค่าหัว · UI+API · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14220–14269, 14237–14255; js/ui.js:1920–1924`
- **รากสาเหตุ:** claimBountyHunt refresh เฉพาะเมื่อ activeBounties.length===0; หลังถูก CLAIMED ครบสี่รายการ length ยัง=4; ไม่มี timetable refresh
- **ผลกระทบ:** หลังเสร็จ 4 งานและผ่านไป 120 วันยัง claim เพิ่มไม่ได้ บอร์ดหยุดเป็น dead feature
- **ผลรันทดสอบ:** `{"active":["CLAIMED","CLAIMED","CLAIMED","CLAIMED"],"afterFourOk":false,"day":480,"firstFour":[true,true,true,true],"lastRefreshDay":360,"reason":"bounty-not-found"}`
- **แนวแก้:** ทำ daily/weekly refresh ที่ตรวจจำนวน OPEN และ lastRefreshDay หรือ prune CLAIMED; รักษา history และ ID unique
- **Accept:** วันใหม่ตาม cadence มีค่าหัวใหม่และไม่รีเซ็ตงานที่ยัง active แบบไม่ตั้งใจ
- **Repro case:** `S26`

### SECT-27 [P1] คนตายยังรับเครดิตจับค่าหัวและรางวัลเกียรติยศได้
- **กลุ่ม/การเข้าถึง:** กิจกรรม/ค่าหัว · API only (UI hunter fallback master) · `runtime-reproduced`
- **โค้ด:** `js/sect.js:14268–14308`
- **รากสาเหตุ:** claimBountyHunt ใช้ hunter จาก W.byId โดยไม่เช็ก dead/exiled/away/detained
- **ผลกระทบ:** ให้ dead=true แล้วกด claim สำเร็จ เพิ่มแต้ม merit เป็น 65 และระบุเป็นผู้จับ
- **ผลรันทดสอบ:** `{"claimed":"CLAIMED","hunterDead":true,"hunterId":"n818489","meritAfter":65,"ok":true}`
- **แนวแก้:** ตรวจ hunter availability และ actual mission completion; หากไม่มีคนพร้อมต้อง return no-hunter
- **Accept:** dead/exiled/detained hunter ได้ ok:false ไม่มีรางวัล/เลื่อนตำแหน่ง
- **Repro case:** `S27`

## 4) Regression matrix ที่ AI ควรเพิ่มลง CI

| สิ่งที่ทดสอบ | กรณีปกติ | กรณีผิด / ขอบเขต |
|---|---|---|
| ผู้สมัคร/ตำแหน่ง/สืบทอด | แต่งตั้ง-ย้าย-ปลดคนมีสิทธิ์ | ตาย, ขัง, away, เปลี่ยน post แล้ว successor stale |
| ศาลวินัย | ยื่นคดี ตัดสินตามรหัสจริง | unknown id, invalid verdict, detainedStillWorking |
| วิกฤตกบฏ | trigger→choice→resolve→save/load | ไม่มีวิกฤต, ชนิดผิด, duel ยุติธรรม, แยกตัว/ถูกจับจริง |
| การเมือง/สภา | เสนอ→โหวต→มติ | resolve ซ้ำ, unknown motion, claimant invalid |
| แลกเปลี่ยน/จารกรรม | ส่ง→กลับ→เรียนวิชา | action ซ้ำ, ID unique, invalid/dead spy, cap warning |
| โทเท็ม/สายเลือด | สถาปนา-ปลุก-คำนวณบัฟ | กดซ้ำ, cost/cooldown, unique NPC count |
| ค่าหัว | ประกาศ→ออกล่า→นำกลับ→รับรางวัล→รอบใหม่ | claim no mission, dead hunter, invalid id, ครบ 4 แล้วไม่หมดถาวร |
| ค่ายกล/ยอดเขา | guard/repair/peakExpedition | unknown anchor; SIM tick/wiring; cooldown |
| Automation | enabled/disabled auto rules | day guard, process exactly once/day, no work when disabled |

## 5) วิธีรันและเกณฑ์ก่อน/หลัง

1. แตก ZIP source v2.3.0 ที่ผู้ใช้ส่งไว้ และรัน: `GAME_SOURCE_ROOT=/path/to/GAME_SOURCE OUTPUT_JSON=sect_results.json node SECT_DEEP_REPRO_TESTS.js`
2. สคริปต์เป็น **negative repro baseline**: ผลเดิมแสดง `REPRO` 27 ข้อ โดย REVIEW โทเท็มไม่ใช่บัคยืนยัน. เมื่อแก้ให้เป็น green ให้ assertion invariant ผ่าน และแยก UI-test ที่กดปุ่มจริงเพื่อยืนยันผู้เล่นเข้าถึงได้.
3. รัน regression เดิมทั้งหมด ไม่ใช่แค่ห้าชุดที่นำมาเป็น control; ย้ำเรื่อง migration เซฟคดี/กบฏ/ตำแหน่ง/รายการแลกเปลี่ยน/รายการค่าหัว และห้ามล้างประวัติผู้เล่น.
4. สำหรับ API-only ต้องตรวจ call graph และเจตนาว่าถูกเรียกโดยกิจกรรมเกมจริงก่อนจัดเป็น exploit ผู้เล่น; คำสั่ง invalid ให้ reject แต่กรณี argument ว่างที่ UI ตั้งใจ auto-pick ยังต้องใช้งานได้.
5. การออกแบบการเมือง/ศาล/ค่าหัวควรมี invariant: atomic transitions, member ownership เดียว, idempotency, ID stable และทุก automation มี clock+cooldown+feature toggle.

## 6) ข้อจำกัดสำคัญ

- ตรวจด้วย Node runtime ของ release และการอ่าน code/UI-action ไม่ได้ทดสอบการคลิกทุกหน้าในเบราว์เซอร์จริง, การจำลองหลายปี, ระบบเศรษฐกิจทั้งหมด หรือ multiplayer (เกมเป็น standalone).
- กรณี `S15` ยืนยันว่าตัวนับ awakenedCount เพิ่มซ้ำ 12 รอบ แต่ **ไม่ได้ยืนยันว่าคะแนน Tier สำนัก +95 ต่อครั้ง**: ในการทดลองคะแนน Tier เปลี่ยนเพียง ~1 เพราะส่วนคำนวณ Tier ใช้ `CULT.sectFourSymbolSummary` คนละตัวนับ. ห้ามอ้างเป็นช่องปั๊ม Tier จากผลนี้.
- `S17` ผู้เล่นกดรับ 4 ค่าหัวแรกได้โดยไม่ต้องล่า แต่ **การรีเฟรชรอบเดียวกันมีเฉพาะ API**; UI ที่ตรวจไม่พบปุ่ม refresh. จึงห้ามเขียนว่าฟาร์มเงินไม่สิ้นสุดผ่าน UI โดยไม่พิสูจน์เพิ่ม.
- `S14` รหัสชนทดสอบหลังลบรายการด้วยตัวทดสอบ; ยังไม่ยืนยันว่าการลบแบบนั้นเกิดในเกมปกติ. จัด P3.
- `S16` โทเท็มแถมพลังแรงมากโดยไม่เสียทรัพยากรจริง แต่ความเหมาะสมต้องดูช่วงปลดล็อกตามเจตนาการออกแบบก่อน ไม่ถือว่าแรง=บัคเสมอ.
- ตำแหน่งโค้ดอ้าง **source ZIP v2.3.0 เดิมเท่านั้น**. ไม่มีการแก้ไฟล์ต้นฉบับ; อย่าใช้บรรทัดจากแพตช์อื่นโดยไม่เทียบ.

## 7) ไฟล์ชุดนี้ใน ZIP รวม

- `QA_SECT_SYSTEMS_AUDIT_V230.docx` / `.md` / `.json`: รายงานหมวดสำนักละเอียด แยกจากรายงานเดิม
- `SECT_PATCH_IMPLEMENTATION_GUIDE.md`: ลำดับแก้และ Definition of Done สำหรับ AI
- `SECT_DEEP_REPRO_TESTS.js`: สคริปต์ตรวจ 27 กรณี (ไม่แก้โค้ดเกม)
- `SECT_DEEP_REPRO_RESULTS.json` / `SECT_DEEP_REPRO_RUN_LOG.txt`: ผลสังเกตต้นฉบับ
- `SECT_REGRESSION_BASELINE_LOG.txt`: ผลทดสอบเดิม 5 ชุด (ผ่าน) ใช้เป็น control
- รายงาน 3 หมวดก่อนหน้ายังอยู่ครบใน ZIP เดียวกันโดยไม่เขียนทับ.


## 8) ภาคผนวกอัปเดต — ผลกระทบลูกโซ่ก่อนเปิดให้ผู้เล่น (8 พ.ย. 2026)

> เพิ่มเคสใหม่ **SECT-28 [P1]** จากรายงานเดิม 27 เป็น **28 ประเด็น (P1=19/P2=7/P3=1/REVIEW=1)**. อัปเดตข้อเดิมด้านล่างเป็นหลักฐานเพิ่ม ไม่แยกเป็นรายงานใหม่ และไม่นับเป็นบัคใหม่ซ้ำ.

### SECT-28 [P1] ศิษย์สืบทอดเสียชีวิต แต่ successorId ยังชี้ผู้ตาย

- **เส้นทาง:** `AI.kill` → `W.sect.posts.disciples` / `W.sect.successorId` → `SIM.serialize` → `SIM.deserialize`
- **โค้ด:** `js/ai.js:1765-1772`, `js/sect.js:805-813`; เกี่ยวข้องกับ SECT-04 (ย้ายตำแหน่งแล้วค้าง).
- **หลักฐาน C01:** ก่อนตาย `posts.disciples` และ `successorId` ชี้ NPC เดียวกัน; หลัง `AI.kill` โพสต์กลายเป็น null แต่ successorId ยังเป็นรหัสผู้ตาย; โหลดเซฟใหม่ยังเป็นรหัสเดิม.
- **ผล:** UI/ระบบสภา/การสืบทอดที่อ่านรหัสนี้โดยตรงอาจรายงานคนตายว่าเป็นผู้สืบทอด. เส้นทางคัดผู้สืบทอดใหม่บางส่วนตรวจ dead แล้ว จึง **ยังไม่ยืนยันว่าตั้งคนตายเป็นเจ้าสำนัก**; ปัญหาคือข้อมูล authoritative ขัดกัน.
- **แก้:** onMemberUnavailable ร่วมของตาย/ย้าย/ปลด/ออกจากสำนัก/กักขัง ตาม policy; cleanup successorId กับ posts ในธุรกรรมเดียวและ normalize บน load.
- **Acceptance:** ตายแล้วสองค่าต้อง null/ชี้คนมีสิทธิ์อย่างสอดคล้องทันทีและหลังโหลด; ทดสอบ master เสียชีวิตต่อเนื่องและเลือก successor จากผู้มีชีวิตได้.

### หลักฐานผลกระทบเพิ่มเติมต่อข้อเดิม (ไม่เพิ่มยอดเคส)

| ประเด็นเดิม | โซ่เหตุการณ์และผลที่รันได้จริง | การแก้ร่วมที่ต้องยืนยัน |
|---|---|---|
| SECT-02 | ลงโทษขังถึงวัน 367 → `SIM.guardRoster` จัดคนที่ถูกขังเข้าเวรยาม (C02). | canonical availability ต้องใช้ทั้งศาล ตำแหน่ง งาน และกองเวร |
| SECT-06 | SPLINTER → 3 สมาชิกยังอยู่ home → 2 คนถูกจัดเวรยามเดิม (C03); ผ่าน dailyUpdate และ save/load ยังอยู่สำนักเดิม (C12). | transfer ownership ถอด posts/guard/expedition + update tier/population |
| SECT-09 | ส่งไปเรียนแบบ `stayAway=true` returnDay=361; ผ่าน `SIM.dailyUpdate` ถึงวัน 364 ยัง AWAY_STUDYING; หลัง reload ยัง away=true (C04). | daily lifecycle ต้อง complete/cancel/return แน่นอน |
| SECT-17/27 | NPC ตายยัง claim bounty สำเร็จ ได้ merit +25, fame +12; ผล save/load ยังอยู่ (C07). | deny inactive hunter ก่อนให้รางวัลและก่อนจับ prisoner |
| SECT-19 | relic UID เดียวถวายได้ 2 ครั้ง แต้มธูป +50; รายการซ้ำยังอยู่หลังโหลด (C06). | unique UID + ownership transfer + idempotent API |
| SECT-16 REVIEW | เปิดโทเท็มฟรีครบ 4: ในตัวอย่าง rating NPC +28.9%, คะแนน Tier สำนัก 222→259 (+37) แต่ **Tier ยัง STANDARD เท่าเดิม** (C11); ไม่ฟันธงว่าโกง. | ตัดสิน design gate ก่อนปรับโบนัส; benchmark ปลายทาง |
| SECT-04 + SECT-28 | ย้ายตำแหน่ง/ตายล้าง posts ไม่ครบ ทำให้ successorId ไม่สอดคล้องถาวร. | consolidate lifecycle helper และ repair legacy saves |
| EQUIP: EQ-013 | AI.kill → จิตศาสตราเลือกทายาท → อาวุธเดิมผู้รับหายถาวร (C10). | ดูรายงานอุปกรณ์สำหรับ atomic item transfer |

### Definition of Done ระดับ release ไม่ใช่แค่ฟังก์ชันผ่าน

1. สมาชิกมี **สถานะและเจ้าของสำนักชุดเดียว**: ตาย/คุมขัง/ออก/แลกเปลี่ยน/กบฏต้องมีผลกับ office, guardRoster, peak, mission, AI duty, tier และ UI ในวันเดียวกัน; ไม่ทำให้ประวัติสูญหาย.
2. กิจกรรมที่ให้รางวัลต้องมี completed/claimed state; invalid/dead/away ID ต้องไม่มีผล; หลัง action ซ้ำต้อง idempotent; save/load แล้วห้ามคืนสิทธิ์เรียกรางวัลซ้ำ.
3. ต้องมี tests ตามลำดับ `action → day tick → save/load → world roster/equip/rating invariant` และตรวจทั้ง normal success + negative path; แก้ shared helper แทนแก้เฉพาะปุ่ม UI.
4. การอัปเกรดเซฟต้องกู้ orphan successor/member ownership และ special gear UIDs แบบไม่ทิ้งของผู้เล่น; ปัญหา API-only ให้ติดตาม call graph ไม่อ้างว่า UI โกงได้หากยังไม่มีหลักฐาน.

## การตรวจข้ามระบบเพิ่มเติม — COMBAT v2.3.0 (8 พ.ย. 2026)

**ผลกระทบลูกโซ่จากสนามรบต่อสำนัก:** COMBAT-01: ตายจากศึกแล้วตำแหน่ง (martial) ไม่ว่าง, W.deaths ไม่เพิ่ม, deathWhy ไม่บันทึก; ยืนยันเซฟ/โหลดแล้วข้อมูลค้าง จึงกระทบ successor, officer, inheritance, relationships. COMBAT-05/06: ค่ายกลให้โบนัส NPC ฝ่ายตรงข้าม และกำแพงธาตุรับดาเมจแทนผู้บุกที่เป็น NPC. ควรแก้ร่วมกับ SECT-28, เช็ก side/membership/party ร่วมกัน ไม่ใช่เช็กแค่ !foe.
