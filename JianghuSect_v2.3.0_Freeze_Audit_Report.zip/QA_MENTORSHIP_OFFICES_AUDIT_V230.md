# รายงาน QA เจาะลึก — ระบบอาจารย์–ศิษย์และตำแหน่งในสำนัก
**JianghuSect 2 v2.3.0 | Freeze / Release Candidate | 8 พฤศจิกายน 2026**

> ขอบเขต: ระบบ mentorship, สายสืบทอด, ชี้แนะ, ถ่ายทอดปราณ, UI กิจกรรมศิษย์, ตำแหน่ง 25 บทบาท/alias, สิทธิ์รักษาการ, การตาย/ออกจากสำนัก, ความสอดคล้องการบันทึกเซฟ. ตรวจซอร์สเกมต้นฉบับแบบ read-only ไม่แก้เกม.

## 1. สรุปผู้บริหารและ Release Gate

**ยังไม่ผ่านเกณฑ์ปล่อยเกม** ในหมวดนี้: พบช่องชี้แนะซ้ำผ่าน UI โดยไม่มีเวลา/ต้นทุน และเส้นทาง AI จบการสอนปกติกลับเปลี่ยนความเป็นอาจารย์อย่างเป็นทางการ รวมถึงการออกจากสำนักที่อาจค้างกลางทางด้วย exception.

- ไฟล์เกมต้นฉบับ: `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip`; SHA-256 `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`.
- ปริมาณ: 33 เคสอิสระ — **21 พบอาการ/เงื่อนไขผิดที่ยืนยันซ้ำได้**, **9 control ผ่าน**, **3 design-review**; ไม่มี test script error. 21 เคสไม่เท่ากับ 21 บัคไม่ซ้ำกัน.
- สังเคราะห์เป็น **14 root-cause findings ใหม่**: **P0 1, P1 10, P2 3**; ประเด็นกฎกติกา **3** ไม่รวมเป็นบัค; และ **1 บัคที่เคยรายงาน SECT-03** ยืนยันซ้ำ ไม่เพิ่มจำนวน.
- Regression เดิมเกี่ยวกับ lineages/offices/AI cognition จำนวน **9 suites** ผ่านทั้งหมดเมื่อรันแยก. การผ่านไม่ได้ครอบคลุม negative-path ที่ทดสอบรอบนี้.
- ระดับการเข้าถึง: UI path มี source path และ runtime call ให้ยืนยัน; ส่วน MOF-07/08/09/10/11/12 มีข้อจำกัดเป็นการเรียก API หรือ crafted state ตามรายการ. **ไม่ได้อ้างว่าได้คลิก UI ผ่าน Chromium แบบ end-to-end**.
- หลีกเลี่ยงการตรวจเศรษฐกิจ/เซฟเกมเชิงลึกซ้ำกับอีกแชท; ตรวจแค่ผลลูกโซ่จำเป็น เช่น mentorship/save persist, delegation, lifecycle.

## 2. แผนภาพผลกระทบข้ามระบบ

- **AI social teach → force bond → เปลี่ยนอาจารย์ → ตำรับ/ถ่ายทอดวิชา/โบนัสทะลวง → ความสัมพันธ์และพงศาวดาร → เซฟค้าง**
- **UI ชี้แนะซ้ำ → cult/merit/ลด stress/บัฟ → ข้ามช่วงบ่มเพาะและเพิ่มอำนาจอาจารย์ → สมดุลวิถีและการแข่งขันสำนัก**
- **ปลดตำแหน่ง → delegated authority ไม่ถูกถอน → ผู้รักษาการใช้อำนาจคลัง/ฝ่ายต่อไป → อำนาจในโลกกับ UI ไม่ตรงกัน**
- **NPC ใหม่ออกสำนัก → คืน knowledge exception หลังลบ roster → assets ไม่คืนครบ → สายอาจารย์/ตำแหน่ง/byId ยังอ้างตัวเก่า → สถานะผิดถาวรได้**

## 3. รายละเอียดสิ่งที่พบ (14 root causes)

### MOF-01 [P0] ชี้แนะซ้ำในเวลาเกมเดียวกัน ปั๊มค่าฝึก/คุณูปการ

**การเข้าถึง:** UI → core  |  **หลักฐาน:** MO-01, MO-20  |  **พิกัด:** `js/sect.js:5086–5120; js/ui.js:7549–7565`

**ผลทดสอบ:** ปุ่มชี้แนะเรียก coachDisciple โดยไม่มีข้อจำกัด session/day หรือค่าใช้จ่าย; การเรียก 12 ครั้ง ณ t=518760 สำเร็จทุกครั้ง ทำให้ cult.prog +124, merit อาจารย์ +24, เวลาไม่เปลี่ยน; ผลฝึกบางส่วนคงอยู่เมื่อเซฟ/โหลด.

**ผลกระทบลูกโซ่:** ผู้เล่นวนคลิก → เร่งบ่มเพาะ/ลด stress/heartDemon/เพิ่มบัฟ → ทะลวง/สเตตัส/สิทธิ์สายย่อยเร็วผิดธรรมชาติ → คุณูปการและตำแหน่งของอาจารย์ผิดสมดุล → ผลค้างในเซฟ.

**แนวทางแก้ต้นทาง:** บังคับ cooldown/งบฝึกและตรวจที่ core action; ระบุว่าหนึ่งรอบฝึกใช้เวลา/ทรัพยากรหรือโควตาใด; อย่าแก้เฉพาะปุ่ม UI.

**Acceptance test:** กด 12 ครั้ง ณ เวลาเดียวกัน: ครั้งเกินโควตาต้องถูกปฏิเสธและไม่มีการเปลี่ยน cult/merit/log; ข้ามเวลา/จ่ายต้นทุนครบแล้วจึงทำได้.

### MOF-02 [P1] กิจกรรมสอนของ AI เปลี่ยนสายอาจารย์–ศิษย์โดยอัตโนมัติ

**การเข้าถึง:** AI normal runtime + core  |  **หลักฐาน:** MO-02, MO-33  |  **พิกัด:** `js/ai.js:1720–1740; js/sect.js:5093–5096`

**ผลทดสอบ:** AI.pairEnd(type=teach) เรียก coachDisciple ซึ่งเรียก formBond(force:true) หากยังไม่ใช่ศิษย์; ทดสอบกำหนดศิษย์ให้ n_master ก่อน แล้วให้ AI คู่สอนอีกคนจบกิจกรรม พบ mentorId เปลี่ยนเป็น n4_105 และหลุดจากรายชื่อศิษย์อาจารย์เดิม.

**ผลกระทบลูกโซ่:** กิจกรรมทางสังคมธรรมดา → เปลี่ยนสายสืบทอด/ความสัมพันธ์/ผู้ได้โบนัสขณะทะลวง → พิธีถ่ายทอดปราณให้คนละคน → ข้อมูลประวัติและบัฟสำนักขัดแย้ง; เกิดเองได้แม้ผู้เล่นไม่ได้คลิก.

**แนวทางแก้ต้นทาง:** แยก mentoring lesson ชั่วคราวกับพิธีรับศิษย์อย่างเป็นทางการ; AI teach ไม่เรียก formBond(force:true); เปลี่ยนสายต้องผ่านกฎย้ายอาจารย์และอัปเดตทุกดัชนี.

**Acceptance test:** AI.pairEnd teach ไม่เปลี่ยน mentorId/mentor bond ของศิษย์ที่มีอาจารย์แล้ว และยังมอบ XP เรียนทั่วไปได้ตามกติกา.

### MOF-03 [P1] อาจารย์ที่ไม่พร้อมยังชี้แนะได้

**การเข้าถึง:** UI/core  |  **หลักฐาน:** MO-04  |  **พิกัด:** `js/sect.js:5086–5120; js/ui.js:7549–7565`

**ผลทดสอบ:** อาจารย์ที่ away=true, sealed=true และ jailUntil สูงกว่าเวลาปัจจุบันชี้แนะสำเร็จจริง; gain cult +15.

**ผลกระทบลูกโซ่:** จำคุก/ปิดด่าน/สำรวจไกล → ยังเพิ่มการฝึกของศิษย์ → ระบบความเสี่ยง/เวลาทำงาน/ระยะทางไร้ผล → เมต้าเลี่ยงข้อจำกัดการเดินทางและลงโทษ.

**แนวทางแก้ต้นทาง:** รวม eligibility กลางสำหรับการชี้แนะปกติ: สมาชิกอยู่ในสำนัก/มีชีวิต/พร้อมทำกิจกรรม/ไม่กักขังหรือออกเดินทาง; กรณีสอนระยะไกลต้องมีกฎเฉพาะ.

**Acceptance test:** away/sealed/detained ปฏิเสธและ state ไม่เปลี่ยน; กลับสำนักและพร้อมทำงานให้ชี้แนะได้.

### MOF-04 [P1] รับศิษย์ที่ถูกเนรเทศ/คุมขังได้โดยไม่ตรวจสถานะ

**การเข้าถึง:** Internal API; some callers may be UI  |  **หลักฐาน:** MO-05  |  **พิกัด:** `js/sect.js:5008–5085`

**ผลทดสอบ:** formBond ตรวจมีชีวิต/ขั้นฝึกแต่ไม่ได้ตรวจ exiled, detainedUntilDay และ membership; สถานะ exiled=true และถูกคุมขังยังทำพิธีรับศิษย์สำเร็จ.

**ผลกระทบลูกโซ่:** บทลงโทษไร้น้ำหนัก → สายอาจารย์ยังเพิ่มและเกิดโบนัส/ภารกิจ → ขัดกับกฎการจัดศิษย์ออกคณะเดินทางและการเมืองสำนัก.

**แนวทางแก้ต้นทาง:** เพิ่ม predicate ผู้เข้าพิธีทั้งสองฝ่าย พร้อมแยกประวัติศิษย์เก่าออกจากความสัมพันธ์ใช้งานปัจจุบัน.

**Acceptance test:** ผู้ถูกเนรเทศ/คุมขังไม่เป็นศิษย์ใหม่ได้; ผู้พ้นโทษและอยู่ในสำนักทำพิธีสำเร็จ.

### MOF-05 [P1] ข้ามเพดานศิษย์ 3 คนด้วยการชี้แนะ

**การเข้าถึง:** Core/API  |  **หลักฐาน:** MO-07; MO-06 control  |  **พิกัด:** `js/sect.js:5029–5039, 5093–5095`

**ผลทดสอบ:** formBond ปกติกันเกิน 3 คน แต่ coachDisciple เรียก formBond(force:true), ทำให้อาจารย์คนเดียวมี apprenticeIds 6 คน.

**ผลกระทบลูกโซ่:** ชี้แนะซ้ำ → สายศิษย์ขยายผิดเพดาน → เพิ่มผลต่อความสัมพันธ์, สืบทอด, จุดคุ้มครอง/โบนัส, ความถี่ AI mentor และกิจกรรมสำนัก.

**แนวทางแก้ต้นทาง:** กำหนด force scope เฉพาะ migration/เหตุการณ์พิเศษที่บันทึกเหตุผล; ชี้แนะและ UI ห้าม force รับศิษย์.

**Acceptance test:** 4th disciple ต้องไม่เพิ่มใน teacher.apprenticeIds; formBond ธรรมดา 3 คนยังผ่าน; ไม่มีข้อมูลสายค้าง.

### MOF-06 [P2] เปลี่ยนอาจารย์แล้ว bond ความสัมพันธ์เก่ายังค้างว่าเป็นสายตรง

**การเข้าถึง:** Core/save  |  **หลักฐาน:** MO-08, MO-23  |  **พิกัด:** `js/sect.js:5040–5078`

**ผลทดสอบ:** เมื่อเปลี่ยนทางการ mentorId และ family ถูกแก้ แต่ SECT.rel ของอาจารย์เก่า/ศิษย์ยังมี bond=อาจารย์สายตรง แม้เซฟ/โหลด.

**ผลกระทบลูกโซ่:** AI ตีความความไว้วางใจ/ความแค้น/ความโศกเศร้า/ลำดับสายผิด → พงศาวดารและกฎพบญาติใช้ข้อมูลขัดกัน.

**แนวทางแก้ต้นทาง:** บน reparent ชำระ/แปลง label ความสัมพันธ์เดิมเป็น "อดีตอาจารย์" โดยไม่ลบความผูกพันทางอารมณ์ทั้งหมด; ซิงก์ bond, mentorId, family, history.

**Acceptance test:** การเปลี่ยนสายทำให้ direct relation ของอาจารย์เก่าสิ้นสุด สายใหม่ตรงกัน และผลเหมือนเดิมหลังโหลด.

### MOF-07 [P1] ถ่ายทอดปราณให้คนนอกสายได้หลายคนและรับผลสะสม

**การเข้าถึง:** API internal, UI checks direct mentor  |  **หลักฐาน:** MO-09, MO-11  |  **พิกัด:** `js/sect.js:5122–5200; js/ui.js:7562–7565`

**ผลทดสอบ:** transmitQi ไม่ตรวจว่า disciple.mentorId === mentor.id; ครู 3 คนที่ไม่ใช่สายตรงถ่ายทอดต่อเนื่องให้ตัวละครหนึ่งคนจน cult.prog +557. ผู้ถ่ายทอดแต่ละคนใช้ครั้งเดียวจริง แต่ศิษย์รับจากหลายคนได้.

**ผลกระทบลูกโซ่:** ข้ามพิธีรับศิษย์ → เร่งทะลวง/ฟื้น HP-Qi/รับวิชาและ imprint ใหม่ → สร้างบิลด์ผิดธรรมชาติ/เสี่ยง imbalance; เกมเปิดช่อง internal API มากกว่าปุ่ม UI.

**แนวทางแก้ต้นทาง:** ระบุ policy การถ่ายทอด/ช่วงใกล้ตาย: ต้องเป็นศิษย์สายตรงและอยู่ร่วมฉาก ยกเว้นเหตุการณ์บันทึกสิทธิพิเศษ; จำกัด recipient หรือประวัติภายในช่วงเวลาที่ออกแบบ.

**Acceptance test:** ผู้ไม่มี bond ถูกปฏิเสธไม่เสีย qiTransmitted; 3 unrelated ไม่สามารถปั๊มความก้าวหน้าได้; ศิษย์ที่ถูกต้องรับได้ตาม intended rules.

### MOF-08 [P1] ผู้ตายหรือถูกเนรเทศยังถ่ายทอดปราณผ่าน API ได้

**การเข้าถึง:** API internal  |  **หลักฐาน:** MO-10  |  **พิกัด:** `js/sect.js:5122–5142; js/ai.js:1764–1772`

**ผลทดสอบ:** transmitQi ตรวจ disciple.dead แต่ไม่ตรวจ mentor.dead หรือ exiled; ตัวอย่างผู้ถ่ายทอด dead=true, exiled=true ยัง success.

**ผลกระทบลูกโซ่:** NPC ตาย/ถูกขับ → ยังถ่ายทอดพลังและสร้าง log/วิชา → ขัด life cycle; เสี่ยงแก้แล้วทำพิธีคำสั่งเสียก่อนตายพัง.

**แนวทางแก้ต้นทาง:** normal transmit ต้องตรวจ mentor alive/valid; dyingWish/preAscension ให้เกิดใน lifecycle ก่อน mark dead เท่านั้น พร้อม token เหตุการณ์/transaction.

**Acceptance test:** dead mentor transmission ผ่าน API ปกติถูกปฏิเสธ; legitimate dyingWish จาก AI.kill ก่อนตายยังผ่าน regression.

### MOF-09 [P1] ปลดตำแหน่งด้วยชื่อย่อทำให้ทะเบียนค้างและ exception

**การเข้าถึง:** API internal; UI resolves aliases  |  **หลักฐาน:** MO-14  |  **พิกัด:** `js/sect.js:789–858; js/ui.js:1637–1643`

**ผลทดสอบ:** appoint(diplomacy) แมปเป็น envoy แต่ dismiss(diplomacy) ไม่แมป; ตัวละคร n.post=null แต่ W.sect.posts.envoy ยังค้าง id และฟังก์ชัน throw เมื่ออ่าน POST[diplomacy].nameTh.

**ผลกระทบลูกโซ่:** ผู้บริหารพ้นตำแหน่งจากมุมบุคคล แต่สำนักยังมีผู้ถือครอง → สิทธิ์/เบี้ยหวัด/AI งานสำนัก/ผู้สืบทอดตำแหน่งผิด → save เก็บข้อมูลทะเบียนไม่ตรงกัน.

**แนวทางแก้ต้นทาง:** ใช้ canonical post resolver ตัวเดียวสำหรับ appoint, dismiss, holder, revokeDelegation; ห้าม mutate ก่อน validate post.

**Acceptance test:** ทุก alias ที่ใช้แต่งตั้งได้ต้องปลดได้; ไม่มี exception และ post/n.post/cognition สอดคล้อง.

### MOF-10 [P1] สิทธิ์ผู้รักษาการคงอยู่หลังปลดตำแหน่งต้นทาง

**การเข้าถึง:** Core internal, indirect AI  |  **หลักฐาน:** MO-15, MO-22; MO-16 control  |  **พิกัด:** `js/sect.js:844–855; js/cognition.js:266–338`

**ผลทดสอบ:** dismiss ไม่เรียก COG.syncOfficeAuthority; ผู้รักษาการเดิมยังผ่าน hasAuthority ก่อนถึงเวลา expiry; record ที่อ้าง holderId ไม่มีอยู่จริงก็ยังให้สิทธิ์ treasury ได้.

**ผลกระทบลูกโซ่:** ปลดคน/หนีจากสำนัก → ผู้รักษาการเดิมยังเบิกคลังหรือสั่งฝ่ายยุทธศาสตร์ → การตัดสินใจอัตโนมัติ/ทรัพยากร/ความเชื่อถือผิด; ยิ่งหนักหากเซฟสิทธิ์ค้าง.

**แนวทางแก้ต้นทาง:** บน dismiss/retire/death/replace sync/revoke delegation แบบ atomic; hasAuthority ต้องตรวจ holder ตัวจริง, scope, active window, domain รวมทั้ง subject ยังอยู่ในสำนัก.

**Acceptance test:** หลังปลด hasAuthority=false ทันที; บันทึก delegation ปลอม/หมดอายุไม่ผ่าน; replacement appointment ยังคงผ่าน control.

### MOF-11 [P2] API รับอาจารย์จากโลกคนละเซฟด้วย object โดยตรง

**การเข้าถึง:** Internal API (not ordinary UI)  |  **หลักฐาน:** MO-24  |  **พิกัด:** `js/sect.js:5008–5030; js/sect.js:MENTORSHIP.resolveNpc`

**ผลทดสอบ:** ส่ง NPC object ที่ไม่ได้อยู่ใน W.byId/W.npcs ให้ formBond ก็สำเร็จและไปแก้ apprenticeIds ของ object ภายนอก; mentorId ยังอาจชน ID ในอีกโลก.

**ผลกระทบลูกโซ่:** ข้อมูลโลก/เซฟปนกันเมื่อเรียก API ภายใน → สายสืบทอดอ้างคนผิด → history/rel/cult skew; ต่ำกว่าปัญหา UI และต้องระวัง shared object tests.

**แนวทางแก้ต้นทาง:** resolve NPC ที่ยอมรับ object ต้องตรวจ identity ด้วย W.byId[id]===obj และ active membership; ยกเว้น migration บันทึกเหตุผล.

**Acceptance test:** object จากโลกอื่นถูกปฏิเสธ โดยไม่แก้ทั้งสองโลก; object ใน W เดียวกันทำงานปกติ.

### MOF-12 [P2] flag รักษาการปิดแล้ว แต่ยังมีสิทธิ์คลัง

**การเข้าถึง:** Internal special-state  |  **หลักฐาน:** MO-26  |  **พิกัด:** `js/cognition.js:234, 266–273`

**ผลทดสอบ:** COG.role ตรวจ welfareAuthority.acting แต่ COG.hasAuthority(treasury) ตรวจเพียง welfareAuthority.id; record acting=false ยัง authorize.

**ผลกระทบลูกโซ่:** UI/คำอธิบายบอกว่าเป็นสมาชิกธรรมดา แต่ backend ยังให้สิทธิ์คลัง → automation และเบี้ยหวัด/การอนุมัติตัดสินผิด.

**แนวทางแก้ต้นทาง:** ใช้ predicate เดียวของ acting treasury ใน role และ hasAuthority; เช็ก active timestamp/active membership.

**Acceptance test:** acting=false ปฏิเสธ; acting=true พร้อมเงื่อนไขครบให้สิทธิ์; ข้ามเซฟแล้วยังเหมือนกัน.

### MOF-13 [P1] ผู้ที่ออกจากสำนักยังสอนและมีโบนัสช่วยทะลวง

**การเข้าถึง:** AI + core + lifecycle  |  **หลักฐาน:** MO-29, MO-30  |  **พิกัด:** `js/sim.js:473–490; js/sect.js:5086–5120; js/ai.js:836–853`

**ผลทดสอบ:** SIM.retire เอา NPC จาก W.npcs แต่ W.byId ยังชี้ object เดิม; coachDisciple ยอมรับและเพิ่ม cult +15 ให้ศิษย์; predicate mentor guidance ใน AI เช็กเพียง byId และ !dead จึงยังให้โบนัสทะลวง.

**ผลกระทบลูกโซ่:** อาจารย์ออกจากสำนัก → การฝึกและโอกาสสำเร็จทะลวงคงอยู่ → เกมโลกไม่รับรู้การจากลา → เส้นทางบรรพชน/มรดกและความสัมพันธ์ขัดกัน → ค้างในเซฟ.

**แนวทางแก้ต้นทาง:** กำหนด active-sect membership predicate ที่เป็น authoritative; อาจารย์อดีตยังอยู่เป็นประวัติได้แต่ไม่ถือเป็นผู้สอน active เว้นแต่มี remote mentoring rule ที่ชัด.

**Acceptance test:** หลัง retire ไม่สามารถ coach หรือให้ live guidance ได้; ประวัติศิษย์ยังดูได้โดยไม่พัง; ตอนกลับเข้าร่วมใหม่ต้อง revalidate.

### MOF-14 [P1] NPC ที่เพิ่งสร้างออกสำนักแล้ว exception หลังถูกลบรายชื่อ

**การเข้าถึง:** Normal lifecycle, not confined to mentorship  |  **หลักฐาน:** MO-31; MO-32 control  |  **พิกัด:** `js/sim.js:349, 473–486; js/knowledge.js:180–200, 665`

**ผลทดสอบ:** SIM.addNpc สร้าง inv ที่ยังไม่มี crystals/subManuals; SIM.retire ลบจาก W.npcs ก่อน MARTIAL.returnKnowledge; latter เรียก M.ensure ที่วนเฉพาะ roster ที่เหลือ แล้ว Object.entries(undefined) throw: Cannot convert undefined or null to object. เกิด partial removal.

**ผลกระทบลูกโซ่:** รับ NPC ใหม่ → ออกสำนัก/เนรเทศ/เลิกเป็นครู → ตัวละครหายจาก roster แต่คืนทรัพย์สินไม่ครบ → อาวุธ/คัมภีร์/คลัง-สมาชิกและบันทึกผิด → save potentially persists fragmented state.

**แนวทางแก้ต้นทาง:** normalize inventory ของ NPC ทันทีที่ addNpc; returnKnowledge defensive default; retire เป็น transaction: validate/transfer assets ก่อน final roster removal; ซิงก์ active indexes; retry safe.

**Acceptance test:** addNpc→retire ไม่ throw, อุปกรณ์+ทรัพย์สินคืนครบ, roster/byId/gone/mentorOffice consistent; failure injection ไม่ทำให้อยู่สถานะครึ่งทาง.

## 4. ประเด็นที่ต้องยืนยันกติกา ไม่ใช่บัคยืนยัน

### DR-01 พิธีสร้างวิชาประจำสำนักฟรีซ้ำ (MO-12)
สร้าง 6 วิชาโดยเวลาและศิลาปราณไม่ลด; อาจตั้งใจให้ระบบสร้างคัมภีร์เป็นรางวัลเชิงเนื้อเรื่อง ไม่ควรใส่ต้นทุนโดยพลการ **แนวพิจารณา:** กำหนดเพดานจำนวนวิชาที่ใช้ได้จริง/ประสิทธิภาพ การคัดเลือกเงื่อนไข และเทสต์ performance ของ library ใหญ่

### DR-02 แต่งตั้งแล้วได้ยศผู้อาวุโสถาวร (MO-17)
NPC rank1 ถูกเลื่อนเป็น rank4 + isElder=true และแม้ปลดยังเป็นผู้อาวุโส; อาจเป็นการให้เกียรติอย่างถาวร **แนวพิจารณา:** ตัดสินว่าตำแหน่งชั่วคราวหรือยศถาวร มีผลต่อสิทธิ์ลงคะแนน/เบี้ยหวัด/หอพักหรือไม่

### DR-03 เลือกผู้สืบทอดซ้ำได้ในเวลาเดียวกัน (MO-28)
electSuccessor สำเร็จ 4 ครั้งโดยเวลาไม่เดิน; อาจเป็นคำสั่งบริหารที่ตั้งใจอนุญาต **แนวพิจารณา:** กำหนดว่าต้องมี cooldown และค่าต้นทุนการเมือง หรือเพียง dedupe event/log เพื่อไม่ปั่นประวัติ

## 5. ความเกี่ยวข้องกับรายงานเดิม — ไม่ทำซ้ำ

- SECT-03 ใน QA_SECT_SYSTEMS_AUDIT_V230: การแต่งตั้งผู้ถูกคุมขัง/ออกภารกิจผ่านชั้น SECT.appoint (ยืนยันซ้ำด้วย MO-21; ไม่เปิดรหัสบัคใหม่ซ้ำ).
- `JHS-014` รายงานทั่วไป: byId ยังชี้อดีตสมาชิก (ซ้ำเชิงอาการกับ MOF-13); รอบนี้เพิ่มหลักฐานว่า mentorship/tribulation ใช้ byId โดยไม่กรอง active-membership.
- `SECT-28` ผู้สืบทอดที่ตายแล้วมี id ค้าง: กฎ sync สถานะ office/lineage ควรใช้ predicate เดียวกับผู้ดำรงตำแหน่งและการออกสำนัก.
- `COMBAT-01` ระบบตายจากศึกข้าม cleanup: การปรับ lifecycle ไม่ควรทำให้ mentorship dyingWish ขาด; ต้องทดสอบร่วมก่อนปล่อย.
- `DAO-002` คัมภีร์ข้ามวิถีหลังเปลี่ยนสาย: การถ่ายทอดปราณ/วิชามรดกต้อง recheck วิถีและขั้นใหม่ก่อนมอบ.

## 6. ผลทดสอบจริงและข้อจำกัด

| ประเภท | จำนวน | ผล |
|---|---:|---|
| บัค/เงื่อนไขผิดที่พิสูจน์ซ้ำ | 21 เคส | reproduced; จัดกลุ่มเป็น 14 สาเหตุใหม่ และ 1 known issue |
| กรณีควบคุม | 9 เคส | 9 ผ่าน |
| ทบทวนดีไซน์ | 3 เคส | สังเกตพฤติกรรมได้ แต่ยังไม่ฟันธงว่าเป็นบัค |
| ข้อผิดพลาดจากสคริปต์ | 0 | ไม่มี |
| Regression เดิม | 9 suites | exit=0 ทุกชุด เมื่อแยกรัน |

**ตัวอย่าง control ที่รักษาไว้หลังแก้:** ครูตายไม่ชี้แนะ, รับศิษย์ตรงเพดาน 3 ได้/คนที่ 4 ปกติถูกปฏิเสธ, รับคู่เดิมไม่เพิ่มประวัติซ้ำ, เปลี่ยนผู้ดำรงตำแหน่งถอนสิทธิ์ delegation, ระบบความคิดรู้จักผู้ที่ถูกปลด, สายอาจารย์ปกติอยู่รอดหลังเซฟ/โหลด, นักฝึกใหม่ไม่เหมาะสมถูกปฏิเสธ, แต่งตั้ง/ปลดแบบ canonical ยังทำงาน, normalize knowledge ก่อน retire ไม่ crash.

**ข้อจำกัดสำคัญ:** ชุด Node `test/load.js` สร้างโลกจำลองเฉพาะเคส; API internal/bad-state ต้องถูกจัดตามความเสี่ยงการเข้าถึงจริง; ไม่ได้ทำ manual UI E2E หรือทดสอบ 100+ ปีโลกเกมในรอบนี้. ผู้พัฒนาควรตรวจ input guards/softlock และ browser action อีกชั้นหลังแก้.

## 7. ลำดับแก้สำหรับ Coding AI

- **Blocker 1:** MOF-01 ปิด farm ชี้แนะไม่เสียเวลา/ต้นทุน ด้วย guard ที่ core + UI feedback; เพิ่ม idempotence และโควตาที่ชัด.
- **Blocker 2:** MOF-02, MOF-05, MOF-06 แยก teach จาก formal lineage, ถอด force รับศิษย์, ป้องกัน 3 คนเกินเพดานและเคลียร์ direct relation เก่า.
- **Blocker 3:** MOF-14 + MOF-13 ทำ NPC exit/retire เป็น atomic transition, normalize inv, ตรวจ roster เป็น authoritative สำหรับ live mentorship.
- **Blocker 4:** MOF-09/10/12 ทำ canonical office IDs, revoke delegated authority, sync cognition และเช็ค active/acting state ทุกครั้ง.
- **Blocker 5:** MOF-03/04/07/08/11 ปรับ active member eligibility และกฎถ่ายทอดปราณ โดยรักษา dying wish ก่อนตาย.
- **Regression gate:** รัน `MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js` แล้วต้องเปลี่ยน finding cases ให้เป็น rejection/expected behavior ตามเกณฑ์รายข้อ (ไม่ใช่ให้ script เก่าเขียวเพราะ test ยืนยันบัค), รันชุดมาตรฐาน 9 suites + full test + browser manual.

## 8. ภาคผนวก 33 เคสอิสระและค่า observed

| Case | ประเภท | ประเมินผล | สิ่งที่ทดสอบ |
|---|---|---|---|
| MO-01 | finding | ยืนยัน | Coaching repeatedly within same simulation minute |
| MO-02 | finding | ยืนยัน | Coaching unrelated disciple force-switches mentorship |
| MO-03 | control | ยืนยัน | Teacher unavailable/dead/exiled can be used for coaching? (control) |
| MO-04 | finding | ยืนยัน | Sealed / detained / absent teacher still teaches |
| MO-05 | finding | ยืนยัน | Exiled / imprisoned cannot form a teacher-disciple bond |
| MO-06 | control | ยืนยัน | Teacher-capacity bound works in ordinary formBond (control) |
| MO-07 | finding | ยืนยัน | Mentorship no cap when coaching forcibly creates pair |
| MO-08 | finding | ยืนยัน | Changing master leaves old social relation flagged as direct mentor |
| MO-09 | finding | ยืนยัน | Transmit Qi to non-disciple with no mentor relationship |
| MO-10 | finding | ยืนยัน | Transmit Qi by dead/exiled teacher |
| MO-11 | finding | ยืนยัน | Several unrelated teachers can feed same student cumulative breakthroughs |
| MO-12 | review | ยืนยัน | Synthesized sect art creation without cost, cooldown or capacity |
| MO-13 | control | ยืนยัน | Repeated formBond same pair is idempotent (control) |
| MO-14 | finding | ยืนยัน | Appoint alias then dismiss via alias leaves real slot and throws |
| MO-15 | finding | ยืนยัน | Dismissing office leaves a delegated officer authorized until expiry |
| MO-16 | control | ยืนยัน | Delegation survives holder replacement when original holder is absent |
| MO-17 | review | ยืนยัน | Dismissing new promoted officer retains elder rank permanently |
| MO-18 | control | ยืนยัน | Dismissed office remains in cached cognition role? |
| MO-19 | control | ยืนยัน | Mentor bond between active members remains across save/load (control) |
| MO-20 | finding | ยืนยัน | Mentor spam and office stale-state persist across save/load |
| MO-21 | finding | ยืนยัน | Office appointment allows detained candidate despite eligibility denial |
| MO-22 | finding | ยืนยัน | Cognition delegation authority accepts stale delegate record without holder |
| MO-23 | finding | ยืนยัน | Historical mentor relationship remains after switch, even after save/load |
| MO-24 | finding | ยืนยัน | Mentor appointment accepts cross-world NPC object |
| MO-25 | control | ยืนยัน | Invalid seniority prevents voluntary novice-mentor pairing (control) |
| MO-26 | finding | ยืนยัน | Acting welfare treasurer retains authority even when flag is inactive |
| MO-27 | control | ยืนยัน | Official appointment and dismissal updates post ledger normally (control) |
| MO-28 | review | ยืนยัน | Repeat election at same world time produces repeated official records |
| MO-29 | finding | ยืนยัน | Retired / out-of-sect teacher still grants coaching to student |
| MO-30 | finding | ยืนยัน | Removed mentor still grants tribulation guidance predicate |
| MO-31 | finding | ยืนยัน | Freshly added NPC retirement throws after roster removal |
| MO-32 | control | ยืนยัน | Knowledge normalization before retirement prevents TypeError (control) |
| MO-33 | finding | ยืนยัน | Ordinary AI teach interaction silently changes master-disciple lineage |

**ไฟล์ที่แนบใน ZIP:** `MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js`, `MENTORSHIP_OFFICES_DEEP_REPRO_RESULTS.json`, `MENTORSHIP_OFFICES_REGRESSION_LOG.txt`, และ `MENTORSHIP_OFFICES_PATCH_IMPLEMENTATION_GUIDE.md`.

**วิธีรัน:** `node MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js /absolute/path/to/GAME_SOURCE > result.json` (ต้องมี `test/load.js` ในซอร์สเกม).
**หลักการ:** ไม่มีการแก้ source เกม, ไม่มีการแนะนำ nerf meta เพียงเพราะตัวเลขสูง, อนุญาตทบทวน DR แยกจาก bug register.
