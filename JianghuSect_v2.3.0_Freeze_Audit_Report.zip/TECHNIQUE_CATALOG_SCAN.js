'use strict';
const fs=require('fs'), G=require(require('path').join(process.env.GAME_SOURCE_ROOT || require('path').join(__dirname, 'GAME_SOURCE'), 'test', 'load'));
const T=G.JD.TECH.techniques||[], Man=G.JD.TECH.mantras||[];
const all=T.concat(Man);const rows=[],issues=[];
const add=(severity,category,t,move,detail)=>issues.push({severity,category,techId:t.id,nameTh:t.nameTh,moveId:move&&move.id||'',detail});
const tMap=new Map(all.map(t=>[t.id,t]));const mids=new Map();
for(const t of all){
 const M=t.moveDefs||[];const passive=!!t.passive||/PASSIVE/.test(t.cat||'');
 if(!t.nameTh)add('HIGH','missing_name',t,null,'nameTh missing');
 if(!Number.isFinite(t.tier)||t.tier<1||t.tier>9)add('HIGH','invalid_tier',t,null,String(t.tier));
 if(!Array.isArray(t.stages)&&M.some(m=>(m.stageReq||1)>1))add('HIGH','stages_absent_multi_move',t,null,`${M.length} moves; maxStageReq ${Math.max(...M.map(m=>m.stageReq||1))}; unlockedStage() defaults 1`);
 if(Array.isArray(t.stages)&&M.length){const max=(t.stages||[]).reduce((a,s)=>Math.max(a,s.stage||1),1);for(const m of M)if((m.stageReq||1)>max)add('HIGH','unreachable_stage',t,m,`move requires ${m.stageReq} but highest technique stage ${max}`);}
 if(passive&&M.length)add('MEDIUM','passive_with_move',t,null,`${M.length} moves but flagged passive`);
 for(const m of M){
  let p=null;try{p=G.SK.moveProfile(t,m)}catch(e){add('HIGH','profile_exception',t,m,e.message);}
  if(mids.has(m.id)) add('HIGH','duplicate_move_id',t,m,`previous ${mids.get(m.id)}`);else mids.set(m.id,t.id);
  if(m.parentId&&m.parentId!==t.id)add('MEDIUM','parent_mismatch',t,m,m.parentId);
  if(p&&(!Number.isFinite(p.M)||!Number.isFinite(p.costPct)||!Number.isFinite(p.cd)||!Number.isFinite(p.wind)||!Number.isFinite(p.hits)))add('HIGH','nonfinite_profile',t,m,JSON.stringify(p));
  if(m.M<0||m.hits<0||m.costPct<0||m.cd<0||m.wind<0)add('HIGH','negative_move_stats',t,m,JSON.stringify({M:m.M,hits:m.hits,costPct:m.costPct,cd:m.cd,wind:m.wind}));
  if(p&&p.arch==='strike'&&m.arch&&!G.SK.ARCH[m.arch])add('MEDIUM','unknown_arch_fallback',t,m,m.arch);
  if(m.stageReq>1&&!t.stages)add('HIGH','no_stage_definition',t,m,`unreachable high move`);
  rows.push({techId:t.id,techName:t.nameTh,cat:t.cat,path:t.path,sub:t.sub,tier:t.tier,grade:t.grade,arch:m.arch,moveId:m.id,moveName:m.nameTh,stageReq:m.stageReq,reqMastery:m.reqMastery,reqCultStage:m.reqCultStage,cd:p&&p.cd,wind:p&&p.wind,M:p&&p.M,costPct:p&&p.costPct,hits:p&&p.hits,heal:p&&p.heal,shield:p&&p.shield,aoe:p&&p.aoe,team:p&&p.team,range:p&&p.range,aiRole:m.aiRole,reqWeapon:t.requiresWeapon,weaponTypes:t.weaponTypes});
 }
}
const result={counts:{total:all.length,tech:T.length,mantras:Man.length,moves:rows.length,issueTotal:issues.length,byCategory:issues.reduce((a,x)=>(a[x.category]=(a[x.category]||0)+1,a),{})},issues,rows};
fs.writeFileSync(require('path').join(__dirname, 'TECHNIQUE_CATALOG_SCAN.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result.counts,null,2));console.log('Sample issues',JSON.stringify(issues.slice(0,35),null,2));
