# รายงานตรวจวิถีหลัก / สายย่อย / สมดุลเมต้า — JianghuSect 2 v2.3.0
> **รายงานใหม่แยกหมวด (ไม่ทับรายงานอุปกรณ์)** | 8 พฤศจิกายน 2026 | source SHA-256: `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`

## 1. บทสรุป

**ขอบเขต:** ตรวจวิถีหลัก 43 วิถีและสายย่อย 286 สาย ใช้โค้ดจริงจากไฟล์ release เดิมบน Node.js; ไม่แก้ source และไม่อ้างว่าทดสอบผ่าน UI ทั้งหมดหรือผล DPS/EHP ครบทุกบิลด์.

**ผล:** พบ 5 กลุ่มปัญหาที่พิสูจน์ได้ (P0 ×1, P1 ×3, P2 ×1), ข้อทบทวนสมดุล ×1 และข้อมูล coverage ×1 รวม 7 ประเด็น. ชุดรันทดสอบ 8 กรณี: ยืนยันบัค 6 เคส (2 เคสใน DAO-001), control ผ่าน 1 และ review 1.

- **แก้ทันที P0:** 15 สายย่อยทะลวงขั้น 1→2 ไม่ได้ เพราะเงื่อนไขเช็กสกิลที่ไม่มีจริง (อ้างผิด 144 จุดใน 9 realm / 128 จุดในระดับ 2–9).
- **แก้ก่อน freeze P1:** สวมคัมภีร์ขั้น 7 ข้ามวิถีหลัง retrain ได้; AI แนะนำสายย่อยผิดจาก 38 affinity refs ใน 35 สาย; 3 วิถีหลักอ่านค่านิยมที่ไม่มีอยู่จริง.
- **แก้เมื่อพร้อม P2:** โบนัสทักษะจากการทะลวงสายย่อยค้างแคช ไม่อัปเดตทันที.
- **ยังไม่สรุปว่าโกง:** ผู้เชี่ยวชาญบางสายมี ATK/DEF/HP สูงมากเมื่อเทียบกับสายย่อย NONE แต่ยังไม่มีการพิสูจน์ด้วย DPS/EHP, ต้นทุนและความหายาก. **ห้ามเนิร์ฟอัตโนมัติ.**

## 2. รายงานแยกรายข้อ (ส่งให้ AI แก้ตรง ๆ)

### DAO-001 [P0] — 15 สายย่อยทะลวงขั้นต่อไม่ได้จริง เพราะอ้าง Skill ID ที่ไม่มีอยู่ในระบบ
**การจำแนก:** `BUG` | **ตำแหน่ง:** `js/cultivation.js:5360–5426`, `js/cultivation.js:5546–5614`, `js/cultivation.js:5981–6001`, `js/proficiency.js:10–46`
**สาเหตุ:** ข้อมูล realm.skillGate ของ 15 สายย่อยใช้ HERBALISM / COOKING / HERB_LORE / COMMERCE / FISHING / CRAFTING / LEADERSHIP แต่ skillRead() ยอมรับเฉพาะรายการ M.SKILL_INFO หรือเกตธาตุพิเศษ ข้อความสกิลที่ไม่รู้จักจึงถูกอ่านเป็น 0 เสมอ ไม่มีทางผ่าน requirement แม้มีศิลา/ตบะครบ และฝึกสกิลจริงถึง 100
**หลักฐาน:** สแกนพบ 144 references ที่ไม่ถูกต้องในเกต 9 ระดับรวม 15 สาย โดย 128 references อยู่ในเกตทะลวงระดับ 2–9; ทดลอง SPIRIT_GRAIN_SOVEREIGN มี herbalism=100, cooking=100, ศิลาและ progress ครบ แต่เกตอ่าน HERBALISM=0 (ต้อง 28), COOKING=0 (ต้อง 16), trackBreakthrough คืน blockedByGate=true
**ผลกระทบ:** NPC และผู้เล่นที่เดิน 15 สายนี้ถูกล็อกความก้าวหน้า; AI ที่พยายามแก้คอขวดฝึกผิด skill หรือวนลูปแก้ไม่ได้ ระบบติดขัดทั้งที่ทรัพยากรครบ
**แนวทางแก้:** สร้างชุด skill IDs ที่เป็น canonical เพียงแห่งเดียว และ validate realm.skillGate ตอนโหลดเกม/CI; map HERBALISM→herbalism, COOKING→cooking, HERB_LORE→herbalism, COMMERCE→trading; ตรวจเจตนา CRAFTING ว่าเป็น FORGING หรือ construction, LEADERSHIP ว่าเป็น administration หรือ diplomacy; FISHING ไม่มี M.SKILL_INFO ต้องเลือก survival/กิจกรรมประมงที่ฝึกได้จริง หรือเพิ่มสกิล canonical อย่างครบระบบ ไม่ใช่แค่แปลงเป็น fishing ตัวพิมพ์เล็กโดยไม่สร้างสกิล; migrate เซฟโดยไม่รีเซ็ต track
**เงื่อนไขรับงาน (acceptance):** ทุกเกต realms 2–9 อ้าง skill ที่ skillRead, skillPractice, skillDrill รองรับ; ตัวละครที่ครบ skill+stone+progress สามารถทะลวงได้; 15 สายไม่ติดบัค; สคริปต์ยืนยันไม่พบ invalidSkillRefs
**Repro IDs:** `DAO-001-A`, `DAO-001-B`

### DAO-002 [P1] — เปลี่ยนวิถีแล้วสวมคัมภีร์ขั้น 7 ต่างวิถีให้ตัวละครขั้น 1 ได้
**การจำแนก:** `BUG` | **ตำแหน่ง:** `js/retraining.js:13–46`, `js/ui.js:2478–2488`, `js/ui.js:6949–6955`, `js/stats.js:674–700`, `js/cultivation.js:4725–4749`
**สาเหตุ:** retrain() คัดลอก unlockedMantras ข้ามวิถีอย่างสมเหตุสมผลเพื่อเก็บองค์ความรู้ แต่ปุ่ม switch-mantra และรายการ UI ตรวจเพียง id อยู่ใน unlockedMantras ไม่ตรวจ tech.path หรือ tech.tier เทียบวิถีและขั้นปัจจุบัน; STATS.get() ให้โบนัสจาก tier มนตราที่สวมจริงโดยไม่คัดกรอง
**หลักฐาน:** ใช้ผลึกเปลี่ยน DEMON/SHADOW_ASSASSIN ขั้น 9 → XIAN/STAR_ARCHER ขั้น 1 (retrain ok=true); คัมภีร์เดิม MANTRA_DEMON_PRIMORDIAL_EMPEROR ขั้น 7 ยังอยู่ในรายการ unlocked และ UI ผ่านเงื่อนไข; สลับแล้ว MATK ตัวอย่างหนึ่ง 85→107 (ค่าขึ้นกับ seed); ดูค่าจริงที่ DAO_PATH_SUBPATH_REPRO_RESULTS.json
**ผลกระทบ:** ข้ามข้อจำกัดขั้นและความเฉพาะวิถีของโบนัสคัมภีร์ เป็นช่องโกงหลัง retrain แบบตั้งใจได้; ความแรงแปรตามระดับคัมภีร์
**แนวทางแก้:** เก็บ unlockedMantras เพื่อประวัติการเรียนได้ แต่เพิ่ม canonical canActivateMantra(n,id) ที่ตรวจ id, path, tier ≤ effectiveTechStage, คำสาป/ข้อยกเว้น; ใช้ใน UI listing, switch-mantra, auto-select, load reconciliation และ STATS.get() เพื่อป้องกันเซฟไม่ถูกต้อง; เลือกคัมภีร์ใหม่หลัง retrain เหมือนเดิม
**เงื่อนไขรับงาน (acceptance):** retrain แล้วมนตราเดิมยังเก็บใน unlock history แต่สวมข้ามวิถี/เกินขั้นไม่ได้; บังคับแก้ c.mantra จากเซฟเดิมให้ปลอดภัย; MATK ไม่โตเพราะคัมภีร์ต่างวิถี; มนตราถูกวิถี/ถูกขั้นยังสลับได้
**Repro IDs:** `DAO-002`

### DAO-003 [P1] — 35 สายย่อยมีค่า Affinity Preference อ้าง key ไม่มีอยู่ 38 จุด ทำให้เลือกสายเอนเอียง
**การจำแนก:** `BUG` | **ตำแหน่ง:** `js/cultivation.js:1696–1740`, `js/cultivation.js:1809–1821`, `js/human_core.js`, `js/proficiency.js:10–46`
**สาเหตุ:** SUBPREF ใช้ affinity ชื่อแบบอาวุธ/วิชา/อาชีพ เช่น ZITHER, FOCUS, HERBALISM, COMMERCE, FISHING, CRAFTING, BLOOD_DEMON, POISON_CORROSION แต่ HC.affinities ไม่มี key เหล่านี้ และ alias map ครอบคลุมเพียงบางรายการ; HC.eff กลับ 0 ทำให้ (0-30)*weight*.45 เป็นค่าลบคงที่ โดยไม่ได้อ่านความถนัดจริง
**หลักฐาน:** ตรวจ 38 records จาก CULT.SUBPREF กระจาย 35 สาย: ZITHER 8, BLOOD_DEMON 5, FOCUS 5, HERBALISM 4, COMMERCE 3, FISHING 3, POISON_CORROSION 3 และกลุ่มอื่น; ทั้งหมดอ่าน HC.eff(...)=0. ดูรายการครบใน DAO_PATH_SUBPATH_REPRO_RESULTS.json
**ผลกระทบ:** NPC มีโอกาสเลือกสายที่เหมาะกับตนลดลงแบบไม่รู้ตัว บางสายใน 286 สายด้อยโอกาสกว่าเพื่อนโดยข้อมูลไม่ตั้งใจ; ไม่ใช่พลังต่อสู้ถูกคูณไม่จำกัด
**แนวทางแก้:** สร้าง alias resolver แยกระหว่าง HC affinity กับ martial skill; FOCUS/ZITHER/WHIP ให้ใช้ affinity proxy ที่เหมาะสมหรือ M.skillRead ตามกฎชัด; HERBALISM/COMMERCE/CRAFTING ฯลฯ map ไป canonical skill/aptitude; BLOOD_DEMON และ POISON_CORROSION ต้องกำหนดความหมายเชิง design ไม่สร้าง key ปลอม; validate ทุก SUBPREF key ใน CI; จัดการคะแนนเดิมอย่างระมัดระวังเพื่อหลีกเลี่ยงเปลี่ยน population distribution รุนแรง
**เงื่อนไขรับงาน (acceptance):** ไม่มี SUBPREF aff key ที่ resolver คืน 0 เพราะไม่รู้จักโดยไม่มีนิยาม explicit; เปลี่ยนค่าความถนัดจริงแล้วคะแนนสายที่อ้างต้องตอบสนอง; สัดส่วนเลือกสายย่อย baseline มีเหตุผล
**Repro IDs:** `DAO-003`

### DAO-004 [P1] — วิถีค้าขาย เสี่ยงโชค และพิธีบรรพชน อ่านชื่อตัวแปรค่านิยมผิด
**การจำแนก:** `BUG` | **ตำแหน่ง:** `js/cultivation.js:1780–1812`, `js/human_core.js`
**สาเหตุ:** CULT.pathScores ใช้ values.wealth (MERCANTILE_DAO และ FORTUNE_GAMBLER) และ values.dutyHonor (ANCESTRAL_RITUAL) ทั้งที่ human core มี wealthResource, sectDuty, honorLegacy; ค่า invalid เป็น 0 และไม่ขึ้นตามความชอบจริง
**หลักฐาน:** เปลี่ยน wealthResource หรือ sectDuty ของ NPC จากค่าหนึ่งไปอีกขั้วพร้อม HC.bump() แต่คะแนนทั้ง 3 วิถีเปลี่ยน 0.000 สำหรับสายย่อยในวิถีเดียวกัน; ข้อมูล key ปัจจุบันตรวจสอบได้จาก n.h.values
**ผลกระทบ:** ตัวละครนิยมทรัพย์สินไม่ได้มีแนวโน้มสู่วิถีค้าขาย/เสี่ยงโชคตามที่สูตรตั้งใจไว้ ตัวละครจงรักภักดี/ยกย่องบรรพชนไม่ส่งผลกับพิธีบรรพชน; เป็นสมดุล AI ที่ผิดแต่ไม่ใช่ช่องโกงตรง ๆ
**แนวทางแก้:** แก้ wealth→wealthResource, dutyHonor→เลือก sectDuty / honorLegacy หรือสูตรผสมตามความหมายของวิถี; เพิ่ม schema validation สำหรับ HC.eff paths ที่เป็นค่า attribute โดยเฉพาะ; ทำ rank-distribution test เพื่อจับ regression
**เงื่อนไขรับงาน (acceptance):** ปรับ wealthResource 0→100 ทำให้คะแนน MERCANTILE_DAO และ FORTUNE_GAMBLER ตอบสนองอย่างมีนัย; ปรับ sectDuty/honorLegacy ทำให้ ANCESTRAL_RITUAL เปลี่ยน; ไม่ใช้ key ที่ไม่มีจริง
**Repro IDs:** `DAO-004`

### DAO-005 [P2] — โบนัสทักษะสายย่อยค้างในแคชหลังทะลวงระดับสำเร็จ
**การจำแนก:** `BUG` | **ตำแหน่ง:** `js/martial.js:337–349`, `js/martial.js:1009–1030`, `js/cultivation.js:5981–6032`
**สาเหตุ:** M.progression(n) คำนวณค่าจาก c.track.ordinal แต่ M.lifeMult(n,skill) cache key มี path/sub/stage/mantra/_passVer และไม่มี track.ordinal; trackBreakthrough() อัปเดต ordinal พร้อม HC.bump() โดยไม่ invalidateMartialCaches() จึงคืนค่าโบนัสทักษะเดิมจนมีการล้างแคชจากกิจกรรมอื่น
**หลักฐาน:** ทะลวง WOOD_SPRING_BODY จาก track 5→6 ด้วย skill gate, stones และ progress ครบ และใช้ guarantee:true เฉพาะเพื่อกัน RNG ล้มเหลวขณะทดสอบ; lifeMult(herbalism) ก่อน=1.298175 หลังทะลวง=1.298175 แต่หลัง invalidateMartialCaches กลายเป็น=1.327580
**ผลกระทบ:** ผลตอบแทนความเชี่ยวชาญชีวิต เช่น เก็บสมุนไพร/แพทย์/หลอมไม่ขึ้นทันที ทำให้ tooltip/progression ต่างจากผลจริง จนกว่าจะเกิด invalidation อื่น; ไม่ใช่บัคที่บวกพลังเกินแต่ทำให้ผู้เล่นเสียประโยชน์
**แนวทางแก้:** เพิ่ม c.track.ordinal ใน cache key ของ M.lifeMult (และตรวจแคชอื่นที่ขึ้นกับ track); หรือ invalidateMartialCaches ใน trackBreakthrough ทั้ง success/failure หากมีผลต่อค่าที่คำนวณ; ตรวจทดสอบ track 1→9 พร้อม ST.dirty และ HC.bump
**เงื่อนไขรับงาน (acceptance):** หลังทะลวงถูกต้อง M.lifeMult เปลี่ยนทันทีโดยไม่เรียก invalidate เพิ่ม; ไม่ได้เปลี่ยนค่าเมื่อทะลวงไม่สำเร็จ; ไม่มี stale cache ข้าม save-load/เปลี่ยนสาย
**Repro IDs:** `DAO-005`

### DAO-006 [REVIEW] — กลุ่มสายย่อยปลายเกมมีสเตตัสสูงโดดเด่น แต่ยังไม่มีหลักฐานว่าเก่งเกินทุกบิลด์
**การจำแนก:** `BALANCE` | **ตำแหน่ง:** `js/martial.js:15–120`, `js/martial.js:337–347`, `js/stats.js:440–512`, `data/data_martial.js`
**สาเหตุ:** สายย่อยต่างบทบาทจงใจบวก ATK/MATK/DEF/HP ต่างกัน การเทียบกับตัวละคร path เดิมที่ sub=NONE แสดงความแรงในการเลือกสาย แต่ไม่ได้พิสูจน์ DPS/EHP จริง และไม่ได้รวมต้นทุน, วิชา, โบนัสเซ็ต, ตำนาน, AI และ matchups
**หลักฐาน:** ทดสอบ 286 สาย ณ ขั้นหลักสูงสุดของวิถี ติดตั้งอุปกรณ์ว่าง ไม่มี mantra/tech active, same NPC seed; เทียบ NONE ในวิถีเดียวกัน. median atk +47.62%, p95 +72.89%, top BLOOD_DEMON/XIAN +97.29%; def top COLOSSUS_SHIELD_TAMER +112.99%; hp top SOUL_VESSEL_AVATAR +62.80% (ทั้งหมดยังเป็นค่าต่างสเตตัส ไม่ใช่ดาเมจหรืออัตราชนะ)
**ผลกระทบ:** อาจเกิด dominant builds ถ้า burst+sustain+survivability สูงพร้อมกันโดยไม่มี tradeoff จริง; ยังไม่ควรเนิร์ฟแบบทั้งสายเพราะเทียบกับ NONE ซึ่งเป็น baseline ที่จงใจอ่อนกว่าสายเฉพาะ
**แนวทางแก้:** ยังไม่เนิร์ฟจากสแกนนี้; ทดสอบทุกวิถีเปรียบ matched tier+stage+rarity+equipment กับ 3 archetypes (burst, tank, support), 100–1,000 battle seeds, ดู DPS/EHP/utility/qi economy/time-to-build/rarity และ counterplay; แก้ exploit จากอุปกรณ์ก่อน re-baseline paths
**เงื่อนไขรับงาน (acceptance):** มี benchmark ย้อนซ้ำได้ที่ระบุ seed, tier, stage, item quality, skill/tech loadouts, rarity; ถ้า build ชนะทุกสถานการณ์แบบไม่มี tradeoff ค่อยเสนอปรับเฉพาะจุด
**Repro IDs:** `DAO-007`

### DAO-007 [INFO] — โครงสร้าง 43 วิถี / 286 สายย่อยและไฟล์สเตตัสพื้นฐานครบในชุดตรวจ
**การจำแนก:** `COVERAGE` | **ตำแหน่ง:** `js/cultivation.js`, `js/martial.js`, `js/stats.js`, `data/data_cult.js`, `data/data_expansion.js`
**สาเหตุ:** ตรวจรายการวิถีจาก CULT.PATHS และสายย่อยทุกวิถี, M.PROFILES, ST.SUBFX และ expansion subStats ประกอบกับค่าการคำนวณสเตตัสที่ขั้นสูงสุด
**หลักฐาน:** 43 major paths, 286 subpaths, ไม่พบ missing M.PROFILES หรือ missing substats, ค่า stat vectors ที่ตรวจไม่มี NaN/Infinity; ข้อมูลครบไม่ได้แปลว่าทุกเอฟเฟกต์ถูกนำไปเรียกใช้ถูกต้อง
**ผลกระทบ:** เป็นผลตรวจขอบเขตและข้อมูลสำหรับแยกปัญหา ไม่ใช่บัค
**แนวทางแก้:** เก็บ validator รายชื่อ/ID unique/ref integrity และ rerun unit suite ทุกแพตช์; เมื่อแก้ data add assertions per path
**เงื่อนไขรับงาน (acceptance):** รีรันได้ coverage เท่าเดิมหรือเปลี่ยนตามการออกแบบโดยไม่เกิด orphan data, missing profile, nonfinite stat; 15 dead-end gate ต้องเป็นศูนย์
**Repro IDs:** `DAO-006`

## 3. รายชื่อสายย่อยที่ทะลวงขั้นไม่ได้ครบทุกสาย (DAO-001)

ตารางนี้เป็นการอ้างอิง **ทั้ง 15 สาย**; `invalid refs` นับทั้ง 9 realms และทุก reference ที่ไม่อยู่ในตัวอ่านทักษะ.

| วิถีหลัก | สายย่อย | Skill ID ที่ไม่มีจริง | refs |
|---|---|---|---:|
| `VENOM_GU` | `IMMORTAL_NECTAR_TOXIN_SAGE` | `HERB_LORE` | 9 |
| `WANDERING_DAO` | `CLOUD_STEP_HERMIT` | `HERB_LORE` | 9 |
| `OCCULT_MAGE` | `SACRED_GOLEM_TAMER` | `CRAFTING` | 9 |
| `NETHER_GRAVE` | `BONE_PUPPET_REFINER` | `CRAFTING` | 9 |
| `TIDE_VOYAGER` | `ABYSSAL_TIDE_SPEAR` | `FISHING` | 9 |
| `TIDE_VOYAGER` | `DRAGON_SHIP_NAVIGATOR` | `FISHING` | 9 |
| `TIDE_VOYAGER` | `DEEP_PEARL_APOTHECARY` | `FISHING` | 9 |
| `FORTUNE_GAMBLER` | `JADE_DICE_HIGH_ROLLER` | `COMMERCE` | 9 |
| `FORTUNE_GAMBLER` | `KARMA_ROULETTE_DEALER` | `COMMERCE` | 9 |
| `FORTUNE_GAMBLER` | `ALL_IN_DESPERADO_BLADE` | `COMMERCE` | 9 |
| `SPIRIT_HUSBANDRY` | `IMMORTAL_HERB_PLANTER` | `HERBALISM` | 9 |
| `SPIRIT_HUSBANDRY` | `IRON_THORN_VINE_WEAVER` | `HERBALISM` | 9 |
| `SPIRIT_HUSBANDRY` | `SPIRIT_GRAIN_SOVEREIGN` | `COOKING, HERBALISM` | 18 |
| `SPIRIT_HUSBANDRY` | `PARASITIC_SPORE_CULTIVATOR` | `HERBALISM` | 9 |
| `ARENA_GLORY` | `BANNER_GLORY_MARSHAL` | `LEADERSHIP` | 9 |

**หมายเหตุ:** FISHING ไม่ใช่สกิล canonical แม้แปลงเป็นตัวพิมพ์เล็ก ดังนั้นการแก้เฉพาะ capitalization จะไม่พอ. ในไฟล์ผลทดสอบมี gate rows ครบต่อ realm.

## 4. สายย่อยที่ Preference Affinity อ้าง key ไม่รู้จัก (DAO-003)

พบ **38 references ใน 35 สายย่อย**. ค่า HC.eff ของ key เหล่านี้เป็น 0 ในตัวอย่าง เพราะไม่มีอยู่ใน schema ทำให้คะแนนเอนเอียงลงโดยไม่ตอบสนองต่อทักษะจริง.

| Key ที่ไม่รองรับ | จำนวนครั้ง |
|---|---:|
| `ZITHER` | 8 |
| `BLOOD_DEMON` | 5 |
| `FOCUS` | 5 |
| `HERBALISM` | 4 |
| `COMMERCE` | 3 |
| `FISHING` | 3 |
| `POISON_CORROSION` | 3 |
| `CRAFTING` | 2 |
| `HERB_LORE` | 2 |
| `COOKING` | 1 |
| `LEADERSHIP` | 1 |
| `WHIP` | 1 |

**รายการครบ 38 records:** ดู `QA_DAO_PATH_SUBPATH_AUDIT_V230.json` หรือ `DAO_PATH_SUBPATH_REPRO_RESULTS.json` (fields `invalid_preference_affinities` / `invalidPreferenceKeys`).

## 5. ตัวอย่างค่าที่โดดเด่น (REVIEW ไม่ใช่บัค)

ทดลองตัวละครเดียวกัน ใช้อุปกรณ์ว่าง ไม่มี mantra/tech และอยู่ที่ขั้นสูงสุดของ *แต่ละวิถี* เทียบกับสายย่อย `NONE` ในวิถีเดียวกัน. ตัวเลขด้านล่างเป็น **% ความต่างของ raw stat** ไม่ใช่ DPS, damage multiplier, win rate หรือ power ranking ข้ามวิถี.

### ATK ที่สูงสุด

| วิถี | สายย่อย | % เทียบ NONE ในวิถีเดียวกัน |
|---|---|---:|
| `XIAN` | `BLOOD_DEMON` | +97.29% |
| `DEMON` | `HEAVEN_DEVOURING_DEMON` | +97.07% |
| `KARMA_SAMSARA` | `ASURA_JUDGMENT_BLADE` | +96.06% |
| `DEMON` | `ASHURA_SLAUGHTER_BLADE` | +94.37% |
| `BEAST_SOVEREIGN` | `SYMBIOTIC_BEAST_WARRIOR` | +93.52% |

### MATK ที่สูงสุด

| วิถี | สายย่อย | % เทียบ NONE ในวิถีเดียวกัน |
|---|---|---:|
| `DEMON` | `HEAVEN_DEVOURING_DEMON` | +90.03% |
| `BEAST_SOVEREIGN` | `PRIMORDIAL_BLOOD_MUTATOR` | +83.45% |
| `BEAST_SOVEREIGN` | `ABYSSAL_DRAGON_TOTEM` | +79.82% |
| `HEART_SOUL` | `MIND_SWORD_TELEKINESIS` | +79.40% |
| `DEMON` | `NETHER_GHOST_KING` | +74.46% |

### DEF ที่สูงสุด

| วิถี | สายย่อย | % เทียบ NONE ในวิถีเดียวกัน |
|---|---|---:|
| `BEAST_SOVEREIGN` | `COLOSSUS_SHIELD_TAMER` | +112.99% |
| `BODY` | `TITAN_MOUNTAIN_BODY` | +99.79% |
| `BODY` | `VAJRA_BODHI` | +96.12% |
| `MECH_PUPPET` | `HEAVENLY_GOLEM` | +89.76% |
| `SAGE_SUPPORT` | `QIMEN_TALISMAN_PATRON` | +81.64% |

### HP ที่สูงสุด

| วิถี | สายย่อย | % เทียบ NONE ในวิถีเดียวกัน |
|---|---|---:|
| `MECH_PUPPET` | `SOUL_VESSEL_AVATAR` | +62.80% |
| `KARMA_SAMSARA` | `BODHI_VOW_GUARDIAN` | +62.77% |
| `BEAST_SOVEREIGN` | `COLOSSUS_SHIELD_TAMER` | +59.38% |
| `KARMA_SAMSARA` | `LOTUS_MERCY_PURIFIER` | +54.72% |
| `SAGE_SUPPORT` | `DIVINE_NECTAR_APOTHECARY` | +54.09% |

**คำตัดสิน:** สายแอสซาซิน/ทำดาเมจมี ATK สูง, แทงก์มี DEF/HP สูง เป็นเอกลักษณ์ที่สมเหตุสมผลได้; ต้องวัด damage, mitigation, heal uptime และ tradeoffs ก่อนตัดสิน.

## 6. แนวทางทดสอบก่อนประกาศเป็นแพตช์สุดท้าย

1. รันชุด `DAO_PATH_SUBPATH_REPRO_TESTS.js` จาก source release; แก้ DAO-001 แล้วต้องไม่พบ invalid gate และไม่ติดคอขวดปลอม.
2. ใช้ `canActivateMantra` แห่งเดียวจาก UI/API/auto-selection/โหลดเซฟ; ตั้งโปรไฟล์ save เก่าที่ติดคัมภีร์ข้ามวิถีแล้วทดสอบ migration.
3. แก้ canonical skill/affinity/value keys อย่างเป็นระบบ แล้วตรวจ population distribution ที่ AI เลือกวิถีด้วย seeded simulation; อย่าปรับน้ำหนักความถนัดโดยไม่เทียบก่อน/หลัง.
4. ยืนยัน path lifecycle: awaken→choose major/sub→study/mantra→track 1–9→retrain→save/load; ตรวจความสอดคล้องของ UI, STATS, MARTIAL, CULT และ AI.
5. เมื่อปิดช่องอุปกรณ์ EQ-001/EQ-009 (จากรายงานอุปกรณ์เดิม) แล้วจึงทดสอบ build meta ในสภาพแวดล้อมสะอาดด้วย 100–1,000 battle seeds, matched tiers/weapon/gear/cost, burst & sustained DPS, EHP, control, resource economy, counter-matchups.
6. จัดระดับผลทดสอบเป็น BUG / REVIEW / INFO; **DAO-006/DAO-007 ไม่ใช่บัคที่ยืนยัน** และไม่ควรถูกแปลงเป็นคำสั่งเนิร์ฟ.

## 7. ไฟล์ในชุด ZIP ที่เกี่ยวข้อง

- `QA_DAO_PATH_SUBPATH_AUDIT_V230.docx` — รายงานอ่านใน Word
- `QA_DAO_PATH_SUBPATH_AUDIT_V230.md` — รายงานสำหรับ AI
- `QA_DAO_PATH_SUBPATH_AUDIT_V230.json` — machine-readable tasks และรายชื่อข้อผิดพลาด
- `DAO_PATH_SUBPATH_REPRO_TESTS.js` — Node reproducibility harness, ไม่แก้โค้ดต้นฉบับ
- `DAO_PATH_SUBPATH_REPRO_RESULTS.json` และ `DAO_PATH_SUBPATH_REPRO_RUN_LOG.txt` — หลักฐานรันจริง
- `DAO_PATH_SUBPATH_BASELINE_MATRIX.json` — สเตตัสตัวอย่างครบ 286 สาย, วิเคราะห์ได้แต่ไม่ใช่ power tier list
- `DAO_PATCH_IMPLEMENTATION_GUIDE.md` — ลำดับงานสำหรับ AI และเกณฑ์ freeze

### ข้อจำกัด/ความมั่นใจ
- P0/P1/P2 ที่ระบุ BUG ผ่านการตรวจโค้ดและทดสอบ Node สืบย้อนผลได้; DAO-002 ทดสอบผ่านฟังก์ชัน retrain จริง และจำลองการตรวจปุ่มตามเงื่อนไข UI ที่มีอยู่ **ไม่ได้ทดสอบคลิกด้วยเบราว์เซอร์โดยตรง**.
- เคส DAO-005 ใช้ `guarantee:true` เพื่อกัน RNG ในการทดสอบเท่านั้น แต่ตรวจ gate/ศิลา/progress จริงครบ; ผู้เล่นปกติยังต้องผ่านโอกาสสำเร็จ.
- ข้อมูล stat outlier ยังไม่ใช่ evidence ของ meta unbeatable เพราะไม่ได้จำลองการต่อสู้หรือเศรษฐกิจจริง.
- **รายงานนี้เพิ่มเติมจากรายงานอุปกรณ์เดิม ไม่แทนที่ ไม่รวมชื่อไฟล์ และไม่มีการแก้ source เกม.**


## 8. ภาคผนวกอัปเดต — ผลต่อเนื่องหลังเซฟ/โหลด (8 พ.ย. 2026)

> **ไม่มีรหัสบัคใหม่ในหมวดวิถี**; ยืนยันผลกระทบต่อเนื่องของ `DAO-001` และ `DAO-002` จากสถานะจริงหลัง `SIM.serialize`/`SIM.deserialize` เพื่อเตรียม release gate. รายการ/ระดับเดิมไม่เปลี่ยน.

- **DAO-002 / C19 (P1):** เรียก retrain จาก DEMON stage9 ไปวิถีใหม่ XIAN stage1 จริง แล้วจำลองเงื่อนไขสลับมนตราจาก UI; คัมภีร์ DEMON tier7 `MANTRA_DEMON_PRIMORDIAL_EMPEROR` กลับมาสวมได้ ค่า MATK ในเคสเพิ่ม **105 → 127** และหลังโหลดเซฟยัง MATK=127, `cult.mantra` ยังคงชี้คัมภีร์ข้ามวิถี. *ไม่ใช่เพียงบัคแสดง UI ชั่วคราว*.
- **DAO-001 / C20 (P0):** ตัวอย่างสาย `SPIRIT_GRAIN_SOVEREIGN` ตั้งทักษะ canonical `herbalism`/`cooking` เต็มและทรัพยากรพร้อมแล้วแต่ติด gate `HERBALISM`/`COOKING` ก่อนและหลังโหลดเซฟ; สายจึงติดขัดต่อเนื่องโดยไม่หายเมื่อรีสตาร์ต. ประเด็น 15 สายย่อยยังเป็น P0.
- **สายสัมพันธ์กับระบบอื่น:** รูน/อุปกรณ์ไม่ควรเป็นวิธีอ้อมเพื่อแก้ gate skill ID; คัมภีร์ข้ามวิถีต้องมี validator ร่วมของ UI/AI/CULT/STATS และ `deserialize` ต้อง sanitize/eject mantra ที่ไม่เข้าวิถี/ขั้นโดย *ยังเก็บ learned record* ไว้.
- **Regression หลังแก้:** retrain → สลับคัมภีร์ invalid → ตรวจค่า STATS/การต่อสู้ → save/load → auto-mantra selection; track gate → ฝึกทักษะที่มีจริง → ทะลวง → save/load; อุปกรณ์ต่างวิถี/ขั้นต้องไม่คืนโบนัสให้ช่องสวมที่ผิดกติกา.

## การตรวจข้ามระบบเพิ่มเติม — COMBAT v2.3.0 (8 พ.ย. 2026)

**ทางเดินบัฟ/สถานะขณะใช้วิถีจริง:** COMBAT-09 ยืนยันสาขาพิเศษ MECH_PUPPET ไม่ทำงานเพราะ generic CULT.PATHS ถูกตรวจมาก่อน จึงไม่หัก integrity ตามกลไก; COMBAT-10 ยืนยัน poison แบบ layered stacks=3 หมดอายุแล้วถูก purge หายทั้งรายการก่อนลดเหลือ 2. ต้องทดสอบ 43 วิถี/286 สายกับ flow การต่อสู้จริงแยกจาก parity data. ดูรายงาน COMBAT โดยตรง.
