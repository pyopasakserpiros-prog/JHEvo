# TECHNIQUE / WEAPON FIX IMPLEMENTATION GUIDE — JianghuSect v2.3.0

> Read `AGENTS.md`, relevant `.agents/skills/` and the actual ZIP. This is an audit/handoff, NOT applied source patch. Keep `GAME_SOURCE/js/human_core.js` byte identical.

## Priority changes

### TECH-01 [P1] — อาวุธและเกราะจำแนกประเภทผิดจากชนิดที่กำหนดไว้
- Root: gearType ของอุปกรณ์บางรุ่นไม่ถูกคัดลอกจาก weaponType/armorType/subType แต่เดาประเภทจาก nameTh ซึ่งประกอบชื่อไอเทมหลายหมวด
- Location: js/martial.js:639,1358; js/economy.js:372–387; data itemById EQ_V234_WPN_017–118 / ARM_002 เป็นต้น
- Fix: กำหนดชนิด canonical จากข้อมูล item ที่มีชนิดชัดเจนก่อน fallback classify(nameTh); ตรวจ mint/procedural/dropped gear และ UI แล้วอัปเดต cache
- Regression acceptance: mint เทียบรายการ 36 ชิ้นทุกชิ้นต้องรักษาชนิดที่ declare และวิชา BOW/ARMOR ตามประเภทจริงใช้ได้
- Evidence: PT-GEAR-TYPE-REAL; 24 WEAPON + 12 ARMOR; ECO.mintGear(EQ_V234_WPN_053) ให้ SWORD ทั้งที่ weaponType=BOW

### TECH-02 [P1] — สวมอุปกรณ์แล้วใช้ท่าที่สูงกว่าขั้นบ่มเพาะและความชำนาญ
- Root: grantedSkills ผ่าน gate ที่ระดับไอเทมเท่านั้น; SK.list ใช้ SK.allMoves(t).slice(0,2) ข้าม unlockedMoves+reqCultStage/reqMastery
- Location: js/martial.js:1271–1290,1343–1354; js/skills.js:606–619
- Fix: กำหนดกติกา Equipment Grant ระบุ override ที่ตั้งใจ (tier cap explicit) และ default ให้ใช้ SK.unlockedMoves รวม reqCultStage/reqMastery; ตรวจ item minStage จากข้อมูลจริง
- Regression acceptance: stage1 ไม่เลือกหรือใช้ move ที่ reqCultStage3; ตัวละครถึงขั้น/ความชำนาญตามกฎแล้วใช้ได้; อุปกรณ์ไม่ให้เรียนวิชาถาวร
- Evidence: PT-EQUIP-GRANT-EARLY; stage1 equips EQ_V234_WPN_025 → TECH_V234_XIAN_ACT_03_M1/M2 require cultivation3; SK.canSelectMove=true

### TECH-03 [P1 / DESIGN-CONFIRM] — โบนัสธาตุ/ประเภทจาก skillModifiers ทำงานกว้างเกินข้อมูล
- Root: ตัวกรองอ่าน matchElement/matchArch/matchTechId แต่ข้อมูลจริงบันทึก element (277) / weaponType (120) แทน
- Location: js/martial.js:1306–1339; ECO.itemById.*.skillModifiers
- Fix: ยืนยันก่อนว่า element/weaponType เป็น metadata หรือเงื่อนไขที่ตั้งใจ; หากเป็น gate ให้ normalize schema หรือแก้ producer/consumer และทำ test ตรง/ไม่ตรงธาตุ
- Regression acceptance: วิชา FIRE เทียบ WATER_ICE ได้โบนัสเฉพาะตาม design; เปลี่ยนอุปกรณ์แล้ว stats/skill ทันทีไม่ค้าง
- Evidence: PT-ELEMENT-MOD, PT-SCHEMA-MOD-MATCH; EQ_V234_WPN_001 FIRE +14% ให้ WATER_ICE (M=1.25→1.43), 277 mod มี element แต่ 0 ใช้ matchElement

### TECH-04 [P1] — กระบวนท่าขั้นสอง 4 วิชาปลดล็อกไม่ได้
- Root: moveDefs.stageReq=2 แต่ t.stages ไม่มี, unlockedStage() คืน 1
- Location: js/skills.js:501–515,528–539; technique definitions 4 IDs
- Fix: เพิ่ม stages ระดับ2 ที่สอดคล้องความชำนาญ/ขั้น หรือแก้ gate ตาม design; ห้ามปลดฟรีแบบไม่ตรวจ
- Regression acceptance: mastery และ cultivation ถึง requirement จึงปลดท่า2 ได้; ต่ำกว่า requirement ยังไม่ได้
- Evidence: PT-UNREACH-MP_STAFF_WALL / MP_SPEAR_LINE / MP_BLADE_SHADOW / MP_FOCUS_SEAL; mastery=99999 ยังได้ stage1

### TECH-05 [P2] — UI บอกเลือกท่าได้แม้อาวุธบังคับไม่พร้อม
- Root: canSelectMove ตรวจ ownership/ความชำนาญ ไม่ตรวจ compatibility ที่การต่อสู้ปฏิเสธ
- Location: js/skills.js:545–556; js/martial.js:385–395,651–659; js/combat.js:1844–1845,1938
- Fix: ปรับ UI/selection ให้เรียก gate สถานะเดียวกับ combat, พร้อมข้อความอาวุธจำเป็น
- Regression acceptance: ไม่อนุญาต select move ที่ requiresWeapon แต่ไม่ตรง; สวมถูกและไม่พังแล้วเลือกได้
- Evidence: PT-SELECT-REQUIRED; MP_BOW_IRON_DRAW_T1 canSelectMove=true มือเปล่า แต่ weaponCanUse=false, skillEfficiency=0

### TECH-06 [P2] — แคชรายการวิชาไม่อัปเดตเมื่อ modifier เปลี่ยนบนอุปกรณ์ UID เดิม
- Root: _skListCache.eqKey ใช้ UID/ID ไม่ใช้ version ของ skillModifiers/runes/quality
- Location: js/skills.js:585–593,632; js/martial.js:1306–1339
- Fix: เพิ่ม equipmentSkillsVersion และ invalidate ทุกครั้งที่เปลี่ยน modifier, enchant, durability, grant, UID; อย่า stringify ทั้ง object ทุก tick
- Regression acceptance: อัปเกรดบน UID เดิมให้ผลใหม่ใน SK.list ทันทีและตรงการคำนวณรอบถัดไป
- Evidence: PT-CACHE-SKILL-MOD; เปลี่ยน multPct จาก .10→1.50 แต่ SK.list ยังแสดง M=1.38; invalidate แล้ว M=3.13

### TECH-07 [P2 / INTERNAL] — เปลี่ยนวิชากลางอาร์เรย์จำนวนเท่าเดิมแล้ว SK.list ค้าง
- Root: cache key เทียบเพียง tl,t0,tL ไม่เก็บ revision/digest รายชื่อ
- Location: js/skills.js:585–593,632
- Fix: ให้ mutation เส้นทางเดียวเพิ่ม techLoadoutVersion และ invalidate ใน teach/unlearn/retrain/equip/deserialize
- Regression acceptance: เปลี่ยนสมาชิกกลางแล้วรายการท่าอัปเดต; save/load คง revision ถูกต้อง
- Evidence: PT-CACHE-MIDDLE; techs[1] เปลี่ยนจาก ART190_XIAN_002→004 แต่ SK.list ไม่เปลี่ยนจน invalidate

## Dependency-aware order
1. Reconcile canonical equipment types (TECH-01); test 36 affected item IDs, gear minting and UI plus combat range/AI.
2. Define equipment-granted skill stage gating or explicit exceptions (TECH-02); test low-stage, owned, equip swap, broken gear.
3. Confirm schema semantics `element`/`weaponType` vs `matchElement` (TECH-03) *before* adjusting all 277 modifiers.
4. Repair 4 unreachable move stages (TECH-04); unify select & cast authorities (TECH-05), versioned cache invalidation (TECH-06/07).
5. Run old suites and new negative tests including death → gear inheritance → save/load.
6. Only after release blockers: plan optional new subpath and weapon moves, with acquisition, stage unlock, AI, UI, balancing, save, and effects.

## Test assets inside this audit ZIP
- `TECHNIQUE_RUNTIME_PROBES.js` (Node, uses `./GAME_SOURCE/test/load` relative to original audit dir; if relocated adjust require path to source loader)
- `TECHNIQUE_RUNTIME_PROBE_RESULTS.json`, `TECHNIQUE_RELATED_REGRESSION_LOG.txt`
- `TECHNIQUE_INDIVIDUAL_CATALOG_QA.csv`, `TECHNIQUE_EACH_MOVE_QA.csv`
- `TECHNIQUE_PATH_COVERAGE.csv`, `TECHNIQUE_SUBPATH_GAP_ACTIONS.csv`, `TECHNIQUE_WEAPON_COVERAGE.csv`
- `TECHNIQUE_EQUIPMENT_TYPE_MISMATCHES.json`, `TECHNIQUE_EQUIPMENT_GRANT_CANDIDATES.json`

## Warning
Read-only source audit, no source modifications. Data cardinality/role gap is pre-screen only, not proof each technique is useless or OP. Distinguish runtime-proven defects from design reviews and content proposals.
