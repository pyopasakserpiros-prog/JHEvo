'use strict';
/* Read-only reproduction against untouched JianghuSect 2 v2.3.0 code.
 * Usage: node MENTORSHIP_OFFICES_DEEP_REPRO_TESTS.js /path/to/GAME_SOURCE
 * Outputs one self-describing JSON object to stdout. No source modifications.
 */
const path=require('path');
const SRC=process.argv[2] || path.join(__dirname, '..', 'audit_v230','game_release','GAME_SOURCE');
const G=require(path.join(SRC,'test','load.js'));
const {SIM,SECT,CULT,COG,HC}=G;
const rows=[];
function w(tag){ return SIM.create('AUDIT-MO-'+tag,{masterIdx:0}); }
function m(W){return W.byId[W.sect.masterId];}
function add(W,rank=1,stage=1){return SIM.addNpc(W,{ageYears:18,rank,stage,quality:.65});}
function st(W){return {t:W.t,day:W.day,stones:W.sect.stones};}
function senior(n){n.rank=5; if(n.cult)n.cult.stage=Math.min(5, CULT.maxStage(n));return n;}
function report(id,title,scope,expected,fn){
 try{const obj=fn()||{};rows.push({id,title,scope,expected,kind:obj.kind||'finding',observed:obj.observed??obj,confirms:obj.confirms===true,notes:obj.notes||null});}
 catch(e){rows.push({id,title,scope,expected,kind:'test_error',error:String(e.stack||e),confirms:false});}
}
report('MO-01','Coaching repeatedly within same simulation minute','UI button → core','At most one teaching reward per appropriate time window',()=>{
 const W=w('01'), teacher=m(W),disc=W.npcs[1], api=SECT.MENTORSHIP;
 senior(teacher);api.formBond(W,teacher,disc,{force:true,quiet:true});
 const before={time:W.t,prog:disc.cult.prog,merit:teacher.merit||0,taught:teacher.stats?.taughtCount||0};
 const res=Array.from({length:12},()=>api.coachDisciple(W,teacher,disc));
 return {confirms:res.every(r=>r.ok)&&W.t===before.time&&teacher.stats.taughtCount-before.taught===12,observed:{before,after:{time:W.t,prog:disc.cult.prog,merit:teacher.merit,taught:teacher.stats.taughtCount},successfulSessions:res.filter(r=>r.ok).length,progressDelta:disc.cult.prog-before.prog}};
});
report('MO-02','Coaching unrelated disciple force-switches mentorship','Core internal + crafted UI command','Cannot silently reassign another teacher’s student from teaching action',()=>{
 const W=w('02'), a=m(W), b=senior(add(W,4,3)), d=W.npcs[1], api=SECT.MENTORSHIP;senior(a);
 api.formBond(W,a,d,{force:true,quiet:true});const before=d.mentorId; const result=api.coachDisciple(W,b,d);
 return {confirms:result.ok&&d.mentorId===b.id&&before!==d.mentorId,observed:{before,after:d.mentorId,coachingOk:result.ok,previousTeacherRetainsChild:(a.apprenticeIds||[]).includes(d.id)}};
});
report('MO-03','Teacher unavailable/dead/exiled can be used for coaching? (control)','Internal API','Dead teacher must be denied (control)',()=>{
 const W=w('03'),a=m(W),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);a.dead=true;
 const res=api.coachDisciple(W,a,d);return {kind:'control',confirms:!res.ok,observed:{result:res}};
});
report('MO-04','Sealed / detained / absent teacher still teaches','UI button → core','Teacher and disciple must be available for an in-person session',()=>{
 const W=w('04'),a=m(W),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);api.formBond(W,a,d,{force:true,quiet:true});a.away=true;a.sealed=true;a.jail=W.t+100000;
 const res=api.coachDisciple(W,a,d);return {confirms:res.ok,observed:{away:a.away,sealed:a.sealed,jailUntil:a.jail,time:W.t,resultOk:res.ok,cultGain:res.cultGain}};
});
report('MO-05','Exiled / imprisoned cannot form a teacher-disciple bond','API, possible UI stale state','Must reject exiled or detained participants',()=>{
 const W=w('05'),a=m(W),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);d.exiled=true;d.detainedUntilDay=W.day+10;
 const res=api.formBond(W,a,d,{quiet:true});return {confirms:res.ok,observed:{exiled:d.exiled,detainedUntilDay:d.detainedUntilDay,formed:res.ok,mentorId:d.mentorId}};
});
report('MO-06','Teacher-capacity bound works in ordinary formBond (control)','UI + core','Fourth junior must be rejected when three are active',()=>{
 const W=w('06'),a=m(W),api=SECT.MENTORSHIP;senior(a);const ds=[...Array(4)].map(()=>add(W));const results=ds.map(d=>api.formBond(W,a,d,{quiet:true}));
 return {kind:'control',confirms:results.slice(0,3).every(r=>r.ok)&&!results[3].ok,observed:{ok:results.map(r=>r.ok),lastReason:results[3].reason,apprenticeCount:a.apprenticeIds?.length}};
});
report('MO-07','Mentorship no cap when coaching forcibly creates pair','API + crafted UI command','Coaching cannot bypass mentor-apprentice count maximum',()=>{
 const W=w('07'),a=m(W),api=SECT.MENTORSHIP;senior(a);const ds=[...Array(6)].map(()=>add(W));const res=ds.map(d=>api.coachDisciple(W,a,d));
 return {confirms:res.every(r=>r.ok)&&a.apprenticeIds.length>3,observed:{max:api.MAX_APPRENTICES,actual:a.apprenticeIds.length,okCount:res.filter(r=>r.ok).length}};
});
report('MO-08','Changing master leaves old social relation flagged as direct mentor','UI → core','Historical relation must not claim active direct mentorship',()=>{
 const W=w('08'),a=m(W),b=senior(add(W,4,3)),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);
 api.formBond(W,a,d,{force:true,quiet:true});const first=SECT.rel(d,a.id).bond;
 api.formBond(W,b,d,{force:true,quiet:true});const second=SECT.rel(d,a.id).bond;
 return {confirms:d.mentorId===b.id&&second==='อาจารย์สายตรง',observed:{currentMaster:d.mentorId,previousMaster:a.id,previousRelationBefore:first,previousRelationAfter:second,activeBondMentor:W.sect.mentorship.bonds[d.id].mentorId}};
});
report('MO-09','Transmit Qi to non-disciple with no mentor relationship','Direct API only; UI button filters','Transmission must require existing valid mentor bond',()=>{
 const W=w('09'),a=m(W),d=add(W,1,1),api=SECT.MENTORSHIP;senior(a);
 const before=d.cult.prog;const res=api.transmitQi(W,a,d);
 return {confirms:res.ok&&d.cult.prog>before,observed:{transmissionOk:res.ok,mentorId:d.mentorId||null,bond:(W.sect.mentorship?.bonds||{})[d.id]||null,progressGain:d.cult.prog-before,imprintMentor:d.mentorImprint?.mentorId}};
});
report('MO-10','Transmit Qi by dead/exiled teacher','Direct API only','Dead/exiled characters cannot initiate ritual',()=>{
 const W=w('10'),a=m(W),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);a.dead=true;a.exiled=true;
 const res=api.transmitQi(W,a,d);return {confirms:res.ok,observed:{dead:a.dead,exiled:a.exiled,transmissionOk:res.ok,progress:d.cult.prog}};
});
report('MO-11','Several unrelated teachers can feed same student cumulative breakthroughs','Direct API / cross-NPC','Transmission should be lineage-based and not an unbounded cross-mentor farming route',()=>{
 const W=w('11'),a=m(W),b=senior(add(W,4,4)),c=senior(add(W,4,4)),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);
 const before=d.cult.prog;const res=[a,b,c].map(o=>api.transmitQi(W,o,d));
 return {confirms:res.every(r=>r.ok),observed:{transmissionCount:res.filter(r=>r.ok).length,progressGain:d.cult.prog-before,imprintMentor:d.mentorImprint?.mentorId,masterId:d.mentorId||null}};
});
report('MO-12','Synthesized sect art creation without cost, cooldown or capacity','UI button → core','Repeated generation needs design cap / cost or intentional unlimited status',()=>{
 const W=w('12'),a=m(W),api=SECT.MENTORSHIP;senior(a);const before=st(W);const res=Array.from({length:6},()=>api.synthesizeSectArt(W,a,{quiet:true}));
 return {kind:'design-review',confirms:res.every(r=>r.ok)&&W.t===before.t&&W.sect.stones===before.stones,observed:{generated:res.filter(r=>r.ok).length,heritageArts:W.sect.mentorship?.heritageArts?.length,librarySize:W.sect.library.length,before,after:st(W),uniqueTechIds:new Set(res.map(r=>r.tech?.id)).size}};
});
report('MO-13','Repeated formBond same pair is idempotent (control)','UI button → core','Repeated bond should not repeat bonuses',()=>{
 const W=w('13'),a=m(W),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);const first=api.formBond(W,a,d,{force:true,quiet:true});const history1=W.sect.mentorship.history.length;const second=api.formBond(W,a,d);return {kind:'control',confirms:first.ok&&second.ok&&history1===W.sect.mentorship.history.length,observed:{first:first.ok,second:second.ok,historyBefore:history1,historyAfter:W.sect.mentorship.history.length}};
});
report('MO-14','Appoint alias then dismiss via alias leaves real slot and throws','Internal API; UI resolves aliases','Aliases should resolve consistently on appoint/dismiss',()=>{
 const W=w('14'),n=add(W,3,3);W.sect.unlockSpecializedOffices=true; const appointed=SECT.appoint(W,'diplomacy',n,'audit');let err=null;try{SECT.dismiss(W,'diplomacy','audit');}catch(e){err=String(e.message||e)}
 return {confirms:appointed&&(!!err||W.sect.posts.envoy===n.id),observed:{appointed,exception:err,aliasSlot:W.sect.posts.diplomacy,realSlot:W.sect.posts.envoy,nPost:n.post}};
});
report('MO-15','Dismissing office leaves a delegated officer authorized until expiry','API + internal authority system','No delegate has authority after office no longer exists',()=>{
 const W=w('15'),a=add(W,3,3),del=add(W,3,3);W.sect.unlockSpecializedOffices=true;
 SECT.appoint(W,'steward',a,'audit');a.away=true;del.assist='steward';COG.syncOfficeAuthority(W);const before=COG.hasAuthority(W,del,'steward');SECT.dismiss(W,'steward','audit');const after=COG.hasAuthority(W,del,'steward');
 return {confirms:before&&after,observed:{before,after,postAfter:W.sect.posts.steward,delegation:W.sect.delegations?.steward||null}};
});
report('MO-16','Delegation survives holder replacement when original holder is absent','API + role authorization','Delegation should not grant authority under a new holder',()=>{
 const W=w('16'),a=add(W,3,3),b=add(W,3,3),del=add(W,3,3);SECT.unlockAllOffices(W,{quiet:true});SECT.appoint(W,'steward',a,'audit');a.away=true;del.assist='steward';COG.syncOfficeAuthority(W);const before=COG.hasAuthority(W,del,'steward');SECT.appoint(W,'steward',b,'audit');const after=COG.hasAuthority(W,del,'steward');
 return {kind:'control',confirms:before&&!after,observed:{delegatedBefore:before,delegatedAfter:after,newHolder:W.sect.posts.steward}};
});
report('MO-17','Dismissing new promoted officer retains elder rank permanently','UI + core','Demotion policy should distinguish honorary elder from post-only rank',()=>{
 const W=w('17'),n=add(W,1,1);SECT.unlockAllOffices(W,{quiet:true});const before={rank:n.rank,isElder:n.isElder||false};SECT.appoint(W,'steward',n,'audit');const promoted={rank:n.rank,isElder:n.isElder};SECT.dismiss(W,'steward','audit');
 return {kind:'design-review',confirms:n.rank>=4&&n.isElder,observed:{before,promoted,dismissed:{rank:n.rank,isElder:n.isElder,post:n.post},canVoteElder:n.rank>=4||n.isElder}};
});
report('MO-18','Dismissed office remains in cached cognition role?','UI/API → cognition','Role must become member immediately after dismissal',()=>{
 const W=w('18'),n=add(W,3,3);SECT.unlockAllOffices(W,{quiet:true});SECT.appoint(W,'steward',n,'audit');const prior=COG.role(W,n).id;SECT.dismiss(W,'steward','audit');const now=COG.role(W,n).id;
 return {kind:'control',confirms:prior==='steward'&&now!=='steward',observed:{before:prior,after:now}};
});
report('MO-19','Mentor bond between active members remains across save/load (control)','Save/load integration','Bond must roundtrip, not lose teacher lists',()=>{
 const W=w('19'),a=m(W),d=W.npcs[1];senior(a);SECT.MENTORSHIP.formBond(W,a,d,{force:true,quiet:true});const data=SIM.serialize(W);const R=SIM.deserialize(data);const da=R.byId[d.id],ma=R.byId[a.id];
 return {kind:'control',confirms:da.mentorId===ma.id&&ma.apprenticeIds.includes(da.id),observed:{savedBytes:data.length,mentorId:da.mentorId,apprenticeIds:ma.apprenticeIds.length}};
});
report('MO-20','Mentor spam and office stale-state persist across save/load','Save/load integration','Invalid progression / authorization should not be permanently saved',()=>{
 const W=w('20'),a=m(W),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);api.formBond(W,a,d,{force:true,quiet:true});for(let i=0;i<5;i++)api.coachDisciple(W,a,d);const gain=d.cult.prog;const R=SIM.deserialize(SIM.serialize(W));
 return {confirms:R.byId[d.id].cult.prog===gain,observed:{beforeSave:gain,afterLoad:R.byId[d.id].cult.prog,teacherMerit:R.byId[a.id].merit,sessionCount:R.sect.mentorship?.bonds?.[d.id]?.coachingSessions}};
});
report('MO-21','Office appointment allows detained candidate despite eligibility denial','UI auto-office path + API; overlaps SECT-03','Appointment must enforce same constraints as eligibility',()=>{
 const W=w('21'),n=add(W,1,1);SECT.unlockAllOffices(W,{quiet:true});n.away=true;n.jail=W.t+50000; const eligible=SECT.eligible(W,'steward',n);const ok=SECT.appoint(W,'steward',n,'audit');return {confirms:!eligible&&ok,observed:{eligible,appointed:ok,rankAfter:n.rank,office:W.sect.posts.steward,away:n.away,jailUntil:n.jail}};
});
report('MO-22','Cognition delegation authority accepts stale delegate record without holder','Core API; injected state','Authorization must check live holder and delegation validity',()=>{
 const W=w('22'),n=W.npcs[1];W.sect.delegations={treasury:{post:'treasury',holderId:'not-existing',delegateId:n.id,since:W.t,until:W.t+10000}};
 const res=COG.hasAuthority(W,n,'treasury');return {confirms:res,observed:{authorized:res,actualOfficeHolder:W.sect.posts.treasury,delegation:W.sect.delegations.treasury}};
});
report('MO-23','Historical mentor relationship remains after switch, even after save/load','Save/load → relations','Former mentorship should be historical, not active',()=>{
 const W=w('23'),a=m(W),b=senior(add(W,4,3)),d=W.npcs[1],api=SECT.MENTORSHIP;senior(a);api.formBond(W,a,d,{force:true,quiet:true});api.formBond(W,b,d,{force:true,quiet:true});const R=SIM.deserialize(SIM.serialize(W));const d2=R.byId[d.id];
 return {confirms:d2.mentorId===b.id&&d2.h.mind.relations[a.id]?.bond==='อาจารย์สายตรง',observed:{current:d2.mentorId,former:a.id,formerRelation:d2.h.mind.relations[a.id]?.bond}};
});
report('MO-24','Mentor appointment accepts cross-world NPC object','Internal API only','All participants should belong to the same current world',()=>{
 const W=w('24a'),X=w('24b'),other=m(X),disc=W.npcs[1],api=SECT.MENTORSHIP;senior(other);const before=disc.mentorId||disc.mentor;const res=api.formBond(W,other,disc,{force:true,quiet:true});
 return {confirms:res.ok&&disc.mentorId===other.id&&W.byId[other.id]!==other,observed:{ok:res.ok,before,after:disc.mentorId,worldResolvesMentor:W.byId[other.id]===other,otherModified:other.apprenticeIds?.includes(disc.id)}};
});

report('MO-25','Invalid seniority prevents voluntary novice-mentor pairing (control)','UI → core','Novice cannot be ordinary mentor for equal-ranked peer',()=>{
 const W=w('25'),a=add(W,1,1),d=add(W,1,1),res=SECT.MENTORSHIP.formBond(W,a,d,{quiet:true});
 return {kind:'control',confirms:!res.ok,observed:{ok:res.ok,reason:res.reason,teacherRank:a.rank,discipleRank:d.rank}};
});
report('MO-26','Acting welfare treasurer retains authority even when flag is inactive','Internal authority, only if welfareAuthority record exists','Inactive acting permission must not grant treasury domain',()=>{
 const W=w('26'),n=W.npcs[1];W.sect.welfareAuthority={id:n.id,acting:false}; const result=COG.hasAuthority(W,n,'treasury');
 return {confirms:result,observed:{authorized:result,acting:false,officeHolder:W.sect.posts.treasury,role:COG.role(W,n).id}};
});
report('MO-27','Official appointment and dismissal updates post ledger normally (control)','UI → core','Valid office appointment/dismissal should succeed and revoke direct authority',()=>{
 const W=w('27'),n=add(W,3,3);SECT.unlockAllOffices(W,{quiet:true});const first=SECT.appoint(W,'steward',n,'audit');const authorityBefore=COG.hasAuthority(W,n,'steward');SECT.dismiss(W,'steward','audit');const after=COG.hasAuthority(W,n,'steward');
 return {kind:'control',confirms:first&&authorityBefore&&!after&&W.sect.posts.steward===null,observed:{appointed:first,authBefore:authorityBefore,authAfter:after,post:n.post}};
});
report('MO-28','Repeat election at same world time produces repeated official records','UI → core','Election should have intentional time/cooldown gate to avoid redundant reports',()=>{
 const W=w('28'),n=W.npcs[1];SECT.unlockAllOffices(W,{quiet:true});
 const before={time:W.t,posts:W.sect.posts.disciples};const res=Array.from({length:4},()=>SECT.electSuccessor(W));
 return {kind:'design-review',confirms:res.every(r=>r.ok)&&W.t===before.time,observed:{timesCalled:res.length,successes:res.filter(r=>r.ok).length,timeBefore:before.time,timeAfter:W.t,electionRecord:W.sect.successorElection?.day,successor:W.sect.successorId}};
});

report('MO-29','Retired / out-of-sect teacher still grants coaching to student','Normal UI can retain mentor reference via W.byId','Teacher absent from active sect roster cannot keep teaching from old ID',()=>{
 const W=w('29'),a=senior(add(W,4,4)),d=W.npcs[1],api=SECT.MENTORSHIP;api.formBond(W,a,d,{force:true,quiet:true});const before=d.cult.prog;a.inv.crystals={};a.inv.subManuals=[];SIM.retire(W,a);const result=api.coachDisciple(W,a,d);
 return {confirms:result.ok&&!W.npcs.includes(a),observed:{teacherIsActiveMember:W.npcs.includes(a),byIdStillReferencesTeacher:W.byId[a.id]===a,discipleMentor:d.mentorId,coached:result.ok,progressGain:d.cult.prog-before}};
});
report('MO-30','Removed mentor still grants tribulation guidance predicate','Simulation AI predicate + retirement','Mentor benefit should require valid active support or intentional historical imprint',()=>{
 const W=w('30'),a=senior(add(W,4,4)),d=W.npcs[1],api=SECT.MENTORSHIP;api.formBond(W,a,d,{force:true,quiet:true});a.inv.crystals={};a.inv.subManuals=[];SIM.retire(W,a);
 const mid=d.mentorId||d.mentor;const predicate=!!(mid&&W.byId[mid]&&!W.byId[mid].dead);return {confirms:predicate&&!W.npcs.includes(a),observed:{teacherMember:W.npcs.includes(a),teacherDead:a.dead,mentorId:mid,breakthroughGuidanceWouldApply:predicate,source:'js/ai.js:836-837,852-853'}};
});

report('MO-31','Freshly added NPC retirement throws after roster removal','Normal simulation lifecycle: addNpc → retire','New NPC must retire atomically, returning inventory and cleaning indexes',()=>{
 const W=w('31'),n=add(W,2,2),before=W.npcs.includes(n);let thrown=null;
 try{SIM.retire(W,n)}catch(e){thrown=String(e.message||e)}
 return {confirms:!!thrown&&!W.npcs.includes(n),observed:{wasActive:before,invCrystals:n.inv.crystals,hasSubManuals:Array.isArray(n.inv.subManuals),error:thrown,memberAfter:W.npcs.includes(n),goneMark:W.gone.includes(n.id),byIdStillReferences:W.byId[n.id]===n}};
});

report('MO-32','Knowledge normalization before retirement prevents TypeError (control)','World initialization / inventory lifecycle','Fresh NPC with properly normalized knowledge inventory should retire cleanly',()=>{
 const W=w('32'),n=add(W,2,2);G.MARTIAL.ensure(W);let thrown=null;try{SIM.retire(W,n)}catch(e){thrown=String(e.message||e)}
 return {kind:'control',confirms:!thrown&&!W.npcs.includes(n),observed:{error:thrown,hasCrystals:!!n.inv.crystals,hasSubManuals:Array.isArray(n.inv.subManuals),memberAfter:W.npcs.includes(n)}};
});
report('MO-33','Ordinary AI teach interaction silently changes master-disciple lineage','Normal AI social runtime via AI.pairEnd','Ordinary teaching encounter should not change formal lineage without a ritual/consent',()=>{
 const W=w('33'),a=senior(add(W,4,4)),d=W.npcs[1],oldTeacher=senior(m(W));SECT.MENTORSHIP.formBond(W,oldTeacher,d,{force:true,quiet:true});const before=d.mentorId;
 G.AI.pairEnd(W,a,d,{type:'teach'});
 return {confirms:d.mentorId===a.id&&before!==a.id,observed:{oldMentorId:before,newMentorId:d.mentorId,newMentorApprenticeIds:a.apprenticeIds,oldMentorStillHasDisciple:(oldTeacher?.apprenticeIds||[]).includes(d.id)}};
});
const counts={cases:rows.length,confirmed:rows.filter(x=>x.kind==='finding'&&x.confirms).length,designReview:rows.filter(x=>x.kind==='design-review'&&x.confirms).length,controls:rows.filter(x=>x.kind==='control'&&x.confirms).length,controlFails:rows.filter(x=>x.kind==='control'&&!x.confirms).length,scriptErrors:rows.filter(x=>x.kind==='test_error').length};
const result={project:'JianghuSect 2 v2.3.0',scope:'mentor-disciple and sect offices deep audit',source:SRC,timestamp:'2026-11-08',counts,rows};
console.log(JSON.stringify(result,null,2));
if(counts.scriptErrors)process.exitCode=1;
