# WORLD EXPLORATION v2.3.0 — คำสั่งแก้ไขสำหรับ Coding AI

อ่าน `AGENTS.md` และสกิล `.agents/skills/procedural-gen`, `qa-test-matrix`, `gameplay-architecture`, `game-data-integrity` จากซอร์สที่ได้รับ **ก่อนแก้**; source version ต้องเป็น `JianghuSect2_v2.3.0_Grand_Dao_Deep_Parity_Release.zip` ไม่ใช่ latest จากบทสนทนาอื่น. **ห้ามแตะ human_core.js.**

## เป้าหมาย

แก้ต้นเหตุโดยรักษาฟีเจอร์เดิม ไม่เพิ่มระบบใหญ่ ไม่เนิร์ฟที่ยังเป็น REVIEW ไม่ยอมให้สถานะกึ่งสำเร็จ หรือแจกของโดยไม่ผูกกับกิจกรรมจริง. โปรดอ่าน `QA_WORLD_EXPLORATION_EXPEDITIONS_AUDIT_V230.md` และ `.json` พร้อมหลักฐาน `WORLD_EXPLORATION_REPRO_RESULTS.json`.

## งาน A — Stop free mint (P0)
- WORLD-01: กำหนดสัญญา activity micro (time/cooldown/travel/once-per-day) ให้เข้ากับเกมเดิม; เช็กก่อน reward, เลือกต้นทุน/เวลาที่ทำให้การสำรวจสมเหตุสมผลและยอมรับได้. UI ต้องสื่อสารเหตุผลเมื่อทำไม่ได้.
- ต้องกันการเรียกซ้ำแบบ burst, same-day, reload, ข้าม micro/คน, และการกด action ซ้อน. **อย่าเอาแค่ disable button มาแทน validation**.
- ตรวจ ECO.earn และ CULT.gain ใช้เพียงครั้งเดียวเมื่อ activity สำเร็จจริง; บันทึก event ID สำเร็จเป็น atomic commit.

## งาน B — Unified participant validation + reservation (P1)
- WORLD-02/03/04/05/06: สร้าง canonical resolver `W.byId[id]`, ตรวจ membership, unique ids, living, not exiled, jail expiry, away, expId, travel และ mission-specific rules; ให้ทุก route `EXPLORE`, `EXPED`, `UI.atlasParty` ใช้ contract เดียว.
- ทำ single-owner mission reservations; enqueue/resolution/abort/death ต้องตรวจ owner; ห้ามส่ง NPC สองงานพร้อมกัน; ปล่อยสมาชิกเฉพาะเมื่อ exId ตรง, กันการจ่าย loot ที่อ้างสมาชิกซ้ำ.
- อย่ากระทบกฎพิเศษของ faction/guest NPC ถ้ามีอยู่จริง: แยก `playerOwned` กับคู่แข่งตามกติกา.

## งาน C — Integrity, rollback, logs (P2)
- WORLD-07 ค่ายตรง region+active เท่านั้น ไม่มี first-outpost fallback.
- WORLD-08 chronicle หนึ่งกิจกรรมหนึ่ง entry และมี unique id.
- WORLD-09 reject foreign/stale NPC object; APIs ควรรับ ID แล้ว canonicalize.
- WORLD-10 validate mission kind BEFORE any mutation; return `{ok:false,reason:...}` and rollback/no partial mission.
- WORLD-11 unknown specified choiceId return invalid-choice ไม่ตกไปใช้ default.

## งาน D — Review (ห้ามเนิร์ฟอัตโนมัติ)
- WORLD-12 ถึงก่อนชนะ (race) vs ชนะพลัง (combat): ระบุ intended mechanic ให้ชัด.
- WORLD-13 จำกัด immediate:true ให้ dev/test-only ถ้าเป็น debug escape.
- WORLD-14 ประสานทีมเศรษฐกิจว่า world.resourcePool เป็น cap หรือ telemetry; ไม่สั่งปรับเอง.

## Test plan ที่ต้องผ่านก่อน merge
1. เปิดเกมใน browser จริง ทดสอบ micro 4 แห่งในหน้าต่าง atlas/sect ด้วย mouse/touch/keyboard; กดซ้ำ, spam click, reload, day advance, UI feedback.
2. ต้องมีผู้เล่นพร้อม 3 NPC, NPC dead/exiled/jailed/away/expId/travel, party duplicate, foreign object; ทั้ง UI และ API ให้ผลเดียวกัน.
3. ส่ง gather และ world anomaly ซ้อนกันต้องถูกปฏิเสธโดยไม่มี state เปลี่ยน; world anomaly ปกติ resolve แล้วปล่อยสมาชิกครั้งเดียว.
4. ทดสอบ cave/pagoda/world anomaly/normal expedition ไม่รับ party duplicate; ทดสอบ malformed kind & unknown choice ให้ no-op.
5. รัน baseline 6 ชุดใน `WORLD_EXPLORATION_REGRESSION_LOG.txt` + game-wide automated suite; ตรวจ `node --check`, schema, source HTML build parity, save/restore กับภารกิจค้างและ event completion.
6. ทดสอบ 30/180 วันและดู chronicle, economy growth, NPC status, memory/performance; ระบุ seed/แพลตฟอร์ม.
7. **Negative-path regression:** สคริปต์เดิมบันทึกพฤติกรรมที่เป็นบัค ดังนั้นหลังแก้ **expected assertions ต้องกลับทิศเป็นปฏิเสธ** ห้ามนำตัวเลข reproduced=30 มาใช้เป็นเกณฑ์ผ่านหลังแก้.

```bash
GAME_SOURCE_ROOT=/path/to/GAME_SOURCE node WORLD_EXPLORATION_REPRO_TESTS.js
```

ไฟล์ทดสอบและเอกสารใน ZIP นี้ **ไม่ได้แก้ source** และไม่การันตี E2E browser เพราะระบบทดสอบปัจจุบันเจอ `ERR_BLOCKED_BY_ADMINISTRATOR`.

## ความเสี่ยงซ้ำกับหมวดอื่น
- สำนัก: SECT-28/การลงโทษ/การออกสำนัก/ค่ายพัก → eligibility ต้องต้นทางเดียว.
- ต่อสู้: COMBAT-01 การตายและการกู้ข้อมูลผู้ตาย → party reservation ต้อง release ถูก.
- อุปกรณ์/วิถี: ค่าสถานะและ mount/skills เพิ่ม travel power, แต่ห้ามซ้ำ NPC ใน roster.
- เศรษฐกิจ/เซฟ: อีกแชทตรวจอยู่ ให้ประสาน invariant/serializer โดยไม่ทับงาน.

## ส่งมอบ
อ้าง ID WORLD-01..14 ใน changelog, ใส่ patch/line/test evidence, อัปเดต `AGENTS.md`-relevant skills และ status docs เมื่อ *แก้ source จริง*, เก็บ `human_core.js` byte-identical, อย่าขัดการรับประกัน backward behavior ที่ตั้งใจไว้ และตรวจ release package ตาม AGENTS.
