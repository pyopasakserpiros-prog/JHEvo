/* JianghuSect2 v2.3.0 — Dao / Subpath follow-up audit
 * Node.js 18+ | no source modifications | source checkout must have test/load.js
 * Run: GAME_SOURCE_ROOT=/path/to/release_root node DAO_PATH_SUBPATH_REPRO_TESTS.js results.json
 * This tool reproduces current bugs; fix target is BUG_REPRODUCED -> BUG_FIXED.
 */
'use strict';
const fs=require('fs'),path=require('path');
const roots=[process.env.GAME_SOURCE_ROOT,path.join(__dirname,'GAME_SOURCE'),path.join(__dirname,'..','GAME_SOURCE'),__dirname].filter(Boolean);
const root=roots.find(p=>fs.existsSync(path.join(p,'test','load.js')));
if(!root)throw Error('Cannot locate game source: set GAME_SOURCE_ROOT to the extracted project folder containing test/load.js');
const g=require(path.join(root,'test','load.js'));
const {CULT,MARTIAL:M,STATS:ST,SIM,HC}=g;
const out={audit:'Dao paths + subpaths v2.3.0',sourceRoot:path.basename(root),createdAt:'2026-11-08',cases:[],findings:{},notes:[]};
function record(id,severity,title,bug,observed,expected){out.cases.push({id,severity,title,verdict:bug?'BUG_REPRODUCED':'BUG_FIXED_OR_NOT_REPRODUCED',observed,expected});}
function create(seed){const W=SIM.create(seed),n=W.npcs[0];return {W,n};}
function paths(){return Object.values(CULT.PATHS)}
const alias={BOW:'SWORD',STAFF:'SPEAR',ASTRAL:'SCRIPTURE',ROSARY:'SOUL_DIVINE',CLAW:'FIST_PALM',NEEDLE:'MEDICINE',FAN:'WIND',ASTROLABE:'SCRIPTURE',ABACUS:'SCRIPTURE'};
const specialSkills=new Set(['WATER_ICE','WOOD_LIFE']);
const invalid=[];
for(const p of paths())for(const sub of p.subPaths){const def=CULT.trackDef(sub.id);if(!def)continue;const refs=[];for(let i=0;i<def.realms.length;i++)for(const field of ['primarySkill','secondarySkill']){const skill=def.realms[i].skillGate?.[field];if(skill&&!M.SKILL_INFO[skill]&&!specialSkills.has(skill))refs.push({realm:i+1,field,skill});}if(refs.length)invalid.push({path:p.id,sub:sub.id,nameTh:sub.nameTh,refs});}
out.findings.badGateSubpaths=invalid;
out.findings.badGateRefAll=invalid.reduce((v,x)=>v+x.refs.length,0);
out.findings.badGateRefRealms2to9=invalid.reduce((v,x)=>v+x.refs.filter(y=>y.realm>=2).length,0);
record('DAO-001-A','P0','Subpath track gates refer to unknown skill IDs',invalid.length>0,{affectedSubs:invalid.length,badRefs:out.findings.badGateRefAll,badRefsRealms2to9:out.findings.badGateRefRealms2to9,subpaths:invalid.map(x=>x.path+'/'+x.sub)},'zero unknown identifiers in all 9 realm gates');
const {W:gateW,n:gateN}=create('DAO-gate-proof');const sample='SPIRIT_GRAIN_SOVEREIGN';gateN.cult={path:'SPIRIT_HUSBANDRY',sub:sample,stage:7,prog:0,mantra:null,techs:[],track:CULT.initTrack(sample,1,gateW.day)};
gateN.inv.stones=1e8;gateW.sect.stones=1e8;
for(const k of ['herbalism','cooking','HERBALISM','COOKING'])gateN.h.skills[k]=100;
gateN.cult.track.prog=CULT.trackThreshold(gateN);
const gateStatus=CULT.checkTrackGates(gateW,gateN);const gateResult=CULT.trackBreakthrough(gateW,gateN);
record('DAO-001-B','P0','Real track breakthrough blocked despite trained canonical skills',!gateStatus.ok&&gateStatus.resourceOk&&gateStatus.missingSkills.some(x=>['HERBALISM','COOKING'].includes(x.skill)),{path:gateN.cult.path,sub:sample,skill100:['herbalism','cooking'],resourceOk:gateStatus.resourceOk,missingSkills:gateStatus.missingSkills.map(({skill,current,required})=>({skill,current,required})),breakthrough:{ok:gateResult.ok,blockedByGate:!!gateResult.blockedByGate}},'skill gates resolve to real learnable skill IDs; breakthrough when progress & skills & stones are sufficient');
const {W:retrainW,n:retrainN}=create('DAO-mantra-proof');const high=CULT.mantraPool('DEMON').filter(t=>t.tier>=7&&!t.legendary).sort((a,b)=>b.tier-a.tier)[0];
if(!high)throw Error('Expected an ordinary tier-7 DEMON mantra');
retrainN.cult={path:'DEMON',sub:'SHADOW_ASSASSIN',stage:9,prog:0,mantra:high.id,unlockedMantras:[high.id],techs:[],track:null};
const destKey=M.subKey('STAR_ARCHER');retrainN.inv.crystals[destKey]=1;retrainN.cp=1e8;
const rt=M.retrain(retrainW,retrainN,destKey);if(!rt.ok)throw Error('Retrain repro failed: '+JSON.stringify(rt));
const validMantra=retrainN.cult.mantra;const before=ST.get(retrainN);
// Exactly mirrors ui.js switch-mantra handler after its membership check.
const uiCanSwitch=(retrainN.cult.unlockedMantras||[]).includes(high.id);
if(uiCanSwitch){retrainN.cult.mantra=high.id;HC.bump(retrainN);ST.dirty(retrainN);}
const after=ST.get(retrainN);
record('DAO-002','P1','Cross-path high-tier old mantra can be re-equipped through UI action',uiCanSwitch&&retrainN.cult.stage===1&&retrainN.cult.mantra===high.id&&after.matk>before.matk,{retrain:rt,oldMantra:{id:high.id,path:high.path,tier:high.tier},newPath:retrainN.cult.path,newStage:retrainN.cult.stage,defaultMantra:validMantra,uiCanSwitch,oldPathMantraEquipped:retrainN.cult.mantra===high.id,matkBefore:before.matk,matkAfter:after.matk,mdefBefore:before.mdef,mdefAfter:after.mdef},'switch-mantra checks selected mantra path, tier and current eligibility after retrain; preserve learned records only');
const {n:scoreN}=create('DAO-preference-keys');const badPref=[];
for(const [sub,pref] of Object.entries(CULT.SUBPREF)){for(const [key,weight] of Object.entries(pref.aff||{})){const actual=alias[key]||key;if(!Object.prototype.hasOwnProperty.call(scoreN.h.affinities,actual))badPref.push({sub,key,actual,weight,value:HC.eff(scoreN,'affinities.'+actual)});}}
out.findings.invalidPreferenceKeys=badPref;
record('DAO-003','P1','Invalid affinity references cause constant negative subpath AI preference',badPref.length>0,{badRefs:badPref.length,affectedSubs:new Set(badPref.map(x=>x.sub)).size,keys:[...new Set(badPref.map(x=>x.actual))],example:badPref.slice(0,6)},'all preference aff keys resolve to canonical HC affinity or explicit martial skill/trait mapping; scores respond to changing intended stat');
const {n:vN}=create('DAO-values-keys');const keyCases=[['MERCANTILE_DAO','wealthResource','wealth'],['FORTUNE_GAMBLER','wealthResource','wealth'],['ANCESTRAL_RITUAL','sectDuty','dutyHonor']];const valueChecks=[];
for(const [p,k,wrong] of keyCases){const targetSub=CULT.PATHS[p].subPaths[0].id;const initial=CULT.pathScores(vN).find(x=>x.path===p&&x.sub===targetSub)?.score;const prev=vN.h.values[k];vN.h.values[k]=(prev<50?100:0);HC.bump(vN);const changed=CULT.pathScores(vN).find(x=>x.path===p&&x.sub===targetSub)?.score;valueChecks.push({path:p,canonicalKey:k,bogusKey:wrong,canonicalValueBefore:prev,canonicalValueAfter:vN.h.values[k],bogusRead:HC.eff(vN,'values.'+wrong),scoreBefore:initial,scoreAfter:changed,delta:changed-initial});vN.h.values[k]=prev;HC.bump(vN);}
record('DAO-004','P1','Three paths read missing value keys so canonical wealth/duty never influences path choice',valueChecks.every(x=>x.delta===0),valueChecks,'path preference score responds to canonical wealthResource/sectDuty/honorLegacy trait changes');
const {W:cW,n:cN}=create('DAO-stale-life-cache');const lifeSub='WOOD_SPRING_BODY';cN.cult={path:'BODY',sub:lifeSub,stage:2,prog:0,mantra:null,techs:[],track:CULT.initTrack(lifeSub,5,cW.day)};
cN.inv.stones=1e8;cW.sect.stones=1e8;
for(const sk of Object.keys(M.SKILL_INFO))M.skillSet(cN,sk,100);M.skillSet(cN,'WOOD_LIFE',100);
cN.cult.track.prog=CULT.trackThreshold(cN);
const cGate=CULT.checkTrackGates(cW,cN);const v0=M.lifeMult(cN,'herbalism');
const cResult=CULT.trackBreakthrough(cW,cN,{guarantee:true});const cached=M.lifeMult(cN,'herbalism');const progressed=M.progression(cN).life.herbalism;
M.invalidateMartialCaches(cN);const correct=M.lifeMult(cN,'herbalism');
record('DAO-005','P2','Life-multiplier cache stale after real valid track breakthrough',cGate.ok&&cResult.ok&&cached===v0&&correct>cached,{gateOk:cGate.ok,breakthrough:{ok:cResult.ok,fromOrdinal:cResult.fromOrdinal,toOrdinal:cResult.toOrdinal},skill:'herbalism',cachedBefore:v0,cachedAfterBreakthrough:cached,correctAfterManualInvalidate:correct,progressionAfter:progressed},'after normal trackBreakthrough, M.lifeMult reflects new track ordinal without explicit invalidate by caller');
const coverage=paths().map(p=>({path:p.id,count:p.subPaths.length}));const subs=paths().flatMap(p=>p.subPaths.map(s=>({path:p.id,id:s.id})));const missingProfile=subs.filter(s=>!M.PROFILES[s.id]);const missingEffects=subs.filter(s=>!ST.SUBFX[s.id]&&!(g.JD.EXPANSION?.subStats||{})[s.id]);
out.findings.catalog={majorPaths:coverage.length,subpaths:subs.length,missingProfiles:missingProfile,missingSubStats:missingEffects};
record('DAO-006','INFO','Catalog and stat-profile connectivity',missingProfile.length>0||missingEffects.length>0,{...out.findings.catalog,paths:coverage},'every path/subpath has a valid profile and stat effect object');
const matFile=path.join(__dirname,'dao_baseline_matrix.json');if(fs.existsSync(matFile)){const m=JSON.parse(fs.readFileSync(matFile,'utf8'));const top=(stat,count=7)=>m.results.slice().sort((a,b)=>b.delta[stat]-a.delta[stat]).slice(0,count).map(x=>({path:x.path,sub:x.sub,deltaPct:x.delta[stat]}));
 out.findings.statOutliers={method:'single seed NPC, max major stage per path, no gear, no mantra, versus same-path NONE',atk:top('atk'),matk:top('matk'),def:top('def'),hp:top('hp')};out.cases.push({id:'DAO-007',severity:'REVIEW',title:'Outlier raw stats in high-level subpath profiles (not validated overpowered)',verdict:'REVIEW_ONLY',observed:out.findings.statOutliers,expected:'benchmark actual DPS/EHP/sustain/utility in matched-tier fights before adjusting meta'});}
out.summary={caseCount:out.cases.length,bugsReproduced:out.cases.filter(x=>x.verdict==='BUG_REPRODUCED').length,controlOrFixed:out.cases.filter(x=>x.verdict==='BUG_FIXED_OR_NOT_REPRODUCED').length,review:out.cases.filter(x=>x.verdict==='REVIEW_ONLY').length};
const dest=process.argv[2];if(dest)fs.writeFileSync(dest,JSON.stringify(out,null,2));console.log('Dao audit reproducibility:',JSON.stringify(out.summary));for(const t of out.cases)console.log(t.id,t.verdict,'|',t.title);console.log('Bad gate:',out.findings.badGateRefAll,'across',out.findings.badGateSubpaths.length,'subpaths');
