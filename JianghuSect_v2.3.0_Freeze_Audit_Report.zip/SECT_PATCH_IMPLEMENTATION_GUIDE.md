# AI Implementation Handoff — Sect Systems v2.3.0 (Non-economy)

## เป้าหมาย
แก้บัคระบบสำนักโดยไม่เพิ่ม feature ไม่เปลี่ยน balance ที่ตั้งใจ และไม่แตะเรื่องเศรษฐกิจ/อุปกรณ์/วิถีที่มีรายงานอีกหมวดแล้ว. อ่าน `QA_SECT_SYSTEMS_AUDIT_V230.md` + ผล JSON ก่อนแก้. ทำงานใน branch แยก ตรวจ save migration.

## ลำดับแก้ที่แนะนำ
1. **Invariant ธุรกรรม/ความถูกต้องของคดี:** SECT-01/02/03/04/12/21. ตรวจ id อย่างเข้มงวดและแยก explicit omitted-id (เลือกค่าแรก) จาก unknown-id; เช็ก availability, custody, successor sync, idempotent resolution.
2. **ความสมเหตุสมผลของกบฏ:** SECT-05/06/07/13/24 และ low-priority SECT-14. ลบ `|| true`; ส่งสมาชิกไปอยู่ฝ่ายเดียว; ไม่สร้างกบฏใน resolve; reject unknown choice; สอดคล้อง with prisoner/actual NPC.
3. **ตัวละครข้ามสำนัก/จารกรรม:** SECT-08/09/10/11. ให้ exchange เป็น lifecycle ชัดเจน with return day, unique ID and anti-repeat; espionage มี eligibility, mission allowlist, RNG/cooldown/cap และราคาที่ยอมรับตาม game balance. หากโมดูลไม่ได้ถูกเรียกใน UI ให้ป้องกันใน API เช่นกัน.
4. **ค่าหัว:** SECT-17/25/26/27. ชัดว่าไม่ได้ตรวจสมดุลราคา แต่ตรวจ completion / mission proof / timetable / dead hunter. UI default null target must still auto-pick first; explicit unknown target reject. ตรวจ distinct refresh controls ก่อนอ้าง exploitable infinite.
5. **ระบบอัตโนมัติ/ยอดเขา:** SECT-22/23. เชื่อม tick once per day with policy.enabled and lastRunDay (ไม่เรียก PEAKS.tick สองครั้ง), select cadence. ป้องกันแจก pill/expedition ซ้ำเมื่อ load หรือ sim resumes.
6. **API และข้อมูล:** SECT-15/18/19/20. บังคับ uniqueness/ownership/counter; invalid targets reject; ancestry relic same UID not dup. SECT-16 เป็น REVIEW: หาก free totems เป็น intentional endgame choice อย่า nerf, เพียงอธิบาย gate ให้ชัด.

## เทสต์ที่ต้องเติม
- หนึ่งชุดต่อ SECT-01..27; ข้อ SECT-16 เป็น design assertion โดยผู้ใช้อนุมัติ ไม่ควรทำให้ release gate FAIL เพราะยังไม่สรุปดีไซน์
- simulation tests: 1/30/120 days; save→load→resume สำหรับ exchange, schism, tribunal, role, bounty, auto, peaks; test RNG deterministic with seeds.
- UI end-to-end: tribunal wrong/stale id, auto appoint, resolve schism with no crisis, bounty four contracts and later refresh, free totems, automation toggles.
- Regression full repository plus five control suites. **รายงานใหม่ยังไม่ใช่ไฟล์แพตช์**; อย่า overwrite save, source หรือรายงานเดิม.

## วิธีรัน
`GAME_SOURCE_ROOT=/path/to/GAME_SOURCE OUTPUT_JSON=/tmp/sect_results.json node SECT_DEEP_REPRO_TESTS.js`

ก่อนแก้: ขึ้น REPRO 27/27 (รวม design-review 1) ตามเจตนาชุดแดง. หลังแก้: เพิ่ม green assertions และเช็กให้ผ่านใน release จริง.


## อัปเดต chain gate สำหรับ AI ก่อนปล่อย (8 พ.ย. 2026)

- **SECT-28 [P1]** เมื่อผู้สืบทอดตาย AI.kill ต้องล้าง successorId/posts.disciples พร้อมกันและ migration orphan state.
- **SECT-02/06/09** เพิ่ม guardRoster/auto duty, SPLINTER ownership และ exchange return checks แบบ `dayTick→save/load`.
- **SECT-17/27/19** เพิ่ม dead hunter, duplicate relic และ reward idempotence แบบข้ามโหลดเซฟ.
- **SECT-16 REVIEW** free 4 totems เพิ่ม rating NPC ≈28.9% และ Tier score +37 ในตัวอย่าง แต่ Tier ยัง STANDARD; นี่คือ evidence เพื่อถาม design ไม่ใช่คำสั่ง nerf.
- **EQ-013 เชื่อมสำนัก**: `AI.kill` อาวุธวิญญาณสืบทอดต้องไม่ลบอาวุธผู้รอดชีวิต; เป็น blocker ที่แก้ในรายงาน gear ด้วย.
