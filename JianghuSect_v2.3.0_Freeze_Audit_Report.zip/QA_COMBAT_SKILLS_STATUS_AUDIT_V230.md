# JianghuSect 2 v2.3.0 — ตรวจระบบต่อสู้ วิชา เอฟเฟกต์สถานะ และ AI ก่อนเปิดให้เล่น
> **รายงานหมวดที่ 5 แยกเป็นอิสระใน ZIP ชุดเดิม** · 8 พฤศจิกายน 2026 · ใช้ source ต้นฉบับเท่านั้น · **ไม่แก้ซอร์สเกม**

## 1. สรุปผลและการตัดสินปล่อยเกม
**ต้นฉบับ ZIP SHA-256:** `983e351b119c63f40b402c5e6e27c44a5f39683dc5e5b995773862efc467df62`
**ขอบเขต:** การต่อสู้/ผลดาเมจ/พลังวิชา/ออราสนับสนุน/วิชาคุ้มกัน/ค่ายกลสำนัก/กำแพงศึกบุก/สถานะผิดปกติ/โล่/วงจรสังหารและเซฟโหลด/AI เลือกสกิล. ไม่ทับหมวดเศรษฐกิจที่มีการตรวจแยกในอีกแชท.

**พบ 11 ประเด็น:** P0 1, P1 7, P1/REVIEW 1, P2 1, P3 1. **ทดสอบ 17 เคส**: ยืนยันอาการ 14, ควบคุม 2, ไม่ยืนยัน 1, script errors 0. ประเด็น 11 ไม่ได้แปลว่าทุกเคสคือบัคคนละตัว. **Regression เดิม 10 ชุดผ่าน** เมื่อแยกรัน.

**ตัดสินก่อนปล่อย:** `NOT READY` จนกว่าจะปิด `COMBAT-01` และแก้ข้อผิดฝ่าย (`COMBAT-02` ถึง `COMBAT-06`) พร้อม test side/participation, ปิดโล่ไม่ลด (`COMBAT-07`) และแก้ MECH path (`COMBAT-09`). `COMBAT-08` ยืนยันอาการ แต่ตัวเลข nerf/cooldown เป็นการออกแบบ ต้องทำ balance playtest ก่อนตัดสิน. อย่าอนุมานว่า 10 tests ผ่าน = ปลอดบัค.

## 2. ตารางติดตามงาน
| ID | ระดับ | ปัญหาโดยย่อ | Test IDs |
|---|---|---|---|
| COMBAT-01 | P0 | การตายจากศึกข้ามระบบบันทึกความตายและล้างตำแหน่ง | CB-13, CB-16, CB-15 |
| COMBAT-02 | P1 | วิชาสนับสนุนเพิ่มโจมตี/ฮีลให้ฝ่ายศัตรู | CB-01, CB-02 |
| COMBAT-03 | P1 | ตัวสนับสนุนที่ไม่อยู่ในศึกส่งบัฟข้ามศึกได้ | CB-03 |
| COMBAT-04 | P1 | ผู้คุ้มกันฝ่ายศัตรูรับความเสียหายแทนอีกฝ่าย | CB-04 |
| COMBAT-05 | P1 | ค่ายกลสำนักเพิ่ม ATK/ลดดาเมจให้ NPC ฝ่ายตรงข้าม | CB-05, CB-12 |
| COMBAT-06 | P1 | กำแพงธาตุศึกบุกสำนักรับดาเมจแทนผู้บุกที่เป็น NPC | CB-06, CB-17 |
| COMBAT-07 | P1 | โล่ shieldBp แบบเดิมรับความเสียหายซ้ำโดยค่าไม่ลด | CB-14 |
| COMBAT-08 | P1/REVIEW | วิชาฮีลจากออราทำงานทุกฮิต ไม่มีต้นทุนต่อครั้งหรือคูลดาวน์ | CB-09 |
| COMBAT-09 | P1 | ป้องกันวิถี MECH_PUPPET สายหุ่นกลไม่มีวันเข้าสาขาพิเศษ | CB-08 |
| COMBAT-10 | P2 | DOT ซ้อนชั้นหมดอายุแล้วหายทั้งหมด ไม่ลดทีละชั้น | CB-07 |
| COMBAT-11 | P3 | chooseSkill ดึง self ก่อนประกาศเมื่อไม่มีเป้าหมาย | CB-10 |

## 3. รายละเอียดทุกข้อ — สาเหตุ → ผลลูกโซ่ → วิธีแก้ → เกณฑ์ปิด
### COMBAT-01 [P0] การตายจากศึกข้ามระบบบันทึกความตายและล้างตำแหน่ง
- **การเข้าถึง/ขอบเขต:** เส้นทางการต่อสู้จริง + ยืนยันหลังเซฟ/โหลด
- **ตำแหน่ง:** js/combat.js:2700–2701,2746; js/ai.js:1765–1782; js/sim.js (serialize/deserialize)
- **ต้นเหตุ:** C.slay ทำ victim.dead = true ก่อน AI.kill; AI.kill มี guard if(n.dead)return ตั้งแต่บรรทัดแรก ทำให้ขั้นตอนส่วนใหญ่ไม่รัน
- **หลักฐานรันจริง:** หลังศึก NPC dead=true แต่ post=martial และ W.sect.posts.martial ยังชี้คนตาย; W.deaths=0, deathWhy=null, ไม่เกิด death log; บันทึก/โหลดแล้วยังค้าง. เคสควบคุมเรียก AI.kill ตรงทำงานถูก.
- **ผลกระทบลูกโซ่:** ศึกสังหาร → ไม่ปลดตำแหน่ง/เตียง/การไว้อาลัย/สืบทอด/ถ่ายทอดปราณหรือมรดกใน AI.kill → UI สำนักและระบบสรรหาตีความผิด → ข้อมูลเซฟผิดถาวร; ความเสี่ยงผู้เล่นสูญเสียกิจกรรม/มรดก
- **แนวทางแก้ที่ราก:** กำหนด single canonical death transaction: C.slay เรียก AI.kill ก่อนให้ dead=true และแยก hook onDeath/การสะสม kill-credit ที่ต้องทำต่อ; ใช้ guard idempotent หลังดำเนินงานสำเร็จ; ตรวจทางตายอื่น, summon และ foe ต่างหาก
- **Acceptance/Regression:** ฆ่า NPC ตำแหน่ง martial 1 ครั้งแล้วต้องมี deathDay/deathWhy, W.deaths+1, post null ทั้ง NPC และ W.sect.posts, log ความตาย 1 ครั้ง, ผลสืบทอดถูกต้อง, เซฟโหลดแล้วคงสถานะ; เรียกซ้ำไม่เพิ่ม death count
- **Reproduction IDs:** `CB-13, CB-16, CB-15`

### COMBAT-02 [P1] วิชาสนับสนุนเพิ่มโจมตี/ฮีลให้ฝ่ายศัตรู
- **การเข้าถึง/ขอบเขต:** runtime combat NPC ฝ่ายตรงข้าม
- **ตำแหน่ง:** js/combat.js:886–917; js/combat.js:203–215
- **ต้นเหตุ:** วน W.npcs ทั้งโลก ใช้ระยะห่างและไม่ dead/away เป็นหลัก ไม่ใช้ C.isAlly(f,supportId, recipientId)
- **หลักฐานรันจริง:** ตัวสนับสนุนฝ่าย B เพิ่มดาเมจให้ฝ่าย A +21%; นักเยียวยาฝ่าย B ฮีลตัวฝ่าย A (บันทึกฮีล 76 HP) ทั้งที่กำลังโจมตีกัน
- **ผลกระทบลูกโซ่:** ดวล/รบหลายทีม → บัฟผิดฝ่าย → DPS/EHP และผลแพ้ชนะกลับด้าน → บันทึกฆ่า, บาดเจ็บ, ตาย และภารกิจสำนักเปลี่ยนจากที่ออกแบบ
- **แนวทางแก้ที่ราก:** แยก list ตัวสนับสนุนที่อยู่ฝั่งเดียวกันใน f ณ เวลาสกิลออกผล; เช็ก C.isAlly(f, supNpc.id, a.id/d.id) ก่อนคำนวณระยะ; คุม recursion และเงื่อนไข no-self ตามดีไซน์
- **Acceptance/Regression:** ฝ่าย B ไม่บัฟหรือฮีล A; ฝ่าย A ยังช่วย A ได้ตามระยะ; ทั้ง NPC vs NPC, NPC vs foe และ raid
- **Reproduction IDs:** `CB-01, CB-02`

### COMBAT-03 [P1] ตัวสนับสนุนที่ไม่อยู่ในศึกส่งบัฟข้ามศึกได้
- **การเข้าถึง/ขอบเขต:** runtime combat; ผู้ยืนใกล้ไม่ใช่ participant
- **ตำแหน่ง:** js/combat.js:886–916; js/combat.js:203–207
- **ต้นเหตุ:** ค้นหา support จาก W.npcs ทั้งหมดโดยไม่บังคับ sideOf(f,supNpc.id) มีค่า
- **หลักฐานรันจริง:** ตัวที่ไม่ได้อยู่ใน f.A หรือ f.B (side=null) ทำให้สถิติ command buffs เพิ่ม 1 ครั้งในศึกได้
- **ผลกระทบลูกโซ่:** สำนักที่ยืนติดลานรบหลายวง → ซ้อนบัฟผ่านระยะโดยไม่ลงสนาม/ไม่เสี่ยงตาย → การคำนวณสมดุลทีมและตำแหน่ง AI ผิด
- **แนวทางแก้ที่ราก:** เฉพาะผู้มีสิทธิ์เข้าร่วม combat f และมีชีวิตในสนามเท่านั้นจึงให้ aura; กรณี world buff ที่ตั้งใจให้ใช้ข้ามวงต้องสร้าง API/flag แยกพร้อมต้นทุนและความชัดเจน
- **Acceptance/Regression:** side=null ให้บัฟ/ฮีลไม่ได้ ขณะสมาชิกทีมเดียวกันในสนามได้ตามปกติ
- **Reproduction IDs:** `CB-03`

### COMBAT-04 [P1] ผู้คุ้มกันฝ่ายศัตรูรับความเสียหายแทนอีกฝ่าย
- **การเข้าถึง/ขอบเขต:** runtime combat ฝ่ายตรงข้าม
- **ตำแหน่ง:** js/combat.js:823–840
- **ต้นเหตุ:** สแกน W.npcs แล้วตรวจแค่ระยะ/defensiveState ไม่มีการตรวจฝ่ายและการเข้าร่วมศึก
- **หลักฐานรันจริง:** guardian ฝ่าย B ไปขวางความเสียหายให้ A: intercepted 10 และตัว guardian เสียเลือดเอง
- **ผลกระทบลูกโซ่:** เปลี่ยนผลการบาดเจ็บของคู่ต่อสู้, AI อาจตายแทนศัตรู → ระบบตาย/ตำแหน่ง/ของตกในสำนักผิด
- **แนวทางแก้ที่ราก:** guard C.isAlly(f, guardian.id, d.id) และ C.alive(guardian); เลือก guardian ฝั่งเดียวกันใน f พร้อมทดสอบกรณี multiple guardians
- **Acceptance/Regression:** ศัตรูและผู้ไม่ร่วมศึกไม่ได้คุ้มกัน; ฝ่ายเดียวกันยัง intercept ได้โดยลดทรัพยากรตามเงื่อนไข
- **Reproduction IDs:** `CB-04`

### COMBAT-05 [P1] ค่ายกลสำนักเพิ่ม ATK/ลดดาเมจให้ NPC ฝ่ายตรงข้าม
- **การเข้าถึง/ขอบเขต:** runtime NPC vs NPC หรือดวล NPC ต่างฝ่าย; scope ไม่รวม hostile foe บางชนิด
- **ตำแหน่ง:** js/combat.js:812–821
- **ต้นเหตุ:** เช็กเพียง !a.foe หรือ !d.foe (เป็น NPC) แทนการเป็นกำลังสำนักเจ้าของค่ายกล
- **หลักฐานรันจริง:** SWORD_NET_SLAUGHTER ทำให้ NPC ฝ่าย B โจมตี 30 → 37; IMMORTAL_AEGIS_DOME ลดดาเมจที่ NPC ฝ่าย B รับจาก 100 → 78
- **ผลกระทบลูกโซ่:** บัฟเชิงยุทธวิธีถูกแบ่งให้คู่ต่อสู้ → สงครามสำนัก/กบฏและป้องกันตำแหน่งตีค่าผิด, ผลชนะเปลี่ยน → รางวัล/มรดกต่อเนื่อง
- **แนวทางแก้ที่ราก:** จำแนก ownership ของ formation จาก W.sect และฝ่าย/สังกัดก่อนใช้; อย่าใช้ !foe เป็นตัวแทนคำว่า ally; ทดสอบ PvE/NPC raid แยก
- **Acceptance/Regression:** ค่ายกลผู้เล่นไม่บัฟ/ป้องกัน NPC ฝ่ายตรงข้าม; NPC ฝ่ายผู้เล่นได้โบนัส; ถ้ารบกลางกลางต้องไม่ติดอัตโนมัติ
- **Reproduction IDs:** `CB-05, CB-12`

### COMBAT-06 [P1] กำแพงธาตุศึกบุกสำนักรับดาเมจแทนผู้บุกที่เป็น NPC
- **การเข้าถึง/ขอบเขต:** runtime raid; hostile NPC raider; ยืนยันกรณี foe ไม่ผิดแบบเดียวกัน
- **ตำแหน่ง:** js/combat.js:1028–1037
- **ต้นเหตุ:** เงื่อนไข f.kind=raid && !d.foe ไม่ตรวจว่า defender เป็นฝ่ายสำนักที่มีกำแพง
- **หลักฐานรันจริง:** โจมตี NPC ผู้บุก 100 แต่กำแพงผู้ป้องกันลด 1000→965 และผู้บุกเสีย HP เพียง 65; เคสควบคุม hostile foe ไม่ได้รับโล่
- **ผลกระทบลูกโซ่:** ป้องกันสำนักกลายเป็นช่วยผู้บุก → siege outcome/จำนวนผู้บาดเจ็บ/รางวัลสงครามผิด, พลังโล่ถูกเผาให้ศัตรู
- **แนวทางแก้ที่ราก:** ตรวจว่า d เป็นสมาชิก/หน่วยฝ่ายที่ได้รับการคุ้มครองจริงและมีสิทธิ์ใน raid f; แยก siege side จาก !foe
- **Acceptance/Regression:** NPC ผู้บุกไม่ได้ใช้กำแพง; ฝ่ายผู้ป้องกันใช้ได้; hostile foe, NPC-neutral, NPC-owned raiders มี regression
- **Reproduction IDs:** `CB-06, CB-17`

### COMBAT-07 [P1] โล่ shieldBp แบบเดิมรับความเสียหายซ้ำโดยค่าไม่ลด
- **การเข้าถึง/ขอบเขต:** runtime API; แหล่งใช้ shieldBp มีใน js/visitors_clues.js; UI-to-legacy route ยังไม่ได้พิสูจน์ครบ
- **ตำแหน่ง:** js/combat.js:459, 731–748; js/visitors_clues.js:5607,5664
- **ต้นเหตุ:** shieldOf สร้าง object ใหม่ {k:shield,amt:u.shieldBp} แทนตัวอ้างอิงบน NPC; C.applyDamage ลดเพียง sh.amt บน object ชั่วคราว
- **หลักฐานรันจริง:** shieldBp=100 รับ 4 hits ×50, HP ไม่ลดเลย และ shieldBp ยัง=100
- **ผลกระทบลูกโซ่:** ศัตรู/NPC ที่ได้โล่ legacy กลายเป็นแทบอมตะเมื่อรับ hit ย่อย; ถ้า P0 ระบบตายผิดด้วยจะบดบังการตรวจมรดก/คำนวณการรบ
- **แนวทางแก้ที่ราก:** ย้าย shieldBp เข้า canonical status shield หรือหักจาก u.shieldBp จริงและสั่ง dirty; ระวัง double counting กับ shield status และ migration save เก่า
- **Acceptance/Regression:** 4 hits ×50 กับ shieldBp=100: โล่หมดตามกฎ, HP สูญเสียหลังโล่หมด; เซฟ/โหลดระหว่างฮิตไม่คืนโล่
- **Reproduction IDs:** `CB-14`

### COMBAT-08 [P1/REVIEW] วิชาฮีลจากออราทำงานทุกฮิต ไม่มีต้นทุนต่อครั้งหรือคูลดาวน์
- **การเข้าถึง/ขอบเขต:** runtime; ข้อจำกัดการ procs ต้องยืนยัน design
- **ตำแหน่ง:** js/combat.js:902–914; js/cultivation.js (SUPPORT_ARTS)
- **ต้นเหตุ:** ทุกครั้งที่ applyDamage ถูกเรียก จะคำนวณ healPct*hpMax แม้ฮิตถี่ใน W.t เดียว ไม่มี ICD หรือ Qi drain ภายในเส้นทางนี้
- **หลักฐานรันจริง:** โดนตีเบา 8 ครั้งใน tick เดียว ตัวสนับสนุนบันทึก healing procs 264 หน่วย (8×33), Qi ใช้ 0; ตัวรับฮีลกลับเต็ม HP ได้
- **ผลกระทบลูกโซ่:** โจมตีแบบ multi-hit / proc ดาเมจต่ำ → กลายเป็นแหล่งฟื้นเลือดไม่จำกัดตามจำนวนฮิต → anti-meta ไม่สมเหตุสมผล; ต้องทดสอบ DPS จริงก่อนตั้งตัวเลข nerf
- **แนวทางแก้ที่ราก:** ยืนยันเจตนา design ก่อน: จำกัด heal ต่อ attack action, ICD per support-target หรือ shared heal budget ต่อ tick; ตั้งค่า Qi/ทรัพยากรตามกฎเดียวกัน; นับเฉพาะ effective healing ไม่ใช่ยอดก่อน cap
- **Acceptance/Regression:** ทดสอบ 1-hit vs 8-hit ภายใน tick เดียว, heal ไม่ scale แปลกกับจำนวน hits; build สนับสนุนยังมีประโยชน์ ไม่ nerf แบบเหวี่ยง
- **Reproduction IDs:** `CB-09`

### COMBAT-09 [P1] ป้องกันวิถี MECH_PUPPET สายหุ่นกลไม่มีวันเข้าสาขาพิเศษ
- **การเข้าถึง/ขอบเขต:** runtime; อ้างอิงวิถีหลักที่มีข้อมูลจริง
- **ตำแหน่ง:** js/combat.js:1451–1476; js/cultivation.js (PATHS/ensureMechState)
- **ต้นเหตุ:** เงื่อนไข else if(CULT.PATHS[d.cult.path]) มาก่อน else if(d.cult.path===MECH_PUPPET) ทำให้ทุก MECH_PUPPET ที่อยู่ใน PATHS ถูกดักด้วย generic branch
- **หลักฐานรันจริง:** ดวลโจมตีหุ่นกล mode BASTION แล้ว integrity ยังคง 100 และไม่มีการดูดซับตามสาขาเฉพาะ
- **ผลกระทบลูกโซ่:** ต้นทุน integrity/charge ไม่ถูกใช้ → ปรับสมดุลความถึกหุ่นกลผิด; ทำให้ความต่างสายย่อยและโหมดหาย
- **แนวทางแก้ที่ราก:** ย้ายเงื่อนไข MECH_PUPPET ก่อน generic PATHS หรือแยก path-specific mitigation resolver หลัง generic แบบไม่ซ้อน; ตรวจ caps และ resource spend
- **Acceptance/Regression:** MECH_PUPPET BASTION ถูกตีแล้ว integrity ลดและ charge อัปเดต; generic paths ยังคงลดดาเมจตามเดิม
- **Reproduction IDs:** `CB-08`

### COMBAT-10 [P2] DOT ซ้อนชั้นหมดอายุแล้วหายทั้งหมด ไม่ลดทีละชั้น
- **การเข้าถึง/ขอบเขต:** runtime statusTick
- **ตำแหน่ง:** js/combat.js:2570–2602; js/stats.js:195–235
- **ต้นเหตุ:** C.statusTick เรียก ST.purgeExpired ก่อนเข้า branch stackDecayMode=LAYERED ทำให้สถานะที่ x.until<=W.t ถูกกรองออกทันที
- **หลักฐานรันจริง:** poison stacks=3 duration=2 ถึงวันหมดอายุแล้วรายการสถานะกลายเป็น [] แทน stacks=2 และต่ออายุครึ่ง duration
- **ผลกระทบลูกโซ่:** build สายพิษ/เลือดไหลเสียช่วงเวลา DOT ที่ออกแบบ; cap/balance ของบัฟบิดเบี้ยว; ตัวเลข DPR จากเทสต์ทั่วไปไม่ครอบคลุมหมดอายุ
- **แนวทางแก้ที่ราก:** กำหนดเจ้าของ lifecycle ของ layered statuses เพียงที่เดียว; แยก purge invalid กับ expire/decay หรือย้าย decay ก่อน purge, ใช้ ST.dirty
- **Acceptance/Regression:** poison layered 3→2→1→0 ข้ามหลาย tick และเซฟ/โหลดระหว่างเสื่อมชั้น; duration ปกติหมดแล้วหาย
- **Reproduction IDs:** `CB-07`

### COMBAT-11 [P3] chooseSkill ดึง self ก่อนประกาศเมื่อไม่มีเป้าหมาย
- **การเข้าถึง/ขอบเขต:** เฉพาะ direct API เรียก d=null; เส้นทางเล่นปกติมักมี target
- **ตำแหน่ง:** js/combat.js:1928–1929
- **ต้นเหตุ:** const ... tdp = d ? C.power(d) : self, self = C.power(a) มี Temporal Dead Zone เมื่อ d เป็น null
- **หลักฐานรันจริง:** เรียก C.chooseSkill(W,f,a,null,{cds:{}}) ได้ ReferenceError Cannot access self before initialization
- **ผลกระทบลูกโซ่:** หาก UI/AI สกิล self/team สามารถเรียกโดยไร้เป้าหมายจะทำให้ action interrupt; ยังไม่ยืนยันเส้น UI ดังกล่าว
- **แนวทางแก้ที่ราก:** ประกาศ self ก่อน tdp แยก statement; ตรวจ self/team skill path และ ctx null guards
- **Acceptance/Regression:** null target ไม่ throw, เลือกสกิล self/team หรือคืน null แบบปลอดภัยตามกฎ
- **Reproduction IDs:** `CB-10`

## 4. ตัวอย่างหลักฐานทดสอบ — แยกอาการกับเคสควบคุม
| เคส | ผล | Observed |
|---|---|---|
| CB-01 | REPRO | `{   "supportSide": "B",   "attackerSide": "A",   "increased": 1,   "damageBonus": 0.21 }` |
| CB-02 | REPRO | `{   "supportSide": "B",   "targetSide": "A",   "hpBefore": 221,   "hpAfter": 272,   "healEvent": 76,   "healPct": 0.154 }` |
| CB-03 | REPRO | `{   "supportInFight": null,   "changedAttacks": 1,   "insideRadius": true }` |
| CB-04 | REPRO | `{   "guardianSide": "B",   "targetSide": "A",   "allowed": true,   "proc": {     "t": 518760,     "kind": "ALLY_AEGIS_INTERCEPT",     "textTh": "👑 ม่านสวรรค์รับเคราะห์แทนสหาย!",     "protectedId": "n_master",     "intercepted": 10   },   "guardHpBefore": 232, …` |
| CB-05 | REPRO | `{   "attackerSide": "B",   "sectPlayerSide": "A",   "dealt": 37,   "raw": 30,   "activeStance": "SWORD_NET_SLAUGHTER" }` |
| CB-06 | REPRO | `{   "defenderSide": "A",   "raiderSide": "B",   "barrierBefore": 1000,   "barrierAfter": 965,   "enemyHpLost": 65 }` |
| CB-07 | REPRO | `{   "before": [     {       "k": "poison",       "stacks": 3,       "until": 518762     }   ],   "after": [],   "expected": "stack=2, renewed until" }` |
| CB-08 | REPRO | `{   "hit": true,   "firstIntegrity": 100,   "finalIntegrity": 100,   "mode": "BASTION",   "hasPathEntry": true,   "damage": 0.30891235298860625 }` |
| CB-09 | REPRO | `{   "heals": 264,   "healPct": 0.154,   "qiSpent": 0,   "hitCount": 8,   "gameTimeElapsed": 0,   "targetHp": 213 }` |
| CB-10 | REPRO | `{   "error": "Cannot access 'self' before initialization" }` |
| CB-11 | NO_REPRO | `{   "skill": "INNATE_DIVINE_FLAME_CRUCIBLE",   "cost": 19,   "qiAfter": 54.32,   "castFx": true,   "hpBefore": 204,   "hpAfter": 169.53491920095098 }` |
| CB-12 | REPRO | `{   "enemySide": "B",   "defendersSide": "A",   "damage": 78,   "raw": 100,   "stance": "IMMORTAL_AEGIS_DOME" }` |
| CB-13 | REPRO | `{   "damageKilled": true,   "dead": true,   "officerPost": "martial",   "sectOfficerId": "n895921",   "deathWhy": null,   "deathsBefore": 0,   "deathsAfter": 0,   "deathLogCount": 0 }` |
| CB-14 | REPRO | `{   "initialShield": 100,   "remainingShield": 100,   "hitCount": 4,   "rawDamageTotal": 200,   "hpLost": 0 }` |
| CB-15 | NO_REPRO | `{   "dead": true,   "post": null,   "officerSlot": null,   "deathWhy": "QA control",   "deathsDelta": 1 }` |
| CB-16 | REPRO | `{   "dead": true,   "post": "martial",   "postRef": "n131620",   "deathWhy": null,   "deaths": 0 }` |
| CB-17 | NO_REPRO | `{   "barrierHp": 1000,   "foeHp": 150 }` |

**คำอธิบาย:** `REPRO` คือบัค/พฤติกรรมที่ต้องทบทวนเกิดซ้ำในการทดสอบแบบจงใจท้าทาย invariant; **ไม่ใช่ผล PASS ของเกม**. `CB-11` ไม่ยืนยันบัค Qi เพราะมีเส้นทางเติม Qi ระหว่างรัน จึงไม่เปิด finding. `CB-15/17` เป็น positive controls. บัคบางจุดผ่าน direct API ไม่พิสูจน์ว่าผู้เล่นทั่วไปกดเอ็กซ์พลอยต์ได้จาก UI. ข้อมูลนี้เป็นการทดสอบ Node module ไม่ใช่ browser E2E.

## 5. แผนซ่อมแบบกลไกกลาง (หลีกเลี่ยงแก้ทีละอาการ)
1. ทำ **canonical combat-side predicate**: unit ต้องอยู่ใน fight side ที่อนุญาตและเจ้าของค่ายกลถูกต้อง; ใช้ผ่าน support/guardian/formation/barrier; แยก combat participant, world passive และ sect membership โดยกฎชัดเจน.
2. ทำ **canonical death transaction**: AI.kill/บริการตายเดียว; idempotent, บันทึกครั้งเดียว, post/bed/mentorship/inheritance/relationships ทุกระบบรับ event เดียว. ทดสอบทั้ง natural, combat, foe, summon, leadership, save/load.
3. ทำ **canonical shield + status lifecycle**: สถานะ shield จริงต้องลด persistent source; layered expiry ต้องผ่าน reducer ก่อน purge; save/load ไม่สร้าง resource ขึ้นใหม่.
4. จัดการ **resource/proc budgets**: heal/guard/MECH ใช้ทรัพยากรและ cooldown ตามแบบแผนเดียว พร้อม simulated multi-hit / multi-actor / 1 vs many cases.
5. หลังแก้แล้ว rerun repro (คาดว่าเคส violation กลับ NO_REPRO) และ 10 baseline suites; เพิ่ม browser combat smoke, soak simulation, legacy-save migration ก่อน Release Gate.

## 6. วิธีรันทดสอบและข้อจำกัด
```bash
GAME_SOURCE_ROOT=/absolute/path/to/GAME_SOURCE node COMBAT_DEEP_REPRO_TESTS.js
OUTPUT_JSON=/tmp/combat_results.json GAME_SOURCE_ROOT=/absolute/path/to/GAME_SOURCE node COMBAT_DEEP_REPRO_TESTS.js
```
ซอร์สต้นฉบับต้องมี `test/load.js` พร้อม `js/` ของเกม. ไฟล์ ZIP นี้มีเฉพาะรายงาน/สคริปต์ ไม่รวมซอร์ส. ไม่ได้รัน browser click-through ทั้งเกม; ไม่ได้รันครบทุก 130+ regression suites; `test/combat_stats.js` มีการจำลองขนาดใหญ่มากและถูกหยุดเมื่อรันนานในการสำรวจ **ไม่ควรนับว่า fail หรือ hang**. ผลทั้งหมดจากต้นฉบับ v2.3.0 ไม่ใช่แพตช์ที่ได้รับการแก้แล้ว.

## 7. หมวดถัดไปที่ควรตรวจ (หลังหมวดต่อสู้)
**อันดับ 1: เซฟ/โหลด, ย้ายเวอร์ชันเซฟ และวงจรเวลาโลก (World Tick / Daily / Monthly)** — เสี่ยงสูงสุดก่อนปล่อยจริง เพราะบัคที่พบหลายหมวดทิ้งสถานะผิดไว้ในเซฟ; ต้องทดสอบ 1 วัน→1 ปี, ปิดเกม/โหลดใหม่ตรงคูลดาวน์/วันครบภารกิจ, ตาย/เกิดใหม่/สืบทอด, ข้ามวัน, ออก-เข้าสำนัก, เอฟเฟกต์ซ้ำ, migration เซฟเก่า และความเร็วเมื่อ NPC จำนวนมาก.
**อันดับ 2: UI เส้นทางเล่นจริง + ความสอดคล้องของเมนู/ปุ่ม/ข้อความ** — ปิดช่อง API-only ที่อาจไม่ถึงผู้เล่น, แต่ยืนยัน exploit ที่กดได้จาก UI; แยก error/lag/browser interactions.
**อันดับ 3: สำรวจโลก/แผนที่/เหตุการณ์/ภารกิจ/การเดินทาง NPC** — ตรวจเหตุการณ์ที่ไม่ยิง tick, ตัวละครติดสถานะ away, reward/interaction ซ้ำ และระบบที่หลงลืมหลังเซฟโหลด. ไม่ทำราคา/เศรษฐกิจซ้ำ.

## 8. เชื่อมโยงรายงานเดิม
- `QA_FREEZE_AUDIT_V230`: P0 death transaction และเซฟโหลดผิดถาวร
- `QA_SECT_SYSTEMS_AUDIT_V230`: post/สืบทอด/ความสัมพันธ์/ป้อมเมืองขึ้นกับ death transaction และ side/formation/barrier
- `QA_GEAR_BALANCE_AUDIT_V230`: อาวุธจิตศาสตรา/มรดกต้องทดสอบทั้งตายจากศึกและตายปกติ; โล่เก่าที่หักไม่จริง
- `QA_DAO_PATH_SUBPATH_AUDIT_V230`: branch MECH และสถานะ DOT layered ใช้ path/subpaths จริง; ระวังไม่เนิร์ฟ meta โดยหลักฐาน DPS ไม่ครบ
