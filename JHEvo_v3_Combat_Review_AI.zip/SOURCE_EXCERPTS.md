# หลักฐานจากซอร์สที่คัดมา — ฐาน 2.0.35

แต่ละช่วงคัดลอกตรงจากไฟล์ต้นฉบับและกำกับเลขบรรทัด ณ commit `76a4756070a39fe786a3a604b47f54f16edfdaf4` ข้ามส่วนอื่นโดยตั้งใจ จึงไม่ใช่ไฟล์ที่ใช้รันได้ อย่าอนุมานว่า excerpt แสดงตรรกะทั้งหมดของฟังก์ชัน

## GAME_SOURCE/js/combat.js

### หน่วย ฝ่าย และสถานะชีวิต · บรรทัด 1–20

```javascript
    1 | /* combat.js — การต่อสู้: ประลองเบา (spar) ดวลจริง ท้าชิงตำแหน่ง ประลองยุทธ์สำนัก และการบุกของศัตรู
    2 |  * หน่วยรบ (unit) = NPC หรือศัตรู (foe) ผลลัพธ์มาจากกำลังรบ (CULT.power) + สภาพร่างกาย + ความคล่องตัว + นิสัย (กล้า/ยอมแพ้/หนี) ไม่ใช่ลูกเต๋าล้วน ๆ */
    3 | (function (g) {
    4 |   'use strict';
    5 |   const U = g.U || require('./util.js'), HC = g.HC, MAP = g.MAP, CULT = g.CULT, ECO = g.ECO, SECT = g.SECT, AI = g.AI, JD = g.JD;
    6 |   const clamp = U.clamp;
    7 |   const C = {};
    8 |   const E = (n, p) => HC.eff(n, p);
    9 | 
   10 |   /* ---------- หน่วยรบทั่วไป ---------- */
   11 |   C.unit = (W, id) => W.byId[id] || (W.foeById && W.foeById[id]) || null;
   12 |   C.alive = u => !!u && !u.dead && !u.fled && !u.yield;
   13 |   C.power = u => g.STATS.rating(u);
   14 |   C.hpMax = u => u.foe ? u.hpMax : CULT.hpMax(u);
   15 |   C.hp = u => u.foe ? u.hp : u.h.state.hp;
   16 |   C.setHp = (u, v) => { if (u.foe) u.hp = v; else u.h.state.hp = v; };
   17 |   C.name = u => u.foe ? u.name : u.h.name.given;
   18 |   C.agi = u => u.foe ? 50 + u.tier * 3 : (E(u, 'physiology.agility') + E(u, 'physiology.reflex')) / 2;
   19 | 
   20 |   /* ---------- ประลองเบา (คู่ฝึกยุทธ์) ---------- */
```

### สร้างศึก หน่วยและการเดิน · บรรทัด 57–99

```javascript
   57 |   C.startFight = (W, A, B, kind, opts) => {
   58 |     opts = opts || {};
   59 |     W.fights = W.fights || []; W.fightSeq = (W.fightSeq || 0) + 1;
   60 |     const f = { id: W.fightSeq, kind, serious: !!opts.serious, A: A.slice(), B: B.slice(), t0: W.t, state: opts.gather ? 'gather' : 'fight', arena: opts.arena || null, cb: opts.cb || null, ctx: opts.ctx || {}, over: false, log: [] };
   61 |     W.fights.push(f);
   62 |     [].concat(A, B).forEach(id => C.enter(W, f, id));
   63 |     return f;
   64 |   };
   65 |   C.enter = (W, f, id) => {
   66 |     const u = C.unit(W, id); if (!u) return;
   67 |     if (u.foe && !u.skl) u.skl = SKs().foeSkills(u);
   68 |     if (!u.foe && f.serious) STs().preFight(W, u, f.kind === 'raid');
   69 |     if (!u.foe) { AI.interruptFor(W, u); u.hidden = false; u.act = { id: 'fight', stage: 'do', left: 9999, total: 9999, ctx: { fid: f.id, target: null, cd: 0 }, why: [['เข้าต่อสู้', 9]] }; u.why = u.act.why; u.path = null; u.run = true; }
   70 |     else { u.act = { id: 'fight', ctx: { fid: f.id, target: null, cd: 0 } }; }
   71 |   };
   72 |   C.join = (W, f, id, side) => { if (f[side].includes(id)) return; f[side].push(id); C.enter(W, f, id); };
   73 |   C.fightOf = (W, u) => u.act && u.act.ctx && u.act.ctx.fid ? (W.fights || []).find(f => f.id === u.act.ctx.fid) : null;
   74 |   C.sideOf = (f, id) => f.A.includes(id) ? 'A' : 'B';
   75 |   C.enemies = (W, f, id) => (C.sideOf(f, id) === 'A' ? f.B : f.A).map(i => C.unit(W, i)).filter(C.alive);
   76 |   C.alliesOf = (W, f, id) => (C.sideOf(f, id) === 'A' ? f.A : f.B).map(i => C.unit(W, i)).filter(C.alive);
   77 | 
   78 |   function yieldThreshold(u) {
   79 |     if (u.foe) return u.fleeAt || 0.2;
   80 |     return clamp(0.34 - (E(u, 'personality.pride') - 50) / 400 - (E(u, 'personality.courage') - 50) / 500, 0.12, 0.45);
   81 |   }
   82 |   function fleeThreshold(u) { // เมื่อสู้จริงจัง
   83 |     if (u.foe) return u.fleeAt || 0.2;
   84 |     return clamp(0.22 - (E(u, 'personality.courage') - 50) / 260 - (E(u, 'personality.loyalty') - 50) / 400 + (E(u, 'personality.caution') - 50) / 400, 0.0, 0.3);
   85 |   }
   86 |   const FX_WORDS = ['ฟัน', 'แทง', 'ปะทะ', 'ฝ่ามือ', 'หลบ'];
   87 |   function techMove(W, u) {
   88 |     if (u.foe || !u.cult || !u.cult.techs.length) return null;
   89 |     const t = CULT.tech(W.rng.pick(u.cult.techs)); if (!t || !t.moves || !t.moves.length) return null; return W.rng.pick(t.moves);
   90 |   }
   91 |   function moveToward(W, u, tx, ty, run) {
   92 |     const dx = tx - u.x, dy = ty - u.y, d = Math.hypot(dx, dy); if (d < 0.01) return;
   93 |     if (u.foe) { const sp = u.speed * (run ? 1.0 : 0.8) * clamp(STs().get(u).move / 100, 0.4, 2); const s = Math.min(d, sp); const nx = u.x + dx / d * s, ny = u.y + dy / d * s; if (!MAP.blocked(W.map, nx, ny)) { u.x = nx; u.y = ny; } else { const ax = u.x + (dx > 0 ? s : -s) * (Math.abs(dx) > Math.abs(dy) ? 1 : 0.2), ay = u.y + (dy > 0 ? s : -s) * (Math.abs(dy) >= Math.abs(dx) ? 1 : 0.2); if (!MAP.blocked(W.map, ax, ay)) { u.x = ax; u.y = ay; } else { u.x += W.rng.gauss(0, 0.3); u.y += W.rng.gauss(0, 0.3); if (MAP.blocked(W.map, u.x, u.y)) { u.x = u.px; u.y = u.py; } } } u.face = dx >= 0 ? 1 : -1; return; }
   94 |     if (!u.path || (W.t + u.n) % 6 === 0) AI.goTo(W, u, Math.floor(tx), Math.floor(ty));
   95 |     AI.stepMove(W, u);
   96 |   }
   97 |   /* =====================================================================
   98 |    * ระบบสู้ใหม่ (v1.4 + v1.10 Overhaul): สเตตัสจริง (STATS) + วิชาหลายกระบวนท่า (SK) + วิชาติดตัว (PASSIVE)
   99 |    * ===================================================================== */
```

### ระยะและยุทธวิธีอาวุธปัจจุบัน · บรรทัด 107–145

```javascript
  107 |   C.resolveWeaponTactics = (a, d, o, f) => {
  108 |     o = o || {};
  109 |     const SK = SKs(), ST = STs();
  110 |     if (!a || !d || !SK || !SK.weaponTacticalProfile) {
  111 |       return { relation: 'NEUTRAL', dmgMult: 1, accAdd: 0, critAdd: 0, penAdd: 0, shieldBreakMult: 1, shatterGuard: false, noteTh: '' };
  112 |     }
  113 |     const pa = SK.weaponTacticalProfile(a);
  114 |     const pd = SK.weaponTacticalProfile(d);
  115 |     const rawDist = (Number.isFinite(a.x) && Number.isFinite(d.x) && (a.x !== d.x || a.y !== d.y)) ? Math.hypot(a.x - d.x, a.y - d.y) : 2.1;
  116 |     const dist = o.dist != null ? o.dist : rawDist;
  117 |     const moveArch = o.arch || (o.skill && o.skill.arch) || '';
  118 |     const isGapCloserMove = ['charge', 'evade', 'blink', 'flurry', 'pierce'].includes(moveArch) || !!(o.isGapCloser);
  119 |     const aHasLightness = pa.hasLightness || isGapCloserMove;
  120 |     const dHasLightness = pd.hasLightness || (ST && ST.has(d, 'evadeUp'));
  121 |     const dShielded = !!shieldOf(d) || (ST && ST.has(d, 'guardUp')) || pd.hasDefenseTech;
  122 | 
  123 |     let relation = 'NEUTRAL', dmgMult = 1, accAdd = 0, critAdd = 0, penAdd = 0, shieldBreakMult = 1, shatterGuard = false, noteTh = '';
  124 | 
  125 |     // 1. Long-reach polearms (SPEAR, STAFF) vs short-reach weapons (FIST, BLADE, SWORD)
  126 |     if (pa.reachClass === 'LONG_POLEARM' && (pd.reachClass === 'SHORT_SWIFT' || pd.reachClass === 'HEAVY_BREAKER')) {
  127 |       const firstStrikeWindow = !f || !f._firstStrikeUsed || !f._firstStrikeUsed[a.id];
  128 |       if (dHasLightness && (ST.has(d, 'evadeUp') || d._gapClosedOn === a.id)) {
  129 |         relation = 'POLEARM_COUNTERED_BY_LIGHTNESS';
  130 |         dmgMult = 0.96;
  131 |         noteTh = 'วิชาตัวเบาของ ' + C.name(d) + ' พุ่งฝ่าระยะ' + (pa.weaponType === 'SPEAR' ? 'หอก' : 'พลอง') + 'สลายความได้เปรียบเปิดศึก';
  132 |       } else if (firstStrikeWindow || dist >= 1.85) {
  133 |         relation = 'POLEARM_FIRST_STRIKE';
  134 |         dmgMult = pa.spec.firstStrikeMult || 1.12;
  135 |         accAdd += pa.spec.firstStrikeAcc || 10;
  136 |         if (f) { f._firstStrikeUsed = f._firstStrikeUsed || {}; f._firstStrikeUsed[a.id] = true; }
  137 |         noteTh = C.name(a) + ' อาศัยระยะ' + (pa.weaponType === 'SPEAR' ? 'ทวนยาว' : pa.weaponType === 'WHIP' ? 'แส้และด้ายปราณ' : 'พลองยาว') + 'ชิงลงมือก่อนอาวุธสั้น';
  138 |       }
  139 |     }
  140 | 
  141 |     // 2. Ranged weapons (BOW, FOCUS) kiting distance advantage vs melee until closed on by dash/leap
  142 |     if (pa.reachClass === 'RANGED_KITE') {
  143 |       const closedOn = (a._closedOnBy === d.id) || (dist < 1.45 && dHasLightness);
  144 |       if (!closedOn && dist >= 1.65) {
  145 |         relation = 'RANGED_KITING_ADVANTAGE';
```

### passive hooks · บรรทัด 221–237

```javascript
  221 |   function runPassiveProcs(W, f, actor, target, triggerKind, dmgDealt) {
  222 |     if (f && f._inProc) return;
  223 |     if (!actor || actor.foe || actor.dead) return;
  224 |     if (f) f._inProc = true;
  225 |     try {
  226 |       const SK = SKs(), ST = STs();
  227 |       const normTrigger = (SK && SK.normalizeTrigger) ? SK.normalizeTrigger(triggerKind) : triggerKind;
  228 |       if (actor.cult && g.MARTIAL && g.MARTIAL.passiveStats) {
  229 |         const ps = g.MARTIAL.passiveStats(actor);
  230 |         if (ps && Array.isArray(ps.procs) && ps.procs.length) {
  231 |           actor._procCds = actor._procCds || {};
  232 |           for (const proc of ps.procs) {
  233 |             const pKind = (SK && SK.normalizeTrigger) ? SK.normalizeTrigger(proc.kind || proc.trigger) : (proc.kind || proc.trigger);
  234 |             if (pKind !== normTrigger) continue;
  235 |             if ((actor._procCds[proc.techId] || 0) > W.t) continue;
  236 |             if (proc.condition && C.COMPOSABLE_ENGINE && C.COMPOSABLE_ENGINE.evaluateCondition) {
  237 |               if (!C.COMPOSABLE_ENGINE.evaluateCondition(proc.condition, actor, target, { W, f, triggerKind: normTrigger, dmgDealt })) continue;
```

### item hooks และ pre-damage · บรรทัด 276–310

```javascript
  276 |             if (proc.action && C.COMPOSABLE_ENGINE && C.COMPOSABLE_ENGINE.executeAction) {
  277 |               C.COMPOSABLE_ENGINE.executeAction(W, f, actor, target, proc.action, proc, { triggerKind: normTrigger, dmgDealt });
  278 |             }
  279 |             actor.lastPassiveProc = { t: W.t, techId: proc.techId, kind: normTrigger };
  280 |           }
  281 |         }
  282 |       }
  283 |       if (C.runItemEffectProcs) {
  284 |         C.runItemEffectProcs(W, f, actor, target, normTrigger, dmgDealt);
  285 |       }
  286 |     } finally { if (f) f._inProc = false; }
  287 |   }
  288 |   C.runPassiveProcs = runPassiveProcs;
  289 | 
  290 |   /* รับความเสียหาย: โล่ → เลือด → ยอมแพ้/หนี/ตาย */
  291 |   C.applyDamage = (W, f, a, d, dmg, note) => {
  292 |     if (W && (W.h || W.foe) && typeof f === "number" && d === undefined) {
  293 |       d = W;
  294 |       dmg = f;
  295 |       a = null;
  296 |       W = { t: (g.STATS && g.STATS.now) || 0, rng: { chance: () => false, next: () => 0.5 }, byId: {} };
  297 |       f = { id: 0, serious: false, A: [d.id], B: [] };
  298 |     }
  299 |     if (dmg > 0 && C.COMPOSABLE_ENGINE && f && (f._composableDepth || 0) < 3) {
  300 |       dmg = C.COMPOSABLE_ENGINE.interceptPreDamage(W, f, a, d, dmg, note);
  301 |     }
  302 |     const sh = shieldOf(d);
  303 |     if (sh) {
  304 |       const ab = Math.min(sh.amt, dmg);
  305 |       sh.amt -= ab;
  306 |       dmg -= ab;
  307 |       if (sh.amt <= 0) {
  308 |         STs().clearStatus(d, x => x.k === 'shield');
  309 |         if (a && !a.dead) runPassiveProcs(W, f, a, d, 'onShieldBreak', ab);
  310 |       }
```

### บริบทการเลือกท่า · บรรทัด 772–790

```javascript
  772 |   function chooseSkill(W, f, a, d, ctx) {
  773 |     const SK = SKs(), ST = STs(); if (ST.has(a, 'silence')) return null;
  774 |     const list = SK.list(a); if (!list.length) return null;
  775 |     const sa = ST.get(a), hpR = hpFrac(a), nonlethal = !f.serious, qi = a.foe ? 1e9 : (a.h.state.qi == null ? 1e9 : a.h.state.qi);
  776 |     const en = C.enemies(W, f, a.id), near = en.filter(x => Math.hypot(x.x - d.x, x.y - d.y) < 2.6).length;
  777 |     const aggr = a.foe ? 0.2 : (E(a, 'personality.aggression') - 50) / 200, caut = a.foe ? 0 : (E(a, 'personality.caution') - 50) / 200;
  778 |     const basicStat = Math.max(sa.atk, sa.matk), td = ST.get(d), tdp = C.power(d), self = C.power(a);
  779 |     const targetShielded = !!shieldOf(d) || ST.has(d, 'guardUp');
  780 |     const paTac = SK.weaponTacticalProfile ? SK.weaponTacticalProfile(a) : null;
  781 |     const pdTac = SK.weaponTacticalProfile ? SK.weaponTacticalProfile(d) : null;
  782 |     let best = null, bs = 1.15; ctx.cds = ctx.cds || {};
  783 |     for (const p of list) {
  784 |       if ((ctx.cds[p.id] || 0) > W.t) continue;
  785 |       if (p.tech && p.tech !== p.id && (ctx.cds['TECH_GCD:' + p.tech] || 0) > W.t) continue;
  786 |       if (!a.foe && g.MARTIAL && g.MARTIAL.skillEfficiency(a, p) <= 0) continue;
  787 |       const cost = a.foe ? 0 : SK.qiCost(a, p); if (qi < cost) continue;
  788 |       if (p.arch === 'forbid' && (nonlethal || (hpR > 0.45 && !(tdp > self * 1.5)))) continue;
  789 |       if (p.drawback && p.drawback.staminaCost && !a.foe && (a.h.state.energy || 0) < p.drawback.staminaCost + 8) continue;
  790 |       const syn = (!a.foe && g.MARTIAL && g.MARTIAL.skillSynergy) ? g.MARTIAL.skillSynergy(a, p) : null;
```

### เลือกท่าปัจจุบันและเป้าหมายรักษา · บรรทัด 882–907

```javascript
  882 |         if (pa.reachClass === 'LONG_POLEARM' && (pd.reachClass === 'SHORT_SWIFT' || pd.reachClass === 'HEAVY_BREAKER') && ['pierce', 'sweep', 'control'].includes(p.arch)) {
  883 |           sc += 0.95; // Polearm prioritizes reach control & first-strike thrusts
  884 |         }
  885 |         if (pa.reachClass === 'RANGED_KITE' && a._closedOnBy !== d.id && ['snipe', 'barrage', 'blast', 'channel'].includes(p.arch)) {
  886 |           sc += 1.15; // Ranged weapon capitalizes on kiting window
  887 |         }
  888 |       }
  889 |       if (p.aiRole === 'anti_armor' && td.def > td.mdef * 1.1) sc += 0.7;
  890 |       if (p.aiRole === 'finisher' && hpFrac(d) < 0.45) sc += 1.1;
  891 |       if (p.aiRole === 'opener' && hpFrac(d) > 0.75) sc += 0.6;
  892 |       if (p.aiRole === 'sustain' && (hpR < 0.65 || (!a.foe && qi < CULT.qiMax(a) * 0.45))) sc += 1.6;
  893 |       const archMeta = SK.ARCH && SK.ARCH[p.arch];
  894 |       const offensivePayload = archMeta
  895 |         ? archMeta.off === true
  896 |         : ((p.M || 0) > 0 || (p.dot || 0) > 0 || !!p.ctrl);
  897 |       if (offensivePayload && elemInter && elemInter.counterRelation === 'COUNTER_ADVANTAGE') sc += 0.38;
  898 |       else if (offensivePayload && elemInter && elemInter.counterRelation === 'RESISTED') sc -= 0.25;
  899 |       // Preserve the existing weapon-type synergy preference for utility/support skills too.
  900 |       if (syn && syn.matched) sc += 0.28;
  901 |       sc *= 0.88 + W.rng.next() * 0.24;
  902 |       if (sc > bs) { bs = sc; best = p; }
  903 |     }
  904 |     return best;
  905 |   }
  906 |   C.chooseSkill = chooseSkill;
  907 |   function lowestAlly(W, f, a) { const side = C.sideOf(f, a.id) === 'A' ? f.A : f.B; let w = null, m = 2; side.forEach(id => { const u = C.unit(W, id); if (!C.alive(u) || u.id === a.id) return; const r = hpFrac(u); if (r < m) { m = r; w = u; } }); return w; }
```

### ก่อนใช้ท่าและการเลือกผู้รับผล · บรรทัด 1272–1302

```javascript
 1272 |       return;
 1273 |     }
 1274 |     // Composable pre-strike execution (stanceShift, tetherLink, sacrificeOverdrive, comboReady consumption)
 1275 |     let comboMult = 1.0;
 1276 |     if (C.COMPOSABLE_ENGINE) {
 1277 |       const preRes = C.COMPOSABLE_ENGINE.preExecuteSkill(W, f, a, d, p, ctx);
 1278 |       if (preRes && preRes.comboMult) comboMult = preRes.comboMult;
 1279 |       if (preRes && preRes.handledCompletely) return;
 1280 |     }
 1281 |     // ท่าโจมตี (รองรับ Target Selector แบบยืดหยุ่น)
 1282 |     const targets = (C.COMPOSABLE_ENGINE && C.COMPOSABLE_ENGINE.selectTargets)
 1283 |       ? C.COMPOSABLE_ENGINE.selectTargets(W, f, a, d, p)
 1284 |       : (p.aoe ? C.enemies(W, f, a.id).filter(x => Math.hypot(x.x - d.x, x.y - d.y) < 2.6) : [d]);
 1285 |     if (d && !targets.includes(d) && C.alive(d)) targets.unshift(d);
 1286 |     const mas = masBase * comboMult; let dealt = 0;
 1287 |     targets.slice(0, 6).forEach((t, tIdx) => {
 1288 |       if (!C.alive(t)) return;
 1289 |       for (let i = 0; i < (p.hits || 1); i++) {
 1290 |         if (!C.alive(t)) break;
 1291 |         const wpnAcc = (!a.foe && g.MARTIAL && g.MARTIAL.weaponCompatibility) ? (g.MARTIAL.weaponCompatibility(a, p.tech || p.id).accDelta || 0) : 0;
 1292 |         const ricochetScale = p.arch === 'chainRicochet' ? Math.pow(0.92, tIdx) * (t.sx && t.sx.length ? 1.18 : 1.0) : (p.aoe && t !== d ? 0.8 : 1);
 1293 |         const r = C.strike(W, f, a, t, { M: p.M * mas * ricochetScale, synDmgMult: p.synDmgMult || 1, accAdd: (p.elementAccAdd || 0) + wpnAcc, type: p.type, pen: p.pen, forced: p.arch === 'blink', label: i === 0 ? label : null, silent: i > 0, critAdd: p.critAdd || 0, critDmgAdd: p.critDmgAdd || 0, isSkill: true, arch: p.arch, skill: p });
 1294 |         if (r.hit) {
 1295 |           dealt += r.dmg;
 1296 |           applyRiders(W, f, a, t, p, r);
 1297 |           if (C.COMPOSABLE_ENGINE) {
 1298 |             dealt += C.COMPOSABLE_ENGINE.postHitSkill(W, f, a, t, p, r) || 0;
 1299 |           }
 1300 |         }
 1301 |       }
 1302 |     });
```

### channel และโจมตี · บรรทัด 1390–1446

```javascript
 1390 |   C.interruptChannel = (W, f, u, reason) => {
 1391 |     if (!u.act || !u.act.ctx || !u.act.ctx.channeling) return false;
 1392 |     const ch = u.act.ctx.channeling;
 1393 |     STs().clearStatus(u, x => x.k === 'channeling');
 1394 |     u.act.ctx.cds = u.act.ctx.cds || {};
 1395 |     u.act.ctx.cds[ch.skillId] = W.t + Math.round((ch.skill.cd || 16) * 0.7);
 1396 |     delete u.act.ctx.channeling;
 1397 |     u.fx = { t: W.t, text: '⚡ เสียสมาธิ!' };
 1398 |     return true;
 1399 |   };
 1400 |   C.resolveChannelTick = (W, f, a, ctx) => {
 1401 |     if (!ctx.channeling) return;
 1402 |     const ch = ctx.channeling;
 1403 |     const t = C.unit(W, ch.targetId);
 1404 |     if (!C.alive(t)) {
 1405 |       STs().clearStatus(a, x => x.k === 'channeling');
 1406 |       delete ctx.channeling;
 1407 |       return;
 1408 |     }
 1409 |     const isFinal = ch.ticksLeft <= 1;
 1410 |     const mult = isFinal ? ch.finishM : ch.tickM;
 1411 |     const r = C.strike(W, f, a, t, {
 1412 |       M: mult,
 1413 |       accAdd: ch.skill.elementAccAdd || 0,
 1414 |       type: ch.skill.type || 'm',
 1415 |       pen: ch.skill.pen || 0,
 1416 |       label: isFinal ? '💥 ' + ch.skill.nameTh + ' ปะทุ!' : '🌀 คลื่นพลัง (' + (ch.totalTicks - ch.ticksLeft + 1) + '/' + ch.totalTicks + ')'
 1417 |     });
 1418 |     if (r.hit) applyRiders(W, f, a, t, ch.skill, r);
 1419 |     ch.ticksLeft--;
 1420 |     if (ch.ticksLeft <= 0 || !C.alive(t)) {
 1421 |       STs().clearStatus(a, x => x.k === 'channeling');
 1422 |       delete ctx.channeling;
 1423 |       a.fx = { t: W.t, text: '✨ ปลดปล่อยสมบูรณ์' };
 1424 |     }
 1425 |   };
 1426 |   C.attack = (W, f, a, d) => {
 1427 |     const ST = STs(); a.fx = a.fx || {};
 1428 |     const ctx = a.act && a.act.ctx ? a.act.ctx : {};
 1429 |     if (ST.has(a, 'stun')) {
 1430 |       if (ctx.channeling) C.interruptChannel(W, f, a, 'ติดมึนงง');
 1431 |       a.fx = { t: W.t, text: '💫' };
 1432 |       return 3;
 1433 |     }
 1434 |     if (ctx.channeling) {
 1435 |       if (ST.has(a, 'silence')) {
 1436 |         C.interruptChannel(W, f, a, 'ถูกผนึกวิชา');
 1437 |         return 3;
 1438 |       }
 1439 |       C.resolveChannelTick(W, f, a, ctx);
 1440 |       const sa = ST.get(a);
 1441 |       return clamp(Math.round(250 / sa.cast), 2, 6);
 1442 |     }
 1443 |     const sa = ST.get(a), p = chooseSkill(W, f, a, d, ctx);
 1444 |     if (p) { useSkill(W, f, a, d, p, ctx); return clamp(Math.round(p.wind * 100 / sa.cast), 2, 18); }
 1445 |     C.strike(W, f, a, d, { M: 1 });
 1446 |     return clamp(Math.round(400 / sa.cast), 2, 9);
```

### tick ผู้ต่อสู้ · บรรทัด 1480–1512

```javascript
 1480 |   C.fightStep = (W, n) => {
 1481 |     const f = C.fightOf(W, n);
 1482 |     if (!f || f.over) { C.leave(W, n); return; }
 1483 |     if (n.dead) return;
 1484 |     if (n.yield || n.fled) { // ยอมแพ้/หนี: ถอยออกจากวงและพักรักษา
 1485 |       if (n.fled && !n.fleeTo) { const b = W.map.byId.infirmary; n.fleeTo = { x: b.door.x, y: b.door.y }; AI.goTo(W, n, n.fleeTo.x, n.fleeTo.y); }
 1486 |       if (n.path) AI.stepMove(W, n); return;
 1487 |     }
 1488 |     const ctx = n.act.ctx; C.statusTick(W, f, n); if (n.dead || n.yield || n.fled) return;
 1489 |     runPassiveProcs(W, f, n, null, 'combatTick', 0);
 1490 |     if (n.h.state.qi != null && n.cult && !STs().has(n, 'stygianFreeze', W.t)) {
 1491 |       const qm = CULT.qiMax(n);
 1492 |       const hasConduit = STs().hasBuff && STs().hasBuff(n, 'qiConduit', W.t);
 1493 |       const stSpec = STs().getActiveStanceSpec ? STs().getActiveStanceSpec(n) : null;
 1494 |       const stQiMult = (stSpec && stSpec.qiRegenBonus) ? (1 + stSpec.qiRegenBonus) : 1.0;
 1495 |       const qRegen = ((n.cult.path === 'XIAN' ? 0.0075 : 0.006) + (hasConduit ? 0.015 : 0)) * stQiMult;
 1496 |       n.h.state.qi = Math.min(qm, n.h.state.qi + qm * qRegen);
 1497 |     }
 1498 |     if (f.state === 'gather') {
 1499 |       const ar = f.arena; if (Math.hypot(n.x - ar.x, n.y - ar.y) > 5 + (f.A.indexOf(n.id) + f.B.indexOf(n.id) + 1) % 3) { if (!n.path) AI.goTo(W, n, Math.floor(ar.x + (C.sideOf(f, n.id) === 'A' ? -3 : 3)), Math.floor(ar.y)); AI.stepMove(W, n); } else n.path = null;
 1500 |       return;
 1501 |     }
 1502 |     let t = C.unit(W, ctx.target);
 1503 |     if (!C.alive(t)) { const en = C.enemies(W, f, n.id); if (!en.length) return; en.sort((a, b) => Math.hypot(a.x - n.x, a.y - n.y) - Math.hypot(b.x - n.x, b.y - n.y)); t = en[0]; ctx.target = t.id; n.path = null; }
 1504 |     const d = Math.hypot(t.x - n.x, t.y - n.y);
 1505 |     const wProf = (SKs() && SKs().weaponTacticalProfile) ? SKs().weaponTacticalProfile(n) : null;
 1506 |     const engageLim = (wProf && n._closedOnBy !== t.id) ? (wProf.engageRange || 1.7) : 1.7;
 1507 |     if (d > engageLim) { moveToward(W, n, t.x, t.y, true); n.face = t.x >= n.x ? 1 : -1; return; }
 1508 |     n.face = t.x >= n.x ? 1 : -1; n.path = null;
 1509 |     if (--ctx.cd > 0) return;
 1510 |     if (g.CPE && g.CPE.fightUse(W, n, ctx)) { ctx.cd = 2; return; }
 1511 |     ctx.cd = C.attack(W, f, n, t);
 1512 |   };
```

### tick ศัตรู · บรรทัด 1521–1545

```javascript
 1521 |   C.foeStep = (W, u) => {
 1522 |     if (u.dead || u.gone) return;
 1523 |     u.px = u.x; u.py = u.y;
 1524 |     if (u.isSummon) {
 1525 |       if (u.dur != null && --u.dur <= 0) {
 1526 |         u.dead = true; u.gone = true;
 1527 |         u.fx = { t: W.t, text: '💨 หมดเวลา' };
 1528 |         return;
 1529 |       }
 1530 |     }
 1531 |     if (u.fled) { moveToward(W, u, MAP.EXIT.x, MAP.EXIT.y, true); if (Math.hypot(u.x - MAP.EXIT.x, u.y - MAP.EXIT.y) < 3) { u.gone = true; } return; }
 1532 |     const f = u.act && u.act.ctx && u.act.ctx.fid ? (W.fights || []).find(q => q.id === u.act.ctx.fid) : null;
 1533 |     if (!f) { u.gone = true; return; }
 1534 |     const ctx = u.act.ctx; C.statusTick(W, f, u); if (u.dead) return; if (STs().has(u, 'stun')) return;
 1535 |     let t = C.unit(W, ctx.target);
 1536 |     if (!C.alive(t) || t.hidden && (W.t % 10 === 0)) { const en = C.enemies(W, f, u.id).filter(x => !x.hidden && !x.away); if (!en.length) { // ไม่มีผู้ป้องกันในสนาม: มุ่งสู่ใจกลางสำนัก
 1537 |         const mh = W.map.byId.main_hall; moveToward(W, u, mh.x + mh.w / 2, mh.y + mh.h + 2, false); u.reachedCore = Math.hypot(u.x - (mh.x + mh.w / 2), u.y - (mh.y + mh.h + 2)) < 3; return; }
 1538 |       en.sort((a, b) => Math.hypot(a.x - u.x, a.y - u.y) - Math.hypot(b.x - u.x, b.y - u.y)); t = en[0]; ctx.target = t.id; }
 1539 |     const d = Math.hypot(t.x - u.x, t.y - u.y);
 1540 |     if (d > 1.7) { moveToward(W, u, t.x, t.y, false); return; }
 1541 |     u.face = t.x >= u.x ? 1 : -1;
 1542 |     if (--ctx.cd > 0) return;
 1543 |     ctx.cd = C.attack(W, f, u, t);
 1544 |   };
 1545 | 
```

### ตรวจจบศึก · บรรทัด 1553–1574

```javascript
 1553 |         const near = all.every(u => Math.hypot(u.x - f.arena.x, u.y - f.arena.y) < 8);
 1554 |         if (near || W.t - f.t0 > 400) { f.state = 'fight'; all.forEach(u => { u.path = null; }); }
 1555 |         continue;
 1556 |       }
 1557 |       if (!f._roundStartFired) {
 1558 |         f._roundStartFired = true;
 1559 |         [].concat(f.A, f.B).map(i => C.unit(W, i)).filter(C.alive).forEach(u => runPassiveProcs(W, f, u, null, 'onRoundStart', 0));
 1560 |       }
 1561 |       if (C.COMPOSABLE_ENGINE) {
 1562 |         if (C.COMPOSABLE_ENGINE.tickDomain && f.activeDomain) C.COMPOSABLE_ENGINE.tickDomain(W, f);
 1563 |         if (C.COMPOSABLE_ENGINE.tickDelayedEchoes && f.delayedEchoes && f.delayedEchoes.length) C.COMPOSABLE_ENGINE.tickDelayedEchoes(W, f);
 1564 |         if (C.COMPOSABLE_ENGINE.decayElementalAuras) C.COMPOSABLE_ENGINE.decayElementalAuras(W, f);
 1565 |       }
 1566 |       const a = f.A.map(i => C.unit(W, i)).filter(C.alive), b = f.B.map(i => C.unit(W, i)).filter(C.alive);
 1567 |       const timeout = W.t - f.t0 > (f.kind === 'raid' ? 900 : 300);
 1568 |       if (!a.length || !b.length || timeout) {
 1569 |         [].concat(a, b).forEach(u => runPassiveProcs(W, f, u, null, 'onRoundEnd', 0));
 1570 |         f.over = true; f.winner = timeout ? (f.kind === 'raid' ? 'B' : null) : (a.length ? 'A' : 'B'); C.conclude(W, f);
 1571 |       }
 1572 |     }
 1573 |     W.fights = fl.filter(f => !f.over || W.t - f.t0 < 5);
 1574 |     C.processQueue(W); C.tournamentTick(W);
```

### callback เมื่อจบศึก · บรรทัด 1600–1603

```javascript
 1600 |     }
 1601 |     if (f.kind === 'wild' && g.WILD) g.WILD.finish(W, f, ws);
 1602 |     if (f.cb) f.cb(W, f, ws, winners, losers);
 1603 |   };
```

### ตัวเลือกเป้าหมาย · บรรทัด 2916–2972

```javascript
 2916 |   COMPOSABLE_ENGINE.selectTargets = (W, f, a, d, p) => {
 2917 |     const comp = (p && p.composable) || {};
 2918 |     const sel = comp.targetSelector || (p && p.targetSelector) || null;
 2919 |     const enemies = C.enemies(W, f, a.id).filter(u => C.alive(u));
 2920 |     const allies = C.alliesOf(W, f, a.id).filter(u => C.alive(u));
 2921 |     // Taunt override for single-target enemy selectors
 2922 |     const tauntStatus = STs().statusOf(a, 'taunted', W.t);
 2923 |     if (tauntStatus && tauntStatus.taunterId) {
 2924 |       const taunter = enemies.find(u => u.id === tauntStatus.taunterId);
 2925 |       if (taunter && (!sel || sel === 'SINGLE_ENEMY' || sel === 'LOWEST_HP_ENEMY' || sel === 'HIGHEST_ATK_ENEMY')) {
 2926 |         return [taunter];
 2927 |       }
 2928 |     }
 2929 |     if (!sel) {
 2930 |       if (p.arch === 'chainRicochet') {
 2931 |         return enemies.slice().sort((x, y) => Math.hypot(x.x - (d ? d.x : a.x), y.y - (d ? d.y : a.y)) - Math.hypot(y.x - (d ? d.x : a.x), y.y - (d ? d.y : a.y))).slice(0, 4);
 2932 |       }
 2933 |       if (p.aoe) {
 2934 |         return enemies.filter(x => !d || Math.hypot(x.x - d.x, x.y - d.y) < 2.8);
 2935 |       }
 2936 |       return d ? [d] : enemies.slice(0, 1);
 2937 |     }
 2938 |     if (sel === 'SELF') return [a];
 2939 |     if (sel === 'ALL_ALLIES') return allies;
 2940 |     if (sel === 'LOWEST_HP_ALLY') {
 2941 |       return allies.slice().sort((x, y) => (C.hp(x) / Math.max(1, C.hpMax(x))) - (C.hp(y) / Math.max(1, C.hpMax(y)))).slice(0, 1);
 2942 |     }
 2943 |     if (sel === 'SAME_PATH_ALLIES') {
 2944 |       const path = a.cult && a.cult.path;
 2945 |       const matched = allies.filter(u => u.cult && u.cult.path === path);
 2946 |       return matched.length ? matched : [a];
 2947 |     }
 2948 |     if (sel === 'SUMMON_OR_PUPPET') {
 2949 |       const sums = allies.filter(u => u.isSummon || (u.cult && u.cult.path === 'MECH_PUPPET'));
 2950 |       return sums.length ? sums : [a];
 2951 |     }
 2952 |     if (!enemies.length) return d ? [d] : [];
 2953 |     if (sel === 'ALL_ENEMIES') return enemies;
 2954 |     if (sel === 'LOWEST_HP_ENEMY') {
 2955 |       return enemies.slice().sort((x, y) => (C.hp(x) / Math.max(1, C.hpMax(x))) - (C.hp(y) / Math.max(1, C.hpMax(y)))).slice(0, 1);
 2956 |     }
 2957 |     if (sel === 'HIGHEST_ATK_ENEMY') {
 2958 |       const ST = STs();
 2959 |       return enemies.slice().sort((x, y) => Math.max(ST.get(y).atk, ST.get(y).matk) - Math.max(ST.get(x).atk, ST.get(x).matk)).slice(0, 1);
 2960 |     }
 2961 |     if (sel === 'MARKED_ENEMIES') {
 2962 |       const marked = enemies.filter(u => COMPOSABLE_ENGINE.totalMarksOn(u, W.t) > 0 || (u.sx && u.sx.some(s => s.until > W.t && ['burn', 'bleed', 'poison', 'curse'].includes(s.k))));
 2963 |       return marked.length ? marked : (d ? [d] : enemies.slice(0, 1));
 2964 |     }
 2965 |     if (sel === 'RICOCHET_CHAIN' || sel === 'SPLASH_NEIGHBORS' || sel === 'PIERCE_LINE') {
 2966 |       const limit = sel === 'RICOCHET_CHAIN' ? 4 : 3;
 2967 |       return enemies.slice().sort((x, y) => Math.hypot(x.x - (d ? d.x : a.x), y.y - (d ? d.y : a.y)) - Math.hypot(y.x - (d ? d.x : a.x), y.y - (d ? d.y : a.y))).slice(0, limit);
 2968 |     }
 2969 |     return d ? [d] : enemies.slice(0, 1);
 2970 |   };
 2971 | 
 2972 |   COMPOSABLE_ENGINE.preExecuteSkill = (W, f, a, d, p, ctx) => {
```

## GAME_SOURCE/js/skills.js

### สร้าง profile จากกระบวนท่า · บรรทัด 244–260

```javascript
  244 |   SK.moveProfile = (t, m) => {
  245 |     if (!t || !m) return null;
  246 |     const key = t.id + '::' + m.id;
  247 |     if (moveCache[key]) return moveCache[key];
  248 |     const arch = m.arch && SK.ARCH[m.arch] ? m.arch : 'strike';
  249 |     const A = SK.ARCH[arch], tier = t.tier || 1;
  250 |     const el = SK.ELEM[t.element] || SK.ELEM.NEUTRAL;
  251 |     const isPrimary = Array.isArray(t.moveDefs) && t.moveDefs[0] === m;
  252 |     const prof = {
  253 |       id: isPrimary ? t.id : m.id,
  254 |       moveId: m.id,
  255 |       tech: t.id,
  256 |       parentNameTh: t.nameTh,
  257 |       nameTh: m.nameTh,
  258 |       stageReq: m.stageReq || 1,
  259 |       reqMastery: m.reqMastery || m.minMastery || 0,
  260 |       reqCultStage: m.reqCultStage || t.reqTier || tier,
```

### ฟิลด์พื้นฐานกระบวนท่า · บรรทัด 261–280

```javascript
  261 |       tier,
  262 |       grade: t.grade || 'Common',
  263 |       legendary: !!t.legendary,
  264 |       arch,
  265 |       archTh: A.nameTh,
  266 |       icon: A.icon,
  267 |       type: m.type || (t.path === 'BODY' ? 'p' : 'm'),
  268 |       element: t.element || 'NEUTRAL',
  269 |       elementProfile: t.elementProfile || (g.ELEM && g.ELEM.getTargetProfile(t)) || null,
  270 |       elemTh: el.nameTh,
  271 |       cd: m.cd || A.cd,
  272 |       wind: m.wind || A.wind,
  273 |       hits: m.hits != null ? m.hits : A.hits,
  274 |       M: m.M != null ? m.M : (m.mult != null ? m.mult : 1.2),
  275 |       costPct: m.costPct != null ? m.costPct : (m.qiCost != null ? Math.round(m.qiCost * 0.45 * 10) / 10 : Math.round(4 * A.cost * (1 + 0.45 * (tier - 1)) * 10) / 10),
  276 |       pen: m.pen != null ? m.pen : (m.penAdd != null ? m.penAdd : (A.penAdd || 0)),
  277 |       critAdd: m.critAdd || 0,
  278 |       aoe: m.aoe != null ? !!m.aoe : !!A.aoe,
  279 |       steal: m.steal != null ? m.steal : (A.steal || 0),
  280 |       dot: m.dot || 0,
```

### composable และความเข้ากันได้ · บรรทัด 300–342

```javascript
  300 |       drawback: m.drawback || null,
  301 |       aiRole: m.aiRole || null,
  302 |       fxKind: m.fxKind || t.fxKind || null,
  303 |       composable: m.composable || t.composable || null,
  304 |       targetSelector: m.targetSelector || (m.composable && m.composable.targetSelector) || t.targetSelector || (t.composable && t.composable.targetSelector) || null,
  305 |       condition: m.condition || (m.composable && m.composable.condition) || t.condition || (t.composable && t.composable.condition) || null,
  306 |       action: m.action || (m.composable && m.composable.action) || t.action || (t.composable && t.composable.action) || null,
  307 |       actions: m.actions || (m.composable && m.composable.actions) || t.actions || (t.composable && t.composable.actions) || null,
  308 |       stanceShift: m.stanceShift || (m.composable && m.composable.stanceId) || t.stanceShift || null,
  309 |       comboPrimer: !!(m.comboPrimer || (m.composable && m.composable.comboPrimer)),
  310 |       comboFinisher: !!(m.comboFinisher || (m.composable && m.composable.comboFinisher)),
  311 |       markPrimer: m.markPrimer || (m.composable && m.composable.markPrimer) || null,
  312 |       markDetonate: m.markDetonate || (m.composable && m.composable.markDetonate) || null,
  313 |       elementalFusion: m.elementalFusion || (m.composable && m.composable.elementalFusion) || t.elementalFusion || null,
  314 |       statusTransmute: m.statusTransmute || (m.composable && m.composable.statusTransmute) || null,
  315 |       sacrificeOverdrive: m.sacrificeOverdrive || (m.composable && m.composable.sacrificeOverdrive) || null,
  316 |       tetherLink: m.tetherLink || (m.composable && m.composable.tetherLink) || null,
  317 |       domain: m.domain || (m.composable && m.composable.domain) || t.domain || null,
  318 |       acupointStrike: m.acupointStrike || (m.composable && m.composable.acupointStrike) || t.acupointStrike || null,
  319 |       delayedEcho: m.delayedEcho || (m.composable && m.composable.delayedEcho) || null,
  320 |       taunt: m.taunt || (m.composable && m.composable.taunt) || false,
  321 |       knockback: m.knockback || (m.composable && m.composable.knockback) || null,
  322 |       poiseDamage: m.poiseDamage || (m.composable && m.composable.poiseDamage) || 0,
  323 |       chargeStage: m.chargeStage || (m.composable && m.composable.chargeStage) || 0,
  324 |       coCast: m.coCast || (m.composable && m.composable.coCast) || t.coCast || null,
  325 |       cleanseToPower: m.cleanseToPower || (m.composable && m.composable.cleanseToPower) || false,
  326 |       contagion: m.contagion || (m.composable && m.composable.contagion) || false,
  327 |       phoenixClause: m.phoenixClause || (m.composable && m.composable.phoenixClause) || false,
  328 |       tags: m.tags || t.tags || null,
  329 |       reqPath: t.reqPath || (t.path !== 'ANY' ? t.path : null),
  330 |       bonusPath: t.bonusPath || t.compatiblePaths || null,
  331 |       reqSubpath: t.reqSubpath || null,
  332 |       bonusSubpath: t.bonusSubpath || t.preferredSubs || (t.sub ? [t.sub] : null),
  333 |       reqWeapon: t.requiresWeapon ? t.weaponTypes : null,
  334 |       bonusWeapon: t.weaponTypes || null,
  335 |       reqElement: t.reqElement || null,
  336 |       bonusElement: t.bonusElement || (t.element !== 'NEUTRAL' ? t.element : null),
  337 |       weaponTypes: t.weaponTypes,
  338 |       armorTypes: t.armorTypes,
  339 |       requiresWeapon: t.requiresWeapon,
  340 |       moves: [m.nameTh]
  341 |     };
  342 |     prof.summary = SK.summary(prof) + ((t.weaponTypes || t.armorTypes) ? ' · ' + g.JD.MARTIAL.types[(t.weaponTypes || t.armorTypes)[0]] + ' ' + (t.requiresWeapon ? 'จำเป็นต้องใช้อาวุธนี้' : 'ถนัด ×1.15 / อื่น ×0.65') + '' : '');
```

### รวบรวมท่าที่ใช้ได้และท่าจากอุปกรณ์ · บรรทัด 551–590

```javascript
  551 |   SK.list = n => {
  552 |     if (n.foe) return n.skl || [];
  553 |     if (!n.cult) return [];
  554 |     const c = n.cult, tl = c.techs ? c.techs.length : 0, t0 = tl ? c.techs[0] : '', tL = tl ? c.techs[tl - 1] : '';
  555 |     const eq = n.equip || {};
  556 |     const eqKey = ((eq.WEAPON && (eq.WEAPON.uid || eq.WEAPON.id) && (!g.MARTIAL || !g.MARTIAL.gearUsable || g.MARTIAL.gearUsable(n, eq.WEAPON))) ? (eq.WEAPON.uid || eq.WEAPON.id) : '') + '|' +
  557 |                   ((eq.ARMOR && (eq.ARMOR.uid || eq.ARMOR.id) && (!g.MARTIAL || !g.MARTIAL.gearUsable || g.MARTIAL.gearUsable(n, eq.ARMOR))) ? (eq.ARMOR.uid || eq.ARMOR.id) : '') + '|' +
  558 |                   ((eq.ACCESSORY && (eq.ACCESSORY.uid || eq.ACCESSORY.id) && (!g.MARTIAL || !g.MARTIAL.gearUsable || g.MARTIAL.gearUsable(n, eq.ACCESSORY))) ? (eq.ACCESSORY.uid || eq.ACCESSORY.id) : '');
  559 |     const slc = n._skListCache;
  560 |     if (slc && slc.path === c.path && slc.sub === c.sub && slc.st === c.stage && slc.mantra === c.mantra && slc.tl === tl && slc.t0 === t0 && slc.tL === tL && slc.eqKey === eqKey && slc.ver === (n._passVer || 0)) {
  561 |       return slc.out;
  562 |     }
  563 |     const activeIds = (g.MARTIAL ? g.MARTIAL.activeTechs(n) : n.cult.techs).slice();
  564 |     if (g.MARTIAL && g.MARTIAL.activeInnateTechs) {
  565 |       for (const innId of g.MARTIAL.activeInnateTechs(n)) {
  566 |         if (!activeIds.includes(innId)) activeIds.push(innId);
  567 |       }
  568 |     }
  569 |     if (n.cult.mantra) {
  570 |       const mTech = CULT.tech(n.cult.mantra);
  571 |       if (mTech && Array.isArray(mTech.moveDefs) && mTech.moveDefs.length && !activeIds.includes(mTech.id)) {
  572 |         activeIds.push(mTech.id);
  573 |       }
  574 |     }
  575 |     const grantedIds = (g.MARTIAL && g.MARTIAL.grantedEquipmentTechs) ? g.MARTIAL.grantedEquipmentTechs(n) : [];
  576 |     for (const gid of grantedIds) {
  577 |       if (!activeIds.includes(gid)) activeIds.push(gid);
  578 |     }
  579 |     const hasSkillMods = g.MARTIAL && g.MARTIAL.hasEquipmentSkillModifiers && g.MARTIAL.hasEquipmentSkillModifiers(n);
  580 |     const out = [];
  581 |     for (const id of activeIds) {
  582 |       const t = CULT.tech(id);
  583 |       if (!t || t.passive || t.cat === 'PASSIVE') continue;
  584 |       const isGranted = grantedIds.includes(id) && !(c.techs && c.techs.includes(id));
  585 |       if (Array.isArray(t.moveDefs) && t.moveDefs.length) {
  586 |         const moves = isGranted ? SK.allMoves(t).slice(0, 2) : SK.unlockedMoves(n, t);
  587 |         for (const mv of moves) {
  588 |           const finalMv = hasSkillMods ? g.MARTIAL.applyEquipmentSkillModifiers(n, mv) : (isGranted ? Object.assign({}, mv, { fromEquipmentGrant: true }) : mv);
  589 |           if (isGranted) finalMv.fromEquipmentGrant = true;
  590 |           out.push(finalMv);
```

### โปรไฟล์อาวุธเชิงยุทธวิธี · บรรทัด 818–840

```javascript
  818 |   SK.weaponTacticalProfile = u => {
  819 |     if (!u || u.foe) {
  820 |       return { weaponType: 'FIST', reachClass: 'SHORT_SWIFT', engageRange: 1.7, isHeavyFist: false, hasLightness: false, hasDefenseTech: false, spec: SK.WEAPON_TACTICS.FIST };
  821 |     }
  822 |     const wType = (g.MARTIAL && g.MARTIAL.equippedType) ? g.MARTIAL.equippedType(u) : 'FIST';
  823 |     const sub = u.cult ? u.cult.sub : 'NONE';
  824 |     const path = u.cult ? u.cult.path : 'NONE';
  825 |     const isHeavyFist = wType === 'FIST' && (path === 'BODY' || SK.HEAVY_FIST_SUBPATHS.includes(sub));
  826 |     const baseSpec = SK.WEAPON_TACTICS[wType] || SK.WEAPON_TACTICS.FIST;
  827 |     const reachClass = isHeavyFist ? 'HEAVY_BREAKER' : baseSpec.reachClass;
  828 |     const hasLightness = SK.hasLightnessOrGapCloser(u);
  829 |     const hasDefenseTech = SK.hasDefensiveTech(u);
  830 |     return {
  831 |       weaponType: wType,
  832 |       reachClass,
  833 |       engageRange: baseSpec.engageRange || 1.7,
  834 |       isHeavyFist,
  835 |       hasLightness,
  836 |       hasDefenseTech,
  837 |       nameTh: isHeavyFist ? 'หมัดวัชระทลายปราการ' : baseSpec.nameTh,
  838 |       stanceTh: isHeavyFist ? 'หมัดหนักทลายโล่และเกราะคุ้มกาย' : baseSpec.stanceTh,
  839 |       counteredByTh: baseSpec.counteredByTh,
  840 |       descTh: baseSpec.descTh,
```

## GAME_SOURCE/js/sim.js

### ลำดับ tick ของโลก · บรรทัด 371–399

```javascript
  371 |   SIM.tick = W => {
  372 |     g.STATS.now = W.t;
  373 |     W.t++;
  374 |     const d = Math.floor(W.t / 1440);
  375 |     if (d !== W.day) { W.day = d; HC.nowDay = d; SIM.dailyUpdate(W); }
  376 |     const npcs = W.npcs;
  377 |     if (true) {
  378 |       let ap = 0;
  379 |       for (let i = 0; i < npcs.length; i++) {
  380 |         const x = npcs[i];
  381 |         if (x && !x.dead && !x.exiled) ap++;
  382 |       }
  383 |       W._alivePop = Math.max(1, ap);
  384 |     }
  385 |     for (let i = 0; i < npcs.length; i++) {
  386 |       const n = npcs[i]; if (n.dead) continue;
  387 |       if (n.travel) { n.px = n.x; n.py = n.y; AI.needs(W, n); if (!n.dead) EXPED.travelStep(W, n); if (n.away && n.exiled) { SIM.retire(W, n); i--; } continue; }
  388 |       if (n.away) continue;
  389 |       AI.step(W, n);
  390 |     }
  391 |     if (g.WILD) g.WILD.tick(W);
  392 |     if (g.WILD_RES) g.WILD_RES.tick(W);
  393 |     if (W.foes.length) EXPED.raidTick(W);
  394 |     if (g.WILD) g.WILD.clampCombat(W);
  395 |     COMBAT.tick(W);
  396 |     if (W.t % 60 === 0) SIM.hourly(W);
  397 |   };
  398 |   SIM.retire = (W, n) => {
  399 |     AI.cancelAct(W, n); AI.freeBed(W, n); if (n.post) { W.sect.posts[n.post] = null; n.post = null; }
```

### บันทึกสถานะและการตัด property ชั่วคราว · บรรทัด 656–665

```javascript
  656 |   SIM.serialize = W => {
  657 |     if (W && Array.isArray(W.npcs)) { for (let i = 0; i < W.npcs.length; i++) { if (W.npcs[i]) W.npcs[i]._cultRateBase = null; } }
  658 |     const M = W.map;
  659 |     const snap = { ...(W._saveExtras || {}), schemaVersion: SIM.SAVE_SCHEMA_VERSION, wildlife: W.wildlife, wildResources: W.wildResources, fishing: W.fishing, v: SIM.VERSION, runtimeTiming: W.runtimeTiming, hc: HC.FINGERPRINT, seed: W.seed, t: W.t, speed: W.speed, rng: W.rng.getState(), seqN: W.seqN, logSeq: W.logSeq, deaths: W.deaths, avgSat: W.avgSat, avgMood: W.avgMood, weather: W.weather, market: W.market, sect: W.sect, world: W.world, threat: W.threat, explore: W.explore, npcs: W.npcs, graveyard: W.graveyard, gone: W.gone, logs: W.logs.slice(-600), duelQueue: W.duelQueue, fights: W.fights, foes: W.foes, foeSeq: W.foeSeq, fightSeq: W.fightSeq,
  660 |       map: { extra: M.extraSt || [], buildings: M.buildings.map(b => ({ id: b.id, level: b.level, hp: b.hp, building: b.building || null })) } };
  661 |     return JSON.stringify(snap, (k, v) => ((k[0] === '_' && k !== '_ver') || k === 'jianghuSects' || k === 'inventoryIntelligence') ? undefined : v);
  662 |   };
  663 |   SIM.deserialize = str => {
  664 |     const s = JSON.parse(str);
  665 |     const object = v => v != null && typeof v === 'object' && !Array.isArray(v);
```

### โหลดสถานะโลกและศึก · บรรทัด 684–690

```javascript
  684 |     const stats = g.STATS, hadStatsTime = stats && Object.prototype.hasOwnProperty.call(stats, 'now'), statsTimeBefore = stats && stats.now;
  685 |     try {
  686 |       const W = SIM.create(s.seed, { masterIdx: 0 });
  687 |       W.rng.setState(s.rng); W.t = s.t; if (g.STATS) g.STATS.now = W.t; W.day = Math.floor(W.t / 1440); W.season = SIM.calendar(W.t).season; HC.nowDay = W.day; W.speed = s.speed == null ? 1 : s.speed; W.seqN = s.seqN; W.logSeq = s.logSeq; W.deaths = s.deaths; W.avgSat = s.avgSat; W.avgMood = s.avgMood; W.weather = s.weather; W.market = s.market; W.sect = s.sect; W.world = s.world; W.threat = s.threat; if (s.explore) W.explore = s.explore; W.graveyard = s.graveyard; W.gone = s.gone; W.logs = s.logs; W.duelQueue = s.duelQueue || []; W.fights = s.fights || []; W.foes = s.foes || []; W.foeSeq = s.foeSeq; W.fightSeq = s.fightSeq;
  688 |       W.foeById = {}; W.foes.forEach(u => W.foeById[u.id] = u);
  689 |       W.wildlife = s.wildlife || { seq: 0, beasts: [], kills: 0 };
  690 |       W.wildlife.beasts = W.wildlife.beasts.map(b => W.foeById[b.id] || b);
```

## GAME_SOURCE/js/expedition.js

### เริ่มศึกบุกสำนัก · บรรทัด 879–900

```javascript
  879 |   X.spawnRaid = (W, kind, strength) => {
  880 |     const rng = W.rng; const tops = W.npcs.filter(n => !n.dead && !n.away && n.cult).map(n => CULT.power(n)).sort((a, b) => b - a).slice(0, 8);
  881 |     const base = tops.reduce((s, v) => s + v, 0) || 80;
  882 |     const total = base * (strength || (0.3 + rng.next() * 0.55));
  883 |     let foes = []; let label;
  884 |     if (kind === 'beast') {
  885 |       const maxTier = Math.max(1, Math.min(5, Math.round(Math.log(Math.max(total, 40) / 70) / Math.log(2.2))));
  886 |       const pool = JD.BEASTS.species.filter(b => !b.sourcePack && b.canRaidLand !== false && b.terrain !== 'water' && b.tier <= maxTier && b.tier >= Math.max(1, maxTier - 2));
  887 |       const sp = rng.pick(pool); const n = clamp(Math.round(total / sp.cp), 1, 8);
  888 |       for (let i = 0; i < n; i++) foes.push({ name: sp.nameTh, tier: sp.tier, power: sp.cp * (0.8 + rng.next() * 0.4), fleeAt: sp.flee / 100, kind: 'beast', sp: sp.id, speciesId: sp.id, element: sp.element, elementProfile: sp.elementProfile, drops: sp.drops });
  889 |       label = 'ฝูง' + sp.nameTh + ' ' + n + ' ตัว';
  890 |     } else {
  891 |       const rival = kind === 'rival' ? W.world.sects.slice().sort((a, b) => a.attitude - b.attitude)[0] : null;
  892 |       const n = clamp(Math.round(3 + total / 120), 3, 9);
  893 |       for (let i = 0; i < n; i++) { const boss = i === 0; foes.push({ name: (boss ? (rival ? 'หัวหน้าชุด' : 'หัวหน้าโจร') : (rival ? 'ศิษย์' + rival.nameTh : 'โจรภูเขา')), tier: boss ? 3 : 1, power: (total / n) * (boss ? 1.9 : 0.8) * (0.8 + rng.next() * 0.4), fleeAt: boss ? 0.15 : 0.3, kind: 'human', boss }); }
  894 |       label = (rival ? 'ศิษย์จาก' + rival.nameTh : 'โจรภูเขา') + ' ' + n + ' คน';
  895 |       if (rival) foes.rivalId = rival.id;
  896 |     }
  897 |     W.foes = W.foes || []; W.foeById = W.foeById || {};
  898 |     const f = COMBAT.startFight(W, [], [], 'raid', { serious: true, cb: X.raidEnd, ctx: { label, kind, total } });
  899 |     f.foes = [];
  900 |     foes.forEach((s, i) => { const id = 'F' + (++W.foeSeq || (W.foeSeq = 1)); const u = Object.assign({ id, foe: true, x: MAP.EXIT.x + .5 + (i % 4) * 1.1 - 1.6, y: MAP.EXIT.y + 0.5 + Math.floor(i / 4) * 1.1, px: 0, py: 0, face: 1, speed: 0.55 + s.tier * 0.02, dead: false, speedBase: 1 }, s); u.hpMax = Math.round(u.power * 1.3 + 30); u.hp = u.hpMax; W.foes.push(u); W.foeById[id] = u; f.B.push(id); f.foes.push(id); COMBAT.enter(W, f, id); });
```

### สัตว์พิทักษ์และฝ่ายในศึก · บรรทัด 940–948

```javascript
  940 |           id, foe: true, isGateBeast: true, sourceBeastUid: beast.uid || beast.id,
  941 |           name: beast.nameTh || species.nameTh || 'อสูรพิทักษ์ประตู', nameTh: beast.nameTh || species.nameTh || 'อสูรพิทักษ์ประตู',
  942 |           tier, level, power, hpMax, hp: Math.round(hpMax * ratio), dead: false, gone: false,
  943 |           kind: 'beast', family: beast.family || species.family, element: beast.element || species.element,
  944 |           bloodlineTrait: trait, fourSymbol, sovereignGuardUsed: false, fleeAt: 0,
  945 |           x: MAP.EXIT.x + (i - 1.5) * 1.1, y: MAP.EXIT.y + 2, px: 0, py: 0, face: 1, speed: 0.62 + tier * 0.025, speedBase: 1
  946 |         };
  947 |         W.foes.push(unit); W.foeById[id] = unit; f.A.push(id); COMBAT.enter(W, f, id); f.ctx.gateBeastIds.push(id);
  948 |       });
```

### สหายและฝ่ายในศึก · บรรทัด 960–972

```javascript
  960 |         const hpMax = Math.max(240, Math.round(power * 1.85));
  961 |         const id = 'ALLY_' + f.id + '_' + (++W.foeSeq || (W.foeSeq = 1));
  962 |         const allyName = ally.figureNameTh || ally.npcNameTh || 'สหายร่วมสาบาน';
  963 |         const unit = {
  964 |           id, foe: true, isSwornAlly: true, sourceBondId: ally.id,
  965 |           name: allyName, nameTh: allyName,
  966 |           tier, level: tier * 2, power, hpMax, hp: hpMax, dead: false, gone: false,
  967 |           kind: 'human', path: ally.path || 'SWORD', weaponType: ally.weaponType || 'SWORD', fleeAt: 0,
  968 |           x: MAP.EXIT.x + (idx - 0.5) * 1.4, y: MAP.EXIT.y + 1.5, px: 0, py: 0, face: 1, speed: 0.72, speedBase: 1
  969 |         };
  970 |         W.foes.push(unit); W.foeById[id] = unit; f.A.push(id); COMBAT.enter(W, f, id); f.ctx.swornAllyIds.push(id);
  971 |         ally.helpCount = (ally.helpCount || 0) + 1;
  972 |         ally.lastInteractionDay = W.day;
```

## GAME_SOURCE/js/explore.js

### ศึกแดนลับและการประเมินกำลัง · บรรทัด 7617–7668

```javascript
 7617 |   EX.resolveSanctum = (W, ex, members, opts) => {
 7618 |     opts = opts || {};
 7619 |     if (!W || !ex || ex.done || !Array.isArray(members) || !members.length) return null;
 7620 |     const sState = EX.ensureSanctums(W);
 7621 |     const sc = EX.SANCTUMS[ex.sanctumId || ex.region] || EX.SANCTUMS.SANCTUM_SWORD_ABYSS;
 7622 |     const alive = members.filter(m => m && !m.dead);
 7623 |     const out = { items: [], stones: 0, mats: {}, pills: {}, gear: [], techs: [], catalysts: {}, crystals: {}, recipes: [], bonusRewards: [], bonusReward: null, bonusRoll: null, retreated: false, failedFloor: null, notes: [], rep: 0, floorsCleared: 0, floorLogs: [] };
 7624 |     sState.runs = (sState.runs || 0) + 1;
 7625 |     const maxTargetFloor = clamp(ex.maxFloor != null ? ex.maxFloor : (opts.maxFloor != null ? opts.maxFloor : sc.floors.length), 1, sc.floors.length);
 7626 |     const formSyn = (g.COMBAT && g.COMBAT.evaluateFormationSynergy) ? g.COMBAT.evaluateFormationSynergy(alive) : { powerMultiplier: 1, damageMitigation: 0, auraNamesTh: [] };
 7627 |     if (formSyn.auraNamesTh && formSyn.auraNamesTh.length) {
 7628 |       out.notes.push('ค่ายกลประสานพลัง: ' + formSyn.auraNamesTh.join(' · '));
 7629 |     }
 7630 |     out.formationSynergies = formSyn.synergies || [];
 7631 | 
 7632 |     for (const fl of sc.floors) {
 7633 |       if (fl.floor > 1) {
 7634 |         const supportMember = alive.find(m => m.cult && m.cult.path === 'SAGE_SUPPORT');
 7635 |         if (supportMember && g.CULT && g.CULT.castHealOrBuff) {
 7636 |           alive.forEach(m => {
 7637 |             if (m && !m.dead && m.h && m.h.state && m.h.state.hp < CULT.hpMax(m) * 0.9) {
 7638 |               g.CULT.castHealOrBuff(W, supportMember, m, { free: true, healPct: 0.35, buffKey: 'vitalRegen', duration: 300 });
 7639 |             }
 7640 |           });
 7641 |         }
 7642 |       }
 7643 |       if (!alive.length || fl.floor > maxTargetFloor) break;
 7644 |       const lead = alive.slice().sort((a, b) => CULT.power(b) - CULT.power(a))[0];
 7645 |       const resSetDef = (g.MARTIAL && g.MARTIAL.RESONANCE_SETS && g.MARTIAL.RESONANCE_SETS[fl.subPath]) || { nameTh: 'ชุดสัจธรรม' + fl.subPath };
 7646 |       const guardian = {
 7647 |         id: 'GUARD_' + sc.id + '_F' + fl.floor,
 7648 |         foe: true,
 7649 |         nameTh: fl.guardianNameTh,
 7650 |         power: fl.basePower,
 7651 |         tier: fl.tier,
 7652 |         subPath: fl.subPath,
 7653 |         resonanceSetId: resSetDef.id || ('RES_' + fl.subPath),
 7654 |         resonancePieces: 3,
 7655 |         equip: { WEAPON: { slot: 'WEAPON', gearType: fl.weaponType, nameTh: fl.weaponType, tier: fl.tier } }
 7656 |       };
 7657 |       const tac = (g.COMBAT && g.COMBAT.resolveWeaponTactics) ? g.COMBAT.resolveWeaponTactics(lead, guardian, { dist: 2.2 }) : { dmgMult: 1, relation: 'NEUTRAL', noteTh: '' };
 7658 |       const partyPower = alive.reduce((sum, m) => {
 7659 |         const rs = (g.MARTIAL && g.MARTIAL.evaluateResonanceSet) ? g.MARTIAL.evaluateResonanceSet(m) : { active: false, pieces: 0 };
 7660 |         return sum + CULT.power(m) * (1 + (rs.active ? rs.pieces * 0.06 : 0));
 7661 |       }, 0) * (tac.dmgMult || 1) * (formSyn.powerMultiplier || 1);
 7662 |       const bossEffectivePower = fl.basePower * 1.12; // 3-piece boss resonance bonus
 7663 |       const winProb = clamp(partyPower / (partyPower + bossEffectivePower * 0.85), 0.05, 0.96);
 7664 |       const won = ex.forceFailFloor === fl.floor ? false : (ex.forceClear ? true : (W.rng ? W.rng.next() < winProb : true));
 7665 | 
 7666 |       const fLog = {
 7667 |         floor: fl.floor,
 7668 |         floorNameTh: fl.nameTh,
```

## GAME_SOURCE/js/sect.js

### ตัวอย่างการประลองแบบคำนวณกำลัง · บรรทัด 1253–1274

```javascript
 1253 |         n.inv.recipes = n.inv.recipes || [];
 1254 |         if (!n.inv.recipes.includes(matchedRecipe.id)) n.inv.recipes.push(matchedRecipe.id);
 1255 |         if (W && W.sect) W.sect.recipeTier = Math.max(W.sect.recipeTier || 2, matchedRecipe.tier || 3);
 1256 |       }
 1257 |     }
 1258 |     return { item: minted, recipe: matchedRecipe };
 1259 |   };
 1260 | 
 1261 |   SECT.simulateAssemblyBout = (W, a, b, opts) => {
 1262 |     opts = opts || {};
 1263 |     const tacA = (g.COMBAT && g.COMBAT.resolveWeaponTactics) ? g.COMBAT.resolveWeaponTactics(a, b, { dist: 2.2 }) : { dmgMult: 1, relation: 'NEUTRAL', noteTh: '' };
 1264 |     const tacB = (g.COMBAT && g.COMBAT.resolveWeaponTactics) ? g.COMBAT.resolveWeaponTactics(b, a, { dist: 2.2 }) : { dmgMult: 1, relation: 'NEUTRAL', noteTh: '' };
 1265 |     const resA = (g.MARTIAL && g.MARTIAL.evaluateResonanceSet) ? g.MARTIAL.evaluateResonanceSet(a) : { active: false, pieces: 0 };
 1266 |     const resB = (g.MARTIAL && g.MARTIAL.evaluateResonanceSet) ? g.MARTIAL.evaluateResonanceSet(b) : { active: false, pieces: 0 };
 1267 |     const formA = opts.useFormation && g.COMBAT && g.COMBAT.evaluateFormationSynergy ? g.COMBAT.evaluateFormationSynergy(opts.formationPartyA || a.conferenceParty || [a]) : { synergies: [], powerMultiplier: 1 };
 1268 |     const formB = opts.useFormation && g.COMBAT && g.COMBAT.evaluateFormationSynergy ? g.COMBAT.evaluateFormationSynergy(opts.formationPartyB || b.conferenceParty || [b]) : { synergies: [], powerMultiplier: 1 };
 1269 |     const powA = a.power != null ? a.power : CULT.power(a);
 1270 |     const powB = b.power != null ? b.power : CULT.power(b);
 1271 |     const scoreA = powA * (tacA.dmgMult || 1) * (1 + (resA.active ? resA.pieces * 0.04 : 0)) * (formA.powerMultiplier || 1) * (0.88 + (W.rng ? W.rng.next() * 0.24 : 0.12));
 1272 |     const scoreB = powB * (tacB.dmgMult || 1) * (1 + (resB.active ? resB.pieces * 0.04 : 0)) * (formB.powerMultiplier || 1) * (0.88 + (W.rng ? W.rng.next() * 0.24 : 0.12));
 1273 |     const win = scoreA >= scoreB ? a : b;
 1274 |     const lose = win === a ? b : a;
```
