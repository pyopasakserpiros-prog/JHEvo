# Implementation entry point

1. **First**: Read [`START_HERE_FOR_AI.md`](./START_HERE_FOR_AI.md) and follow its prioritized **Task-to-Skill Routing Matrix**.
2. **Current Baseline**: Patch v2.0.13 is implemented on branch `main`. Read [`PATCH_IMPLEMENTATION_REPORT_V2_0_13.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_13.md) (and [`PATCH_IMPLEMENTATION_REPORT_V2_0_12.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_12.md)) before planning follow-up work; `NEXT_PATCH_PROMPT_V2_0_12_EN.md` and `SUBSEQUENT_PATCH_PROMPT_V2_0_10_EN.md` are completed specifications retained as historical context, not requests to repeat those patches.
3. **Mandatory Skill Loading**: Before modifying any file in `GAME_SOURCE/`, read the matching Master Skill in `.agents/skills/<skill>/SKILL.md` (mirrored in `.codex/skills/<skill>/SKILL.md`).

---

# JianghuSect AI Agent & Codex Instructions

This repository contains the complete source and data for **JianghuSect Evolution (สำนักยุทธ์เจียงหู)**.
All AI assistants (Antigravity, Codex CLI, Gemini, Cursor, Claude Code) must follow the priority routing below.

## 1. Priority Skill Routing for Active & Upcoming Work

Always load only the skills relevant to the subsystem you are touching:

### Tier 1 — Deep-Dive Core Gameplay & Domain Skills (Read First for Feature Work)
1. **[`progression-design`](./.agents/skills/progression-design/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: 10 Major Cultivation Paths (`CRAFT_CREATION` included), 84 Subpaths, Stage Equivalence (`CULT.equivalentStage`), 15 Starting Sect Archetypes (`SECT.FOUNDATION_CURRICULUM`), Spirit Beast Companions/Breeding/War-Beasts/Mount Caravans, and Universal Dungeons (`EX.NINE_DAO_PAGODA`, `EX.ELEMENTAL_REALMS`).
2. **[`combat-design`](./.agents/skills/combat-design/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: Exact `COMBAT.strike` damage formula, 12 composite stats (`STATS.KEYS`), 8 timed buffs (`STATS.BUFF_CATALOG` with strict `until` expiration), 7 weapon classes, 29 Equipment Resonance Sets (`MARTIAL.RESONANCE_SETS`), Subpath Synergies (`MARTIAL.SYNERGIES`), Formation Synergies (`COMBAT.evaluateFormationSynergy`), and Grand Martial Conferences (`SECT.WORLD_MARTIAL_CONFERENCE`).
3. **[`ai-behavior-patterns`](./.agents/skills/ai-behavior-patterns/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: NPC Psychological Utility AI (`js/ai.js` `ScoreAcc` / `S.add` Thai reasons in `npc.why`), Goal-Driven Cognition & Build Improvisation (`js/cognition.js` `COG.evaluateBuildImprovisation`, aspirations, goals, 18 sect offices, zero-RNG rule), 12-Layer `HC` stats (`js/human_core.js`), and station reservation (`AI.freeStation`, `AI.reserve`, `AI.release`).
4. **[`procedural-gen`](./.agents/skills/procedural-gen/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: Procedural Equipment (`ECO.rollProceduralGear`), Ancient Sanctums (`EX.resolveSanctum`, `EX.NINE_DAO_PAGODA`, `EX.ELEMENTAL_REALMS` in `js/explore.js`), Expeditions & Caravans (`EXPED.caravan`, Spirit Mount Caravans `MOUNT_CHARGER`/`AVIAN`/`UNGULATE`), Sect Gate Raids & War-Beasts (`EXPED.spawnRaid`, `EXPED.rally`, `W.sect.gateBeasts` in `js/expedition.js`), Seeded `U.RNG`, `240×192` World Map, Southern Spirit River, and Fishing Monte Carlo loot tables.
5. **[`economy-balancing`](./.agents/skills/economy-balancing/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: Sect Stock (`W.sect.stock`), Spirit Stones (`W.sect.stones`), CP Monetary Ledger (`js/cpeco.js` `CPE.scarcity`/`CPE.priceOf` anti-arbitrage, `CPE.daily` inflation control, `CPE.welfareDaily`), Inventory Intelligence (`ECO.inventoryIntelligence`), Sanctum & Elemental Refinement Catalysts (`ECO.REFINEMENT_CATALYSTS`), Repair Stones (`ECO.REPAIR_STONES`), Procedural Craft Substitutions (`ECO.resolveCraftMaterials`), Idempotent Craft Receipts (`W.sect.craftTransactions`), External Market & Stale Gear Sales (`js/external_market.js` `EXT.sellStaleSectGear`), and `VASSAL_TREATY` tribute flows.
6. **[`game-ui-ux`](./.agents/skills/game-ui-ux/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: Wuxia UI drawers (`js/ui.js`), 72-cell Item Icon Atlas (`UI.resolveItemAtlasCell`), Responsive Grid/List Pagination (`UI.calcGridPageSize`), Single-Pass Positional Log Linkifier (`UI.linkify`), NPC/Sect/World sheets, and the 6-tab Edit Hub (`UI.rEdit` + `SECT.EDITOR`).
7. **[`game-data-integrity`](./.agents/skills/game-data-integrity/SKILL.md)** *(Deep-Dive Master)*
   - **Use for**: Adding/modifying items (`420` items), recipes (`631` `REC_*` / `ITEM_*` Dual-ID recipes), martial arts (`697` techniques + `87` mantras = `784`), weapon affinities, `elementProfile`, combat effects, and 100% Edit Hub spawner resolution.

### Tier 2 — Deep-Dive Architecture, Save, Performance & QA Guardrail Skills
8. **[`gameplay-architecture`](./.agents/skills/gameplay-architecture/SKILL.md)** *(Deep-Dive Master)* — Exact 40-script-tag invariant in `index.html`, matching source-module order in `test/load.js`, `W` single source of truth, simulation lifecycle, `SIM.expandStations` dormitory bed cap (`100` max), and `tools/build_single.js`.
9. **[`save-system-patterns`](./.agents/skills/save-system-patterns/SKILL.md)** *(Deep-Dive Master)* — `SIM.serialize` / `SIM.deserialize` (`js/sim.js` lines 534–620), automatic `_` transient cache stripping, canonical NPC hidden-class restoration on load, `W._saveExtras` forward compatibility, pointer rebinding, `ECO.ensureUniqueGearUids`, legacy craft receipt adoption, and dead-reference pruning.
10. **[`performance-budgeting`](./.agents/skills/performance-budgeting/SKILL.md)** & **[`web-performance`](./.agents/skills/web-performance/SKILL.md)** *(Deep-Dive Master)* — Maintaining `< 3.0 ms/tick` (80 NPCs, 80x+ speed) via `_stVer`, `_passVer`, `WeakMap` suitability/preference caches, `_stEarliestBuffExp`, `SIM_BUDGET_MS = 12`, `16×16` Canvas terrain chunk caching (`buildChunk`), and `measureCached`.
11. **[`qa-test-matrix`](./.agents/skills/qa-test-matrix/SKILL.md)** & **[`web-testing`](./.agents/skills/web-testing/SKILL.md)** *(Deep-Dive Master)* — Mandatory 4-step verification gate, 86 automated suites plus a full JavaScript syntax sweep (`87/87` groups in `test/run_all.js`, `tools/run_parallel_tests.js`), Node VM / DOM stub harness (`test/load.js`), and headless Chromium CDP (`tools/cdp_playwright.js`).

---

## 2. Mandatory Validation & Build Commands
Whenever modifying data, AI, progression, or combat code, **always run**:
```bash
node GAME_SOURCE/tools/validate_data_schema.js
cd GAME_SOURCE && node tools/build_single.js
node test/run_all.js
```

## 3. Non-Negotiable Constraints
- **Core Lock:** Never modify `GAME_SOURCE/js/human_core.js` (`HC.FINGERPRINT === '155:2f9c9dd7'`, SHA-256 locked).
- **Script Load Order:** Keep exactly 40 `<script>` tags in `GAME_SOURCE/index.html`; preserve the corresponding data and simulation module load order in `GAME_SOURCE/test/load.js` (which is a CommonJS loader, not an HTML file).
- **Thai Localization:** All user-facing items, martial arts, recipes, techniques, and `S.add` AI reasons MUST include Thai (`nameTh`).
