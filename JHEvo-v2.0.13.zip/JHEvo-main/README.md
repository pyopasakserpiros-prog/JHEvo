# JianghuSect — v2.0.13 Patch Complete

JianghuSect Evolution (JHEvo) is a browser-based cultivation and sect-management game. The `main` branch contains Patch v2.0.13.

**For an AI asked to continue development from this repository:** start with [`START_HERE_FOR_AI.md`](./START_HERE_FOR_AI.md) and read [`PATCH_IMPLEMENTATION_REPORT_V2_0_13.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_13.md). Note that [`NEXT_PATCH_PROMPT_V2_0_12_EN.md`](./NEXT_PATCH_PROMPT_V2_0_12_EN.md) is completed and retained as historical specification context.

- **Playable standalone game:** [`GAME_SOURCE/JianghuSect_single.html`](./GAME_SOURCE/JianghuSect_single.html)
- **Full source and tests:** [`GAME_SOURCE/`](./GAME_SOURCE/)
- **Current patch report:** [`PATCH_IMPLEMENTATION_REPORT_V2_0_13.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_13.md)
- **Previous patch reports:** [`PATCH_IMPLEMENTATION_REPORT_V2_0_12.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_12.md), [`WEAPON_PATH_COVERAGE_AUDIT_V2_0_12.md`](./WEAPON_PATH_COVERAGE_AUDIT_V2_0_12.md), [`PATCH_IMPLEMENTATION_REPORT_V2_0_11.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_11.md), [`PATCH_IMPLEMENTATION_REPORT_V2_0_10.md`](./PATCH_IMPLEMENTATION_REPORT_V2_0_10.md), [`PATCH_IMPLEMENTATION_REPORT.md`](./PATCH_IMPLEMENTATION_REPORT.md) (v2.0.9)
- **Completed patch specifications:** [`NEXT_PATCH_PROMPT_V2_0_12_EN.md`](./NEXT_PATCH_PROMPT_V2_0_12_EN.md), [`SUBSEQUENT_PATCH_PROMPT_V2_0_10_EN.md`](./SUBSEQUENT_PATCH_PROMPT_V2_0_10_EN.md) (completed specifications; retain as historical context)
- **Future roadmap:** [`FUTURE_ROADMAP_AND_IDEAS.md`](./FUTURE_ROADMAP_AND_IDEAS.md)
- **AI entry point and guardrails:** [`START_HERE_FOR_AI.md`](./START_HERE_FOR_AI.md), [`AGENTS.md`](./AGENTS.md)

## v2.0.13 highlights

- **Procedural Equipment Engine & Material-Substituted Forging:** Added `ECO.rollProceduralGear` across all 14 weapon/armor/accessory subtypes (strictly capped at T1–T4 to preserve T5–T7+ signature artifacts), persistent collision-free `uid` tracking (`ECO.ensureUniqueGearUids`), and 14 material-substituted procedural recipes (`REC_PROC_*`) with deterministic previews (`ECO.previewProceduralCraft`).
- **Durability (`100/100`), Retirement & 4 Qualities of Repair Stones:** Added combat/expedition wear on procedural gear, broken-gear lockout, salvage retirement, and 4 qualities of Repair Stones (`ITEM_REPAIR_STONE_1`..`4`) reducing `maxDur` by `25 / 20 / 15 / 10` down to `minMaxDur = 20`.
- **Complete 4-Step Sect Trading Cycle:** NPCs evaluate bag gear vs equipped gear, donate surplus for CP once (`donatedRewarded = true`), allow other disciples to buy donated `uid`s from `W.sect.gear`, and sell stale unsold gear (`>= 6` days) to external merchants for Spirit Stones while permanently removing sold `uid`s from the world.
- **10th Major Cultivation Path (`CRAFT_CREATION` — วิถีรังสรรค์โอสถและศาสตราเทวะ) & 6 Subpaths:** Added a dedicated production & creation cultivation path (`PILL_FURNACE_IMMORTAL`, `POISON_VENOM_CAULDRON`, `HEAVENLY_ANVIL_SMITH`, `SPIRIT_SWORD_ARTIFICER`, `RUNE_ARRAY_ENGRAVER`, `DIVINE_FLAME_SMELTER`) where brewing pills, forging gear, and engraving runes directly grant cultivation progress (`ECO.grantCraftCultivation`), complete with 6 innate techniques, 15 path techniques, 4 cross-path adaptable techniques, 3 mantras, 4 signature T5 items, and 2 resonance sets.
- **Comprehensive Bug & Game-Logic Review:** Fixed 11 issues across `stats.js`, `martial.js`, `economy.js`, `cpeco.js`, `external_market.js`, `expedition.js`, `sect.js`, `sim.js`, and `ui.js`.

## Verification

- Data schema validation: passed with 0 errors.
- Full regression run: 87/87 test groups passed (including `v213_procedural_equipment_and_review_suite`).
- The protected `human_core.js` SHA-256 and exact 40-script-tag invariant remain intact.
