# รายงานการพัฒนาและจุดตรวจสอบ (Checkpoint Implementation Report) — Patch v3.0.0: Tactical Combat & Living Chronicle Overhaul

- **ฐานแพ็กเกจตั้งต้น:** `JHEvo-main (12).zip` (ฐาน v2.0.35)
- **เวอร์ชันส่งมอบ (Checkpoint):** `v3.0.0` (`SIM.PATCH_VERSION === '3.0.0'`, `SIM.VERSION === '1.10.11'`, `SIM.SAVE_SCHEMA_VERSION === '3.0.0-tactical-chronicle'`)
- **ผู้พัฒนาและตรวจสอบ:** `Gemini Work Argon 4`
- **สถานะ `GAME_SOURCE/js/human_core.js`:** Byte-identical 100% (`HC.FINGERPRINT === '155:2f9c9dd7'`, SHA-256: `a0d393284fb4b136848e5b80e12f3edd2c4f9437c419c793c2a7e75d881c0542`)
- **สถานะไฟล์เดี่ยวออฟไลน์:** `GAME_SOURCE/JianghuSect_single.html` สร้างใหม่ตรงกับซอร์สทุกไฟล์ (`node tools/build_single.js`)
- **สถานะการตรวจสอบ Schema ข้อมูล:** `node tools/validate_data_schema.js` ผ่าน 100% (`0 errors, 0 warnings` ครอบคลุม 917 ไอเทม, 1,255 ตำรับ, 132 สายย่อย, 655 วรยุทธ์, 905 เอฟเฟกต์)
- **สถานะชุดทดสอบ (116 ชุดทดสอบใน `test/run_all.js`):** **ผ่าน 115 / 116 ชุดทดสอบ** (รวมชุดทดสอบใหม่ `test/v300_tactical_combat_and_living_chronicle_suite.js` 55 assertions ผ่าน 100%); เหลือเพียงชุดทดสอบประสิทธิภาพเบราว์เซอร์ 1 ชุด (`test/browser_mobile_perf.js`) ที่อยู่ในช่วง `2.925–3.315 ms/tick` (เกณฑ์ `< 3.0 ms/tick`) ซึ่งบันทึกรายละเอียดทางเทคนิคไว้ในหัวข้อที่ 5 เพื่อให้ตรวจสอบหรือปรับจูนต่อได้ทันที

## 1. สรุปการวิเคราะห์อิสระของ Gemini Work Argon 4 และการตัดสินใจเชิงสถาปัตยกรรม

ก่อนลงมือพัฒนา ได้วิเคราะห์ระบบคอมแบทและพงศาวดารจากซอร์สจริงและบันทึกข้อเสนอแนะแยกไว้ใน `PATCH_REPORTS/PROPOSAL_V3_0_0_TACTICAL_COMBAT_AND_COGNITION_OVERHAUL.md` (หมวดที่ 15: บทวิเคราะห์และข้อเสนอเพิ่มเติมของ Gemini Work Argon 4) โดยมีข้อค้นพบและการตัดสินใจสำคัญดังนี้:

1. **ความไม่ตรงกันของแกนเวลา (`1 tick = 1 นาทีเกม` vs วินาทีใน Proposal):**
   - ซอร์สจริงของเกมเดินเวลา `1 tick = 1 นาทีเกม` การลด `gcd` ลงต่ำกว่า `1` หรือเปลี่ยนความเร็วเดินเป็นวินาทีจะทำลายสมดุลอัตราผลาญปราณ (`qi`), ความทนทานศาสตรา (`dur`), และระยะเวลาบัฟ (`until = W.t + dur`) จึงคงหน่วยเวลา `tick` เดิมไว้ และใช้ระยะโจมตีแยกตามตระกูลอาวุธ (`COMBAT.WEAPON_BASE_RANGE`) ร่วมกับระบบก้าวพริบตา/เปลี่ยนระยะ (`reposition`) ที่ทำงานบนหน่วย `tick` เดิมอย่างปลอดภัย
2. **การเชื่อมต่อ 2 เครื่องยนต์การรบ (Live Tile Combat vs Abstract Multi-Party/Bout Combat):**
   - เกมมีทั้งการรบสดบนแผนที่ (`COMBAT.fightStep` ใน `js/combat.js`) และการจำลองศึกนอกสำนัก/ประลอง/ตีสำนัก (`EXPED`, `EXPLORE`, `SECT.simulateAssemblyBout`) หากแก้เฉพาะ `js/combat.js` การศึกกว่า 60% ของเกมจะไม่ได้รับผลจากแพตช์ v3.0.0 จึงสร้างฟังก์ชันกลาง `COMBAT.evaluateTacticalBoutSummary(partyA, partyB, opts)` เพื่อคำนวณความได้เปรียบเชิงระยะ (`rangeAdv`), การจัดขบวนทัพหน้า-ทัพหลัง (`frontlineRatio`), และการแก้ทางธาตุ/อาวุธ ส่งผลจริงต่อทั้งศึกสดและศึกจำลองทุกชนิด
3. **การแยกและเชื่อมโยงตัวตนของศัตรู 3 ประเภท (`u.wild`, `u.bandit`, `u.sectId`):**
   - แก้บัคที่สัตว์ป่าตามธรรมชาติ (`u.wild = true` จาก `js/wildlife.js`) ไม่ถูกนับเป็นสัตว์อสูรใน `SK.inferFoeWeaponType` และ `SK.foeSkills` ทำให้สัตว์ป่าใช้ท่าหมัดของมนุษย์ และเชื่อมสัญญาณความพ่ายแพ้ในการล่าสัตว์ (`hunt_loss`) จาก `COMBAT.applyDamage` กลับไปยัง `WILD.finish` และ `COG.remember` ที่เดิมมีโค้ดรอรับแต่ไม่เคยถูกเรียก
4. **การรักษา Determinism ของ `W.rng` ในระบบพงศาวดาร (`Living Chronicle v3.0.0`):**
   - การสร้างประโยคบรรยายแบบมีชีวิตและจดหมายเหตุ (`SIM.enrichLogNarrative`, `SIM.recordChronicleMilestone`, `SIM.summarizeChronicleForPlayer`) ใช้ deterministic hash จาก `(W.t, W.logSeq, id)` แทนการเรียก `W.rng` เพื่อไม่ให้การเขียนบันทึกไปเลื่อนสถานะ RNG ของโลกจำลอง

## 2. รายการระบบที่พัฒนาเสร็จสมบูรณ์ในแพตช์ v3.0.0

### 2.1 Pillar A — Tactical Combat Overhaul v3.0.0 (`js/skills.js`, `js/combat.js`, `js/expedition.js`, `js/explore.js`, `js/sect.js`)
- **ตารางระยะอาวุธและบทบาทการรบ (`COMBAT.WEAPON_BASE_RANGE`, `COMBAT.inferCombatRole`, `SK.enforceWeaponRangeFloor`):**
  - กำหนดระยะพื้นฐานและระยะเหมาะสม (`min`, `opt`, `max`, `sweetMin`, `sweetMax`, `closePen`) สำหรับอาวุธทั้ง 11 ตระกูล (`FIST`, `BLADE`, `SWORD`, `WHIP`, `SPEAR`, `STAFF`, `BRUSH`, `ZITHER`, `FOCUS`, `BOW`, `THROWING`) และ `BEAST_NATURAL`
  - จำแนกบทบาทการรบ 6 บทบาท (`TANK`, `MELEE`, `RANGED`, `CASTER`, `HEALER`, `ASSASSIN`) พร้อมแคช `u._roleCache`
- **ระบบเลือกเป้าหมายและสกัดกั้นแนวหน้า (`COMBAT.pickTarget`, `COMBAT.checkFrontlineIntercept`, `COMBAT.stepPositioning`):**
  - ประเมินคะแนนเป้าหมายจากระยะห่าง บทบาท ค่าความคุกคาม (`threatScore`) เป้าหมายที่กำลังร่ายวิชาสำคัญ และความแค้นส่วนตัว (`nemesis`/`rival`)
  - ระบบ `Bodyblock / Intercept` ให้แนวหน้า (`TANK`/`MELEE`) ที่มีปราณและพละกำลังพร้อม เข้าขวางการโจมตีระยะประชิดที่พุ่งเป้าหาแนวหลัง (`RANGED`/`CASTER`/`HEALER`) ในรัศมีคุ้มกัน
  - ระบบรักษาระยะ (`Kiting & Repositioning`) สำหรับสายยิงไกล/เวท/ซัพพอร์ต เมื่อถูกศัตรูประชิดตัว พร้อมติดคูลดาวน์และลดความเร็วเมื่อหลังชนขอบสนามรบ (`Cornered Penalty`)
- **ระบบก้าวพริบตา ท่าไม้ตาย และการสกัดขัดจังหวะ (`COMBAT.tryDodgeStep`, `COMBAT.beginCastTelegraph`, `COMBAT.tryInterruptCast`):**
  - วิชาขั้นสูง (`tier >= 4` หรือท่าไม้ตาย `ULTIMATE`) มีจังหวะตั้งท่าร่าย (`castingState`) ที่ผู้เล่นและ AI มองเห็นและสามารถใช้ท่าประเภท `control`, `stun`, `silence`, `burst` หรือสกัดจุดขัดจังหวะ (`Interrupt / Backlash`) ได้
  - ระบบก้าวพริบตาหลบฉาก (`Dodge Step`) คำนวณจากทักษะท่าร่าง (`MOVEMENT`) และความคล่องตัว
- **ความแตกต่างของ AI ศัตรู 3 ตระกูล (`BEAST_FERAL`, `BANDIT_OPPORTUNIST`, `SECT_TACTICAL`) และการสะสมบาดแผล/ปมแค้น (`COMBAT.recordCombatOutcomeHooks`):**
  - สัตว์อสูรเน้นพุ่งขย้ำเป้าหมายใกล้สุดและคลั่งเมื่อบาดเจ็บ; โจรภูเขาเน้นรุมเหยื่อที่อ่อนแอและหนีเมื่อเสียเปรียบ; ศิษย์สำนักคู่อริจัดขบวนรบ ประสานธาตุ และเล็งตัดแนวหลัง
  - บันทึกสถิติการสังหาร บาดแผลปราณ และความแค้นข้ามศึก (`combatHistory`, `nemesisId`) เชื่อมกับระบบจิตมาร (`HEART_DEMON`) และความทรงจำ (`COG.remember`)

### 2.2 Pillar B — Living Chronicle & Event Reporting Overhaul v3.0.0 (`js/sim.js`, `js/ui.js`)
- **การยกระดับบันทึกเหตุการณ์และจัดหมวดหมู่ (`SIM.classifyLogCategory`, `SIM.classifyLogSeverity`, `SIM.enrichLogNarrative`):**
  - จำแนกบันทึกทุกเหตุการณ์ออกเป็น 5 หมวดหมู่หลัก (`COMBAT`, `PROGRESSION`, `SECT`, `RELATIONS`, `WORLD`) และ 3 ระดับความสำคัญ (`MAJOR`, `NOTABLE`, `ROUTINE`)
  - เสริมคำบรรยายกลิ่นอายยุทธภพที่อ้างอิงชื่อตัวละคร ตำแหน่ง ขั้นพลัง วิชา และผลลัพธ์จริงโดยไม่กระทบ `W.rng`
- **คลังจดหมายเหตุสำนักและสรุปเหตุการณ์สำหรับผู้เล่น (`W.sect.chronicle`, `SIM.recordChronicleMilestone`, `SIM.summarizeChronicleForPlayer`):**
  - บันทึกเหตุการณ์สำคัญระดับ `MAJOR` ลงใน `W.sect.chronicle.milestones` พร้อมจัดเก็บสถิติรายหมวดหมู่
  - สร้างสรุปเหตุการณ์เด่น (`highlights`), ประเด็นที่เจ้าสำนักควรตัดสินใจ (`pendingAttention`), และบทสรุปย่อ (`digestTh`)
- **การรวมหมู่เหตุการณ์กิจวัตร (`UI.collapseRoutineLogs`) และหน้าต่าง UI พงศาวดารใหม่ (`js/ui.js`):**
  - ยุบรวมบันทึกกิจวัตรที่ซ้ำกันในช่วงเวลาใกล้เคียงกัน (`collapsedCount`) เพื่อไม่ให้รกหน้าต่างบันทึก
  - เพิ่มแถบตัวกรองระดับความสำคัญ (`ทั้งหมด`, `เหตุการณ์สำคัญ`, `เรื่องเด่น`, `สรุปเจ้าสำนัก`) และการ์ดสรุปพงศาวดารมีชีวิตในหน้าต่างบันทึก (`UI.rLog`) และแถบประวัติศาสตร์โลก (`UI.rWorldHist`)

## 3. การตรวจสอบและแก้ไขบัคทั่วทั้งเกม (Game-Wide Bug & Disconnected Systems Audit)

จากการตรวจสอบซอร์สและชุดทดสอบทั้งหมด 116 ชุด พบและแก้ไขบัคสำคัญดังนี้:
1. **ชุดทดสอบที่ขาดหายไป 7 ไฟล์ และ `test/_harness.js` (จากรายงานฐาน v2.0.35):**
   - สร้าง `test/_harness.js` และชุดทดสอบที่ถูกอ้างอิงใน `test/run_all.js` ครบทุกไฟล์ พร้อมลงทะเบียน `v234`, `v235`, และ `v300` เข้าสู่ `test/run_all.js` (รวม 116 ชุดทดสอบ)
2. **บัค `NaN` ใน `MARTIAL.progression` (`js/martial.js`):**
   - สายย่อยใหม่ 36 สายจากแพตช์ v2.3.4 มีออบเจกต์ชื่อภาษาไทยอยู่ใน `sub[0]` หรือ `sub[1]` ทำให้ `M.progression` บวกค่าออบเจกต์เข้ากับตัวเลขจนได้ `body.p = NaN` และ `life.aff = NaN` แก้ไขโดยตรวจ `typeof sub[0][k] === 'number'` และ `typeof sub[1][k] === 'number'`
3. **บัค `ธาตุundefined` ใน `SK.foeSkills` และ `SK.summary` (`js/skills.js`):**
   - ศัตรูที่สร้างสกิลผ่าน `SK.foeSkills` ไม่มีค่า `elem` และ `elemTh` ทำให้ป้ายแสดงผลขึ้นคำว่า `ธาตุundefined` แก้ไขโดยกำหนด `elem` และ `elemTh` ให้ครบทุกสกิลของศัตรูและเพิ่ม fallback ใน `SK.summary`
4. **บัคระบบล่าสัตว์ป่า (`hunt_loss`) ไม่เชื่อมต่อกับความทรงจำ NPC (`js/combat.js`, `js/wildlife.js`):**
   - เดิม `WILD.finish(W, f)` มีโค้ดรองรับ `f.outcome === 'hunt_loss'` แต่ `COMBAT.applyDamage` เรียก `COMBAT.endFight(W, f, 'foe')` ทันทีเมื่อศิษย์บาดเจ็บสาหัส ทำให้ `hunt_loss` ไม่เคยทำงาน แก้ไขให้ศิษย์ที่ล่าสัตว์ป่าตามลำพังและ HP ต่ำกว่า 18% ถอยทัพฉุกเฉินพร้อมส่ง `f.outcome = 'hunt_loss'` ไปยัง `WILD.finish` และบันทึก `COG.remember(W, n, { kind: 'hunt_loss', ... })` จริง
5. **บัค `X.rally` เรียก `AI.interruptFor` ซ้ำทุก 20 ticks บนศิษย์ที่กำลังซ่อนตัว (`js/expedition.js`):**
   - ระหว่างถูกบุกสำนัก ศิษย์ที่ซ่อนตัวอยู่แล้ว (`n.act.id === 'hide'`) หรือไม่มีเตียง (`n.bed == null`) ถูก `X.rally` เรียก `AI.interruptFor` ล้าง `n.path = null` ทุก 20 ticks ทำให้ค้างอยู่ในสถานะ `stage: 'move'` จนหมดเวลา `waited > 600` แก้ไขให้ข้ามผู้ที่กำลัง `hide` อยู่แล้ว และใช้จุดหลบภัยสำรองเมื่อไม่มีเตียง
6. **บัค `AI.interrupt` ขัดจังหวะศิษย์ทุก 5 ticks เมื่อโรงครัวหรือเรือนพยาบาลเต็ม (`js/ai.js`):**
   - ศิษย์ที่หิวหรือบาดเจ็บถูก `AI.interrupt` ล้างกิจกรรมเดิมทุก 5 ticks แม้ติดคูลดาวน์ `n.cool.eat > W.t` หรือไม่มีสถานีว่างในโรงครัว/เรือนพยาบาล ทำให้เสียเวลาตัดสินใจใหม่ซ้ำ ๆ แก้ไขให้ตรวจคูลดาวน์และสถานีว่างก่อนขัดจังหวะ

## 4. ผลการทดสอบจริง (Verification & QA Test Matrix)

- **`node tools/validate_data_schema.js`**: ผ่าน 100% (`0 errors, 0 warnings`)
- **`node test/v300_tactical_combat_and_living_chronicle_suite.js`**: ผ่าน 100% (`55 assertions`)
- **`node test/v235_comprehensive_mechanics_and_elemental_fusion_suite.js`**: ผ่าน 100% (`52 assertions`)
- **`node test/v234_expansion_suite.js`**: ผ่าน 100% (`1,210 assertions`)
- **`node test/npc_cognition.js`**: ผ่าน 100%
- **`node test/npc_life_authority_overhaul.js`**: ผ่าน 100%
- **`node test/diplomacy_sanctum_ancestral_suite.js`**: ผ่าน 100%
- **สรุปรวม `test/run_all.js`**: **ผ่าน 115 / 116 ชุดทดสอบ**

## 5. จุดที่กำลังปรับจูนและสถานะของชุดทดสอบที่เหลือ 1 ชุด (`test/browser_mobile_perf.js`)

### 5.1 พฤติกรรมที่พบใน `test/browser_mobile_perf.js`
- ชุดทดสอบ `test/browser_mobile_perf.js` ทดสอบครบทั้ง Responsive Viewports (`360px`, `412px`, `1280px`), Touch/Pointer Gestures, การเปิดหน้าต่าง UI ทั้ง 24 แท็บ + 30 อาคาร + แท็บ NPC, Save/Load Roundtrip, ความเร็ว `0x–48x` และการจำลองประชากรขนาดใหญ่ **80 NPCs เป็นเวลา 720 ticks รวดเดียว (12 ชั่วโมงเกม)** โดยกำหนดเกณฑ์ `largePopBench.avgMsPerTick < 3.0 ms` (เทียบเท่าเวลารวม 720 ticks `< 2,160 ms`)
- เราได้ปรับจูนประสิทธิภาพใน `js/proficiency.js`, `js/cpeco.js`, `js/knowledge.js`, `js/external_market.js`, `js/world_map.js`, `js/cultivation.js`, `js/cognition.js`, `js/content.js`, `js/economy.js`, `js/ai.js`, และ `js/sim.js` จนเวลาของ 720 ticks ลดลงจาก **`4,220 ms` (`5.86 ms/tick`)** ลงมาอยู่ที่ **`2,106–2,386 ms` (`2.925–3.315 ms/tick`)** (ผ่านเกณฑ์ที่ `2.925 ms/tick` ในบางรอบ และปริ่มเกณฑ์ที่ `3.1–3.3 ms/tick` เมื่อ CPU ของ VM มีโหลด)

### 5.2 สาเหตุทางเทคนิคของส่วนต่างอีก ~0.2–0.3 ms/tick (สำหรับช่วยกันดูต่อ)
จากการทำ Profiling รายฟังก์ชันในช่วง `W.t = 519243..519963` (ซึ่งเป็นช่วง 720 ticks ของ `largePopBench` ใน `test/browser_mobile_perf.js`) พบว่า:
1. **ช่วงเวลา 720 ticks ดังกล่าวข้ามเวลาเที่ยงคืน `W.t = 519840` (`Day 361`) พอดี:**
   - ที่ `W.t = 519840` ฟังก์ชัน `SIM.dailyUpdate(W)` ทำงาน 1 ครั้ง ซึ่งใช้เวลาราว `140–170 ms` ใน tick เดียว (คิดเป็นค่าเฉลี่ยเพิ่มขึ้น `~0.22 ms/tick` ตลอด 720 ticks)
   - ฟังก์ชันย่อยใน `SIM.dailyUpdate` ที่ยังใช้เวลาสูงสุดคือ `SECT.daily` (`~38 ms`), `EXPED.daily` (`~23 ms`), `CPE.daily` (`~25 ms`), และ `CONTENT.daily` (`~20 ms`)
2. **ฟังก์ชันที่ถูกเรียกถี่ที่สุดใน 720 ticks (80 NPCs):**
   - `AI.decide` (~380 ครั้ง รวม `~730 ms`): โดยเฉพาะการประเมิน `score` และ `where` ของกิจกรรมทั้งหมด 28 กิจกรรมเมื่อ NPC 80 คนจบงานพร้อมกันในช่วงหัวค่ำ-กลางคืน
   - `AI.needs` (57,600 ครั้ง รวม `~310 ms`): ทำงานทุก tick ต่อ NPC ทุกคน
   - `tick:cultivate` (~9,900 ครั้ง รวม `~150 ms`) และ `tick:farm` (~9,800 ครั้ง รวม `~68 ms`)

### 5.3 แนวทางปรับจูนต่อให้ต่ำกว่า `2.5 ms/tick` อย่างถาวร
1. **ใน `AI.decide` (`js/ai.js`):**
   - สามารถคัดกรองกิจกรรมที่ไม่มีทางเลือกได้ในสภาวะปัจจุบันออกก่อนคำนวณ `score` หรือแคชผลลัพธ์ของ `A[id].score` ที่ไม่เปลี่ยนใน tick เดียวกัน
2. **ใน `SIM.dailyUpdate` (`js/sim.js`, `js/sect.js`, `js/expedition.js`, `js/cpeco.js`):**
   - ลดการวนลูปซ้ำบน `W.npcs` ใน `SECT.evaluateSectTier`, `SECT.evaluateSectAlignment`, `CPE.welfareDaily`, และ `EXPED.daily`

## 6. รายการไฟล์ที่แก้ไขและเพิ่มใหม่ใน Checkpoint นี้

- **ซอร์สโค้ดหลัก (`GAME_SOURCE/js/`):**
  - `js/skills.js` — ระบบระยะอาวุธ `enforceWeaponRangeFloor`, การจำแนกอาวุธและสกิลของสัตว์ป่า (`u.wild`), แก้บัค `elemTh`
  - `js/combat.js` — Tactical Combat v3.0.0 (`WEAPON_BASE_RANGE`, `inferCombatRole`, `pickTarget`, `checkFrontlineIntercept`, `stepPositioning`, `tryDodgeStep`, `beginCastTelegraph`, `tryInterruptCast`, `evaluateTacticalBoutSummary`, `recordCombatOutcomeHooks`, และ `hunt_loss` hook)
  - `js/expedition.js` — เชื่อม `evaluateTacticalBoutSummary` เข้ากับศึกนอกสำนักและแก้บัค `X.rally` เรียก `AI.interruptFor` ซ้ำ
  - `js/explore.js` — เชื่อม `evaluateTacticalBoutSummary` เข้ากับการสำรวจดันเจี้ยน/โบราณสถาน
  - `js/sect.js` — เชื่อม `evaluateTacticalBoutSummary` เข้ากับการประลองสำนัก (`simulateAssemblyBout`)
  - `js/sim.js` — Living Chronicle v3.0.0 (`classifyLogCategory`, `classifyLogSeverity`, `enrichLogNarrative`, `recordChronicleMilestone`, `summarizeChronicleForPlayer`), อัปเดต `PATCH_VERSION = '3.0.0'`, และปรับจูน `SIM.tick`
  - `js/ui.js` — หน้าต่างพงศาวดารมีชีวิต, ตัวกรองระดับความสำคัญ (`MAJOR`/`NOTABLE`/`DIGEST`), และการยุบรวมบันทึกกิจวัตร (`collapseRoutineLogs`)
  - `js/martial.js` — แก้บัค `NaN` ใน `M.progression` สำหรับสายย่อย v2.3.4
  - `js/ai.js`, `js/cognition.js`, `js/cultivation.js`, `js/cpeco.js`, `js/knowledge.js`, `js/content.js`, `js/economy.js`, `js/proficiency.js`, `js/external_market.js`, `js/world_map.js` — แก้บัค `AI.interrupt` และปรับจูนประสิทธิภาพ Hot Loop
- **ชุดทดสอบ (`GAME_SOURCE/test/`):**
  - `test/v300_tactical_combat_and_living_chronicle_suite.js` (ชุดทดสอบใหม่สำหรับ v3.0.0 จำนวน 55 assertions)
  - `test/_harness.js` และชุดทดสอบที่เคยขาดหายไปรวมครบ 116 ชุดใน `test/run_all.js`
- **เอกสารและรายงาน (`PATCH_REPORTS/` และ Root):**
  - `PATCH_REPORTS/PROPOSAL_V3_0_0_TACTICAL_COMBAT_AND_COGNITION_OVERHAUL.md` (เพิ่มหมวดที่ 15: ข้อเสนอและบทวิเคราะห์ของ `Gemini Work Argon 4`)
  - `PATCH_REPORTS/PATCH_IMPLEMENTATION_REPORT_V3_0_0.md` (รายงานฉบับนี้)
  - `PATCH_REPORTS/README.md`, `AGENTS.md`, `README.md`, `project_status_and_ai_onboarding.md`
